package com.mando.scheduler.server;

public class SchedulerConstants {
	public static String PERIOD_EVERYDAY_10S_REPEAT    = "10 * * * * ?";  // 매일 10초 마다
	public static String PERIOD_EVERYDAY_1M_REPEAT     = "0 0/1 * * * ?"; // 매일 1분 마다
	public static String PERIOD_EVERYDAY_5M_REPEAT     = "0 0/5 * * * ?"; // 매일 5분 마다
	public static String PERIOD_EVERYDAY_12H           = "0 12 * * ?";	  //매일 12시(정오)
	public static String PERIOD_EVERYDAY_AM_10_15      = "0 15 10 ? * *";	//매일 오전 10시 15분
	public static String PERIOD_2016_EVERYDAY_AM_10_15 = "0 15 10 * * ? 2016";	//2016년에 매일 아침 10시 15분
	public static String PERIOD_EVERYDAY_PM_2H_1M_REPEAT  = "0 * 14 * * ?";		//매일 오후 2시 0분 ~ 59분
	public static String PERIOD_EVERYDAY_PM_2H_5M_REPEAT  = "0 0/5 14 * * ?";	//매일 오후 2시부터 2시 55분까지 5분마다
	public static String PERIOD_EVERYDAY_PM_2H_FROM_2H_5M_TO_1M_REPEAT  = "0 0-5 14 * * ?";			//매일 오후 2시부터 2시 5분까지 매분
	public static String PERIOD_EVERYYEAR_3M_WED_PM_2H_10M_AND_44M      = "0 10,44 14 ? 3 WED";		//매년 3월의 수요일마다 오후 2시 10분과 2시 44분
	public static String PERIOD_MONDAY_FROM_FRIDAY_TO_AM_10H_15M        = "0 15 10 ? * MON-FRI";	//월요일부터 금요일까지 오전 10시 15분
	public static String PERIOD_EVERYMONTH_15DAY_AM_10H_15M             = "0 15 10 15 * ?";			//매달 15일 오전 10시 15분
	public static String PERIOD_EVERYMONTH_LASTDAY_AM_10H_15M           = "0 15 10 L * ?";			//매달 마지막 날 오전 10시 15분
	public static String PERIOD_EVERYMONTH_LASTFRIDAY_AM_10H_15M        = "0 15 10 ? * 6L";			//매달 마지막 금요일 오전 10시 15분
	public static String PERIOD_EVERYMONTH_3WEEK_FRIDAY_AM_10H_15M      = "0 15 10 ? * 6#3";		//매달 3번째 금요일 오전 10시 15분
	public static String PERIOD_EVERYMONTH_FIRSTDAY_5D_REPEAT_AM_12H    = "0 0 12 1/5 * ?";			//매달 첫날부터 5일마다 12시(정오)
	public static String PERIOD_EVERYYEAR_11M_11D_AM_11H_11M            = "0 11 11 11 11 ?";		//매년 11월 11일 오전 11시 11분
	public static String PERIOD_EVERYDAY_PM_2H_5M_REPEAT_AND_PM_6H_5M_REPEAT        = "0 0/5 14,18 * * ?";	//매일 오후 2시부터 2시 55분까지 5분마다, 6시부터 6시 55분까지 5분마다
	public static String PERIOD_2016_FROM_2018_TO_EVERYMONTH_LASTFRIDAY_AM_10H_15M  = "0 15 10 ? * 6L 2016-2018";	//2016년부터 2018년까지 매달 마지막 금요일 오전 10시 15분
}
