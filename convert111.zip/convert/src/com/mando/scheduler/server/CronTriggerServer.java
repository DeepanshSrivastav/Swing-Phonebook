/* 
 * All content copyright Terracotta, Inc., unless otherwise indicated. All rights reserved. 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not 
 * use this file except in compliance with the License. You may obtain a copy 
 * of the License at 
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0 
 *   
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT 
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the 
 * License for the specific language governing permissions and limitations 
 * under the License.
 * 
 */

package com.mando.scheduler.server;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import org.apache.log4j.xml.DOMConfigurator;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;

import com.mando.scheduler.job.cdmConvertJob;


public class CronTriggerServer {
	
	static {
		DOMConfigurator.configure("log4j.xml");
	}
	
	org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(CronTriggerServer.class.getName());
	
	public void run() throws Exception {

		SchedulerFactory sf = new StdSchedulerFactory();
		Scheduler sched = sf.getScheduler();
		try {
			
			
			
			log.info("------------------- Initializing -------------------");
			
			
			CronTrigger triggerConvert = newTrigger().withIdentity("trigger1", "group1").withSchedule(cronSchedule(SchedulerConstants.PERIOD_EVERYDAY_1M_REPEAT)).build();
			
			JobDetail convertJob = newJob(cdmConvertJob.class).withIdentity("cdmConvertJob", "group1").build();
			sched.scheduleJob(convertJob, triggerConvert);
			
			
			sched.start();
			
		} catch (SchedulerException e1) {
			e1.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}finally{

		}
	}

	public static void main(String[] args) throws Exception {
		CronTriggerServer example = new CronTriggerServer();
		example.run();
	}

}
