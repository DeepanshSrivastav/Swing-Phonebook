package com.mando.scheduler.job;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;


@DisallowConcurrentExecution
public class cdmConvertJob implements Job {



	
	private static final String SYNC_TEMPLATE_FILE_NAME = "SyncSetting.seeb";
	private static  String WORKING_ROOT_DIR = null;
	private static  String COMPOSER_SYNC_EXE = null;

	

	
	private static final String STATUS_SUFFIX_READY = "_ready";
	private static final String STATUS_SUFFIX_DONE = "_done";
	private static final String STATUS_SUFFIX_ERROR = "_error";
	private static final String FILE_LIST   = "file.list";
	
	
	
	org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(cdmConvertJob.class.getName());
	
	
	public void execute(JobExecutionContext arg0) throws JobExecutionException {
		//log.debug("!!!!!!! CONVERT START !!!!!!!");
		
		
		log.debug("!!!!!!! CONVERT START !!!!!!!");
		
		
		try {
			
			Properties prop = new Properties();
			prop.load(this.getClass().getClassLoader().getResourceAsStream("com/mando/scheduler/job/config.properties"));
			
			
			WORKING_ROOT_DIR = prop.getProperty("WORKING_ROOT_DIR");;
			COMPOSER_SYNC_EXE = prop.getProperty("COMPOSER_SYNC_EXE");;
			
			
			//MapList mlECList = new MapList();
			
			File workRootDir = new File(WORKING_ROOT_DIR);
			File[] wDirs = workRootDir.listFiles();
			
			for (int i = 0; i < wDirs.length; i++) {
				
				String strWorkspace = null;
				try {
					File workspaceDir = wDirs[i];

					if (!workspaceDir.isDirectory())
						continue;

					String strCurrentFolder = workspaceDir.getName();
					strWorkspace = WORKING_ROOT_DIR + File.separator + strCurrentFolder;
					
					// if folder is be completed.
					if (strCurrentFolder.contains(STATUS_SUFFIX_DONE))
						continue;

					
					if (strCurrentFolder.contains(STATUS_SUFFIX_READY)) {
						
						//start conversion
						this.executeFileConversion(strWorkspace);
						
						//start rename file name
						this.renameSMG(strWorkspace);
											
						// ftp 
						this.transferFilesToPLM(strWorkspace);
						
						//
						this.removeCatiaFiles(strWorkspace);
						
						// rename folder ready -> done
						String strToChageWorkspace = strWorkspace.replaceAll(STATUS_SUFFIX_READY, STATUS_SUFFIX_DONE);
						new File(strWorkspace).renameTo(new File(strToChageWorkspace));
						
					}
					
				} catch (Exception e) {
					e.printStackTrace();
					String strToChageWorkspace = strWorkspace.replaceAll(STATUS_SUFFIX_READY, STATUS_SUFFIX_ERROR);
					new File(strWorkspace).renameTo(new File(strToChageWorkspace));
					
					log.debug("error", e);
					
				}
				
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	
	
	
	
	/**
	 * 
	 * @param strWorkspace
	 * @param strEONo
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void executeFileConversion(String strWorkspace) throws Exception { 

		try {
			
			
			
			log.info("********************************");
			log.info("Run Composersync");
			log.info("Workspace : " + strWorkspace);
			log.info("********************************");
			
			
//			String COMPOSER_SYNC_EXE = "C:\\Program Files\\Dassault Systemes\\CATIAComposer\\7.2\\Bin\\ComposerSync.exe" ;
//			String strSeebFile = "D:\\workspace_convert\\20170105_PKA17CP001\\SyncSetting.seeb";
//			String[] command = { COMPOSER_SYNC_EXE, "-batch", strSeebFile, "-verbose:no" };
			
			
			
			String strSeebFile = strWorkspace + java.io.File.separator +SYNC_TEMPLATE_FILE_NAME;
			
			List command = new ArrayList();
			command.add(COMPOSER_SYNC_EXE);
			command.add("-batch");
			command.add(strSeebFile);
			command.add("-verbose:no" );
			
			
			ProcessBuilder probuilder = new ProcessBuilder(command);
			Process process = probuilder.start();
			process.waitFor();
	        

	       
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

	}
	
	
	/**
	 * 
	 * @param strWorkspace
	 * @throws Exception
	 */
	private void renameSMG(String strWorkspace) throws Exception {

		try {
			
			log.info("********************************");
			log.info("Rename smg file");
			log.info("********************************");

			File fileList = new File(strWorkspace + File.separator + FILE_LIST);
			
			if(!fileList.exists())
				return;
			
			
			BufferedReader br = new BufferedReader(new FileReader(fileList));

			String line = null;

			while ((line = br.readLine()) != null) {

				
				if(StringUtils.isEmpty(line))
					continue;
				
				String[] arrInof = line.split("\\|");

				String strPartNo = arrInof[0];
				String strPartRev = arrInof[1];
				String strSmgFileName = arrInof[2];
				
				String strNewSmgFileName = strPartNo + "_" +strPartRev + ".smg";
				File smgFile = new java.io.File(strWorkspace + File.separator + strSmgFileName);
				if (smgFile.exists()) {
					
					File newFile = new File(strWorkspace + File.separator + strNewSmgFileName);
					smgFile.renameTo(newFile);
					
					
					log.info( "Smg File Name : " + strSmgFileName + " -> " + strNewSmgFileName);
					
				}
			}
			
			br.close();
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	 
	
	/**
	 * 
	 * @param strWorkspace
	 * @throws Exception
	 */
	private void removeCatiaFiles(String strWorkspace) throws Exception {
		
		try {
			
			
			log.info("********************************");
			log.info("Remove catia files");
			log.info("********************************");
			
			  java.io.File folder = new java.io.File(strWorkspace);
			  File[] files = folder.listFiles();
			  
			  for (int i = 0; i < files.length; i++) {
				  File file = files[i];
				  
				  String strFilaName = file.getName();
				  
				  if(strFilaName.contains(".CATProduct") || strFilaName.contains(".CATPart") ) {
					  file.delete();
					  log.info("Remove  : " + strFilaName);
				  }
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	/**
	 * 
	 * @param strWorkspace
	 * @param strEONo
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	private void transferFilesToPLM(String strWorkspace) throws Exception {
		
		try {
			
			
			log.info("********************************");
			log.info("Transfer smg file");
			log.info("********************************");

			Properties prop = new Properties();
			prop.load(this.getClass().getClassLoader().getResourceAsStream("com/mando/scheduler/job/config.properties"));

			String strLocalFolder = strWorkspace;

			
			String strSiteName = prop.getProperty("CDM_CURRENT_SITE");
			if(StringUtils.isEmpty(strSiteName)) {
				strSiteName = "MDK";
			}
			
			
			String KEY_PLM_FTP_SERVER 		= strSiteName + "_" + "FTP_SERVER";
			String KEY_PLM_FTP_ID 			= strSiteName + "_" + "FTP_ID";
			String KEY_PLM_FTP_PASSWORD 	= strSiteName + "_" + "FTP_PASSWORD";
			String KEY_PLM_FTP_HOME 		= strSiteName + "_" + "FTP_HOME";
			
			String PLM_FTP_SERVER 			= prop.getProperty(KEY_PLM_FTP_SERVER);
			String PLM_FTP_ID 				= prop.getProperty(KEY_PLM_FTP_ID);
			String PLM_FTP_PASSWORD 		= prop.getProperty(KEY_PLM_FTP_PASSWORD);
			String PLM_FTP_HOME 		    = prop.getProperty(KEY_PLM_FTP_HOME);
			
			
			List slFileExtension = new ArrayList();
			slFileExtension.add("smg");
			
	    	//파일 변환 완료 되면 PLM 변환서버 FTP Upload
			cdmConvertFTPUtil.FTPFileUpload(PLM_FTP_SERVER, PLM_FTP_ID, PLM_FTP_PASSWORD, strLocalFolder, PLM_FTP_HOME, slFileExtension);
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	
	
	
	
	
	
	
	
	
	


	public static void main(String[] args) {
		
		try {
			cdmConvertJob job = new cdmConvertJob();
			job.transferFilesToPLM("D:\\workspace_convert\\20170106_PKA17CP001_done");
			
			
			
//			
//			Context context = job.getContext();
//			
//			log.debug(context);
//			DomainObject do3DObj = new DomainObject("47604.45839.50593.7489");
//			
//			String strFileFormat = "prt";
//			FileList fileList = do3DObj.getFiles(context);
//			log.debug(fileList);
//			do3DObj.checkoutFiles(context, false, strFileFormat, fileList, "c:\\mig");
//			
			
			
			//strFileName = do3DObj.getInfo(context, "format["+strFileFormat+"].file.name");
			
			//47604.45839.50593.7489
			//job.execute(null);
			
			//job.executeFileConversion("C:\\workspace_convert\\201612290700_X-2016-00286");
			//Path file = Paths.get("c:/TEST.txt");
	        //Path movePath = Paths.get("c:/TEST/");
	        //Files.move(file, movePath.resolve(file.getFileName()));
	        
			//File tmpFile = new File("C:\\enoviaV6R2016x\\server\\workspace\\mx64e644900dec1e12581184f8\\SyncTemplate.seeb");
            //tmpFile.delete();
			
            //File f = new File("C:\\enoviaV6R2016x\\server\\workspace\\mx64e644900dec1e12581184f8");
			//f.delete();
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	}
	
	
}


