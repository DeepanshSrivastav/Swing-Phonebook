package com.mando.scheduler.job;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.List;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import com.matrixone.apps.domain.DomainObject;

import matrix.db.Context;

public class cdmConvertFTPUtil {
	private static FTPClient ftpClient;
	private static int SFTP_PORT = 22;
	private static int FPT_PORT = 21;
	
	static org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(cdmConvertFTPUtil.class.getName());
	
	protected static void connect(String url, String id, String password, int port) {
		ftpClient = new FTPClient();
		try {
			ftpClient.connect(url, port);
			
			int reply = ftpClient.getReplyCode();
			if(!FTPReply.isPositiveCompletion(reply)) {
				ftpClient.disconnect();
				System.out.println("FTP Connection Fail");
			} else {
				ftpClient.setSoTimeout(10000);
				ftpClient.login(id, password);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			if(ftpClient != null && ftpClient.isConnected()) {
				try {
					ftpClient.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
	}
	
	public static boolean FTPFileDownload(String url, String id, String password, String filePath, String fileName) {
		boolean result = true;
		try {
			connect(url, id, password, SFTP_PORT);
			ftpClient.enterLocalPassiveMode();
			File file = new File(filePath+"\\"+fileName);
			OutputStream outputStream = new FileOutputStream(file);
			ftpClient.retrieveFile("/"+fileName, outputStream);
			outputStream.close();
		} catch(Exception e) {
			e.printStackTrace();
			result = false;
		}finally {
			if(ftpClient != null && ftpClient.isConnected()) {
				try {
					ftpClient.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public static boolean FTPFileUpload(String url, String id, String password, String filePath, String serverPath, String fileName) {
		boolean result = true;
		try {
			connect(url, id, password, SFTP_PORT);
			File file = new File(fileName);
			FileInputStream inputStream = new FileInputStream(file);
			ftpClient.storeFile("/"+serverPath+"/"+file.getName(), inputStream);
			inputStream.close();
		} catch(Exception e) {
			e.printStackTrace();
			result = false;
		} finally {
			if(ftpClient != null && ftpClient.isConnected()) {
				try {
					ftpClient.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return result;
	}
	
	/**
	 * 
	 * @param url
	 * @param id
	 * @param password
	 * @param strLocalFolder
	 * @param strRemoteFolder
	 * @param slFileExtention List of file extension to upload.
	 * @return
	 */
	public static boolean FTPFileUpload(String url, String id, String password, String strLocalFolder, String strRemoteFolder, List slFileExtension)  throws Exception{
		boolean result = true;
		try {
			connect(url, id, password, FPT_PORT);
			ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
			ftpClient.setControlEncoding("euc-kr");
			ftpClient.enterLocalPassiveMode();
			ftpClient.changeWorkingDirectory(strRemoteFolder);
			
			
			File[] flList =  new File(strLocalFolder).listFiles();

			for (int i = 0; i < flList.length; i++) {
				File file = flList[i];
				
				String strFileExt = file.getName().replaceAll(".+\\.", "");
				
				if(!slFileExtension.contains(strFileExt))
					continue;
				
				
				FileInputStream inputStream = new FileInputStream(file);
				String strFileName = new String(file.getName().getBytes("euc-kr"), "8859_1");
				boolean isSuccess = ftpClient.storeFile(strFileName, inputStream);
				
				
				log.info("Transfer File : " + strFileName); 
				
				inputStream.close();
			}
			
			
			
		} catch(Exception e) {
			e.printStackTrace();
			result = false;
			throw e;
		} finally {
			if(ftpClient != null && ftpClient.isConnected()) {
				try {
					ftpClient.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return result;
	}
	
	private static File[] getAllFiles(String strDirPath) {

        File tmpDir = null;
        File tmpFile = null;
        File[] tmpFiles = null;

        try {

            tmpDir = new File(strDirPath);

            if(tmpDir != null && tmpDir.exists()) {

                tmpFiles = tmpDir.listFiles();
            }
            
        } catch(Exception e) {
            e.printStackTrace();
        } finally {
            tmpDir = null;
            tmpFile = null;
        }
        
        return tmpFiles;
    }
	
	public static void main(String[] args) {
		
		try {
			//double a = Double.parseDouble("1.0");
		    //System.out.println(String.valueOf((int) a));
		    
			
			Context context = new Context("");
			context.setUser("admin_platform");//p13941
			context.setPassword("");
			context.connect();
			
		    DomainObject partDomObj = new DomainObject();
		    System.out.println(partDomObj);
		    partDomObj.createObject(context, "cdmMechanicalPart", "BC14012333", "A", "cdmPartPolicy", "eService Production");
			
			//cdmConvertFTPUtil job = new cdmConvertFTPUtil();
			//job.FTPFileUpload("127.0.01","jh_admin","123456","","");
			//job.FTPFileDownload("127.0.01","jh_admin","123456","C:\\temp","BrakeAssy.smg");
			//Path file = Paths.get("c:/TEST.txt");
	        //Path movePath = Paths.get("c:/TEST/");
	        //Files.move(file, movePath.resolve(file.getFileName()));
	        
			//File tmpFile = new File("C:\\enoviaV6R2016x\\server\\workspace\\mx64e644900dec1e12581184f8\\SyncTemplate.seeb");
            //tmpFile.delete();
			
            //File f = new File("C:\\enoviaV6R2016x\\server\\workspace\\mx64e644900dec1e12581184f8");
			//f.delete();
			
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	}


}
