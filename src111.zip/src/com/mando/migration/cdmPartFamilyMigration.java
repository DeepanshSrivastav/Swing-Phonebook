package com.mando.migration;

import java.util.HashMap;
import java.util.Map;

import com.mando.util.cdmConstantsUtil;
import com.matrixone.apps.domain.util.MapList;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;

public class cdmPartFamilyMigration {


	public static void main(String[] args) throws Exception {
		Context context = null;
		try {
			context = new Context("");
//			getContext
	
			
//			context.setUser("admin_platform");
//			context.setPassword("Qwer1234");
//			context.setVault(cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//			context.connect();
			
			context = cdmCommonMigration.getContext();
			Map<String,String> parmaMap = new HashMap<String,String>();
			
			//file 정보는 cdmMigrationStringResource.properties 위치 */ 
			JPO.invoke(context, "cdmAttributeGroupMigration", null, "createPatFamilyForBlockCode", JPO.packArgs(parmaMap)); 	 //  Part Family create
			JPO.invoke(context, "cdmAttributeGroupMigration", null, "createPL", JPO.packArgs(parmaMap));			     //   part family connect  
			JPO.invoke(context, "cdmAttributeGroupMigration", null, "connectPartFamily", JPO.packArgs(parmaMap));			     //   part family connect  
			JPO.invoke(context, "cdmAttributeGroupMigration", null, "connectPFandAG", JPO.packArgs(parmaMap));			 		 //   part family connect ag
			
			JPO.invoke(context, "cdmAttributeGroupMigration", null, "createPartFamilyForElectronicPart", JPO.packArgs(parmaMap)); //   part family create and connect
		
		} catch (MatrixException e) {
			e.printStackTrace();
		}
//		
	}

}
