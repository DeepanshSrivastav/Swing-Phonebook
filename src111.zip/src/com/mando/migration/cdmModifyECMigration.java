package com.mando.migration;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class cdmModifyECMigration {
	

	public static Context getContext() throws Exception {
		String sUser = System.getProperty("mx.user");
		String sPasswd = System.getProperty("mx.passwd");
		
		Context context = new Context("");
		context.setUser(sUser);
		context.setPassword(sPasswd);

		//context.setVault(cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
		context.connect();
		
		return context;
	}
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public static void main(String[] args) throws Exception {
		Context context = null;
		try {
//			if(args.length !=2){
//				throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//			}
			
			context = new Context("");
			context = getContext();
//			context.setUser("admin_platform");
//			context.setPassword("Qwer1234");
//			context.setVault(cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			context.connect();
			
			HashMap paramMap = new HashMap();
			
			String sFileLocationAndFileName 	= args[1];
//			String sFileLocationAndFileName 	= "C:\\temp\\Import_File\\EC\\EC_Info_02.xls";
			String sFileLocation 		= "";
			String sFileName 			= "";
			//EC_Info_02.xls
			sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
			sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
			if(sFileName.contains("EC")){
				paramMap.put("File_Location", sFileLocation);
				paramMap.put("File", sFileName);
			
				JPO.invoke(context, "cdmECMigration", null, "setModifyECInfo", JPO.packArgs(paramMap));// EC
				
			}
		
		} catch (MatrixException e) {
			e.printStackTrace();
		}finally{
			
		}
		
	}

}
