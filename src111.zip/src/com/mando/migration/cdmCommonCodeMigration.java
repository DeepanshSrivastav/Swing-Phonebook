package com.mando.migration;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class cdmCommonCodeMigration {
	

	public static Context getContext() throws Exception {
		String sUser = System.getProperty("mx.user");
		String sPasswd = System.getProperty("mx.passwd");
		
		Context context = new Context("");
		context.setUser(sUser);
		context.setPassword(sPasswd);

		context.connect();
		
		return context;
	}
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public static void main(String[] args) throws Exception {
		Context context = null;
		try {
			
			
			context = new Context("");
			context = getContext();
			
			HashMap paramMap = new HashMap();
			String sTheme = "";
			String sFileLocationAndFileName 	= args[1];
//			String sFileLocationAndFileName 	= "C:\\temp\\Import_File\\COMMONCODE\\2016_1125_1223_LIB_정리_v03.xlsx";
			
			String sFileLocation 		= "";
			String sFileName 			= "";

			sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
			sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
			
			if(cdmStringUtil.isNotEmpty(sFileLocation) && cdmStringUtil.isNotEmpty(sFileName) && sFileName.contains("LIB")){
				paramMap.put("File_Location", sFileLocation);
				paramMap.put("File", sFileName);
				
				JPO.invoke(context, "cdmCommonCodeMigration", null, "createScreenCommonCode", JPO.packArgs(paramMap));		 // Screen  sheet information commoncode
				JPO.invoke(context, "cdmCommonCodeMigration", null, "createCustomerCommonCode", JPO.packArgs(paramMap));	 // Customer sheet infomation commoncode
				JPO.invoke(context, "cdmCommonCodeMigration", null, "createLibDataCommonCode", JPO.packArgs(paramMap));		 //  Lib_Data sheet information commoncode
				JPO.invoke(context, "cdmCommonCodeMigration", null, "createOptionCommonCode", JPO.packArgs(paramMap)); 		 //  option sheet information commoncode
				JPO.invoke(context, "cdmCommonCodeMigration", null, "createProductGroupCommonCode", JPO.packArgs(paramMap)); //  ProductGroup  sheet information commoncode
				JPO.invoke(context, "cdmCommonCodeMigration", null, "createVehicleCommonCode", JPO.packArgs(paramMap)); 	 //  vehicle sheet information commoncode
				
			
				//PROJECT
				JPO.invoke(context, "cdmProjectGroupMigration", null, "addProjectGroupAndProject", JPO.packArgs(paramMap)); 	 //  project sheet commoncode
			
			}
			
	
			
		} catch (MatrixException e) {
			e.printStackTrace();
		}
		
	}

}
