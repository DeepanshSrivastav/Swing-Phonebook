package com.mando.migration;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class cdmCommonMigration {
	

	public static Context getContext() throws Exception {
		String sUser = System.getProperty("mx.user");
		String sPasswd = System.getProperty("mx.passwd");
		
		Context context = new Context("");
		context.setUser(sUser);
		context.setPassword(sPasswd);

		//context.setVault(cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
		context.connect();
		
		return context;
	}
	
	
	public static void main(String[] args) throws Exception {}

}
