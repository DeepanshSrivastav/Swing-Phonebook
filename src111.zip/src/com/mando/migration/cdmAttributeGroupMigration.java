package com.mando.migration;

import java.util.HashMap;
import java.util.Map;

import com.mando.util.cdmConstantsUtil;
import com.matrixone.apps.domain.util.MapList;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.MatrixException;

public class cdmAttributeGroupMigration {


	public static void main(String[] args) throws Exception {
		Context context = null;
		try {
			context = new Context("");
			
//			context.setUser("admin_platform");
//			context.setPassword("Qwer1234");
//			context.setVault(cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//			context.connect();
			
			context = cdmCommonMigration.getContext();
			 
			Map<String,String> parmaMap = new HashMap<String,String>();
			
			//file 정보는 cdmMigrationStringResource.properties 위치 */ 
			/*attribute group*/
			JPO.invoke(context, "cdmAttributeGroupMigration", null, "addAttrubute", JPO.packArgs(parmaMap)); 	 	 //  ATTRIBUTE create
			JPO.invoke(context, "cdmAttributeGroupMigration", null, "createAttributeGroup", JPO.packArgs(parmaMap)); //  attribute group create
			 
			
	
			
		} catch (MatrixException e) {
			e.printStackTrace();
		}
//		
	}

}
