package com.mando.util;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class SqlSessionUtil {
	private final static String resource = "/config/mybatis/mybatis-config.xml";//mybatis/mappers/mybatis-config.xml
	private static SqlSessionFactory sqlSessionFactory;
	
	static {
        try {
			InputStream inputStream = Resources.getResourceAsStream(SqlSessionUtil.resource);
			SqlSessionUtil.sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
		} catch (IOException e) {
			e.printStackTrace();
		}
    }
	
	public static SqlSession getSqlSession() {
		return SqlSessionUtil.sqlSessionFactory.openSession();
	}
	
	@Deprecated
	public static void reNew() {
		
		//commented by ci.lee on 1/20/2017. Because it would increase Sql Connections. 
		//reNew(null);
	}
	
	public static void reNew(String environmentName) {
		try {
			InputStream inputStream = Resources.getResourceAsStream(resource);
			if(environmentName == null || environmentName.equals("")){
				SqlSessionUtil.sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
			}else{
				SqlSessionUtil.sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream, environmentName);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
//	public static void main(String[] args) throws Exception {
//		try{
//			String strFile = "mybatis/mappers/mybatis-config.xml";
//			InputStream inputStream = Resources.getResourceAsStream(strFile);
//			SqlSessionFactory sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream, "plm");
//			Map paramMap = new HashMap();
//			SqlSession sqlSession = SqlSessionUtil.getSqlSession();
//			List<Map<String, String>> list = sqlSession.selectList("getMaterialMap", paramMap);
//			System.out.println("list       "+list.size());
//			
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//	}
	
}
