
package com.mando.util;

import java.io.UnsupportedEncodingException;

import org.apache.commons.lang3.StringUtils;

import com.matrixone.apps.domain.DomainConstants;

public class cdmStringUtil {

    
    public cdmStringUtil() {
    }

    public static String setEmpty( String str ) {

        String ret = "";
        if ( str != null && !"null".equals(str)) {
            ret = str.trim();
        }
        return ret;
    }
    /*
    public static boolean isNullString( String string ) {

        if ( string == null || string.equalsIgnoreCase( "null" ) || string.trim().equals( "" ) ) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean isNotNullString( String string ) {
        return !(isNullString( string ));
    }

    public static String setEmptyExt( String arg ) {

        if ( isNullString( arg ) ) {
            return "";
        } else {
            return arg.trim();
        }
    }

    public static String header( String str, int len ) {

        return header( str, len, " " );
    }

    public static String header( String str, int len, String sFillPost ) {

        str = StringUtil.setEmptyExt( str );
        str += getFillString( sFillPost, len );

        if ( str.length() > len ) {
            str = str.substring( 0, len );
        }
        return str;
    }

    public static String tail( String str, int len ) {

        return tail( str, len, " " );
    }

    public static String tail( String str, int len, String sFillPre ) {

        str = getFillString( sFillPre, len ) + StringUtil.setEmptyExt( str );

        if ( str.length() > len ) {
            len = str.length() - len;
            str = str.substring( len );
        }
        return str;
    }

    public static String getFillString( String sFill, int len ) {

        String sRet = "";
        if ( sFill != null && !sFill.equals( "" ) ) {
            for ( int i = 0 ; i < len ; i++ ) {
                sRet += sFill;
            }
        }
        return sRet;
    }

    public static String slice( String sSource, int len ) {

        String sTmp = "";

        sTmp = sSource.substring( 0, sSource.length() < len ? sSource.length() : len );
        while ( sTmp.getBytes().length > len ) {
            sTmp = sTmp.substring( 0, sTmp.length() - 1 );
        }
        //      sSource.getBytes()
        return sTmp;
    }

    public static String SPACE( int iLen ) {

        return StringUtil.header( " ", iLen );
    }

    public static String SPACE( int iLen, String sFill ) {

        return StringUtil.header( sFill, iLen, sFill );
    }

    public static String replaceFirst( String sSource, String sTarget, String sReplace ) {

        String sRet = sSource;
        int iIdx = sSource.indexOf( sTarget );
        if ( iIdx >= 0 ) {
            String sTmp = sSource.substring( 0, iIdx );
            sTmp += sReplace;
            sTmp += sSource.substring( iIdx + sTarget.length() );
            sRet = sTmp;
        }
        return sRet;
    }

    public static String getErrorString( Exception e ) {

        String sRet = "";
        try {
            sRet = e.getClass().toString() + " : ";
            sRet += e.getMessage() + "\n";
            StackTraceElement[] ste = e.getStackTrace();
            for ( StackTraceElement et : ste ) {
                sRet += "\t" + et.toString() + "\n";
            }
        } catch ( Exception ex ) {

        }
        return sRet;
    }

    public static String checkNull( String s ) {

        if ( s == null || "null".equalsIgnoreCase( s ) ) {
            s = "";
        }
        return s;
    }

    public static String setEmptyHTML( String str ) throws Exception {

        String sReturn = "&nbsp;";
        if ( !"".equals( setEmptyExt( str ) ) ) {
            sReturn = str;
        }
        return sReturn;
    }

    public static ArrayList StringSplit( String str, String delim ) {

        ArrayList list = new ArrayList();
        StringTokenizer stk = new StringTokenizer( str, delim );

        while ( stk.hasMoreTokens() ) {
            list.add( stk.nextToken() );
        }
        return list;
    }

    public static String getToken( String pStr, String pDelimiter, int pIndex ) {

        if ( pStr == null || pStr == "" )
            return "";
        if ( pDelimiter == null || pDelimiter == "" )
            return pStr;

        int vStart = 0;
        int vEnd = pStr.length();

        if ( pStr.length() < pDelimiter.length() ) {
            return pStr;
        }

        if ( pStr.substring( 0, pDelimiter.length() ).equals( pDelimiter ) && pIndex > 0 )
            pIndex++;

        for ( int i = 1 ; i <= pIndex ; i++ ) {

            if ( i > 1 )
                vStart = vEnd + pDelimiter.length();
            vEnd = pStr.indexOf( pDelimiter, vStart );

            if ( vEnd < 0 ) {
                if ( pIndex > i ) {
                    i += pIndex;
                    vEnd = vStart;
                } else {
                    i += pIndex;
                    vEnd = pStr.length();
                }
            }
        }

        return pStr.substring( vStart, vEnd );
    }

    public static String getToken( String strComment, int m ) throws Exception {

        String retComment = "";
        StringTokenizer strToken = new StringTokenizer( strComment, "|" );

        int i = 0;
        try {
            while ( i != m ) {
                retComment = (String)strToken.nextElement();
                i++;
            }

        } catch ( Exception e ) {
            retComment = "";

        }
        return retComment;
    }

    public static ArrayList<String> getToken( String pStr, String pDelimiter ) {

        ArrayList<String> al = new ArrayList<String>();

        if ( pStr == null || pStr.equals( "" ) )
            return al;
        if ( pDelimiter == null || pDelimiter.equals( "" ) )
            return al;

        if ( pStr.length() < pDelimiter.length() ) {
            al.add( pStr );
            return al;
        }

        int vStart = 0;
        int vEnd = pStr.length();
        boolean vFirst = false;

        if ( pStr.substring( 0, pDelimiter.length() ).equals( pDelimiter ) )
            vFirst = true;

        for ( int i = 0 ; vEnd > -1 ; i++ ) {

            if ( i > 0 )
                vStart = vEnd + pDelimiter.length();

            vEnd = pStr.indexOf( pDelimiter, vStart );

            if ( vEnd > -1 ) {
                al.add( pStr.substring( vStart, vEnd ) );
            }
        }
        if ( vStart < pStr.length() ) {
            al.add( pStr.substring( vStart ) );
        }

        return al;
    }

    public static String[] getToken( String str ) {

        if ( str == null || str.equals( "" ) )
            return null;
        StringTokenizer st = new StringTokenizer( str, "_" );
        String s1 = "", s2 = "";
        while ( st.hasMoreTokens() ) {
            s1 = st.nextToken();
            if ( s1.equals( "0" ) )
                s1 = "";
            s2 = st.nextToken();
            if ( s2.equals( "0" ) )
                s2 = "";
        }
        String[] returnValue = { s1, s2 };
        return returnValue;
    }

    public static String arrayListToStringWithDelimeter( ArrayList al, String delimeter ) {

        return arrayListToStringWithDelimeter( al, delimeter, 0 );
    }

    public static String arrayListToStringWithDelimeter( ArrayList al, String delimeter, int startinx ) {

        StringBuffer sb = new StringBuffer();

        for ( int count = startinx ; count < al.size() ; count++ ) {
            sb.append( (String)al.get( count ) );

            if ( count != al.size() - 1 ) {
                sb.append( delimeter );
            }
        }

        return sb.toString();
    }
   
    public static String replace(String line, String oldString, String newString)
    {
        for (int index = 0;(index = line.indexOf(oldString, index)) >= 0; index += newString.length())
            line = line.substring(0, index) + newString + line.substring(index + oldString.length());

        return line;
    }
    */
    
    /**
     * String이 Null이 아니며 공백이 아니면 true를 return
     * 
     * @param string
     * @return
     */
    static public boolean isNotEmpty(String string) {
    	string = StringUtils.trimToEmpty(string);
        return StringUtils.isNotEmpty(("null".equals(string) || "undefined".equals(string)?"":string));
    }

    /**
     * String이 Null이거나 공백이면 true를 return
     * 
     * @param string
     * @return
     */
    static public boolean isEmpty(String string) {
    	string = StringUtils.trimToEmpty(string);
        return StringUtils.isEmpty(("null".equals(string) || "undefined".equals(string)?"":string));
    }

    /**
     * isEmpty(String) 함수와 동일
     * 
     * @param string
     * @return
     */
    static public boolean isNullString(String string) {
    	string = StringUtils.trimToEmpty(string);
        return StringUtils.isEmpty(("null".equals(string) || "undefined".equals(string)?"":string));
    }
    
    /**
     *<pre>
     * isNotEmpty 함수와 동일
     *</pre>
     * @param arg
     * @return
     */
    public static boolean isNotNullString(String arg) {
    	arg = StringUtils.trimToEmpty(arg);
		return (!isNullString(arg));
	}
    
    /*
     * 
     */
    static public String browserCommonCodeLanguage(String languageStr) {
    	String displayTitle = "";
    	String firstLang = languageStr.split("-")[0];
    	if ("ko".equals(firstLang)) {
    		displayTitle = "attribute[cdmCommonCodeNameKo].value";
    	}else if ("en".equals(firstLang)) {
    		displayTitle = "attribute[cdmCommonCodeNameEn].value";
    	}else if ("zh".equals(firstLang)) {
    		displayTitle = "attribute[cdmCommonCodeNameCn].value";
    	}else{
    		displayTitle = "attribute[cdmCommonCodeNameEn].value";
    	}
        return displayTitle;
    }
    
    static public String convertISOtoUTF8(String str) throws Exception{
		str = new String(str.getBytes("ISO-8859-1"),"UTF-8");
    	return str;
	}
    
    
    public static String setOptionValueEmpty( String str ) {

        String ret = "";
        str = StringUtils.trimToEmpty(str);
        if ( DomainConstants.EMPTY_STRING.equals(str)) {
            ret = "";
        } else {
        	ret = str.replaceAll(",", ";");
        }
        return ret;
    }
    
}


	