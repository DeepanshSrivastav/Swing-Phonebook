package com.mando.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import matrix.db.FileList;

public class cdmFTPUtil {
	private static FTPClient ftpClient;
	
	protected static void connect(String url, String id, String password) throws Exception{
		ftpClient = new FTPClient();
		try {
			ftpClient.connect(url, 21);
			
			int reply = ftpClient.getReplyCode();
			if(!FTPReply.isPositiveCompletion(reply)) {
				ftpClient.disconnect();
				System.out.println("FTP Connection Fail");
			} else {
				ftpClient.setSoTimeout(10000);
				ftpClient.login(id, password);
			}
			
		} catch(Exception e) {
			e.printStackTrace();
			if(ftpClient != null && ftpClient.isConnected()) {
				try {
					ftpClient.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
			throw e;
		}
	}
	
	public static boolean FTPFileDownload(String url, String id, String password, String filePath, String fileName) {
		boolean result = true;
		try {
			connect(url, id, password);
			ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
			ftpClient.setControlEncoding("euc-kr");
			ftpClient.enterLocalPassiveMode();
			ftpClient.changeWorkingDirectory("/vaults/ipmsvault/others/cdm/part/leaddraw/plm2cdm");
			
			File file = new File(filePath+"\\"+fileName);
			OutputStream outputStream = new FileOutputStream(file);
			ftpClient.retrieveFile(fileName, outputStream);
			
			outputStream.flush();
			outputStream.close();
		} catch(Exception e) {
			e.printStackTrace();
			result = false;
		}finally {
			if(ftpClient != null && ftpClient.isConnected()) {
				try {
					ftpClient.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public static boolean FTPFileUpload(String url, String id, String password, String filePath, String serverPath, String fileName) {
		boolean result = true;
		try {
			connect(url, id, password);
			ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
			ftpClient.enterLocalPassiveMode();
			File file = new File(fileName);
			FileInputStream inputStream = new FileInputStream(file);
			ftpClient.storeFile("/"+serverPath+"/"+file.getName(), inputStream);
			inputStream.close();
		} catch(Exception e) {
			e.printStackTrace();
			result = false;
		} finally {
			if(ftpClient != null && ftpClient.isConnected()) {
				try {
					ftpClient.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return result;
	}
	
	public static boolean FTPFileUpload(String url, String id, String password, String filePath, String serverPath) throws Exception{
		boolean result = true;
		try {
			connect(url, id, password);
			ftpClient.setFileType(FTPClient.BINARY_FILE_TYPE);
			ftpClient.setControlEncoding("euc-kr");
			ftpClient.enterLocalPassiveMode();
			ftpClient.changeWorkingDirectory(serverPath);
			File[] flList = getAllFiles(filePath);
			if(flList.length > 0) {
				for(int i=0; i<flList.length; i++){
					File file = flList[i];
	                FileInputStream inputStream = new FileInputStream(file);
	                String strFileName = new String(file.getName().getBytes("euc-kr"), "8859_1" );
	                boolean isSuccess = ftpClient.storeFile(strFileName, inputStream);
	    			inputStream.close();
				}
            }	
		} catch(Exception e) {
			e.printStackTrace();
			result = false;
			throw e;
		} finally {
			if(ftpClient != null && ftpClient.isConnected()) {
				try {
					ftpClient.disconnect();
				} catch (IOException ioe) {
					ioe.printStackTrace();
				}
			}
		}
		return result;
	}
	
	private static File[] getAllFiles(String strDirPath) {

        File tmpDir = null;
        File tmpFile = null;
        File[] tmpFiles = null;

        try {

            tmpDir = new File(strDirPath);

            if(tmpDir != null && tmpDir.exists()) {

                tmpFiles = tmpDir.listFiles();
            }
            
        } catch(Exception e) {
            e.printStackTrace();
        } finally {
            tmpDir = null;
            tmpFile = null;
        }
        
        return tmpFiles;
    }
	

}
