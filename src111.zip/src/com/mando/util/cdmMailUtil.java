package com.mando.util;

import java.util.Date;
import java.io.InputStream;
import java.util.Properties;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.BodyPart;
import javax.mail.Multipart;
import javax.mail.Transport;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMultipart;
import javax.mail.internet.InternetAddress;

import org.apache.commons.lang3.StringUtils;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.Context;
import matrix.util.StringList;

public class cdmMailUtil {
	
	private static final String MANDO_SMTP_HOST    = getPropValue("Mail.properties", "MANDO_SMTP_HOST");   
	private static final String MANDO_HOST         = getPropValue("Mail.properties", "MANDO_HOST");        
	private static final String MANDO_MAIL_USER    = getPropValue("Mail.properties", "MANDO_MAIL_USER");   
	private static final String CDM_ADMIN_USER     = getPropValue("Mail.properties", "CDM_ADMIN_USER");    
	
	private static Properties getPropFile( String sFileName ) {
		Properties prop = new Properties();

		try{
			cdmPropertiesUtil pu = new cdmPropertiesUtil();
			InputStream ips = pu.getClass().getResourceAsStream( "/" + sFileName );
			prop.load( ips );
			ips.close();
		}catch(Exception e){
			
		}
		return prop;
	}
	
	private static String getPropValue( String sFileName, String sName ) {
		String sRet = "";
	    try {
			sRet = ( String )getPropFile( sFileName ).get( sName );
		} catch( Exception e ) {
		}
		return StringUtils.trimToEmpty(sRet);
	}
	
	public static void sendMail(String from, String[] tos, String subject, String content) throws Exception {
		try {
			Properties props = new Properties();
			props.put("mail.host", MANDO_HOST);
			props.put("mail.transport.protocol", "smtp");
			props.put("mail.smtp.host", MANDO_SMTP_HOST);
			props.put("mail.smtp.user", MANDO_MAIL_USER);
			
			Session se = Session.getDefaultInstance(props, null);
			se.setDebug(true);
			MimeMessage msg = new MimeMessage(se);
				
			String sQuery = "temp query bus Person * * limit 1 where attribute[Email Address]=='" + from + "' select attribute[Last Name] dump |";
			Context context = ContextUtil.getAnonymousContext();
			context.setUser(CDM_ADMIN_USER);
			String sResultValue = MqlUtil.mqlCommand(context, sQuery);
			StringList lastNames = FrameworkUtil.split(sResultValue, "|" );
			context.closeContext();
			context = null;
				
			// sending header info
			msg.setFrom(new InternetAddress(from, (String) lastNames.lastElement(), "EUC-KR"));
			InternetAddress[] recepits = new InternetAddress[tos.length];
			for (int i = 0; i < recepits.length; i++) {
				recepits[i] = new InternetAddress(tos[i]);
			}
				
			msg.setRecipients(Message.RecipientType.TO, recepits);
			msg.setSubject(subject);
			msg.setSentDate(new Date());
				
			// make multipart body 
			BodyPart messageBodyPart = new MimeBodyPart();
			messageBodyPart.setHeader("Content-Transfer-Encoding", "quoted-printable");
			messageBodyPart.setContent(content, "text/html; charset=utf-8");
				
			Multipart multipart = new MimeMultipart();
			multipart.addBodyPart(messageBodyPart);
			msg.setContent(multipart);
				
			Transport transport = se.getTransport();
			transport.connect();
			transport.sendMessage(msg, msg.getAllRecipients());
			transport.close();
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
		}
	}
	
    public String getPersonMailAddress(Context context, String strId) throws Exception {
    	String sMailAddress = "";
        if(strId!=null && !"".equals(strId)){
        	DomainObject person = new DomainObject(strId);
        	sMailAddress = (String) person.getInfo(context, "attribute[Email Address]");
        }
        return sMailAddress;
    }
	
}
