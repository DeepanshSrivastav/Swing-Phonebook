package com.mando.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.charset.Charset;
import java.util.Iterator;
import java.util.Map;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.json.JSONArray;
import com.matrixone.json.JSONObject;

import matrix.db.Context;

public class cdmJsonDataUtil {

	JSONObject objJson = new JSONObject();
	
	private static String readAll(BufferedReader br) throws Exception{
		try{
			String str ;
		    StringBuffer strBuffer = new StringBuffer();
		    while((str = br.readLine()) != null){
		    	strBuffer.append(str);
		    }
			return strBuffer.toString();
		}catch(Exception e){
			throw e;
		}
	}
	
	public static String readJsonFormUrl(String strUrl) throws Exception{
		InputStreamReader isr = null;
		BufferedReader br = null;
		String strReadLine = DomainConstants.EMPTY_STRING;
		try{
			System.out.println("URL     :     "+strUrl);
			URL url = new URL(strUrl);
			URLConnection urlConn = url.openConnection();
		    InputStream is = urlConn.getInputStream();
		    isr = new InputStreamReader(is, "UTF-8");
		    br = new BufferedReader(isr);
		    strReadLine = readAll(br);
			System.out.println("Read Line     :     " + strReadLine);
			
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally {
			isr.close();
			br.close();
		}
		return strReadLine;
	}
	
	public static String getJSONResultData(String strJson, String searchWord)throws Exception{
		String strDataInfo = DomainConstants.EMPTY_STRING;
		try{
		    JSONObject jsonObj = new JSONObject(strJson);
		    strDataInfo = (String)jsonObj.getString(searchWord);
		    
		}catch(Exception e){
			throw e;
		}
		return strDataInfo;
	} 
	
	public static String getJSON(String strUrl)throws Exception{
		String strJsonObj = null;
		try{
			strJsonObj = readJsonFormUrl(strUrl);
		}catch(Exception e){
			throw e;
		}
		return strJsonObj;
	} 
	
	public static String getJSONResultArrayData(String strJson, String searchWord, int iRow)throws Exception{
		String strDataInfo = DomainConstants.EMPTY_STRING;
		try{
		    JSONObject jsonObj  = new JSONObject(strJson);
		    JSONArray jsonArray = jsonObj.getJSONArray(searchWord);
		    JSONObject jsonRow  = jsonArray.getJSONObject(iRow);
		    
		    strDataInfo = jsonRow.getString("PARTNUMBER");
		    
		}catch(Exception e){
			throw e;
		}
		return strDataInfo;
	} 
	
	public static boolean isNullString(String arg) {
        if (arg == null || arg.equals("") || arg.equalsIgnoreCase("null"))
            return true;
        else
            return false;
    }
	
	public static String replace(String original, String oldstr, String newstr) {
        if (!isNullString(original)) {
            String convert = new String();
            int dsk = 0;
            int begin = 0;
            dsk = original.indexOf(oldstr);

            if (dsk == -1)
                return original;

            while (dsk != -1) {
                convert = convert + original.substring(begin, dsk) + newstr;
                begin = dsk + oldstr.length();
                dsk = original.indexOf(oldstr, begin);
            }
            convert = convert + original.substring(begin);

            return convert;
        } else {
            return "";
        }
    }
	
	public static void main(String[] args) throws Exception {
		try{
			String propertyFile = "config/mybatis/config.properties";
			String plmPartUrl = "PLM_PART_URL";
			String strUrl = cdmPropertiesUtil.getPropValue(propertyFile, plmPartUrl);
			System.out.println("strUrl       "+strUrl);
			//strUrl = "http://gbomdev.mando.com/Windchill/cdmCreatePartNumbers.jsp?uid=mandoAdmin&blockCode=BC200&count=1&serialYn=N&specificationYn=Y";
			         //"http://gbomdev.mando.com/Windchill/cdmCreatePartNumbers.jsp?uid=p13941&blockCode=BC412&count=1&serialYn=N&specificationYn=Y
			
			Context context = new Context("");
			context.setUser("p13941");
			context.setPassword("Qwer1234");
			context.connect();
			
			String strPartNo = DomainConstants.EMPTY_STRING;
			StringBuffer strBuffer = new StringBuffer();
			strBuffer.append("uid");
			strBuffer.append("=");
			strBuffer.append(context.getUser());
			strBuffer.append("&");
			strBuffer.append("blockCode");
			strBuffer.append("=");
			strBuffer.append("BC412");//Block Code
			strBuffer.append("&");
			strBuffer.append("count");
			strBuffer.append("=");
			strBuffer.append("1");//Number of Part
			strBuffer.append("&");
			strBuffer.append("serialYn");
			strBuffer.append("=");
			strBuffer.append("N");
			strBuffer.append("&");
			strBuffer.append("specificationYn");
			strBuffer.append("=");
			strBuffer.append("N");
			
			String strJsonObject = (String)cdmJsonDataUtil.getJSON("http://gbomdev.mando.com/Windchill/cdmCreatePartNumbers.jsp?uid=mandoAdmin&blockCode=BC200&count=3&serialYn=N&specificationYn=Y");
			System.out.println("strJsonObject       "+strJsonObject);
			
			String strResultInfo = cdmJsonDataUtil.getJSONResultData(strJsonObject, "RESULT");
			System.out.println("strResultInfo       "+strResultInfo);
			
			if("SUCCESS".equals(strResultInfo)){
		    	strPartNo = cdmJsonDataUtil.getJSONResultArrayData(strJsonObject, "DATA", 0);
				System.out.println("strPartNo     :     "+strPartNo);
		    }
			
		}catch(Exception e){
			throw e;
		}
	}
	
	
	
}
