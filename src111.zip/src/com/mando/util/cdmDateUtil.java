package com.mando.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

import matrix.db.Context;

import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.framework.ui.UIUtil;

/**
 * 날짜/시간 처리를 위한 Utility
 * 
 */
public class cdmDateUtil {

    private static String ev6DateFormatString = eMatrixDateFormat.getEMatrixDateFormat();
    private static SimpleDateFormat ev6Sdf = new SimpleDateFormat(eMatrixDateFormat.getEMatrixDateFormat(), Locale.US);
    private static SimpleDateFormat ev6DateSdf = new SimpleDateFormat("MM/dd/yy");
    private static SimpleDateFormat digDateTimeSdf = new SimpleDateFormat("yyyy. M. d HH:mm:ss");

    /**
     * EV6 Basic 속석 중 Modified, Originated를 24시간 형식으로 Display한다.
     * 
     * @param context
     * @param strDate
     * @return
     * @throws Exception
     */
    public static String getDisplayDateForDIG(Context context, String strDate) throws Exception {
        return digDateTimeSdf.format(ev6Sdf.parse(strDate));
    }

    /**
     * Java Date를 EV6 내부 날짜 Format으로 변환한다.
     * 
     * @param context
     * @param date
     * @return
     * @throws Exception
     */
    public static String formatDateStringForENOVIA(Context context, Date date) throws Exception {
        try {
            return ev6Sdf.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Java Date를 EV6 내부 날짜 Format으로 변환한다.
     * 
     * @param context
     * @param date
     * @param locale
     * @return
     * @throws Exception
     */
    public static String formatDateStringForENOVIA(Context context, Date date, Locale locale) throws Exception {
        try {
            return new SimpleDateFormat(ev6DateFormatString, locale).format(date);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * Java Date를 EV6 내부 날짜 Format으로 변환한다. (단, 시간은 버리고 순수하게 날짜 부분만 변환한다.)
     * 
     * @param date
     * @return
     * @throws Exception
     */
    public static String getFormattedDateStringToSetAttribute(Date date) throws Exception {
        try {
            return ev6DateSdf.format(date);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * 날짜 String을 EV6 내부 날짜 Format으로 변환한다.
     * 
     * @param context
     * @param dateString
     * @return
     * @throws Exception
     */
    public static String getFormattedInputDate(Context context, String dateString) throws Exception {
        try {
            String formattedDateString = "";

            if (dateString != null && !dateString.equals("")) {
                Locale locale = context.getLocale();
                TimeZone tz = TimeZone.getTimeZone(context.getSession().getTimezone());
                double dbMilisecondsOffset = (double) (-1) * tz.getRawOffset();
                double clientTZOffset = (new Double(dbMilisecondsOffset / (1000 * 60 * 60))).doubleValue();
                formattedDateString = com.matrixone.apps.domain.util.eMatrixDateFormat.getFormattedInputDate(context, dateString, clientTZOffset, locale);
            }

            return formattedDateString;
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }

    /**
     * EV6 날짜 format을 화면에 표시할 날짜 format으로 변환한다.
     * 
     * @param context
     * @param strDate
     * @param timeZone
     * @param locale
     * @return
     */
    public static String getFormatDisplayDate(Context context, Object strDate, String timeZone, Locale locale) {
        String formatDate = "";
        try {
            if (strDate == null || "".equals(strDate.toString())) return formatDate;
            formatDate = eMatrixDateFormat.getFormattedDisplayDate((String) strDate, Double.parseDouble(timeZone), locale);
        } catch (Exception e) {
            return "";
        }
        return formatDate;
    }

    /**
     * <pre>
     * EV6 날짜 format을 화면에 표시할 날짜 format으로 변환한다.
     * </pre>
     * 
     * @param context
     * @param strDate
     * @return
     */
    public static String getFormatDisplayDate(Context context, Object strDate) {
        String formatDate = "";
        try {
            if (strDate == null || "".equals(strDate.toString())) return formatDate;
            //formatDate = eMatrixDateFormat.getFormattedDisplayDate((String) strDate, Double.parseDouble(context.getTimezone()), context.getLocale());
            formatDate = eMatrixDateFormat.getFormattedDisplayDate((String) strDate, -9.0d, context.getLocale());
        } catch (Exception e) {
            return "";
        }
        return formatDate;
    }
    
    /*
     * 
     * 날짜 String Format 변경 2001-12-10  -> 01/12/10
     */
    public static String convertDateFormat(String date, String format1, String format2) throws Exception {
		if (UIUtil.isNullOrEmpty(date))
			return date;

		String strDate = date;
		try {
			SimpleDateFormat sd = new SimpleDateFormat(format1, Locale.US);
			Date d = sd.parse(date);
			sd.applyPattern(format2);
			strDate = sd.format(d);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return strDate;
	}
    
}
