package com.mando.util;
import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.matrixone.apps.domain.util.FrameworkUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

/**
 * Excel JPO 
 * 
 * 1. getXssfSheet (get sheet) 
 * 2. getCellValue (cell value return)
 * 
 */
public class cdmCommonExcel {
	public static String TEMP_DIR = "";
	public static final String BACKSLASH = "\\";
	public static final String START_SQUARE_BRACKET = "[";
	public static final String END_SQUARE_BRACKET = "]";
	public static final String START_ANGLE_BRACKET = "{";
	public static final String END_ANGLE_BRACKET = "}";
	public static final String START_ROUND_BRACKET = "(";
	public static final String END_ROUND_BRACKET = ")";
	public static final String AND = " && ";
	public static final String OR = " || ";
	public static final String EQ = " == ";
	public static final String NEQ = " != ";
			
	public cdmCommonExcel() {
    }
	
	/**
	 * Description : XSSFSheet return 
	 * @param context
	 * @param filePath
	 * @param SheetName
	 * @return
	 * @throws Exception
	 */
	public static XSSFSheet getXssfSheet(Context context,String filePath,String SheetName)throws Exception{
		try {
			if (com.mando.util.cdmStringUtil.isEmpty(filePath))
				throw new IllegalArgumentException();

			XSSFSheet sheet = null;
			XSSFWorkbook workbook = new XSSFWorkbook(new FileInputStream(new File(filePath)));
			sheet = workbook.getSheet(SheetName);
			if(com.mando.util.cdmStringUtil.isEmpty(SheetName)) {
				sheet = workbook.getSheetAt(0);
			}
			return sheet;
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}finally {
		}
	}
	
	/**
	 * @param context
	 * @param filePath
	 * @param SheetName
	 * @return
	 * @throws Exception
	 */
	public static HSSFSheet getHssfSheet(Context context,String filePath,String SheetName)throws Exception{
		HSSFSheet sheet = null;
		try {
			if (com.mando.util.cdmStringUtil.isEmpty(filePath))
				throw new IllegalArgumentException();

			HSSFWorkbook workbook = new HSSFWorkbook(new FileInputStream(new File(filePath)));
			sheet = workbook.getSheet(SheetName);
			if(com.mando.util.cdmStringUtil.isEmpty(SheetName)) {
//				sheet = workbook.getSheetAt(0);
				sheet = workbook.getSheetAt(0);
			}
			return sheet;
		}catch(Exception e){
			e.printStackTrace();
		}
		return sheet;
	}
	
	/**
	 * 
	 * @param cell
	 * @return
	 * @throws Exception
	 */
	public static Object getCellValue(XSSFCell cell) throws Exception {

		Object object = new String("");
		try {
			if (cell == null)
				// return null;
				return "";

			switch (cell.getCellType()) {

			case XSSFCell.CELL_TYPE_NUMERIC:

				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd H:mm");
					object = formatter.format(cell.getDateCellValue());

				} else {

					double numbericCellValue = cell.getNumericCellValue();
					String value = String.valueOf(numbericCellValue);
					StringList stListValue = FrameworkUtil.split(value, ".");
					if (stListValue.size() > 1) {
						String endSt = (String) stListValue.get(1);
						value = endSt.equals("0") ? (String) stListValue.get(0) : value;
					}

					object = value;
				}

				break;

			case XSSFCell.CELL_TYPE_FORMULA:

				object = String.valueOf(cell.getCellFormula());

				break;

			case XSSFCell.CELL_TYPE_STRING:

				object = String.valueOf(cell.getStringCellValue());

				break;

			case XSSFCell.CELL_TYPE_BLANK:

				object = String.valueOf(cell.getBooleanCellValue());
				object = "";
				break;

			case XSSFCell.CELL_TYPE_ERROR:

				object = String.valueOf(cell.getErrorCellValue());

				break;

			default:

				break;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return object;

	}
	
	
	/**
	 * 
	 * @param cell
	 * @return
	 * @throws Exception
	 */
	public static String getCellValue2(Cell cell) throws Exception {

		String str = new String("");
		try {
			if (cell == null)
				// return null;
				return "";

			switch (cell.getCellType()) {

			case XSSFCell.CELL_TYPE_NUMERIC:

				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd H:mm");
					str = formatter.format(cell.getDateCellValue());

				} else {

					double numbericCellValue = cell.getNumericCellValue();
					String value = String.valueOf(numbericCellValue);

					str = value;
				}

				break;

			case XSSFCell.CELL_TYPE_FORMULA:

				str = String.valueOf(cell.getCellFormula());

				break;

			case XSSFCell.CELL_TYPE_STRING:

				str = String.valueOf(cell.getStringCellValue());

				break;

			case XSSFCell.CELL_TYPE_BLANK:

				str = String.valueOf(cell.getBooleanCellValue());
				str = "";
				break;

			case XSSFCell.CELL_TYPE_ERROR:

				str = String.valueOf(cell.getErrorCellValue());

				break;

			default:

				break;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str;

	}
	
	/**
	 * get sheet 
	 * @param context
	 * @param filePath
	 * @param SheetName
	 * @return
	 * @throws Exception
	 */
	public static Sheet getXssfSheet2(Context context, String filePath, String SheetName) throws Exception {
		Sheet sheet = null;
		try {
			if (com.mando.util.cdmStringUtil.isEmpty(filePath))
				throw new IllegalArgumentException();

			Workbook wb = WorkbookFactory.create(new FileInputStream(new File(filePath)));
			

			sheet = wb.getSheet(SheetName);

			if (com.mando.util.cdmStringUtil.isEmpty(SheetName)) {
				sheet = wb.getSheetAt(0);
			}
			return sheet;
		} catch (Exception e) {
			e.printStackTrace();
			return sheet;
//			throw e;
		} 
	}
	
	/**
	 * null process
	 * 
	 * @param data
	 * @return
	 */
	public static String isVaildNullData(String data) {
		return ((data == null || "null".equals(data)) ? "" : data.trim());
	}
	
	public static String getTimeStamp() {
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date) + "__" + new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}
	
	public static String getTimeStamp2() {
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date) + " " + new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}
	
	 public static Properties getProperty(String fileName) throws Exception {
	        Properties prop = new Properties();
	        String sPropertiesFileName = fileName + ".properties";
	        ClassLoader cl = Thread.currentThread().getContextClassLoader();
	        if (cl == null)
	            cl = ClassLoader.getSystemClassLoader();
	        URL url = cl.getResource(sPropertiesFileName);
	        File file = null;
	        FileInputStream fis = null;
	        try {
	            String filePath = url.getFile();
	            file = new File(filePath);
	            fis = new FileInputStream(file);

	            prop.load(fis);

	        } catch (Exception e) {
	            e.printStackTrace();
	        } finally {
	            if (fis != null) {
	                try {
	                    fis.close();
	                } catch (Exception ee) {/* do nothing */
	                }
	                fis = null;
	            }
	            if (file != null)
	                file = null;
	        }

	        return prop;
	    }
	 
	 	/**
		 * yyyy-MM-dd
		 * @return
		 */
		public static String getDateStamp() {
			Date date = new Date();
			String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date);

			timeStamp = timeStamp.replace('-', '_');
			timeStamp = timeStamp.replace(':', '_');

			return timeStamp;
		}
}
