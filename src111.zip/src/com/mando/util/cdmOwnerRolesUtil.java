package com.mando.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.Vector;

import org.apache.commons.lang3.StringUtils;

import com.matrixone.MCADIntegration.utils.MCADUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.StringList;

public class cdmOwnerRolesUtil {
	
	private static final String REPLACE_PRE_FIX      = "ctx::";
	private static final String ROLE_NAME            = "roleName";
	private static final String ORGANIZATION_NAME    = "organizationName";
	private static final String PROJECT_NAME         = "projectName";
	private static final String PRODUCT_DIVISION     = "ProductDivision";
	private static final String PRODUCT_TYPE         = "ProductType";
	private static final String VEHICLE              = "Vehicle";
	
	public static Map getUserInfo( Context context ) throws IOException, ClassNotFoundException {
		String roleName             =   DomainConstants.EMPTY_STRING;
		String organizationName     =   DomainConstants.EMPTY_STRING;
		String projectName          =   DomainConstants.EMPTY_STRING;
		
		Map mOwnerMap = new HashMap();
		try{
			
			DomainObject userObj = PersonUtil.getPersonObject(context, context.getUser());
		    String sCommandStatementProject = "print bus $1 select $2 $3 dump";
			String projectAndOrg 			= MqlUtil.mqlCommand(context, sCommandStatementProject, userObj.getObjectId(context), "organization", "project");
			Vector prjAndOrg 				= MCADUtil.getVectorFromString(projectAndOrg, ",");
			organizationName 				= (String)prjAndOrg.get(0);
			projectName						= (String)prjAndOrg.get(1);
			//mOwnerMap.put(ROLE_NAME,           roleName);
			mOwnerMap.put(ORGANIZATION_NAME,   organizationName);
			mOwnerMap.put(PROJECT_NAME,        projectName);
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return mOwnerMap;
	}
	
	
	public static String getUserValue( Context context, String strKey ) {
		String strUserInfo = DomainConstants.EMPTY_STRING;
	    try {
	    	strUserInfo = (String)getUserInfo(context).get(strKey);
		} catch( Exception e ) {
			e.printStackTrace();
		}
		return StringUtils.trimToEmpty(strUserInfo); 
	}
	
	public static String getDefaultProject(Context paramContext) throws FrameworkException {
		return getDefaultProject(paramContext, paramContext.getUser());
	}

	public static String getDefaultProject(Context paramContext, String paramString) throws FrameworkException {
		String strprojectName = "";
		String strSecurityContext = getDefaultSecurityContext(paramContext, paramString);
		String strSecurityType = PropertyUtil.getSchemaProperty(paramContext, "type_SecurityContext");
		String strSecurityRelProject = PropertyUtil.getSchemaProperty(paramContext, "relationship_SecurityContextProject");
		StringList localStringList = new StringList();
		localStringList.addElement("from[" + strSecurityRelProject + "].to.name");
		MapList localMapList = DomainObject.findObjects(paramContext, strSecurityType, strSecurityContext, "*", "*", "*", null, strSecurityContext, true, localStringList, (short) 0);
		if (localMapList.size() > 0) {
			Map localMap = (Map) localMapList.get(0);
			strprojectName = (String) localMap.get("from[" + strSecurityRelProject + "].to.name");
		}
		return strprojectName;
	}

	public static String getDefaultOrganization(Context paramContext) throws FrameworkException {
		return getDefaultOrganization(paramContext, paramContext.getUser());
	}

	public static String getDefaultOrganization(Context paramContext, String paramString) throws FrameworkException {
		String strOrganizationName = "";
		String strSecurityContext = getDefaultSecurityContext(paramContext, paramString);
		String strSecurityType = PropertyUtil.getSchemaProperty(paramContext, "type_SecurityContext");
		String strSecurityRelOrganization = PropertyUtil.getSchemaProperty(paramContext, "relationship_SecurityContextOrganization");
		StringList localStringList = new StringList();
		localStringList.addElement("from[" + strSecurityRelOrganization + "].to.name");
		MapList localMapList = DomainObject.findObjects(paramContext, strSecurityType, strSecurityContext, "*", "*", "*", null, strSecurityContext, true, localStringList, (short) 0);
		if (localMapList.size() > 0) {
			Map localMap = (Map) localMapList.get(0);
			strOrganizationName = (String) localMap.get("from[" + strSecurityRelOrganization + "].to.name");
			strOrganizationName = strOrganizationName.substring(strOrganizationName.lastIndexOf("-")+2);
		}
		return strOrganizationName;
	}
	
	
	public static String getDefaultSecurityContext(Context paramContext, String paramString) throws FrameworkException {
		StringBuffer localStringBuffer = new StringBuffer(150);
		localStringBuffer.append("print ");
		localStringBuffer.append("$1");
		localStringBuffer.append(" \"");
		localStringBuffer.append("$2");
		localStringBuffer.append("\" select $3 dump");
		String strPersonPropertyValue = MqlUtil.mqlCommand(paramContext, localStringBuffer.toString(),
				new String[] { "person", paramString, "property[preference_VPLMIntegVPLMContext].value" });
		
		String strPersonProperty = strPersonPropertyValue;
		if (!(strPersonPropertyValue.startsWith(REPLACE_PRE_FIX))) {
			strPersonProperty = REPLACE_PRE_FIX + strPersonProperty;
		}
		String strMql = "print person $1 select $2 dump;";
		String strContextValue = MqlUtil.mqlCommand(paramContext, strMql, true,
				new String[] { paramString, "assignment[" + strPersonProperty + "]" });
		if ("false".equals(strContextValue.toLowerCase())) {
			strPersonPropertyValue = "";
		}
		return strPersonPropertyValue;
	}
	
	
	public static Map getProjectValues ( Context context , String projectName, String organizationName) {
		
		Map projectsMap = new HashMap();
		try{
			String strProjectId = getProjectObjectId(context, projectName, organizationName);
			if(! DomainConstants.EMPTY_STRING.equals(strProjectId)){
				DomainObject domObj = new DomainObject(strProjectId);
				String strProductDivision = StringUtils.trimToEmpty(domObj.getInfo(context, "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to."+cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage()) ));
				String strProductType     = StringUtils.trimToEmpty(domObj.getInfo(context, "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to."+cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage()) ));
				String strVehicle         = StringUtils.trimToEmpty(domObj.getInfo(context, "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to."+cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage()) ));
				projectsMap.put(DomainConstants.SELECT_ID,  strProjectId);
				projectsMap.put(PRODUCT_TYPE,     			strProductType);
				projectsMap.put(PRODUCT_DIVISION, 			strProductDivision);
				projectsMap.put(VEHICLE,          			strVehicle);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return projectsMap;
	}
	
	
	public static String getProjectObjectId ( Context context, String projectName, String organizationName) {
		String stProject    = projectName + " - " + organizationName;
	    String displayTitle = cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PROJECT_CODE;
	    String strRootWhere = displayTitle + "=='"+stProject+"'";
	    String strProjectRootId = DomainConstants.EMPTY_STRING;
	    try{
	    	strProjectRootId = MqlUtil.mqlCommand(context, "temp query bus $1 $2 $3 where $4 select $5 dump", new String[] {cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, "*", "-", strRootWhere, "id"});
			if(! DomainConstants.EMPTY_STRING.equals(strProjectRootId)){
				String[] strProjectRootIdArray = strProjectRootId.split(",");
				strProjectRootId = strProjectRootIdArray[3];	
			}
	    }catch(Exception e){
	    	e.printStackTrace();
	    }
	    return strProjectRootId;
	}
	
	
	public static String getRootValue( Context context, String strRootKey ) {
		
		String strWhereAttributeName = cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_COMMON_CODE;
		String strRootWhere = strWhereAttributeName + "=='"+strRootKey+"'";
		String strProductRootId = DomainConstants.EMPTY_STRING;
		
		try {
			strProductRootId = MqlUtil.mqlCommand(context, "temp query bus $1 $2 $3 where $4 select $5 dump", new String[] {cdmConstantsUtil.TYPE_CDMCOMMONCODE, "*", "-", strRootWhere, "id"});
			if(! DomainConstants.EMPTY_STRING.equals(strProductRootId)){
				String[] strProductRootIdArray = strProductRootId.split(",");
				strProductRootId = strProductRootIdArray[3];
			}
		} catch (FrameworkException e) {
			e.printStackTrace();
		}
		return strProductRootId;
	}
	
	
	public static String getProductsValue( Context context, String strRootKey, String strCommonCodeValue ) {
		StringList selectStmts = new StringList();
		selectStmts.add(DomainConstants.SELECT_ID);
		StringList selectRel = new StringList();
		String strProductRootId = getRootValue(context, strRootKey);
		if(DomainConstants.EMPTY_STRING.equals(strProductRootId)){
			return DomainConstants.EMPTY_STRING;
		}
		String strProductId = DomainConstants.EMPTY_STRING;
		try{
			DomainObject rootDomObj = new DomainObject(strProductRootId);
			String strWhere = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage()) + "=='"+strCommonCodeValue+"'";
			MapList mlProductTypeLowList = rootDomObj.getRelatedObjects(context, 
					cdmConstantsUtil.RELATIONSHIP_CDMCOMMONCODERELATIONSHIP,    // relationship
					cdmConstantsUtil.TYPE_CDMCOMMONCODE,                        // type
					selectStmts,                         						// objects
					selectRel,                           						// relationships
					false,                               						// to
					true,                                						// from
					(short)1,                            						// recurse
					strWhere,                                					// where
					null,                                						// relationship where
					(short)0);                           						// limit
			if(mlProductTypeLowList.size() == 0){
				return DomainConstants.EMPTY_STRING;
			}
			Map map = (Map)mlProductTypeLowList.get(0);
			strProductId = (String)map.get(DomainConstants.SELECT_ID);
		}catch(Exception e){
			e.printStackTrace();
		}
		return strProductId;
	}
	
	
	public static String getProductsValue( Context context, String strCommonCodeValue ) {
		
		String strProductsValueId = DomainConstants.EMPTY_STRING;
		try{
			String strWhere = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage()) + "=='"+strCommonCodeValue+"'";
			String mqlValue = MqlUtil.mqlCommand(context, "temp query bus $1 $2 $3 where $4 select $5 dump $6", new String[] {cdmConstantsUtil.TYPE_CDMCOMMONCODE, "*", "-", strWhere, "id", ","});
			if(! DomainConstants.EMPTY_STRING.equals(mqlValue)){
				StringList slProductsValueList = FrameworkUtil.split(mqlValue, "," );
				strProductsValueId = slProductsValueList.get(3).toString();	
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return strProductsValueId;
	}
	
	
	public static int getRelatedEBOMParts( Context context, String strParentObjectId ) {
		StringList selectStmts = new StringList();
		selectStmts.add(DomainConstants.SELECT_ID);
		StringList selectRel = new StringList();
		String strProductId = DomainConstants.EMPTY_STRING;
		MapList mlPartList = new MapList();
		try{
			if(DomainConstants.EMPTY_STRING.equals(strParentObjectId)){
				return 0;
			}
			DomainObject rootDomObj = new DomainObject(strParentObjectId);
			String strWhere = null;
			mlPartList = rootDomObj.getRelatedObjects(context, 
					DomainConstants.RELATIONSHIP_EBOM,   // relationship
					cdmConstantsUtil.TYPE_CDMPART,   	 // type
					selectStmts,                         // objects
					selectRel,                           // relationships
					false,                               // to
					true,                                // from
					(short)0,                            // recurse
					strWhere,                            // where
					null,                                // relationship where
					(short)0);                           // limit
		}catch(Exception e){
			e.printStackTrace();
		}
		return mlPartList.size();
	}
	
	public static String getUserFullName(Context context, String name) throws Exception {
    	String userFullName = name;
        try {
            if (name != null && ! name.equals("") && ! name.equals("") && ! name.equals("creator")) {
                DomainObject person = getPersonDomainObject(context, name);
                userFullName = person.getInfo(context, DomainConstants.SELECT_ATTRIBUTE_FIRSTNAME);
            }
        } catch (Exception e) {}
        return userFullName;
    }
	
	@SuppressWarnings("unused")
    public static DomainObject getPersonDomainObject(Context context, String name) throws Exception {
        DomainObject person = new DomainObject(new BusinessObject("Person", name, "-", "eService Production"));
        if (person == null)
            person = new DomainObject(new BusinessObject("Person", name, "-", "eService Administration"));
        if (person == null || !person.exists(context))
            throw new Exception("Error : Not exists user !!!.");
        return person;
    }
	
}
