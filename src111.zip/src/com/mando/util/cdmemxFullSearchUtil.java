package com.mando.util;

import java.util.HashMap;
import java.util.Iterator;
import java.util.StringTokenizer;

import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.mxType;
import com.matrixone.apps.framework.ui.UISearchUtil;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.Context;
import matrix.util.Pattern;
import matrix.util.StringList;

public class cdmemxFullSearchUtil {
	public static String convertSymbolicNames(Context paramContext, String paramString1, String paramString2)
			throws Exception {
		String str1 = paramString1;
		if ((paramString1 != null) && (!("".equals(paramString1)))) {
			StringList localStringList1 = FrameworkUtil.splitString(paramString1, paramString2);
			StringList localStringList2 = new StringList(localStringList1.size());
			Object localObject = "";
			for (int i = 0; i < localStringList1.size(); ++i) {
				String str2 = (String) localStringList1.get(i);
				String str3 = "=";
				if (str2.indexOf("!=") != -1) {
					str3 = "!=";
				} else if (str2.indexOf(">") != -1) {
					str3 = ">";
				} else if (str2.indexOf("<") != -1) {
					str3 = "<";
				}
				String str4 = str2.substring(0, str2.indexOf(str3));
				String str5 = str2.substring(str2.indexOf(str3) + str3.length());
				if ("CURRENT".equalsIgnoreCase(str4)) {
					UISearchUtil localUISearchUtil = new UISearchUtil();
					str5 = getStateNames(paramContext, str5, (String) localObject);
				} else {
					str5 = getActualNames(paramContext, str5);
				}
				if ("TYPES".equalsIgnoreCase(str4)) {
					localObject = str5;
				}
				localStringList2.add(str4 + str3 + str5);
			}
			str1 = FrameworkUtil.join(localStringList2, paramString2);
		}
		str1 = "TYPES=cdmPart:POLICY=cdmPartPolicy:CURRENT=Preliminary";
		return ((String) str1);
	}
	
	
	private static boolean canUse(String paramString) {
		return ((paramString != null) && (!("".equals(paramString.trim()))) && (!("null".equals(paramString))));
	}
	
	public static String getStateNames(Context paramContext, String paramString1, String paramString2) throws Exception {
		Pattern localPattern = new Pattern("");
		if (canUse(paramString1)) {
			Object localObject1 = new Pattern("");
			StringList localStringList1 = FrameworkUtil.split(paramString1, ",");
			Object localObject2;
			String str2;
			for (int i = 0; i < localStringList1.size(); ++i) {
				localObject2 = (String) localStringList1.get(i);
				if (canUse((String) localObject2)) {
					StringList localStringList2 = FrameworkUtil.split((String) localObject2, ".");
					if (localStringList2.size() == 1) {
						((Pattern) localObject1).addPattern((String) localObject2);
					} else {
						str2 = (String) localStringList2.get(0);
						str2 = getActualNames(paramContext, str2);
						localObject2 = (String) localStringList2.get(1);
//						localObject2 = PropertyUtil.getSchemaProperty(paramContext, "policy", str2, (String) localObject2);
						localObject2 = PropertyUtil.getSchemaProperty(paramContext, "policy", "cdmPartPolicy", "Preliminary");
						
						localPattern.addPattern((String) localObject2);
					}
				}
			}
			if (!("".equals(((Pattern) localObject1).getPattern()))) {
				String str1 = getUnresolvedStateNames(paramContext, ((Pattern) localObject1).getPattern(),
						paramString2);
				localObject2 = FrameworkUtil.split(str1, ",");
				for (int j = 0; j < ((StringList) localObject2).size(); ++j) {
					str2 = (String) ((StringList) localObject2).get(j);
					if (canUse(str2)) {
						localPattern.addPattern(str2);
					}
				}
			}
		}

		Object localObject1 = localPattern.getPattern();
		if (((String) localObject1).length() > 0) {
			localObject1 = ((String) localObject1).substring(1, ((String) localObject1).length());
		}

		return ((String) (String) localObject1);
	}
	
	
	
	private static String getUnresolvedStateNames(Context paramContext, String paramString1, String paramString2)
			throws Exception {
		Pattern localPattern = new Pattern("");
		String str1 = "";
		if ((paramString2 == null) || ("".equalsIgnoreCase(paramString2))) {
			paramString2 = EnoviaResourceBundle.getProperty(paramContext, "emxFramework.GenericSearch.Types");
		}

		MapList localMapList = new MapList();
		StringBuffer localStringBuffer = new StringBuffer();
		String str2 = getActualNames(paramContext, paramString2);
		StringTokenizer localStringTokenizer = new StringTokenizer(str2, ",");
		Object localObject1;
		Object localObject2;
		Object localObject3;
		while (localStringTokenizer.hasMoreTokens()) {
			String str3 = localStringTokenizer.nextToken();
			try {
				localMapList = mxType.getPolicies(paramContext, str3, true);
			} catch (Exception localException) {
			}
			if (localMapList != null) {
				localObject1 = localMapList.iterator();
				while (((Iterator) localObject1).hasNext()) {
					localObject2 = (HashMap) ((Iterator) localObject1).next();
					localObject3 = (String) ((HashMap) localObject2).get("name");
					localStringBuffer.append((String) localObject3);
					localStringBuffer.append(",");
				}
			}
		}
		String str3 = localStringBuffer.toString();

		if ((str3 != null) && (!("".equalsIgnoreCase(str3)))) {
			localObject1 = FrameworkUtil.split(str3, ",");
			localObject2 = paramString1;
			localObject3 = FrameworkUtil.split((String) localObject2, ",");

			for (int i = 0; i < ((StringList) localObject1).size(); ++i) {
				String str4 = (String) ((StringList) localObject1).get(i);

				for (int j = 0; j < ((StringList) localObject3).size(); ++j) {
					String str5 = (String) ((StringList) localObject3).get(j);
					String str6 = PropertyUtil.getSchemaProperty(paramContext, "policy", str4, str5);
					if ((str6 != null) && ("".equals(str6))) {
						str6 = str5;
					}
					if ((!(str6.startsWith("state_"))) && (!(localPattern.match(str6)))) {
						localPattern.addPattern(str6);
					}
				}
			}
			str1 = localPattern.getPattern();
			if ((str1 != null) && (!("".equals(str1)))) {
				str1 = str1.substring(1, str1.length());
			}
		}
		return ((String) (String) (String) str1);
	}
	
	
    
    public static String getActualNames(Context paramContext, String paramString) throws Exception {
		String str1 = "";
		String str2 = "";
		String str3 = "";
		int i = 0;
		StringTokenizer localStringTokenizer = new StringTokenizer(paramString, ",");
		Pattern localPattern = new Pattern("");

		int j = 0;
		try {
			while (localStringTokenizer.hasMoreTokens()) {
				str3 = localStringTokenizer.nextToken();
				String str4 = str3;
				if (i == 0) {
					str3 = str3.trim();
				}
				if (str3.endsWith("\\")) {
					i = 1;
				} else {
					i = 0;
				}
				if (str3.indexOf(".") != -1) {
					StringList localStringList = FrameworkUtil.split(str3, ".");
					str2 = PropertyUtil.getSchemaProperty(paramContext, "policy",
							PropertyUtil.getSchemaProperty(paramContext, (String) localStringList.get(0)),
							(String) localStringList.get(1));
				} else {
					str2 = PropertyUtil.getSchemaProperty(paramContext, str3);
				}
				if ("".equals(str2)) {
					localPattern.addPattern(str4);
					if (paramString.endsWith(","))
						;
					j = 1;
				}

				if ((!(str3.equals(str2))) && (UIUtil.isNotNullAndNotEmpty(str2))) {
					localPattern.addPattern(str2);
				}
				localPattern.addPattern(str4);
			}

			str1 = localPattern.getPattern();
			if (j != 0) {
				str1 = str1.concat(",");
			}
			if (str1.length() != 0)
				str1 = str1.substring(1, str1.length());
		} catch (Exception localException) {
			return "";
		}

		return str1;
	}
    
}
