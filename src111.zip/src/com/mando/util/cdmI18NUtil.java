package com.mando.util;

import com.matrixone.apps.domain.DomainObject;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.MatrixException;

/**
 * 
 * @author jshyun
 * @date 2016. 9. 5.
 * 
 * Utility for I18N(Internationalization) and L10N(Localization) 
 */
public class cdmI18NUtil {
	private Context context;
	private String locale;
	
	public cdmI18NUtil(Context context){
		this(context, "en");
	}
	
	public cdmI18NUtil(Context context, String locale){
		this.context = context;
		this.locale = locale;
	}
	
	public void setLocale(String locale){
		this.locale = locale;
	}
	
	public String getLocale(){
		return locale;
	}
	
	/**
	 * 
	 * @param name format(CC-%010d)
	 * @param state check state
	 * @return cdmCommonCode value return by user's browser locale. 
	 * @throws Exception 
	 * 
	 * If state is true, do not return cdmCommonCode value be current 'Inactive'. 
	 * If state is false, return cdmCommonCode value.
	 */
	public String getL10N(String name, boolean state) throws Exception {
		try {
			BusinessObject bus = new BusinessObject("cdmCommonCode", name, "-", "eService Production");
			DomainObject domObj = new DomainObject(bus);
			
			if(state && !"Active".equals(domObj.getInfo(context, "current"))){
				throw new Exception(domObj.getId(context) + " is not in the 'Active' state.");
			}
			
			if(locale == null){
				throw new Exception("locale is null.");
			}else if(locale.startsWith("ko")){
				return domObj.getAttributeValue(context, "cdmCommonCodeNameKo");
			}else if(locale.startsWith("en")){
				return domObj.getAttributeValue(context, "cdmCommonCodeNameEn");
			}else if(locale.startsWith("zh")){
				return domObj.getAttributeValue(context, "cdmCommonCodeNameCn");
			}else{
				return domObj.getAttributeValue(context, "cdmCommonCodeNameEn");
			}
		} catch (MatrixException e) {
			throw e;
		}
	}
}
