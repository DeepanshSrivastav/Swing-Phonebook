package com.mando.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

public class cdmPropertiesUtil {
	public cdmPropertiesUtil() {
	}

	public static Properties getJDBCPropFile() throws IOException, ClassNotFoundException {
		return getPropFile( "Connection.properties" );
	}

	public static Properties getPropFile( String sFileName ) throws IOException, ClassNotFoundException {
		Properties prop = new Properties();

		cdmPropertiesUtil pu = new cdmPropertiesUtil();
		InputStream ips = pu.getClass().getResourceAsStream( "/" + sFileName );
		prop.load(ips);
		ips.close();
		return prop;
	}

	public static String getPropValue( String sFileName, String sName ) {
		String sRet = "";
	    try {
			sRet = ( String )getPropFile( sFileName ).get( sName );
		} catch( Exception e ) {
		}
		return StringUtils.trimToEmpty(sRet);
	}
}
