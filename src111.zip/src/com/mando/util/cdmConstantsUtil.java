package com.mando.util;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.util.PropertyUtil;

public class cdmConstantsUtil implements DomainConstants {

	// TYPE
	public static final String TYPE_CDMORCADPRODUCT = PropertyUtil.getSchemaProperty("type_cdmOrCADProduct");
	public static final String TYPE_CDMORCADDESIGNTEMPLATE = PropertyUtil.getSchemaProperty("type_cdmOrCADDesignTemplate");
	public static final String TYPE_CDMCOMMONCODE = PropertyUtil.getSchemaProperty("type_cdmCommonCode");
	public static final String TYPE_CDM_SUB_PROJECT_GROUP = PropertyUtil.getSchemaProperty("type_cdmSubProjectGroup");
	public static final String TYPE_CDM_PROJECT_GROUP_OBJECT = PropertyUtil.getSchemaProperty("type_cdmProjectGroupObject");
	public static final String TYPE_CDMORCADPART = PropertyUtil.getSchemaProperty("type_cdmOrCADPart");
	public static final String TYPE_DRAWING = PropertyUtil.getSchemaProperty("type_Drawing");
	public static final String TYPE_CDMPEO		= PropertyUtil.getSchemaProperty("type_cdmPEO");
	public static final String TYPE_CDMEAR		= PropertyUtil.getSchemaProperty("type_cdmEAR");
	public static final String TYPE_CDMECO		= PropertyUtil.getSchemaProperty("type_cdmECO");
	public static final String TYPE_CDMDCR		= PropertyUtil.getSchemaProperty("type_cdmDCR");
	public static final String TYPE_CDMAUTOCAD		= PropertyUtil.getSchemaProperty("type_cdmAutoCAD");
	public static final String TYPE_CDMNXPART		= PropertyUtil.getSchemaProperty("type_cdmNXPart");
	public static final String TYPE_CDMNXDRAWING		= PropertyUtil.getSchemaProperty("type_cdmNXDrawing");
	public static final String TYPE_DOCUMENT		= PropertyUtil.getSchemaProperty("type_Document");
	public static final String TYPE_CDMPART = PropertyUtil.getSchemaProperty("type_cdmPart");
	public static final String TYPE_CATDrawing = PropertyUtil.getSchemaProperty("type_CATDrawing");
	
	public static final String TYPE_CATPART = PropertyUtil.getSchemaProperty("type_CATPart");
	public static final String TYPE_CATPRODUCT = PropertyUtil.getSchemaProperty("type_CATProduct");
	public static final String TYPE_CDMMECHANICALPART = PropertyUtil.getSchemaProperty("type_cdmMechanicalPart");
	public static final String TYPE_CDMPHANTOMPART = PropertyUtil.getSchemaProperty("type_cdmPhantomPart");
	public static final String TYPE_CDMIMAGEDRAWING = PropertyUtil.getSchemaProperty("type_cdmImageDrawing");
	public static final String TYPE_CDMV4MODEL = PropertyUtil.getSchemaProperty("type_cdmV4Model");
	public static final String TYPE_CDM_ELECTRONIC_PART = PropertyUtil.getSchemaProperty("type_cdmElectronicPart");
	public static final String TYPE_CDM_ELECTRONIC_ASSEMBLY_PART = PropertyUtil.getSchemaProperty("type_cdmElectronicAssemblyPart");
	// 2016.12.07 sj park
	public static final String TYPE_CDMADMINNOTICE = PropertyUtil.getSchemaProperty("type_cdmAdminNotice");
	
	public static final String TYPE_CDMSTEP = PropertyUtil.getSchemaProperty("type_cdmSTEP");
	public static final String TYPE_CDMDXF = PropertyUtil.getSchemaProperty("type_cdmDXF");
	public static final String TYPE_CDMCATIACGM = PropertyUtil.getSchemaProperty("type_cdmCATIAcgm");
	public static final String TYPE_CDMCATIACGR = PropertyUtil.getSchemaProperty("type_cdmCATIAcgr");
	public static final String TYPE_CDMIGES = PropertyUtil.getSchemaProperty("type_cdmIGES");
	public static final String TYPE_CDMSMG = PropertyUtil.getSchemaProperty("type_cdmSMG");
	public static final String TYPE_CDMCATIAMATERIAL = PropertyUtil.getSchemaProperty("type_cdmCATIAMaterial");
	public static final String TYPE_CDMORCADMASTER = PropertyUtil.getSchemaProperty("type_cdmOrCADMaster");
	
	// POLICY
	public static final String POLICY_DESIGN_TEAM_DEFINITION = PropertyUtil.getSchemaProperty("policy_DesignTEAMDefinition");
	public static final String Policy_DESIGN_TEAM_RESOURCE = PropertyUtil.getSchemaProperty("policy_DesignTEAMResource");
	public static final String POLICY_VERSIONED_DESIGN_TEAM_POLICY = PropertyUtil.getSchemaProperty("policy_VersionedDesignTEAMPolicy");
	public static final String POLICY_CDMCOMMONCODEPOLICY = PropertyUtil.getSchemaProperty("policy_cdmCommonCodePolicy");
	public static final String POLICY_CDM_PROJECT_GROUP_POLICY = PropertyUtil.getSchemaProperty("policy_cdmProjectGroupPolicy");
	public static final String POLICY_CDM_EC_POLICY = PropertyUtil.getSchemaProperty("policy_cdmECPolicy");
	public static final String POLICY_CDM_PART_DEVELOPMENT_POLICY = PropertyUtil.getSchemaProperty("policy_cdmPartDevelopmentPolicy");
	public static final String POLICY_CDM_PART_PRODUCTION_POLICY = PropertyUtil.getSchemaProperty("policy_cdmPartProductionPolicy");
	public static final String POLICY_CDM_PART_POLICY = PropertyUtil.getSchemaProperty("policy_cdmPartPolicy");
	
	//2016.12.07 sj park
	public static final String POLICY_CDM_ADMIN_NOTICE_POLICY = PropertyUtil.getSchemaProperty("policy_cdmAdminNoticePolicy");
	
	
	// RELATIONSHIP
	public static final String RELATIONSHIP_VERSION_OF = PropertyUtil.getSchemaProperty("relationship_VersionOf");
	public static final String RELATIONSHIP_LATEST_VERSION = PropertyUtil.getSchemaProperty("relationship_LatestVersion");
	public static final String RELATIONSHIP_ACTIVE_VERSION = PropertyUtil.getSchemaProperty("relationship_ActiveVersion");
	public static final String RELATIONSHIP_CDMCOMMONCODERELATIONSHIP = PropertyUtil.getSchemaProperty("relationship_cdmCommonCodeRelationship");
	public static final String RELATIONSHIP_CDM_PROJECT_GROUP_OBJECT_TYPE_RELATIONSHIP = PropertyUtil.getSchemaProperty("relationship_cdmProjectGroupObjectTypeRelationShip");
	public static final String RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME = PropertyUtil.getSchemaProperty("relationship_cdmProjectGroupRelationshipProductName");
	public static final String RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE = PropertyUtil.getSchemaProperty("relationship_cdmProjectGroupRelationshipProductType");
	public static final String RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE = PropertyUtil.getSchemaProperty("relationship_cdmProjectGroupRelationshipVehicle");
	public static final String RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER = PropertyUtil.getSchemaProperty("relationship_cdmProjectGroupRelationshipCustomer");
	
	public static final String RELATIONSHIP_CAD_SUBCOMPONENT = PropertyUtil.getSchemaProperty("relationship_CADSubComponent");
	public static final String RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC = PropertyUtil.getSchemaProperty("relationship_cdmProjectRelationshipEC");
	public static final String RELATIONSHIP_CDMRELATEDPCBPART = PropertyUtil.getSchemaProperty("relationship_cdmRelatedPCBPart");
	public static final String RELATIONSHIP_CDMRELATEDDRAWING = PropertyUtil.getSchemaProperty("relationship_cdmRelatedDrawing");
	public static final String RELATIONSHIP_CDM_PART_RELATION_OPTION       = PropertyUtil.getSchemaProperty("relationship_cdmPartRelationOption");
	public static final String RELATIONSHIP_CDM_PART_RELATION_ORG          = PropertyUtil.getSchemaProperty("relationship_cdmPartRelationOrg");
	public static final String RELATIONSHIP_CDM_PART_RELATION_PROJECT      = PropertyUtil.getSchemaProperty("relationship_cdmPartRelationProject");
	public static final String RELATIONSHIP_CDM_PART_RELATION_VEHICLE      = PropertyUtil.getSchemaProperty("relationship_cdmPartRelationVehicle");
	public static final String RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE = PropertyUtil.getSchemaProperty("relationship_cdmPartRelationProjectType");
	public static final String RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE = PropertyUtil.getSchemaProperty("relationship_cdmPartRelationProductType");
	public static final String RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_PARTS 	= PropertyUtil.getSchemaProperty("relationship_cdmProjectRelationshipParts");
	public static final String RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_DOCUMENTS = PropertyUtil.getSchemaProperty("relationship_cdmProjectRelationshipDocuments");
	public static final String RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_WORKSPACE = PropertyUtil.getSchemaProperty("relationship_cdmProjectRelationshipWorkspace");
	public static final String RELATIONSHIP_CDM_DOCUMENTS_PROJECT_RELATIONSHIP = PropertyUtil.getSchemaProperty("relationship_cdmDocumentsProjectRelationship");
	public static final String RELATIONSHIP_ASSOCIATED_DRAWING = PropertyUtil.getSchemaProperty("relationship_AssociatedDrawing");
	public static final String RELATIONSHIP_DERIVED_OUTPUT = PropertyUtil.getSchemaProperty("relationship_DerivedOutput");
	
	// ATTRIBUTE
	public static final String ATTRIBUTE_V_NAME = PropertyUtil.getSchemaProperty("attribute_V_Name");
	public static final String ATTRIBUTE_CDMCOMMONCODETREESEQ = PropertyUtil.getSchemaProperty("attribute_cdmCommonCodeTreeSeq");
	public static final String ATTRIBUTE_CDMCOMMONCODENAMEEN = PropertyUtil.getSchemaProperty("attribute_cdmCommonCodeNameEn");
	public static final String ATTRIBUTE_CDMCOMMONCODENAMEKO = PropertyUtil.getSchemaProperty("attribute_cdmCommonCodeNameKo");
	public static final String ATTRIBUTE_CDMCOMMONCODENAMECN = PropertyUtil.getSchemaProperty("attribute_cdmCommonCodeNameCn");
	public static final String ATTRIBUTE_CDM_COMMON_CODE = PropertyUtil.getSchemaProperty("attribute_cdmCommonCode");
	
	public static final String ATTRIBUTE_CDM_PROJECT_GROUP_CUSTOMER_ATTRIBUTE = PropertyUtil.getSchemaProperty("attribute_cdmProjectGroupCustomerAttribute");
	public static final String ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE = PropertyUtil.getSchemaProperty("attribute_cdmProjectGroupProductTypeAttribute");
	public static final String ATTRIBUTE_CDM_PROJECT_GROUP_OBJECT_CODE = PropertyUtil.getSchemaProperty("attribute_cdmProjectGroupObjectCode");
	public static final String ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_NAME_ATTRIBUTE = PropertyUtil.getSchemaProperty("attribute_cdmProjectGroupProductNameAttribute");
	public static final String ATTRIBUTE_CDM_PROJECT_GROUP_VEHICLE_ATTRIBUTE = PropertyUtil.getSchemaProperty("attribute_cdmProjectGroupVehicleAttribute");
	public static final String ATTRIBUTE_CDM_SUB_PROJECT_GROUP_CODE = PropertyUtil.getSchemaProperty("attribute_cdmSubProjectGroupCode");
	public static final String ATTRIBUTE_CDM_PROJECT_CODE = PropertyUtil.getSchemaProperty("attribute_cdmProjectCode");
	public static final String ATTRIBUTE_CDMCHECKMIGRATION = PropertyUtil.getSchemaProperty("attribute_cdmCheckMigration");
	public static final String ATTRIBUTE_CDM_PROJECT_OBJECT_ID_M = PropertyUtil.getSchemaProperty("attribute_cdmProjectObjectIdM");
	
	public static final String ATTRIBUTE_CDM_EC_CODE = PropertyUtil.getSchemaProperty("attribute_cdmECCode");
	public static final String ATTRIBUTE_CDM_EC_CDMONLY  = PropertyUtil.getSchemaProperty("attribute_cdmECCategory");
	public static final String ATTRIBUTE_CDM_EC_PROJECT  = PropertyUtil.getSchemaProperty("attribute_cdmECProject");
	public static final String ATTRIBUTE_CDM_EC_CATEGORY = PropertyUtil.getSchemaProperty("attribute_cdmECCategoryOnlyCDM");
	public static final String ATTRIBUTE_CDM_EC_TITLE	= PropertyUtil.getSchemaProperty("attribute_cdmECTitle");
	public static final String ATTRIBUTE_CDM_EC_CREATOR = PropertyUtil.getSchemaProperty("attribute_cdmECCreator");
	public static final String ATTRIBUTE_CDM_EC_CREATE_DATE = PropertyUtil.getSchemaProperty("attribute_cdmECCreateDate");
	
	public static final String ATTRIBUTE_CDM_PART_TYPE                = PropertyUtil.getSchemaProperty("attribute_cdmPartType");
	public static final String ATTRIBUTE_CDM_PART_GLOBAL              = PropertyUtil.getSchemaProperty("attribute_cdmPartGlobal");
	public static final String ATTRIBUTE_CDM_PART_ERP_INTERFACE       = PropertyUtil.getSchemaProperty("attribute_cdmPartERPInterface");
	public static final String ATTRIBUTE_CDM_PART_IS_CASTING          = PropertyUtil.getSchemaProperty("attribute_cdmPartIsCasting");
	public static final String ATTRIBUTE_CDM_PART_APPROVAL_TYPE       = PropertyUtil.getSchemaProperty("attribute_cdmPartApprovalType");
	public static final String ATTRIBUTE_CDM_PART_PHASE               = PropertyUtil.getSchemaProperty("attribute_cdmPartPhase");
	public static final String ATTRIBUTE_CDM_PART_DRAWING_NO          = PropertyUtil.getSchemaProperty("attribute_cdmPartDrawingNo");
	public static final String ATTRIBUTE_CDM_PART_ECO_NUMBER          = PropertyUtil.getSchemaProperty("attribute_cdmPartECONumber");
	public static final String ATTRIBUTE_CDM_PART_INVESTOR            = PropertyUtil.getSchemaProperty("attribute_cdmPartInvestor");
	public static final String ATTRIBUTE_CDM_PART_ITEM_TYPE           = PropertyUtil.getSchemaProperty("attribute_cdmPartItemType");
	public static final String ATTRIBUTE_CDM_PART_NAME                = PropertyUtil.getSchemaProperty("attribute_cdmPartName");
	public static final String ATTRIBUTE_CDM_PART_NO                  = PropertyUtil.getSchemaProperty("attribute_cdmPartNo");
	public static final String ATTRIBUTE_CDM_PART_OEM_ITEM_NUMBER     = PropertyUtil.getSchemaProperty("attribute_cdmPartOEMItemNumber");
	public static final String ATTRIBUTE_CDM_PART_OPTION1             = PropertyUtil.getSchemaProperty("attribute_cdmPartOption1");
	public static final String ATTRIBUTE_CDM_PART_OPTION2             = PropertyUtil.getSchemaProperty("attribute_cdmPartOption2");
	public static final String ATTRIBUTE_CDM_PART_OPTION3             = PropertyUtil.getSchemaProperty("attribute_cdmPartOption3");
	public static final String ATTRIBUTE_CDM_PART_OPTION4             = PropertyUtil.getSchemaProperty("attribute_cdmPartOption4");
	public static final String ATTRIBUTE_CDM_PART_OPTION5             = PropertyUtil.getSchemaProperty("attribute_cdmPartOption5");
	public static final String ATTRIBUTE_CDM_PART_OPTION6             = PropertyUtil.getSchemaProperty("attribute_cdmPartOption6");
	public static final String ATTRIBUTE_CDM_PART_OPTION7             = PropertyUtil.getSchemaProperty("attribute_cdmPartOption7");
	public static final String ATTRIBUTE_CDM_PART_OPTION8             = PropertyUtil.getSchemaProperty("attribute_cdmPartOption8");
	public static final String ATTRIBUTE_CDM_PART_OPTION9             = PropertyUtil.getSchemaProperty("attribute_cdmPartOption9");
	public static final String ATTRIBUTE_CDM_PART_OPTION_ETC          = PropertyUtil.getSchemaProperty("attribute_cdmPartOptionETC");
	public static final String ATTRIBUTE_CDM_PART_ORG1 			      = PropertyUtil.getSchemaProperty("attribute_cdmPartOrg1");
	public static final String ATTRIBUTE_CDM_PART_ORG2 			      = PropertyUtil.getSchemaProperty("attribute_cdmPartOrg2");
	public static final String ATTRIBUTE_CDM_PART_ORG3                = PropertyUtil.getSchemaProperty("attribute_cdmPartOrg3");
	public static final String ATTRIBUTE_CDM_PART_PRODUCT_TYPE        = PropertyUtil.getSchemaProperty("attribute_cdmPartProductType");
	public static final String ATTRIBUTE_CDM_PART_PROJECT             = PropertyUtil.getSchemaProperty("attribute_cdmPartProject");
	public static final String ATTRIBUTE_CDM_PART_PUBLISHING_TARGET   = PropertyUtil.getSchemaProperty("attribute_cdmPartPublishingTarget");
	public static final String ATTRIBUTE_CDM_PART_ESTIMATED_WEIGHT    = PropertyUtil.getSchemaProperty("attribute_cdmPartEstimatedWeight");
	public static final String ATTRIBUTE_CDM_PART_SIZE                = PropertyUtil.getSchemaProperty("attribute_cdmPartSize");
	public static final String ATTRIBUTE_CDM_PART_CAD_WEIGHT          = PropertyUtil.getSchemaProperty("attribute_cdmPartCADWeight");
	public static final String ATTRIBUTE_CDM_PART_SURFACE_TREATMENT   = PropertyUtil.getSchemaProperty("attribute_cdmPartSurfaceTreatment");
	public static final String ATTRIBUTE_CDM_PART_REAL_WEIGHT         = PropertyUtil.getSchemaProperty("attribute_cdmPartRealWeight");
	public static final String ATTRIBUTE_CDM_PART_MATERIAL            = PropertyUtil.getSchemaProperty("attribute_cdmPartMaterial");
	public static final String ATTRIBUTE_CDM_PART_SURFACE             = PropertyUtil.getSchemaProperty("attribute_cdmPartSurface");
	public static final String ATTRIBUTE_CDM_PART_DESCRIPTION         = PropertyUtil.getSchemaProperty("attribute_cdmDescription");
	public static final String ATTRIBUTE_CDM_PART_VEHICLE             = PropertyUtil.getSchemaProperty("attribute_cdmPartVehicle");
	public static final String ATTRIBUTE_CDM_PART_CHANGE_REASON       = PropertyUtil.getSchemaProperty("attribute_cdmPartChangeReason");
	public static final String ATTRIBUTE_CDM_PART_PROJECT_TYPE        = PropertyUtil.getSchemaProperty("attribute_cdmPartProjectType");
	public static final String ATTRIBUTE_CDM_PART_OPTION_DESCRIPTION  = PropertyUtil.getSchemaProperty("attribute_cdmPartOptionDescription");
	public static final String ATTRIBUTE_CDM_PART_UOM                 = PropertyUtil.getSchemaProperty("attribute_cdmPartUOM");
	public static final String ATTRIBUTE_CDM_PART_EBOM_RELATION_ATTRIBUTE_UOM  = PropertyUtil.getSchemaProperty("attribute_cdmPartEBOMRelationAttributeUOM");
	public static final String ATTRIBUTE_CDM_PART_ORG_REL_ATTRIBUTE            = PropertyUtil.getSchemaProperty("attribute_cdmPartOrgRelAttribute");
	public static final String ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE         = PropertyUtil.getSchemaProperty("attribute_cdmPartOptionRelAttribute");
	
	public static final String ATTRIBUTE_CDM_EC_ATTRIBUTE_EC_TYPE_M          = PropertyUtil.getSchemaProperty("attribute_cdmECAttributeECTypeM");
	public static final String ATTRIBUTE_CDM_EC_ATTRIBUTE_COMMENTS_M         = PropertyUtil.getSchemaProperty("attribute_cdmECAttributeCommentsM");
	public static final String ATTRIBUTE_CDM_EC_ATTRIBUTE_PEO_TYPE_M         = PropertyUtil.getSchemaProperty("attribute_cdmECAttributePeoTypeM");
	public static final String ATTRIBUTE_CDM_EC_ATTRIBUTE_TEAM_M         	 = PropertyUtil.getSchemaProperty("attribute_cdmECAttributeTeamM");
	public static final String ATTRIBUTE_CDM_EC_ATTRIBUTE_PERSON_CHANGE_M    = PropertyUtil.getSchemaProperty("attribute_cdmECAttributePersonChangeM");
	public static final String ATTRIBUTE_CDM_EC_PHASE_M 				     = PropertyUtil.getSchemaProperty("attribute_cdmECPhaseM");
	
	public static final String ATTRIBUTE_CDM_DOCUMENTS_MASS  		   = PropertyUtil.getSchemaProperty("attribute_cdmDocumentsMass");
	public static final String ATTRIBUTE_CDM_DOCUMENTS_SURFACE  	   = PropertyUtil.getSchemaProperty("attribute_cdmDocumentsSurface");
	public static final String ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE   = PropertyUtil.getSchemaProperty("attribute_cdmDocumentsDocumentType");
	public static final String ATTRIBUTE_CDM_FILE_TYPE 			   	   = PropertyUtil.getSchemaProperty("attribute_cdmFileType");
	public static final String ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE	   = PropertyUtil.getSchemaProperty("attribute_cdmDocumentsPageSize");
	public static final String ATTRIBUTE_CDM_DOCUMENTS_SCALE	       = PropertyUtil.getSchemaProperty("attribute_cdmDocumentsScale");
	public static final String ATTRIBUTE_CDM_COMMENT			       = PropertyUtil.getSchemaProperty("attribute_cdmComment");
	public static final String ATTRIBUTE_CDM_DETAIL_DESCRIPTION		   = PropertyUtil.getSchemaProperty("attribute_cdmDetailDescription");
	public static final String ATTRIBUTE_CDM_3D_CAD_IDENTIFIER	   	   = PropertyUtil.getSchemaProperty("attribute_cdm3DCadIdentifier");
	public static final String ATTRIBUTE_CDM_TDMXID  		   	       = PropertyUtil.getSchemaProperty("attribute_cdmTDMXID");
	
	public static final String ATTRIBUTE_CDM_DOCUMENTS_TITLE_TYPE      = PropertyUtil.getSchemaProperty("attribute_cdmDocumentsTitleType");
	public static final String ATTRIBUTE_CDM_PART_STANDARD_BOM         = PropertyUtil.getSchemaProperty("attribute_cdmPartStandardBOM");
	public static final String ATTRIBUTE_CDM_MIGRATION_FLAG            = PropertyUtil.getSchemaProperty("attribute_cdmMigrationFlag");
	public static final String ATTRIBUTE_CDM_PART_APPLY_PART_LIST      = PropertyUtil.getSchemaProperty("attribute_cdmPartApplyPartList");
	public static final String ATTRIBUTE_CDM_PART_APPLY_SIZE_LIST      = PropertyUtil.getSchemaProperty("attribute_cdmPartApplySizeList");
	public static final String ATTRIBUTE_CDM_PART_APPLY_SURFACE_TREATMENT_LIST  = PropertyUtil.getSchemaProperty("attribute_cdmPartApplySurfaceTreatmentList");
	public static final String ATTRIBUTE_CDM_PART_FAMILY_BLOCK_CODE_NAME = PropertyUtil.getSchemaProperty("attribute_cdmPartFamilyBlockCodeName");
	public static final String ATTRIBUTE_CDM_ELECTRONIC_PART_SPECIFICATION = PropertyUtil.getSchemaProperty("attribute_cdmElectronicPartSpecification");
	public static final String ATTRIBUTE_CDM_DRAWING_NO          = PropertyUtil.getSchemaProperty("attribute_cdmDrawingNo");
	public static final String ATTRIBUTE_CDM_PART_PLM_OBJECTID   = PropertyUtil.getSchemaProperty("attribute_cdmPartPLMObjectId");
	public static final String ATTRIBUTE_CDM_PART_PLM_VARIANT_YN = PropertyUtil.getSchemaProperty("attribute_cdmPartPLMVariantYN");
	public static final String ATTRIBUTE_RELEASE_PHASE = PropertyUtil.getSchemaProperty("attribute_ReleasePhase");
	public static final String ATTRIBUTE_CDM_PART_PLM_MATERIAL_CO_SIGN_YN = PropertyUtil.getSchemaProperty("attribute_cdmPartPLMMaterialCoSignYN");
	public static final String ATTRIBUTE_CDM_PART_PLM_SURFACE_TREATMENT_CO_SIGN_YN = PropertyUtil.getSchemaProperty("attribute_cdmPartPLMSurfaceTreatmentCoSignYN");
	public static final String ATTRIBUTE_CDM_PART_OPTION_LABEL_NAME = PropertyUtil.getSchemaProperty("attribute_cdmPartOptionLabelName");
	public static final String ATTRIBUTE_CDM_PART_ESTIMATED_WEIGHT_UOM = PropertyUtil.getSchemaProperty("attribute_cdmPartEstimateWeightUnit");
	public static final String ATTRIBUTE_CDM_NOMENCLATURE = PropertyUtil.getSchemaProperty("attribute_cdmNomenclature");
																												   
	
	
	
	// SELECT ATTRIBUTE
	public static final String SELECT_ATTRIBUTE_TITLE = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_TITLE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_V_NAME = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_V_NAME).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDMCOMMONCODETREESEQ = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDMCOMMONCODETREESEQ).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_SUB_PROJECT_GROUP_CODE       = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_SUB_PROJECT_GROUP_CODE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PROJECT_GROUP_OBJECT_CODE    = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PROJECT_GROUP_OBJECT_CODE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PROJECT_CODE    = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PROJECT_CODE).append("]").toString();
	
	public static final String SELECT_ATTRIBUTE_CDM_PART_TYPE    			 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_TYPE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_GLOBAL    			 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_GLOBAL).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_ERP_INTERFACE    	 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_ERP_INTERFACE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_IS_CASTING    		 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_IS_CASTING).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_APPROVAL_TYPE    	 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_APPROVAL_TYPE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_PHASE    			 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_PHASE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_DRAWING_NO    		 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_DRAWING_NO).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_ECO_NUMBER    		 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_ECO_NUMBER).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_INVESTOR    		 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_INVESTOR).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_ITEM_TYPE    		 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_ITEM_TYPE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_NAME    			 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_NAME).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_NO    				 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_NO).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OEM_ITEM_NUMBER     = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OEM_ITEM_NUMBER).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION1             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION1).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION2             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION2).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION3             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION3).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION4             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION4).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION5             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION5).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION6             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION6).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION7             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION7).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION8             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION8).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION9             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION9).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION_ETC    	     = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION_ETC).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_ORG1    			 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_ORG1).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_ORG2    			 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_ORG2).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_ORG3    			 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_ORG3).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_PRODUCT_TYPE        = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_PRODUCT_TYPE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_PROJECT             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_PROJECT).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_PUBLISHING_TARGET   = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_PUBLISHING_TARGET).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_ESTIMATED_WEIGHT    = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_ESTIMATED_WEIGHT).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_SIZE                = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_SIZE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_CAD_WEIGHT          = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_CAD_WEIGHT).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_SURFACE_TREATMENT   = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_SURFACE_TREATMENT).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_REAL_WEIGHT         = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_REAL_WEIGHT).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_MATERIAL            = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_MATERIAL).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_SURFACE             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_SURFACE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_DESCRIPTION         = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_DESCRIPTION).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_VEHICLE             = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_VEHICLE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_CHANGE_REASON       = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_CHANGE_REASON).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_PROJECT_TYPE        = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_PROJECT_TYPE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION_DESCRIPTION  = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION_DESCRIPTION).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_UOM                 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_UOM).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_EBOM_RELATION_ATTRIBUTE_UOM  = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_EBOM_RELATION_ATTRIBUTE_UOM).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_ORG_REL_ATTRIBUTE            = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_ORG_REL_ATTRIBUTE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE         = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_COMMON_CODE              = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_COMMON_CODE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_EC_CDMONLY			= (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_EC_CDMONLY).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_STANDARD_BOM		 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_STANDARD_BOM).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_APPLY_PART_LIST	 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_APPLY_PART_LIST).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_APPLY_SIZE_LIST	 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_APPLY_SIZE_LIST).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_APPLY_SURFACE_TREATMENT_LIST	 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_APPLY_SURFACE_TREATMENT_LIST).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_EC_CODE	         = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_EC_CODE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_EC_PROJECT	     = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_EC_PROJECT).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_EC_TITLE	     = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_EC_TITLE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_EC_CREATOR	     = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_EC_CREATOR).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_EC_CREATE_DATE	 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_EC_CREATE_DATE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_FAMILY_BLOCK_CODE_NAME	 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_FAMILY_BLOCK_CODE_NAME).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_ELECTRONIC_PART_SPECIFICATION	 = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_ELECTRONIC_PART_SPECIFICATION).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_DRAWING_NO				= (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_DRAWING_NO).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_PLM_OBJECTID = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_PLM_OBJECTID).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_PLM_VARIANT_YN = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_PLM_VARIANT_YN).append("]").toString();
	public static final String SELECT_ATTRIBUTE_RELEASE_PHASE = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_RELEASE_PHASE).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_PLM_MATERIAL_CO_SIGN_YN = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_PLM_MATERIAL_CO_SIGN_YN).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_PLM_SURFACE_TREATMENT_CO_SIGN_YN = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_PLM_SURFACE_TREATMENT_CO_SIGN_YN).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_OPTION_LABEL_NAME = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_OPTION_LABEL_NAME).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_PART_ESTIMATED_WEIGHT_UOM = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_PART_ESTIMATED_WEIGHT_UOM).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_DOCUMENTS_MASS = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_DOCUMENTS_MASS).append("]").toString();
	public static final String SELECT_ATTRIBUTE_CDM_NOMENCLATURE = (new StringBuilder()).append("attribute[").append(ATTRIBUTE_CDM_NOMENCLATURE).append("]").toString();
	
	
	
	
	// STATE
	public static final String STATE_DESIGN_TEAM_DEFINITION_IN_WORK = PropertyUtil.getSchemaProperty("policy", POLICY_DESIGN_TEAM_DEFINITION, "state_Preliminary");
	public static final String STATE_DESIGN_TEAM_DEFINITION_RELEASED = PropertyUtil.getSchemaProperty("policy", POLICY_DESIGN_TEAM_DEFINITION, "state_Release");
	public static final String STATE_CDM_PART_PRODUCTION_POLICY_RELEASED = PropertyUtil.getSchemaProperty("policy", POLICY_CDM_PART_PRODUCTION_POLICY, "state_Released");
	
	public static final String STATE_CDM_PARTPOLICY_POLICY_PRELIMINARY = PropertyUtil.getSchemaProperty("policy", POLICY_CDM_PART_POLICY, "state_Preliminary");
	public static final String STATE_CDM_PARTPOLICY_POLICY_REVIEW = PropertyUtil.getSchemaProperty("policy", POLICY_CDM_PART_POLICY, "state_Review");
	public static final String STATE_CDM_PARTPOLICY_POLICY_OBSOLETE = PropertyUtil.getSchemaProperty("policy", POLICY_CDM_PART_POLICY, "state_Obsolete");
	public static final String STATE_CDM_PARTPOLICY_POLICY_RELEASE = PropertyUtil.getSchemaProperty("policy", POLICY_CDM_PART_POLICY, "state_Release");

	public static final String STATE_CDM_PARTPOLICY_POLICY_IN_REVIEW = PropertyUtil.getSchemaProperty("policy", POLICY_CDM_PART_POLICY, "state_In_Review");
	
	
	public static final String STATE_CDM_EC_POLICY_IN_WORK = PropertyUtil.getSchemaProperty("policy", POLICY_CDM_EC_POLICY, "state_Preliminary");
	public static final String STATE_CDM_EC_POLICY_IN_REVIEW = PropertyUtil.getSchemaProperty("policy", POLICY_CDM_EC_POLICY, "state_Review");
	public static final String STATE_CDM_EC_POLICY_RELEASED = PropertyUtil.getSchemaProperty("policy", POLICY_CDM_EC_POLICY, "state_Release");
	public static final String STATE_CDM_EC_POLICY_CANCELLED = PropertyUtil.getSchemaProperty("policy", POLICY_CDM_EC_POLICY, "state_Obsolete");

	
	// ETC
    public static final String VAULT_ESERVICE_PRODUCTION = "eService Production";
    public static final String VAULT_VPLM = "vplm";
    
    /*
	 * Text Constants
	 */
	public static final String TEXT_GENERAL_LIBRARY    = "GeneralLibrary";
	public static final String TEXT_DOCUMENT_LIBRARY   = "DocumentLibrary";
	public static final String TEXT_PART_LIBRARY       = "PartLibrary";
	public static final String TEXT_COMMON_CODE        = "CommonCode";
	public static final String TEXT_PROJECT_GROUP      = "ProjectGroup";
	public static final String TEXT_PROJECT_TYPE       = "ProjectType";
	public static final String TEXT_PRODUCT_TYPE       = "ProductType";
	public static final String TEXT_PROJECTNAME        = "ProjectName";
	public static final String TEXT_PROJECT			   = "Project";
	public static final String TEXT_PROJECTOID		   = "ProjectOID";
	public static final String TEXT_TITLE		   	   = "Title";
	public static final String TEXT_WORKSPACE          = "Workspace";
	public static final String TEXT_IS_UNDERBAR_LEAF   = "IS_LEAF";
	public static final String TEXT_HASCHILD           = "hasChild";
	public static final String TEXT_OBJECTID           = "objectId";
	public static final String TEXT_PROTO              = "Proto";
	public static final String TEXT_PRODUCTION         = "Production";
	public static final String TEXT_PRODUCTTYPE		   = "Product Type";
	public static final String TEXT_PRODUCTNAME		   = "Product Name";
	public static final String TEXT_CUSTOMER		   = "Customer";
	public static final String TEXT_VEHICLE			   = "Vehicle";
	
	public static final String TEXT_TYPEACTUAL         = "TypeActual";
	public static final String TEXT_CURRENT            = "current";
	public static final String TEXT_CODE         	   = "Code";
	public static final String TEXT_POLICY         	   = "Policy";
	public static final String TEXT_CDMONLY        	   = "CDM Only";
	public static final String TEXT_DESCRIPTION        = "Description";
	public static final String TEXT_SUCCESS        	   = "Success";
	public static final String TEXT_FAIL        	   = "Fail";
	public static final String TEXT_OBSOLETE		   = "OBSOLETE";
	public static final String TEXT_REALEASED          = "Released";
	public static final String TEXT_RELEASE			   = "Release";
	
	
	public static final String TEXT_CDM_SUB_PROJECT_GROUP     = "cdmSubProjectGroup";
	public static final String TEXT_CDM_PROJECT_GROUP_OBJECT  = "cdmProjectGroupObject";
	public static final String TEXT_PART_SPACE_FAMILY         = "Part Family";
	public static final String TEXT_PART                      = "Part";
	public static final String TEXT_DOCUMENT_SPACE_FAMILY     = "Document Family";
	public static final String TEXT_DOCUMENT                  = "Document";
	public static final String TEXT_WORKSPACE_SPACE_VAULT     = "Workspace Vault";
	public static final String TEXT_ENGINEERINGCENTRAL        = "engineeringcentral";
	public static final String TEXT_EMX_ENGINEERING_CENTRAL_STRING_RESOURCE = "emxEngineeringCentralStringResource";
	
	public static final String TEXT_KINDOFDOCUMENT = "type.kindof[Document]";
	
	public static final String TEXT_CDMPARTEBOMRELATIONATTRIBUTEUOM 		 = "cdmPartEBOMRelationAttributeUOM";
	public static final String TEXT_CDMPARTEBOMRELATIONATTRIBUTEECONUMBERM 	 = "cdmPartEBOMRelationAttributeECONumberM";
	public static final String TEXT_QUANTITY								 = "Quantity";
	public static final String TEXT_FINDNUMBER								 = "Find Number";
	
	public static final String TEXT_CDM_EC								= "cdmEC";
	public static final String TEXT_NOTIFY_IN_BACKGROUND				= "notifyInBackground";
	
}
