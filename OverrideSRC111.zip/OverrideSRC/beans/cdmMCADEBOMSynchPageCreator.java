/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.matrixone.MCADIntegration.server.beans;

import java.util.Hashtable;

import matrix.db.Context;

public class cdmMCADEBOMSynchPageCreator extends MCADEBOMSynchPageCreator {

	public cdmMCADEBOMSynchPageCreator(Context paramContext, MCADIntegrationSessionData paramMCADIntegrationSessionData, String paramString1, String paramString2) throws Exception {
		super(paramContext, paramMCADIntegrationSessionData, paramString1, paramString2);
	}

	@SuppressWarnings("unchecked")
	protected void getExtendedNodeData(Hashtable paramHashtable, String paramString, String paramString2) {

		try {
			String actionStatus = (String) paramHashtable.get("ActionStatus");
			String design = (String) paramHashtable.get("Design");
			String ebomCurrent = (String) paramHashtable.get("ebomCurrent") == null ? "" : (String) paramHashtable.get("ebomCurrent");
			String ecoName = (String) paramHashtable.get("ecoName") == null ? "" : (String) paramHashtable.get("ecoName");
			String ecoId = (String) paramHashtable.get("ecoId") == null ? "" : (String) paramHashtable.get("ecoId");
			String connectECO = (String) paramHashtable.get("connectECO") == null ? "" : (String) paramHashtable.get("connectECO");
			String projectId = (String) paramHashtable.get("projectId") == null ? "" : (String) paramHashtable.get("projectId");
			String duplicatePart = (String) paramHashtable.get("duplicatePart") == null ? "" : (String) paramHashtable.get("duplicatePart");
			String revisePart = (String) paramHashtable.get("revisePart") == null ? "" : (String) paramHashtable.get("revisePart");
			String existBlockCode = (String) paramHashtable.get("existBlockCode") == null ? "" : (String) paramHashtable.get("existBlockCode");
			String has3DPart = (String) paramHashtable.get("has3DPart") == null ? "" : (String) paramHashtable.get("has3DPart");
			String ebomPartPhase = (String) paramHashtable.get("ebomPartPhase") == null ? "" : (String) paramHashtable.get("ebomPartPhase");
	
	
			Hashtable objectNodeMap = this.ebomSynchPageObject.getObjectNodeData(paramString);
	
			Hashtable valuesMap = (Hashtable) objectNodeMap.get("Values");
			Hashtable cellTypesMap = (Hashtable) objectNodeMap.get("CellTypes");
			
			// [B] Modified by JTKIM 2016-09-27
			// EBOM Sync Validation Add
			boolean isCheck = false;
			String validationMsg = "";
			// New Part 확인. OrCAD 일 경우 EBOM Part가 없을 경우 Sync 불가.
			if ("New".equals(actionStatus) && isValidationOrCADType(design)) {
				isCheck = true;
				validationMsg = this.integSessionData.getStringResource("mcadIntegration.Client.Message.EBOMPartDoseNotExist") + "\n";
			}
	
			if (isCheck == false && isValidationCurrent(ebomCurrent) && isValidationOrCADType(design)) {
				isCheck = true;
				validationMsg = validationMsg + this.integSessionData.getStringResource("mcadIntegration.Client.Message.EBOMPartThatIsNotInReleasedState") + "\n";
			}
	
			if ("true".equals(duplicatePart) && "true".equals(revisePart)) {
				isCheck = true;
				validationMsg = validationMsg + this.integSessionData.getStringResource("mcadIntegration.Client.Message.EBOMPartRevise") + "\n";
			}

			if ("true".equals(duplicatePart) && "true".equals(revisePart) == false) {
				isCheck = true;
				validationMsg = validationMsg + this.integSessionData.getStringResource("mcadIntegration.Client.Message.EBOMPartDuplicate") + "\n";
			}

			if ("false".equals(existBlockCode)) {
				isCheck = true;
				validationMsg = validationMsg + this.integSessionData.getStringResource("mcadIntegration.Client.Message.BlockCode") + "\n";
			}
			
			if (isCheck) {
				((Hashtable) valuesMap).put("Validation", "Error");
			} else {
				((Hashtable) valuesMap).put("Validation", "OK");
			}
			((Hashtable) valuesMap).put("Error Reason", validationMsg);
			
			((Hashtable) valuesMap).put("PartCurrent", ebomCurrent);
			((Hashtable) valuesMap).put("ECONO", ecoName);
			((Hashtable) valuesMap).put("ECOID", ecoId);
			((Hashtable) valuesMap).put("connectECO", connectECO);
			((Hashtable) valuesMap).put("PROJECTID", projectId);
			((Hashtable) valuesMap).put("has3DPart", has3DPart);
			((Hashtable) valuesMap).put("ebomPartPhase", ebomPartPhase);
			// [E] Modified by JTKIM 2016-09-27
	
			cellTypesMap.put("ECONO", "Label");
			cellTypesMap.put("PartCurrent", "Label");
			cellTypesMap.put("Validation", "Label");
			cellTypesMap.put("Error Reason", "Label");
			cellTypesMap.put("connectECO", "Hidden");
			cellTypesMap.put("ECOID", "Hidden");
			cellTypesMap.put("PROJECTID", "Hidden");
			cellTypesMap.put("has3DPart", "Hidden");
			cellTypesMap.put("ebomPartPhase", "Hidden");
	
	//		Hashtable localHashtable4 = new Hashtable(4);
	//		localHashtable4.put("Values", valuesMap);
	//		localHashtable4.put("CellTypes", cellTypesMap);
	//		localHashtable4.put("Options", localHashtable3);
	//
	//		this.ebomSynchPageObject.addObjectNodeData(str1, localHashtable4);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private boolean isValidationCurrent(String ebomCurrent) throws Exception {

		if ("Release".equals(ebomCurrent)) return false;

		return true;
	}

	private boolean isValidationOrCADType(String sType) throws Exception {

		if ("cdmOrCADPart".equals(sType)) return true;

		return false;
	}
}