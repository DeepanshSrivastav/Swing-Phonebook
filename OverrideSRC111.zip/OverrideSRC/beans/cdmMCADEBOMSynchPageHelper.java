/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.matrixone.MCADIntegration.server.beans;

import java.util.HashSet;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerException;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectList;
import matrix.db.Context;
import matrix.db.State;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class cdmMCADEBOMSynchPageHelper extends MCADEBOMSynchPageHelper {
	public cdmMCADEBOMSynchPageHelper(Context paramContext, MCADIntegrationSessionData paramMCADIntegrationSessionData, String paramString1, String paramString2) throws Exception {
		super(paramContext, paramMCADIntegrationSessionData, paramString1, paramString2);
		this.integSessionData = paramMCADIntegrationSessionData;
		this.integrationName = paramString1;
		this.logger = paramMCADIntegrationSessionData.getLogger();
		this.util = new MCADMxUtil(paramContext, this.logger, paramMCADIntegrationSessionData.getResourceBundle(), paramMCADIntegrationSessionData.getGlobalCache());
		this.configUIUtil = new IEFConfigUIUtil(paramContext, paramMCADIntegrationSessionData, paramString1);

		this.globalConfigObject = paramMCADIntegrationSessionData.getGlobalConfigObject(paramString1, paramContext);
		if (this.globalConfigObject == null) {
			this.logger.log("[MCADEBOMSynchPageHelper.MCADEBOMSynchPageHelper] Failed to get Global Config Object", 6);
		}

		this.serverGeneralUtil = new MCADServerGeneralUtil(paramContext, paramMCADIntegrationSessionData, paramString1);

		this.cadTypeAttrActualName = MCADServerGeneralUtil.getActualNameForAEFData(paramContext, "attribute_CADType");
		this.excludeFromBOMAttrActualName = MCADServerGeneralUtil.getActualNameForAEFData(paramContext, "attribute_IEF-ExcludeFromBOM");
		this.defaultCustomTable = paramString2;
		this.selectedCues = this.configUIUtil.getSelectedCues(paramContext);
		this.styleClassTable = new Hashtable();

		String str1 = this.globalConfigObject.getEBOMRegistryTNR();
		StringTokenizer localStringTokenizer = new StringTokenizer(str1, "|");
		if (localStringTokenizer.countTokens() >= 3) {
			String str2 = (String) localStringTokenizer.nextElement();
			String str3 = (String) localStringTokenizer.nextElement();
			String str4 = (String) localStringTokenizer.nextElement();

			this.ebomConfigObject = new IEFEBOMConfigObject(paramContext, str2, str3, str4);
		}

		this.confAttrPartNumber = this.ebomConfigObject.getConfigAttributeValue(IEFEBOMConfigObject.ATTR_PART_NUMBER);
		this.confAttrPartSeries = this.ebomConfigObject.getConfigAttributeValue(IEFEBOMConfigObject.ATTR_PART_SERIES);
	}

	private String integrationName = null;
	private IEFEBOMConfigObject ebomConfigObject = null;

	private MCADServerGeneralUtil serverGeneralUtil = null;
	private IEFConfigUIUtil configUIUtil = null;
	private String cadTypeAttrActualName = "";

	private String excludeFromBOMAttrActualName = "";
	private String defaultCustomTable = null;
	private String selectedCues = null;
	private Hashtable styleClassTable = null;
	private int cueIncrementor = 0;

	private Hashtable instIdFamIdTable = new Hashtable();
	private Hashtable famIdEBOMNameTable = new Hashtable();
	private Hashtable busIdAutoNameTable = new Hashtable();
	private Hashtable drawingAssociatedDesignNameTable = new Hashtable();


	@SuppressWarnings("unchecked")
	public Hashtable getNodeMatrixData(Context paramContext, String paramString) throws Exception {
		Hashtable localHashtable = new Hashtable();
		int i = 0;
		try {
			BusinessObject localBusinessObject1 = new BusinessObject(paramString);
			localBusinessObject1.open(paramContext);

			String str1 = localBusinessObject1.getTypeName();
			String str2 = localBusinessObject1.getName();
			String str3 = localBusinessObject1.getRevision();
			String str4 = this.util.getAttributeForBO(paramContext, paramString, this.cadTypeAttrActualName);
			String str5 = localBusinessObject1.getDescription(paramContext);
			Object localObject1 = "";
			String str6 = "--";
			String str7 = "";
			String str8 = null;
			String str9 = "--";
			String str10 = "--";
			String str11 = "";
			String str12 = "";
			String str13 = "";
			String str14 = this.util.getAttributeForBO(paramContext, paramString, this.excludeFromBOMAttrActualName);
			String str15 = "";
			String str16 = null;
			String ebomPartCurrent = ""; // modified by jtkim
			String ecoName = ""; // modified by jtkim
			String ecoId = ""; // modified by jtkim
			String projectId = ""; // modified by jtkim
			String ebomPartPhase = ""; // modified by jtkim
			String ebomPartType = ""; // modified by jtkim

			// [B] modify by jtkim 2016-12-26
			String has3DPart = "";
			if ("CATDrawing".equals(str1)) {
				DomainObject catiaObj = DomainObject.newInstance(paramContext, localBusinessObject1);
				has3DPart = catiaObj.getInfo(paramContext, "to[Associated Drawing]");
				ebomPartType = catiaObj.getInfo(paramContext, "attribute[IEF-EBOMSync-PartTypeAttribute]");
			}
			// [E] modify by jtkim 2016-12-26
			BusinessObject localBusinessObject2 = new BusinessObject();

			localBusinessObject2 = localBusinessObject1;
			localBusinessObject2.open(paramContext);
			str8 = localBusinessObject2.getTypeName();
			str9 = localBusinessObject2.getRevision();
			str11 = localBusinessObject2.getLocker(paramContext).getName();
			str13 = localBusinessObject2.getPolicy(paramContext).getName();
			localBusinessObject2.close(paramContext);

			String str17 = this.util.getAttributeForBO(paramContext, localBusinessObject2, MCADMxUtil.getActualNameForAEFData(paramContext, "attribute_Title"));

			if (null == str17) {
				str17 = "";
			}
			State localState = this.util.getCurrentState(paramContext, localBusinessObject2);
			String str18 = localState.getName();

			String str19 = "unlocked";
			if (!(str11.equals(""))) {
				str19 = "locked";
			}

 			localHashtable.put("Alert", "false");
			if (this.globalConfigObject.isTypeOfClass(str4, "TYPE_INSTANCE_LIKE")) {
				if (this.instIdFamIdTable.containsKey(paramString)) {
					str15 = (String) this.instIdFamIdTable.get(paramString);
					str16 = this.util.getAttributeForBO(paramContext, str15, MCADMxUtil.getActualNameForAEFData(paramContext, "attribute_IEF-EBOMExpositionMode"));
				} else {
					str15 = this.serverGeneralUtil.getTopLevelFamilyObjectForInstance(paramContext, paramString);
					str16 = this.util.getAttributeForBO(paramContext, str15, MCADMxUtil.getActualNameForAEFData(paramContext, "attribute_IEF-EBOMExpositionMode"));
					if ((this.instIdFamIdTable.containsValue(str15)) && (null != str16) && ("single".equalsIgnoreCase(str16)) && ("false".equalsIgnoreCase(str14))) {
						localHashtable.put("Alert", "true");
					}

					if ((null != str16) && ("single".equalsIgnoreCase(str16)) && ("false".equalsIgnoreCase(str14))) {
						Object localObject2 = new BusinessObject(str15);
						str5 = ((BusinessObject) localObject2).getDescription(paramContext);
					}
					this.instIdFamIdTable.put(paramString, str15);
				}
			}
			Object localObject3;
			if ("false".equalsIgnoreCase(str14)) {
				Object localObject2 = "true";
				Vector localVector = this.ebomConfigObject.getAttributeAsVector(IEFEBOMConfigObject.ATTR_INVALID_TYPES, "\n");

				localObject3 = getRelatedPartsList(paramContext, localBusinessObject1);

				Object localObject4;
				Object localObject6;
				Object localObject7;
				if ((localObject3 != null) && (((BusinessObjectList) localObject3).size() > 0)) {
					localObject4 = new StringBuffer();

					DomainObject tempObj = null;
					
					for (int k = 0; k < ((BusinessObjectList) localObject3).size(); ++k) {

						localObject6 = ((BusinessObjectList) localObject3).getElement(k);
						localObject7 = ((BusinessObject) localObject6).getName();

						tempObj = new DomainObject((BusinessObject) localObject6);
						if (tempObj.isLastRevision(paramContext) == false) continue;
						
//						if (k != 0) {
						if (((StringBuffer) localObject4).length() > 0) {
							((StringBuffer) localObject4).append(",");
						}

						((StringBuffer) localObject4).append((String) localObject7);
						// [B] Modify by jtkim 2016-10-12
						// EBOM Part Current Add
						if (localObject6 != null) {
							State ebomPartStates = this.util.getCurrentState(paramContext, (BusinessObject) localObject6);
							if (ebomPartCurrent == null || ebomPartCurrent == "") {
								ebomPartCurrent = ebomPartStates.getName();
							} else {
								ebomPartCurrent = ebomPartCurrent + "," + ebomPartStates.getName();
							}

							StringList busSelect = new StringList();
							busSelect.add("to[Affected Item].from.name");
							busSelect.add("to[Affected Item].from.id");
							busSelect.add("to[cdmPartRelationProject].from.id");
							busSelect.add("attribute[cdmPartPhase]");
							

							Map infoMap = tempObj.getInfo(paramContext, busSelect);

							ebomPartPhase = (String) infoMap.get("attribute[cdmPartPhase]");
							if (ebomPartPhase == null) ebomPartPhase = "";

							ecoName = (String) infoMap.get("to[Affected Item].from.name");
							if (ecoName == null) ecoName = "";

							ecoId = (String) infoMap.get("to[Affected Item].from.id");
							if (ecoId == null) ecoId = "";

							projectId = (String) infoMap.get("to[cdmPartRelationProject].from.id");
							if (projectId == null) projectId = "";
						}
						// [E] Modify by jtkim 2016-10-12
					}

					localObject1 = ((StringBuffer) localObject4).toString();

					Object localObject5 = ((BusinessObjectList) localObject3).getElement(0);
					str7 = ((BusinessObject) localObject5).getTypeName();
					str6 = "AttributeUpdate";
					i = 1;
				}

				if (i == 0) {
					localObject4 = this.serverGeneralUtil.getRelatedEBOMPart(paramContext, paramString, str4, (String) localObject2, this.ebomConfigObject, false);
					if ((localObject4 != null) && (!("".equals(localObject4)))) {
						Object localObject5 = new BusinessObject((String) localObject4);
						((BusinessObject) localObject5).open(paramContext);
						localObject1 = ((BusinessObject) localObject5).getName();
						str7 = ((BusinessObject) localObject5).getTypeName();
						((BusinessObject) localObject5).close(paramContext);

						if (this.confAttrPartNumber.equalsIgnoreCase("AUTONAME")) {
							this.busIdAutoNameTable.put(paramString, localObject1);
						}

						// [B] Modify by jtkim 2017-01-02
						DomainObject tempObj = new DomainObject((BusinessObject) localObject4);
						StringList busSelect = new StringList();
						busSelect.add("to[Affected Item].from.name");
						busSelect.add("to[Affected Item].from.id");
						busSelect.add("to[cdmPartRelationProject].from.id");
						busSelect.add("attribute[cdmPartPhase]");

						Map infoMap = tempObj.getInfo(paramContext, busSelect);

						ebomPartPhase = (String) infoMap.get("attribute[cdmPartPhase]");
						if (ebomPartPhase == null) ebomPartPhase = "";

						ecoName = (String) infoMap.get("to[Affected Item].from.name");
						if (ecoName == null) ecoName = "";

						ecoId = (String) infoMap.get("to[Affected Item].from.id");
						if (ecoId == null) ecoId = "";
						// [B] Modify by jtkim 2017-01-02

						str6 = "FullUpdate";
						i = 1;
					}
				}

				int j = 0;
				Object localObject5 = new HashSet();

				if (i == 0) {
					if ((str4 != null) && (!("".equals(str4))) && (((str4.equalsIgnoreCase("drawing")) || (str4.equalsIgnoreCase("presentation"))))) {
						localObject6 = new StringBuffer();
						localObject7 = new HashSet();

						((HashSet) localObject7).add(paramString);

						localObject5 = this.serverGeneralUtil.getDrawingEBOMNameAndDesignIds(paramContext, localBusinessObject1, (HashSet) localObject7, (StringBuffer) localObject6);

						if (!(((StringBuffer) localObject6).toString().equals(""))) {
							localObject1 = ((StringBuffer) localObject6).toString();
						} else {
							localObject1 = localBusinessObject1.getName();
						}

						j = 1;
					}

					str7 = this.ebomConfigObject.getConfigAttributeValue(IEFEBOMConfigObject.ATTR_DEFAULT_NEW_PART_TYPE);

					// [B] Modify by jtkim 2016-10-21
					// [SYNC-003] Change type if orcad.
					if (str1.equals("cdmOrCADPart") || str1.equals("cdmOrCADProduct")) str7 = "cdmElectronicPart";
					// [E] Modify by jtkim 2016-10-21

					if (this.confAttrPartNumber.equalsIgnoreCase("CADMODELNAME")) {
						if (j == 0) {
							if (this.globalConfigObject.isTypeOfClass(str4, "TYPE_INSTANCE_LIKE")) {
								if ((null != str16) && ("single".equalsIgnoreCase(str16))) {
									localObject6 = new BusinessObject(str15);
									((BusinessObject) localObject6).open(paramContext);
									localObject7 = ((BusinessObject) localObject6).getName();
									this.busIdAutoNameTable.put(paramString, localObject7);
									((BusinessObject) localObject6).close(paramContext);
									localObject1 = localObject7;
								} else {
									localObject1 = str2;
								}
							} else
								localObject1 = str2;
						}

						// [B] Modify by jtkim 2016-11-02
						// [SYNC-004] If "_" exists in Name, it searches for EBOM Part only before "_".
						if (((String) localObject1).indexOf("-") > -1) {
							localObject1 = ((String) localObject1).substring(0, ((String) localObject1).indexOf("-"));
						}
						// [E] Modify by jtkim 2016-11-02

						localObject6 = getEBOMPart(paramContext, localBusinessObject1, this.ebomConfigObject, (String) localObject1);

						if (localObject6 != null) {
							str6 = "FullUpdate";

							// [B] Modify by jtkim 2016-11-02
							// [SYNC-001] If the ebom part is connected to the same catia type, Error
							//localObject6
							DomainObject obj = new DomainObject((BusinessObject) localObject6);
							//str1
							StringList partSpecTypeList = obj.getInfoList(paramContext, "from[Part Specification].to.type");
							StringList partSpecNameList = obj.getInfoList(paramContext, "from[Part Specification].to.name");
							StringList busSelect = new StringList();
//							busSelect.add("attribute[cdmPartName]");
//							busSelect.add("from[Part Specification].to.name");
//							Map ebomPartInfo = obj.getInfo(paramContext, busSelect);

//							Object typeObj = ebomPartInfo.get("from[Part Specification].to.type");

							String partSpecType = "";
							String partSpecName = "";
							int partSpecIdx = 0;
							for (Iterator itr = partSpecTypeList.listIterator(); itr.hasNext();) {
								partSpecType = (String) itr.next();
								if (str1.equals(partSpecType)) {
									localHashtable.put("duplicatePart", "true");

									partSpecName = (String) partSpecNameList.get(partSpecIdx);
									if (str2 != null && str2.equals(partSpecName)) localHashtable.put("revisePart", "true");

									break;
								}
								partSpecIdx++;
							}

							// [B] Modify by jtkim 2017-01-02
							busSelect = new StringList();
							busSelect.add("to[Affected Item].from.name");
							busSelect.add("to[Affected Item].from.id");
							busSelect.add("to[cdmPartRelationProject].from.id");
							busSelect.add("attribute[cdmPartPhase]");

							Map infoMap = obj.getInfo(paramContext, busSelect);

							ebomPartPhase = (String) infoMap.get("attribute[cdmPartPhase]");
							if (ebomPartPhase == null) ebomPartPhase = "";

							ecoName = (String) infoMap.get("to[Affected Item].from.name");
							if (ecoName == null) ecoName = "";

							ecoId = (String) infoMap.get("to[Affected Item].from.id");
							if (ecoId == null) ecoId = "";
							// [B] Modify by jtkim 2017-01-02

							// [E] Modify by jtkim 2016-11-02

						} else {
							str6 = "New";
						}

						// [B] Modify by jtkim 2016-10-12
						// [SYNC-002] Add ebom part status
						if (localObject6 != null) {
							State ebomPartStates = this.util.getCurrentState(paramContext, (BusinessObject) localObject6);
							ebomPartCurrent = ebomPartStates.getName();
						}
						// [E] Modify by jtkim 2016-10-12

					}

					if (this.confAttrPartNumber.equalsIgnoreCase("AUTONAME")) {
						if (j == 0) {
							if (this.globalConfigObject.isTypeOfClass(str4, "TYPE_INSTANCE_LIKE")) {
								if ((null != str16) && ("single".equalsIgnoreCase(str16))) {
									if (this.famIdEBOMNameTable.containsKey(str15)) {
										localObject1 = (String) this.famIdEBOMNameTable.get(str15);
										this.busIdAutoNameTable.put(paramString, localObject1);
									} else {
										localObject6 = this.util.getAutonames(paramContext, "type_Part", this.confAttrPartSeries, 1);
										localObject1 = (String) ((Vector) localObject6).get(0);
										this.busIdAutoNameTable.put(paramString, localObject1);
										this.famIdEBOMNameTable.put(str15, localObject1);
									}
								} else {
									localObject6 = this.util.getAutonames(paramContext, "type_Part", this.confAttrPartSeries, 1);
									localObject1 = (String) ((Vector) localObject6).get(0);
									this.busIdAutoNameTable.put(paramString, localObject1);
								}
							} else {
								localObject6 = this.util.getAutonames(paramContext, "type_Part", this.confAttrPartSeries, 1);
								localObject1 = (String) ((Vector) localObject6).get(0);
								this.busIdAutoNameTable.put(paramString, localObject1);
							}

						} else {
							this.busIdAutoNameTable.put(paramString, "");
						}

						str6 = "New";
					}

				}

				if (j != 0) {
					this.drawingAssociatedDesignNameTable.put(paramString, localObject5);
				}

				if (localVector.contains(str1)) {
					localObject1 = "";
					str7 = "";
					str6 = "-";
				}

			}

			if ((this.globalConfigObject.isTypeOfClass(str4, "TYPE_INSTANCE_LIKE")) && ("single".equalsIgnoreCase(str16)) && ("false".equalsIgnoreCase(str14))) {
				if (("true".equals(localHashtable.get("Alert"))) && (str6.equals("AttributeUpdate"))) {
					localHashtable.put("Alert", "false");
				}

				if ((!("".equals(localObject1))) && ("false".equals(localHashtable.get("Alert"))) && (str6.equals("FullUpdate"))) {
					String localObject2 = isOtherInstanceAlreadySynched(paramContext, (String) localObject1, localBusinessObject1, str2);
					localHashtable.put("Alert", localObject2);
				}

			}

			localHashtable.put("BusinessObjectId", paramString);
			localHashtable.put("Design", str8);
			localHashtable.put("Name", str2);
			localHashtable.put("Revision", str9);
			localHashtable.put("Version", str10);
  			localHashtable.put("EBOM", localObject1);
			localHashtable.put("ActionStatus", str2.startsWith("_") ? "NonBOMPart" : str6);
			localHashtable.put("Description", str5);
			localHashtable.put("State", str18);
			localHashtable.put("PartType", ebomPartType == "" ? str7 : ebomPartType);
			localHashtable.put("LockStatus", str19);
			localHashtable.put("CADType", str4);
			localHashtable.put("Policy", str13);
			localHashtable.put("Title", str17);
			localHashtable.put("ExcludeFromBOM", (str14 == null) ? "" : str14);

			localHashtable.put("ebomCurrent", ebomPartCurrent); // Modify by jtkim 2016-10-12
			localHashtable.put("ecoName", ecoName); // Modify by jtkim 2016-10-12
			localHashtable.put("ecoId", ecoId); // Modify by jtkim 2016-10-12
			localHashtable.put("connectECO", ecoId == "" ? "false" : "true"); // Modify by jtkim 2016-10-17
			localHashtable.put("projectId", projectId); // Modify by jtkim 2016-10-17
			localHashtable.put("isCheckDrawingNo", "true");
			localHashtable.put("has3DPart", has3DPart);
			localHashtable.put("ebomPartPhase", ebomPartPhase);

			// [B] modify by jtkim 2016-12-15
			// [SYNC-005] Add Validation if Part Family exists.
			if (str1.equals("cdmOrCADPart") || str1.equals("cdmOrCADProduct")) {
				localHashtable.put("existBlockCode", "true");
			} else {
				String mqlResult = "";
				if (str2.startsWith("_") == false) {
					String blockCode = str2.substring(0, 5);
					mqlResult = MqlUtil.mqlCommand(paramContext, "temp query bus 'Part Family' * * where attribute[cdmPartFamilyBlockCodeName]~='" + blockCode + "*' select id dump;");
				}
				localHashtable.put("existBlockCode", cdmStringUtil.isEmpty(mqlResult) ? "false" : "true");
			}
			// [E] modify by jtkim 2016-12-15

			Object localObject2 = null;
			Vector localVector = this.configUIUtil.getCustomViewData(paramString, "", this.defaultCustomTable, paramContext);
			if ((this.selectedCues != null) && (!("".equals(this.selectedCues)))) {
				localObject3 = this.configUIUtil.getStyle(paramContext, this.selectedCues, paramString);
				if ((localObject3 != null) && (!("".equals(localObject3)))) {
					if (this.styleClassTable.containsKey(localObject3)) {
						localObject2 = (String) this.styleClassTable.get(localObject3);
					} else {
						localObject2 = "cueClass" + this.cueIncrementor;
						this.styleClassTable.put(localObject3, localObject2);
						this.cueIncrementor += 1;
					}
				}
			}
			localHashtable.put("CustomTable", localVector);
			if (localObject2 != null) {
				localHashtable.put("CUECLASS", localObject2);
			} else {
				localHashtable.put("CUECLASS", "");
			}
			getExtendedNodeMatrixData(paramContext, localBusinessObject1, localHashtable);
			localBusinessObject1.close(paramContext);
		} catch (MatrixException localMatrixException) {
			MCADServerException.createException(localMatrixException.getMessage(), localMatrixException);
		}

		return ((Hashtable) (Hashtable) (Hashtable) (Hashtable) (Hashtable) (Hashtable) (Hashtable) localHashtable);
	}

	private String isOtherInstanceAlreadySynched(Context paramContext, String paramString1, BusinessObject paramBusinessObject, String paramString2) throws Exception {
		String str1 = "false";
		String str2 = paramBusinessObject.getAttributeValues(paramContext, MCADMxUtil.getActualNameForAEFData(paramContext, "attribute_IEF-EBOMSync-PartTypeAttribute")).getValue();
		String str3 = MCADMxUtil.getActualNameForAEFData(paramContext, "relationship_PartSpecification");
		boolean bool = false;
		if (str2.equals("")) {
			str2 = this.ebomConfigObject.getConfigAttributeValue(IEFEBOMConfigObject.ATTR_DEFAULT_NEW_PART_TYPE);
		}

		if (str2 == null || str2.equals("")) {
			MCADServerException.createException(this.integSessionData.getStringResource("mcadIntegration.Server.Message.PartTypeNotApecifiedInEBOMRegistry"), (Throwable) null);
		}

		Object localObject = null;

		try {
			String[] localException = new String[] { str2, paramString1, "*", "revisions", "|" };
			String str4 = this.util.executeMQL(paramContext, "temp query bus $1 $2 $3 select $4 dump $5", localException);
			if (str4.startsWith("true")) {
				str4 = str4.substring(5);
				StringTokenizer localStringTokenizer1 = new StringTokenizer(str4, "\n");
				if (localStringTokenizer1.hasMoreTokens()) {
					StringTokenizer localStringTokenizer2 = new StringTokenizer(localStringTokenizer1.nextToken(), "|");
					String str5 = "";
					if (localStringTokenizer2.hasMoreTokens()) {
						str5 = localStringTokenizer2.nextToken();
					}

					String str6 = "";
					if (localStringTokenizer2.hasMoreTokens()) {
						str6 = localStringTokenizer2.nextToken();
					}

					String str7 = "";
					Vector localVector = new Vector();

					while (localStringTokenizer2.hasMoreTokens()) {
						localVector.addElement(localStringTokenizer2.nextToken());
					}

					for (int i = 0; i < localVector.size(); ++i) {
						String str8 = (String) localVector.elementAt(i);
						localException = new String[] { str5, str6, str8, str3, "relationship", "to.name", "|" };
						String str9 = this.util.executeMQL(paramContext, "expand bus $1 $2 $3 from relationship $4 select $5 $6 dump $7", localException);
						if (str9.startsWith("true")) {
							str9 = str9.substring(5);
							StringTokenizer localStringTokenizer3 = new StringTokenizer(str9, "\n");

							while (localStringTokenizer3.hasMoreTokens() && localStringTokenizer3.hasMoreTokens()) {
								String str10 = localStringTokenizer3.nextToken();
								StringTokenizer localStringTokenizer4 = new StringTokenizer(str10, "|");
								String str11 = "";
								if (localStringTokenizer4.countTokens() == 7) {
									localStringTokenizer4.nextToken();
									localStringTokenizer4.nextToken();
									localStringTokenizer4.nextToken();
									String str12 = localStringTokenizer4.nextToken();
									bool = this.serverGeneralUtil.isDrawingLike(paramContext, str12);
									localStringTokenizer4.nextToken();
									localStringTokenizer4.nextToken();
									str11 = localStringTokenizer4.nextToken();
								}

								if (!"".equals(str11) && !str11.equals(paramString2) && !bool) {
									str1 = "true";
									break;
								}
							}
						}
					}
				}
			}
		} catch (Exception arg25) {
			MCADServerException.createException(arg25.getMessage(), arg25);
		}

		return str1;
	}

	protected void getExtendedTableHeaderData(Vector paramVector) {
		Hashtable localHashtable1 = new Hashtable(6);
		localHashtable1.put("ColumnID", "ECONO");
		localHashtable1.put("ColumnName", "ECO No.");
		localHashtable1.put("ColumnWidth", MCADIntegrationSessionData.getPropertyValue("mcadIntegration.Server.ColumnName.PartType"));
		paramVector.addElement(localHashtable1);
		
		Hashtable localHashtable2 = new Hashtable(6);
		localHashtable2.put("ColumnID", "PartCurrent");
		localHashtable2.put("ColumnName", "EBOM Part State");
		localHashtable2.put("ColumnWidth", MCADIntegrationSessionData.getPropertyValue("mcadIntegration.Server.ColumnName.PartType"));
		paramVector.addElement(localHashtable2);
		
		Hashtable localHashtable3 = new Hashtable(6);
		localHashtable3.put("ColumnID", "Validation");
		localHashtable3.put("ColumnName", "Validation");
		localHashtable3.put("ColumnWidth", MCADIntegrationSessionData.getPropertyValue("mcadIntegration.Server.ColumnName.PartType"));
		paramVector.addElement(localHashtable3);
		
		Hashtable localHashtable4 = new Hashtable(6);
		localHashtable4.put("ColumnID", "Error Reason");
		localHashtable4.put("ColumnName", "Error Reason");
		localHashtable4.put("ColumnWidth", MCADIntegrationSessionData.getPropertyValue("mcadIntegration.Server.ColumnName.PartType"));
		paramVector.addElement(localHashtable4);
	}
	
	public BusinessObject getEBOMPart(Context paramContext, BusinessObject paramBusinessObject, IEFEBOMConfigObject paramIEFEBOMConfigObject, String paramString) throws Exception {
		BusinessObject localBusinessObject = null;
		this.MATCHING_PART_RULE = paramIEFEBOMConfigObject.getConfigAttributeValue(IEFEBOMConfigObject.ATTR_PART_MATCHING_RULE);
		this.PART_RELEASE_STATE = paramIEFEBOMConfigObject.getConfigAttributeValue(IEFEBOMConfigObject.ATTR_RELEASE_PART_STATE);
		String str = paramBusinessObject.getAttributeValues(paramContext, MCADMxUtil.getActualNameForAEFData(paramContext, "attribute_IEF-EBOMSync-PartTypeAttribute")).getValue();

		if (str.equals("")) {
			str = paramIEFEBOMConfigObject.getConfigAttributeValue(IEFEBOMConfigObject.ATTR_DEFAULT_NEW_PART_TYPE);
		}
		if ((str == null) || (str.equals(""))) {
			MCADServerException.createException(this.integSessionData.getStringResource("mcadIntegration.Server.Message.PartTypeNotApecifiedInEBOMRegistry"), null);
		}
		localBusinessObject = this.util.getPartRevisionForRule(paramContext, str, paramString, this.MATCHING_PART_RULE);

		return localBusinessObject;
	}
}