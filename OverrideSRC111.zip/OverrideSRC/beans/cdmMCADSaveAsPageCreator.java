/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.matrixone.MCADIntegration.server.beans;

import com.matrixone.MCADIntegration.utils.xml.IEFXmlNode;

import matrix.db.Context;

public class cdmMCADSaveAsPageCreator extends MCADSaveAsPageCreator {

	public cdmMCADSaveAsPageCreator(Context paramContext, MCADIntegrationSessionData paramMCADIntegrationSessionData, String paramString, IEFXmlNode paramIEFXmlNode) throws Exception {
		super(paramContext, paramMCADIntegrationSessionData, paramString, paramIEFXmlNode);
		// TODO Auto-generated constructor stub
	}
//	private String busIdsString;
//	protected MCADIntegrationSessionData integSessionData;
//	protected MCADGlobalConfigObject globalConfigObject;
//	protected MCADLocalConfigObject localConfigObject;
//	protected MCADServerLogger logger;
//	private DSCExpandObjectWithSelect objectExpander;
//	private IEFXmlNode saveAsDetailsNode;
//	protected IEFSaveAsPage saveAsPageObject;
//	private MCADSaveAsPageHelper saveAsPageHelper;
//	private MCADSaveAsPageViews pageViews;
//	private MCADMxUtil util;
//	private MCADServerGeneralUtil serverGeneralUtil;
//	private IEFConfigUIUtil configUIUtil;
//	protected String lateralViewProgramName;
//	protected String defaultLateralViewProgramName;
//	protected String defaultLateralViewProgramLabel;
//	protected String lateralViewProgramLabel;
//	protected String verticalViewProgramName;
//	protected String defaultVerticalViewProgramName;
//	protected String defaultVerticalViewProgramLabel;
//	protected String verticalViewProgramLabel;
//	private boolean isRecurssiveLateralView;
//	private Hashtable lateralNavigationProgNameMapping;
//	private String defaultLateralView;
//	private Hashtable verticalNavigationProgNameMapping;
//	private Hashtable cadIDNodeDataTable;
//	private Hashtable sharedPartNameNodeIDsVectorTable;
//	private Hashtable busIDDependentRelIDsTable;
//	private Hashtable busIDNodeMatrixDataTable;
//	private Hashtable extrenalRefParentRevIDsCurrIDTable;
//	private HashSet alreadyExpandedNodesInPath;
//	private Hashtable familyIDInstanceListTable;
//	private Hashtable assignedFolderInfTable;
//	private Hashtable familyNameNameNodeIDsVectorTable;
//	public Hashtable expandedCadObjTreeTableNodesTable;
//	private Context contextForRun;
//	public String defaultCustomTable;
//	private IEFEBOMConfigObject ebomConfigObj;
//	private String operationName;
//	private Hashtable instanceIDExpandedfromFamIDTable;
//	protected HashSet intermediateExpandedNodes;
//	protected boolean isDebugOn;
//	private Vector expandedFamilyIDsVector;
//	private MCADFolderUtil folderUtil;
//	private boolean silentSaveAS;
//	private boolean isCallFromAPI;
//	private HashMap operationsMap;
//	private boolean isAdvancedDuplicate;
//
//	public cdmMCADSaveAsPageCreator(Context paramContext, MCADIntegrationSessionData paramMCADIntegrationSessionData, String paramString, IEFXmlNode paramIEFXmlNode, HashMap paramHashMap, boolean paramBoolean) throws Exception {
//		this(paramContext, paramMCADIntegrationSessionData, paramString, paramIEFXmlNode, true);
//		this.operationsMap = paramHashMap;
//		this.isAdvancedDuplicate = true;
//	}
//
//	public cdmMCADSaveAsPageCreator(Context paramContext, MCADIntegrationSessionData paramMCADIntegrationSessionData, String paramString, IEFXmlNode paramIEFXmlNode) throws Exception {
//		this.busIdsString = "";
//
//		this.integSessionData = null;
//		this.globalConfigObject = null;
//		this.localConfigObject = null;
//		this.logger = null;
//		this.objectExpander = null;
//
//		this.saveAsDetailsNode = null;
//		this.saveAsPageObject = null;
//		this.saveAsPageHelper = null;
//		this.pageViews = null;
//
//		this.util = null;
//		this.serverGeneralUtil = null;
//		this.configUIUtil = null;
//
//		this.lateralViewProgramName = "As-Built";
//		this.defaultLateralViewProgramName = "As-Built";
//		this.defaultLateralViewProgramLabel = "As-Built";
//		this.lateralViewProgramLabel = "As-Built";
//		this.verticalViewProgramName = "None";
//		this.defaultVerticalViewProgramName = "None";
//		this.defaultVerticalViewProgramLabel = "None";
//		this.verticalViewProgramLabel = "None";
//		this.isRecurssiveLateralView = true;
//
//		this.lateralNavigationProgNameMapping = null;
//		this.defaultLateralView = "";
//		this.verticalNavigationProgNameMapping = null;
//
//		this.cadIDNodeDataTable = new Hashtable();
//		this.sharedPartNameNodeIDsVectorTable = new Hashtable();
//		this.busIDDependentRelIDsTable = null;
//		this.busIDNodeMatrixDataTable = new Hashtable();
//		this.extrenalRefParentRevIDsCurrIDTable = new Hashtable();
//		this.alreadyExpandedNodesInPath = new HashSet();
//		this.familyIDInstanceListTable = new Hashtable();
//		this.assignedFolderInfTable = null;
//		this.familyNameNameNodeIDsVectorTable = new Hashtable();
//		this.expandedCadObjTreeTableNodesTable = new Hashtable();
//
//		this.contextForRun = null;
//
//		this.defaultCustomTable = "";
//
//		this.ebomConfigObj = null;
//
//		this.operationName = "";
//
//		this.instanceIDExpandedfromFamIDTable = new Hashtable();
//		this.intermediateExpandedNodes = new HashSet();
//		this.isDebugOn = false;
//		this.expandedFamilyIDsVector = new Vector();
//		this.folderUtil = null;
//		this.silentSaveAS = false;
//		this.isCallFromAPI = false;
//		this.operationsMap = new HashMap();
//		this.isAdvancedDuplicate = false;
//
//		this.integSessionData = paramMCADIntegrationSessionData;
//		this.integrationName = paramString;
//
//		this.globalConfigObject = paramMCADIntegrationSessionData.getGlobalConfigObject(paramString, paramContext);
//		this.localConfigObject = paramMCADIntegrationSessionData.getLocalConfigObject();
//		this.saveAsDetailsNode = paramIEFXmlNode;
//		this.logger = paramMCADIntegrationSessionData.getLogger();
//		this.util = new MCADMxUtil(paramContext, this.logger, paramMCADIntegrationSessionData.getResourceBundle(), paramMCADIntegrationSessionData.getGlobalCache());
//		this.serverGeneralUtil = new MCADServerGeneralUtil(paramContext, paramMCADIntegrationSessionData, paramString);
//		this.configUIUtil = new IEFConfigUIUtil(paramContext, paramMCADIntegrationSessionData, paramString);
//
//		this.objectExpander = new DSCExpandObjectWithSelect(paramContext, paramMCADIntegrationSessionData, paramString);
//		this.extrenalRefParentRevIDsCurrIDTable = this.objectExpander.getExtrenalRefParentRevIDsCurrIDTable();
//
//		this.defaultCustomTable = this.configUIUtil.getDefaultCustomTableName(paramString, "SaveAs", paramMCADIntegrationSessionData);
//		this.pageViews = new MCADSaveAsPageViews(paramContext, paramMCADIntegrationSessionData, paramString);
//		this.isDebugOn = this.localConfigObject.isTurnDebugOn();
//
//		loadViewProgramRegistry(paramContext);
//		this.objectExpander.setViewApplier(this.pageViews);
//
//		String str1 = this.globalConfigObject.getEBOMRegistryTNR();
//		StringTokenizer localStringTokenizer = new StringTokenizer(str1, "|");
//		if (localStringTokenizer.countTokens() >= 3) {
//			String str2 = (String) localStringTokenizer.nextElement();
//			String str3 = (String) localStringTokenizer.nextElement();
//			String str4 = (String) localStringTokenizer.nextElement();
//
//			this.ebomConfigObj = new IEFEBOMConfigObject(paramContext, str2, str3, str4);
//		}
//
//		this.objectExpander.setExpandInactiveInstances(true);
//		this.folderUtil = new MCADFolderUtil(paramContext, paramMCADIntegrationSessionData.getResourceBundle(), paramMCADIntegrationSessionData.getGlobalCache());
//		this.contextForRun = paramContext;
//	}
//
//	public cdmMCADSaveAsPageCreator(Context paramContext, MCADIntegrationSessionData paramMCADIntegrationSessionData, String paramString1, IEFXmlNode paramIEFXmlNode, String paramString2, Hashtable paramHashtable) throws Exception {
//		this.busIdsString = "";
//
//		this.integSessionData = null;
//		this.globalConfigObject = null;
//		this.localConfigObject = null;
//		this.logger = null;
//		this.objectExpander = null;
//
//		this.saveAsDetailsNode = null;
//		this.saveAsPageObject = null;
//		this.saveAsPageHelper = null;
//		this.pageViews = null;
//
//		this.util = null;
//		this.serverGeneralUtil = null;
//		this.configUIUtil = null;
//
//		this.lateralViewProgramName = "As-Built";
//		this.defaultLateralViewProgramName = "As-Built";
//		this.defaultLateralViewProgramLabel = "As-Built";
//		this.lateralViewProgramLabel = "As-Built";
//		this.verticalViewProgramName = "None";
//		this.defaultVerticalViewProgramName = "None";
//		this.defaultVerticalViewProgramLabel = "None";
//		this.verticalViewProgramLabel = "None";
//		this.isRecurssiveLateralView = true;
//
//		this.lateralNavigationProgNameMapping = null;
//		this.defaultLateralView = "";
//		this.verticalNavigationProgNameMapping = null;
//
//		this.cadIDNodeDataTable = new Hashtable();
//		this.sharedPartNameNodeIDsVectorTable = new Hashtable();
//		this.busIDDependentRelIDsTable = null;
//		this.busIDNodeMatrixDataTable = new Hashtable();
//		this.extrenalRefParentRevIDsCurrIDTable = new Hashtable();
//		this.alreadyExpandedNodesInPath = new HashSet();
//		this.familyIDInstanceListTable = new Hashtable();
//		this.assignedFolderInfTable = null;
//		this.familyNameNameNodeIDsVectorTable = new Hashtable();
//		this.expandedCadObjTreeTableNodesTable = new Hashtable();
//
//		this.contextForRun = null;
//
//		this.defaultCustomTable = "";
//
//		this.ebomConfigObj = null;
//
//		this.operationName = "";
//
//		this.instanceIDExpandedfromFamIDTable = new Hashtable();
//		this.intermediateExpandedNodes = new HashSet();
//		this.isDebugOn = false;
//		this.expandedFamilyIDsVector = new Vector();
//		this.folderUtil = null;
//		this.silentSaveAS = false;
//		this.isCallFromAPI = false;
//		this.operationsMap = new HashMap();
//		this.isAdvancedDuplicate = false;
//
//		this.integSessionData = paramMCADIntegrationSessionData;
//		this.integrationName = paramString1;
//		this.localConfigObject = paramMCADIntegrationSessionData.getLocalConfigObject();
//		this.saveAsDetailsNode = paramIEFXmlNode;
//		this.logger = paramMCADIntegrationSessionData.getLogger();
//		this.util = new MCADMxUtil(paramContext, this.logger, paramMCADIntegrationSessionData.getResourceBundle(), paramMCADIntegrationSessionData.getGlobalCache());
//		this.serverGeneralUtil = new MCADServerGeneralUtil(paramContext, paramMCADIntegrationSessionData, paramString1);
//		this.configUIUtil = new IEFConfigUIUtil(paramContext, paramMCADIntegrationSessionData, paramString1);
//		this.globalConfigObject = paramMCADIntegrationSessionData.getGlobalConfigObject(paramString1, paramContext);
//		this.objectExpander = new DSCExpandObjectWithSelect(paramContext, paramMCADIntegrationSessionData, paramString1);
//		this.pageViews = new MCADSaveAsPageViews(paramContext, paramMCADIntegrationSessionData, paramString1);
//		this.isDebugOn = this.localConfigObject.isTurnDebugOn();
//		this.assignedFolderInfTable = paramHashtable;
//
//		if ((paramString2 == null) || ("".equals(paramString2))) {
//			this.defaultCustomTable = this.configUIUtil.getDefaultCustomTableName(paramString1, "SaveAs", paramMCADIntegrationSessionData);
//		} else {
//			this.defaultCustomTable = paramString2;
//		}
//
//		loadViewProgramRegistry(paramContext);
//		this.objectExpander.setViewApplier(this.pageViews);
//
//		String str1 = this.globalConfigObject.getEBOMRegistryTNR();
//		StringTokenizer localStringTokenizer = new StringTokenizer(str1, "|");
//		if (localStringTokenizer.countTokens() >= 3) {
//			String str2 = (String) localStringTokenizer.nextElement();
//			String str3 = (String) localStringTokenizer.nextElement();
//			String str4 = (String) localStringTokenizer.nextElement();
//
//			this.ebomConfigObj = new IEFEBOMConfigObject(paramContext, str2, str3, str4);
//		}
//
//		this.objectExpander.setExpandInactiveInstances(true);
//		this.folderUtil = new MCADFolderUtil(paramContext, paramMCADIntegrationSessionData.getResourceBundle(), paramMCADIntegrationSessionData.getGlobalCache());
//		this.contextForRun = paramContext;
//	}
//
//	public cdmMCADSaveAsPageCreator(Context paramContext, MCADIntegrationSessionData paramMCADIntegrationSessionData, String paramString, IEFXmlNode paramIEFXmlNode, boolean paramBoolean) throws Exception {
//		this.busIdsString = "";
//
//		this.integSessionData = null;
//		this.globalConfigObject = null;
//		this.localConfigObject = null;
//		this.logger = null;
//		this.objectExpander = null;
//
//		this.saveAsDetailsNode = null;
//		this.saveAsPageObject = null;
//		this.saveAsPageHelper = null;
//		this.pageViews = null;
//
//		this.util = null;
//		this.serverGeneralUtil = null;
//		this.configUIUtil = null;
//
//		this.lateralViewProgramName = "As-Built";
//		this.defaultLateralViewProgramName = "As-Built";
//		this.defaultLateralViewProgramLabel = "As-Built";
//		this.lateralViewProgramLabel = "As-Built";
//		this.verticalViewProgramName = "None";
//		this.defaultVerticalViewProgramName = "None";
//		this.defaultVerticalViewProgramLabel = "None";
//		this.verticalViewProgramLabel = "None";
//		this.isRecurssiveLateralView = true;
//
//		this.lateralNavigationProgNameMapping = null;
//		this.defaultLateralView = "";
//		this.verticalNavigationProgNameMapping = null;
//
//		this.cadIDNodeDataTable = new Hashtable();
//		this.sharedPartNameNodeIDsVectorTable = new Hashtable();
//		this.busIDDependentRelIDsTable = null;
//		this.busIDNodeMatrixDataTable = new Hashtable();
//		this.extrenalRefParentRevIDsCurrIDTable = new Hashtable();
//		this.alreadyExpandedNodesInPath = new HashSet();
//		this.familyIDInstanceListTable = new Hashtable();
//		this.assignedFolderInfTable = null;
//		this.familyNameNameNodeIDsVectorTable = new Hashtable();
//		this.expandedCadObjTreeTableNodesTable = new Hashtable();
//
//		this.contextForRun = null;
//
//		this.defaultCustomTable = "";
//
//		this.ebomConfigObj = null;
//
//		this.operationName = "";
//
//		this.instanceIDExpandedfromFamIDTable = new Hashtable();
//		this.intermediateExpandedNodes = new HashSet();
//		this.isDebugOn = false;
//		this.expandedFamilyIDsVector = new Vector();
//		this.folderUtil = null;
//		this.silentSaveAS = false;
//		this.isCallFromAPI = false;
//		this.operationsMap = new HashMap();
//		this.isAdvancedDuplicate = false;
//
//		this.integSessionData = paramMCADIntegrationSessionData;
//		this.integrationName = paramString;
//
//		this.globalConfigObject = paramMCADIntegrationSessionData.getGlobalConfigObject(paramString, paramContext);
//		this.localConfigObject = paramMCADIntegrationSessionData.getLocalConfigObject();
//		this.saveAsDetailsNode = paramIEFXmlNode;
//		this.logger = paramMCADIntegrationSessionData.getLogger();
//		this.util = new MCADMxUtil(paramContext, this.logger, paramMCADIntegrationSessionData.getResourceBundle(), paramMCADIntegrationSessionData.getGlobalCache());
//		this.serverGeneralUtil = new MCADServerGeneralUtil(paramContext, paramMCADIntegrationSessionData, paramString);
//		this.configUIUtil = new IEFConfigUIUtil(paramContext, paramMCADIntegrationSessionData, paramString);
//
//		this.objectExpander = new DSCExpandObjectWithSelect(paramContext, paramMCADIntegrationSessionData, paramString);
//		this.extrenalRefParentRevIDsCurrIDTable = this.objectExpander.getExtrenalRefParentRevIDsCurrIDTable();
//
//		this.defaultCustomTable = this.configUIUtil.getDefaultCustomTableName(paramString, "SaveAs", paramMCADIntegrationSessionData);
//		this.pageViews = new MCADSaveAsPageViews(paramContext, paramMCADIntegrationSessionData, paramString);
//		this.isDebugOn = this.localConfigObject.isTurnDebugOn();
//
//		loadViewProgramRegistry(paramContext);
//		this.objectExpander.setViewApplier(this.pageViews);
//
//		String str1 = this.globalConfigObject.getEBOMRegistryTNR();
//		StringTokenizer localStringTokenizer = new StringTokenizer(str1, "|");
//		if (localStringTokenizer.countTokens() >= 3) {
//			String str2 = (String) localStringTokenizer.nextElement();
//			String str3 = (String) localStringTokenizer.nextElement();
//			String str4 = (String) localStringTokenizer.nextElement();
//
//			this.ebomConfigObj = new IEFEBOMConfigObject(paramContext, str2, str3, str4);
//		}
//
//		this.objectExpander.setExpandInactiveInstances(true);
//		this.folderUtil = new MCADFolderUtil(paramContext, paramMCADIntegrationSessionData.getResourceBundle(), paramMCADIntegrationSessionData.getGlobalCache());
//		this.contextForRun = paramContext;
//		this.silentSaveAS = paramBoolean;
//	}
//
//	public void setIsCallFromAPI(boolean paramBoolean) {
//		this.isCallFromAPI = paramBoolean;
//	}
//
//	public void run() {
//		try {
//			int i = 0;
//			if (!(this.contextForRun.isTransactionActive())) {
//				i = 1;
//				this.util.startReadOnlyTransaction(this.contextForRun);
//			}
//			String str1 = "com.matrixone.MCADIntegration.ui.IEFSaveAsPage";
//			this.saveAsPageObject = ((IEFSaveAsPage) DSCCustomClassFactory.getCustomClassInstance(str1, new String[0], new Object[0], this.integSessionData.getServerRegistry()));
//
//			String[] arrayOfString = new String[3];
//			arrayOfString[0] = "matrix.db.Context";
//			arrayOfString[1] = "com.matrixone.MCADIntegration.server.beans.MCADIntegrationSessionData";
//			arrayOfString[2] = "java.lang.String";
//
//			Object[] arrayOfObject = new Object[3];
//			arrayOfObject[0] = this.contextForRun;
//			arrayOfObject[1] = this.integSessionData;
//			arrayOfObject[2] = this.integrationName;
//
//			if (this.silentSaveAS) {
//				localObject1 = new IEFServerUIObjectHelper(this.integSessionData);
//				this.saveAsPageObject.setListener((IEFUIObjectHelper) localObject1);
//			}
//
//			Object localObject1 = "com.matrixone.MCADIntegration.server.beans.MCADSaveAsPageHelper";
//
//			this.saveAsPageHelper = ((MCADSaveAsPageHelper) DSCCustomClassFactory.getCustomClassInstance((String) localObject1, arrayOfString, arrayOfObject, this.integSessionData.getServerRegistry()));
//
//			if (this.isAdvancedDuplicate) {
//				this.saveAsPageHelper.setAdvancedDuplicateOptions(this.operationsMap);
//			}
//			this.operationName = this.saveAsDetailsNode.getAttribute("operation");
//
//			this.logger.logDebug("[MCADSaveAsPageCreator.run] operationName   : " + this.operationName);
//
//			this.pageViews = new MCADSaveAsPageViews(this.contextForRun, this.integSessionData, this.integrationName);
//
//			this.objectExpander.setViewApplier(this.pageViews);
//			String str2 = this.saveAsDetailsNode.getAttribute("LateralView");
//			if ((null != str2) && (!("".equals(str2)))) {
//				this.lateralViewProgramName = "As-Built";
//				this.lateralViewProgramLabel = "As-Built";
//				this.defaultLateralViewProgramName = "As-Built";
//				this.defaultLateralViewProgramLabel = "As-Built";
//			}
//			if (this.operationName.equalsIgnoreCase("GetSaveAsContent")) {
//				buildData(this.contextForRun);
//			} else if (this.operationName.equalsIgnoreCase("GetSaveAsViewContent")) {
//				buildDataForParticularView(this.contextForRun);
//			} else if (this.operationName.equalsIgnoreCase("GetSaveAsVersionContent")) {
//				buildDataForParticularVersion(this.contextForRun);
//			}
//
//			if (i != 0) {
//				this.util.commitReadOnlyTransaction(this.contextForRun);
//			}
//			this.serverResponse = this.saveAsPageObject;
//			this.isSuccessful = true;
//
//			System.gc();
//		} catch (Throwable localThrowable) {
//			this.isSuccessful = false;
//
//			this.logger.log("[MCADSaveAsPageCreator.run] Failed while creating SaveAs page content. Error :" + localThrowable.getMessage(), 6);
//
//			this.util.abortReadOnlyTransaction(this.contextForRun);
//
//			this.errorMessage = localThrowable.getMessage();
//			this.logger.printStackTrace(localThrowable);
//		} finally {
//			this.isCompleted = true;
//		}
//	}
//
//	public Hashtable getRelationshipColumnValuesTable(String paramString) throws Exception {
//		Hashtable localHashtable = new Hashtable();
//		localHashtable.put("IsLateralNavigationRequired", paramString);
//
//		return localHashtable;
//	}
//
//	public void setAlreadyExpandedNodesForExpandRequest(Context paramContext, String paramString1, String paramString2) {
//		this.alreadyExpandedNodesInPath.clear();
//		Object localObject = null;
//
//		Vector localVector = MCADUtil.getVectorFromString(paramString1, "|");
//		for (int i = 0; i < localVector.size(); ++i) {
//			String str = (String) localVector.elementAt(i);
//			if (str.trim().equals(""))
//				continue;
//			localObject = str;
//			this.alreadyExpandedNodesInPath.add(str);
//			if (this.alreadyExpandedNodesInPath.size() > 1) {
//				setAlreadyExpandedExternalRefData(paramContext, (String) localVector.elementAt(i - 1), str);
//			}
//		}
//
//		if (localObject != null)
//			setAlreadyExpandedExternalRefData(paramContext, localObject, paramString2);
//	}
//
//	private void setAlreadyExpandedExternalRefData(Context paramContext, String paramString1, String paramString2) {
//		try {
//			Vector localVector1 = this.util.getRelationNamesBetweenObjects(paramContext, paramString1, paramString2);
//			for (int i = 0; i < localVector1.size(); ++i) {
//				if (!(this.globalConfigObject.isRelationshipOfClass((String) localVector1.elementAt(i), "ExternalRefereneLike")))
//					continue;
//				Vector localVector2 = new Vector();
//				localVector2.addElement("");
//				this.serverGeneralUtil.storeConflictingParentIDs(paramContext, paramString1, localVector2, this.extrenalRefParentRevIDsCurrIDTable);
//				break;
//			}
//		} catch (Exception localException) {
//		}
//	}
//
//	private void buildData(Context paramContext) throws Exception {
//		IEFXmlNodeImpl localIEFXmlNodeImpl = this.saveAsDetailsNode.getChildByName("cadobjectlist");
//
//		if (this.localConfigObject.isTurnDebugOn()) {
//			this.logger.logDebug("[MCADSaveAsPageCreator.buildData] cadObjectListNode : " + localIEFXmlNodeImpl.getXmlString());
//		}
//		String str1 = "";
//		String str2 = "";
//		String str3 = "";
//		String str4 = "";
//		String str5 = "";
//		String str6 = "";
//		String str7 = "";
//		String str8 = "";
//
//		Enumeration localEnumeration = localIEFXmlNodeImpl.elements();
//		if (localEnumeration.hasMoreElements()) {
//			localObject1 = (IEFXmlNode) localEnumeration.nextElement();
//			this.busIdsString = ((IEFXmlNode) localObject1).getAttribute("objectid");
//			str1 = ((IEFXmlNode) localObject1).getAttribute("regEx");
//			str2 = ((IEFXmlNode) localObject1).getAttribute("replaceString");
//			str3 = ((IEFXmlNode) localObject1).getAttribute("StdPart");
//			str4 = ((IEFXmlNode) localObject1).getAttribute("folderId");
//			str5 = ((IEFXmlNode) localObject1).getAttribute("silentSaveAs");
//
//			str6 = ((IEFXmlNode) localObject1).getAttribute("cadDrwSeries");
//			str7 = ((IEFXmlNode) localObject1).getAttribute("cadModelSeries");
//			str8 = ((IEFXmlNode) localObject1).getAttribute("objectIds");
//
//			this.saveAsPageHelper.setRegExpression(str1);
//			this.saveAsPageHelper.setReplaceString(str2);
//			this.saveAsPageHelper.setStdPartPrefix(str3);
//			this.saveAsPageHelper.setFolderId(str4);
//			this.saveAsPageHelper.setCadDrwSeries(str6);
//			this.saveAsPageHelper.setCadModelSeries(str7);
//
//			if ((str5 != null) && (str5.length() > 0)) {
//				this.saveAsPageHelper.setSilentSaveAs(str5);
//			} else {
//				this.saveAsPageHelper.setSilentSaveAs("false");
//			}
//		}
//
//		this.logger.logDebug("[MCADSaveAsPageCreator::buildData] Receivedd :" + this.busIdsString);
//
//		Object localObject1 = new StringTokenizer(this.busIdsString, "|");
//
//		String str9 = null;
//		String str10 = null;
//
//		if (((StringTokenizer) localObject1).hasMoreTokens()) {
//			str9 = ((StringTokenizer) localObject1).nextToken();
//		}
//		if (((StringTokenizer) localObject1).hasMoreTokens()) {
//			str10 = ((StringTokenizer) localObject1).nextToken();
//		}
//
//		if ((str9 == null) || ("".equals(str9.trim()))) {
//			localObject2 = this.integSessionData.getStringResource("mcadIntegration.Server.Message.CantSaveNoMinorFound");
//			MCADServerException.createException((String) localObject2, null);
//		}
//
//		this.saveAsPageObject.rootBusID = str9;
//		this.saveAsPageObject.instanceName = str10;
//
//		Object localObject2 = new Hashtable(1);
//		((Hashtable) localObject2).put(str9, "all");
//
//		HashSet localHashSet = new HashSet(localIEFXmlNodeImpl.getChildCount());
//		ArrayList localArrayList1 = null;
//
//		String str11 = this.util.getAttributeForBO(paramContext, str9, MCADMxUtil.getActualNameForAEFData(paramContext, "attribute_CADType"));
//		boolean bool1 = this.globalConfigObject.isTypeOfClass(str11, "TYPE_INSTANCE_LIKE");
//		boolean bool2 = this.globalConfigObject.isTypeOfClass(str11, "TYPE_FAMILY_LIKE");
//
//		if (bool1) {
//			localHashSet.add(str9);
//		} else if (bool2) {
//			localObject3 = new String[1];
//			localObject3[0] = str9;
//
//			localArrayList1 = this.serverGeneralUtil.getFamilyStructureRecursively(paramContext, localObject3, this.saveAsPageHelper.getFamilyidInstanceStructureTable(), this.saveAsPageHelper.getFamilyidInstanceAttrTable());
//		}
//
//		Object localObject3 = new Hashtable(1);
//		ArrayList localArrayList2 = new ArrayList(2);
//		localArrayList2.add(this.lateralViewProgramLabel);
//		localArrayList2.add(this.verticalViewProgramLabel);
//		((Hashtable) localObject3).put(str9, localArrayList2);
//
//		if ((localArrayList1 != null) && (localArrayList1.size() > 0)) {
//			for (int i = 0; i < localArrayList1.size(); ++i) {
//				localObject4 = (String) localArrayList1.get(i);
//				((Hashtable) localObject2).put(localObject4, "all");
//				((Hashtable) localObject3).put(localObject4, localArrayList2);
//				localHashSet.add(localObject4);
//			}
//		}
//
//		((Hashtable) localObject3).put(str9, localArrayList2);
//
//		if (((Hashtable) localObject2).size() > 0) {
//			this.objectExpander.familyIdInstanceStructureTable = this.saveAsPageHelper.getFamilyidInstanceStructureTable();
//			this.objectExpander.addToInstanceLikeIds(localHashSet);
//			this.busIDDependentRelIDsTable = this.objectExpander.getRelationshipAndChildObjectInfoForParent(paramContext, (Map) localObject2, this.globalConfigObject.getRelationshipsOfClass("AssemblyLike"), new HashMap(0), (Hashtable) localObject3, true, "As-Built", null, null);
//		}
//		this.integSessionData.setSessionObjectByKey("busIDList", this.busIDDependentRelIDsTable);
//		this.integSessionData.setSessionObjectByKey("verticalViewProgram", this.verticalViewProgramName);
//		IEFTreeTableNode localIEFTreeTableNode = this.saveAsPageObject.createRootNode();
//
//		Object localObject4 = getRelationshipColumnValuesTable("true");
//
//		getNodesRow(paramContext, str9, localIEFTreeTableNode, true, false, null, "true", (Hashtable) localObject4, false, true);
//
//		setSaveAsPageData(paramContext, str9);
//	}
//
//	private void setSaveAsPageData(Context paramContext, String paramString) throws Exception {
//		this.saveAsPageObject.setIntegrationName(this.integrationName);
//		this.saveAsPageObject.setTabsList(this.saveAsPageHelper.getTabsList());
//		this.saveAsPageObject.setTabsDataTable(this.saveAsPageHelper.getTabsDataTable(paramContext, this.defaultCustomTable));
//
//		this.saveAsPageObject.familyNameNodeIDsArray = getFamilyNamesTable();
//		this.saveAsPageObject.familyIDInstanceListTable = this.familyIDInstanceListTable;
//		this.saveAsPageObject.typeFamilyLikeClass = this.globalConfigObject.getTypeListForClass("TYPE_FAMILY_LIKE");
//		this.saveAsPageObject.typeInstanceLikeClass = this.globalConfigObject.getTypeListForClass("TYPE_INSTANCE_LIKE");
//		this.saveAsPageObject.isSystemCaseSensitive = this.integSessionData.isSystemCaseSensitive();
//		this.saveAsPageObject.sharedPartIdentityNodeIDsArray = this.sharedPartNameNodeIDsVectorTable;
//		this.saveAsPageObject.unsupportedChars = this.globalConfigObject.getNonSupportedCharacters();
//		this.saveAsPageObject.selectedPartNameWidth = MCADIntegrationSessionData.getPropertyValue("mcadIntegration.Server.ColumnName.SelectedPartNameWidth");
//		this.saveAsPageObject.verticalViewName = this.verticalViewProgramLabel;
//		this.saveAsPageObject.lateralViewName = this.defaultLateralViewProgramLabel;
//		this.saveAsPageObject.selectedFolderNameWidth = MCADIntegrationSessionData.getPropertyValue("mcadIntegration.Server.ColumnName.SelectedFolderNameWidth");
//		this.saveAsPageObject.folderPathListWidth = MCADIntegrationSessionData.getPropertyValue("mcadIntegration.Server.ColumnName.FolderPathListWidth");
//		this.saveAsPageObject.folderPathListHeight = MCADIntegrationSessionData.getPropertyValue("mcadIntegration.Server.ColumnName.FolderPathListHeight");
//		this.saveAsPageObject.saveAsDetailsNode = this.saveAsDetailsNode;
//		this.saveAsPageObject.verticalNavigationProgNameMapping = this.verticalNavigationProgNameMapping;
//		this.saveAsPageObject.verticalViewProgName = this.verticalViewProgramName;
//		this.saveAsPageObject.instanceIDDisplayedFamIDsArray = this.instanceIDExpandedfromFamIDTable;
//		this.saveAsPageObject.isExpandedSubComponent = this.globalConfigObject.isExpandedSubComponent();
//
//		this.saveAsPageObject.setStyleClassTable(this.saveAsPageHelper.getStyleClassTable());
//
//		if (this.ebomConfigObj != null) {
//			String str = this.ebomConfigObj.getConfigAttributeValue(IEFEBOMConfigObject.ATTR_PART_MATCHING_RULE);
//
//			if (str != null) {
//				this.saveAsPageObject.isMatchCADModelRevisionForPart = str.equals("MATCH_CADMODEL_REV");
//			}
//		}
//		setExtendedSaveAsPageData(paramContext, paramString);
//	}
//
//	protected void setExtendedSaveAsPageData(Context paramContext, String paramString) {
//	}
//
//	private IEFTreeTableNode getNodesRow(Context paramContext, String paramString1, IEFTreeTableNode paramIEFTreeTableNode, boolean paramBoolean1, boolean paramBoolean2, String paramString2, String paramString3, Hashtable paramHashtable, boolean paramBoolean3, boolean paramBoolean4) throws Exception {
//		if (null == paramHashtable) {
//			paramHashtable = new Hashtable();
//		}
//
//		if ((paramBoolean4) && (!(this.lateralViewProgramName.equalsIgnoreCase("As-Built"))) && (!(this.lateralViewProgramLabel.equalsIgnoreCase(this.integSessionData.getStringResource("mcadIntegration.Server.Message.lateralViewNameDueToVerticalNavigation")))) && (!(this.lateralViewProgramName.equalsIgnoreCase("As-Built"))) && (!(this.lateralViewProgramLabel.equalsIgnoreCase(this.integSessionData.getStringResource("mcadIntegration.Server.Message.lateralViewNameDueToVerticalNavigation"))))) {
//			paramString1 = this.pageViews.getRelatedLateralViewBusObjectID(paramContext, paramString1, this.lateralViewProgramName);
//		}
//
//		Hashtable localHashtable = getNodeMatrixData(paramContext, paramString1);
//
//		String str1 = (String) localHashtable.get("Name");
//		String str2 = getUUID();
//		String str3 = null;
//		if (paramIEFTreeTableNode != null) {
//			str3 = paramIEFTreeTableNode.objectID;
//		}
//
//		String str4 = getNodeData(paramContext, paramString1, str3);
//		String str5 = (String) localHashtable.get("CADType");
//		String str6 = (String) localHashtable.get("LockStatus");
//		String str7 = (String) this.cadIDNodeDataTable.get(str4);
//		boolean bool1 = false;
//		int i = 0;
//
//		if (paramString3.equalsIgnoreCase("false")) {
//			bool1 = true;
//		}
//		String str8 = (String) localHashtable.get("StdPart");
//		String str9 = (String) localHashtable.get("CommonPart");
//
//		if (str8.equalsIgnoreCase("true")) {
//			bool1 = true;
//			paramBoolean1 = false;
//		}
//
//		if (str9.equalsIgnoreCase("true")) {
//			bool1 = true;
//			paramBoolean1 = false;
//			i = 1;
//		}
//		IEFTreeTableNode localIEFTreeTableNode = null;
//
//		String str10 = "TopDown";
//		if (paramHashtable.containsKey("relArrow")) {
//			str10 = (String) paramHashtable.get("relArrow");
//		}
//		if (paramBoolean2) {
//			localIEFTreeTableNode = new IEFTreeTableNode(paramString2, str7, str4, str6, bool1, str10, paramHashtable);
//			this.saveAsPageObject.replaceNode(localIEFTreeTableNode);
//			if (i != 0)
//				localIEFTreeTableNode.setBackGroungColor("#00CC99");
//			keepSharedPartInTable(str4, paramString2);
//		} else {
//			localIEFTreeTableNode = paramIEFTreeTableNode.addChild(this.saveAsPageObject, str2, str7, str4, str6, bool1, str10, paramHashtable);
//			if (i != 0)
//				localIEFTreeTableNode.setBackGroungColor("#00CC99");
//			keepSharedPartInTable(str4, str2);
//		}
//
//		if (paramBoolean3) {
//			localIEFTreeTableNode.setNodeType(1);
//		}
//
//		if (isCadObjectAlreadyExpanded(str4)) {
//			addReplicatedNodeID(localIEFTreeTableNode);
//			return localIEFTreeTableNode;
//		}
//
//		this.expandedCadObjTreeTableNodesTable.put(str4, localIEFTreeTableNode);
//		Object localObject;
//		if ((this.globalConfigObject.isTypeOfClass(str5, "TYPE_FAMILY_LIKE")) || (this.globalConfigObject.isTypeOfClass(str5, "TYPE_INSTANCE_LIKE"))) {
//			localObject = (String) localHashtable.get("FamilyID");
//
//			if ((null != localObject) && (!("".equalsIgnoreCase((String) localObject))) && (this.globalConfigObject.isTypeOfClass(str5, "TYPE_INSTANCE_LIKE")))
//				addInstanceIdForFamily(paramString1, (String) localObject);
//			getDependentTableRowsForFamilyTower(paramContext, paramString1, (String) localObject, paramBoolean1, str5, localIEFTreeTableNode);
//		} else if (this.globalConfigObject.isTypeOfClass(str5, "TYPE_FAMILY_LIKE")) {
//			localObject = (Hashtable) localHashtable.get("InstanceStructure");
//			getDependentTableRowsForFamilyInstance(paramContext, paramString1, (Hashtable) localObject, localIEFTreeTableNode);
//		}
//
//		if (paramBoolean1) {
//			getDependentTableRows(paramContext, paramString1, localIEFTreeTableNode, str5);
//			bool2 = isDesignExpandable(paramContext, paramString1, str5);
//			if (bool2) {
//				localIEFTreeTableNode.hasChildNodes = true;
//			}
//		}
//		boolean bool2 = false;
//
//		if (this.globalConfigObject.isTypeOfClass(str5, "TYPE_DRAWING_LIKE")) {
//			bool2 = true;
//		}
//
//		if ((((!(paramBoolean3)) || (bool2))) && (!(this.verticalViewProgramLabel.equals("None")))) {
//			IEFXmlNode localIEFXmlNode1 = this.pageViews.getRelatedVerticalViewBusObjectIDs(paramContext, paramString1, this.verticalViewProgramLabel, this.alreadyExpandedNodesInPath);
//
//			Enumeration localEnumeration = localIEFXmlNode1.getChildrenByName("node");
//			while (localEnumeration.hasMoreElements()) {
//				IEFXmlNode localIEFXmlNode2 = (IEFXmlNode) localEnumeration.nextElement();
//				getNodesRowForVerticalView(paramContext, localIEFXmlNode2, localIEFTreeTableNode, paramBoolean4);
//			}
//			return localIEFTreeTableNode;
//		}
//
//		if (this.globalConfigObject.isTypeOfClass(str5, "TYPE_FAMILY_LIKE")) {
//			keepFamilyPartInTable(str1, str2);
//		} else if ((!(paramBoolean1)) && (this.globalConfigObject.isTypeOfClass(str5, "TYPE_INSTANCE_LIKE"))) {
//			str1 = paramIEFTreeTableNode.name;
//			keepFamilyPartInTable(str1, str2);
//		}
//
//		return ((IEFTreeTableNode) localIEFTreeTableNode);
//	}
//
//	private void getNodesRowForVerticalView(Context paramContext, IEFXmlNode paramIEFXmlNode, IEFTreeTableNode paramIEFTreeTableNode, boolean paramBoolean) throws Exception {
//		String str1 = paramIEFXmlNode.getAttribute("relid");
//		String str2 = paramIEFXmlNode.getAttribute("busid");
//		String str3 = "BottomUp";
//
//		this.alreadyExpandedNodesInPath.add(str2);
//
//		Hashtable localHashtable = new Hashtable();
//		localHashtable.put("RID", str1);
//		localHashtable.put("relArrow", str3);
//
//		IEFTreeTableNode localIEFTreeTableNode = getNodesRow(paramContext, str2, paramIEFTreeTableNode, false, false, null, "true", localHashtable, true, paramBoolean);
//
//		Enumeration localEnumeration = paramIEFXmlNode.getChildrenByName("node");
//		while (localEnumeration.hasMoreElements()) {
//			IEFXmlNode localIEFXmlNode = (IEFXmlNode) localEnumeration.nextElement();
//
//			getNodesRowForVerticalView(paramContext, localIEFXmlNode, localIEFTreeTableNode, paramBoolean);
//		}
//	}
//
//	public void getDependentTableRowsForFamilyTower(Context paramContext, String paramString1, String paramString2, boolean paramBoolean, String paramString3, IEFTreeTableNode paramIEFTreeTableNode) throws Exception {
//		if (this.globalConfigObject.isTypeOfClass(paramString3, "TYPE_FAMILY_LIKE")) {
//			getDependentTableRowsForFamily(paramContext, paramString1, paramBoolean, paramIEFTreeTableNode);
//		} else {
//			getDependentTableRowsForInstance(paramContext, paramString1, paramString2, paramBoolean, paramIEFTreeTableNode);
//		}
//	}
//
//	private void getDependentTableRowsForFamily(Context paramContext, String paramString, boolean paramBoolean, IEFTreeTableNode paramIEFTreeTableNode) throws Exception {
//		Hashtable localHashtable1 = getNodeMatrixData(paramContext, paramString);
//
//		if (this.expandedFamilyIDsVector.contains(paramString))
//			return;
//		this.expandedFamilyIDsVector.addElement(paramString);
//
//		Hashtable localHashtable2 = (Hashtable) localHashtable1.get("InstanceStructure");
//
//		if ((localHashtable2 == null) || (localHashtable2.size() <= 0))
//			return;
//		Enumeration localEnumeration = localHashtable2.keys();
//		while (localEnumeration.hasMoreElements()) {
//			String str = (String) localEnumeration.nextElement();
//
//			Hashtable localHashtable3 = getRelationshipColumnValuesTable("false");
//			this.instanceIDExpandedfromFamIDTable.put(str, paramString);
//			if ((!(this.expandedFamilyIDsVector.contains(str))) && (!(this.alreadyExpandedNodesInPath.contains(paramString)))) {
//				this.alreadyExpandedNodesInPath.add(paramString);
//
//				this.intermediateExpandedNodes.add(paramString);
//
//				getNodeData(paramContext, str, paramString);
//
//				IEFTreeTableNode localIEFTreeTableNode = getNodesRow(paramContext, str, paramIEFTreeTableNode, true, false, null, "true", localHashtable3, false, true);
//
//				addInstanceIdForFamily(str, paramString);
//
//				this.intermediateExpandedNodes.remove(paramString);
//				this.alreadyExpandedNodesInPath.remove(paramString);
//			}
//		}
//	}
//
//	private void getDependentTableRowsForInstance(Context paramContext, String paramString1, String paramString2, boolean paramBoolean, IEFTreeTableNode paramIEFTreeTableNode) throws Exception {
//		Hashtable localHashtable1 = getNodeMatrixData(paramContext, paramString1);
//
//		int i = 1;
//
//		Hashtable localHashtable2 = getRelationshipColumnValuesTable("false");
//		localHashtable2.put("relArrow", "BottomUp");
//		String str1 = null;
//		if ((paramString2 != null) && (i != 0)) {
//			str1 = paramString2;
//		} else {
//			str1 = (String) localHashtable1.get("FamilyID");
//		}
//
//		getDependentTableRowsForFamily(paramContext, paramString1, paramBoolean, paramIEFTreeTableNode);
//
//		if ((str1 == null) || (this.alreadyExpandedNodesInPath.contains(paramString1)))
//			return;
//		this.alreadyExpandedNodesInPath.add(paramString1);
//
//		Hashtable localHashtable3 = getNodeMatrixData(paramContext, str1);
//		String str2 = (String) localHashtable3.get("FamilyID");
//
//		this.intermediateExpandedNodes.add(paramString1);
//
//		getNodeData(paramContext, str1, str2);
//
//		this.intermediateExpandedNodes.remove(paramString1);
//
//		int j = 0;
//		if (!(this.instanceIDExpandedfromFamIDTable.containsKey(paramString1)))
//			j = ((!(this.expandedFamilyIDsVector.contains(str1))) && (!(this.alreadyExpandedNodesInPath.contains(str1)))) ? 1 : 0;
//		else
//			j = ((!(this.expandedFamilyIDsVector.contains(str1))) && (!(this.alreadyExpandedNodesInPath.contains(str1))) && (this.instanceIDExpandedfromFamIDTable.containsValue(str1))) ? 1 : 0;
//		Object localObject;
//		if (j != 0) {
//			localObject = getNodesRow(paramContext, str1, paramIEFTreeTableNode, false, false, null, "true", localHashtable2, false, true);
//
//			getDependentTableRowsForInstance(paramContext, str1, str2, true, (IEFTreeTableNode) localObject);
//		} else {
//			localObject = (Hashtable) localHashtable3.get("InstanceStructure");
//			if ((localObject != null) && (((Hashtable) localObject).size() > 0)) {
//				Enumeration localEnumeration = ((Hashtable) localObject).keys();
//				while (localEnumeration.hasMoreElements()) {
//					String str3 = (String) localEnumeration.nextElement();
//					addInstanceIdForFamily(str3, paramString2);
//				}
//			}
//		}
//
//		this.alreadyExpandedNodesInPath.remove(paramString1);
//	}
//
//	private boolean isDesignExpandable(Context paramContext, String paramString1, String paramString2) throws Exception {
//		boolean bool = false;
//
//		int i = 1;
//
//		Hashtable localHashtable = new Hashtable();
//		String str = "";
//		Object localObject1;
//		if ((this.busIDDependentRelIDsTable != null) && (this.globalConfigObject.isTypeOfClass(paramString2, "TYPE_INSTANCE_LIKE"))) {
//			localObject1 = (Hashtable) this.busIDNodeMatrixDataTable.get(paramString1);
//			localHashtable = (Hashtable) this.busIDDependentRelIDsTable.get(paramString1);
//			str = (String) ((Hashtable) localObject1).get("FamilyID");
//			i = (((!(this.alreadyExpandedNodesInPath.contains(str))) && (!(this.instanceIDExpandedfromFamIDTable.containsValue(str))) && (!(this.instanceIDExpandedfromFamIDTable.containsKey(paramString1)))) || ((localHashtable != null) && (localHashtable.size() > 0))) ? 1 : 0;
//		}
//		Object localObject2;
//		if ((!(this.alreadyExpandedNodesInPath.contains(paramString1))) && (((this.globalConfigObject.isTypeOfClass(paramString2, "TYPE_FAMILY_LIKE")) || ((this.globalConfigObject.isTypeOfClass(paramString2, "TYPE_INSTANCE_LIKE")) && (i != 0))))) {
//			bool = true;
//		} else if (!(this.alreadyExpandedNodesInPath.contains(paramString1))) {
//			localObject1 = new Hashtable();
//			localObject2 = this.globalConfigObject.getRelationshipsOfClass("AssemblyLike");
//
//			((Hashtable) localObject1).putAll((Map) localObject2);
//
//			if (((Hashtable) localObject1).size() > 0) {
//				bool = this.serverGeneralUtil.isDesignExpandable(paramContext, paramString1, (Hashtable) localObject1);
//			}
//		}
//
//		if ((!(bool)) && (!(this.verticalViewProgramLabel.equals("None")))) {
//			localObject1 = this.pageViews.getRelatedVerticalViewBusObjectIDs(paramContext, paramString1, this.verticalViewProgramLabel, this.alreadyExpandedNodesInPath);
//			localObject2 = ((IEFXmlNode) localObject1).getChildrenByName("node");
//			if (((Enumeration) localObject2).hasMoreElements())
//				bool = true;
//		}
//		if (this.isDebugOn) {
//			this.logger.log("[MCADFSaveAsPageCreator.isDesignExpandable] expandable : " + bool, 3);
//		}
//		return bool;
//	}
//
//	private void getDependentTableRowsForFamilyInstance(Context paramContext, String paramString, Hashtable paramHashtable, IEFTreeTableNode paramIEFTreeTableNode) throws Exception {
//		try {
//			Enumeration localEnumeration = paramHashtable.keys();
//			while (localEnumeration.hasMoreElements()) {
//				String str = (String) localEnumeration.nextElement();
//
//				Hashtable localHashtable = getRelationshipColumnValuesTable("true");
//
//				getNodesRow(paramContext, str, paramIEFTreeTableNode, false, false, null, "true", localHashtable, false, true);
//				addInstanceIdForFamily(str, paramString);
//			}
//		} catch (Exception localException) {
//			MCADServerException.createException(localException.getMessage(), localException);
//		}
//	}
//
//	private void addInstanceIdForFamily(String paramString1, String paramString2) {
//		Vector localVector = (Vector) this.familyIDInstanceListTable.get(paramString2);
//		if (localVector == null) {
//			localVector = new Vector();
//		}
//		if (!(localVector.contains(paramString1)))
//			localVector.addElement(paramString1);
//		this.familyIDInstanceListTable.put(paramString2, localVector);
//	}
//
//	private void getDependentTableRows(Context paramContext, String paramString1, IEFTreeTableNode paramIEFTreeTableNode, String paramString2) throws Exception {
//		String str1 = paramString1;
//
//		this.logger.logDebug("[MCADSavaAsPageCreator.getDependentTableRows] ObjectID :" + paramString1);
//
//		if ((this.globalConfigObject.isTypeOfClass(paramString2, "TYPE_FAMILY_LIKE")) || (this.alreadyExpandedNodesInPath.contains(str1)))
//			return;
//		Hashtable localHashtable1 = getChildRelationshipIDsForAssembly(paramString1);
//		Hashtable localHashtable2 = this.globalConfigObject.getRelationshipsOfClass("AssemblyLike");
//
//		if (null == localHashtable1)
//			return;
//		Enumeration localEnumeration = localHashtable1.keys();
//		while (localEnumeration.hasMoreElements()) {
//			String str2 = (String) localEnumeration.nextElement();
//			Vector localVector = (Vector) localHashtable1.get(str2);
//
//			Object localObject = (String) localVector.elementAt(0);
//			String str3 = (String) localVector.elementAt(1);
//			String str4 = (String) localHashtable2.get(str3);
//
//			String str5 = (String) this.extrenalRefParentRevIDsCurrIDTable.get(localObject);
//			if (str5 != null) {
//				localObject = str5;
//			}
//
//			this.alreadyExpandedNodesInPath.add(str1);
//
//			Hashtable localHashtable3 = getRelationshipColumnValuesTable("true");
//
//			localHashtable3.put("RID", str2);
//			localHashtable3.put("Name", str3);
//
//			if (this.globalConfigObject.isRelationshipOfClass(str3, "ExternalRefereneLike")) {
//				String str6 = "ExternalRefTopDown";
//				if (str4.equals("from"))
//					str6 = "ExternalRefBottomUp";
//				localHashtable3.put("relArrow", str6);
//			}
//			getNodesRow(paramContext, (String) localObject, paramIEFTreeTableNode, true, false, null, "true", localHashtable3, false, true);
//
//			this.alreadyExpandedNodesInPath.remove(str1);
//		}
//
//		this.logger.logDebug("[MCADSavaAsPageCreator.getDependentTableRows] End of the method");
//	}
//
//	private Hashtable getChildRelationshipIDsForAssembly(String paramString) throws Exception {
//		this.logger.logDebug("MCADSaveAsPageCreator:getChildRelationshipIDsForAssembly Getting Relationship info for busid " + paramString);
//
//		Hashtable localHashtable = (Hashtable) this.busIDDependentRelIDsTable.get(paramString);
//
//		if (localHashtable == null) {
//			this.logger.logDebug("MCADSaveAsPageCreator:getChildRelationshipIDsForAssembly Relationship info is null " + this.busIDDependentRelIDsTable.keySet().toString());
//		}
//
//		return localHashtable;
//	}
//
//	private String getNodeData(Context paramContext, String paramString1, String paramString2) throws Exception {
//		String str1 = paramString1;
//
//		if (!(this.cadIDNodeDataTable.containsKey(str1))) {
//			Hashtable localHashtable1 = getNodeMatrixData(paramContext, paramString1);
//			String str2 = (String) localHashtable1.get("CADType");
//			String str3 = (String) localHashtable1.get("Name");
//			String str4 = (String) localHashtable1.get("Revision");
//			String str5 = (String) localHashtable1.get("Design");
//			String str6 = (String) localHashtable1.get("BusinessObjectId");
//			String str7 = (String) localHashtable1.get("Version");
//			String str8 = (String) localHashtable1.get("TargetRevision");
//			Vector localVector1 = (Vector) localHashtable1.get("RevisionsList");
//			Vector localVector2 = (Vector) localHashtable1.get("VersionsList");
//			String str9 = str3;
//			String str10 = "";
//			String str11 = "";
//			String str12 = "";
//			String str13 = "";
//			String str14 = "";
//			String str15 = "";
//			String str16 = "false";
//			String str17 = "";
//			String str18 = "true";
//			String str19 = "true";
//			String str20 = (String) localHashtable1.get("IsAssignFolderEnable");
//			String str21 = (String) localHashtable1.get("Title");
//			String str22 = (String) localHashtable1.get("RevSequence");
//			String str23 = this.globalConfigObject.isObjectAndFileNameDifferent() + "";
//
//			String str24 = (String) localHashtable1.get("StdPart");
//			String str25 = (String) localHashtable1.get("CommonPart");
//			String str26 = (String) localHashtable1.get("TargetName");
//			String str27 = (String) localHashtable1.get("silentSaveAs");
//
//			if ((this.assignedFolderInfTable != null) && (paramString2 != null) && (this.assignedFolderInfTable.containsKey(paramString2))) {
//				localObject1 = (Vector) this.assignedFolderInfTable.get(paramString2);
//				str13 = (String) ((Vector) localObject1).elementAt(0);
//
//				if (str13.equalsIgnoreCase("true")) {
//					str14 = (String) ((Vector) localObject1).elementAt(1);
//					str15 = (String) ((Vector) localObject1).elementAt(2);
//					this.assignedFolderInfTable.put(str1, localObject1);
//				}
//			}
//
//			if (("".equals(str14)) || (str14 == null)) {
//				str14 = (String) localHashtable1.get("FolderId");
//				str15 = (String) localHashtable1.get("FolderPath");
//				str13 = "false";
//			}
//
//			if (this.globalConfigObject.isTypeOfClass(str2, "TYPE_FAMILY_LIKE")) {
//				str11 = paramString1;
//				str12 = str3;
//
//				if (this.integrationName.equalsIgnoreCase("MxPro"))
//					;
//				str17 = getPROEGenericInstanceId(paramContext, str3, str11);
//			} else if (this.globalConfigObject.isTypeOfClass(str2, "TYPE_INSTANCE_LIKE")) {
//				localObject1 = new BusinessObject(paramString1);
//				localObject2 = this.serverGeneralUtil.getFamilyObjectForInstance(paramContext, (BusinessObject) localObject1);
//				str11 = ((BusinessObject) localObject2).getObjectId();
//
//				str28 = this.serverGeneralUtil.getTopLevelFamilyObjectForInstance(paramContext, paramString1);
//				localObject3 = new BusinessObject(str28);
//				((BusinessObject) localObject3).open(paramContext);
//				str12 = ((BusinessObject) localObject3).getName();
//
//				((BusinessObject) localObject3).close(paramContext);
//
//				str10 = this.serverGeneralUtil.getIndivisualInstanceName(str3);
//				if ((!(this.integrationName.equalsIgnoreCase("MxPro"))) || (str10.equalsIgnoreCase(str12))) {
//					str16 = "true";
//				}
//				str9 = str10 + "(" + str12 + ")";
//				str19 = "false";
//			}
//
//			if (!(isPartAssignmentEnable(paramContext, str2, str5))) {
//				str18 = "false";
//			}
//
//			Object localObject1 = this.lateralViewProgramLabel;
//			Object localObject2 = this.verticalViewProgramLabel;
//			String str28 = this.integSessionData.getStringResource("mcadIntegration.Server.FieldName." + ((String) localObject1));
//
//			Object localObject3 = new Hashtable(36);
//			HashMap localHashMap = new HashMap();
//
//			String str29 = paramContext.getLocale().getLanguage();
//			localHashMap.put("Design", MCADMxUtil.getNLSName(paramContext, "Type", str5, "", "", str29));
//			((Hashtable) localObject3).put("NLSTABLEFORADMINTYPES", localHashMap);
//			((Hashtable) localObject3).put("ID", str6);
//			((Hashtable) localObject3).put("Name", str3);
//			((Hashtable) localObject3).put("CADType", str2);
//			((Hashtable) localObject3).put("Selected", "false");
//			((Hashtable) localObject3).put("Design", str5);
//			((Hashtable) localObject3).put("Revision", str4);
//			((Hashtable) localObject3).put("FamilyName", str12);
//			((Hashtable) localObject3).put("Version", str7);
//			((Hashtable) localObject3).put("InstanceName", str10);
//			((Hashtable) localObject3).put("FamilyID", str11);
//			((Hashtable) localObject3).put("TargetRevision", "");
//			((Hashtable) localObject3).put("ApplyToChild", str13);
//
//			((Hashtable) localObject3).put("StdPart", str24);
//			((Hashtable) localObject3).put("CommonPart", str25);
//			((Hashtable) localObject3).put("TargetName", str26);
//			((Hashtable) localObject3).put("silentSaveAs", str27);
//
//			if ((null != this.integrationName) && (this.integrationName.equalsIgnoreCase("solidworks")) && (this.globalConfigObject.isTypeOfClass(str2, "TYPE_INSTANCE_LIKE"))) {
//				((Hashtable) localObject3).put("AssignFolder", "");
//			} else {
//				((Hashtable) localObject3).put("AssignFolder", str15);
//			}
//			((Hashtable) localObject3).put("SelectedFolderId", str14);
//			((Hashtable) localObject3).put("IsPROEInstanceGeneric", str16);
//			((Hashtable) localObject3).put("PROEGenericInstanceId", str17);
//			((Hashtable) localObject3).put("IsPartAssignmentEnable", str18);
//
//			String str30 = "SaveAs";
//			((Hashtable) localObject3).put(str30, "");
//			if (str23.equals("true")) {
//				str30 = "SaveAsTitle";
//				((Hashtable) localObject3).put(str30, "");
//				localObject4 = (String) localHashtable1.get("AutoName");
//				((Hashtable) localObject3).put("AutoName", localObject4);
//
//				if (this.isCallFromAPI) {
//					((Hashtable) localObject3).put("SaveAs", localObject4);
//				}
//				str31 = (String) localHashtable1.get("HasFiles");
//				((Hashtable) localObject3).put("HasFiles", str31);
//			}
//
//			if ((str26 != null) && (str26.length() > 0)) {
//				((Hashtable) localObject3).put(str30, str26);
//				((Hashtable) localObject3).put("Selected", "true");
//				((Hashtable) localObject3).put("TargetRevision", str4);
//			} else if ((this.isCallFromAPI) && (str23.equals("true"))) {
//				((Hashtable) localObject3).put(str30, str21);
//				((Hashtable) localObject3).put("Selected", "true");
//				((Hashtable) localObject3).put("TargetRevision", str4);
//			}
//
//			((Hashtable) localObject3).put("IsAssignFolderEnable", "false");
//			((Hashtable) localObject3).put("AppliedLateralView", localObject1);
//			((Hashtable) localObject3).put("IsLateralNavigationRequired", str19);
//			((Hashtable) localObject3).put("AppliedVerticalView", localObject2);
//			((Hashtable) localObject3).put("AppliedLateralViewDisplay", str28);
//			((Hashtable) localObject3).put("RevisionsList", localVector1);
//			((Hashtable) localObject3).put("VersionsList", localVector2);
//			((Hashtable) localObject3).put("TargetRev", str8);
//			((Hashtable) localObject3).put("AssignFolderEnable", str20);
//			if ((null != this.integrationName) && (this.integrationName.equalsIgnoreCase("solidworks")) && (this.globalConfigObject.isTypeOfClass(str2, "TYPE_INSTANCE_LIKE"))) {
//				((Hashtable) localObject3).put("DefaultAssignFolder", "");
//			} else {
//				((Hashtable) localObject3).put("DefaultAssignFolder", str15);
//			}
//			((Hashtable) localObject3).put("Title", str21);
//			((Hashtable) localObject3).put("RevSequence", str22);
//			((Hashtable) localObject3).put("IsObjectAndFileNameDifferent", str23);
//			Object localObject4 = (Vector) localHashtable1.get("CustomTable");
//			((Hashtable) localObject3).put("CustomTable", localObject4);
//
//			String str31 = (String) localHashtable1.get("CUECLASS");
//			if (str31 != null)
//				((Hashtable) localObject3).put("CueClass", str31);
//			else {
//				((Hashtable) localObject3).put("CueClass", "");
//			}
//			if (this.globalConfigObject.isAssignCADModelNameFromPart()) {
//				((Hashtable) localObject3).put("Specification", "");
//				((Hashtable) localObject3).put("AssignPart", "");
//				((Hashtable) localObject3).put("SelectedPartID", "");
//			}
//
//			Hashtable localHashtable2 = new Hashtable(10);
//			localHashtable2.put("Title", "Label");
//			localHashtable2.put("Design", "Label");
//			localHashtable2.put("Revision", "Label");
//			localHashtable2.put("Version", "ComboBox");
//			localHashtable2.put("Lock", "Label");
//			localHashtable2.put("TargetRevision", "ReadOnlyTextBox");
//
//			int i = 0;
//			if ((str25 != null) && (str24 != null)) {
//				if (str25.equalsIgnoreCase("true"))
//					i = 1;
//				if (str24.equalsIgnoreCase("true")) {
//					i = 1;
//				}
//			}
//			if ((str26 != null) && (str26.length() > 0) && (i == 0)) {
//				localHashtable2.put(str30, "EditBox");
//				localHashtable2.put("TargetRevision", "EditBox");
//				((Hashtable) localObject3).put("IsAssignFolderEnable", "true");
//				localHashtable2.put("Revision", "ComboBox");
//			} else {
//				localHashtable2.put(str30, "ReadOnlyTextBox");
//			}
//
//			localHashtable2.put("AssignFolder", "AssignFolder");
//			localHashtable2.put("AppliedLateralViewDisplay", "Label");
//
//			if (this.globalConfigObject.isAssignCADModelNameFromPart()) {
//				localHashtable2.put("Specification", "ReadOnlyTextBox");
//				localHashtable2.put("AssignPart", "AssignPart");
//
//				if (str18.equals("true")) {
//					localHashtable2.put(str30, "ReadOnlyTextBox");
//				}
//			}
//
//			Hashtable localHashtable3 = new Hashtable(5);
//			localHashtable3.put("Version", localVector2);
//			localHashtable3.put("Revision", localVector1);
//
//			Hashtable localHashtable4 = new Hashtable(4);
//			localHashtable4.put("Values", localObject3);
//			localHashtable4.put("CellTypes", localHashtable2);
//			localHashtable4.put("Options", localHashtable3);
//
//			getExtendedNodeData(paramContext, localHashtable4, localHashtable1);
//
//			this.saveAsPageObject.addObjectNodeData(str1, localHashtable4);
//			this.cadIDNodeDataTable.put(str1, str9);
//		}
//
//		return ((String) (String) (String) (String) str1);
//	}
//
//	protected void getExtendedNodeData(Context paramContext, Hashtable paramHashtable1, Hashtable paramHashtable2) throws Exception {
//	}
//
//	private Hashtable getNodeMatrixData(Context paramContext, String paramString) throws Exception {
//		Hashtable localHashtable = null;
//
//		if (this.busIDNodeMatrixDataTable.containsKey(paramString)) {
//			localHashtable = (Hashtable) this.busIDNodeMatrixDataTable.get(paramString);
//		} else {
//			localHashtable = this.saveAsPageHelper.getNodeMatrixData(paramContext, paramString);
//			this.busIDNodeMatrixDataTable.put(paramString, localHashtable);
//		}
//
//		return localHashtable;
//	}
//
//	private void keepSharedPartInTable(String paramString1, String paramString2) {
//		Vector localVector;
//		if (!(this.sharedPartNameNodeIDsVectorTable.containsKey(paramString1))) {
//			localVector = new Vector();
//			localVector.addElement(paramString2);
//			this.sharedPartNameNodeIDsVectorTable.put(paramString1, localVector);
//		} else {
//			localVector = (Vector) this.sharedPartNameNodeIDsVectorTable.get(paramString1);
//			localVector.addElement(paramString2);
//		}
//	}
//
//	private String getPROEGenericInstanceId(Context paramContext, String paramString1, String paramString2) throws Exception {
//		Object localObject = "";
//		BusinessObject localBusinessObject1 = new BusinessObject(paramString2);
//		Vector localVector = this.serverGeneralUtil.getInstanceListForFamilyObject(paramContext, localBusinessObject1.getObjectId(paramContext));
//		Enumeration localEnumeration = localVector.elements();
//		while (localEnumeration.hasMoreElements()) {
//			BusinessObject localBusinessObject2 = (BusinessObject) localEnumeration.nextElement();
//
//			localBusinessObject2.open(paramContext);
//			String str1 = localBusinessObject2.getObjectId();
//			String str2 = localBusinessObject2.getName();
//			localBusinessObject2.close(paramContext);
//
//			String str3 = this.serverGeneralUtil.getIndivisualInstanceName(str2);
//			if (str3.equalsIgnoreCase(paramString1)) {
//				localObject = str1;
//				break;
//			}
//		}
//		return ((String) localObject);
//	}
//
//	private boolean isPartAssignmentEnable(Context paramContext, String paramString1, String paramString2) {
//		int i = 1;
//		if (this.globalConfigObject.isAssignCADModelNameFromPart()) {
//			if (this.globalConfigObject.isTypeOfClass(paramString1, "TYPE_FAMILY_LIKE")) {
//				i = 0;
//			} else if (this.ebomConfigObj != null) {
//				Vector localVector = this.ebomConfigObj.getAttributeAsVector(IEFEBOMConfigObject.ATTR_INVALID_TYPES, "\n");
//				if (localVector.contains(paramString2)) {
//					i = 0;
//				}
//
//			}
//
//		} else {
//			i = 0;
//		}
//		return i;
//	}
//
//	private void loadViewProgramRegistry(Context paramContext) {
//		String str1 = this.localConfigObject.getViewRegistryName(this.integrationName);
//
//		this.lateralNavigationProgNameMapping = this.util.readLateralNavigationProgNameMapping(paramContext, str1);
//		String str2 = this.localConfigObject.getDefaultLateralView(this.integrationName);
//		if ((str2 != null) && (!(str2.equals("")))) {
//			localObject = (Vector) this.lateralNavigationProgNameMapping.get(str2);
//			if ((localObject != null) && (((Vector) localObject).size() > 0)) {
//				this.defaultLateralViewProgramLabel = str2;
//				this.defaultLateralViewProgramName = ((String) ((Vector) localObject).elementAt(0));
//				this.lateralViewProgramLabel = str2;
//				this.lateralViewProgramName = str2;
//			}
//		}
//
//		this.verticalNavigationProgNameMapping = this.util.readVerticalNavigationProgNameMapping(paramContext, str1);
//		Object localObject = this.localConfigObject.getDefaultVerticalView(this.integrationName);
//		if ((localObject == null) || (((String) localObject).equals("")))
//			return;
//		Vector localVector = (Vector) this.verticalNavigationProgNameMapping.get(localObject);
//		if ((localVector == null) || (localVector.size() <= 0))
//			return;
//		this.verticalViewProgramLabel = ((String) localObject);
//		this.verticalViewProgramName = ((String) localVector.elementAt(0));
//	}
//
//	public void buildDataForParticularVersion(Context paramContext) throws Exception {
//		String str1 = "";
//		String str2 = "";
//
//		IEFXmlNodeImpl localIEFXmlNodeImpl1 = this.saveAsDetailsNode.getChildByName("cadobjectlist");
//		Enumeration localEnumeration = localIEFXmlNodeImpl1.elements();
//
//		Hashtable localHashtable1 = new Hashtable(localIEFXmlNodeImpl1.getChildCount());
//		Hashtable localHashtable2 = new Hashtable(localIEFXmlNodeImpl1.getChildCount());
//
//		this.lateralViewProgramLabel = this.integSessionData.getStringResource("mcadIntegration.Server.Message.lateralViewNameDueToVerticalNavigation");
//		HashSet localHashSet = new HashSet(localIEFXmlNodeImpl1.getChildCount());
//		Object localObject3;
//		Object localObject4;
//		Object localObject5;
//		while (localEnumeration.hasMoreElements()) {
//			localIEFXmlNode = (IEFXmlNode) localEnumeration.nextElement();
//			localObject1 = localIEFXmlNode.getAttribute("objectid");
//			str3 = localIEFXmlNode.getAttribute("rootBusID");
//			str2 = localIEFXmlNode.getAttribute("revision");
//			this.verticalViewProgramName = localIEFXmlNode.getAttribute("appliedverticalview");
//
//			str4 = this.saveAsPageHelper.getLaterallyNavigatedBusObjectID(paramContext, (String) localObject1, str2);
//			this.saveAsPageObject.rootBusID = str4;
//
//			localHashtable1.put(str4, "all");
//
//			localObject2 = null;
//
//			localObject3 = this.util.getAttributeForBO(paramContext, str4, MCADMxUtil.getActualNameForAEFData(paramContext, "attribute_CADType"));
//			boolean bool1 = this.globalConfigObject.isTypeOfClass((String) localObject3, "TYPE_INSTANCE_LIKE");
//			boolean bool2 = this.globalConfigObject.isTypeOfClass((String) localObject3, "TYPE_FAMILY_LIKE");
//
//			if (bool1) {
//				localHashSet.add(str4);
//			} else if (bool2) {
//				localObject4 = new String[1];
//				localObject4[0] = str4;
//
//				localObject2 = this.serverGeneralUtil.getFamilyStructureRecursively(paramContext, localObject4, this.saveAsPageHelper.getFamilyidInstanceStructureTable(), this.saveAsPageHelper.getFamilyidInstanceAttrTable());
//			}
//
//			localObject4 = new ArrayList(2);
//			((ArrayList) localObject4).add("As-Built");
//			((ArrayList) localObject4).add(this.verticalViewProgramLabel);
//
//			if ((localObject2 != null) && (((ArrayList) localObject2).size() > 0)) {
//				for (int i = 0; i < ((ArrayList) localObject2).size(); ++i) {
//					localObject5 = (String) ((ArrayList) localObject2).get(i);
//					localHashtable1.put(localObject5, "all");
//					localHashtable2.put(localObject5, localObject4);
//					localHashSet.add(localObject5);
//				}
//			}
//
//			localHashtable2.put(str4, localObject4);
//		}
//
//		if (localHashtable1.size() > 0) {
//			this.objectExpander.familyIdInstanceStructureTable = this.saveAsPageHelper.getFamilyidInstanceStructureTable();
//			this.objectExpander.addToInstanceLikeIds(localHashSet);
//			this.busIDDependentRelIDsTable = this.objectExpander.getRelationshipAndChildObjectInfoForParent(paramContext, localHashtable1, this.globalConfigObject.getRelationshipsOfClass("AssemblyLike"), new HashMap(0), localHashtable2, true, "As-Built", null, null);
//		}
//
//		this.integSessionData.setSessionObjectByKey("busIDList", this.busIDDependentRelIDsTable);
//		this.integSessionData.setSessionObjectByKey("verticalViewProgram", this.verticalViewProgramName);
//		IEFXmlNode localIEFXmlNode = null;
//		Object localObject1 = null;
//
//		String str3 = "";
//		String str4 = "";
//		Object localObject2 = "";
//
//		localEnumeration = localIEFXmlNodeImpl1.elements();
//		while (localEnumeration.hasMoreElements()) {
//			localObject3 = (IEFXmlNode) localEnumeration.nextElement();
//			str1 = ((IEFXmlNode) localObject3).getAttribute("objectid");
//			str3 = ((IEFXmlNode) localObject3).getAttribute("instancename");
//			str2 = ((IEFXmlNode) localObject3).getAttribute("revision");
//			str4 = ((IEFXmlNode) localObject3).getAttribute("nodeid");
//			String str5 = ((IEFXmlNode) localObject3).getAttribute("grayoutnode");
//			String str6 = this.saveAsPageHelper.getLaterallyNavigatedBusObjectID(paramContext, str1, str2);
//			localObject1 = new Hashtable();
//
//			this.logger.logDebug("[MCADSaveAsPageCreator.getNodesTableForParticularView] busID : " + str1);
//			this.logger.logDebug("[MCADSaveAsPageCreator.getNodesTableForParticularView] instanceName : " + str3);
//			this.logger.logDebug("[MCADSaveAsPageCreator.getNodesTableForParticularView] nodeIDs : " + str4);
//			this.logger.logDebug("[MCADSaveAsPageCreator.getNodesTableForParticularView] GrayOutNode : " + str5);
//
//			localObject4 = (str5.equalsIgnoreCase("true")) ? "false" : "true";
//			IEFXmlNodeImpl localIEFXmlNodeImpl2 = ((IEFXmlNode) localObject3).getChildByName("nodelist");
//
//			localObject5 = getRelationshipColumnValuesTable("true");
//			getNodesRow(paramContext, str6, null, true, true, str4, (String) localObject4, (Hashtable) localObject5, false, true);
//		}
//
//		setSaveAsPageDataForParticularVersion(paramContext, localIEFXmlNodeImpl1);
//	}
//
//	private void setSaveAsPageDataForParticularVersion(Context paramContext, IEFXmlNode paramIEFXmlNode) throws Exception {
//		this.saveAsPageObject.familyNameNodeIDsArray = getFamilyNamesTable();
//		this.saveAsPageObject.verticalViewName = this.verticalViewProgramLabel;
//		this.saveAsPageObject.lateralViewName = this.lateralViewProgramLabel;
//		this.saveAsPageObject.sharedPartIdentityNodeIDsArray = this.sharedPartNameNodeIDsVectorTable;
//		this.saveAsPageObject.verticalViewProgName = this.verticalViewProgramName;
//		this.saveAsPageObject.instanceIDDisplayedFamIDsArray = this.instanceIDExpandedfromFamIDTable;
//	}
//
//	public void buildDataForParticularView(Context paramContext) throws Exception {
//		String str = "true";
//		if (this.localConfigObject.isTurnDebugOn()) {
//			this.logger.logDebug("[MCADSaveAsPageCreator::buildDataForParticularView] Received saveAsDetailsNode:" + this.saveAsDetailsNode.getXmlString());
//		}
//		IEFXmlNodeImpl localIEFXmlNodeImpl = this.saveAsDetailsNode.getChildByName("cadobjectlist");
//		this.verticalViewProgramLabel = this.saveAsDetailsNode.getAttribute("verticalview");
//		str = this.saveAsDetailsNode.getAttribute("applyrecursively");
//		this.lateralViewProgramLabel = this.saveAsDetailsNode.getAttribute("lateralview");
//
//		this.logger.logDebug("[MCADSaveAsPageCreator.buildDataForParticularView] LateralViewProgramLabel : " + this.lateralViewProgramLabel);
//		this.logger.logDebug("[MCADSaveAsPageCreator.buildDataForParticularView] ApplyViewRecursively : " + str);
//		Vector localVector;
//		if (!(this.lateralViewProgramLabel.equalsIgnoreCase("As-Built"))) {
//			localVector = (Vector) this.lateralNavigationProgNameMapping.get(this.lateralViewProgramLabel);
//			Object localObject;
//			if (localVector == null) {
//				localObject = new Hashtable();
//				((Hashtable) localObject).put("PROGRAM", this.lateralViewProgramLabel);
//
//				MCADServerException.createException(this.integSessionData.getStringResource("mcadIntegration.Server.Message.LateralViewProgramIsNotSupported", (Hashtable) localObject), null);
//			}
//
//			this.lateralViewProgramName = ((String) localVector.elementAt(0));
//
//			if (localVector.size() > 1) {
//				localObject = (String) localVector.elementAt(1);
//				if ((localObject != null) && (((String) localObject).equalsIgnoreCase("true")))
//					this.isRecurssiveLateralView = true;
//				else
//					this.isRecurssiveLateralView = false;
//			}
//		} else {
//			this.lateralViewProgramName = "As-Built";
//		}
//
//		if (!(this.verticalViewProgramLabel.equalsIgnoreCase("None"))) {
//			localVector = (Vector) this.verticalNavigationProgNameMapping.get(this.verticalViewProgramLabel);
//			if (localVector != null) {
//				this.verticalViewProgramName = ((String) localVector.elementAt(0));
//			}
//		}
//
//		this.saveAsPageObject.lateralViewName = this.lateralViewProgramLabel;
//		this.saveAsPageObject.verticalViewName = this.verticalViewProgramLabel;
//
//		if (this.lateralViewProgramName != null) {
//			this.saveAsPageObject.programNameForLateralView = this.lateralViewProgramName;
//		}
//		if (this.verticalViewProgramName != null) {
//			this.saveAsPageObject.verticalViewProgName = this.verticalViewProgramName;
//		}
//		getNodesTableForParticularView(paramContext, localIEFXmlNodeImpl, str);
//
//		setSaveAsPageDataForParticularView(paramContext, localIEFXmlNodeImpl);
//	}
//
//	private void getNodesTableForParticularView(Context paramContext, IEFXmlNode paramIEFXmlNode, Object paramObject) throws Exception {
//		Enumeration localEnumeration = paramIEFXmlNode.elements();
//
//		Hashtable localHashtable1 = new Hashtable(10);
//		Hashtable localHashtable2 = new Hashtable(10);
//
//		HashSet localHashSet = new HashSet(paramIEFXmlNode.getChildCount());
//		IEFXmlNode localIEFXmlNode;
//		String str1;
//		Object localObject1;
//		String str2;
//		Object localObject2;
//		while (localEnumeration.hasMoreElements()) {
//			localIEFXmlNode = (IEFXmlNode) localEnumeration.nextElement();
//
//			str1 = localIEFXmlNode.getAttribute("objectid");
//			this.saveAsPageObject.rootBusID = str1;
//
//			localHashtable1.put(str1, "all");
//
//			localObject1 = null;
//
//			str2 = this.util.getAttributeForBO(paramContext, str1, MCADMxUtil.getActualNameForAEFData(paramContext, "attribute_CADType"));
//			boolean bool1 = this.globalConfigObject.isTypeOfClass(str2, "TYPE_INSTANCE_LIKE");
//			boolean bool2 = this.globalConfigObject.isTypeOfClass(str2, "TYPE_FAMILY_LIKE");
//
//			if (bool1) {
//				localHashSet.add(str1);
//			} else if (bool2) {
//				localObject2 = new String[1];
//				localObject2[0] = str1;
//
//				localObject1 = this.serverGeneralUtil.getFamilyStructureRecursively(paramContext, localObject2, this.saveAsPageHelper.getFamilyidInstanceStructureTable(), this.saveAsPageHelper.getFamilyidInstanceAttrTable());
//			}
//
//			localObject2 = new ArrayList(2);
//			((ArrayList) localObject2).add(this.saveAsPageObject.lateralViewName);
//			((ArrayList) localObject2).add(this.verticalViewProgramLabel);
//
//			if ((localObject1 != null) && (((ArrayList) localObject1).size() > 0)) {
//				for (int i = 0; i < ((ArrayList) localObject1).size(); ++i) {
//					String str4 = (String) ((ArrayList) localObject1).get(i);
//					localHashtable1.put(str4, "all");
//					localHashtable2.put(str4, localObject2);
//					localHashSet.add(str4);
//				}
//			}
//			localHashtable2.put(str1, localObject2);
//		}
//
//		if (localHashtable2.size() > 0) {
//			this.objectExpander.familyIdInstanceStructureTable = this.saveAsPageHelper.getFamilyidInstanceStructureTable();
//			this.objectExpander.addToInstanceLikeIds(localHashSet);
//
//			this.busIDDependentRelIDsTable = this.objectExpander.getRelationshipAndChildObjectInfoForParent(paramContext, localHashtable1, this.globalConfigObject.getRelationshipsOfClass("AssemblyLike"), new HashMap(0), localHashtable2, false, "As-Built", null, null);
//		}
//
//		this.integSessionData.setSessionObjectByKey("busIDList", this.busIDDependentRelIDsTable);
//		this.integSessionData.setSessionObjectByKey("verticalViewProgram", this.verticalViewProgramName);
//		localEnumeration = paramIEFXmlNode.elements();
//		while (localEnumeration.hasMoreElements()) {
//			localIEFXmlNode = (IEFXmlNode) localEnumeration.nextElement();
//
//			str1 = localIEFXmlNode.getAttribute("objectid");
//			localObject1 = localIEFXmlNode.getAttribute("instancename");
//			str2 = localIEFXmlNode.getAttribute("nodeid");
//			String str3 = localIEFXmlNode.getAttribute("grayoutnode");
//
//			this.logger.logDebug("[MCADSaveAsPageCreator.getNodesTableForParticularView] busID : " + str1);
//			this.logger.logDebug("[MCADSaveAsPageCreator.getNodesTableForParticularView] instanceName : " + ((String) localObject1));
//			this.logger.logDebug("[MCADSaveAsPageCreator.getNodesTableForParticularView] NodeID : " + str2);
//			this.logger.logDebug("[MCADSaveAsPageCreator.getNodesTableForParticularView] GrayOutNode : " + str3);
//
//			Hashtable localHashtable3 = new Hashtable();
//
//			localObject2 = (str3.equalsIgnoreCase("true")) ? "false" : "true";
//
//			Hashtable localHashtable4 = getRelationshipColumnValuesTable("true");
//			if (paramObject.equals("true")) {
//				this.defaultLateralViewProgramName = this.lateralViewProgramName;
//				getNodesRowForViewAfterRecursiveApplication(paramContext, localIEFXmlNode, str1, null, str2, localHashtable4, null, false);
//			} else {
//				getNodesRowForView(paramContext, str1, null, true, true, str2, (String) localObject2, localHashtable4, localIEFXmlNode);
//			}
//		}
//	}
//
//	private IEFTreeTableNode getNodesRowForViewAfterRecursiveApplication(Context paramContext, IEFXmlNode paramIEFXmlNode, String paramString1, IEFTreeTableNode paramIEFTreeTableNode, String paramString2, Hashtable paramHashtable1, Hashtable paramHashtable2, boolean paramBoolean) throws Exception {
//		if (paramString1 == null) {
//			paramString1 = paramIEFXmlNode.getAttribute("busid");
//		}
//		if (!(this.lateralViewProgramName.equalsIgnoreCase("As-Built"))) {
//			paramString1 = this.pageViews.getRelatedLateralViewBusObjectID(paramContext, paramString1, this.lateralViewProgramName);
//		}
//		IEFTreeTableNode localIEFTreeTableNode = getNodesRow(paramContext, paramString1, null, true, true, paramString2, "true", paramHashtable1, false, paramBoolean);
//
//		return localIEFTreeTableNode;
//	}
//
//	private IEFTreeTableNode getNodesRowForView(Context paramContext, String paramString1, IEFTreeTableNode paramIEFTreeTableNode, boolean paramBoolean1, boolean paramBoolean2, String paramString2, String paramString3, Hashtable paramHashtable, IEFXmlNode paramIEFXmlNode) throws Exception {
//		if (!(this.lateralViewProgramName.equalsIgnoreCase("As-Built"))) {
//			paramString1 = this.pageViews.getRelatedLateralViewBusObjectID(paramContext, paramString1, this.lateralViewProgramName);
//		}
//		String str1 = getUUID();
//		String str2 = "false";
//
//		if (paramString3.equalsIgnoreCase("false")) {
//			str2 = "true";
//		}
//
//		String str3 = null;
//		if (paramIEFTreeTableNode != null) {
//			str3 = paramIEFTreeTableNode.objectID;
//		}
//		String str4 = getNodeData(paramContext, paramString1, str3);
//		String str5 = (String) this.cadIDNodeDataTable.get(str4);
//
//		Hashtable localHashtable = getNodeMatrixData(paramContext, paramString1);
//		String str6 = (String) localHashtable.get("LockedBy");
//		String str7 = ("".equals(str6)) ? "unlocked" : "locked";
//
//		boolean bool = str2.equalsIgnoreCase("true");
//		IEFTreeTableNode localIEFTreeTableNode = null;
//
//		String str8 = "TopDown";
//		if (paramHashtable.containsKey("relArrow")) {
//			str8 = (String) paramHashtable.get("relArrow");
//		}
//		if (paramBoolean2) {
//			localIEFTreeTableNode = new IEFTreeTableNode(paramString2, str5, str4, str7, bool, str8, paramHashtable);
//			this.saveAsPageObject.replaceNode(localIEFTreeTableNode);
//			keepSharedPartInTable(str4, paramString2);
//		} else {
//			localIEFTreeTableNode = paramIEFTreeTableNode.addChild(this.saveAsPageObject, str1, str5, str4, str7, bool, str8, paramHashtable);
//			keepSharedPartInTable(str4, str1);
//		}
//
//		if (paramIEFXmlNode != null) {
//			Enumeration localEnumeration = paramIEFXmlNode.elements();
//			while (localEnumeration.hasMoreElements()) {
//				IEFXmlNode localIEFXmlNode = (IEFXmlNode) localEnumeration.nextElement();
//				getNodesRowForView(paramContext, paramString1, null, true, true, paramString2, paramString3, paramHashtable, localIEFXmlNode);
//			}
//
//		}
//
//		return localIEFTreeTableNode;
//	}
//
//	private void setSaveAsPageDataForParticularView(Context paramContext, IEFXmlNode paramIEFXmlNode) throws Exception {
//		this.saveAsPageObject.familyNameNodeIDsArray = getFamilyNamesTable();
//		this.saveAsPageObject.familyIDInstanceListTable = this.familyIDInstanceListTable;
//		this.saveAsPageObject.verticalViewName = this.verticalViewProgramLabel;
//		this.saveAsPageObject.lateralViewName = this.lateralViewProgramLabel;
//		this.saveAsPageObject.sharedPartIdentityNodeIDsArray = this.sharedPartNameNodeIDsVectorTable;
//		this.saveAsPageObject.verticalViewProgName = this.verticalViewProgramName;
//		this.saveAsPageObject.instanceIDDisplayedFamIDsArray = this.instanceIDExpandedfromFamIDTable;
//	}
//
//	private Hashtable getFamilyNamesTable() {
//		Hashtable localHashtable = new Hashtable();
//		Enumeration localEnumeration = this.familyNameNameNodeIDsVectorTable.keys();
//
//		for (int i = 0; localEnumeration.hasMoreElements(); ++i) {
//			String str = (String) localEnumeration.nextElement();
//			Vector localVector = (Vector) this.familyNameNameNodeIDsVectorTable.get(str);
//			localHashtable.put(str, localVector);
//		}
//		return localHashtable;
//	}
//
//	private void keepFamilyPartInTable(String paramString1, String paramString2) {
//		Vector localVector;
//		if (!(this.familyNameNameNodeIDsVectorTable.containsKey(paramString1))) {
//			localVector = new Vector();
//			localVector.addElement(paramString2);
//			this.familyNameNameNodeIDsVectorTable.put(paramString1, localVector);
//		} else {
//			localVector = (Vector) this.familyNameNameNodeIDsVectorTable.get(paramString1);
//			localVector.addElement(paramString2);
//		}
//	}
//
//	private boolean isCadObjectAlreadyExpanded(String paramString) {
//		int i = 0;
//		if (this.expandedCadObjTreeTableNodesTable.containsKey(paramString)) {
//			IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) this.expandedCadObjTreeTableNodesTable.get(paramString);
//			if ((localIEFTreeTableNode != null) && (localIEFTreeTableNode.hasChildNodes) && (localIEFTreeTableNode.childNodes.size() > 0)) {
//				this.logger.logDebug("[MCADSaveAsPageCreator.isCadObjectAlreadyExpanded]UniqueKey already expanded..." + paramString);
//				i = 1;
//			}
//		}
//		return i;
//	}
//
//	private void addReplicatedNodeID(IEFTreeTableNode paramIEFTreeTableNode) {
//		IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) this.expandedCadObjTreeTableNodesTable.get(paramIEFTreeTableNode.objectID);
//
//		if (this.alreadyExpandedNodesInPath.contains(paramIEFTreeTableNode.objectID))
//			paramIEFTreeTableNode.hasChildNodes = false;
//		else {
//			paramIEFTreeTableNode.hasChildNodes = localIEFTreeTableNode.hasChildNodes;
//		}
//		paramIEFTreeTableNode.replicatedNodeID = localIEFTreeTableNode.nodeID;
//	}
//
//	public IEFSaveAsPage getSaveAsPageObject() {
//		return this.saveAsPageObject;
//	}
//
//	public Hashtable getBusIDNodeMatrixDataTable() {
//		return this.busIDNodeMatrixDataTable;
//	}
//
//	public void setBusIDNodeMatrixDataTable(Hashtable paramHashtable) {
//		this.busIDNodeMatrixDataTable = paramHashtable;
//	}
}