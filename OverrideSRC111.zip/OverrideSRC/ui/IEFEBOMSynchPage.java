/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.matrixone.MCADIntegration.ui;

import java.io.Serializable;
import java.util.Collection;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Hashtable;
import java.util.StringTokenizer;
import java.util.Vector;

import com.matrixone.MCADIntegration.utils.MCADException;
import com.matrixone.MCADIntegration.utils.MCADUtil;
import com.matrixone.MCADIntegration.utils.xml.IEFXmlNode;

public class IEFEBOMSynchPage extends IEFTreeTable implements Serializable {
	public String rootBusIdList;
	public String instanceName;	public String busIdsString;
	public IEFXmlNode EBOMSynchDetailsNode;
	public boolean isNodeSelected;
	public String acceptLannguage;
	public Hashtable familyIDInstanceListTable;
	public boolean isProgressiveLoadingEnabled;
	private static final String FUNCTIONAL_PAGE_NAME = "EBOMSynch";
	private int FORM_COUNTER;
	public String rootBusID;
	public boolean isSystemCaseSensitive;
	public String unsupportedChars;

	public IEFEBOMSynchPage() {
		this.rootBusIdList = "";

		this.instanceName = "";

		this.busIdsString = null;
		this.EBOMSynchDetailsNode = null;

		this.isNodeSelected = false;
		this.acceptLannguage = "";
		this.familyIDInstanceListTable = null;

		this.isProgressiveLoadingEnabled = false;

		this.FORM_COUNTER = 0;

		this.rootBusID = null;

		this.isSystemCaseSensitive = false;
		this.unsupportedChars = null;
	}

	public String getTableData(String paramString) {
		StringBuffer localStringBuffer1 = new StringBuffer();

		this.activeTabName = paramString;
		Object localObject1;
		Object localObject2;
		if ((this.styleClassTable != null) && ("CustomView".equals(paramString))) {
			Enumeration localEnumeration = this.styleClassTable.keys();
			while (localEnumeration.hasMoreElements()) {
				localObject1 = (String) localEnumeration.nextElement();
				localObject2 = (String) this.styleClassTable.get(localObject1);

				localStringBuffer1.append("<STYLE TYPE=\"text/css\">." + ((String) localObject2) + "{" + ((String) localObject1) + "}</style>");
			}
		}

		if ((paramString.trim().equals("")) || (paramString.trim().equals("EBOMSynch"))) {
			this.rowIndx = 0;
			this.totalNumberOfRows = 0;

			for (int i = 0; i < this.rootTreeTableNode.childNodes.size(); ++i) {
				localObject1 = (IEFTreeTableNode) this.rootTreeTableNode.childNodes.elementAt(i);
				((IEFTreeTableNode) localObject1).totalNumberOfRows(this);
			}

			if ((this.maxRowLimit > this.totalNumberOfRows) && (this.minRowLimit != 0) && (this.totalNumberOfRows != 0)) {
				this.minRowLimit -= this.maxRowLimit - this.totalNumberOfRows;
				if (this.minRowLimit > 0) {
					this.maxRowLimit = this.totalNumberOfRows;
				}
			}
			this.rowIndx = 0;

			StringBuffer localStringBuffer2 = new StringBuffer();

			for (int k = 0; k < this.rootTreeTableNode.childNodes.size(); ++k) {
				localObject2 = (IEFTreeTableNode) this.rootTreeTableNode.childNodes.elementAt(k);
				((IEFTreeTableNode) localObject2).writeNodeContent(localStringBuffer2, this);
			}

			localStringBuffer1.append("<tr id='empty'><td bgcolor='" + IEFTreeTable.GRAYED_OUT_COLOR + "' height='" + this.topInvisibleNodeHeight + "' colspan='");
			localStringBuffer1.append(getColumnCount("") * 2 + 8);
			localStringBuffer1.append("'></td></tr>");

			localStringBuffer1.append(localStringBuffer2);

			localStringBuffer1.append("<tr id='empty'><td bgcolor='" + IEFTreeTable.GRAYED_OUT_COLOR + "' height='" + this.bottomInvisibleNodeHeight + "' colspan='");
			localStringBuffer1.append(getColumnCount("") * 2 + 8);
			localStringBuffer1.append("'></td></tr>");
		} else if (paramString.trim().equals("CustomView")) {
			this.rowIndx = 0;
			this.totalNumberOfRows = 0;

			for (int j = 0; j < this.rootTreeTableNode.childNodes.size(); ++j) {
				IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) this.rootTreeTableNode.childNodes.elementAt(j);
				localIEFTreeTableNode.totalNumberOfRows(this);
			}

			if ((this.maxRowLimit > this.totalNumberOfRows) && (this.minRowLimit != 0) && (this.totalNumberOfRows != 0)) {
				this.minRowLimit -= this.maxRowLimit - this.totalNumberOfRows;
				if (this.minRowLimit > 0) {
					this.maxRowLimit = this.totalNumberOfRows;
				}
			}
			this.rowIndx = 0;

			StringBuffer localStringBuffer3 = new StringBuffer();

			for (int l = 0; l < this.rootTreeTableNode.childNodes.size(); ++l) {
				localObject2 = (IEFTreeTableNode) this.rootTreeTableNode.childNodes.elementAt(l);
				((IEFTreeTableNode) localObject2).writeNodeContent(localStringBuffer3, this);
			}

			localStringBuffer1.append("<tr id='empty'><td bgcolor='" + IEFTreeTable.GRAYED_OUT_COLOR + "' height='" + this.topInvisibleNodeHeight + "' colspan='");
			localStringBuffer1.append(getColumnCount("") * 2 + 8);
			localStringBuffer1.append("'></td></tr>");

			localStringBuffer1.append(localStringBuffer3);

			localStringBuffer1.append("<tr id='empty'><td bgcolor='" + IEFTreeTable.GRAYED_OUT_COLOR + "' height='" + this.bottomInvisibleNodeHeight + "' colspan='");
			localStringBuffer1.append(getColumnCount("") * 2 + 8);
			localStringBuffer1.append("'></td></tr>");
		}

		return ((String) (String) localStringBuffer1.toString());
	}

	public void setFormData(StringBuffer paramStringBuffer, IEFTreeTableNode paramIEFTreeTableNode) {
		if (this.activeTabName.trim().equals("CustomView")) {
			writeCustomViewContent(paramStringBuffer, paramIEFTreeTableNode);
			return;
		}

		Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(paramIEFTreeTableNode.objectID);
		Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
		Hashtable localHashtable3 = (Hashtable) localHashtable1.get("CellTypes");
		HashMap localHashMap = (HashMap) localHashtable2.get("NLSTABLEFORADMINTYPES");

		String str1 = "form" + (this.FORM_COUNTER++);

		Hashtable localHashtable4 = (Hashtable) this.tabsDataTable.get("EBOMSynch");
		Vector localVector = (Vector) localHashtable4.get("TableColumnData");
		for (int i = 0; i < localVector.size(); ++i) {
			Hashtable localHashtable5 = (Hashtable) localVector.elementAt(i);

			String str2 = (String) localHashtable5.get("ColumnID");

			String str3 = (String) localHashtable3.get(str2);

			String str4 = (String) localHashMap.get(str2);

			if ((str4 == null) || ("".equals(str4))) {
				str4 = (String) localHashtable2.get(str2);
			}

			if (str2.equalsIgnoreCase("ActionStatus")) {
				str4 = this.uiObjectHelper.getString("mcadIntegration.Applet.Label." + str4);
			}
			String str5 = (String) localHashtable2.get("ActionStatus");

			if (str3.equalsIgnoreCase(COTROL_LABEL_TYPE)) {
				str4 = MCADUtil.escapeStringForHTML(str4);
				if (str2.equalsIgnoreCase("EBOM")) {
					if (str5.equalsIgnoreCase("New")) {
						paramStringBuffer.append("<td align='left' nowrap='true'><font name = \"verdana\" color = \"DarkGreen\"><B>" + str4 + "</B></font></td>");
					} else if (str5.equalsIgnoreCase("Remove")) {
						paramStringBuffer.append("<td align='left' nowrap='true'><font color = \"Red\"><S>" + str4 + "</S></font></td>");
					} else {
						paramStringBuffer.append("<td align='left' nowrap='true'>" + str4 + "</td>");
					}
				} else if (str2.equalsIgnoreCase("Alert")) {
					String str6 = (String) localHashtable2.get("Alert");
					if ("true".equalsIgnoreCase(str6)) {
						String str7 = this.uiObjectHelper.getString("mcadIntegration.Applet.ToolTipText.EBOMSynchornizationAlredyDoneOnOtherInstance");

						paramStringBuffer.append("<td align='left' nowrap='true'><img src=\"");
						paramStringBuffer.append(IMG_ICON_ALERT);
						paramStringBuffer.append("\" title=\"");
						paramStringBuffer.append(str7);
						paramStringBuffer.append("\" border=\"0\" width=\"16\" height=\"16\" /> </td>");
					} else {
						paramStringBuffer.append("<td align='left' nowrap='true'> </td>");
					}
				// [B] modify by jtkim 2016-12-01
				// [CATIA-001] Add EBOM Sync Table column
				} else if (str2.equalsIgnoreCase("Validation")) {
					if (str4.equalsIgnoreCase("Error")) {
						paramStringBuffer.append("<td align=\'left\' nowrap=\'true\'><font name = \"verdana\" color = \"Red\"><B>" + str4 + "</B></font></td>");
					} else {
						paramStringBuffer.append("<td align=\'left\' nowrap=\'true\'>" + str4 + "</td>");
					}
				} else if (str2.equalsIgnoreCase("Error Reason")) {
					paramStringBuffer.append("<td align=\'left\' nowrap=\'true\'><font name = \"verdana\" color = \"Red\"><B>" + str4 + "</B></font></td>");
				} else if (str2.equals("ECONO")) {
					if (str5.equalsIgnoreCase("New")) {
						paramStringBuffer.append("<td align=\'left\' nowrap=\'true\'>").append("<input type=\"text\" readonly=\'true\' name=\"ECONO\" value=\"").append(str4).append("\"/></td>");
					} else {
						paramStringBuffer.append("<td align=\'left\' nowrap=\'true\'>" + str4 + "</td>");
					}
				} else {
				// [E] modify by jtkim 2016-12-01
					paramStringBuffer.append("<td align='left' nowrap='true'>" + str4 + "</td>");
				}

				paramStringBuffer.append("<td><img src=\"" + IMG_LINE_VERT + "\" width=\"16\" height=\"24\" /></td>");
			} else {
				if (!(str3.equalsIgnoreCase(COTROL_EDITBOX_TYPE)))
					continue;
				paramStringBuffer.append("<td align='center'><input type=\"text\" name=\"" + str2 + "\" value=\"" + str4 + "\" size=\"10\" onChange=\"parent.changeNodeCellValue('" + paramIEFTreeTableNode.nodeID + "',this)\"/></td>");
				paramStringBuffer.append("<td><img src=\"" + IMG_LINE_VERT + "\" width=\"16\" height=\"24\" /></td>");
			}
		}
	}

	private void writeCustomViewContent(StringBuffer paramStringBuffer, IEFTreeTableNode paramIEFTreeTableNode) {
		Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(paramIEFTreeTableNode.objectID);
		Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");

		String str1 = (String) localHashtable2.get("CueClass");

		String str2 = "form" + (this.FORM_COUNTER++);

		if ((str1 != null) && (!("".equals(str1)))) {
			str1 = "class=\"" + str1 + "\"";
		} else {
			str1 = "";
		}

		Hashtable localHashtable3 = (Hashtable) this.tabsDataTable.get("CustomView");
		Vector localVector1 = (Vector) localHashtable3.get("TableColumnData");

		if (localHashtable2.containsKey("CustomTable")) {
			Vector localVector2 = (Vector) localHashtable2.get("CustomTable");
			int j;
			String str4;
			if (localVector2.size() == localVector1.size()) {
				for (j = 0; j < localVector1.size(); ++j) {
					str4 = (String) localVector2.elementAt(j);
					str4 = MCADUtil.escapeStringForHTML(str4);
					paramStringBuffer.append("<td " + str1 + " align='left' nowrap='true'>" + str4 + "</td>");
					paramStringBuffer.append("<td><img src=\"" + IMG_LINE_VERT + "\" width=\"16\" height=\"24\" /></td>");
				}

			} else {
				for (j = 0; j < localVector1.size(); ++j) {
					str4 = "";
					paramStringBuffer.append("<td " + str1 + " align='left' nowrap='true'>" + str4 + "</td>");
					paramStringBuffer.append("<td><img src=\"" + IMG_LINE_VERT + "\" width=\"16\" height=\"24\" /></td>");
				}
			}
		} else {
			for (int i = 0; i < localVector1.size(); ++i) {
				String str3 = "";
				paramStringBuffer.append("<td " + str1 + " align='left' nowrap='true'>" + str3 + "</td>");
				paramStringBuffer.append("<td><img src=\"" + IMG_LINE_VERT + "\" width=\"16\" height=\"24\" /></td>");
			}
		}
	}

	public String submitPage(String paramString) {
		String str1 = TRUE;

		this.metaMaxCount = 0;
		try {
			String str2 = isEBOMRestrictedOnDesign();
			if (!("".equals(str2))) {
				return str2;
			}

			this.uiObjectHelper.uiObjectActivityStarted();

			this.selectedPageData = getSelectedNodesData();

			this.uiObjectHelper.uiObjectActivityEnded();

			updateProgressBarData(false);
			this.uiObjectHelper.callCommandHandler(this.integrationName, "ebomSynchSelected", paramString, false);
		} catch (Exception localException) {
			this.uiObjectHelper.uiObjectActivityEnded();
			this.uiObjectHelper.printStackTrace(localException);

			str1 = localException.getMessage();
		}

		return str1;
	}

	private Hashtable getSelectedNodesData() throws Exception {
		Hashtable localHashtable = new Hashtable();
		
		// [B] modify by jtkim 2016-12-01
		// [CATIA-002] Add EBOM Sync Parameter
		StringBuffer localStringBuffer = new StringBuffer(20);
		HashSet localHashSet = new HashSet();
		Vector localVector1 = this.getTreeTableRootNodes();

		for (int str1 = 0; str1 < localVector1.size(); ++str1) {
			IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) localVector1.elementAt(str1);
			if (rootBusID.equals(localIEFTreeTableNode.objectID)) {
				Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(localIEFTreeTableNode.objectID);
				Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
				HashMap localHashMap = (HashMap) localHashtable2.get("NLSTABLEFORADMINTYPES");
				String partType = (String) localHashMap.get("PartType");
				if ("Phantom Part".equals(partType)) localHashtable.put("isRootPhantomPart", "true");
			}
			this.setSelectedNodes(localIEFTreeTableNode, localStringBuffer, localHashSet);
		}

		String arg6 = MCADUtil.getStringFromCollection(localHashSet, "@");
		localHashtable.put("ObjectViewInfo", arg6);
		// [E] modify by jtkim 2016-12-01

		localHashtable.put("IntegrationName", getIntegrationName(""));
		localHashtable.put("busId", this.rootBusID);

		if ((this.instanceName != null) && (!("".equals(this.instanceName)))) {
			localHashtable.put("instanceName", this.instanceName);
		}

		return localHashtable;
	}

	protected void updateProgressBarData(boolean paramBoolean) {
		this.metaMaxCount += 1;
	}

	public String getFunctionalPageName() {
		return "EBOMSynch";
	}

	public String getProgressBarQueryString() {
		return "progessWindowType=MetaData&metaMaxCount=" + this.metaMaxCount + "&fileMaxCount=" + this.fileMaxCount;
	}

	public boolean isGrayOutMsgRequired() {
		int i = 0;

		Enumeration localEnumeration = this.nodeIDtreeTableNodeTable.elements();
		while (localEnumeration.hasMoreElements()) {
			IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) localEnumeration.nextElement();

			if (localIEFTreeTableNode.makeNodeGrayed) {
				i = 1;
				break;
			}
		}

		return i == 0 ? false : true;
	}

	public String isEBOMRestrictedOnDesign() {
		StringBuffer localStringBuffer = new StringBuffer("");

		Enumeration localEnumeration = this.nodeIDtreeTableNodeTable.elements();
		while (localEnumeration.hasMoreElements()) {
			IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) localEnumeration.nextElement();
			Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(localIEFTreeTableNode.objectID);
			Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
			String str1 = (String) localHashtable2.get("isEBOMRestricted");

			if (str1.startsWith("true|")) {
				str1 = str1.substring(5);
				StringTokenizer localStringTokenizer = new StringTokenizer(str1, "|");

				if ((localStringTokenizer.hasMoreTokens()) && (localStringTokenizer.countTokens() == 6)) {
					Hashtable localHashtable3 = new Hashtable();
					localHashtable3.put("TYPE1", localStringTokenizer.nextToken());
					localHashtable3.put("NAME1", localStringTokenizer.nextToken());
					localHashtable3.put("REV1", localStringTokenizer.nextToken());

					localHashtable3.put("TYPE2", localStringTokenizer.nextToken());
					localHashtable3.put("NAME2", localStringTokenizer.nextToken());
					localHashtable3.put("REV2", localStringTokenizer.nextToken());

					String str2 = this.uiObjectHelper.getString("mcadIntegration.Applet.Message.CantEBOMOnObjectHavingStructureDiffWithStructureDetails", localHashtable3);
					localStringBuffer.append(str2);
					localStringBuffer.append("\n");
					break;
				}

			}
			// [B] Modify by jtkim 2016-10-17
			// [CATIA-003] Add EBOM Sync Validation
			String str2 = (String) localHashtable2.get("Validation");
			if ("Error".equals(str2)) {
				String str3 = this.uiObjectHelper.getString("mcadIntegration.Client.Message.EBOMSyncValidationMsg");
				localStringBuffer.append(str3);
				break;
			}

			String ecoNo = (String) localHashtable2.get("ECONO");
			String actionStatus = (String) localHashtable2.get("ActionStatus");
			String projectId = (String) localHashtable2.get("PROJECTID");
			System.out.println("[SYNC-LOG] :: ecoNo >> " + ecoNo + " actionStatus >> " + actionStatus + " projectId >> " + projectId);
			if ("New".equals(actionStatus)) {
				if (ecoNo == null || "".equals(ecoNo)) {
					String errorMsg = this.uiObjectHelper.getString("mcadIntegration.Client.Message.EBOMSyncECOValidationMsg");
					localStringBuffer.append(errorMsg);
					break;
				}

				if (projectId == null || "".equals(projectId)) {
					String errorMsg = this.uiObjectHelper.getString("mcadIntegration.Client.Message.EBOMSyncProjectValidationMsg");
					localStringBuffer.append(errorMsg);
					break;
				}
			}
			// [E] Modify by jtkim 2016-10-17
		}

		return localStringBuffer.toString();
	}
	
	//
	private void setSelectedNodes(IEFTreeTableNode paramIEFTreeTableNode, StringBuffer paramStringBuffer, Collection paramCollection) throws Exception {
		Enumeration localEnumeration = this.objectIDNodeDataTable.keys();
		while (localEnumeration.hasMoreElements()) {
			String tableKey = (String) localEnumeration.nextElement();
			Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(tableKey);
			Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
			HashMap localHashMap = (HashMap) localHashtable2.get("NLSTABLEFORADMINTYPES");

			String ID = (String) localHashtable2.get("ID");
			String Name = (String) localHashtable2.get("Name");
			String ActionStatus = (String) localHashtable2.get("ActionStatus");
			String ECONO = (String) localHashtable2.get("ECONO");
			String ecoId = (String) localHashtable2.get("ECOID");
			String projectId = (String) localHashtable2.get("PROJECTID");
			String ebomPartType = (String) localHashMap.get("PartType");
			String isDrawingNo = (String) localHashtable2.get("isCheckDrawingNo");

			StringBuffer localStringBuffer = new StringBuffer();

			
			localStringBuffer.append(ID);
			localStringBuffer.append("|");

			localStringBuffer.append(Name);
			localStringBuffer.append("|");

			localStringBuffer.append(ActionStatus);
			localStringBuffer.append("|");

			localStringBuffer.append(ECONO);
			localStringBuffer.append("|");

			localStringBuffer.append(ecoId);
			localStringBuffer.append("|");

			localStringBuffer.append(projectId);
			localStringBuffer.append("|");

			localStringBuffer.append(ebomPartType);
			localStringBuffer.append("|");

			localStringBuffer.append(isDrawingNo);
			localStringBuffer.append("|");

			paramCollection.add(localStringBuffer.toString());
		}
	}

	public String updateECONo(String changeName) throws MCADException {
		String str1 = TRUE;

		try {
			Enumeration localEnumeration = this.objectIDNodeDataTable.keys();
			String preEcoNo = null;
			String actionStatus = null;
			String tableKey = null;
			while (localEnumeration.hasMoreElements()) {
				tableKey = (String) localEnumeration.nextElement();
				Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(tableKey);
				Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
				
				preEcoNo = (String) localHashtable2.get("connectECO");
				actionStatus = (String) localHashtable2.get("ActionStatus");
				
				if ("false".equals(preEcoNo) && "New".equals(actionStatus)) {
					localHashtable2.put("ECONO", changeName);
				}
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str1;
	}
	
	public String updateECOId(String changeId) throws MCADException {
		String str1 = TRUE;

		try {
			Enumeration localEnumeration = this.objectIDNodeDataTable.keys();
			String preEcoNo = null;
			String actionStatus = null;
			String tableKey = null;
			while (localEnumeration.hasMoreElements()) {
				tableKey = (String) localEnumeration.nextElement();
				Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(tableKey);
				Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
				
				preEcoNo = (String) localHashtable2.get("connectECO");
				actionStatus = (String) localHashtable2.get("ActionStatus");
				
				if ("false".equals(preEcoNo) && "New".equals(actionStatus)) {
					localHashtable2.put("ECOID", changeId);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str1;
	}

	public String updateProject(String projectId) throws MCADException {
		String str1 = TRUE;

		try {
			Enumeration localEnumeration = this.objectIDNodeDataTable.keys();
			String actionStatus = null;
			String tableKey = null;
			while (localEnumeration.hasMoreElements()) {
				tableKey = (String) localEnumeration.nextElement();
				Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(tableKey);
				Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
				
				actionStatus = (String) localHashtable2.get("ActionStatus");
				
				if ("New".equals(actionStatus)) {
					localHashtable2.put("PROJECTID", projectId);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str1;
	}

	public String updateEBOMPartType(String paramString) throws MCADException {
		String str1 = TRUE;

		try {
			Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(rootBusID);
			Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
			HashMap localHashMap = (HashMap) localHashtable2.get("NLSTABLEFORADMINTYPES");
			localHashMap.put("PartType", paramString);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str1;
	}
	
	public String checkDrawingNumber(String paramString) throws MCADException {
		String str1 = TRUE;

		try {
			Enumeration localEnumeration = this.objectIDNodeDataTable.keys();
			String actionStatus = null;
			String tableKey = null;
			while (localEnumeration.hasMoreElements()) {
				tableKey = (String) localEnumeration.nextElement();
				Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(tableKey);
				Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
				localHashtable2.put("isCheckDrawingNo", paramString);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return str1;
	}

	public String getRootHas3DPart(String paramString) throws MCADException {
		String result = "";

		try {
			Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(this.rootBusID);
			Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
			result = (String) localHashtable2.get("has3DPart");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String getRootEBOMPartPhase(String paramString) throws MCADException {
		String result = "";
		try {
			Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(this.rootBusID);
			Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
			result = (String) localHashtable2.get("ebomPartPhase");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}
	//
}