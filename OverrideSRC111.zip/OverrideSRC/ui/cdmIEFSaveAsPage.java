/*** Eclipse Class Decompiler plugin, copyright (c) 2016 Chen Chao (cnfree2000@hotmail.com) ***/
package com.matrixone.MCADIntegration.ui;

import java.io.Serializable;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Vector;

import com.matrixone.MCADIntegration.utils.MCADException;
import com.matrixone.MCADIntegration.utils.MCADUtil;

public class cdmIEFSaveAsPage extends IEFSaveAsPage implements Serializable {
	private static final long serialVersionUID = 1L;
	private int FORM_COUNTER;

	public cdmIEFSaveAsPage() {
//		this.rootBusID = "";
//		this.instanceName = "";
//		this.verticalViewName = null;
//		this.lateralViewName = null;
//		this.verticalViewProgName = null;
//
//		this.selectedFolderNameWidth = null;
//		this.folderPathListWidth = null;
//		this.folderPathListHeight = null;
//		this.selectedPartNameWidth = null;
//
//		this.verticalNavigationProgNameMapping = null;
//		this.programNameForLateralView = "";
//		this.isProgressiveLoadingEnabled = false;
//		this.saveAsDetailsNode = null;
//
//		this.isSystemCaseSensitive = false;
//		this.isBulkLoadingCheckinEnabled = false;
//
//		this.isMatchCADModelRevisionForPart = false;
//
//		this.unsupportedChars = null;
//
//		this.assignedFolderInfTable = null;
//		this.familyIDInstanceListTable = null;
//		this.familyNameNodeIDsArray = null;
//		this.instanceIDDisplayedFamIDsArray = null;
//		this.nameTypeMultipleRevisionsTable = new Hashtable();

		this.FORM_COUNTER = 0;

//		this.unitSeparator = MCADAppletServletProtocol.UNIT_SEPERATOR;
//		this.recordSeparator = MCADAppletServletProtocol.RECORD_SEPERATOR;
//		this.groupSeparator = MCADAppletServletProtocol.GROUP_SEPERATOR;
//
//		this.isLateralNavigationAllowed = false;
//		this.partNameCADIDMap = new HashMap();
//		this.wholeStructure = true;
	}

	public void setFormData(StringBuffer paramStringBuffer, IEFTreeTableNode paramIEFTreeTableNode) {
		try {
			if (this.activeTabName.trim().equals("CustomView")) {
				writeCustomViewContent(paramStringBuffer, paramIEFTreeTableNode);
				return;
			}

			Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(paramIEFTreeTableNode.objectID);
			Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
			Hashtable localHashtable3 = (Hashtable) localHashtable1.get("CellTypes");
			Hashtable localHashtable4 = (Hashtable) localHashtable1.get("Options");
			HashMap localHashMap = (HashMap) localHashtable2.get("NLSTABLEFORADMINTYPES");
	
			String str1 = (String) localHashtable2.get("Selected");
	
			String str2 = (String) localHashtable2.get("StdPart");
			String str3 = (String) localHashtable2.get("CommonPart");
			this.uiObjectHelper.logDebugMessage(new StringBuilder().append("[IEFSaveAsPage.setFormData] stdPart:").append(str2).append(" commonPart:").append(str3).toString());
	
			String str4 = new StringBuilder().append("form").append(this.FORM_COUNTER++).toString();
			String str5 = "";
			if ((str2 != null) && (str3 != null) && (((str2.equalsIgnoreCase("true")) || (str3.equalsIgnoreCase("true"))))) {
				str5 = "disabled ='true'";
			}
	
			paramStringBuffer.append(new StringBuilder().append("<td align='center'><input type=\"checkbox\" name=\"picked\" ").append((str1.equalsIgnoreCase("true")) ? "checked='true'" : "").append(str5).append(" onClick=\"parent.changeNodeSelection('").append(paramIEFTreeTableNode.nodeID).append("',this)\"/></td>").toString());
			paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());
	
			Hashtable localHashtable5 = (Hashtable) this.tabsDataTable.get("SaveAs");
			Vector localVector1 = (Vector) localHashtable5.get("TableColumnData");
			for (int i = 0; i < localVector1.size(); ++i) {
				Hashtable localHashtable6 = (Hashtable) localVector1.elementAt(i);
				String str6 = (String) localHashtable6.get("ColumnID");
				Hashtable localHashtable7 = paramIEFTreeTableNode.relationshipColumnValues;
				String str7;
				if ((localHashtable7 != null) && (localHashtable7.size() > 0) && false) {
					str7 = (String) paramIEFTreeTableNode.relationshipColumnValues.get(str6);
					if (str7 != null) {
						paramStringBuffer.append(new StringBuilder().append("<td align='center' nowrap='true'>").append(str7).append("</td>").toString());
						paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());
					}
	
				} else {
					str7 = (String) localHashtable3.get(str6);
					String str8 = (String) localHashMap.get(str6);
					String str9 = (String) localHashtable2.get("CADType");
	
					if ((str8 == null) || ("".equals(str8))) {
						str8 = (String) localHashtable2.get(str6);
					}
	
					String str10 = (String) localHashtable2.get("IsLateralNavigationRequired");
					if (localHashtable7 != null) {
						str10 = (String) localHashtable7.get("IsLateralNavigationRequired");
					}
					if ((((str6.equals("Version")) || (str6.equals("Revision")))) && (str10 != null) && (str10.equals(FALSE))) {
						paramStringBuffer.append(new StringBuilder().append("<td align='left' nowrap='true'>").append(str8).append("</td>").toString());
						paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());
					} else {
						String str11 = "";
	
						if (str6.equals("SaveAsTitle")) {
							String str12 = (String) localHashtable2.get("HasFiles");
	
							if (str12.equals("true")) {
								str11 = this.uiObjectHelper.getString("mcadIntegration.Client.Message.EnterFilenameWithoutExtension");
							} else {
								str11 = this.uiObjectHelper.getString("mcadIntegration.Client.Message.EnterInstanceName");
							}
	
						}
	
						if (str7.equalsIgnoreCase(COTROL_LABEL_TYPE)) {
							str8 = MCADUtil.escapeStringForHTML(str8);
	
							paramStringBuffer.append(new StringBuilder().append("<td align='left' nowrap='true'>").append(str8).append("</td>").toString());
							paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());
						} else if (str7.equalsIgnoreCase(COTROL_EDITBOX_TYPE)) {
							// [B] modify by jtkim 2016-11-02
							if ("SaveAs".equals(str6)) {
								paramStringBuffer.append(new StringBuilder().append("<td align='center'><input type=\"text\" readonly='true' name=\"").append(str6).append("\" value=\"").append(str8).append("\" size=\"30\" onChange=\"parent.changeNodeCellValue('").append(paramIEFTreeTableNode.nodeID).append("',this)\" title=\"").append(str11).append("\"/>").append("<input class=\"button\" type=\"button\" name=\"PartNumber\" size=\"200\" value=\"...\" onclick=\"parent.showPartNumber('").append(paramIEFTreeTableNode.nodeID).append("')\"/></td>").toString());
								paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());
							} else {
								paramStringBuffer.append(new StringBuilder().append("<td align='center'><input type=\"text\" readonly='true' name=\"").append(str6).append("\" value=\"").append(str8).append("\" size=\"10\" onChange=\"parent.changeNodeCellValue('").append(paramIEFTreeTableNode.nodeID).append("',this)\" title=\"").append(str11).append("\"/></td>").toString());
								paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());								
							}
							// [E] modify by jtkim 2016-11-02
						} else if (str7.equalsIgnoreCase(CONTROL_READONLYTEXTBOX_TYPE)) {
							paramStringBuffer.append(new StringBuilder().append("<td align='center'><input type=\"text\" name=\"").append(str6).append("\" value=\"").append(str8).append("\" size=\"10\" readonly='true' title=\"").append(str11).append("\"/></td>").toString());
							paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());
						} else if (str7.equalsIgnoreCase(CONTROL_ASSIGN_PART_TYPE)) {
							setAssignPartCellContent(paramStringBuffer, paramIEFTreeTableNode, localHashtable2, str4);
						} else if (str7.equalsIgnoreCase("AssignFolder")) {
							try {
								setAssignFolderCellContent(paramStringBuffer, paramIEFTreeTableNode, localHashtable2, str9);
							} catch (MCADException localMCADException) {
								localMCADException.printStackTrace();
							}
						} else if (str7.equalsIgnoreCase(COTROL_COMBOBOX_TYPE)) {
							Vector localVector2 = (Vector) localHashtable4.get(str6);
	
							paramStringBuffer.append(new StringBuilder().append("<td align='center'><select name=\"").append(str6).append("\" onChange=\"parent.changeNodeCellValue('").append(paramIEFTreeTableNode.nodeID).append("',this)\"").toString());
	
							paramStringBuffer.append(">");
	
							setSelectControlOptions(str8, localVector2, paramStringBuffer);
							paramStringBuffer.append("</select></td>");
							paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());
						} else {
							if (!(str7.startsWith(CONTROL_CUSTOM_PREFIX)))
								continue;
							paramStringBuffer.append(getExtendedCellContent(paramIEFTreeTableNode, str6, str7, str8));
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void writeCustomViewContent(StringBuffer paramStringBuffer, IEFTreeTableNode paramIEFTreeTableNode) {
		Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(paramIEFTreeTableNode.objectID);
		Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");

		String str1 = (String) localHashtable2.get("Selected");
		String str2 = (String) localHashtable2.get("CueClass");

		String str3 = new StringBuilder().append("form").append(this.FORM_COUNTER++).toString();

		paramStringBuffer.append(new StringBuilder().append("<td align='center'><input type=\"checkbox\" name=\"picked\" ").append((str1.equalsIgnoreCase("true")) ? "checked='true'" : "").append(" onClick=\"parent.changeNodeSelection('").append(paramIEFTreeTableNode.nodeID).append("',this)\"/></td>").toString());
		paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());

		if ((str2 != null) && (!("".equals(str2))))
			str2 = new StringBuilder().append("class=\"").append(str2).append("\"").toString();
		else {
			str2 = "";
		}
		Hashtable localHashtable3 = (Hashtable) this.tabsDataTable.get("CustomView");
		Vector localVector1 = (Vector) localHashtable3.get("TableColumnData");

		if (localHashtable2.containsKey("CustomTable")) {
			Vector localVector2 = (Vector) localHashtable2.get("CustomTable");
			int j;
			String str5;
			if (localVector2.size() == localVector1.size()) {
				for (j = 0; j < localVector1.size(); ++j) {
					str5 = (String) localVector2.elementAt(j);
					str5 = MCADUtil.escapeStringForHTML(str5);
					paramStringBuffer.append(new StringBuilder().append("<td ").append(str2).append(" align='left' nowrap='true'>").append(str5).append("</td>").toString());
					paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());
				}

			} else {
				for (j = 0; j < localVector1.size(); ++j) {
					str5 = "";
					paramStringBuffer.append(new StringBuilder().append("<td ").append(str2).append(" align='left' nowrap='true'>").append(str5).append("</td>").toString());
					paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());
				}
			}
		} else {
			for (int i = 0; i < localVector1.size(); ++i) {
				String str4 = "";
				paramStringBuffer.append(new StringBuilder().append("<td ").append(str2).append(" align='left' nowrap='true'>").append(str4).append("</td>").toString());
				paramStringBuffer.append(new StringBuilder().append("<td><img src=\"").append(IMG_LINE_VERT).append("\" width=\"16\" height=\"24\" /></td>").toString());
			}
		}
	}
	
	public void updateSinglePartNumber(String paramString) throws MCADException {
		Enumeration localEnumeration = MCADUtil.getTokensFromString(paramString, "|");

		String objectId = (String) localEnumeration.nextElement();
		String partNumber = (String) localEnumeration.nextElement();

		Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(objectId);
		Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");

		localHashtable2.put("SaveAs", partNumber);
		localHashtable2.put("preSaveAs", partNumber);
	}

	public void updateMultiPartNumber(String paramString) throws MCADException {
		String str1 = TRUE;

		try {
			Enumeration localEnumeration = this.objectIDNodeDataTable.keys();
			String selected = null;
			String tableKey = null;
			while (localEnumeration.hasMoreElements()) {
				tableKey = (String) localEnumeration.nextElement();
				Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(tableKey);
				Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
				
				selected = (String) localHashtable2.get("Selected");
				if ("true".equalsIgnoreCase(selected)) {
					localHashtable2.put("SaveAs", paramString);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public String checkRootNode(String paramString) throws MCADException {
		String result = "";
		try {
			IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) this.nodeIDtreeTableNodeTable.get(paramString);
			String selectBusId = localIEFTreeTableNode.objectID;
			if (rootBusID.equals(selectBusId)) result = "true";
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String getTableObjectId(String nodeId) throws MCADException {
		String result = "";
		try {
			IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) this.nodeIDtreeTableNodeTable.get(nodeId);
			result = localIEFTreeTableNode.objectID;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String getTableObjectValue(String paramString) throws MCADException {
		String result = "";
		try {
			Enumeration localEnumeration = MCADUtil.getTokensFromString(paramString, "|");

			String nodeId = (String) localEnumeration.nextElement();
			String selectValue = (String) localEnumeration.nextElement();

			String objectId = getTableObjectId(nodeId);
			Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(objectId);
			Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");
			result = (String) localHashtable2.get(selectValue);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	public String changeSelectionForAll(String paramString) {
		String str1 = TRUE;

		Enumeration localEnumeration = this.objectIDNodeDataTable.elements();
		while (localEnumeration.hasMoreElements()) {
			Hashtable localHashtable1 = (Hashtable) localEnumeration.nextElement();
			Hashtable localHashtable2 = (Hashtable) localHashtable1.get("Values");

			String str2 = (String) localHashtable2.get("TargetRev");
			String str3 = (String) localHashtable2.get("AssignFolderEnable");
			String str4 = (String) localHashtable2.get("DefaultAssignFolder");
			String str5 = (String) localHashtable2.get("StdPart");
			String str6 = (String) localHashtable2.get("CommonPart");
			String str7 = (String) localHashtable2.get("TargetName");

			// [B] Set New Part Number
			str7 = (String) localHashtable2.get("preSaveAs");
			// [E] Set New Part Number

			int i = 0;
			int j = 0;
			if ((str5 != null) && (str5.equalsIgnoreCase("true"))) {
				i = 1;
			}

			if ((str6 != null) && (str6.equalsIgnoreCase("true"))) {
				j = 1;
			}

			String str8 = (String) localHashtable2.get("IsPartAssignmentEnable");

			String str9 = (String) localHashtable2.get("IsObjectAndFileNameDifferent");

			boolean bool = str9.equals("true");

			String str10 = "";
			if (str9.equals("true")) {
				str10 = (String) localHashtable2.get("AutoName");
			}

			Hashtable localHashtable3 = (Hashtable) localHashtable1.get("CellTypes");
			if (paramString.equalsIgnoreCase(TRUE)) {
				if (bool) {
					localHashtable3.put("SaveAsTitle", "EditBox");
				} else if ((str8.equalsIgnoreCase("true")) || (i != 0) || (j != 0))
					localHashtable3.put("SaveAs", "ReadOnlyTextBox");
				else {
					localHashtable3.put("SaveAs", "EditBox");
				}

				if ((i != 0) || (j != 0)) {
					localHashtable3.put("TargetRevision", "ReadOnlyTextBox");
					localHashtable3.put("Revision", "Label");
					localHashtable2.put("IsAssignFolderEnable", "false");
					localHashtable2.put("AssignFolder", str4);
				} else {
					localHashtable3.put("TargetRevision", "EditBox");
					localHashtable3.put("Revision", "ComboBox");
				}
				if ((str3.equalsIgnoreCase("true")) && (i == 0) && (j == 0)) {
					localHashtable2.put("IsAssignFolderEnable", "true");
					localHashtable2.put("AssignFolder", str4);
				}
				localHashtable2.put("TargetRevision", getTargetRev((String) localHashtable2.get("FamilyID"), str2, (String) localHashtable2.get("RevSequence")));
				if ((str7 != null) && (str7.length() > 0))
					str10 = str7;
				localHashtable2.put("SaveAs", str10);
			} else {
				localHashtable3.put("SaveAs", "ReadOnlyTextBox");
				localHashtable3.put("TargetRevision", "ReadOnlyTextBox");
				localHashtable3.put("Revision", "Label");
				if ((str7 != null) && (str7.length() > 0))
					str10 = str7;
				localHashtable2.put("SaveAs", "");
				localHashtable2.put("SaveAsTitle", "");
				localHashtable2.put("TargetRevision", "");
				if (str3.equalsIgnoreCase("true")) {
					localHashtable2.put("IsAssignFolderEnable", "false");
					localHashtable2.put("AssignFolder", str4);
				}
				
				// [B] modify by jtkim 2016-12-22
				localHashtable2.put("preSaveAs", str7);
				// [E] modify by jtkim 2016-12-22
			}

			localHashtable2.put("Selected", paramString);

			if (i != 0) {
				localHashtable2.put("Selected", FALSE);
			}
		}
		return str1;
	}

	public String getNodeIdList(String paramString) {
		StringBuffer resultSB = new StringBuffer();
		Enumeration localEnumeration = this.nodeIDtreeTableNodeTable.elements();
		
		IEFTreeTableNode localIEFTreeTableNode;
		while (localEnumeration.hasMoreElements()) {
			localIEFTreeTableNode = (IEFTreeTableNode) localEnumeration.nextElement();
			resultSB.append(localIEFTreeTableNode.nodeID).append("|");
		}
		resultSB.setLength(resultSB.length() - 1);
		return resultSB.toString();
	}

// ##########################################################################################
// [B] OOTB Override ########################################################################
// ##########################################################################################
	public String changeNodeSelection(String paramString) {
		String str1 = TRUE;

		Enumeration localEnumeration = MCADUtil.getTokensFromString(paramString, "|");
		String str2 = (String) localEnumeration.nextElement();
		String str3 = (String) localEnumeration.nextElement();
		String str4 = (String) localEnumeration.nextElement();

		IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) this.nodeIDtreeTableNodeTable.get(str2);
		changeNodeSelectionForPart(localIEFTreeTableNode, str3, str4);

		return str1;
	}

	private void changeNodeSelectionForPart(IEFTreeTableNode paramIEFTreeTableNode, String paramString1, String paramString2) {
		Hashtable localHashtable1 = (Hashtable) this.objectIDNodeDataTable.get(paramIEFTreeTableNode.objectID);
		Hashtable valuesHashtable = (Hashtable) localHashtable1.get("Values");
		Hashtable cellTypesHashtable = (Hashtable) localHashtable1.get("CellTypes");
		String str1 = (String) valuesHashtable.get("TargetRev");
		String str2 = (String) valuesHashtable.get("AssignFolderEnable");
		String str3 = (String) valuesHashtable.get("DefaultAssignFolder");
		String str4 = (String) valuesHashtable.get("IsPartAssignmentEnable");
		String str5 = (String) valuesHashtable.get("FamilyID");
		String str6 = (String) valuesHashtable.get("IsObjectAndFileNameDifferent");
		boolean bool = str6.equals("true");
		valuesHashtable.put("Selected", paramString1);

		if (paramString1.equalsIgnoreCase(TRUE)) {
			if (bool) {
				cellTypesHashtable.put("SaveAsTitle", "EditBox");
			} else if (str4.equalsIgnoreCase("true"))
				cellTypesHashtable.put("SaveAs", "ReadOnlyTextBox");
			else {
				cellTypesHashtable.put("SaveAs", "EditBox");
			}

			cellTypesHashtable.put("TargetRevision", "EditBox");
			cellTypesHashtable.put("Revision", "ComboBox");
			if (str2.equalsIgnoreCase("true")) {
				valuesHashtable.put("IsAssignFolderEnable", "true");
				valuesHashtable.put("AssignFolder", str3);
			}

			String str7 = "";

			if (bool) {
				str7 = (String) valuesHashtable.get("AutoName");
			}

			valuesHashtable.put("TargetRevision", getTargetRev(str5, str1, (String) valuesHashtable.get("RevSequence")));
			valuesHashtable.put("SaveAs", str7);
		} else {
			if (bool) {
				cellTypesHashtable.put("SaveAsTitle", "EditBox");
			} else {
				cellTypesHashtable.put("SaveAs", "ReadOnlyTextBox");
			}

			cellTypesHashtable.put("TargetRevision", "ReadOnlyTextBox");
			cellTypesHashtable.put("Revision", "Label");
			valuesHashtable.put("SaveAs", "");
			valuesHashtable.put("SaveAsTitle", "");
			valuesHashtable.put("TargetRevision", "");

			if (str2.equalsIgnoreCase("true")) {
				valuesHashtable.put("IsAssignFolderEnable", "false");
				valuesHashtable.put("AssignFolder", str3);
			}

		}

		if ((paramString2.equalsIgnoreCase(TRUE)) && (paramString1.equalsIgnoreCase(TRUE))) {
			for (int i = 0; i < paramIEFTreeTableNode.childNodes.size(); ++i) {
				IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) paramIEFTreeTableNode.childNodes.elementAt(i);
				changeChildNodeSelection(localIEFTreeTableNode, paramString2);
			}
		}

		if ((paramString1.equalsIgnoreCase(TRUE)) || (str5 == null) || (str5.trim().equals("")))
			return;
		selectFamilyNode(str5);
	}

	private void changeChildNodeSelection(IEFTreeTableNode paramIEFTreeTableNode, String paramString) {
		changeNodeSelectionForPart(paramIEFTreeTableNode, TRUE, paramString);
		for (int i = 0; i < paramIEFTreeTableNode.childNodes.size(); ++i) {
			IEFTreeTableNode localIEFTreeTableNode = (IEFTreeTableNode) paramIEFTreeTableNode.childNodes.elementAt(i);
			changeChildNodeSelection(localIEFTreeTableNode, paramString);
		}
	}

	private void selectFamilyNode(String paramString) {
		String str1 = FALSE;
		Hashtable localHashtable = (Hashtable) this.objectIDNodeDataTable.get(paramString);
		if (localHashtable == null)
			return;
		Vector localVector = (Vector) this.familyIDInstanceListTable.get(paramString);
		for (Object localObject1 = localVector.iterator(); ((Iterator) localObject1).hasNext();) {
			Object localObject2 = ((Iterator) localObject1).next();

			Object localObject3 = (Hashtable) this.objectIDNodeDataTable.get(localObject2);
			Object localObject4 = (Hashtable) ((Hashtable) localObject3).get("Values");
			String str2 = (String) ((Hashtable) localObject4).get("Selected");
			if (str2.equalsIgnoreCase(TRUE)) {
				str1 = TRUE;
				break;
			}
		}

		Object localObject1 = (Hashtable) localHashtable.get("Values");
		Object localObject2 = (Hashtable) localHashtable.get("CellTypes");
		if (!(str1.equalsIgnoreCase(TRUE))) {
			((Hashtable) localObject1).put("Selected", FALSE);
		}

		Object localObject3 = (String) ((Hashtable) localObject1).get("TargetRev");
		Object localObject4 = (String) ((Hashtable) localObject1).get("AssignFolderEnable");
		String str2 = (String) ((Hashtable) localObject1).get("DefaultAssignFolder");
		String str3 = (String) ((Hashtable) localObject1).get("IsPartAssignmentEnable");

		String str4 = (String) ((Hashtable) localObject1).get("IsObjectAndFileNameDifferent");

		boolean bool = str4.equals("true");

		String str5 = "";

		if (bool) {
			str5 = (String) ((Hashtable) localObject1).get("AutoName");
			((Hashtable) localObject2).put("SaveAsTitle", "EditBox");
		} else if (str3.equalsIgnoreCase("true")) {
			((Hashtable) localObject2).put("SaveAs", "ReadOnlyTextBox");
		} else {
			((Hashtable) localObject2).put("SaveAs", "EditBox");
		}

		((Hashtable) localObject2).put("TargetRevision", "EditBox");
		((Hashtable) localObject2).put("Revision", "ComboBox");
		if (((String) localObject4).equalsIgnoreCase("true")) {
			((Hashtable) localObject1).put("IsAssignFolderEnable", "true");
			((Hashtable) localObject1).put("AssignFolder", str2);
		}
		((Hashtable) localObject1).put("TargetRevision", localObject3);
		((Hashtable) localObject1).put("SaveAs", str5);

		String str6 = (String) ((Hashtable) localObject1).get("FamilyID");
		if ((str6 != null) && (!(str6.trim().equals(""))) && (!(str6.equals(paramString))))
			selectFamilyNode(str6);
	}

	private String getTargetRev(String paramString1, String paramString2, String paramString3) {
		if ((paramString1 != null) && (!(paramString1.trim().equals(""))) && (paramString3 != null) && (!(paramString3.trim().equals(""))) && (this.instanceIDDisplayedFamIDsArray.containsValue(paramString1))) {
			paramString2 = paramString3;
		}

		return paramString2;
	}
}