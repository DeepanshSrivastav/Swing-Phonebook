var colorBlue 		= "#6699BB";
var colorRed 		= "#cc0000";
var colorYellow		= "#ff7f00";
var colorGreen 		= "#009c00";
var colorGray 		= "#5f747d";
var colorGrayBright	= "#aab8be";
