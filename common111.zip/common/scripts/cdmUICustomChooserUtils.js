//=================================================================
// JavaScript Type Chooser Utility Functions
// Version 1.0
//
// Copyright (c) 1992-2004 MatrixOne, Inc.
// All Rights Reserved.
// This program contains proprietary and trade secret information of MatrixOne,Inc.
// Copyright notice is precautionary only
// and does not evidence any actual or intended publication of such program
//=================================================================
    var objObjectChooser = new emxUIObjectChooser(bMultiSelect, bShowIcons, bIsFromSearch, searchMode, expandProgram , displayKey);
    //add types
    for (var i=0; i < arrOrgs.length; i++){    	
        objObjectChooser.addOrg(arrOrgs[i]);
    }
    var objToolbar = new emxUIToolbar;
    //objToolbar.addItem(new emxUIToolbarButton(emxUIToolbar.ICON_ONLY, "iconActionHelp.gif", COMMON_HELP, "javascript:openHelp(\"" + HELP_MARKER + "\", \"" + SUITE_DIR + "\", \"" + LANGUAGE_STRING + "\")"));
    
    function doLoad() {
        toolbars.init('divToolbar');
        objObjectChooser.setContainer(document.getElementById("divTree"));
        objObjectChooser.init(); //URL and parameters are handled by JavaScript
        //doFilter();
    }

    function doFilter() {
        var objSel = document.getElementById("selFilter");
        var objTxt = document.getElementById("txtFilter");
//        var objChk = document.getElementById("chkTopLevelOnly");
        var objBtn = document.getElementById("btnFilter");
        
        if( document.getElementById("txtFilter").value == "" ) {
        	document.getElementById("loadLevel").value = "1";        	
        }else{
        	document.getElementById("loadLevel").value = "0";
        }

//        objBtn.disabled = objChk.disabled = objTxt.disabled = objSel.disabled = true;
        objBtn.disabled = objTxt.disabled = objSel.disabled = true;
        
        document.body.style.cursor = "wait";

        setTimeout(function () {
//            objObjectChooser.applyFilter(objSel.options[objSel.selectedIndex].value, objTxt.value, objChk.checked, document.getElementById("loadLevel").value);
//            objBtn.disabled = objChk.disabled = objTxt.disabled = objSel.disabled = false;
            objObjectChooser.applyFilter(objSel.options[objSel.selectedIndex].value, objTxt.value, document.getElementById("loadLevel").value);
            objBtn.disabled = objTxt.disabled = objSel.disabled = false;
            document.body.style.cursor = "";
        }, 100);
    }
    
    function searchFilter() {
        var objSel = document.getElementById("selFilter");
        var objTxt = document.getElementById("txtFilter");
//        var objChk = document.getElementById("chkTopLevelOnly");
        var objBtn = document.getElementById("btnFilter");
        
        if( document.getElementById("txtFilter").value == "" ) {
        	document.getElementById("loadLevel").value = "1";        	
        }else{
        	document.getElementById("loadLevel").value = "0";
        }

//        objBtn.disabled = objChk.disabled = objTxt.disabled = objSel.disabled = true;
        objBtn.disabled = objTxt.disabled = objSel.disabled = true;

        document.body.style.cursor = "wait";

        setTimeout(function () {
//            objObjectChooser.searchFilter(objSel.options[objSel.selectedIndex].value, objTxt.value, objChk.checked, document.getElementById("loadLevel").value);
//            objBtn.disabled = objChk.disabled = objTxt.disabled = objSel.disabled = false;
        	objObjectChooser.searchFilter(objSel.options[objSel.selectedIndex].value, objTxt.value, true, document.getElementById("loadLevel").value);
        	objBtn.disabled = objTxt.disabled = objSel.disabled = false;
            document.body.style.cursor = "";
        }, 100);
    }

    function doDone(appendMode) {
    	var strSelected = objObjectChooser.getValue();
		if (strSelected != "") {			
			if (submitURL == "") {
				//declare actual values and translated values
				var arrActuals = new Array;
				var arrTranslations = new Array;
				var arrTranslationsTitle = new Array;
				//split the string into an array at each comma
				var arrItems = strSelected.split(",");
				
				//go through array and create the strings
				for (var i=0; i < arrItems.length; i++) {
				
				    //make sure this item is not blank
				    if (arrItems[i] != "") {
					    //split this item at the pipe
					    var arrTemp = arrItems[i].split("||");
					   
					    if( fromPage == "partForm" ){
					    	if (arrActuals.find(arrTemp[0]) == -1) 
						        arrActuals[arrActuals.length] = arrTemp[0];
					    	// [B] modify by jtkim 2016-12-13
					    	// OOTB Bug
					    	if (arrTranslations.find(arrTemp[1]) == -1) 
					    		arrTranslations[arrTranslations.length] = arrTemp[1];
					    }
					}
				}		
				
			    //create strings from the arrays
			    var strActuals = arrActuals.join(",");
			    var strTranslations = arrTranslations.join(",");
			   
			    // Pass back the abs & translated values.
			    if (!appendMode) {
			        txtType.value = strActuals;
			        txtTypeDisp.value = strTranslations;
			    } else {
			   	    var tempIndex1, tempIndex2;
			        for (var k=0; k<arrActuals.length; k++) {
			            tempIndex1 = txtType.value.indexOf(arrActuals[k]);
			       	    if (tempIndex1 > -1) {
			       			tempIndex1 = strActuals.indexOf(arrActuals[k]);
			       			tempIndex2 = strActuals.indexOf(",", tempIndex1+1);
	
			       			if (tempIndex1 > -1 && tempIndex2 == -1)
								strActuals = strActuals.substring(0, tempIndex1);
							else if (tempIndex1 > -1 && tempIndex2 > -1)
								strActuals = strActuals.substring(0, tempIndex1) + strActuals.substring(tempIndex2+1);
							
			       			tempIndex1 = strTranslations.indexOf(arrTranslations[k]);
			       			tempIndex2 = strTranslations.indexOf(",", tempIndex1+1);
			       			
			       			if (tempIndex1 > -1 && tempIndex2 == -1)
								strTranslations = strTranslations.substring(0, tempIndex1);
							else if (tempIndex1 > -1 && tempIndex2 > -1)
								strTranslations = strTranslations.substring(0, tempIndex1) + strTranslations.substring(tempIndex2+1);
			       		
			       	    }
			        }
			       
			        if (txtTypeDisp.value == "*") {
			       		txtTypeDisp.value = "";
			       		txtType.value = "";
			        }
			       
			        if (strActuals.length > 0 && txtTypeDisp.value.length > 0) strActuals = "," + strActuals;
			        if (strTranslations.length > 0 && txtTypeDisp.value.length > 0) strTranslations = "," + strTranslations;
				   		       
				    txtType.value = txtType.value + strActuals;
				    txtTypeDisp.value = txtTypeDisp.value + strTranslations;
			    }
			
			    //Is there a callback function??
			    if((typeof top.callbackFunction) != "undefined") {
			        top.callbackFunction();
			    }
			
			    if (!appendMode) {
			   		top.close();
			    }
            } else {
		        try{
                    var arrItems = new Array();
                    arrItems = objObjectChooser.getValueArray();
                    var plusObjId = "";
                    if(arrItems instanceof Array){
                    	arrItems = objObjectChooser.getValueArray();
                    	for (var i=0; i < arrItems.length; i++) {
                        	var arrTemp = arrItems[i].split("||");
                        	if(plusObjId=="" || plusObjId==null) plusObjId = arrTemp[0];
                        	else plusObjId += "|" + arrTemp[0];
                        }
                    }else{
                    	arrItems = arrItems.split("||");
                        plusObjId = arrItems[0];
                    }
                    plusObjId = "&newId=" + plusObjId;
                        
                    if(submitURL.indexOf("../") > -1){
                        submitURL = submitURL + plusObjId;
                    }else{
                        submitURL = "../common/" + submitURL + plusObjId;
                    }
                    top.location.href=submitURL;
                        
                }catch(e1){
                    alert(e1);
                }
		    }
        } else {
		    alert(SELECT_TYPE_MSG);
		}
    }

	function getSelectPeople() {
        var arrInputs = peopleList.document.getElementsByTagName("input");
        var arrTemp = new Array;
        
        for (var i=0; i < arrInputs.length; i++) {
        	if (arrInputs[i].name=="emxTableRowId"){
        		if (arrInputs[i].type=="checkbox"){
        			if (arrInputs[i].checked) {
                        arrTemp.push(arrInputs[i].value);
					}
        		} else {
        			if (arrInputs[i].checked) {
        				return arrInputs[i].value;
        			}
        		}
        	}
        }
        return arrTemp.toString();		
	}
	
    function doCancel() {
      top.close();
    }
