BPSTopBar = {
	loadTopBar:function(){
		require(['UWA/Core', 
		'DS/TopFrame/TopFrame', 
		'DS/TopBar/TopBar', 
		'DS/TopBarProxy/TopBarProxy', 
		'DS/Foundation/FoundationData', 
		'DS/SNSearchUX/SearchUX_TopBar', 
		'css!DS/TopBar/TopBar', 
		'DS/UWPClientCode/PublicAPI', 
		'DS/ENOFrameworkSearchUIContainer/SearchUIContainer', 
		'DS/ENOFrameworkSearch/Search',
		'DS/ENOFrameworkTagger/Tagger',
		'DS/TagNavigator/TagNavigator',
		'DS/TagNavigatorProxy/TagNavigatorProxy'], 
		function (Core, 
		TopFrame, 
		TopBar, 
		TopBarProxy, 
		FoundationData, 
		SearchTopBar,
		cssTopBar, 
		PublicAPI, 
		SearchUIContainer, 
		Search,
		Tagger,
		TagNavigator,
		TagNavigatorProxy) {
		    'use strict';
		    var appName;
		    var userName;
		    $.ajax({
       		   url: '../resources/bps/menu/appName',
       		   dataType: 'json',
       		   async:false,
       		   success: function (data){
		    	console.log(data);
		    	appName = data[0].appName;
		    	userName = data[0].userName;
       		   }
            });
		    var search;
		    var path = window.location.pathname.split('/')[1];
		    var url = window.location.protocol + "//" + window.location.host;
		    var completeURL = url + "/" +  path;
		    TopFrame.init({
                userId: userName,
				envId:'OnPremise',
				tenant:'OnPremise',
                startupParams: {cstorage: [{id: 'OnPremise' , displayName: 'OnPremise', url: completeURL}], 
                				search: [{id: 'OnPremise' , displayName: 'OnPremise', url: url}],
                				tagger: [{id:'OnPremise', displayName:'OnPremise', url:completeURL}]},
                appId: "IFWE",
                baseAppletPath: "../../WebClient/",
                baseImgPath: "../../webapps/i3DXCompass/assets/images",
                baseHtmlPath: clntbaseHtmlPath,
                passportUrl: passportURL,
                proxyTicketUrl: proxyTicketURL,
                tagsServerUrl: completeURL,
                myAppsBaseURL: completeURL,
                userName: userName,
                brand: 'ENOVIA',
                lang: top.clntlang,
                application: appName,
                onFilterChange: function (filters) {
                	alert(filters);
                },
                searchParams :{
                    open: function(openOptions){
                        var container = new SearchUIContainer(getTopWindow());
                        openOptions.searchcontent = "bd";
						var tagger = new Tagger();
           				search = new Search(openOptions);
                    },
                    isOpen: function(){
                    	if(jQuery("div#searchContainer").is(':visible')){
                    		return true;
                    	}else{
                    		return false;
                    	}
                       
                    },
					close:function(){
						jQuery('#searchContainer').fadeOut(); jQuery('#bd').empty();
					},
					hide:function(){
						
					}
                },
                events: {
		            tagger: function () {
		            },
		            search: function(){},
		            clearSearch:function(){}
		        }
            });
		    TopFrame.addEvent('onLeftPanelOpened', function () {
				var leftPanelWidth = jQuery('.column-left').innerWidth();
				jQuery("div#pageContentDiv").css('left', leftPanelWidth+'px');
				jQuery("div#pageContentDiv").css('transition', 'left .5s ease-in');
				jQuery("div#divExtendedHeaderContent").css('left', leftPanelWidth+'px');
				jQuery("div#divExtendedHeaderContent").css('transition', 'left .5s ease-in');
				jQuery("div#mydeskpanel").css('z-index', '1');
				jQuery("div#leftPanelMenu").css('z-index', '1');
			});
			TopFrame.addEvent('onLeftPanelClosed', function () {
				if(getTopWindow().isPanelOpen){
					getTopWindow().openPanel();
				} else {
					getTopWindow().closePanel();
				}
			});
		    var thisCommandProvider = {};
		    thisCommandProvider.topBarProxy = new TopBarProxy({
		        id: 'CommandProvider1'
		    });
		    
		    TopBar.MainMenuBar.setActiveMenuProviders("CommandProvider1");
		    var callback = thisCommandProvider.callback = function (menuItem) {
		    	var url = menuItem.get('url');
		    	var targetLocation = menuItem.get('targetLocation') == 'popup' ? undefined : menuItem.get('targetLocation');
		    	emxUICore.link(url, targetLocation);
		    };
		    var ajaxPersonMenuURL = '../resources/bps/menu/AEFPersonMenu';
            var ajaxActionsURL = '../resources/bps/menu/Actions';
            var ajaxShareMenuURL = '../resources/bps/menu/AEFShareMenu';
            var ajaxMyHomeURL = '../resources/bps/menu/AEFMyHome';
            var addCallback = function (data) {
                data.forEach(function (item) {
                    if (item.submenu) {
                        item.submenu.forEach(function (subItem) {
                            if (subItem.submenu) {
                                subItem.submenu.forEach(function (sub2Item) {
                                    sub2Item.onExecute = callback;
                                });
                            } else {
                                subItem.onExecute = callback;
                            }
                        });
                    } else {
                        item.onExecute = callback;
                    }
                });
                return data;
            };
            var topbarAjaxActionsComplete = function (data) {
                var cbData = addCallback(data);
                thisCommandProvider.topBarProxy.addContent({
                    add: cbData
                    
                });
            };

            var topbarAjaxProfileComplete = function (data) {
                var cbData = addCallback(data);
                thisCommandProvider.topBarProxy.addContent({
                    profile: cbData
                });
            };

            
            var topbarShareComplete = function (data) {
                var cbData = addCallback(data);
                thisCommandProvider.topBarProxy.addContent({
                    share: cbData
                });
            };
            var topbarMyHomeComplete = function (data) {
                var cbData = addCallback(data);
                thisCommandProvider.topBarProxy.addContent({
                    home: cbData
                });
            };
            $.ajax({
     		   url: ajaxActionsURL,
     		   dataType: 'json',
	           success: topbarAjaxActionsComplete
            });
            $.ajax({
      		   url: ajaxPersonMenuURL,
      		   dataType: 'json',
      		   success: topbarAjaxProfileComplete
             });
            $.ajax({
       		   url: ajaxShareMenuURL,
       		   dataType: 'json',
       		   success: topbarShareComplete
              });
            $.ajax({
       		   url: ajaxMyHomeURL,
       		   dataType: 'json',
       		   success: topbarMyHomeComplete
              });
            
			var toppos = toppos = jQuery('#topbar').height() + jQuery('#navBar').height();
            jQuery("div#pageContentDiv").css('top',toppos);
			jQuery("div#leftPanelMenu").css('top',toppos);
			jQuery("div#mydeskpanel").css('top',toppos);
			jQuery("div#panelToggle").css('top',toppos);
			jQuery("div#GlobalMenuSlideIn").css('top',toppos);
			
			jQuery("div#rightSlideIn").css('top',toppos);
			jQuery("div#leftSlideIn").css('top',toppos);
			jQuery("div#GlobalMenuSlideIn").css('top',toppos);
			jQuery(".app-content").hide();
		});
			
	}
};
window.addEventListener('load', function(){
	BPSTopBar.loadTopBar();
});
