
var SnN = {
			FROM_SNN : false,
			FRAME_TO_BE_REFRESHED : null,
			selected_Objects_search : function _selected_Objects_search (url, parameters){
			   this.FROM_SNN = true;
			   var submitForm = document.createElement('form');
				var urlParams = new Query(url);
				var submitURL = "";
				urlParams.items.forEach(function(urlParamItems){
					var input1   = document.createElement('input');
					input1.type  = "hidden";
					input1.name  = urlParamItems.name;
					input1.value = urlParamItems.value;
					if(urlParamItems.name === "submitURL"){
						if(urlParamItems.value.contains("?")){
							var submitURLParams = new Query(urlParamItems.value);
							submitURLParams.items.forEach(function(submitURLParamItems){
								var submitURLInput   = document.createElement('input');
								submitURLInput.type  = "hidden";
								submitURLInput.name  = submitURLParamItems.name;
								submitURLInput.value = submitURLParamItems.value;
								submitForm.appendChild(submitURLInput);
							});
						}
						submitURL = urlParamItems.value;
					}
					submitForm.appendChild(input1);
				});
				parameters.forEach(function(selectedObject){
					var input2 = document.createElement('input');
					input2.type = "hidden";
					input2.name = "emxTableRowId";
					input2.value = selectedObject.id;
					submitForm.appendChild(input2);
				});
				submitForm.target = "hiddenFrame";
				submitForm.action=submitURL;
				addSecureToken(submitForm);
				document.body.appendChild(submitForm);
				submitForm.submit();
				removeSecureToken(submitForm);
		},
		loadSnN : function _loadSnN(refinementToSnN, url){
			var socket;
				if (!UWA.is(socket)) {

		            // Create a new socket. The socket id is the one defined in {@link module:DS/SearchIntegrationSample/SearchIntegrationSample.SearchIntegrationSample#options options}
		            socket = new UWA.Utils.InterCom.Socket('in_ctx_search_sample_'+getTopWindow().defOptionsGlobal.socketName);

		            
		            // Subscribe to the Search Intercom server (it has already been created by the 3D#)
		            socket.subscribeServer('SearchComServer', top, getTopWindow().defOptionsGlobal.targetOrigin);
		        }
			var refinementToSnNJSON = JSON.parse(refinementToSnN);
			refinementToSnNJSON.app_socket_id = 'in_ctx_search_sample_'+getTopWindow().defOptionsGlobal.socketName;
			refinementToSnNJSON.widget_id = getTopWindow().defOptionsGlobal.socketName;
			if (UWA.is(socket)) {
				socket.dispatchEvent('RegisterContext', refinementToSnNJSON);
				socket.addListener('Selected_Objects_search', this.selected_Objects_search.bind(this, url));
		        // Dispatch the in context search event
		        socket.dispatchEvent('InContextSearch', refinementToSnNJSON);
		    } else {
		        throw new Error('Socket not initialized');
		    }
			}
};
