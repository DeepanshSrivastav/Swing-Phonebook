//=================================================================
// JavaScript DOM Type Chooser
// Version 1.0
//
// Copyright (c) 1992-2002 MatrixOne, Inc.
// All Rights Reserved.
// This program contains proprietary and trade secret information of MatrixOne,Inc.
// Copyright notice is precautionary only
// and does not evidence any actual or intended publication of such program
//=================================================================

function emxUIObjectChooser(blnMultiSelect, blnShowIcons, bIsFromSearch, searchMode, expandProgram , displayKey) {

    this.className = "emxUITypeChooser";
    this.container = null;
    this.doms = new Array;
    this.orgs = new Array;
    this.orgName = new Array;
    this.typeName = new Array;
    this.iscreate = new Array;
    this.uniqueCode = new Array;
    this.title = new Array;
    this.hasChild = new Array;
    this.multiSelect = bMultiSelect;
    this.showIcons = blnShowIcons;
    this.allLevelsLoaded = false;
    this.fullTreeGenerated = false;
    this.isFromSearch = bIsFromSearch;
    this.searchMode = searchMode;
    this.expandProgram = expandProgram;
    this.displayKey = displayKey;
    this.rootNode = rootNode;
    this.formFieldNameDisplay = formFieldNameDisplay;
}

emxUIObjectChooser.XSL_TREE = emxUIConstants.DIR_COMMON + "cdmUICustomChooserTree.xsl";
emxUIObjectChooser.XSL_TYPE = emxUIConstants.DIR_COMMON + "cdmUICustomChooser.xsl";
emxUIObjectChooser.XSL_TYPE_CHILDREN = emxUIConstants.DIR_COMMON + "cdmUICustomChooserChildren.xsl";
emxUIObjectChooser.XML_FULL_TREE = emxUIConstants.DIR_COMMON + "cdmCustomChooserLoadFullTree.jsp";
emxUIObjectChooser.XML_ALL_LEVELS = emxUIConstants.DIR_COMMON + "cdmCustomChooserLoadAllLevels.jsp";
emxUIObjectChooser.XML_TOP_LEVEL_ONLY = emxUIConstants.DIR_COMMON + "cdmCustomChooserLoadFirstLevel.jsp";
emxUIObjectChooser.XML_TYPE = emxUIConstants.DIR_COMMON + "cdmCustomChooserLoadTree.jsp";
emxUIObjectChooser.URL_COUNT_TYPES =  emxUIConstants.DIR_COMMON + "cdmCustomChooserCountTypes.jsp";

emxUIObjectChooser.prototype.addOrg = function _emxUIObjectChooser_addOrg(sOrg) {
		var arrTemp = sOrg.split("||");
		var length = this.orgs.length;
        this.orgs[length] = arrTemp[0];
        this.orgName[length] = arrTemp[1];
        this.typeName[length] = arrTemp[2];   
        this.iscreate[length] = arrTemp[3];   
        this.uniqueCode[length] = arrTemp[4];   
        this.title[length] = arrTemp[5];
        this.hasChild[length] = arrTemp[6];
};

emxUIObjectChooser.prototype.addURLParams = function (strURL) {	
    return strURL + "?&multiSelect=" + this.multiSelect + "&showIcons=" + this.showIcons + "&searchMode=" + this.searchMode+"&expandProgram="+expandProgram+"&displayKey="+displayKey+"&rootNode="+rootNode+"&formFieldNameDisplay="+formFieldNameDisplay;
};

function newDoc(oXML){
    var win = window.open();
    with(win.document){
    open();
    write(oXML.xml);
    close();
    }
}

emxUIObjectChooser.prototype.applyFilter = function() {
        this.setBusy(true);
        var objThis = this;    
        this.container.innerHTML = emxUIConstants.HTML_LOADING;
        setTimeout(function () {        	
            var objRE = objThis.createExpression(objThis.selFilter.selectedIndex, objThis.txtFilter.value);                
                
            objThis.doms["full"] = null;
            objThis.doms["current"] = objThis.generateFilteredDOM(objThis.doms["original"], objRE);
            objThis.displayTree();
            objThis.setBusy(false);
        }, 100);
};

emxUIObjectChooser.prototype.searchFilter = function() {
    this.setBusy(true);
    var objThis = this;    
    this.container.innerHTML = emxUIConstants.HTML_LOADING;
    
    setTimeout(function () {        	
    	var txtFilter = objThis.txtFilter.value;
    	var objRE = objThis.createExpression(objThis.selFilter.selectedIndex, objThis.txtFilter.value, true);                
        var objCurrent = objThis.doms["current"];
        var strURL = objThis.addURLParams(emxUIObjectChooser.XML_TOP_LEVEL_ONLY);
    	objThis.doms["original"] = emxUICore.getXMLDataPost(strURL, objThis.getURLData().toString());
        if("" == txtFilter){
            objThis.doms["current"] = objThis.generateSearchFilteredDOM(objThis.doms["original"], objRE);
        }else if(txtFilter.length < 2){
        	alert("Enter more than 2 letters");
        	objThis.doms["current"] = objThis.generateSearchFilteredDOM(objThis.doms["original"], objRE);
        }else{
        	objThis.doms["full"] = emxUICore.getXMLDataPost(objThis.addURLParams(emxUIObjectChooser.XML_ALL_LEVELS)+"&loadLevel="+document.getElementById("loadLevel").value, objThis.getURLData().toString()+"&loadLevel="+document.getElementById("loadLevel").value+"&txtFilter="+objThis.txtFilter.value+"&formFieldNameDisplay="+formFieldNameDisplay);
        	objThis.doms["current"] = objThis.generateSearchFilteredDOM(objThis.doms["full"], objRE);	
        }
        
        objThis.displayTree();
        objThis.setBusy(false);
    }, 100);
};

emxUIObjectChooser.prototype.init = function _emxUIObjectChooser_init() {
        this.txtFilter = document.getElementById("txtFilter");
        this.btnFilter = document.getElementById("btnFilter");
        this.selFilter = document.getElementById("selFilter");
        
       	this.screen = document.getElementById("divScreen");
        this.loadDefinition();   
        var objThis = this;
        
        setTimeout(function () {    
        	objThis.setBusy(true);
        	objThis.setBusy(false);
        },600);
        
};

emxUIObjectChooser.prototype.setBusy = function (blnBusy) {
        if (blnBusy) {                
        	this.btnFilter.disabled = true;
            this.txtFilter.disabled = true;
            this.selFilter.disabled = true;
            if (this.isFromSearch) {
                this.screen.style.visibility = "visible";
            }
        } else {
            this.btnFilter.disabled = false;
            this.txtFilter.disabled = false;
            this.selFilter.disabled = false;
            if (this.isFromSearch) {
                this.screen.style.visibility = "hidden";
            }
        }
};

/**
 * Creates the URL parameters necessary to load the initial data from the database.
 * @return A string of URL parameters.
 */
emxUIObjectChooser.prototype.getURLData = function () {

        try {
        	if (this.orgs.length > 0) {
                var objBuf = new emxUIStringBuffer();
                
                objBuf.write("numOrgs=");
                objBuf.write(this.orgs.length);
                for (var i=0; i < this.orgs.length; i++) {
                        objBuf.write("&orgId");
                        objBuf.write(i);
                        objBuf.write("=");
                        objBuf.write(this.orgs[i]);
                        objBuf.write("&typeName");
                        objBuf.write(i);
                        objBuf.write("=");
                        objBuf.write(this.typeName[i]);
                        objBuf.write("&orgName");
                        objBuf.write(i);
                        objBuf.write("=");
                        objBuf.write(this.orgName[i]);
                        objBuf.write("&iscreate");
                        objBuf.write(i);
                        objBuf.write("=");
                        objBuf.write(this.iscreate[i]);
                        objBuf.write("&uniqueCode");
                        objBuf.write(i);
                        objBuf.write("=");
                        objBuf.write(this.uniqueCode[i]);
                        objBuf.write("&title");
                        objBuf.write(i);
                        objBuf.write("=");
                        objBuf.write(this.title[i]);
                        objBuf.write("&hasChild");
                        objBuf.write(i);
                        objBuf.write("=");
                        objBuf.write(this.hasChild[i]);
                }
                return objBuf.toString();
			} else {
				return "";
			}
        } catch (objError) {
                alert("An error occurred while encoding data to be sent to the server.");
        }
};

/**
 * Displays the current tree by transforming the XML DOM using XSLT
 * and inserting it into the container.
 */
emxUIObjectChooser.prototype.displayTree = function () {
	this.container.innerHTML = "<form onSubmit='javascript:doDone();return false;'>" + emxUICore.transformToText(this.doms["current"], this.doms["xsl-tree"]) + "</form>";
};

/**
 * Loads the type chooser XML definition.
 */
emxUIObjectChooser.prototype.loadDefinition = function () {
    var strURL = this.addURLParams(emxUIObjectChooser.XML_TOP_LEVEL_ONLY);
    try {
        var objThis = this;
        objThis.setBusy(true);
        setTimeout(function () {    
            objThis.doms["original"] = emxUICore.getXMLDataPost(strURL, objThis.getURLData().toString());
            //objThis.sortDOM(objThis.doms["original"]);
            objThis.doms["xsl-tree"] = emxUICore.getXMLData(emxUIObjectChooser.XSL_TREE);   
            objThis.doms["xsl-type"] = emxUICore.getXMLData(emxUIObjectChooser.XSL_TYPE);     
            objThis.doms["xsl-type-children"] = emxUICore.getXMLData(emxUIObjectChooser.XSL_TYPE_CHILDREN);   
            objThis.doms["current"] = objThis.doms["original"];
            objThis.displayTree();    
            //objThis.setBusy(false); 
        }, 100);
    } catch (objError) {
        alert("An error occured while trying to load the data.");        
    }
};

emxUIObjectChooser.prototype.setContainer = function _emxUIObjectChooser_setContainer(objDOMParent) {
        this.container = objDOMParent;
};

emxUIObjectChooser.prototype.generateFullTree = function (objXML) {
        var objNewXML = emxUICore.createXMLDOM();
        var objRoot = emxUICore.getElementsByTagName(objXML, "aef:root")[0];
        var objRootLabel = emxUICore.getElementsByTagName(objRoot, "aef:label")[0].cloneNode(true);
        var objNewRoot = objRoot.cloneNode(false);
        var arrOrgs = emxUICore.getElementsByTagName(objXML, "aef:org");

        objNewXML.appendChild(objXML.documentElement.cloneNode(false));
        objNewXML.documentElement.appendChild(objNewRoot);
        objNewRoot.appendChild(objRootLabel.cloneNode(true));
        
        for (var i=0; i < arrOrgs.length; i++) {
                objNewXML.documentElement.childNodes[0].appendChild(arrOrgs[i].cloneNode(true));
        }
        //this.sortDOM(objNewXML);
        return objNewXML;
};

/**
 * Handles expanding/collapsing of subtrees. If the node's children
 * haven't been loaded yet, it loads them.
 * @param strID The unique ID to locate the HTML elements for this type.
 * @param strTypeName The type that is being expanded/collapsed.
 */
emxUIObjectChooser.prototype.toggleExpand = function (strID, strOrgId, strOrgName, strTypeName, iscreate , uniqueCode, title, hasChild) {
		turnOnProgress();
		
        var objDivA = document.getElementById("div" + strID + "A");
        var objDivB = document.getElementById("div" + strID + "B");
        var objTD = document.getElementById("td" + strID);
        var objImg = objTD.getElementsByTagName("img")[0];
		
        if (objDivB.childNodes.length > 1) {
            if (objDivB.style.display == "none") {
                objDivB.style.display = "inline";
                objImg.src = objImg.src.replace("Closed", "Open");
            } else {
                objDivB.style.display = "none";
                objImg.src = objImg.src.replace("Open", "Closed");
            }
        } else {

        	var objThis = this;
        	if (objThis.addOrgToDOM(strOrgId, strOrgName, strTypeName, iscreate, uniqueCode, title, hasChild,  objThis.doms["current"])) {
        		this.setBusy(true);
            
        		if (objDivB.style.display == "none") {
        			objDivB.style.display = "inline";
        			objImg.src = objImg.src.replace("Closed", "Open");
        		} else {
        			objDivB.style.display = "none";
        			objImg.src = objImg.src.replace("Open", "Closed");
        		}
       
        		setTimeout(function () {
  
	                //check to see if the type has to be loaded
	                if (objThis.doms["full"]) {
	                	objThis.addOrgToDOM(strOrgId, strOrgName, strTypeName, iscreate, uniqueCode, title, hasChild, objThis.doms["full"]);
	                }
	                        
	                objThis.addOrgToDOM(strOrgId, strOrgName, strTypeName, iscreate, uniqueCode, title, hasChild, objThis.doms["original"]);
	                                        
	                var objNewNode = emxUICore.selectSingleNode(objThis.doms["current"].documentElement, "//aef:org[@id='" + strOrgId + "']");
														
	                objDivB.innerHTML = emxUICore.transformToText(objNewNode, objThis.doms["xsl-type-children"]);          
	                    
	                objThis.setBusy(false);
						
	            }, 500);
			} else {
				if (objDivB.style.display == "none") {
	                objDivB.style.display = "inline";
	                objImg.src = objImg.src.replace("Closed", "Open");
	            } else {
	                objDivB.style.display = "none";
	                objImg.src = objImg.src.replace("Open", "Closed");
	            }
			    objThis.setBusy(false);
			}
        }
        setTimeout( "turnOffProgress()" , 50 );
};

emxUIObjectChooser.prototype.findPeople = function (strOrgId, strOrgName, strTypeName) {
	var queryString = "?orgId=" + strOrgId + "&orgName=" + strOrgName.replace("&", "/") + "&typeName=" + strTypeName  + "&iscreate=" + iscreate + "&multiSelect=" + this.multiSelect + "&isNeededOId=" + this.isNeededOId;
	var iframe = document.getElementById('peopleList');
	iframe.src = "khrOrganizationFindPeople.jsp" + queryString;
};

/**
 * Adds an individual type into the given XML DOM.
 * @param strTypeName The name of type to add.
 * @param objDOM The DOM to add into.
 */
emxUIObjectChooser.prototype.addOrgToDOM = function (orgId, orgName, typeName, iscreate, uniqueCode, title, hasChild, objDOM) {
	var tempNodes = new Array;
    var arrNodes = emxUICore.selectNodes(objDOM.documentElement, "//aef:org[@id='" + orgId + "']");
    //check to see if the next level of nodes needs to be loaded.
    if (arrNodes.length > 0 && arrNodes[0].getAttribute("haschildren") == "true" && emxUICore.getElementsByTagName(arrNodes[0], "aef:org").length == 0) {
        
        var objNewDOM = null;
        if (this.doms["org_" + orgId]) {
            objNewDOM = this.duplicateDOM(this.doms["org_" + orgId]);
        } else {
            //objNewDOM =  emxUICore.getXMLData(this.addURLParams(emxUIObjectChooser.XML_TYPE)+ "&expandProgram=" + this.expandProgram + "&orgId=" + orgId + "&orgName=" + orgName + "&typeName=" + typeName + "&iscreate=" + iscreate + "&uniqueCode=" + uniqueCode + "&title=" + title + "&hasChild=" + hasChild +"&multiSelect=" + this.multiSelect+"&formFieldNameDisplay="+formFieldNameDisplay);
        	objNewDOM =  emxUICore.getXMLDataPost(this.addURLParams(emxUIObjectChooser.XML_TYPE)+ "&expandProgram=" + this.expandProgram + "&orgId=" + orgId + "&orgName=" + orgName + "&typeName=" + typeName + "&iscreate=" + iscreate + "&uniqueCode=" + uniqueCode + "&title=" + title + "&hasChild=" + hasChild +"&multiSelect=" + this.multiSelect+"&formFieldNameDisplay="+formFieldNameDisplay);
            this.doms["org_" + orgId] = this.duplicateDOM(objNewDOM);
        }
        var objNewNode = emxUICore.getElementsByTagName(objNewDOM, "aef:org");
        if (objNewNode == null) alert(objNewDOM.xml);
        if( objNewNode.length > 0 ){
        	for( var i = 0 ; i < objNewNode.length ; i++ ){
        		arrNodes[0].appendChild(objNewNode[i]);
        	}
        }else{
        	return false;
        }
        objDOM.loadXML(objDOM.xml);
        return true;
    } else {
        return false;
    }

};

/**
 * Sorts the types into alphabetical order.
 * @param objXML The XML DOM to sort.
 */
emxUIObjectChooser.prototype.sortDOM = function (objXML) {

        function _sortDOM(objXML) {
        		
                var arrTemp = new Array;
                var arrOrgs = emxUICore.selectNodes(objXML, "aef:org");
                
                for (var i=arrOrgs.length-1; i >= 0; i--) {  
                        _sortDOM(arrOrgs[i]);
                        arrTemp.push(arrOrgs[i]);                
                }
                arrTemp.sort(compareDOMText);
                
                for (var i=0; i < arrTemp.length; i++) {
                        objXML.appendChild(arrTemp[i]);
                }     
        }

        var objStartNode = objXML;
        if (objXML.nodeType != 1) {
            objStartNode = emxUICore.getElementsByTagName(objXML, "aef:root")[0];
        }
        _sortDOM(objStartNode);
};

/**
 * Creates an exact duplicate of an XML DOM.
 * @param objXML The XML DOM to duplicate.
 * @return An exact duplicate of the XML DOM.
 */
emxUIObjectChooser.prototype.duplicateDOM = function (objXML) {
        var objNewXML = emxUICore.createXMLDOM();
        for (var i=0; i < objXML.childNodes.length; i++) {
                objNewXML.appendChild(objXML.childNodes[i].cloneNode(true));
        }
        return objNewXML;
};

/**
 * Creates a DOM based on the given filter.
 * @param objXML The XML DOM to filter.
 * @param objRE The regular expression to match nodes against.
 * @return A filtered DOM copy.
 */
emxUIObjectChooser.prototype.generateFilteredDOM = function (objXML, objRE) {
        var objNewXML = this.duplicateDOM(objXML);
        var objRoot = emxUICore.getElementsByTagName(objNewXML, "aef:root")[0];
        var arrOrgs = emxUICore.selectNodes(objRoot, "//aef:org");
        
        for (var i=arrOrgs.length-1; i >= 0; i--) {
            var objText = emxUICore.getElementsByTagName(arrOrgs[i], "aef:text")[0];
            if (!objRE.test(objText.childNodes[0].nodeValue)) {
                objRoot.removeChild(arrOrgs[i]);
            }
        }
        return objNewXML;
};

/**
 * Creates a DOM based on the given filter.
 * @param objXML The XML DOM to filter.
 * @param objRE The regular expression to match nodes against.
 * @return A filtered DOM copy.
 */
emxUIObjectChooser.prototype.generateSearchFilteredDOM = function (objXML, objRE) {
        var objNewXML = this.duplicateDOM(objXML);
        var objRoot = emxUICore.getElementsByTagName(objNewXML, "aef:root")[0];
        var arrOrgs = emxUICore.selectNodes(objRoot, "//aef:org");
        var objTextValue = "";
        for (var i=arrOrgs.length-1; i >= 0; i--) {
        	var objText = emxUICore.getElementsByTagName(arrOrgs[i], "aef:text")[0];
        	objTextValue = objText.childNodes[0].nodeValue;
            if (!objRE.test(objTextValue)) {
                objRoot.removeChild(arrOrgs[i]);
            }
        }
        return objNewXML;
};

/**
 * Creates a regular expression based on the filter text.
 * @param strOpt The selected option index in the dropdown.
 * @param strFilter The filter text.
 * @return A regular expression matching the filter text.
 */
emxUIObjectChooser.prototype.createExpression = function (strOpt, strFilter) {
            
        strFilter = (strFilter.length > 0) ? strFilter : "*";

        strFilter = strFilter.replace(/^\s*/g, "");
        strFilter =  strFilter.replace(/\s+$/g, "");            
        
        strFilter = strFilter.replace(/([\.\$\^\[\]\(\)\{\}\+\-\?\|\\])/g, "\\ $1");
        strFilter = strFilter.replace(/(\\)\s([\.\$\^\[\]\(\)\{\}\+\-\?\|\\])/g, "$1$2");

        switch(strOpt){
                case 0:
                        strFilter += "*";
                        break;
                case 1:
                        strFilter = "*" + strFilter;
                        break;
                case 2:
                        strFilter = "*" + strFilter + "*";
                        break;
        }
        
        strFilter = "^" + strFilter.replace(/\*/g, ".*") + "$";
        strFilter = strFilter.replace(/\.\*\.\*/g, ".*");

        return new RegExp(strFilter);
};

/**
 * Returns the value of the selected item(s) in
 * the type chooser.
 * @return A string indicated the selected items.
 */
emxUIObjectChooser.prototype.getValue = function () {
        var arrInputs = this.container.getElementsByTagName("input");
        var arrTemp = new Array;
        
        for (var i=0; i < arrInputs.length; i++) {
                if (arrInputs[i].name=="radType") {
                        if (arrInputs[i].checked) {
                                return arrInputs[i].value;
                        }
                } else if (arrInputs[i].checked) {
                        arrTemp.push(arrInputs[i].value);                
                }
        }
        
        return arrTemp.toString();

};


/**
 * Returns the value of the selected item(s) in
 * the type chooser.
 * @return Array or String
 */
emxUIObjectChooser.prototype.getValueArray = function () {
        var arrInputs = this.container.getElementsByTagName("input");
        var arrTemp = new Array;
        
        for (var i=0; i < arrInputs.length; i++) {
                if (arrInputs[i].name=="radType") {
                        if (arrInputs[i].checked) {
                                return arrInputs[i].value;
                        }
                } else if (arrInputs[i].checked) {
                        arrTemp.push(arrInputs[i].value);                
                }
        }
        
        return arrTemp;

};

function compareDOMText(objA, objB) {

        var strA = emxUICore.getElementsByTagName(objA, "aef:text")[0].childNodes[0].nodeValue;
        var strB = emxUICore.getElementsByTagName(objB, "aef:text")[0].childNodes[0].nodeValue;
        
        if (strA < strB) {
                return -1;
        } else if (strA > strB){
                return 1;
        } else {
                return 0;
        }

}
