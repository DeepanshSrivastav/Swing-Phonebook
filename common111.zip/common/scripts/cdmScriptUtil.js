
function partSubmitvalidation(editForm){
	if($("input[name=TypeActualDisplay]").val() == "") {
        return false;
    }
    if($("input[name=Phase]").val() == "") {
        return false;
    }
    if($("input[name=Vehicle]").val() == "") {
        return false;
    }
    if($("input[name=PartName]").val() == "") {
        return false;
    }
    if($("input[name=Project]").val() == "") {
        return false;
    }
    if($("input[name=UnitOfMeasure]").val() == "") {
        return false;
    }
    if($("input[name=ECONumber]").val() == "") {
        return false;
    }
    if($("input[name=ProjectType]").val() == "") {
        return false;
    }
    if($("input[name=ProductType]").val() == "") {
        return false;
    }
    return true;
}

function clearPartForm(){
	$("input[name=TypeActualDisplay]").val('');
	$("input[name=Phase]").val('');
	$("input[name=PartNo]").val('');
	$("input[name=Vehicle]").val('');
	$("input[name=PartName]").val('');
	$("input[name=Project]").val('');
	$("input[name=ApprovalType]").val('');
	$("input[name=PartType]").val('');
	$("input[name=Global]").val('');
	$("input[name=DrawingNo]").val('');
	$("input[name=UnitOfMeasure]").val('');
	$("input[name=ECONumber]").val('');
	$("input[name=ItemType]").val('');
	$("input[name=OEMItemNumber]").val('');
	$("input[name=Comments]").val('');
	$("input[name=ChangeReason]").val('');
	$("input[name=Org1]").val('');
	$("input[name=Org2]").val('');
	$("input[name=Org3]").val('');
	$("input[name=ProjectType]").val('');
	$("input[name=ProductType]").val('');
	$("input[name=ERPInterface]").val('');
	$("input[name=Surface]").val('');
	$("input[name=EstimatedWeight]").val('');
	$("input[name=Material]").val('');
	$("input[name=RealWeight]").val('');
	$("input[name=Size]").val('');
	$("input[name=CADWeight]").val('');
	$("input[name=SurfaceTreatment]").val('');
	$("input[name=IsCasting]").val('');
	$("input[name=Option1]").val('');
	$("input[name=Option2]").val('');
	$("input[name=Option3]").val('');
	$("input[name=Option4]").val('');
	$("input[name=Option5]").val('');
	$("input[name=Option6]").val('');
	$("input[name=OptionETC]").val('');
	$("input[name=OptionDescription]").val('');
	$("input[name=PublishingTarget]").val('');
	
	$("input[type='checkbox']").prop("checked", false);
}