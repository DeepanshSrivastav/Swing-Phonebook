import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.ibatis.session.SqlSession;

import com.mando.util.SqlSessionUtil;
import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmDateUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.sun.org.apache.bcel.internal.generic.INSTANCEOF;

import matrix.db.Context;
import matrix.util.MatrixService;
import matrix.util.StringList;

public class cdmCatiaWebService_mxJPO implements MatrixService {
	String LINESEP = "[$$$LINE]";
	String VALUESEP = "[$VALUE]";
	String COUNTSEP = "[@COUNT]";
	String ENGSPECSEP = "[@ENGSPEC]";
	String EQUAL = "==";
	StringList basicInfoList = new StringList();
	
	public cdmCatiaWebService_mxJPO(Context context, String[] args){
		basicInfoList.add("current");
		basicInfoList.add("name");
		basicInfoList.add("revision");
		basicInfoList.add("originated");
		basicInfoList.add("modified");
		basicInfoList.add("type");
	}
	
	/**
	 * Returns the attribute value of the object.
	 * @param attributeName
	 * @param type
	 * @param name
	 * @param revision
	 * @return
	 * @throws Exception
	 */
	public String getObjectAttributeValue(String attributeName, String type, String name, String revision) throws Exception {
		String returnValue = "false@";
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		try{

			context = cadUtil.getEnoviaContext();

			StringList busSelect = new StringList();
			busSelect.add(attributeName);

			if (basicInfoList.contains(attributeName) == false) {
				String mqlResult = MqlUtil.mqlCommand(context, "print type " + type + " select " + attributeName + " dump");
				if ("FALSE".equals(mqlResult)) return returnValue + "Attribute is not Exist.";
			}

			String busWhere = "";
			if ("last".equals(revision)) {
				revision = "*";
				busWhere = "revision==last";
			}

			MapList findList = DomainObject.findObjects(	context,
															type, 
															name, 
															revision,
															"*",
															"*",
															busWhere,
															true,
															busSelect );

			String selectValue = null;

			if (findList.size() > 1) return returnValue + "Duplicate Part Number.";

			if (findList.size() > 0) {
				Map infoMap = (Map) findList.get(0);
				selectValue = (String) infoMap.get(attributeName);

				returnValue = "true@" + selectValue;
			} else {
				returnValue = returnValue + "Object is not Exist.";
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			returnValue = "false@" + e.toString();
		}

		return returnValue;
	}

	/**
	 * Returns the ID of the object.
	 * @param type
	 * @param name
	 * @param revision
	 * @return
	 * @throws Exception
	 */
	public String getObjectId(String type, String name, String revision) throws Exception {
		String returnValue = "";
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		try{

			context = cadUtil.getEnoviaContext();

			returnValue = cadUtil.getObjectId(context, type, name, revision);

		} catch (Exception e) {
			e.printStackTrace();
			returnValue = "false@" + e.toString();
		}

		return returnValue;
	}

	/**
	 * Update the attributes of an object
	 * @param attributeName
	 * @param value
	 * @param type
	 * @param name
	 * @param revision
	 * @return
	 * @throws Exception
	 */
	public String setObjectAttributeValue(String attributeName, String value, String type, String name, String revision) throws Exception {
		String returnValue = "false@";
		boolean isTran = false;
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		try{

			context = cadUtil.getEnoviaContext();

			StringList busSelect = new StringList();
			busSelect.add(cdmConstantsUtil.SELECT_ID);
			busSelect.add(attributeName);

			String busWhere = "";
			if ("last".equals(revision)) {
				revision = "*";
				busWhere = "revision==last";
			}

//			String mqlResult = MqlUtil.mqlCommand(context, "print type " + type + " select " + attributeName + " dump");
//			if ("FALSE".equals(mqlResult)) return returnValue + "Attribute is not exist.";

			MapList findList = DomainObject.findObjects(	context,
															type, 
															name, 
															revision,
															"*",
															"*",
															busWhere,
															true,
															busSelect );

			if (findList.size() > 0) {
				String objectId = null;
				ContextUtil.startTransaction(context, true);
				isTran = true;
				
				for (Iterator itr = findList.listIterator(); itr.hasNext();) {
					Map infoMap = (Map) itr.next();
					objectId = (String) infoMap.get(cdmConstantsUtil.SELECT_ID);
		
					DomainObject obj = DomainObject.newInstance(context, objectId);
					
					if (obj != null) {
						obj.setAttributeValue(context, attributeName, value);
					}
					returnValue = "true@";
				}
				ContextUtil.commitTransaction(context);
			} else {
				returnValue = returnValue + "Object is not Exist.";
			}

		} catch (Exception e) {
			e.printStackTrace();
			returnValue = "false@" + e.toString();
			if (isTran) ContextUtil.abortTransaction(context);
		}

		return returnValue;
	}
	
	/**
	 * Returns whether the object exists.
	 * @param type
	 * @param name
	 * @param revision
	 * @return
	 * @throws Exception
	 */
	public String isExistObject(String type, String name, String revision) throws Exception {
		String returnValue = "false@";
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		try{

			if (cdmStringUtil.isEmpty(revision)) revision = "*";

			if (cdmStringUtil.isEmpty(type)) type = "*";

			context = cadUtil.getEnoviaContext();

			StringList busSelect = new StringList();
			busSelect.add(cdmConstantsUtil.SELECT_ID);

			MapList findList = DomainObject.findObjects(	context,
															type, 
															name, 
															revision,
															"*",
															"*",
															"",
															true,
															busSelect );

			if (findList.size() > 0) returnValue = "true@";

		} catch (Exception e) {
			e.printStackTrace();
			returnValue = "false@" + e.toString();
		}

		return returnValue;
	}

	/**
	 * Returns the last revision of the object.
	 * @param type
	 * @param name
	 * @return
	 * @throws Exception
	 */
	public String getLastObjectRevision(String type, String name) throws Exception {
		String returnValue = "false@";
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		try{

			context = cadUtil.getEnoviaContext();

			StringList busSelect = new StringList();
			busSelect.add(cdmConstantsUtil.SELECT_REVISION);

			String busWhere = "policy!='" + cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY + "'";
			busWhere = busWhere + "&&revision==last";
       			MapList findList = DomainObject.findObjects(	context,
															type, 
															name, 
															"*",
															"*",
															"*",
															busWhere,
															true,
															busSelect );


			if (findList.size() > 1) return returnValue + "Duplicate Part Number.";

			String objectLastRev = null;
			if (findList.size() > 0) {
				Map infoMap = (Map) findList.get(0);
				objectLastRev = (String) infoMap.get(cdmConstantsUtil.SELECT_REVISION);

				returnValue = "true@" + objectLastRev;
			} else {
				returnValue = returnValue + "Object is Not Exist.";
			}

		} catch (Exception e) {
			e.printStackTrace();
			returnValue = "false@" + e.toString();
		}

		return returnValue;
	}

	/**
	 * Returns the name of the object connected to the object.
	 * @param type
	 * @param name
	 * @param revision
	 * @param relName
	 * @param derection
	 * @param connectType
	 * @return
	 * @throws Exception
	 */
	public String getConnectObject(String type, String name, String revision, String relName, String derection, String connectType) throws Exception {
		String returnValue = "false@";
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		try{
			context = cadUtil.getEnoviaContext();

			String objectId = getObjectId(type, name, revision);
			boolean isFrom = false;
			boolean isTo = true;

			if (objectId.startsWith("false")) return returnValue + "Duplicate Part Number.";

			DomainObject obj = DomainObject.newInstance(context, objectId);

			StringList busSelect = new StringList();
			busSelect.add(cdmConstantsUtil.SELECT_NAME);

			StringList relSelect = new StringList();

			if ("from".equals(derection)) {
				isFrom = true;
				isTo = false;
			}

			MapList findList = obj.getRelatedObjects(context,
													relName,
													connectType,
													busSelect,
													relSelect,
													isFrom,
													isTo,
													(short)0,
													null,
													null,
													0);

			if (findList.size() > 0) {
				returnValue = "true@";

				String objectName = "";
				for (Iterator itr = findList.listIterator(); itr.hasNext();) {
					Map tempMap = (Map) itr.next();
					returnValue = returnValue + (String) tempMap.get(cdmConstantsUtil.SELECT_NAME) + ",";
				}
				returnValue = returnValue.substring(0, returnValue.length() - 1);
			} else {
				returnValue = returnValue + "Object is not Exist.";
			}
		} catch (Exception e) {
			e.printStackTrace();
			returnValue = "false@" + e.toString();
		}

		return returnValue;
	}

	/**
	 * 
	 * @param type
	 * @param name
	 * @param revision
	 * @return
	 * @throws Exception
	 */
	public String getEBOMAssyList(String type, String name, String revision) throws Exception {
		String returnValue = "false@";
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		try{
			context = cadUtil.getEnoviaContext();

			MapList resultList = cadUtil.getAssyList(context, type, name, revision);

			String objectNumber = "";
			String objectName = "";
			String objectOEMNumber = "";
			Map objectMap = null;
			StringBuffer sb = new StringBuffer();
			if (resultList != null && resultList.size() > 0) {
				returnValue = "";
				for (Iterator itr = resultList.listIterator(); itr.hasNext();) {
					objectMap = (Map) itr.next();

					sb.append("PART NAME==");
					sb.append((String) objectMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_NAME));
					sb.append(VALUESEP);
					sb.append("PART NO==");
					sb.append((String) objectMap.get(cdmConstantsUtil.SELECT_NAME));
					sb.append(VALUESEP);
					sb.append("PART OEM NO==");
					sb.append((String) objectMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_OEM_ITEM_NUMBER));
					sb.append(LINESEP);
				}
				returnValue = sb.toString();
				if (returnValue.length() > 0) returnValue = returnValue.substring(0, returnValue.lastIndexOf(LINESEP));
			}
		} catch (Exception e) {
			e.printStackTrace();
			returnValue = "false@" + e.toString();
		}

		return returnValue;
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getEBOMPartList(String type, String name, String revision, String engSpec) throws Exception {
		StringBuffer sb = new StringBuffer();
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		DecimalFormat df = new DecimalFormat("#.######################################################################");
		try{
			context = cadUtil.getEnoviaContext();

			Map assyMap = null;
			Map childCountMap = new HashMap();
			Map tempMap = null;

			LinkedHashMap infoMap = new LinkedHashMap();

			String assyId = null;
			String ebomPartId = "";
			String quantity = "";
			String childCount = "";
			String count = null;
			String isSize = null;
			String isSurfaceTreatment = null;
			String finishValue = null;
			String itemNo = null;
			String splitItemNo = null;
			String resultItemNo = null;
			String showValue = null;
			String childPartName = null;
			String attrName = null;
			String attrValue = null;
			String vehicleValue = null;

			Object vehicle = null;

			StringList itemNoList = null;
			StringList engSpecList = new StringList();
			if (cdmStringUtil.isNotEmpty(engSpec)) {
				engSpec = engSpec.replace("$VALUE", "");
				engSpecList = new StringList(engSpec.split("\\[\\]"));
			}
			MapList childMapList = new MapList();

			DomainObject parentObj = DomainObject.newInstance(context);

			MapList assyList = cadUtil.getAssyList(context, type, name, revision);
			for (Iterator itr = assyList.listIterator(); itr.hasNext();) {
				assyMap = (Map) itr.next( );
				assyId = (String) assyMap.get(cdmConstantsUtil.SELECT_ID);
				parentObj.setId(assyId);
				MapList ebomList = cadUtil.getEbomList(context, parentObj);

				// Set Child Count Map for each Assy.
				// If there is no existing value, set the value "-"
				// ChildCountMap has "AssyObjectId + ChildObjectId" as a Key value.
				cadUtil.initCountMap(childCountMap, assyList, ebomList);

				for (Iterator ebomItr = ebomList.listIterator(); ebomItr.hasNext();) {
					tempMap = (Map) ebomItr.next();
					ebomPartId = (String) tempMap.get(cdmConstantsUtil.SELECT_ID);
					quantity = (String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
					childCount = (String) childCountMap.get(assyId + ebomPartId);

					if(cdmStringUtil.isNotEmpty(childCount) && "-".equals(childCount) == false) {
//						double childCnt = Double.parseDouble(childCount);
//						double qty = Double.parseDouble(quantity);
//						qty = qty + childCnt;
//						childCountMap.put(assyId + ebomPartId, Double.toString(qty));
					} else {
						childCountMap.put(assyId + ebomPartId, quantity);
						if(infoMap.containsKey(ebomPartId) == false) {  
							if (childMapList.contains(tempMap) == false) childMapList.add(tempMap);
							infoMap.put(ebomPartId, tempMap);
						}
					}
				}
			}
			
			// Set Item No
			cadUtil.setItemNo(childMapList, infoMap);

			LinkedHashMap lhMap = cadUtil.setListSortMap(childMapList, infoMap);

			cadUtil.setSkipItemNo(childMapList, lhMap);

			Set keySet = lhMap.keySet();

			for (Iterator keyItr = keySet.iterator(); keyItr.hasNext();) {
				String key = (String) keyItr.next();

				tempMap = (Map) lhMap.get(key);
				ebomPartId = (String) tempMap.get(cdmConstantsUtil.SELECT_ID);
				childPartName = (String) tempMap.get(cdmConstantsUtil.SELECT_NAME);
				vehicle = tempMap.get("to[" + cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE + "].from." + cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_COMMON_CODE);

				StringList vehicleList = new StringList();
				vehicleValue = "";
				if (vehicle instanceof String) {
					vehicleList.add((String) vehicle);
				} else {
					vehicleList = (StringList) vehicle;
				}

				if (vehicleList != null) {
					for (Iterator vehItr = vehicleList.listIterator(); vehItr.hasNext();) {
						vehicleValue = (String) vehItr.next();
						vehicleValue = vehicleValue + ",";
					}
					vehicleValue = vehicleValue.substring(0, vehicleValue.length() - 1);
				}
				if(cdmStringUtil.isEmpty(vehicleValue)) vehicleValue = "";

				finishValue = "";
				isSurfaceTreatment = (String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_APPLY_SURFACE_TREATMENT_LIST);
				if ("true".equals(isSurfaceTreatment)) {
					finishValue = finishValue + (String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_SURFACE_TREATMENT);
				}

				isSize = (String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_APPLY_SIZE_LIST);
				if ("true".equals(isSize)) {
					if (cdmStringUtil.isNotEmpty(finishValue)) finishValue = finishValue + "\\n";
					finishValue = finishValue + (String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_SIZE);
				}

				// [B] Item No
				itemNo = (String) tempMap.get("ITEM_NO");
				itemNoList = FrameworkUtil.split(itemNo, "-");

				resultItemNo = "";
				for (Iterator itemNoItr = itemNoList.listIterator(); itemNoItr.hasNext();) {
					splitItemNo = (String) itemNoItr.next();
					resultItemNo = resultItemNo + Integer.parseInt(splitItemNo) + "-";
				}
				if (cdmStringUtil.isNotEmpty(resultItemNo)) resultItemNo = resultItemNo.substring(0, resultItemNo.length() - 1);

				// If ITEM NO is 99999, blank
				if ("99999".equals(resultItemNo)) resultItemNo = "";
				// [E] Item No

				// [B] Set Show Value
				showValue = (String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_APPLY_PART_LIST);
				if (cdmStringUtil.isEmpty(showValue)) showValue = "true";
				// [E] Set Show Value
				// [AssyName]==[ChildCount]
				assyList.sort(cdmConstantsUtil.SELECT_NAME, "decending", "string");
				for (Iterator assyItr = assyList.listIterator(); assyItr.hasNext();) {
					assyMap = (Map) assyItr.next();
					assyId = (String) assyMap.get(cdmConstantsUtil.SELECT_ID);
					count = (String) childCountMap.get(assyId + ebomPartId);

					if (count.indexOf(".") > -1) count = df.format(Double.parseDouble(count));

					sb.append((String) assyMap.get(cdmConstantsUtil.SELECT_NAME));
					sb.append(EQUAL);
					sb.append(count);
					sb.append(VALUESEP);
				}

				sb.append(COUNTSEP);
				sb.append("SHOW==");
				sb.append(showValue);
				sb.append(VALUESEP);
				sb.append("PART NO==");
				sb.append(childPartName);
				sb.append(VALUESEP);
				sb.append("PART NAME==");
				sb.append((String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_NAME));
				sb.append(VALUESEP);
				sb.append("REV==");
				sb.append((String) tempMap.get(cdmConstantsUtil.SELECT_REVISION));
				sb.append(VALUESEP);
				sb.append("ITEM NO==");
				sb.append(resultItemNo); // ITEM NO
				sb.append(VALUESEP);
				sb.append("MATERIAL==");
				sb.append((String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_MATERIAL));
				sb.append(VALUESEP);
				sb.append("FINISH==");
				sb.append(finishValue); // FINISH
				sb.append(VALUESEP);
				sb.append("OEM PART NO==");
				sb.append((String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_OEM_ITEM_NUMBER)); // OEM PART NO.
				sb.append(VALUESEP);
				sb.append("VEHICLE==");
				sb.append(vehicleValue);
				sb.append(VALUESEP);
				sb.append("OP Seq==");
				sb.append((String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_FIND_NUMBER)); // OP Seq

				// [B] Set Engine Spec.
				System.out.println(">>>>>>>>>>>>>>>>>>>>>>>> ebomPartId :: " + ebomPartId);
				if (engSpecList.size() > 0) {
					Map attributeGroupValues = cadUtil.getAttributeGroupValueMap(context, ebomPartId);
					sb.append(ENGSPECSEP);
					for (Iterator esItr = engSpecList.listIterator(); esItr.hasNext();) {
						attrName = (String) esItr.next();
						attrValue = (String) attributeGroupValues.get(attrName);
						if (cdmStringUtil.isEmpty(attrValue)) attrValue = "";
						sb.append(attrName).append("==");
						sb.append(attrValue);
						sb.append(VALUESEP);
					}
				}
				sb.setLength(sb.length() - VALUESEP.length());
				// [E] Set Engine Spec.

				if (keyItr.hasNext()) sb.append(LINESEP);
			}
		} catch (Exception e) {
			e.printStackTrace();
			sb.append("false@" + e.toString());
		}
		System.out.println(">>>>>>>>>> Result :: " + sb.length());
		System.out.println(">>>>>>>>>> Result :: " + sb);
		return sb.toString();
	}

	public String getAttributeGroupValuesOfPart(String type, String name, String revision) throws Exception {
		String resultValue = "false@";
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		try {
			context = cadUtil.getEnoviaContext();

			String partId = getObjectId(type, name, revision);

			if (cdmStringUtil.isEmpty(partId)) resultValue = resultValue + "Object is not Exist.";

			
			MapList attributeGroupValues = cadUtil.getAttributeGroupValues(context, partId);

			Map attributeGroupMap = null;
			StringBuffer sb = new StringBuffer();
			String attrName = "";
			String attrValue = "";
			for (Iterator itr = attributeGroupValues.listIterator(); itr.hasNext();) {
				attributeGroupMap = (Map) itr.next();
				attrName = (String) attributeGroupMap.get("attrName");
				attrValue = (String) attributeGroupMap.get("attrValue");
				sb.append(attrName);
				sb.append(EQUAL);
				sb.append(attrValue);
				sb.append(VALUESEP);
			}
			resultValue = sb.toString();
			if (resultValue.length() > 0) resultValue = resultValue.substring(0, resultValue.lastIndexOf(VALUESEP));
		} catch (Exception e) {
			e.printStackTrace();
			resultValue = resultValue + e.toString();
		}
		return resultValue;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String getEBOMPartNumber(String name) throws Exception {
		String result = "false@";
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		try {
			context = cadUtil.getEnoviaContext();
			
			Map paramMap = new HashMap();
			paramMap.put("newName", name);
			result = cadUtil.getSpecificationPartNumber(context, paramMap);
			result = "true@" + result;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * Returns the object corresponding to the type name.
	 * @param type
	 * @param name
	 * @param isLastRevision
	 * @return
	 * @throws Exception
	 */
	public String getObjectList(String type, String name, String isLastRevision) throws Exception {
		String returnValue = "false@";
		Context context = null;
		cdmCADUtil_mxJPO cadUtil = new cdmCADUtil_mxJPO();
		String revision = "*";
		try{

			context = cadUtil.getEnoviaContext();

			StringList busSelect = new StringList();
			busSelect.add(cdmConstantsUtil.SELECT_NAME);
			busSelect.add(cdmConstantsUtil.SELECT_REVISION);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_NAME);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
			busSelect.add(cdmConstantsUtil.SELECT_CURRENT);
			busSelect.add(cdmConstantsUtil.SELECT_TYPE);
			busSelect.add(cdmConstantsUtil.SELECT_OWNER);
			busSelect.add("to[" + cdmConstantsUtil.RELATIONSHIP_AFFECTED_ITEM + "].from.name");
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_DRAWING_NO);
			busSelect.add("to["+cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE+"].from.attribute[cdmCommonCodeNameKo]");
			busSelect.add("to[" + cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE + "].from." + cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_COMMON_CODE);
			busSelect.add(cdmConstantsUtil.SELECT_MODIFIED);

			String busWhere = "";
			if ("true".equals(isLastRevision)) {
				busWhere = "revision==last";
			}

			MapList findList = DomainObject.findObjects(	context,
															type, 
															name, 
															revision,
															"*",
															"*",
															busWhere,
															true,
															busSelect );

			if (findList.size() == 0) return returnValue + "Object Is Not Exist.";

			Map objMap = null;
			
			String resultName = null;
			String resultRevision = null;
			String resultPartName = null;
			String resultReleasePhase = null;
			String resultCurrent = null;
			String resultType = null;
			String resultOwner = null;
			String resultECONo = null;
			String resultDrawingNo = null;
			String resultProductDivision = null;
			String resultVehicle = null;
			String resultModified = null;

			int count = 1;
			StringBuffer sb = new StringBuffer();

			for (Iterator findItr = findList.listIterator(); findItr.hasNext();) {
				objMap = (Map) findItr.next();
				
				resultName = (String) objMap.get(cdmConstantsUtil.SELECT_NAME);
				resultRevision = (String) objMap.get(cdmConstantsUtil.SELECT_REVISION);
				resultPartName = (String) objMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_NAME);
				resultReleasePhase = (String) objMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_RELEASE_PHASE);
				resultCurrent = (String) objMap.get(cdmConstantsUtil.SELECT_CURRENT);
				resultType = (String) objMap.get(cdmConstantsUtil.SELECT_TYPE);
				resultOwner = (String) objMap.get(cdmConstantsUtil.SELECT_OWNER);
				resultECONo = (String) objMap.get("to[" + cdmConstantsUtil.RELATIONSHIP_AFFECTED_ITEM + "].from.name");
				resultDrawingNo = (String) objMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_DRAWING_NO);
				resultProductDivision = (String) objMap.get("to["+cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE+"].from.attribute[cdmCommonCodeNameKo]");
				resultVehicle = (String) objMap.get("to[" + cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE + "].from." + cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_COMMON_CODE);
				resultModified = (String) objMap.get(cdmConstantsUtil.SELECT_MODIFIED);

				resultModified = cdmDateUtil.getFormatDisplayDate(context, resultModified);

				if (cdmStringUtil.isEmpty(resultVehicle)) resultVehicle = "";
				if (resultVehicle.indexOf("") > -1) resultVehicle = resultVehicle.replace("", ",");

				sb.append("NO").append(EQUAL).append(Integer.toString(count)).append(VALUESEP);
				sb.append("NAME").append(EQUAL).append(resultName).append(VALUESEP);
				sb.append("PART NAME").append(EQUAL).append(resultPartName).append(VALUESEP);
				sb.append("REVISION").append(EQUAL).append(resultRevision).append(VALUESEP);
				sb.append("RELEASE PHASE").append(EQUAL).append(resultReleasePhase).append(VALUESEP);
				sb.append("STATE").append(EQUAL).append(resultCurrent).append(VALUESEP);
				sb.append("TYPE").append(EQUAL).append(resultType).append(VALUESEP);
				sb.append("OWNER").append(EQUAL).append(resultOwner).append(VALUESEP);
				sb.append("ECO NUMBER").append(EQUAL).append(resultECONo).append(VALUESEP);
				sb.append("DRAWING NO").append(EQUAL).append(resultDrawingNo).append(VALUESEP);
				sb.append("PRODUCT DIVISION").append(EQUAL).append(resultProductDivision).append(VALUESEP);
				sb.append("VEHICLE").append(EQUAL).append(resultVehicle).append(VALUESEP);
				sb.append("LAST MODIFIED").append(EQUAL).append(resultModified);
				sb.append(LINESEP);
				count++;
			}
			sb.setLength(sb.length() - LINESEP.length());
			returnValue = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
			returnValue = "false@" + e.toString();
		}

		return returnValue;
	}

	public String getPLMState(String PARTNO) throws Exception {
		String resultValue = "";
		try{
			if (cdmStringUtil.isEmpty(PARTNO)) return resultValue = "false@Parameter is Empty!!";
			Map paramMap = new HashMap();
	
			paramMap.put("PARTNO", PARTNO);

			List<Map<String, String>> resultList = getSqlList("getPLMState", paramMap);
			resultValue = getParsingKeyValue(resultList);
		} catch (Exception e) {
			e.printStackTrace();
			resultValue = "false@" + e.toString();
		}
		return resultValue;
	}

	public String getCodeName(String MAINCODE, String SUBCODE) throws Exception {
		String resultValue = "";
		try{
			if (cdmStringUtil.isEmpty(MAINCODE) || cdmStringUtil.isEmpty(SUBCODE)) return resultValue = "false@Parameter is Empty!!";
			Map paramMap = new HashMap();
	
			paramMap.put("MAINCODE", MAINCODE);
			paramMap.put("SUBCODE", SUBCODE);

			List<Map<String, String>> resultList = getSqlList("getCodeName", paramMap);
			resultValue = getParsingKeyValue(resultList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultValue;
	}

	public String getUniqueCatiaFileChecker(String MAINCODE, String SUBCODE) throws Exception {
		String resultValue = "";
		try{
			if (cdmStringUtil.isEmpty(MAINCODE) || cdmStringUtil.isEmpty(SUBCODE)) return resultValue = "false@Parameter is Empty!!";
			Map paramMap = new HashMap();

			paramMap.put("MAINCODE", MAINCODE);
			paramMap.put("SUBCODE", SUBCODE);

			List<Map<String, String>> resultList = getSqlList("getUniqueCatiaFileChecker", paramMap);
			resultValue = getParsingKeyValue(resultList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultValue;
	}

	public String getPartNumberName(String PARTNO) throws Exception {
		String resultValue = "";
		try{
			if (cdmStringUtil.isEmpty(PARTNO)) return resultValue = "false@Parameter is Empty!!";
			Map paramMap = new HashMap();

			paramMap.put("PARTNO", PARTNO);

			List<Map<String, String>> resultList = getSqlList("getPartNumberName", paramMap);
			resultValue = getParsingKeyValue(resultList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultValue;
	}

	public String getPLMStateNotRev(String PARTNO) throws Exception {
		String resultValue = "";
		try{
			if (cdmStringUtil.isEmpty(PARTNO)) return resultValue = "false@Parameter is Empty!!";

			Map paramMap = new HashMap();
	
			paramMap.put("PARTNO", PARTNO);

			List<Map<String, String>> resultList = getSqlList("getPLMStateNotRev", paramMap);
			resultValue = getParsingKeyValue(resultList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultValue;
	}

	public String getPLMStateRev(String PARTNO, String PARTREV) throws Exception {
		String resultValue = "";
		try{
			if (cdmStringUtil.isEmpty(PARTNO) || cdmStringUtil.isEmpty(PARTREV)) return resultValue = "false@Parameter is Empty!!";
			Map paramMap = new HashMap();
	
			paramMap.put("PARTNO", PARTNO);
			paramMap.put("PARTREV", PARTREV);

			List<Map<String, String>> resultList = getSqlList("getPLMStateRev", paramMap);
			resultValue = getParsingKeyValue(resultList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultValue;
	}

	public List<Map<String, String>> getSqlList(String key, Map paramMap) throws Exception {
		SqlSessionUtil.reNew("plm");
		SqlSession sqlSession = SqlSessionUtil.getSqlSession();
		List<Map<String, String>> resultList = null;
		try {
			resultList = sqlSession.selectList(key, paramMap);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (sqlSession != null) {
				try { sqlSession.close(); } catch (Exception ex) {}
			}
		}
		return resultList;
	}

	public String getParsingKeyValue(List<Map<String, String>> list) throws Exception {
		String resultValue = "";
		try {
			Map listMap = null;
			Set keySet = null;
			Iterator keyItr = null;
			String key = null;
			String value = null;
			StringBuffer sb = new StringBuffer();

			if (list == null || list.size() == 0) return resultValue = "false@No Data";

			for (Iterator listItr = list.listIterator(); listItr.hasNext();) {
				listMap = (Map) listItr.next();
				keySet = listMap.keySet();
				keyItr = keySet.iterator();
				while (keyItr.hasNext()) {
					key = (String) keyItr.next();
					value = listMap.get(key) + "";
					if (cdmStringUtil.isEmpty(value)) value = "";
					sb.append(key).append(EQUAL).append(value).append(VALUESEP);
				}
				sb.setLength(sb.length() - VALUESEP.length());
				sb.append(LINESEP);
			}
			sb.setLength(sb.length() - LINESEP.length());
			resultValue = sb.toString();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultValue;
	}
}
