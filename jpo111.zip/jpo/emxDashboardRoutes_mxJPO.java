import matrix.db.Context;


public class emxDashboardRoutes_mxJPO extends emxDashboardRoutesBase_mxJPO {
	
    /**
     * @param context
     * @param args
     * @throws Exception
     */
    public emxDashboardRoutes_mxJPO(Context context, String[] args) throws Exception {
    	super(context, args);
    } 

}
