//
// $Id: ${CLASSNAME}.java.rca 1.5 Wed Oct 22 16:54:21 2008 przemek Experimental przemek $ 
//
import java.util.Map;
import matrix.db.Context;
import com.matrixone.apps.domain.util.*;
import com.matrixone.apps.classification.ClassificationUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import matrix.db.BusinessObject;
import matrix.db.RelationshipType;
import matrix.util.MatrixException;
import matrix.util.StringList;

public class emxMultipleClassificationClassification_mxJPO extends emxMultipleClassificationClassificationBase_mxJPO
{
    public emxMultipleClassificationClassification_mxJPO (Context context, String[] args)  throws Exception
    {
        super(context, args);
    }
}
