import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.beans.MCADConfigObjectLoader;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.beans.MCADServerGeneralUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADGlobalConfigObject;
import com.matrixone.MCADIntegration.utils.MCADUtil;
import com.matrixone.apps.classification.AttributeGroup;
import com.matrixone.apps.classification.Classification;
import com.matrixone.apps.domain.DomainAccess;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainSymbolicConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.domain.util.mxBus;
import com.matrixone.apps.engineering.EBOMAutoSync;
import com.matrixone.apps.engineering.EBOMMarkup;
import com.matrixone.apps.engineering.EngineeringConstants;
import com.matrixone.apps.engineering.EngineeringUtil;
import com.matrixone.apps.engineering.PartFamily;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralConstants;
import com.matrixone.apps.library.PartLibrary;
import com.matrixone.apps.manufacturerequivalentpart.Part;
import com.matrixone.jdom.Element;
import com.matrixone.search.index.Config.formatIndexedType;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.BusinessType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.MatrixWriter;
import matrix.db.RelationshipType;
import matrix.util.DateFormatUtil;
import matrix.util.List;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;
import com.mando.util.cdmCommonExcel;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

/**
 * part 이 존재하는 경우에 eng spec 이 붙여지는 경우로 생성된 migration
 *  
 *  
 * @author mj
 *
 */
public class cdmECMigration_mxJPO {
	public BufferedWriter consoleWriter			 = null;
	public BufferedWriter logWriter 			 = null;
	
	public BufferedWriter successObjectidWriter  = null;
	public BufferedWriter failedObjectidWriter   = null;
	public BufferedWriter errorLogFile        	 = null;
	public BufferedWriter debugLogFile           = null;
	public BufferedReader bufferReader           = null;
	       
	public String inputDirectory 			= "";
	public String outputDirectory 			= "";
	public String fileName 		        	= "";
	        
	public String failedIdsLogsDirectory 	= "";
	public PrintStream errorStream		    = null;
	public File successLogFile 				= null;
	public File failedLogFile 				= null;
	public Integer sequenceInt ;
	
	public static final String S_CLASSIFICATION_ATTRIBUTE_GROUPS 		= DomainConstants.INTERFACE_CLASSIFICATION_ATTRIBUTE_GROUPS;
	public static final String S_FILESEPARATOR 							= "\\";
	public static final String S_UNDERLINE  							= "_";
	public static final String S_COLON   								= ":";
	public static final String S_ACTIVEVERSION                            = cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION;
	public static final String S_OUTPUT_DIRECTORY						= "MIGRATION_LOGS";
	
	public int  mxMain(Context context,String args[])throws Exception{
		return 0;
	}
	
	/**
	 * 
	 * 파라미터 데이타를 사용하지않고 
	 * argTest 이라는 string[] 에 직접 입력하여  initializeM 호출
	 * 
	 * args[0] :inputDirectory 파일 경로 정보 (파일명 포함되지않음) 
	 * args[1] : file name
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void executeECMigration(Context context, String args[])throws Exception{
		long startTime = System.currentTimeMillis();
		System.out.println("[cdmECMigration_mxJPO : executeECMigration] start ."+cdmCommonExcel.getTimeStamp2() );
		
		
		String logFileName = "ECMigration";
		if(args.length!=1){
			throw new Exception("The excel path does not exist.");
		}
		String sFileLocationAndFileName = args[0];
		
		String sFileLocation 		= "";
		String sFileName 			= "";
//		Map paramMap = (HashMap)JPO.unpackArgs(args);
//		String sFileLocationAndFileName =(String)paramMap.get("File");
		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
			
		
//		String[] argTest = {"C:\\temp\\Import_File\\EC","20161010_EC_Info_01.txt"};
		String[] argTest = {sFileLocation,sFileName};
		//context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		initializeM(context,argTest,2,logFileName);    
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("     EC DATA MIGRATION "+ getTimeStamp()+" \n");
		writeMessageToConsole("		Reading input log file from : "+inputDirectory+fileName);
		writeMessageToConsole("		Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		int lineNumber = 0;
		String recordEC_Code = "";
		String recordRowNum     = "";
		StringList stListHeader = new StringList();
		int failCount 	= 0;
		int successCount = 0;
		int totalCount = 0;
		
		String sRecordRowNum         = "";
		String sRecordTypeName       = "";
		String sRecordTempState      = "";
		String sRecordId       		 = "";
		String sRecordPhase          = "";
		String sRecordUser			 = "";
		String sRecordUSER_ID_MOD    = "";
		String sRecordAPPROVAL_DATE  = "";
		String sRecordProject		 = "";
		String sRecordProjectCust	 = "";
		String sRecordProduct_Type   = "";
		String sRecordEC_Type    	 = "";
		String sRecordEC_Code        = "";
		String sRecordTeam        	 = "";
		String sRecordPerson_Change  = "";
		String sRecordPeo_Type  	 = "";
		String sRecordProjectId      = "";
		String sRecordProductGroup   = "";
		String sRecordVehicle        = "";
		String sRecordProjectRelId   = "";
		String sRecordProductGroupRel  = "";
		String sRecordVehicleRel       = "";
		
		String sPhysicalNumberRows = "";
		try {
			String stReadData = "";
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, "");
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			StringBuffer sbErrorMessage = new StringBuffer("");
			boolean checkTriggerOff = false;
			totalCount = physicalNumberRows-1;
			for (int i = 1; i < physicalNumberRows; i++) {
				try {
					XSSFRow row = sheet.getRow(i);
					sPhysicalNumberRows = String.valueOf(i+1);
					//comment 와 description은 다시 돌릴것 
					Cell cell_0 		 = row.getCell(0);// CLASS_NAME
					Cell cell_1 		 = row.getCell(1);// STATE
					Cell cell_2 		 = row.getCell(2);// CN_ID
					Cell cell_3 		 = row.getCell(3);// PHASE
					Cell cell_4 		 = row.getCell(4);// USER_OBJECT_ID
					Cell cell_5 		 = row.getCell(5);// USER_ID_MOD
					Cell cell_6 		 = row.getCell(6);// APPROVAL_DATE
					Cell cell_7 	     = row.getCell(7); //CN_PROJECT
					Cell cell_8          = row.getCell(8); //CN_PROJECT_CUST
					Cell cell_9          = row.getCell(9); //CN_PRODUCT_TYPE
					Cell cell_10         = row.getCell(10);//CN_EC_TYPE
					Cell cell_11         = row.getCell(11);//CN_EC_CODE
					Cell cell_12         = row.getCell(12);//CN_TEAM
					Cell cell_13         = row.getCell(13);//CN_PERSON_IN_CHARGE
					Cell cell_14         = row.getCell(14);//CN_PEO_TYPE
					Cell cell_15         = row.getCell(15);//CN_PROJECT_ID
					Cell cell_16         = row.getCell(16);//PROD_GROUP
					Cell cell_17         = row.getCell(17);//CN_CUST_VEHICLE
					Cell cell_18         = row.getCell(18);//CN_PROJECT_REL_ID
					Cell cell_19         = row.getCell(19);//PROD_GROUP_REL
					Cell cell_20         = row.getCell(20);//CN_CUST_VEHICLE_REL
					Cell cell_21         = row.getCell(21);//CREATION_DATE

					String sRowNum           = String.valueOf(i+1);                                                      //                                                      
					String sTypeName         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_0));     // CLASS_NAME                                            
					String sTempState        = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_1 ));     // STATE                                                
					String sId       		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_2 ));    // CN_ID				,migration 대상자 아님                  
					String sPhase            = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_3 ));    // PHASE                                                 
					String sUser			 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_4 ));    // USER_OBJECT_ID                                        
					String sUSER_ID_MOD    = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_5 ));    // USER_ID_MOD   		,migration 대상자 아님                  
					String sAPPROVAL_DATE  = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_6 ));    // APPROVAL_DATE      ,migration 대상자 아님                  
					String sProject			 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_7));     // CN_PROJECT                                                                            
					String sProjectCust		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_8));     // CN_PROJECT_CUST                                   
					String sProduct_Type     = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_9));     // CN_PRODUCT_TYPE                                   
					String sEC_Type    		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_10));    // CN_EC_TYPE                                        
					String sEC_Code          = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_11));    // CN_EC_CODE                                        
					String sTeam        	 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_12));    // CN_TEAM                                           
					String sPerson_Change    = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_13));    // CN_PERSON_IN_CHARGE , PLM 에서 생성한 EC 사용자 user 정보   
					String sPeo_Type  		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_14));    // CN_PEO_TYPE   
					String sProjectId        = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_15));    // ProjectId                                           
					String sProductGroup     = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_16));    // PROD_GROUP                                           
					String sVehicle         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_17));     // CN_CUST_VEHICLE                                           
					//sProjectId,sProductGroup,sVehicle 정보가 없으면 아래의 3개 정보를 검색하여 사용한다. 이 데이타는 추후 추합또는 변경될수 있는 정보(다시 마이그레이션 진행할시 테스트 필요 ) 12/27
					String sProjectRelId      = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_18));     //CN_PROJECT_REL_ID                                       
					String sProductGroupRel   = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_19));     //PROD_GROUP_REL                                            
					String sVehicleRel         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_20));    //CN_CUST_VEHICLE_REL                                       
					String sCreateDate         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_21));    //CREATION_DATE                                       

					sRecordRowNum         = sRowNum           ;
					sRecordTypeName       = sTypeName         ;
					sRecordTempState      = sTempState        ;
					sRecordId       	  = sId       		 ;
					sRecordPhase          = sPhase            ;
					sRecordUser			  = sUser			 ;
					sRecordUSER_ID_MOD    = sUSER_ID_MOD    ;
					sRecordAPPROVAL_DATE  = sAPPROVAL_DATE  ;
					sRecordProject		  = sProject			;
					sRecordProjectCust	  = sProjectCust		;
					sRecordProduct_Type   = sProduct_Type   ;
					sRecordEC_Type    	  = sEC_Type    		;
					sRecordEC_Code        = sEC_Code        ;
					sRecordTeam        	  = sTeam        	 ;
					sRecordPerson_Change  = sPerson_Change    ;
					sRecordPeo_Type  	  = sPeo_Type  		;
					sRecordProjectId      = sProjectId        ;
					sRecordProductGroup   = sProductGroup     ;
					sRecordVehicle        = sVehicle          ;
					sRecordProjectRelId    = sProjectRelId          ;
					sRecordProductGroupRel = sProductGroupRel          ;
					sRecordVehicleRel      = sVehicleRel          ;
					
					String sStatePolicy = "";
				
					recordRowNum = sRowNum;
					recordEC_Code = sEC_Code;
					
					ContextUtil.startTransaction(context, true);
					if(UIUtil.isNullOrEmpty(sProjectId) && UIUtil.isNullOrEmpty(sProductGroup) && (" - ".equals(sVehicle) || UIUtil.isNullOrEmpty(sVehicle)) && UIUtil.isNullOrEmpty(sProjectRelId) && UIUtil.isNullOrEmpty(sProductGroupRel) && (UIUtil.isNullOrEmpty(sVehicleRel) || " - ".equals(sVehicleRel) )){
						failCount++;
						writeErrorToFile("LINE NUMBER: \t"+sPhysicalNumberRows +"\t" + "not projectId And Security Info not Exist. \t 5");
					}
					
					MqlUtil.mqlCommand(context, "Trigger Off");
					checkTriggerOff = true;
					
//					boolean checkOwner = false;
//					boolean checkOrg = false;
//					boolean checkProject = false;
//					boolean bOrgAndProjectExist = false;
//					
//					boolean checkRelOrg = false;
//					boolean checkRelProject = false;
//					boolean bOrgAndProjectRelExist = false;
					String sOwner = "";
//					String findOrg = "list role $1 select $2 dump;";
//					if (cdmStringUtil.isNotEmpty(sVehicle) && cdmStringUtil.isNotEmpty(sProductGroup)) {
//						String str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sVehicle, "isanorg" });
//						if ("TRUE".equalsIgnoreCase(str2)) {
//							findOrg = "list role $1 select $2 dump;";
//							str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sProductGroup, "isaproject" });
//							if ("TRUE".equalsIgnoreCase(str2)) {
//								checkOrg = true;
//								checkProject = true;
//								bOrgAndProjectExist = true;
//							}
//						}
//					}
					
//		
//					String findRelOrg = "list role $1 select $2 dump;";
//					if (cdmStringUtil.isNotEmpty(sVehicleRel) && cdmStringUtil.isNotEmpty(sProductGroupRel)) {
//						String str2 = MqlUtil.mqlCommand(context, findRelOrg, true, new String[] { sVehicleRel, "isanorg" });
//						if ("TRUE".equalsIgnoreCase(str2)) {
//							findRelOrg = "list role $1 select $2 dump;";
//							str2 = MqlUtil.mqlCommand(context, findRelOrg, true, new String[] { sProductGroupRel, "isaproject" });
//							if ("TRUE".equalsIgnoreCase(str2)) {
//								checkRelOrg = true;
//								checkRelProject = true;
//								bOrgAndProjectRelExist = true;
//							}
//						}
//					}
					
					String tempCreatedDate = "";
					if(UIUtil.isNotNullAndNotEmpty(sCreateDate)){
						Date createdate = new Date(sCreateDate);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa", new Locale("en", "US"));
						tempCreatedDate = sdf.format(createdate); 
					}
					
					
					boolean notExistProject    = false;
					boolean checkProjectRelExist = false;
					String sProjectCommonCode                = cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE;
//					String sProjectGroupCustomerAttribute	 = cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_CUSTOMER_ATTRIBUTE;
//					String sProjectGroupProductTypeAttribute = cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE;
//					String sProejctMql = MqlUtil.mqlCommand(context, " temp query bus cdmProjectGroupObject * * where \" attribute["+sProjectCommonCode+"] =='"+sProject +"' &&  attribute["+sProjectGroupCustomerAttribute+"] =='" + sProjectCust + "' && attribute["+sProjectGroupProductTypeAttribute+"] == '" + sProduct_Type + "' \" select id dump |");
//					String sProejctMql = MqlUtil.mqlCommand(context, " temp query bus cdmProjectGroupObject * * where \" attribute["+sProjectCommonCode+"] =='"+sProject +"' &&  from[cdmProjectGroupRelationshipCustomer].to.attribute[cdmCommonCode] == '" + sProjectCust + "' && from[cdmProjectGroupRelationshipProductType].to.attribute[cdmCommonCodeNameEn] == '" + sProduct_Type + "' \" select id dump |");
					String sProjectMql = "";
					if(UIUtil.isNotNullAndNotEmpty(sProjectId)){
						
						sProjectMql = MqlUtil.mqlCommand(context, " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectObjectIdM] =='"+sProjectId+"' \" select id dump |");
					}else if(UIUtil.isNotNullAndNotEmpty(sProjectRelId)){
						sProjectMql = MqlUtil.mqlCommand(context, " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectObjectIdM] =='"+sProjectRelId+"' \" select id dump |");
						checkProjectRelExist = true;
					}
					StringList stListProjectMqlResult = FrameworkUtil.split(sProjectMql, "|");
					String stProjectId = "";
					if(stListProjectMqlResult.size()>2){
						stProjectId = (String)stListProjectMqlResult.get(3);
					}else{
						notExistProject =true;
						sbErrorMessage.append(" NOT EXIST PROJECT OJBECT. PLEESE CHECK. \t 1");
//						throw new Exception(errorMessage);
					}
					
					String sIsPersonMql = MqlUtil.mqlCommand(context, "temp query bus Person '"+sUser+"'  * select id dump |");
					StringList stListIsPersonMqlResult = FrameworkUtil.split(sIsPersonMql, "|"); 
					if ("DCR".equalsIgnoreCase(sTypeName)) {
						/* ****************************************************************************************************************
						 * attribute_cdmDCRCDMOnlyCategoryAttribute 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )
						 * CN_EC_CODE 가 중복이면 에러 처리 
						 * project 과 연결 및 속성 추가 
						 ***************************************************************************************************************** */
						String sIsExistDCR = MqlUtil.mqlCommand(context, "temp query bus \""+cdmConstantsUtil.TYPE_CDMDCR+"\"  \""+sEC_Code+"\"  *  select id dump |");
						StringList sListIsExistDCR = FrameworkUtil.split(sIsExistDCR, "|");
						
						if(sListIsExistDCR.size() > 2){
							String errorMessage = "DCR OBJECT ... EO CODE VALUE DUPLICATION. \t 2 \t";
							throw new  Exception(errorMessage);
						}
						String sDCR_CDM_Only = "Yes";

						DomainObject domDcrObj = new DomainObject(); 
//						String strDcrObjectId = FrameworkUtil.autoName(context, "type_" + cdmConstantsUtil.TYPE_CDMDCR, "policy_" + cdmConstantsUtil.POLICY_CDM_EC_POLICY);
						domDcrObj.createObject(context, cdmConstantsUtil.TYPE_CDMDCR, sEC_Code, "-", cdmConstantsUtil.POLICY_CDM_EC_POLICY, "eService Production");
						String strDcrObjectId = domDcrObj.getId(context);
						
						if(!notExistProject){
							MqlUtil.mqlCommand(context, "connect bus '" + stProjectId + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC + "' to " + strDcrObjectId);
						}
						HashMap ecMap = new HashMap();
						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CATEGORY, sDCR_CDM_Only);
						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, "Y");
						ecMap.put("cdmECConvertComplete", "Yes");
						
//						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CODE				         , sEC_Code);
//						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CDMONLY			 	         , sDCR_CDM_Only);
//						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_PROJECT                      , sProject);
//						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_PHASE_M                      , sPhase);
//						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_EC_TYPE_M          , sEC_Type);
//						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_COMMENTS_M         , );
//						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_PEO_TYPE_M         , sPeo_Type);
//						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_TEAM_M             , sTeam);
//						ecMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_PERSON_CHANGE_M    , sPerson_Change);
//						ecMap.put(cdmConstantsUtil.ATTRIBUTE_TITLE						 , sDescription);
						
						domDcrObj.setAttributeValues(context, ecMap);
//						if(cdmStringUtil.isNotEmpty(sComments)){
//							domDcrObj.setDescription(context, sComments);
//						}
						
						/*state 정보 */
						if("New".equals(sTempState)){
							domDcrObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_IN_WORK);
						}else if("Checked In".equals(sTempState)){
							domDcrObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_IN_REVIEW);
						}else if("Released".equals(sTempState)){
							domDcrObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_RELEASED);
						}else{
							String sErrorMessage = "EXACTLY NOT DEFIENED STATE . ABOUT DCR OEJBCT . LINE NUMBER :"+recordRowNum+"\t 4";
							throw new Exception(sErrorMessage);
						}
						
						/* *****************************************************************
						 * 	migration에 받은 생성 유저정보가 person 존재하면 owner 정보 추가 
						 *  originator 정보 변경 
						 * ***************************************************************** */
						if(stListIsPersonMqlResult.size()>2){
							domDcrObj.setOwner(context, sUser);
							domDcrObj.setAttributeValue(context, "Originator", sUser);
						}
						if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2", strDcrObjectId, tempCreatedDate);
						}
						
					
						
					}else if("EAR".equals(sTypeName)){
						/* ***************************************************************************
						 * ATTRIBUTE_CDM_EAR_CDMONLY 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )	
						 * CN_EC_CODE 가 중복이면 에러 처리
						 * ***************************************************************************/
//						String sIsExistEAR = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMEAR+"'  *  *  where \" attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_EC_CODE+"] == '"+sEC_Code+"' \" select id dump |");
						String sIsExistEAR = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMEAR+"'  \""+sEC_Code+"\"  *  select id dump |");
						StringList sListIsExistEAR = FrameworkUtil.split(sIsExistEAR, "|");
						
						if(sListIsExistEAR.size() > 2){
							String errorMessage = "EAR OBJECT ... EO CODE VALUE DUPLICATION. \t 2 \t";
							throw new  Exception(errorMessage);
						}
						
						
//						String strEarObjectId = FrameworkUtil.autoName(context, "type_"+cdmConstantsUtil.TYPE_CDMEAR, "policy_"+cdmConstantsUtil.POLICY_CDM_EC_POLICY);
						DomainObject domEarObj = new DomainObject();
						domEarObj.createObject(context,  cdmConstantsUtil.TYPE_CDMEAR, sEC_Code, "-", cdmConstantsUtil.POLICY_CDM_EC_POLICY, "eService Production");
						String strEarObjectId = domEarObj.getId(context);
						if(!notExistProject){
							MqlUtil.mqlCommand(context, "connect bus '" + stProjectId + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC + "' to " + strEarObjectId);
						}
						/* ****************************************************************************
						 * 속성 정보 추가 
						 * ****************************************************************************  */
						String sEAR_CDM_Only = "Yes";
						HashMap earMap = new HashMap();
//						earMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CODE                          , sEC_Code );
//						earMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CDMONLY                       , sEAR_CDM_Only );
//						earMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_PROJECT                       ,  sProject );
//						earMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_PHASE_M			  	       ,  sPhase);                       
//						earMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_EC_TYPE_M           ,  sEC_Type);                     
//						earMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_COMMENTS_M          ,  sComments);                    
//					    earMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_PEO_TYPE_M          ,  sPeo_Type);                    
//					    earMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_TEAM_M              ,  sTeam);                        
//					    earMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_PERSON_CHANGE_M     ,  sPerson_Change);               
						earMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CATEGORY                       , sEAR_CDM_Only );
					    earMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION			 	       , "Y");
					    earMap.put("cdmECConvertComplete", "Yes");
//					    earMap.put(cdmConstantsUtil.ATTRIBUTE_TITLE						   , sDescription);
						domEarObj.setAttributeValues(context, earMap);
						
						/* *****************************************************************
						 * 	migration에 받은 생성 유저정보가 person 존재하면 owner 정보 추가 
						 *  originator 정보 변경 
						 * ***************************************************************** */
						if(stListIsPersonMqlResult.size()>2){
							domEarObj.setOwner(context, sUser);
							domEarObj.setAttributeValue(context, "Originator", sUser);
						}
						
						if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2", strEarObjectId, tempCreatedDate);
						}

						/*state 정보 */
						if("New".equals(sTempState)){
							domEarObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_IN_WORK);
						}else if("Checked In".equals(sTempState)){
							domEarObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_IN_REVIEW);
						}else if("Released".equals(sTempState)){
							
							domEarObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_RELEASED);
						}else{
							String sErrorMessage = "EXACTLY NOT DEFIENED STATE . ABOUT EAR OEJBCT . LINE NUMBER :"+recordRowNum+"\t 4";
							throw new Exception(sErrorMessage);
						}
						
						
						
						
					}else if("ECO".equals(sTypeName)){
						/* ****************************************************************************************************************
						 * ATTRIBUTE_CDM_ECO_CDMONLY 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )
						 * CN_EC_CODE 가 중복이면 에러 처리 
						 * project 과 연결 및 속성 추가 
						 ***************************************************************************************************************** */
//						String sIsExistECO = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMECO+"'  *  *  where \" attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_EC_CODE+"] == '"+sEC_Code+"' \" select id dump |");
						String sIsExistECO = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMECO+"'  \""+sEC_Code+"\"  *   select id dump |");
						StringList sListIsExistECO = FrameworkUtil.split(sIsExistECO, "|");
						
						if(sListIsExistECO.size() > 2){
							String errorMessage = "ECO OBJECT ... EO CODE VALUE DUPLICATION. \t 2 \t";
							throw new  Exception(errorMessage);
						}
						
						String sECO_CDM_Only = "Yes"; 
//						String strEcoObjectId = FrameworkUtil.autoName(context, "type_"+cdmConstantsUtil.TYPE_CDMECO, "policy_"+cdmConstantsUtil.POLICY_CDM_EC_POLICY);
						
						DomainObject domEcoObj = new DomainObject();
						domEcoObj.createObject(context,  cdmConstantsUtil.TYPE_CDMECO, sEC_Code, "-", cdmConstantsUtil.POLICY_CDM_EC_POLICY, "eService Production");
						String strEcoObjectId = domEcoObj.getId(context);
						if(!notExistProject){
							MqlUtil.mqlCommand(context, "connect bus '" + stProjectId + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC + "' to " + strEcoObjectId);
						}
						HashMap ecoMap = new HashMap();
//						ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CODE					 ,	sEC_Code);
//						ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CDMONLY				 ,  sECO_CDM_Only);
						ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CATEGORY				 ,  sECO_CDM_Only);
//						ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_PROJECT                ,	sProject);
						
//						ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_PHASE_M					  ,  sPhase);                       
//						ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_EC_TYPE_M           ,  sEC_Type);                     
//						ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_COMMENTS_M         ,  sComments);                    
//					    ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_PEO_TYPE_M          ,  sPeo_Type);                    
//					    ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_TEAM_M         	  ,  sTeam);                        
//					    ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_PERSON_CHANGE_M     ,  sPerson_Change);               
					    ecoMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION			 	  , "Y");
					    ecoMap.put("cdmECConvertComplete", "Yes");
//					    ecoMap.put(cdmConstantsUtil.ATTRIBUTE_TITLE						 , sDescription);
						domEcoObj.setAttributeValues(context, ecoMap);

						/* *****************************************************************
						 * 	migration에 받은 생성 유저정보가 person 존재하면 owner 정보 추가 
						 *  originator 정보 변경 
						 * ***************************************************************** */
						if(stListIsPersonMqlResult.size()>2){
							domEcoObj.setOwner(context, sUser);
							domEcoObj.setAttributeValue(context, "Originator", sUser);
						}
						if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2", strEcoObjectId, tempCreatedDate);
						}
						domEcoObj.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sUser);
						
						
						/*state 정보 */
						if("New".equals(sTempState)){
							domEcoObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_IN_WORK);
						}else if("Checked In".equals(sTempState)){
							domEcoObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_IN_REVIEW);
						}else if("Released".equals(sTempState)){
							
							domEcoObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_RELEASED);
						}else{
							String sErrorMessage = "EXACTLY NOT DEFIENED STATE . ABOUT ECO OEJBCT . LINE NUMBER :"+recordRowNum+"\t 4";
							throw new Exception(sErrorMessage);
						}
							
						String connectForUser = "";
						if(stListIsPersonMqlResult.size()>2){
							connectForUser = sUser;
						}else{
							connectForUser = context.getUser();
						}
						//trigger start 
						DomainRelationship.connect(context,
								   new DomainObject(PersonUtil.getPersonObjectID(context,connectForUser)),
								   DomainConstants.RELATIONSHIP_ASSIGNED_EC,
								   domEcoObj);
						//trigger end
						
						
					}else if("PEO".equals(sTypeName)){
						/* ****************************************************************************************************************
						 * ATTRIBUTE_CDM_PEO_CDMONLY 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )
						 * CN_EC_CODE 가 중복이면 에러 처리 
						 * project 과 연결 및 속성 추가 
						 ***************************************************************************************************************** */
						String sIsExistPEO = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMPEO+"'  \""+sEC_Code+"\"  *   select id dump |");
						StringList sListIsExistPEO = FrameworkUtil.split(sIsExistPEO, "|");
						
						if(sListIsExistPEO.size() > 2){
							String errorMessage = "PEO OBJECT ... EO CODE VALUE DUPLICATION. \t 2 \t";
							throw new  Exception(errorMessage);
						}
						
						String sPEO_CDM_Only = "Yes";
//						String strPeoObjectId = FrameworkUtil.autoName(context, "type_"+cdmConstantsUtil.TYPE_CDMPEO, "policy_"+cdmConstantsUtil.POLICY_CDM_EC_POLICY);
						DomainObject domPeoObj = new DomainObject();
						domPeoObj.createObject(context,  cdmConstantsUtil.TYPE_CDMPEO, sEC_Code, "-", cdmConstantsUtil.POLICY_CDM_EC_POLICY, "eService Production");
						String strPeoObjectId = domPeoObj.getId(context);
						if(!notExistProject){
							MqlUtil.mqlCommand(context, "connect bus '" + stProjectId + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC + "' to " + strPeoObjectId);
						}
						HashMap peoMap = new HashMap();
//						peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CODE   		, sEC_Code );
//						peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CDMONLY		, sPEO_CDM_Only);
						peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CATEGORY		, sPEO_CDM_Only);
//						peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_PROJECT		, sProject);

//						peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_PHASE_M					  ,  sPhase);                       
//						peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_EC_TYPE_M          ,  sEC_Type);                     
//						peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_COMMENTS_M         ,  sComments);                    
//					    peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_PEO_TYPE_M         ,  sPeo_Type);                    
//					    peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_TEAM_M         	  ,  sTeam);                        
//					    peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_ATTRIBUTE_PERSON_CHANGE_M    ,  sPerson_Change);               
					    peoMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION			 	 	  , "Y");
					    peoMap.put("cdmECConvertComplete", "Yes");
//					    peoMap.put(cdmConstantsUtil.ATTRIBUTE_TITLE						 , sDescription);
						domPeoObj.setAttributeValues(context, peoMap);
						/* *****************************************************************
						 * 	migration에 받은 생성 유저정보가 person 존재하면 owner 정보 추가 
						 *  originator 정보 변경 
						 * ***************************************************************** */
						if(stListIsPersonMqlResult.size()>2){
							domPeoObj.setOwner(context, sUser);
							domPeoObj.setAttributeValue(context, "Originator", sUser);
						}
						if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2", strPeoObjectId, tempCreatedDate);
						}
						
						/*state 정보 */
						if("New".equals(sTempState)){
							domPeoObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_IN_WORK);
						}else if("Checked In".equals(sTempState)){
							domPeoObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_IN_REVIEW);
						}else if("Released".equals(sTempState)){
							
							domPeoObj.setState(context, cdmConstantsUtil.STATE_CDM_EC_POLICY_RELEASED);
						}else{
							String sErrorMessage = "EXACTLY NOT DEFIENED STATE . ABOUT PEO OEJBCT . LINE NUMBER :"+recordRowNum +"\t 4";
							throw new Exception(sErrorMessage);
						}
						
						
					}
					MqlUtil.mqlCommand(context, "Trigger On");
					checkTriggerOff = false;
					ContextUtil.commitTransaction(context);
					successCount++;
					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString()) && !"TEO".equals(sTypeName)){
						writeSuccessToFile("SUCCESS PROCESS.  -LINE NUMBER: " + sPhysicalNumberRows+" \t recordEC_Code:\t"+recordEC_Code+" \t "+sbErrorMessage.toString());
						
					}else if(cdmStringUtil.isEmpty(sbErrorMessage.toString()) && !"TEO".equals(sTypeName)){
						writeSuccessToFile("SUCCESS PROCESS.  -LINE NUMBER: " + sPhysicalNumberRows +"\t"+recordEC_Code);
					}else if("TEO".equals(sTypeName)){
						writeMessageToConsole("LINE NUMBER: \t" + sPhysicalNumberRows+"\t TEO not Make it \t"+recordRowNum+"\t"+recordEC_Code+"\t" );
					}
					
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failCount++;
					writeMessageToConsole("LINE NUMBER: \t" + sPhysicalNumberRows+"\t"+recordRowNum+"\t"+recordEC_Code+"\t" + exception.getMessage());
					writeErrorToFile("LINE NUMBER: \t"+sPhysicalNumberRows +"\t" + exception.getMessage());
					exception.printStackTrace(errorStream);
					
					writeFailToFile(sPhysicalNumberRows+"\t"+sRecordRowNum+"\t"+sRecordTypeName +"\t"+sRecordTempState +"\t"+sRecordId+"\t"+sRecordPhase+"\t"+sRecordUser+"\t"+sRecordUSER_ID_MOD+"\t"+sRecordAPPROVAL_DATE+"\t"+sRecordProject+"\t"+sRecordProjectCust+"\t"+sRecordProduct_Type+"\t"+sRecordEC_Type+"\t"+sRecordEC_Code+"\t"+sRecordTeam+"\t"+ sRecordPerson_Change+"\t"+sRecordPeo_Type +"\t"+sRecordProjectId+"\t"+ sRecordProductGroup+"\t"+sRecordVehicle+"\t"+sRecordProjectRelId+"\t"+sRecordProductGroupRel +"\t"+sRecordVehicleRel);
					
				}finally{
					sPhysicalNumberRows = "";
					recordRowNum = "";
					recordEC_Code = "";
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "Trigger On");
						checkTriggerOff = false;
					}
				}

			}

			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        File EC Migration COMPLETED                    ...");
			writeMessageToConsole("====================================================================================\n");
		}catch(Exception exception)
		{
			writeFailToFile("LINE NUMBER: \t" + sPhysicalNumberRows+" \t EXCEPTION:  \t"+exception.getMessage());
			writeMessageToConsole("LINE NUMBER: \t" + sPhysicalNumberRows+" \t EXCEPTION:  \t"+exception.getMessage());
			writeErrorToFile("LINE NUMBER: \t" + sPhysicalNumberRows+"\t EXCEPTION:  \t"+exception.getMessage());
			exception.printStackTrace(errorStream);
		
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms");
			writeMessageToConsole("Close Time "+cdmCommonExcel.getTimeStamp2());
			writeMessageToConsole("FAIL COUNT:("+ failCount + ")   SUCCESS COUNT:("+successCount+") TOTAL COUNT :("+totalCount+")" );
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			System.out.println("[cdmECMigration_mxJPO : executeECMigration] end ."+cdmCommonExcel.getTimeStamp2());
		}
	}
	
	/**
	 * 위의 소스의 파일과 다른점은 projectId 을 (여기서 사용되는 파일은 존재하지않는다.)
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void setModifyECInfo(Context context,String args[])throws Exception{
//		
		//
		long startTime = System.currentTimeMillis();
		System.out.println("[cdmECMigration_mxJPO : setModifyECInfo] start ."+cdmCommonExcel.getTimeStamp2());
		
		String logFileName = "ModifyEC_Migration";
		Map paramMap = (HashMap)JPO.unpackArgs(args);
		String ecFilePath = (String)paramMap.get("File_Location");
//		String ecFileName = (String)paramMap.get("File");
//		if(cdmStringUtil.isEmpty(ecFilePath) || cdmStringUtil.isEmpty(ecFileName)){
//			String errorMessage = "The excel path does not exist.";
//			throw new Exception(errorMessage);
//		}
		
		if(args.length!=1){
			throw new Exception("The excel path does not exist.");
		}
		String sFileLocationAndFileName = args[0];
		
		String sFileLocation 		= "";
		String sFileName 			= "";

		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		
//		String[] argTest = {"C:\\temp\\Import_File\\EC","EC_Info_02.xls"};
		String[] argTest = {sFileLocation,sFileName};
		initializeM(context,argTest,2,logFileName);      //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("     ModifyEC DATA MIGRATION "+ getTimeStamp()+" \n");
		writeMessageToConsole("		Reading input log file from : "+inputDirectory+fileName);
		writeMessageToConsole("		Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		int lineNumber = 0;
		
		String recordRowNum     = "";
		StringList stListHeader = new StringList();
		int failCount 	= 0;
		int successCount = 0;
		int totalCount = 0;
		String sPhysicalNumberRows = "";
		try {
			String stReadData = "";
			boolean checkTriggerOff = false;
			
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, "");
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			StringBuffer sbErrorData = new StringBuffer();
			
			totalCount = physicalNumberRows-1;
			for (int i = 1; i < physicalNumberRows; i++) {
				try {
					
					XSSFRow row = sheet.getRow(i);
					lineNumber =i+1;
					sPhysicalNumberRows = String.valueOf(i);
					//comment 와 description은 다시 돌릴것 
					Cell cell_0 		 = row.getCell(0);// CLASS_NAME
					Cell cell_1 		 = row.getCell(1);// STATE
					Cell cell_2 		 = row.getCell(2);// TDM_DESCRIPTION
					Cell cell_3 		 = row.getCell(3);// CN_EC_CODE
					Cell cell_4 		 = row.getCell(4);// CN_COMMENTS
					
					String sRowNum           = String.valueOf(i-1);                                                                                                           
					String sTypeName         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_0));     // CLASS_NAME                                            
					String sTempState        = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_1 ));     // STATE
					String sDescription      = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_2 ));     // TDM_DESCRIPTION
					String sEC_Code         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_3 ));     // sEC_Code
					String sComments         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_4 ));     // CN_COMMENTS
					sbErrorData.append(sTypeName);
					sbErrorData.append("\t");
					sbErrorData.append(sTempState);
					sbErrorData.append("\t");
					sbErrorData.append(sDescription);
					sbErrorData.append("\t");
					sbErrorData.append(sEC_Code);
					sbErrorData.append("\t");
					sbErrorData.append(sComments);
					
//					recordRowNum = sRowNum;
					
					ContextUtil.startTransaction(context, true);
					MqlUtil.mqlCommand(context, "Trigger Off");
					checkTriggerOff = true;
					
					

					String sFindType = "";
					if ("DCR".equalsIgnoreCase(sTypeName)) {
						 sFindType = cdmConstantsUtil.TYPE_CDMDCR;
					}else if("EAR".equals(sTypeName)){
						sFindType = cdmConstantsUtil.TYPE_CDMEAR;
					}else if("ECO".equals(sTypeName)){
						sFindType = cdmConstantsUtil.TYPE_CDMECO;
					}else if("PEO".equals(sTypeName)){
						sFindType = cdmConstantsUtil.TYPE_CDMPEO;
					}
						
					/* ****************************************************************************************************************
					 * attribute_cdmDCRCDMOnlyCategoryAttribute 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )
					 * CN_EC_CODE 가 중복이면 에러 처리 
					 ***************************************************************************************************************** */
						String sIsExistDCR = MqlUtil.mqlCommand(context, "temp query bus \""+sFindType+"\"  \""+sEC_Code+"\"  *  select id dump |");
						StringList sListIsExistDCR = FrameworkUtil.split(sIsExistDCR, "|");
						
						if(sListIsExistDCR.size() > 2){
							String objectId = (String)sListIsExistDCR.get(3);
							DomainObject domDcrObj = new DomainObject(); 
							String strDcrObjectId = domDcrObj.getId(context);
							HashMap ecMap = new HashMap();
							ecMap.put(cdmConstantsUtil.ATTRIBUTE_TITLE						 , sDescription);
							
							domDcrObj.setAttributeValues(context, ecMap);
							if(cdmStringUtil.isNotEmpty(sComments)){
								domDcrObj.setDescription(context, sComments);
							}
							successCount++;
							writeSuccessToFile("SUCCESS.  -LINE NUMBER: " + lineNumber +"\t"+sTypeName+"\t"+sDescription+"\t"+sComments);
						}
						
					

					MqlUtil.mqlCommand(context, "Trigger On");
					checkTriggerOff = false;
					ContextUtil.commitTransaction(context);
					
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failCount++;
					writeMessageToConsole("LINE NUMBER: " + lineNumber+"\t Exception: \t" + exception.getMessage());
					writeErrorToFile("[LINE NUMBER: \t"+lineNumber +"\t ERROR: \t" + exception.getMessage());
					exception.printStackTrace(errorStream);
					writeFailToFile("LINE NUMBER: \t" + lineNumber+ "\t" + sbErrorData.toString()+"\t EXCEPTION: "+exception.getMessage());
					
				}finally{
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "Trigger On");
						checkTriggerOff = false;
					}
				}

			}

			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        File EC Migration COMPLETED                    ...");
			writeMessageToConsole("====================================================================================\n");
		}catch(Exception exception)
		{
			writeFailToFile("LINE NUMBER:" + lineNumber+" \t EXCEPTION: "+exception.getMessage());
			writeMessageToConsole("LINE NUMBER:" + lineNumber+"\t EXCEPTION: "+exception.getMessage());
			writeErrorToFile("LINE NUMBER:" + lineNumber+"\t EXCEPTION: "+exception.getMessage());
			exception.printStackTrace(errorStream);
		
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms");
			writeMessageToConsole("FAIL COUNT:("+ failCount + ")   SUCCESS COUNT:("+successCount+") TOTAL COUNT :("+totalCount+")" );
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			System.out.println("[cdmECMigration_mxJPO : executeECMigration] end ."+cdmCommonExcel.getTimeStamp2());
		}
	
		//
	}
//	private boolean connectMajorAndMinorObjects(Context context, String minorRevString, boolean parameBoolean, String stObjectId, String stVersionId) {
//		// TODO Auto-generated method stub
//		boolean result = false;
//		String relVersionOf = cdmConstantsUtil.RELATIONSHIP_VERSION_OF;
//		String relActiveVersion = cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION;
//		String relLatestVersion = cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION;
//		String relcadComponent = cdmConstantsUtil.RELATIONSHIP_CAD_SUBCOMPONENT;
//		try {
//			AttributeList localAttributeList = new AttributeList();
//			String str4 = MCADMxUtil.getActualNameForAEFData(context, "attribute_MoveFilesToVersion");
//			String str5 = MCADMxUtil.getActualNameForAEFData(context, "attribute_Title");
//			String str6 = MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
//			String str7 = MCADMxUtil.getActualNameForAEFData(context, "attribute_IEF-FileMessageDigest");
//			
//			localAttributeList.addElement(new Attribute(new AttributeType(str4), "False"));   
//			localAttributeList.addElement(new Attribute(new AttributeType(str6), "True"));    
//			localAttributeList.addElement(new Attribute(new AttributeType(str7), ""));        
//			
//			StringBuffer localStringBufferVersion = new StringBuffer();
//			localStringBufferVersion.append("connect bus \"");
//			localStringBufferVersion.append(stObjectId);
//			localStringBufferVersion.append("\" relationship \"");
//			localStringBufferVersion.append(cdmConstantsUtil.RELATIONSHIP_VERSION_OF);
//			localStringBufferVersion.append("\" preserve to \"");
//			localStringBufferVersion.append(stVersionId);
//			localStringBufferVersion.append("\" ");
//			
//			StringBuffer localStringBufferActive = new StringBuffer();
//			localStringBufferActive.append("connect bus \"");
//			localStringBufferActive.append(stObjectId);
//			localStringBufferActive.append("\" relationship \"");
//			localStringBufferActive.append(cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION);
//			localStringBufferActive.append("\" preserve to \"");
//			localStringBufferActive.append(stVersionId);
//			localStringBufferActive.append("\" ");
//			
//			StringBuffer localStringBufferLatest = new StringBuffer();
//			localStringBufferLatest.append("connect bus \"");
//			localStringBufferLatest.append(stObjectId);
//			localStringBufferLatest.append("\" relationship \"");
//			localStringBufferLatest.append(cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION);
//			localStringBufferLatest.append("\" preserve to \"");
//			localStringBufferLatest.append(stVersionId);
//			localStringBufferLatest.append("\" ");
//			
//		
//			
//			result = true;
//		} catch (Exception e) {
//			e.printStackTrace();
//			result = false;
//		}finally{
//			return result;
//			
//		}
//	}

	/**
	 * null 발생시 "" 로 체크  
	 * @param data
	 * @return
	 */
	public String isVaildNullData(String data){
		return ((data == null || "null".equals(data)) ? "" : data.trim());
	}
	
	
    private boolean isValidData(String data) {
		return ((data == null || "null".equals(data)) ? 0 : data.trim().length()) > 0;
	}
    
	private void closeLogStream() throws IOException
	{
		try 
		{
			if(null != logWriter)
				logWriter.close();

			if(null != errorStream)
				errorStream.close();

			if(null != successObjectidWriter)
				successObjectidWriter.close();

			if(null != failedObjectidWriter)
				failedObjectidWriter.close();
		} 
		catch (IOException e) 
		{
			System.out.println("Exception while closing log stream "+e.getMessage());
		}
	}
	
	private void writeErrorToFile(String message)throws Exception{
		errorStream.write(message.getBytes("UTF-8"));
		errorStream.write("\n".getBytes("UTF-8"));
	}
	
	private void writeMessageToConsole(String message) throws Exception
	{
		writeMessageToLogFile(message);
	}

	private void writeMessageToLogFile(String message) throws Exception
	{
		logWriter.write( message + "\n");
		logWriter.flush();
	}
	
	private String getTimeStamp(){
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date)+"T"+ new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}
	
	public void writeFailToFile(String message) throws Exception{
		failedObjectidWriter.write( message + "\n");
		failedObjectidWriter.flush();
	}
	public void writeSuccessToFile(String message)throws Exception{
		successObjectidWriter.write(message + "\n");
		successObjectidWriter.flush();
	}
	
	/**
	 * @param context
	 * @param args
	 * @param requestAgsNum
	 * @param logFileName
	 */
	public void initializeM(Context context,String args[],int requestAgsNum , String logFileName)throws Exception{

//		consoleWriter 		= new BufferedWriter(new MatrixWriter(context));
		sequenceInt			= 1;

		if (args.length != requestAgsNum )
		{
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}


		inputDirectory = args[0];

		// documentDirectory does not ends with "/" add it
		if(inputDirectory != null && !inputDirectory.endsWith(S_FILESEPARATOR))
		{
			inputDirectory = inputDirectory + S_FILESEPARATOR;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + S_FILESEPARATOR + S_OUTPUT_DIRECTORY + S_FILESEPARATOR + logFileName  +"_"+   S_FILESEPARATOR;
        File fileOutputDirectory = new File(outputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        	
        }
		// input file name
		fileName = args[1];
        logFileName+=fileName+"_"+getTimeStamp();
		logWriter 			 	= new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(outputDirectory + logFileName + "_SuccessObjectids.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(outputDirectory + logFileName + "_FailedObjectids" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		

		
	
	}
	
	/**
	 * 0102 에러 발생 
	 * @param context
	 * @param arg
	 * @throws Exception
	 */
	public void connectEC (Context context,String args[])throws Exception{

		long startTime = System.currentTimeMillis();
		System.out.println("[cdmECMigration_mxJPO : executeECMigration] start ."+cdmCommonExcel.getTimeStamp2() +"second");
		
		
		String logFileName = "ECConnectMigration";
		if(args.length!=1){
			throw new Exception("The excel path does not exist.");
		}
		String sFileLocationAndFileName = args[0];
		
		String sFileLocation 		= "";
		String sFileName 			= "";

		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		
		String[] argTest = {sFileLocation,sFileName};
		//context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		initializeM(context,argTest,2,logFileName);    
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("     EC DATA MIGRATION "+ getTimeStamp()+" \n");
		writeMessageToConsole("		Reading input log file from : "+inputDirectory+fileName);
		writeMessageToConsole("		Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		int lineNumber = 0;
		String recordEC_Code = "";
		String recordRowNum     = "";
		StringList stListHeader = new StringList();
		int failCount 	= 0;
		int successCount = 0;
		int totalCount = 0;
		
		String sRecordRowNum         = "";
		String sRecordTypeName       = "";
		String sRecordTempState      = "";
		String sRecordId       		 = "";
		String sRecordPhase          = "";
		String sRecordUser			 = "";
		String sRecordUSER_ID_MOD    = "";
		String sRecordAPPROVAL_DATE  = "";
		String sRecordProject		 = "";
		String sRecordProjectCust	 = "";
		String sRecordProduct_Type   = "";
		String sRecordEC_Type    	 = "";
		String sRecordEC_Code        = "";
		String sRecordTeam        	 = "";
		String sRecordPerson_Change  = "";
		String sRecordPeo_Type  	 = "";
		String sRecordProjectId      = "";
		String sRecordProductGroup   = "";
		String sRecordVehicle        = "";
		String sRecordProjectRelId   = "";
		String sRecordProductGroupRel  = "";
		String sRecordVehicleRel       = "";
		
		String sPhysicalNumberRows = "";
		try {
			String stReadData = "";
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, "");
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			StringBuffer sbErrorMessage = new StringBuffer("");
			boolean checkTriggerOff = false;
			totalCount = physicalNumberRows-3;
			for (int i = 3; i < physicalNumberRows; i++) {
				try {
					XSSFRow row = sheet.getRow(i);
					sPhysicalNumberRows = String.valueOf(i+1);
					//comment 와 description은 다시 돌릴것 
					Cell cell_0 		 = row.getCell(0);// CLASS_NAME
					Cell cell_1 		 = row.getCell(1);// STATE
					Cell cell_2 		 = row.getCell(2);// CN_ID
					Cell cell_3 		 = row.getCell(3);// PHASE
					Cell cell_4 		 = row.getCell(4);// USER_OBJECT_ID
					Cell cell_5 		 = row.getCell(5);// USER_ID_MOD
					Cell cell_6 		 = row.getCell(6);// APPROVAL_DATE
					Cell cell_7 	     = row.getCell(7); //CN_PROJECT
					Cell cell_8          = row.getCell(8); //CN_PROJECT_CUST
					Cell cell_9          = row.getCell(9); //CN_PRODUCT_TYPE
					Cell cell_10         = row.getCell(10);//CN_EC_TYPE
					Cell cell_11         = row.getCell(11);//CN_EC_CODE
					Cell cell_12         = row.getCell(12);//CN_TEAM
					Cell cell_13         = row.getCell(13);//CN_PERSON_IN_CHARGE
					Cell cell_14         = row.getCell(14);//CN_PEO_TYPE
					Cell cell_15         = row.getCell(15);//CN_PROJECT_ID
					Cell cell_16         = row.getCell(16);//PROD_GROUP
					Cell cell_17         = row.getCell(17);//CN_CUST_VEHICLE
					Cell cell_18         = row.getCell(18);//CN_PROJECT_REL_ID
					Cell cell_19         = row.getCell(19);//PROD_GROUP_REL
					Cell cell_20         = row.getCell(20);//CN_CUST_VEHICLE_REL

					String sRowNum           = String.valueOf(i+1);                                                      //                                                      
					String sTypeName         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_0));     // CLASS_NAME                                            
					String sTempState        = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_1 ));     // STATE                                                
					String sId       		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_2 ));    // CN_ID				,migration 대상자 아님                  
					String sPhase            = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_3 ));    // PHASE                                                 
					String sUser			 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_4 ));    // USER_OBJECT_ID                                        
					String sUSER_ID_MOD    = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_5 ));    // USER_ID_MOD   		,migration 대상자 아님                  
					String sAPPROVAL_DATE  = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_6 ));    // APPROVAL_DATE      ,migration 대상자 아님                  
					String sProject			 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_7));     // CN_PROJECT                                                                            
					String sProjectCust		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_8));     // CN_PROJECT_CUST                                   
					String sProduct_Type     = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_9));     // CN_PRODUCT_TYPE                                   
					String sEC_Type    		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_10));    // CN_EC_TYPE                                        
					String sEC_Code          = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_11));    // CN_EC_CODE                                        
					String sTeam        	 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_12));    // CN_TEAM                                           
					String sPerson_Change    = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_13));    // CN_PERSON_IN_CHARGE , PLM 에서 생성한 EC 사용자 user 정보   
					String sPeo_Type  		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_14));    // CN_PEO_TYPE   
					String sProjectId        = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_15));    // ProjectId                                           
					String sProductGroup     = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_16));    // PROD_GROUP                                           
					String sVehicle         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_17));     // CN_CUST_VEHICLE                                           
					//sProjectId,sProductGroup,sVehicle 정보가 없으면 아래의 3개 정보를 검색하여 사용한다. 이 데이타는 추후 추합또는 변경될수 있는 정보(다시 마이그레이션 진행할시 테스트 필요 ) 12/27
					String sProjectRelId      = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_18));     //CN_PROJECT_REL_ID                                       
					String sProductGroupRel   = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_19));     //PROD_GROUP_REL                                            
					String sVehicleRel         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_20));    //CN_CUST_VEHICLE_REL                                       

					sRecordRowNum         = sRowNum           ;
					sRecordTypeName       = sTypeName         ;
					sRecordTempState      = sTempState        ;
					sRecordId       	  = sId       		 ;
					sRecordPhase          = sPhase            ;
					sRecordUser			  = sUser			 ;
					sRecordUSER_ID_MOD    = sUSER_ID_MOD    ;
					sRecordAPPROVAL_DATE  = sAPPROVAL_DATE  ;
					sRecordProject		  = sProject			;
					sRecordProjectCust	  = sProjectCust		;
					sRecordProduct_Type   = sProduct_Type   ;
					sRecordEC_Type    	  = sEC_Type    		;
					sRecordEC_Code        = sEC_Code        ;
					sRecordTeam        	  = sTeam        	 ;
					sRecordPerson_Change  = sPerson_Change    ;
					sRecordPeo_Type  	  = sPeo_Type  		;
					sRecordProjectId      = sProjectId        ;
					sRecordProductGroup   = sProductGroup     ;
					sRecordVehicle        = sVehicle          ;
					sRecordProjectRelId    = sProjectRelId          ;
					sRecordProductGroupRel = sProductGroupRel          ;
					sRecordVehicleRel      = sVehicleRel          ;
					
					String sStatePolicy = "";
				
					recordRowNum = sRowNum;
					recordEC_Code = sEC_Code;
					
					ContextUtil.startTransaction(context, true);
					if(UIUtil.isNullOrEmpty(sProjectId) && UIUtil.isNullOrEmpty(sProductGroup) && (" - ".equals(sVehicle) || UIUtil.isNullOrEmpty(sVehicle)) && UIUtil.isNullOrEmpty(sProjectRelId) && UIUtil.isNullOrEmpty(sProductGroupRel) && (UIUtil.isNullOrEmpty(sVehicleRel) || " - ".equals(sVehicleRel) )){
						failCount++;
						writeErrorToFile("LINE NUMBER: \t"+sPhysicalNumberRows +"\t" + "not projectId And Security Info not Exist. \t 5");
					}
					
					MqlUtil.mqlCommand(context, "Trigger Off");
					checkTriggerOff = true;
					
					boolean checkOwner = false;
					boolean checkOrg = false;
					boolean checkProject = false;
					boolean bOrgAndProjectExist = false;
					
					boolean checkRelOrg = false;
					boolean checkRelProject = false;
					boolean bOrgAndProjectRelExist = false;
					String sOwner = "";
					String findOrg = "list role $1 select $2 dump;";
					if (cdmStringUtil.isNotEmpty(sVehicle) && cdmStringUtil.isNotEmpty(sProductGroup)) {
						String str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sVehicle, "isanorg" });
						if ("TRUE".equalsIgnoreCase(str2)) {
							findOrg = "list role $1 select $2 dump;";
							str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sProductGroup, "isaproject" });
							if ("TRUE".equalsIgnoreCase(str2)) {
								checkOrg = true;
								checkProject = true;
								bOrgAndProjectExist = true;
							}
						}
					}
					
		
					String findRelOrg = "list role $1 select $2 dump;";
					if (cdmStringUtil.isNotEmpty(sVehicleRel) && cdmStringUtil.isNotEmpty(sProductGroupRel)) {
						String str2 = MqlUtil.mqlCommand(context, findRelOrg, true, new String[] { sVehicleRel, "isanorg" });
						if ("TRUE".equalsIgnoreCase(str2)) {
							findRelOrg = "list role $1 select $2 dump;";
							str2 = MqlUtil.mqlCommand(context, findRelOrg, true, new String[] { sProductGroupRel, "isaproject" });
							if ("TRUE".equalsIgnoreCase(str2)) {
								checkRelOrg = true;
								checkRelProject = true;
								bOrgAndProjectRelExist = true;
							}
						}
					}
					
					
					
					boolean notExistProject    = false;
					boolean checkProjectRelExist = false;
					String sProjectCommonCode                = cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE;
//					String sProjectGroupCustomerAttribute	 = cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_CUSTOMER_ATTRIBUTE;
//					String sProjectGroupProductTypeAttribute = cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE;
//					String sProejctMql = MqlUtil.mqlCommand(context, " temp query bus cdmProjectGroupObject * * where \" attribute["+sProjectCommonCode+"] =='"+sProject +"' &&  attribute["+sProjectGroupCustomerAttribute+"] =='" + sProjectCust + "' && attribute["+sProjectGroupProductTypeAttribute+"] == '" + sProduct_Type + "' \" select id dump |");
//					String sProejctMql = MqlUtil.mqlCommand(context, " temp query bus cdmProjectGroupObject * * where \" attribute["+sProjectCommonCode+"] =='"+sProject +"' &&  from[cdmProjectGroupRelationshipCustomer].to.attribute[cdmCommonCode] == '" + sProjectCust + "' && from[cdmProjectGroupRelationshipProductType].to.attribute[cdmCommonCodeNameEn] == '" + sProduct_Type + "' \" select id dump |");
					String sProejctMql = "";
					if(UIUtil.isNotNullAndNotEmpty(sProjectId)){
						sProejctMql = MqlUtil.mqlCommand(context, " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectObjectIdM] == '"+sProjectId+"' \" select id dump |");
					}else if(UIUtil.isNotNullAndNotEmpty(sProjectRelId)){
						sProejctMql = MqlUtil.mqlCommand(context, " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectObjectIdM] == '"+sProjectRelId+"' \" select id dump |");
						checkProjectRelExist = true;
					}
					StringList stListProjectMqlResult = FrameworkUtil.split(sProejctMql, "|");
					String stProjectId = "";
					if(stListProjectMqlResult.size()>2){
						stProjectId = (String)stListProjectMqlResult.get(3);
					}else{
						notExistProject =true;
						sbErrorMessage.append(" NOT EXIST PROJECT OJBECT. PLEESE CHECK. \t 1");
//						throw new Exception(errorMessage);
					}
					
					String sIsPersonMql = MqlUtil.mqlCommand(context, "temp query bus Person '"+sUser+"'  * select id dump |");
					StringList stListIsPersonMqlResult = FrameworkUtil.split(sIsPersonMql, "|"); 
					if ("DCR".equalsIgnoreCase(sTypeName)) {
						/* ****************************************************************************************************************
						 * attribute_cdmDCRCDMOnlyCategoryAttribute 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )
						 * CN_EC_CODE 가 중복이면 에러 처리 
						 * project 과 연결 및 속성 추가 
						 ***************************************************************************************************************** */
						String sIsExistDCR = MqlUtil.mqlCommand(context, "temp query bus \""+cdmConstantsUtil.TYPE_CDMDCR+"\"  \""+sEC_Code+"\"  *  select id dump |");
						StringList sListIsExistDCR = FrameworkUtil.split(sIsExistDCR, "|");
						if(sListIsExistDCR.size() > 2){
							String existDCRId = (String)sListIsExistDCR.get(3);
						
							if(!notExistProject){
								MqlUtil.mqlCommand(context, "connect bus '" + stProjectId + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC + "' to " + existDCRId);
							}
						}
						
						
					}else if("EAR".equals(sTypeName)){
						/* ***************************************************************************
						 * ATTRIBUTE_CDM_EAR_CDMONLY 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )	
						 * CN_EC_CODE 가 중복이면 에러 처리
						 * ***************************************************************************/
//						String sIsExistEAR = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMEAR+"'  *  *  where \" attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_EC_CODE+"] == '"+sEC_Code+"' \" select id dump |");
						String sIsExistEAR = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMEAR+"'  \""+sEC_Code+"\"  *  select id dump |");
						StringList sListIsExistEAR = FrameworkUtil.split(sIsExistEAR, "|");
						
						if(sListIsExistEAR.size() > 2){
							String existEARId = (String)sListIsExistEAR.get(3);
							if(!notExistProject){
								MqlUtil.mqlCommand(context, "connect bus '" + stProjectId + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC + "' to " + existEARId);
							}
							
						}
						
						
						
					}else if("ECO".equals(sTypeName)){
						/* ****************************************************************************************************************
						 * ATTRIBUTE_CDM_ECO_CDMONLY 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )
						 * CN_EC_CODE 가 중복이면 에러 처리 
						 * project 과 연결 및 속성 추가 
						 ***************************************************************************************************************** */
//						String sIsExistECO = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMECO+"'  *  *  where \" attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_EC_CODE+"] == '"+sEC_Code+"' \" select id dump |");
						String sIsExistECO = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMECO+"'  \""+sEC_Code+"\"  *   select id dump |");
						StringList sListIsExistECO = FrameworkUtil.split(sIsExistECO, "|");
						
						if(sListIsExistECO.size() > 2){
							String existECOId = (String)sListIsExistECO.get(3);
							if(!notExistProject){
								MqlUtil.mqlCommand(context, "connect bus '" + stProjectId + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC + "' to " + existECOId);
							}
						}
						
					
					}else if("PEO".equals(sTypeName)){
						/* ****************************************************************************************************************
						 * ATTRIBUTE_CDM_PEO_CDMONLY 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )
						 * CN_EC_CODE 가 중복이면 에러 처리 
						 * project 과 연결 및 속성 추가 
						 ***************************************************************************************************************** */
						String sIsExistPEO = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMPEO+"'  \""+sEC_Code+"\"  *   select id dump |");
						StringList sListIsExistPEO = FrameworkUtil.split(sIsExistPEO, "|");
						
						if(sListIsExistPEO.size() > 2){
							String existPEOId = (String)sListIsExistPEO.get(3);
							if(!notExistProject){
								MqlUtil.mqlCommand(context, "connect bus '" + stProjectId + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC + "' to " + existPEOId);
							}
							
						}else{
							
						}
					}
					MqlUtil.mqlCommand(context, "Trigger On");
					checkTriggerOff = false;
					ContextUtil.commitTransaction(context);
					successCount++;
					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
						writeSuccessToFile("SUCCESS PROCESS.  -LINE NUMBER: " + sPhysicalNumberRows+" \t recordEC_Code:"+recordEC_Code+" \t "+sbErrorMessage.toString());
						
					}else{
						
						writeMessageToConsole("SUCCESS PROCESS.  -LINE NUMBER: " + sPhysicalNumberRows);
					}
					writeMessageToConsole("SUCCESS PROCESS.  -LINE NUMBER: " + sPhysicalNumberRows);
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failCount++;
					writeMessageToConsole("LINE NUMBER: \t" + sPhysicalNumberRows+"\t" + exception.getMessage());
					writeErrorToFile("LINE NUMBER: \t"+sPhysicalNumberRows +"\t" + exception.getMessage());
					exception.printStackTrace(errorStream);
					writeFailToFile(sPhysicalNumberRows+"\t"+sRecordRowNum+"\t"+sRecordTypeName +"\t"+sRecordTempState +"\t"+sRecordId+"\t"+sRecordPhase+"\t"+sRecordUser+"\t"+sRecordUSER_ID_MOD+"\t"+sRecordAPPROVAL_DATE+"\t"+sRecordProject+"\t"+sRecordProjectCust+"\t"+sRecordProduct_Type+"\t"+sRecordEC_Type+"\t"+sRecordEC_Code+"\t"+sRecordTeam+"\t"+ sRecordPerson_Change+"\t"+sRecordPeo_Type +"\t"+sRecordProjectId+"\t"+ sRecordProductGroup+"\t"+sRecordVehicle+"\t"+sRecordProjectRelId+"\t"+sRecordProductGroupRel +"\t"+sRecordVehicleRel);
					
				}finally{
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "Trigger On");
						checkTriggerOff = false;
					}
				}

			}

			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        File EC Migration COMPLETED                    ...");
			writeMessageToConsole("====================================================================================\n");
		}catch(Exception exception)
		{
			writeFailToFile("LINE NUMBER: \t" + sPhysicalNumberRows+" \t EXCEPTION:  \t"+exception.getMessage());
			writeMessageToConsole("LINE NUMBER: \t" + sPhysicalNumberRows+" \t EXCEPTION:  \t"+exception.getMessage());
			writeErrorToFile("LINE NUMBER: \t" + sPhysicalNumberRows+"\t EXCEPTION:  \t"+exception.getMessage());
			exception.printStackTrace(errorStream);
		
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms");
			writeMessageToConsole("FAIL COUNT:("+ failCount + ")   SUCCESS COUNT:("+successCount+") TOTAL COUNT :("+totalCount+")" );
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			System.out.println("[cdmECMigration_mxJPO : executeECMigration] end ."+cdmCommonExcel.getTimeStamp2());
		}
	
	}
	
	/**
	 * 0105 originated 추가 이부분은 메인 migration에 이미 추가 됨 
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void originatedDateAdd(Context context,String[] args)throws Exception{

		long startTime = System.currentTimeMillis();
		System.out.println("[cdmECMigration_mxJPO : originatedDateAdd] start ."+cdmCommonExcel.getTimeStamp2() +"second");
		
		
		String logFileName = "EC_M_add";
		
//		HashMap argHm = new HashMap<>();
//		argHm = JPO.unpackArgs(args);
//		String sFileLocationAndFileName = (String)argHm.get("fileData");
		
		if(args.length!=1){
			throw new Exception("The excel path does not exist.");
		}
		String sFileLocationAndFileName = args[0];
		
		String sFileLocation 		= "";
		String sFileName 			= "";

		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		logFileName +="_"+sFileName.substring(0, sFileName.lastIndexOf("."));
		
//		String[] argTest = {"C:\\temp\\Import_File\\EC","20161010_EC_Info_01.txt"};
		String[] argTest = {sFileLocation,sFileName};
		//context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		initializeM(context,argTest,2,logFileName);    
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("     EC DATA MIGRATION "+ getTimeStamp()+" \n");
		writeMessageToConsole("		Reading input log file from : "+inputDirectory+fileName);
		writeMessageToConsole("		Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		int lineNumber = 0;
		String recordEC_Code = "";
		String recordRowNum     = "";
		StringList stListHeader = new StringList();
		int failCount 	= 0;
		int successCount = 0;
		int totalCount = 0;
		
		String sRecordRowNum         = "";
		String sRecordTypeName       = "";
		String sRecordTempState      = "";
		String sRecordId       		 = "";
		String sRecordPhase          = "";
		String sRecordUser			 = "";
		String sRecordUSER_ID_MOD    = "";
		String sRecordAPPROVAL_DATE  = "";
		String sRecordProject		 = "";
		String sRecordProjectCust	 = "";
		String sRecordProduct_Type   = "";
		String sRecordEC_Type    	 = "";
		String sRecordEC_Code        = "";
		String sRecordTeam        	 = "";
		String sRecordPerson_Change  = "";
		String sRecordPeo_Type  	 = "";
		String sRecordProjectId      = "";
		String sRecordProductGroup   = "";
		String sRecordVehicle        = "";
		String sRecordProjectRelId   = "";
		String sRecordProductGroupRel  = "";
		String sRecordVehicleRel       = "";
		
		String sPhysicalNumberRows = "";
		try {
			String stReadData = "";
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, "");
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			StringBuffer sbErrorMessage = new StringBuffer("");
			boolean checkTriggerOff = false;
			totalCount = physicalNumberRows-3;
			for (int i = 3; i < physicalNumberRows; i++) {
				try {
					XSSFRow row = sheet.getRow(i);
					sPhysicalNumberRows = String.valueOf(i+1);
					if (row == null){
						String errorMessage= "THERE IS NO INFORMATION IN THE EXCEL SHEET.";
						throw new Exception(errorMessage);
					}
				
					//comment 와 description은 다시 돌릴것 
					Cell cell_0 		 = row.getCell(0);// CLASS_NAME
					Cell cell_1 		 = row.getCell(1);// STATE
					Cell cell_2 		 = row.getCell(2);// CN_ID
					Cell cell_3 		 = row.getCell(3);// PHASE
					Cell cell_4 		 = row.getCell(4);// USER_OBJECT_ID
					Cell cell_5 		 = row.getCell(5);// USER_ID_MOD
					Cell cell_6 		 = row.getCell(6);// APPROVAL_DATE
					Cell cell_7 	     = row.getCell(7); //CN_PROJECT
					Cell cell_8          = row.getCell(8); //CN_PROJECT_CUST
					Cell cell_9          = row.getCell(9); //CN_PRODUCT_TYPE
					Cell cell_10         = row.getCell(10);//CN_EC_TYPE
					Cell cell_11         = row.getCell(11);//CN_EC_CODE
					Cell cell_12         = row.getCell(12);//CN_TEAM
					Cell cell_13         = row.getCell(13);//CN_PERSON_IN_CHARGE
					Cell cell_14         = row.getCell(14);//CN_PEO_TYPE
					Cell cell_15         = row.getCell(15);//CN_PROJECT_ID
					Cell cell_16         = row.getCell(16);//PROD_GROUP
					Cell cell_17         = row.getCell(17);//CN_CUST_VEHICLE
					Cell cell_18         = row.getCell(18);//CN_PROJECT_REL_ID
					Cell cell_19         = row.getCell(19);//PROD_GROUP_REL
					Cell cell_20         = row.getCell(20);//CN_CUST_VEHICLE_REL
					Cell cell_21         = row.getCell(21);//CREATION_DATE

					String sRowNum           = String.valueOf(i+1);                                                      //                                                      
					String sTypeName         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_0));     // CLASS_NAME                                            
					String sTempState        = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_1 ));     // STATE                                                
					String sId       		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_2 ));    // CN_ID				,migration 대상자 아님                  
					String sPhase            = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_3 ));    // PHASE                                                 
					String sUser			 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_4 ));    // USER_OBJECT_ID                                        
					String sUSER_ID_MOD    = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_5 ));    // USER_ID_MOD   		,migration 대상자 아님                  
					String sAPPROVAL_DATE  = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_6 ));    // APPROVAL_DATE      ,migration 대상자 아님                  
					String sProject			 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_7));     // CN_PROJECT                                                                            
					String sProjectCust		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_8));     // CN_PROJECT_CUST                                   
					String sProduct_Type     = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_9));     // CN_PRODUCT_TYPE                                   
					String sEC_Type    		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_10));    // CN_EC_TYPE                                        
					String sEC_Code          = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_11));    // CN_EC_CODE                                        
					String sTeam        	 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_12));    // CN_TEAM                                           
					String sPerson_Change    = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_13));    // CN_PERSON_IN_CHARGE , PLM 에서 생성한 EC 사용자 user 정보   
					String sPeo_Type  		 = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_14));    // CN_PEO_TYPE   
					String sProjectId        = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_15));    // ProjectId                                           
					String sProductGroup     = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_16));    // PROD_GROUP                                           
					String sVehicle         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_17));     // CN_CUST_VEHICLE                                           
					//sProjectId,sProductGroup,sVehicle 정보가 없으면 아래의 3개 정보를 검색하여 사용한다. 이 데이타는 추후 추합또는 변경될수 있는 정보(다시 마이그레이션 진행할시 테스트 필요 ) 12/27
					String sProjectRelId      = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_18));     //CN_PROJECT_REL_ID                                       
					String sProductGroupRel   = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_19));     //PROD_GROUP_REL                                            
					String sVehicleRel         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_20));    //CN_CUST_VEHICLE_REL                                       
					String sCreateDate         = cdmCommonExcel.isVaildNullData(cdmCommonExcel.getCellValue2(cell_21));    //CREATION_DATE                                       

					sRecordRowNum         = sRowNum           ;
					sRecordTypeName       = sTypeName         ;
					sRecordTempState      = sTempState        ;
					sRecordId       	  = sId       		 ;
					sRecordPhase          = sPhase            ;
					sRecordUser			  = sUser			 ;
					sRecordUSER_ID_MOD    = sUSER_ID_MOD    ;
					sRecordAPPROVAL_DATE  = sAPPROVAL_DATE  ;
					sRecordProject		  = sProject			;
					sRecordProjectCust	  = sProjectCust		;
					sRecordProduct_Type   = sProduct_Type   ;
					sRecordEC_Type    	  = sEC_Type    		;
					sRecordEC_Code        = sEC_Code        ;
					sRecordTeam        	  = sTeam        	 ;
					sRecordPerson_Change  = sPerson_Change    ;
					sRecordPeo_Type  	  = sPeo_Type  		;
					sRecordProjectId      = sProjectId        ;
					sRecordProductGroup   = sProductGroup     ;
					sRecordVehicle        = sVehicle          ;
					sRecordProjectRelId    = sProjectRelId          ;
					sRecordProductGroupRel = sProductGroupRel          ;
					sRecordVehicleRel      = sVehicleRel          ;
					
					String sStatePolicy = "";
				
					recordRowNum = sRowNum;
					recordEC_Code = sEC_Code;
					
					ContextUtil.startTransaction(context, true);
					if(UIUtil.isNullOrEmpty(sProjectId) && UIUtil.isNullOrEmpty(sProductGroup) && (" - ".equals(sVehicle) || UIUtil.isNullOrEmpty(sVehicle)) && UIUtil.isNullOrEmpty(sProjectRelId) && UIUtil.isNullOrEmpty(sProductGroupRel) && (UIUtil.isNullOrEmpty(sVehicleRel) || " - ".equals(sVehicleRel) )){
						failCount++;
						writeErrorToFile("LINE NUMBER: \t"+sPhysicalNumberRows +"\t" + "not projectId And Security Info not Exist. \t 5");
					}
					
					MqlUtil.mqlCommand(context, "Trigger Off");
					checkTriggerOff = true;
					
					String tempCreatedDate = "";
					if(UIUtil.isNotNullAndNotEmpty(sCreateDate)){
						Date createdate = new Date(sCreateDate);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa", new Locale("en", "US"));
						tempCreatedDate = sdf.format(createdate); 
					}
					
		
					if ("DCR".equalsIgnoreCase(sTypeName)) {
						/* ****************************************************************************************************************
						 * attribute_cdmDCRCDMOnlyCategoryAttribute 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )
						 * CN_EC_CODE 가 중복이면 에러 처리 
						 * project 과 연결 및 속성 추가 
						 ***************************************************************************************************************** */
						String sIsExistDCR = MqlUtil.mqlCommand(context, "temp query bus \""+cdmConstantsUtil.TYPE_CDMDCR+"\"  \""+sEC_Code+"\"  *  where \"attribute[cdmCheckMigration]=='Y'\" select id dump |");
						StringList sListIsExistDCR = FrameworkUtil.split(sIsExistDCR, "|");
						
						if(sListIsExistDCR.size() > 2){
							if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
								String strDcrObjectId = (String)sListIsExistDCR.get(3);
								MqlUtil.mqlCommand(context, "mod bus $1 originated $2", strDcrObjectId, tempCreatedDate);
							}
						}else{
							String errorMessage = "not DCR exist. \t 2";
							throw new  Exception(errorMessage);
							
						}
						
					}else if("EAR".equals(sTypeName)){
						/* ***************************************************************************
						 * ATTRIBUTE_CDM_EAR_CDMONLY 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )	
						 * CN_EC_CODE 가 중복이면 에러 처리
						 * ***************************************************************************/
//						String sIsExistEAR = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMEAR+"'  *  *  where \" attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_EC_CODE+"] == '"+sEC_Code+"' \" select id dump |");
						String sIsExistEAR = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMEAR+"'  \""+sEC_Code+"\"  *  select id dump |");
						StringList sListIsExistEAR = FrameworkUtil.split(sIsExistEAR, "|");
						
						if(sListIsExistEAR.size() > 2){
							if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
								String stECId = (String)sListIsExistEAR.get(3);
								MqlUtil.mqlCommand(context, "mod bus $1 originated $2", stECId, tempCreatedDate);
							}
						}else{
							String errorMessage = "EAR OBJECT ... Exist. \t 2";
							throw new  Exception(errorMessage);
						}
//						
						
					}else if("ECO".equals(sTypeName)){
						/* ****************************************************************************************************************
						 * ATTRIBUTE_CDM_ECO_CDMONLY 의 데이타는 무조건 Yes로 입력 (추후 변경 사항 있을 수 있음 )
						 * CN_EC_CODE 가 중복이면 에러 처리 
						 * project 과 연결 및 속성 추가 
						 ***************************************************************************************************************** */
						String sIsExistECO = MqlUtil.mqlCommand(context, "temp query bus '"+cdmConstantsUtil.TYPE_CDMECO+"'  \""+sEC_Code+"\"  *   select id dump |");
						StringList sListIsExistECO = FrameworkUtil.split(sIsExistECO, "|");
						
						if(sListIsExistECO.size() > 2){
							if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
								String stECId = (String)sListIsExistECO.get(3);
								MqlUtil.mqlCommand(context, "mod bus $1 originated $2", stECId, tempCreatedDate);
							}
						}else{
							String errorMessage = "ECO OBJECT ... Exist. \t 2";
							throw new  Exception(errorMessage);
						}
						
						
					} else if ("PEO".equals(sTypeName)) {
						/*
						 * *****************************************************
						 * *****************************************************
						 * ****** ATTRIBUTE_CDM_PEO_CDMONLY 의 데이타는 무조건 Yes로 입력
						 * (추후 변경 사항 있을 수 있음 ) CN_EC_CODE 가 중복이면 에러 처리 project 과
						 * 연결 및 속성 추가
						 */
						String sIsExistPEO = MqlUtil.mqlCommand(context, "temp query bus '" + cdmConstantsUtil.TYPE_CDMPEO + "'  \"" + sEC_Code + "\"  *   select id dump |");
						StringList sListIsExistPEO = FrameworkUtil.split(sIsExistPEO, "|");

						if (sListIsExistPEO.size() > 2) {
							String stECId = (String)sListIsExistPEO.get(3);
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2", stECId, tempCreatedDate);
						} else {
							String errorMessage = "PEO OBJECT ... EXIST. \t 2";
							throw new Exception(errorMessage);
						}

					}
					MqlUtil.mqlCommand(context, "Trigger On");
					checkTriggerOff = false;
					ContextUtil.commitTransaction(context);
					successCount++;
					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
						writeSuccessToFile("SUCCESS PROCESS.  -LINE NUMBER: " + sPhysicalNumberRows+" \t recordEC_Code:"+recordEC_Code+" \t "+sbErrorMessage.toString());
						
					}else{
						
						writeMessageToConsole("SUCCESS PROCESS.  -LINE NUMBER: " + sPhysicalNumberRows);
					}
					
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failCount++;
					writeMessageToConsole("LINE NUMBER: \t" + sPhysicalNumberRows+"\t" + exception.getMessage());
					writeErrorToFile("LINE NUMBER: \t"+sPhysicalNumberRows +"\t" + exception.getMessage());
					exception.printStackTrace(errorStream);
					writeFailToFile(sPhysicalNumberRows+"\t"+sRecordRowNum+"\t"+sRecordTypeName +"\t"+sRecordTempState +"\t"+sRecordId+"\t"+sRecordPhase+"\t"+sRecordUser+"\t"+sRecordUSER_ID_MOD+"\t"+sRecordAPPROVAL_DATE+"\t"+sRecordProject+"\t"+sRecordProjectCust+"\t"+sRecordProduct_Type+"\t"+sRecordEC_Type+"\t"+sRecordEC_Code+"\t"+sRecordTeam+"\t"+ sRecordPerson_Change+"\t"+sRecordPeo_Type +"\t"+sRecordProjectId+"\t"+ sRecordProductGroup+"\t"+sRecordVehicle+"\t"+sRecordProjectRelId+"\t"+sRecordProductGroupRel +"\t"+sRecordVehicleRel);
					
				}finally{
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "Trigger On");
						checkTriggerOff = false;
					}
				}

			}

			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        File EC Migration COMPLETED                    ...");
			writeMessageToConsole("====================================================================================\n");
		}catch(Exception exception)
		{
			writeFailToFile("LINE NUMBER: \t" + sPhysicalNumberRows+" \t EXCEPTION:  \t"+exception.getMessage());
			writeMessageToConsole("LINE NUMBER: \t" + sPhysicalNumberRows+" \t EXCEPTION:  \t"+exception.getMessage());
			writeErrorToFile("LINE NUMBER: \t" + sPhysicalNumberRows+"\t EXCEPTION:  \t"+exception.getMessage());
			exception.printStackTrace(errorStream);
		
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms");
			writeMessageToConsole("FAIL COUNT:("+ failCount + ")   SUCCESS COUNT:("+successCount+") TOTAL COUNT :("+totalCount+")" );
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			System.out.println("[cdmECMigration_mxJPO : originatedDateAdd] end ."+cdmCommonExcel.getTimeStamp2());
		}
	
	}
		
}


