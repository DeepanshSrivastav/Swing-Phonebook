import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.mando.util.cdmConstantsUtil;
import com.matrixone.apps.common.SubscriptionManager;
import com.matrixone.apps.common.Workspace;
import com.matrixone.apps.common.WorkspaceVault;
import com.matrixone.apps.domain.DomainAccess;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralConstants;
import com.matrixone.apps.team.TeamUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.SelectList;
import matrix.util.StringList;
import com.mando.util.cdmCommonExcel;
import com.mando.util.cdmStringUtil;;


/**
 * Project 을 위한 migration
 */
public class cdmProjectGroupMigration_mxJPO {
	
	public static final String FILE_SEPARATOR			 	= "//";
	public static final String DUMP_DEFAULT			 	 	= "|";
	
//	public static final String S_COMMONCODE_EXCEL_PATH 		= "C:\\temp\\Import_File\\COMMONCODE";
//	public static final String S_COMMONCODE_EXCEL_PATH_NAME = "20161109_LIBv02 .xlsx";
	public static final String S_SUBPROJECT_GROUP_TYPE 		 = "cdmSubProjectGroup";
	public static final String S_PROJECT_GROUP_OBJECT_TYPE	 = "cdmProjectGroupObject";

	public static final String QUERY_WILDCARD 			     = "*";
	public static final String S_PROJECT_TOP_OBJECT_NAME 	 = "Project Tree";
	public static final String OUTPUT_DIRECTORY              = "MIGRATION_LOGS";
	public static final String S_PROJECT_SHEET_NAME 	     = "Project";
	public static final String S_ATTRIBUTE_CDMCOMMONCODE     = "cdmCommonCode"; 
	
	
	/**
	 * TDM_DESCRIPTION,CN_CODE,PRODUCT_TYPE,PROD_DIV  Unique four data processing
	 * TDM_DESCRIPTION : description 
	 * CN_CODE : attribute[cdmProjectCode]
	 * PRODUCT_TYPE : attribute[cdmProjectGroupProductTypeAttribute]
	 * PROD_DIV: attribute[cdmProjectGroupProductNameAttribute]
	 * CN_ACTIVATE : -1 case  promote
	 * 
	 * Levels 1 to 4, no data is generated if there is no level information between levels 2, 3, and 4  
	 * @param context
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes", "resource" })
	public void addProjectGroupAndProject(Context context, String[] args) throws Exception {
		
		System.out.println("cdmCommonCodeMigration : addProjectGroupAndProject --> start." +cdmCommonExcel.getTimeStamp2() );
		long startTime = System.currentTimeMillis();
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		if(args.length != 1){
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		String tempFileAndLocation = args[0];
		String commonCodeFilePath = "";
		String commonCodeFileName = "";
		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
		
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명
//		String[] sTempArgs = {S_COMMONCODE_EXCEL_PATH,S_COMMONCODE_EXCEL_PATH_NAME};
		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
		if (sTempArgs.length!=2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory  = sTempArgs[0];
		fileName		= sTempArgs[1];
		//로그 default 명 
		String logFileName 	= "createProject";

		//읽을 메인 시트명
		String sheetName 	= S_PROJECT_SHEET_NAME;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + FILE_SEPARATOR;
		}
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + FILE_SEPARATOR + OUTPUT_DIRECTORY + FILE_SEPARATOR + logFileName + "_" + cdmCommonExcel.getTimeStamp() + FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"     PROJECT MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		int successObjectCount     = 0;
		int failObjectCount 	   = 0;
		String sPhysicalNumberRows = "";
		int totalObjectCont        = 0;
		try{
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalObjectCont = physicalNumberRows-2;
			
			// project find start 
			String   sWhere 		 = "";
			String   sSelect		 = "id";
			
			//type,name,revision,where,select,dump
			String   stProjectTreeId = "";
			stProjectTreeId = (String)getOnlySearchBus(context,S_SUBPROJECT_GROUP_TYPE, S_PROJECT_TOP_OBJECT_NAME, QUERY_WILDCARD,sWhere,sSelect,DUMP_DEFAULT);
			//project find end 
			 
//			String prefixGroupProject = "";
			
			if(cdmStringUtil.isEmpty(stProjectTreeId)){
				DomainObject dProjectTree = new DomainObject();
				
				dProjectTree.createObject(context, S_SUBPROJECT_GROUP_TYPE, S_PROJECT_TOP_OBJECT_NAME, "-", "cdmProjectGroupPolicy", cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
				stProjectTreeId = (String)dProjectTree.getId(context);
			}
			
			HashMap<String,String> tempCommonCodeHm = new HashMap<String,String>();
			HashMap<String,String> commonCodeHm = new HashMap<String,String>();
			tempCommonCodeHm.put("commonCodeVehicleIdLev2"      , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Vehicle' \"" );
			tempCommonCodeHm.put("commonCodeProductGroupIdLev2" , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Product Group Name'\" " );
			tempCommonCodeHm.put("commonCodeProductDivIdLev2"   , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Product Div'  \"" );
			tempCommonCodeHm.put("commonCodeCustomerIdLev2"   , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Customer'  \"" );
			
			for (Iterator iterator = tempCommonCodeHm.keySet().iterator(); iterator.hasNext();) {
				
				String stCommonCodeKey = (String) iterator.next();
				String stCommonCodeValue= (String)tempCommonCodeHm.get(stCommonCodeKey);
				String stCommonCodeMql = MqlUtil.mqlCommand(context, "temp query bus cdmCommonCode * * where "+stCommonCodeValue+" select id dump | ");
				
				StringList commonCodeMqlResult = FrameworkUtil.split(stCommonCodeMql, "|");
				String stLev2CommonCode = "";
				
				if(commonCodeMqlResult.size() >2 ){
					stLev2CommonCode = (String)commonCodeMqlResult.get(3);
					commonCodeHm.put(stCommonCodeKey, stLev2CommonCode);
				}else{
					String errorMessage = "NOT EXIST COMMONCODE OBJECT.";
					throw new Exception(errorMessage);
				}
			}
			String tempLev2CommonCodeVehicleId     	 = (String)commonCodeHm.get("commonCodeVehicleIdLev2");
			String tempLev2CommonCodeProductGroupId  = (String)commonCodeHm.get("commonCodeProductGroupIdLev2");
			String tempLev2CommonCodeProductTypeId 	 = (String)commonCodeHm.get("commonCodeProductDivIdLev2");
			String tempLev2CommonCodeCustomerId      = (String)commonCodeHm.get("commonCodeCustomerIdLev2");
			
			/*데이타는 ROW 3줄 부터 시작*/
			for (int i = 2; i < physicalNumberRows; i++) {
				StringBuffer sbErrorData = new StringBuffer(""); 
				try{
					XSSFRow row = sheet.getRow(i);
					sPhysicalNumberRows = String.valueOf(i+1);
					
					if (row == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL) \t 1";
						throw new Exception(errorMessage);
					}
					
					
					XSSFCell cell_0 = row.getCell(0);// 순번
					XSSFCell cell_1 = row.getCell(1);// TDMX_ID
					XSSFCell cell_2 = row.getCell(2);// TDM_DESCRIPTION
					XSSFCell cell_4 = row.getCell(4);// PROD_Type
					XSSFCell cell_5 = row.getCell(5);// PROD_Name
					XSSFCell cell_6 = row.getCell(6);// TDMX_CUSTOMER
					XSSFCell cell_7 = row.getCell(7);// CN_VEHICLE
					
					if (cell_5 != null && cell_2 != null && cell_7 != null && cell_6 != null && cell_4 != null) {
						String stNumber                 = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_0));
						String stProject_Id             = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_1));
						String stLev4 				    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_2));
						String stProductType 		    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_4));
						String stProductNameAndLev2     = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_5));
						String stCustomerAndLev3 	    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_6));
						String stVehicle 			    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_7));
						
						
						int number = Integer.parseInt(stNumber);
						
						if(cdmStringUtil.isEmpty(stLev4)){
							sbErrorData.append("NOT EXIST DATA. (CELL_2 EMPTY): " );
							sbErrorData.append(stLev4);
							sbErrorData.append("\t");
//							String errorMessage = "NOT EXIST DATA. (CELL_2 EMPTY)";
//							throw new Exception(errorMessage);
						}
						if(cdmStringUtil.isEmpty(stProductType)){
							sbErrorData.append("NOT EXIST DATA. (CELL_4 EMPTY): ");
							sbErrorData.append(stProductType);
							sbErrorData.append("\t");
//							String errorMessage = "NOT EXIST DATA. (CELL_4 EMPTY)";
//							throw new Exception(errorMessage);
						}
						if(cdmStringUtil.isEmpty(stProductNameAndLev2)){
							sbErrorData.append("NOT EXIST DATA. (CELL_5 EMPTY): ");
							sbErrorData.append(stProductNameAndLev2);
							sbErrorData.append("\t");
//							String errorMessage = "NOT EXIST DATA. (CELL_5 EMPTY)";
//							throw new Exception(errorMessage);
						}
						if(cdmStringUtil.isEmpty(stCustomerAndLev3)){
							sbErrorData.append("NOT EXIST DATA. (CELL_6 EMPTY)");
							sbErrorData.append(stCustomerAndLev3);
							sbErrorData.append("\t");
//							String errorMessage = "NOT EXIST DATA. (CELL_6 EMPTY)";
//							throw new Exception(errorMessage);
						}
						
						String sProductNameObjectId = "";
						String sProductTypeObjectId = "";
						String sCustomerObjectId 	= "";
						String sVehicleObjectId 	= "";

						// Product Group
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeProductGroupId)) {
							String productGroupIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stProductNameAndLev2 + "' && attribute[cdmCommonTemp2]=='" + stProductType + "' \" dump |";
							sProductNameObjectId = expandCommonCodeMql(context, tempLev2CommonCodeProductGroupId, productGroupIddWhere, "S");
	
						}
	
						/* Product Type */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeProductTypeId) ) {
							String productDivIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stProductType + "' \" dump |";
							sProductTypeObjectId = expandCommonCodeMql(context, tempLev2CommonCodeProductTypeId, productDivIddWhere, "S");
	
						}
						
						/* CUSTOMER */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeCustomerId) ) {
							String productCustomerIdWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCode] == '" + stCustomerAndLev3 + "' \" dump |";
							sCustomerObjectId = expandCommonCodeMql(context, tempLev2CommonCodeCustomerId, productCustomerIdWhere, "S");
						}
						
						/* VEHICLE */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeVehicleId) ) {
							String productVehicleIdWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCode]=='" + stVehicle + "' && to[cdmCommonCodeRelationship].from.attribute[cdmCommonCode]=='"+stCustomerAndLev3+ "' \" dump |";
							sVehicleObjectId = expandCommonCodeMql(context, tempLev2CommonCodeVehicleId, productVehicleIdWhere, "S");
						}

						
						if(cdmStringUtil.isEmpty(sVehicleObjectId)) {
							sbErrorData.append("NOT EXIST COMMOMCODE(Vehicle) :");
							sbErrorData.append("Vehicle -Attribute[CommonCode] :");
							sbErrorData.append(stVehicle);
							sbErrorData.append(" | Vehicle -to[].from.Attribute[CommonCode] :");
							sbErrorData.append(stCustomerAndLev3);
							sbErrorData.append("\t");
//							String sErrorMessage = "NOT EXIST COMMOMCODE(Vehicle)";
//							throw new Exception(sErrorMessage);
						}
						
						if(cdmStringUtil.isEmpty(sCustomerObjectId)) {
							
							sbErrorData.append("NOT EXIST COMMOMCODE(Customer) :");
							sbErrorData.append("Customer -Attribute[CommonCode] :");
							sbErrorData.append(stCustomerAndLev3);
							sbErrorData.append("\t");
							
//							String sErrorMessage = "NOT EXIST COMMOMCODE(Customer)";
//							throw new Exception(sErrorMessage);
						}
						
						if(cdmStringUtil.isEmpty(sProductTypeObjectId)) {
							
							sbErrorData.append("NOT EXIST COMMOMCODE(Product Type) :");
							sbErrorData.append("Product Type -Attribute[cdmCommonCodeNameEn] :");
							sbErrorData.append(stProductType);
							sbErrorData.append("\t");
							
//							String sErrorMessage = "NOT EXIST COMMOMCODE(Product Type)";
//							throw new Exception(sErrorMessage);
						}
						
						if(cdmStringUtil.isEmpty(sProductNameObjectId)) {
							
							sbErrorData.append("NOT EXIST COMMOMCODE(Product Name) :");
							sbErrorData.append("Product Name -Attribute[cdmCommonCodeNameEn] :");
							sbErrorData.append(stProductNameAndLev2);
							sbErrorData.append(" | attribute[cdmCommonTemp2] :");
							sbErrorData.append(stProductType);
							sbErrorData.append("\t");
//							String sErrorMessage = "NOT EXIST COMMOMCODE(Product Name)";
//							throw new Exception(sErrorMessage);
						}
						
						
						String projectGroupWhere = "attribute[cdmProjectCode] == '" + stProductNameAndLev2 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + stProjectTreeId + "' ";
//						String existLev2 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP, "", "", "", "", projectGroupWhere, selectList);
						
						String existLev2 = "";
						existLev2 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupWhere, "id", DUMP_DEFAULT);
						
						if(existLev2 ==null){
							String errorMessage = "NOT EXIST PROEJCT GROUP LEV2 OBJECT.";
							throw new Exception(errorMessage);
						}
						
//						ContextUtil.startTransaction(context, true);
						if (cdmStringUtil.isEmpty(existLev2)) {
							
							
							Map requestArg = new HashMap();
							requestArg.put("objectId", stProjectTreeId);
							requestArg.put("Title", stProductNameAndLev2);
							requestArg.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
							requestArg.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
		
//							Map createLev2Map = (Map) JPO.invoke(context, "cdmProjectGroup", null, "createProjectGroup", JPO.packArgs(requestArg), Map.class);
							Map createLev2Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArg), Map.class);
							String createLev2Id = (String) createLev2Map.get("id");
							if(cdmStringUtil.isEmpty(createLev2Id)){
								String errorMessage = "NOT CREATE LEVEL2 OBJECT.";
								throw new Exception(errorMessage);
							}
		
							String projectGroupLev3Where = "attribute[cdmProjectCode] == '" + stCustomerAndLev3 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev2Id + "' ";
//							String existLev3 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP, "", "", "", "", projectGroupLev3Where, selectList);
							String existLev3 = "";
							existLev3 		 = getOnlySearchBus(context,S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev3Where, "id", DUMP_DEFAULT);
							
							if(existLev3 == null){
								String errorMessage = "NOT EXIST PROEJCT GROUP LEV3 OBJECT.";
								throw new Exception(errorMessage);
							}
							
							if (cdmStringUtil.isEmpty(existLev3)) {
								// lev 3 not exist
								Map requestArgLev3 = new HashMap();
								requestArgLev3.put("objectId", createLev2Id);
								requestArgLev3.put("Title", stCustomerAndLev3);
								requestArgLev3.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
								requestArgLev3.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
								
//								
								Map createLev3Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArgLev3), Map.class);
								String createLev3Id = (String) createLev3Map.get("id");
								if(cdmStringUtil.isEmpty(createLev3Id)){
									String errorMessage = "NOT CREATE LEVEL3 OBJECT.";
									throw new Exception(errorMessage);
								}	
								
//								String projectGroupObjectWhere = "attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE + "] == '" + stProductType + "'  && attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_VEHICLE_ATTRIBUTE + "] == '" + stVehicle + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev3Id + "' ";
//								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev3Id + "' ";
								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev3Id + "' ";
//								String existLev4 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, "", "", "", "", projectGroupObjectWhere, selectList);
								String existLev4 = "";
								existLev4 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
								if(existLev4 == null){
									String errorMessage = "NOT EXIST PROEJCTGROUP OBJECT OBJECT.";
									throw new Exception(errorMessage);
								}
								
								if (cdmStringUtil.isEmpty(existLev4)) {
									if (cdmStringUtil.isNotEmpty(stLev4)) {
										Map requestArgLev4 = new HashMap();
										requestArgLev4.put("objectId", createLev3Id);
										requestArgLev4.put("Name", stLev4);
										requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
										requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
										
//										requestArgLev4.put("Customer", stCustomerAndLev3);
//										requestArgLev4.put("ProductType", stProductType);
//										requestArgLev4.put("ProductName", stProductNameAndLev2);
//										requestArgLev4.put("Vehicle", stVehicle);
										requestArgLev4.put("ProductNameObjectId", sProductNameObjectId);
										requestArgLev4.put("ProductTypeObjectId", sProductTypeObjectId);
										requestArgLev4.put("CustomerObjectId", sCustomerObjectId);
										requestArgLev4.put("VehicleObjectId", sVehicleObjectId);
										requestArgLev4.put("ProjectLeafId", stProject_Id);
										
										requestArgLev4.put("sCustomer",stCustomerAndLev3 );
		
//										Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "cdmProjectGroupCreate", JPO.packArgs(requestArgLev4), Map.class);
										Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
										String createLev4Id = "";
										createLev4Id = (String) createLev4Map.get("id");
										if(cdmStringUtil.isEmpty(createLev4Id)){
											String sErrorMessage = "NOT CREATE PROJECT LEV4.";
											throw new Exception(sErrorMessage);
										}
		
									}
								}
							} else {
									
//									String projectGroupObjectWhere = "attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE + "] == '" + stProductType + "'  && attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_VEHICLE_ATTRIBUTE + "] == '" + stVehicle + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
									String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
//									String existLev4 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, "", "", "", "", projectGroupObjectWhere, selectList);
									String existLev4 = "";
									existLev4 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
									
									if(existLev4 == null){
										String errorMessage = "NOT EXIST PROEJCTGROUPOBJECT OBJECT.";
										throw new Exception(errorMessage);
									}
									if (cdmStringUtil.isEmpty(existLev4)) {
										if (cdmStringUtil.isNotEmpty(stLev4)) {
											Map requestArgLev4 = new HashMap();
											requestArgLev4.put("objectId", existLev3);
											requestArgLev4.put("Name", stLev4);
											requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
											requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
		
//											requestArgLev4.put("Customer", stCustomerAndLev3);
//											requestArgLev4.put("ProductType", stProductType);
//											requestArgLev4.put("ProductName", stProductNameAndLev2);
//											requestArgLev4.put("Vehicle", stVehicle);
											requestArgLev4.put("ProductNameObjectId", sProductNameObjectId);
											requestArgLev4.put("ProductTypeObjectId", sProductTypeObjectId);
											requestArgLev4.put("CustomerObjectId", sCustomerObjectId);
											requestArgLev4.put("VehicleObjectId", sVehicleObjectId);
											requestArgLev4.put("ProjectLeafId",stProject_Id );
		
											requestArgLev4.put("sCustomer",stCustomerAndLev3 );
//											Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "cdmProjectGroupCreate", JPO.packArgs(requestArgLev4), Map.class);
											Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
											String createLev4Id = (String) createLev4Map.get("id");
		
										}
									}
								}
						} else { // lev 2 exist
							String projectGroupLev3Where = "attribute[cdmProjectCode] == '" + stCustomerAndLev3 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev2 + "'";
//							String existLev3 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP, "", "", "", "", projectGroupLev3Where, selectList);
							String existLev3 = "";
							existLev3 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev3Where, "id", DUMP_DEFAULT);
						
							if(existLev3 == null){
								String errorMessage = "NOT EXIST PROEJCTGROUP OBJECT.";
								throw new Exception(errorMessage);
							}
							if (cdmStringUtil.isEmpty(existLev3)) {
								// lev 3 not exist
								if (cdmStringUtil.isNotEmpty(stCustomerAndLev3)) {
									Map requestArgLev3 = new HashMap();
									requestArgLev3.put("objectId", existLev2);
									requestArgLev3.put("Title", stCustomerAndLev3);
									requestArgLev3.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
									requestArgLev3.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
		
									Map createLev3Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArgLev3), Map.class);
									String createLev3Id = (String) createLev3Map.get("id");
									if(cdmStringUtil.isEmpty(createLev3Id)){
										String errorMessage = "NOT CREATE LEVEL3 OBJECT.";
										throw new Exception(errorMessage);
									}
//									String projectGroupObjectWhere = "attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE + "] == '" + stProductType + "' && attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_VEHICLE_ATTRIBUTE + "] == '" + stVehicle + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev3Id + "'";
									String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" +
											sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" +
											sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+
//											sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" +  createLev3Id+ "' ";
											sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" +  createLev3Id+ "' ";
									
//									String existLev4 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, "", "", "", "", projectGroupObjectWhere, selectList);
									String existLev4 = "";
									existLev4 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
									
									if(existLev4 == null){
										String errorMessage = "NOT EXIST PROEJCTGROUPOBJECT OBJECT.";
										throw new Exception(errorMessage);
									}
									
									if (cdmStringUtil.isEmpty(existLev4)) {
										if (cdmStringUtil.isNotEmpty(stLev4)) {
											Map requestArgLev4 = new HashMap();
											requestArgLev4.put("objectId", createLev3Id);
											requestArgLev4.put("Name", stLev4);
											requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
											requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
		
//											requestArgLev4.put("Customer", stCustomerAndLev3);
//											requestArgLev4.put("ProductType", stProductType);
//											requestArgLev4.put("ProductName", stProductNameAndLev2);
//											requestArgLev4.put("Vehicle", stVehicle);
											requestArgLev4.put("ProductNameObjectId", sProductNameObjectId);
											requestArgLev4.put("ProductTypeObjectId", sProductTypeObjectId);
											requestArgLev4.put("CustomerObjectId", sCustomerObjectId);
											requestArgLev4.put("VehicleObjectId", sVehicleObjectId);
											requestArgLev4.put("ProjectLeafId",stProject_Id );
		
											requestArgLev4.put("sCustomer",stCustomerAndLev3 );
											Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
//											Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroup", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
											String createLev4Id = (String) createLev4Map.get("id");
											if(cdmStringUtil.isEmpty(createLev4Id)){
												String sErrorMessage = (String) createLev4Map.get("errorMessage");
												
												String errorMessage = "NOT CREATE LEV4 PROJECT. " + sErrorMessage;
												throw new Exception(errorMessage);
											}
										}
									}
								}
							} else {
								// lev3 exist
//								String projectGroupObjectWhere = "attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE + "] == '" + stProductType + "' && attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_VEHICLE_ATTRIBUTE + "] == '" + stVehicle + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
//								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDMCOMMONCODENAMEKO + "] == '" + stProductType + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE + "] == '" + stVehicle + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE + "] == '" +stProductNameAndLev2 +"' && from[cdmProjectGroupRelationshipCustomer].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE + "] == '" + stCustomerAndLev3 + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
//								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
//								String existLev4 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, "", "", "", "", projectGroupObjectWhere, selectList);
								String existLev4 = "";
								existLev4 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
								
								if(existLev4 == null){
									String errorMessage = "NOT EXIST PROEJCT OBJECT OBJECT.";
									throw new Exception(errorMessage);
								}
								
								if (cdmStringUtil.isEmpty(existLev4)) {
									Map requestArgLev4 = new HashMap();
									requestArgLev4.put("objectId", existLev3);
									requestArgLev4.put("Name", stLev4);
									requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
									requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
		
//									requestArgLev4.put("Customer", stCustomerAndLev3);
//									requestArgLev4.put("ProductType", stProductType);
//									requestArgLev4.put("ProductName", stProductNameAndLev2);
//									requestArgLev4.put("Vehicle", stVehicle);
									requestArgLev4.put("ProductNameObjectId", sProductNameObjectId);
									requestArgLev4.put("ProductTypeObjectId", sProductTypeObjectId);
									requestArgLev4.put("CustomerObjectId", sCustomerObjectId);
									requestArgLev4.put("VehicleObjectId", sVehicleObjectId);
									requestArgLev4.put("ProjectLeafId", stProject_Id);
									
									requestArgLev4.put("sCustomer",stCustomerAndLev3 );
									
		
									Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
//									Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroup", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
									String createLev4Id = (String) createLev4Map.get("id");
									if(cdmStringUtil.isEmpty( createLev4Id)){
										String sErrorMessage = (String) createLev4Map.get("errorMessage");
										String errorMessage = "NOT CREATE LEV4 PROJECT. " + sErrorMessage;
										throw new Exception(errorMessage);
									}
								}else{
									String errorMessage = "Not Create Lev4 Project. Already exist.";
									throw new Exception(errorMessage);
								}
							}
		
						}
						
						successObjectCount ++;
						if(cdmStringUtil.isNotEmpty(sbErrorData.toString())){
							
							multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. LINE NUMBER: \t " + sPhysicalNumberRows +"\t  CreateProjectLev4: \t "+stLev4 +"\t  CreateProjectLev3:"+stCustomerAndLev3+" \t  CreateProjectLev2: \t "+stProductNameAndLev2 +" \t  "+sbErrorData.toString());
						}
						multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. LINE NUMBER: \t " + sPhysicalNumberRows +" \t  CreateProjectLev4: \t "+stLev4 +"\t CreateProjectLev3:"+stCustomerAndLev3+" \t  CreateProjectLev2: \t "+stProductNameAndLev2 +" | ");
						
					}else{
						String errorMessage = "NOT EXIST NECESSARY DATA";
						throw new Exception(errorMessage);
					}
//					ContextUtil.commitTransaction(context);
				}catch(Exception e1){
					failObjectCount++;
//					ContextUtil.abortTransaction(context);
					multiWriteMessageToFile(failedObjectidWriter, "LINE NUMBER: \t" + sPhysicalNumberRows+"\t EXCEPTION: \t" + e1.getMessage() );
					mulitWriteErrorToFile(errorStream, "LINE NUMBER: \t" + sPhysicalNumberRows + " \t EXCEPTION: \t" + e1.getMessage());
					e1.printStackTrace(errorStream);
				}
			}
			
			
		}catch(Exception e2){
//			multiWriteMessageToFile(logWriter, "LINE NUMBER: " + sPhysicalNumberRows+" | EXCEPTION : " + e2.getMessage() );
			mulitWriteErrorToFile(errorStream, "LINE NUMBER: " + sPhysicalNumberRows + " \t EXCEPTION:" + e2.getMessage());
			e2.printStackTrace(errorStream);
		
		}finally{
			multiWriteMessageToFile(logWriter, "==================================================================================== ");
			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, " Total Count:("+totalObjectCont +")   FAIL COUNT : ("+failObjectCount+")    SUCCESS COUNT : ("+successObjectCount+")    LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms             ");
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

			System.out.println("cdmCommonCodeMigration : addProjectGroupAndProject --> end." +cdmCommonExcel.getTimeStamp2() );
		}
	}
	
	@SuppressWarnings("finally")
	public Map createProject(Context context,String args[])throws Exception{
//		 result = "";
		boolean checkTriggerOff = false;

		checkTriggerOff = true;
		Map resultMap = new HashMap();		
		final HttpSession HttpServletRequest = null;
		
		Map returnMap = new HashMap();
		HashMap paramMap = (HashMap) JPO.unpackArgs(args);
		String strParentOID = (String) paramMap.get("objectId");
		String strName = (String) paramMap.get("Name");
		String strType = (String) paramMap.get(cdmConstantsUtil.TEXT_TYPEACTUAL);
		String strPolicy = (String) paramMap.get(cdmConstantsUtil.TEXT_POLICY);
		String strProductNameId = (String) paramMap.get("ProductNameObjectId");
		String strProductTypeId = (String) paramMap.get("ProductTypeObjectId");
		String strCustomerId = (String) paramMap.get("CustomerObjectId");
		String strVehicleId = (String) paramMap.get("VehicleObjectId");
		String strProjectID = (String)paramMap.get("ProjectLeafId");
		
		String sCustomer = (String)paramMap.get("sCustomer");
		
		try {

			ContextUtil.startTransaction(context, true);
			DomainObject domObj = new DomainObject();
			String sProjectDiv = "";
			String sArrayTempVehicle = "";
			String sOrg = "";
			String[] sArrayName = strName.split("-");
			if(sArrayName.length == 2){
			 sProjectDiv = ((String)sArrayName[0].trim());
			 sArrayTempVehicle = ((String)sArrayName[1].trim());
			 sOrg = sCustomer +" - "+sArrayTempVehicle;
			}
			String strProjectObjectId = FrameworkUtil.autoName(context, "type_cdmProjectGroupObject", "policy_cdmProjectGroupPolicy");
			domObj.setId(strProjectObjectId);
			MqlUtil.mqlCommand(context, "connect bus '" + strParentOID + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_OBJECT_TYPE_RELATIONSHIP + "' to " + strProjectObjectId);
			
			returnMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE, strName);
			returnMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, "Y");
			returnMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_OBJECT_ID_M ,strProjectID);
			
			domObj.setAttributeValues(context, returnMap);
			domObj.promote(context);
			// Workspace Exist Check
			ContextUtil.pushContext(context, null, null, null);
//			boolean isWorkspaceExists = (boolean) Workspace.isWorkspaceExists(context, FrameworkUtil.getVaultNames(context, false, true).toString(), strName);
			ContextUtil.popContext(context);

//			if (!isWorkspaceExists) {
				Workspace WorkspaceObj = (Workspace) DomainObject.newInstance(context, DomainConstants.TYPE_WORKSPACE, DomainConstants.TEAM);
				String strWorkspaceObjectId = "";
				// Workspace Create
				strWorkspaceObjectId = TeamUtil.autoRevision(context, HttpServletRequest, WorkspaceObj.TYPE_PROJECT, strName, WorkspaceObj.POLICY_PROJECT, context.getVault().getName());
				WorkspaceObj.setId(strProjectObjectId);//project
				WorkspaceObj.setDescription(context, strName);
				
				DomainObject workSpaceDObj = new DomainObject(); // workspace
				workSpaceDObj.setId(strWorkspaceObjectId);
				boolean checkOwner = false;
				boolean checkOrg = false;
				boolean checkProject = false;
				String sOwner = "";
				String findOrg = "list role $1 select $2 dump;";
				if (cdmStringUtil.isNotEmpty(sOrg) && cdmStringUtil.isNotEmpty(sProjectDiv)) {
					String str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sOrg, "isanorg" });
					if ("TRUE".equalsIgnoreCase(str2)) {
						findOrg = "list role $1 select $2 dump;";
						str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sProjectDiv, "isaproject" });
						if ("TRUE".equalsIgnoreCase(str2)) {
							checkOrg = true;
							checkProject = true;
						}
					}
				}
				WorkspaceObj.setOwnership(context, checkOwner, checkOrg, checkProject, sOwner, sOrg, sProjectDiv);
				workSpaceDObj.setOwnership(context, checkOwner, checkOrg, checkProject, sOwner, sOrg, sProjectDiv);
				WorkspaceObj.update(context);
				workSpaceDObj.update(context);
//
//				// Workspace - Project Connection
//				DomainAccess.createObjectOwnership(context, strProjectObjectId, com.matrixone.apps.domain.util.PersonUtil.getPersonObjectID(context), "Full", DomainAccess.COMMENT_MULTIPLE_OWNERSHIP);
				DomainRelationship.connect(context, new DomainObject(strProjectObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_WORKSPACE, new DomainObject(strWorkspaceObjectId));
//			}

			if (!strProductNameId.equals("")) {
				MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME + " to " + strProductNameId);
			}
			if (!strProductTypeId.equals("")) {
				MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE + " to " + strProductTypeId);
			}
			if (!strCustomerId.equals("")) {
				MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER + " to " + strCustomerId);
			}
			if (!strVehicleId.equals("")) {
				StringList slVehicleList = FrameworkUtil.split(strVehicleId, ",");
				for (int i = 0; i < slVehicleList.size(); i++) {
					String strVehicleObjectId = (String) slVehicleList.get(i);
					if (!"".equals(strVehicleObjectId)) {
						MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE + " to " + strVehicleObjectId);
					}
				}
			}
			ContextUtil.commitTransaction(context);
//			result = strProjectObjectId;
			resultMap.put("id", strProjectObjectId);
		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			e.printStackTrace();
			String errorMessage = e.getMessage();
			resultMap.put("id", "");
			resultMap.put("errorMessage", errorMessage);
		}
	
		finally{
			if(checkTriggerOff){
//				MqlUtil.mqlCommand(context, "Trigger On");
//				MqlUtil.mqlCommand(context, "history on");
			}
			return resultMap;
		}
		
	}
	
	@SuppressWarnings("finally")
	public Map createProjectGroup(Context context,String args[])throws Exception{
		
		boolean bTriggeroff = false;
//		MqlUtil.mqlCommand(context, "Trigger Off");
		MqlUtil.mqlCommand(context, "history off");
		Map returnMap = new HashMap();
		try {
			
			ContextUtil.startTransaction(context, true);
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String strParentOID = (String) paramMap.get("objectId");
			String strCode = (String) paramMap.get("Title");
			String strType = (String) paramMap.get(cdmConstantsUtil.TEXT_TYPEACTUAL);
			String strPolicy = (String) paramMap.get(cdmConstantsUtil.TEXT_POLICY);

			String strObjectId = FrameworkUtil.autoName(context, "type_cdmSubProjectGroup", "policy_cdmProjectGroupPolicy");
//			String strObjectId = FrameworkUtil.autoName(context, "type_" + strType, "policy_"+strPolicy);
			DomainObject domObj = new DomainObject(strObjectId);
			String strGroupObjectId = domObj.getObjectId(context);

			MqlUtil.mqlCommand(context, "connect bus '" + strParentOID + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_OBJECT_TYPE_RELATIONSHIP + "' to " + strGroupObjectId);

			returnMap.put("cdmProjectCode", strCode);
			returnMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, "Y");
			domObj.setAttributeValues(context, returnMap);
			domObj.promote(context);
			returnMap.put("id", strGroupObjectId);
			ContextUtil.commitTransaction(context);

		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			returnMap.put("id", "");
			e.printStackTrace();
		}
		
		finally{
//			MqlUtil.mqlCommand(context, "Trigger On");
			MqlUtil.mqlCommand(context, "history on");
			return returnMap;
		}
	}
	
	
	/**
	 * 12.27 에서만 사용될 method 
	 * @param context
	 * @param arg
	 * @throws Exception
	 */
	public void connectProject(Context context,String[] arg)throws Exception{
		long startTime = System.currentTimeMillis();
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null;
		
		HashMap<String,String> tempCommonCodeHm = new HashMap<String,String>();
		HashMap<String,String> commonCodeHm = new HashMap<String,String>();
		tempCommonCodeHm.put("commonCodeVehicleIdLev2"      , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Vehicle' \"" );
		tempCommonCodeHm.put("commonCodeProductGroupIdLev2" , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Product Group Name'\" " );
		tempCommonCodeHm.put("commonCodeProductDivIdLev2"   , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Product Div'  \"" );
		tempCommonCodeHm.put("commonCodeCustomerIdLev2"   , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Customer'  \"" );
		
		for (Iterator iterator = tempCommonCodeHm.keySet().iterator(); iterator.hasNext();) {
			
			String stCommonCodeKey = (String) iterator.next();
			String stCommonCodeValue= (String)tempCommonCodeHm.get(stCommonCodeKey);
			String stCommonCodeMql = MqlUtil.mqlCommand(context, "temp query bus cdmCommonCode * * where "+stCommonCodeValue+" select id dump | ");
			
			StringList commonCodeMqlResult = FrameworkUtil.split(stCommonCodeMql, "|");
			String stLev2CommonCode = "";
			
			if(commonCodeMqlResult.size() >2 ){
				stLev2CommonCode = (String)commonCodeMqlResult.get(3);
				commonCodeHm.put(stCommonCodeKey, stLev2CommonCode);
			}else{
				String errorMessage = "NOT EXIST COMMONCODE OBJECT.";
				throw new Exception(errorMessage);
			}
		}
		
		String tempLev2CommonCodeVehicleId     	 = (String)commonCodeHm.get("commonCodeVehicleIdLev2");
		String tempLev2CommonCodeProductGroupId  = (String)commonCodeHm.get("commonCodeProductGroupIdLev2");
		String tempLev2CommonCodeProductTypeId 	 = (String)commonCodeHm.get("commonCodeProductDivIdLev2");
		String tempLev2CommonCodeCustomerId      = (String)commonCodeHm.get("commonCodeCustomerIdLev2");
		//
		
		if(arg.length != 1){
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		String tempFileAndLocation = arg[0];
		String commonCodeFilePath = "";
		String commonCodeFileName = "";
		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
		
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명
//		String[] sTempArgs = {S_COMMONCODE_EXCEL_PATH,S_COMMONCODE_EXCEL_PATH_NAME};
		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
		if (sTempArgs.length!=2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory  = sTempArgs[0];
		fileName		= sTempArgs[1];
		//로그 default 명 
		String logFileName 	= "modifyProject";

		//읽을 메인 시트명
		String sheetName 	= S_PROJECT_SHEET_NAME;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + FILE_SEPARATOR;
		}
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + FILE_SEPARATOR + OUTPUT_DIRECTORY + FILE_SEPARATOR + logFileName + "_" + cdmCommonExcel.getTimeStamp() + FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"     PROJECT MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		int successObjectCount     = 0;
		int failObjectCount 	   = 0;
		String sPhysicalNumberRows = "";
		int totalObjectCont        = 0;
		
		StringList busSelect = new StringList();
		busSelect.add("id");
		busSelect.add("attribute[cdmProjectObjectIdM]");
		String busWhere = "attribute[cdmProjectObjectIdM]!='' && attribute[cdmCheckMigration]=='Y'" ;
		MapList projectExistMapList = new MapList();
		projectExistMapList = DomainObject.findObjects(context,
				"cdmProjectGroupObject", 
				"*", 
				"*",
				"*",
				"*",
				busWhere,
				true,
				busSelect );
		HashMap projectExistMap	= new HashMap<>();	
		for (int projectExistNum = 0; projectExistNum < projectExistMapList.size(); projectExistNum++) {
			Map tempProjectExistMap = (Map)projectExistMapList.get(projectExistNum);
			String projectId = (String)tempProjectExistMap.get("id");
			String attributeInfo = (String)tempProjectExistMap.get("attribute[cdmProjectObjectIdM]");
			projectExistMap.put(attributeInfo, projectId);
			
		}
		try{
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalObjectCont = physicalNumberRows-2;
		
			for (int i = 2; i < physicalNumberRows; i++) {
				StringBuffer sbErrorData = new StringBuffer(""); 
				try{
					XSSFRow row = sheet.getRow(i);
					sPhysicalNumberRows = String.valueOf(i+1);
					
					if (row == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL) \t 1";
						throw new Exception(errorMessage);
					}
					
					String strProjectObjectId = "";
					XSSFCell cell_0 = row.getCell(0);// 순번
					XSSFCell cell_1 = row.getCell(1);// TDMX_ID
					XSSFCell cell_2 = row.getCell(2);// TDM_DESCRIPTION
					XSSFCell cell_4 = row.getCell(4);// PROD_Type
					XSSFCell cell_5 = row.getCell(5);// PROD_Name
					XSSFCell cell_6 = row.getCell(6);// TDMX_CUSTOMER
					XSSFCell cell_7 = row.getCell(7);// CN_VEHICLE
					
					if (cell_5 != null && cell_2 != null && cell_7 != null && cell_6 != null && cell_4 != null) {
						String stNumber                 = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_0));
						String stProject_Id             = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_1));
						String stLev4 				    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_2));
						String stProductType 		    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_4));
						String stProductNameAndLev2     = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_5));
						String stCustomerAndLev3 	    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_6));
						String stVehicle 			    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_7));
						strProjectObjectId = (String)projectExistMap.get(stProject_Id);
						
						String sProductNameObjectId = "";
						String sProductTypeObjectId = "";
						String sCustomerObjectId 	= "";
						String sVehicleObjectId 	= "";
						// Product Group
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeProductGroupId)) {
							String productGroupIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stProductNameAndLev2 + "' && attribute[cdmCommonTemp2]=='" + stProductType + "' \" dump |";
							sProductNameObjectId = expandCommonCodeMql(context, tempLev2CommonCodeProductGroupId, productGroupIddWhere, "S");
				
						}
				
						/* Product Type */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeProductTypeId) ) {
							String productDivIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stProductType + "' \" dump |";
							sProductTypeObjectId = expandCommonCodeMql(context, tempLev2CommonCodeProductTypeId, productDivIddWhere, "S");
				
						}
						
						/* CUSTOMER */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeCustomerId) ) {
							String productCustomerIdWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCode] == '" + stCustomerAndLev3 + "' \" dump |";
							sCustomerObjectId = expandCommonCodeMql(context, tempLev2CommonCodeCustomerId, productCustomerIdWhere, "S");
						}
						
						/* VEHICLE */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeVehicleId) ) {
							String productVehicleIdWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCode]=='" + stVehicle + "' && to[cdmCommonCodeRelationship].from.attribute[cdmCommonCode]=='"+stCustomerAndLev3+ "' \" dump |";
							sVehicleObjectId = expandCommonCodeMql(context, tempLev2CommonCodeVehicleId, productVehicleIdWhere, "S");
						}
						//
						
						String strProductNameId = sProductNameObjectId;
						String strProductTypeId = sProductTypeObjectId;
						String strCustomerId = sCustomerObjectId;
						String strVehicleId = sVehicleObjectId;
						if (!strProductNameId.equals("")) {
							MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME + " to " + strProductNameId);
						}
						if (!strProductTypeId.equals("")) {
							MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE + " to " + strProductTypeId);
						}
						if (!strCustomerId.equals("")) {
							MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER + " to " + strCustomerId);
						}
						if (!strVehicleId.equals("")) {
							StringList slVehicleList = FrameworkUtil.split(strVehicleId, ",");
							for (int jj = 0; jj < slVehicleList.size(); jj++) {
								String strVehicleObjectId = (String) slVehicleList.get(jj);
								if (!"".equals(strVehicleObjectId)) {
									MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE + " to " + strVehicleObjectId);
								}
							}
						}
						successObjectCount++;
						multiWriteMessageToFile(successObjectidWriter, "LINE NUMBER: \t" + sPhysicalNumberRows+"\t "+stProject_Id+" \t" + sbErrorData.toString());
					}
				}catch(Exception e1){
					failObjectCount++;
//					ContextUtil.abortTransaction(context);
					multiWriteMessageToFile(failedObjectidWriter, "LINE NUMBER: \t" + sPhysicalNumberRows+"\t EXCEPTION: \t" + e1.getMessage() );
					mulitWriteErrorToFile(errorStream, "LINE NUMBER: \t" + sPhysicalNumberRows + " \t EXCEPTION: \t" + e1.getMessage());
					e1.printStackTrace(errorStream);
				}
			}
		}catch(Exception e){
			multiWriteMessageToFile(logWriter, "==================================================================================== ");
			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, " Total Count:("+totalObjectCont +")   FAIL COUNT : ("+failObjectCount+")    SUCCESS COUNT : ("+successObjectCount+")    LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms             ");
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e2) {
				System.out.println("Exception while closing log stream " + e2.getMessage());
			}

			System.out.println("cdmCommonCodeMigration : connectProject --> end." +cdmCommonExcel.getTimeStamp2() );
		}
	}
	
	
	/**
	 * Only the first data of the retrieved bus information is fetched.
	 * @param context
	 * @param sType
	 * @param sName
	 * @param sRevision
	 * @param sWhere
	 * @param sSelect
	 * @param sDumpAccept
	 * @param sDumpMark
	 * @return
	 */
	private String getOnlySearchBus(Context context, String sType, String sName, String sRevision, String sWhere, String sSelect,  String sDumpMark) {
		// TODO Auto-generated method stub
		String result = "";
		try{
			if(cdmStringUtil.isEmpty(sRevision)){
				sRevision = "*";
			}
			
			String stMql = "";
			String stMqlResult = "";
			
			if(UIUtil.isNotNullAndNotEmpty(sWhere)){
				stMql = "temp query bus $1  $2 $3 where $4 select $5 dump $6 ";
				stMqlResult = MqlUtil.mqlCommand(context, stMql, new String[] { sType, sName, sRevision,sWhere, sSelect,sDumpMark});
			}else{
				stMql = "temp query bus $1  $2 $3  select $4 dump $5 ";
				stMqlResult = MqlUtil.mqlCommand(context, stMql, new String[] { sType, sName, sRevision, sSelect,sDumpMark});
			}
			StringList sListMqlResults 	= new StringList();
//			sListMqlResult 				= FrameworkUtil.split(stMqlResult, sDumpMark);
			//
			
			sListMqlResults = FrameworkUtil.split(stMqlResult, "\n");
			for (int i=0 ; i < sListMqlResults.size(); i++)
			{
				String sMqlResult = (String) sListMqlResults.get(i);
				StringList sListMqlResult = new StringList();
				sListMqlResult = FrameworkUtil.split(sMqlResult, sDumpMark);

				if (sListMqlResult.size() > 2) {
					result = (String) sListMqlResult.get(3);
					break;
				} else {
					result = "";
				}
			}
			return result;
		}catch(Exception e){
			e.printStackTrace();
			return null;
		}
		
	}

	private void mulitWriteErrorToFile(PrintStream pStrem , String message) throws Exception {
		pStrem.write(message.getBytes("UTF-8"));
		pStrem.write("\n".getBytes("UTF-8"));
		pStrem.flush();
	}
	private void multiWriteMessageToFile(BufferedWriter buff, String message) throws Exception {
		buff.write(message + "\n");
		buff.flush();

	}

//	/**
//	 * TYPE_CDMSUBPROJECTGROUP 과 TYPE_CDMPROJECTGROUPOBJECT object 생성
//	 * 
//	 * @param context
//	 * @param args: excel path 
//	 * @return
//	 * @throws Exception
//	 */
//	@SuppressWarnings({ "unused", "rawtypes", "unchecked" })
//	@com.matrixone.apps.framework.ui.CreateProcessCallable
//	public Map cdmProjectGroupCreate(Context context, String[] args) throws Exception {
//		Map returnMap = new HashMap();
//		HashMap paramMap = (HashMap) JPO.unpackArgs(args);
//		String parentOID = (String) paramMap.get("objectId");
//		String name = (String) paramMap.get("Name");
//		String type = (String) paramMap.get("TypeActual");
//		String policy = (String) paramMap.get("Policy");
//		
//		String customer = (String) paramMap.get("Customer")==null?"":(String) paramMap.get("Customer");
//		String productType = (String) paramMap.get("ProductType")==null?"":(String) paramMap.get("ProductType");
//		String productName = (String) paramMap.get("ProductName")==null?"":(String) paramMap.get("ProductName");
//		String vehicle = (String) paramMap.get("Vehicle")==null?"":(String) paramMap.get("Vehicle");
//		
//		
//		try {
//			
//			DomainObject domObj = new DomainObject();
//			String objectId= "";
//			if(cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP.equals(type)){
//				objectId = FrameworkUtil.autoName(context, "type_cdmSubProjectGroup", "policy_cdmProjectGroupPolicy");
//			}else{
//				objectId = FrameworkUtil.autoName(context, "type_cdmProjectGroupObject", "policy_cdmProjectGroupPolicy");
//			}
//			
//			domObj.setId(objectId);
//			MqlUtil.mqlCommand(context, "connect bus '" + parentOID + "' relationship cdmProjectGroupObjectTypeRelationShip to " + objectId);
//			
//			if(type.equals(cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT)){
//				Map requestMap2 = new HashMap();
//				requestMap2.put("cdmProjectGroupCustomerAttribute", customer);
//				requestMap2.put("cdmProjectCode", name);
//				requestMap2.put("cdmProjectGroupProductNameAttribute", productName);
//				requestMap2.put("cdmProjectGroupVehicleAttribute", vehicle);
//				requestMap2.put("cdmProjectGroupProductTypeAttribute", productType);
//				
//				domObj.setAttributeValues(context, requestMap2);
//			}else{
//				domObj.setAttributeValue(context, "cdmProjectCode", name);
//			}
//			
//			returnMap.put("id", objectId);
//
//			return returnMap;
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw e;
//		}
//	}
	
	
//	@SuppressWarnings({ "rawtypes", "unused" })
//	private String uniqueCommonCodeAttribute(Context context, String type, String name, String revision, String owner, String vault, String where, SelectList selectList) {
//		// TODO Auto-generated method stub
//		String result = "";
//		try {
//			if (cdmStringUtil.isEmpty(type)) {
//				type = cdmConstantsUtil.QUERY_WILDCARD;
//			}
//			if (cdmStringUtil.isEmpty(name)) {
//				name = cdmConstantsUtil.QUERY_WILDCARD;
//			}
//			if (cdmStringUtil.isEmpty(revision)) {
//				revision = cdmConstantsUtil.QUERY_WILDCARD;
//			}
//			if (cdmStringUtil.isEmpty(owner)) {
//				owner = cdmConstantsUtil.QUERY_WILDCARD;
//			}
//			if (cdmStringUtil.isEmpty(vault)) {
//				vault = cdmConstantsUtil.QUERY_WILDCARD;
//			}
//			if (cdmStringUtil.isEmpty(where)) {
//				where = "";
//			}
//			if (selectList == null) {
//				SelectList selectList2 = new SelectList();
//				selectList2.addId();
//				selectList = selectList2;
//			}
//
//			MapList findUniqueMapList = DomainObject.findObjects(context, type, // type
//					name, // name
//					revision, // rev
//					owner, // owner
//					vault, // vault
//					where, // where
//					false, // expand
//					selectList); // select
//
//			
//			if (findUniqueMapList.size() > 0) {
//				for (int i = 0; i < findUniqueMapList.size(); i++) {
//					Map findUniqueMap = (Map) findUniqueMapList.get(i);
//					String stFindUnique = (String) findUniqueMap.get("id");
//					result = stFindUnique;
//					break;
//				}
//
//			} else {
//				result = "";
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//
//		return result;
//	}
		
	
	
	/**
	 * migration 한 모든 projectObject 및 Project 정보 삭제 
	 * @param context
	 * @param arg
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void deleteProject(Context context, String arg[]) throws Exception {
		try {
			
			
			String type = cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT;
			String name = cdmConstantsUtil.QUERY_WILDCARD;
			String revision = cdmConstantsUtil.QUERY_WILDCARD;
			String owner = cdmConstantsUtil.QUERY_WILDCARD;
			String vault = cdmConstantsUtil.QUERY_WILDCARD;
			String objectWhere = "name ~= \"Project-*\"";
			SelectList selectList = new SelectList();
			selectList.addId();

			MapList findMapListDeleteObjects = DomainObject.findObjects(context, type, // type
					name, // name
					revision, // rev
					owner, // owner
					vault, // vault
					objectWhere, // where
					false, // expand
					selectList); // select
			System.out.println("findMapListDeleteObjects ->"+findMapListDeleteObjects.size());
			for (int i = 0; i < findMapListDeleteObjects.size(); i++) {
				Map findMapDeleteObjects = (Map) findMapListDeleteObjects.get(i);
				String objectId = (String) findMapDeleteObjects.get("id");

				DomainObject dObj = new DomainObject(objectId);
				dObj.delete(context);
			}

			String type2 = cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP;
			String name2 = cdmConstantsUtil.QUERY_WILDCARD;
			String objectWhere2 = "name ~= \"ProjectGroup-*\"";
			MapList findMapListDeleteGroup = DomainObject.findObjects(context, type2, // type
					name2, // name
					revision, // rev
					owner, // owner
					vault, // vault
					objectWhere2, // where
					false, // expand
					selectList); // selectb
			System.out.println("findMapListDeleteGroup ->"+findMapListDeleteGroup.size());
			for (int i = 0; i < findMapListDeleteGroup.size(); i++) {
				Map findMapDeleteGroup = (Map) findMapListDeleteGroup.get(i);
				String grouptObjectId = (String) findMapDeleteGroup.get("id");

				DomainObject dObjGroup = new DomainObject(grouptObjectId);
				dObjGroup.delete(context);
			}
			System.out.println("sucees ~~");
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
	/**
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void modifyProjectGroup(Context context,String args[])throws Exception{
		String erroId = "";
		try{
			String typeSubProjectGroup = "cdmSubProjectGroup";
			String name = cdmConstantsUtil.QUERY_WILDCARD;
			String objectWhere = "name ~= \"ProjectGroup-*\" && attribute[cdmProjectCode]!='' ";
			String revision = cdmConstantsUtil.QUERY_WILDCARD;
			String owner = cdmConstantsUtil.QUERY_WILDCARD;
			String vault = cdmConstantsUtil.QUERY_WILDCARD;
			SelectList selectList = new SelectList();
			selectList.addId();
//			selectList.add("attribute[cdmSubProjectGroupCode]");
			
			
			MapList findPGMapList = DomainObject.findObjects (context, 
					typeSubProjectGroup, // type
					name, // name
					revision, // rev
					owner, // owner
					vault, // vault
					objectWhere, // where
					false, // expand
					selectList); // selectb
			
			for (Iterator iterator = findPGMapList.iterator(); iterator.hasNext();) {
				Map findPGMap = (Map) iterator.next();
				String findPGId = (String)findPGMap.get("id");
				erroId = findPGId;
				String preFindPGAttributeCode = (String)findPGMap.get("attribute[cdmSubProjectGroupCode]");
				
				DomainObject dObj = new DomainObject();
				dObj.setId(findPGId);
				dObj.setAttributeValue(context, "cdmCheckMigration", "Y");
//				dObj.setAttributeValue(context, "cdmSubProjectGroupCode", "");
				
			}
			System.out.println("success !");
		}catch(Exception e){
			String error = "erroId "+erroId;
			System.out.println(error);
			e.printStackTrace();
		}
	}
	
	
	/**
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void modifyProject(Context context,String args[])throws Exception{
		String erroId = "";
		try{
			String typeProject = "cdmProjectGroupObject";
			String name = cdmConstantsUtil.QUERY_WILDCARD;
			String objectWhere = "name ~= \"Project-*\" && attribute[cdmProjectCode]!='' ";
			String revision = cdmConstantsUtil.QUERY_WILDCARD;
			String owner = cdmConstantsUtil.QUERY_WILDCARD;
			String vault = cdmConstantsUtil.QUERY_WILDCARD;
			SelectList selectList = new SelectList();
			selectList.addId();
			selectList.add("attribute[cdmProjectGroupObjectCode]");
			
			
			MapList findPMapList = DomainObject.findObjects (context, 
					typeProject, // type
					name, // name
					revision, // rev
					owner, // owner
					vault, // vault
					objectWhere, // where
					false, // expand
					selectList); // selectb
			
			for (Iterator iterator = findPMapList.iterator(); iterator.hasNext();) {
				Map findPMap = (Map) iterator.next();
				String findPId = (String)findPMap.get("id");
				erroId = findPId;
				String preFindPAttributeCode = (String)findPMap.get("attribute[cdmProjectGroupObjectCode]");
				
				DomainObject dObj = new DomainObject();
				dObj.setId(findPId);
				dObj.setAttributeValue(context, "cdmCheckMigration", "Y");
//				dObj.setAttributeValue(context, "cdmProjectGroupObjectCode", "");
				
			}
			System.out.println("success !");
		}catch(Exception e){
			String error = "erroId "+erroId;
			System.out.println(error);
			e.printStackTrace();
		}
	}
	

	public String expandCommonCodeMql(Context context,String lev2CommonCode,String commonCodeWhere, String SingleAndMulti)throws Exception{
		StringBuffer result = new StringBuffer();
		try{
			String stCommonCodeMql = "expand  bus "+ lev2CommonCode  +" "+commonCodeWhere ;
    	 	String stCommonCodeMqResult = MqlUtil.mqlCommand(context, stCommonCodeMql);
    	 	
    	 	StringList stListCommonCodeMqResult =  FrameworkUtil.split(stCommonCodeMqResult, "\n");
    	 	int number = 1;
    	 	
    	 	for (Iterator stListCommonCodeIerator = stListCommonCodeMqResult.iterator(); stListCommonCodeIerator.hasNext();) {
    	 		String stTempCommonCode = (String) stListCommonCodeIerator.next();
			
				StringList stListTempCommonCode =  FrameworkUtil.split(stTempCommonCode, "|");
				String stCommonCode= (String)stListTempCommonCode.get(6); //ex : 1|cdmCommonCodeRelationship|to|cdmCommonCode|CC-0000006643|-|8820.41398.39528.10777
				
				if("M".equals(SingleAndMulti) && stListCommonCodeMqResult.size() > number && stListCommonCodeMqResult.size() >1 ){
					result.append(",");
	    	 	}
				result.append(stCommonCode);
				number ++;
				if("S".equals(SingleAndMulti)){
					break;
				}
    	 	}
    	 	return result.toString();
		}catch(Exception e){
			e.printStackTrace();
			StringBuffer errorBuf = new StringBuffer();
			errorBuf.append("");
			return errorBuf.toString();
		}
		
	}
	
	/**
	 * 0105 
	 * cdmProjectGroupObject miss 된 connect 처리 
	 * 
	 */
	public void connectCommonCode(Context context, String args[])throws Exception{

		
		System.out.println("cdmCommonCodeMigration : connectCommonCode --> start." +cdmCommonExcel.getTimeStamp2() );
		long startTime = System.currentTimeMillis();
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		Map paramMap = (HashMap)JPO.unpackArgs(args);
		String commonCodeFilePath = (String)paramMap.get("File_Location");
		String commonCodeFileName = (String)paramMap.get("File");
//		if(cdmStringUtil.isEmpty(commonCodeFilePath) || cdmStringUtil.isEmpty(commonCodeFileName)){
//			String errorMessage = "The file to read does not exist.";
//			throw new Exception(errorMessage);
//		}
		
//		if(args.length != 1){
//			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//		}
//		String tempFileAndLocation = arCgs[0];
//		String commonCodeFilePath = "";
//		String commonCodeFileName = "";
//		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
//		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
		
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명
//		String[] sTempArgs = {S_COMMONCODE_EXCEL_PATH,S_COMMONCODE_EXCEL_PATH_NAME};
		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
		if (sTempArgs.length!=2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory  = sTempArgs[0];
		fileName		= sTempArgs[1];
		//로그 default 명 
		String logFileName 	= "connectCommonCode";

		//읽을 메인 시트명
		String sheetName 	= S_PROJECT_SHEET_NAME;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + FILE_SEPARATOR;
		}
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + FILE_SEPARATOR + OUTPUT_DIRECTORY + FILE_SEPARATOR + logFileName + "_" + cdmCommonExcel.getTimeStamp() + FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"     PROJECT MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		int successObjectCount     = 0;
		int failObjectCount 	   = 0;
		String sPhysicalNumberRows = "";
		int totalObjectCont        = 0;
		try{
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalObjectCont = physicalNumberRows-2;
			
			// project find start 
			String   sWhere 		 = "";
			String   sSelect		 = "id";
			
			//type,name,revision,where,select,dump
			String   stProjectTreeId = "";
			stProjectTreeId = (String)getOnlySearchBus(context,S_SUBPROJECT_GROUP_TYPE, S_PROJECT_TOP_OBJECT_NAME, QUERY_WILDCARD,sWhere,sSelect,DUMP_DEFAULT);
			//project find end 
			 
			
			HashMap<String,String> tempCommonCodeHm = new HashMap<String,String>();
			HashMap<String,String> commonCodeHm = new HashMap<String,String>();
			tempCommonCodeHm.put("commonCodeVehicleIdLev2"      , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Vehicle' \"" );
			tempCommonCodeHm.put("commonCodeProductGroupIdLev2" , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Product Group Name'\" " );
			tempCommonCodeHm.put("commonCodeProductDivIdLev2"   , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Product Div'  \"" );
			tempCommonCodeHm.put("commonCodeCustomerIdLev2"   , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Customer'  \"" );
			
			for (Iterator iterator = tempCommonCodeHm.keySet().iterator(); iterator.hasNext();) {
				
				String stCommonCodeKey = (String) iterator.next();
				String stCommonCodeValue= (String)tempCommonCodeHm.get(stCommonCodeKey);
				String stCommonCodeMql = MqlUtil.mqlCommand(context, "temp query bus cdmCommonCode * * where "+stCommonCodeValue+" select id dump | ");
				
				StringList commonCodeMqlResult = FrameworkUtil.split(stCommonCodeMql, "|");
				String stLev2CommonCode = "";
				
				if(commonCodeMqlResult.size() >2 ){
					stLev2CommonCode = (String)commonCodeMqlResult.get(3);
					commonCodeHm.put(stCommonCodeKey, stLev2CommonCode);
				}else{
					String errorMessage = "NOT EXIST COMMONCODE OBJECT.";
					throw new Exception(errorMessage);
				}
			}
			String tempLev2CommonCodeVehicleId     	 = (String)commonCodeHm.get("commonCodeVehicleIdLev2");
			String tempLev2CommonCodeProductGroupId  = (String)commonCodeHm.get("commonCodeProductGroupIdLev2");
			String tempLev2CommonCodeProductTypeId 	 = (String)commonCodeHm.get("commonCodeProductDivIdLev2");
			String tempLev2CommonCodeCustomerId      = (String)commonCodeHm.get("commonCodeCustomerIdLev2");
			
			/*데이타는 ROW 3줄 부터 시작*/
			for (int i = 2; i < physicalNumberRows; i++) {
				StringBuffer sbErrorData = new StringBuffer(""); 
				try{
					XSSFRow row = sheet.getRow(i);
					sPhysicalNumberRows = String.valueOf(i+1);
					
					if (row == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL) \t 1";
						throw new Exception(errorMessage);
					}
					
					
					XSSFCell cell_0 = row.getCell(0);// 순번
					XSSFCell cell_1 = row.getCell(1);// TDMX_ID
					XSSFCell cell_2 = row.getCell(2);// TDM_DESCRIPTION
					XSSFCell cell_4 = row.getCell(4);// PROD_Type
					XSSFCell cell_5 = row.getCell(5);// PROD_Name
					XSSFCell cell_6 = row.getCell(6);// TDMX_CUSTOMER
					XSSFCell cell_7 = row.getCell(7);// CN_VEHICLE
					
					if (cell_5 != null && cell_2 != null && cell_7 != null && cell_6 != null && cell_4 != null) {
						String stNumber                 = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_0));
						String stProject_Id             = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_1));
						String stLev4 				    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_2));
						String stProductType 		    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_4));
						String stProductNameAndLev2     = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_5));
						String stCustomerAndLev3 	    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_6));
						String stVehicle 			    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_7));
						
						
						int number = Integer.parseInt(stNumber);
						
						if(cdmStringUtil.isEmpty(stLev4)){
							sbErrorData.append("NOT EXIST DATA. (CELL_2 EMPTY): " );
							sbErrorData.append(stLev4);
							sbErrorData.append("\t");
//							String errorMessage = "NOT EXIST DATA. (CELL_2 EMPTY)";
//							throw new Exception(errorMessage);
						}
						if(cdmStringUtil.isEmpty(stProductType)){
							sbErrorData.append("NOT EXIST DATA. (CELL_4 EMPTY): ");
							sbErrorData.append(stProductType);
							sbErrorData.append("\t");
//							String errorMessage = "NOT EXIST DATA. (CELL_4 EMPTY)";
//							throw new Exception(errorMessage);
						}
						if(cdmStringUtil.isEmpty(stProductNameAndLev2)){
							sbErrorData.append("NOT EXIST DATA. (CELL_5 EMPTY): ");
							sbErrorData.append(stProductNameAndLev2);
							sbErrorData.append("\t");
//							String errorMessage = "NOT EXIST DATA. (CELL_5 EMPTY)";
//							throw new Exception(errorMessage);
						}
						if(cdmStringUtil.isEmpty(stCustomerAndLev3)){
							sbErrorData.append("NOT EXIST DATA. (CELL_6 EMPTY)");
							sbErrorData.append(stCustomerAndLev3);
							sbErrorData.append("\t");
//							String errorMessage = "NOT EXIST DATA. (CELL_6 EMPTY)";
//							throw new Exception(errorMessage);
						}
						
						String sProductNameObjectId = "";
						String sProductTypeObjectId = "";
						String sCustomerObjectId 	= "";
						String sVehicleObjectId 	= "";

						// Product Group
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeProductGroupId)) {
							String productGroupIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stProductNameAndLev2 + "' && attribute[cdmCommonTemp2]=='" + stProductType + "' \" dump |";
							sProductNameObjectId = expandCommonCodeMql(context, tempLev2CommonCodeProductGroupId, productGroupIddWhere, "S");
	
						}
	
						/* Product Type */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeProductTypeId) ) {
							String productDivIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stProductType + "' \" dump |";
							sProductTypeObjectId = expandCommonCodeMql(context, tempLev2CommonCodeProductTypeId, productDivIddWhere, "S");
	
						}
						
						/* CUSTOMER */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeCustomerId) ) {
							String productCustomerIdWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCode] == '" + stCustomerAndLev3 + "' \" dump |";
							sCustomerObjectId = expandCommonCodeMql(context, tempLev2CommonCodeCustomerId, productCustomerIdWhere, "S");
						}
						
						/* VEHICLE */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeVehicleId) ) {
							String productVehicleIdWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCode]=='" + stVehicle + "' && to[cdmCommonCodeRelationship].from.attribute[cdmCommonCode]=='"+stCustomerAndLev3+ "' \" dump |";
							sVehicleObjectId = expandCommonCodeMql(context, tempLev2CommonCodeVehicleId, productVehicleIdWhere, "S");
						}

						
						if(cdmStringUtil.isEmpty(sVehicleObjectId)) {
							sbErrorData.append("NOT EXIST COMMOMCODE(Vehicle) :");
							sbErrorData.append("Vehicle -Attribute[CommonCode] :");
							sbErrorData.append(stVehicle);
							sbErrorData.append(" | Vehicle -to[].from.Attribute[CommonCode] :");
							sbErrorData.append(stCustomerAndLev3);
							sbErrorData.append("\t");
//							String sErrorMessage = "NOT EXIST COMMOMCODE(Vehicle)";
//							throw new Exception(sErrorMessage);
						}
						
						if(cdmStringUtil.isEmpty(sCustomerObjectId)) {
							
							sbErrorData.append("NOT EXIST COMMOMCODE(Customer) :");
							sbErrorData.append("Customer -Attribute[CommonCode] :");
							sbErrorData.append(stCustomerAndLev3);
							sbErrorData.append("\t");
							
//							String sErrorMessage = "NOT EXIST COMMOMCODE(Customer)";
//							throw new Exception(sErrorMessage);
						}
						
						if(cdmStringUtil.isEmpty(sProductTypeObjectId)) {
							
							sbErrorData.append("NOT EXIST COMMOMCODE(Product Type) :");
							sbErrorData.append("Product Type -Attribute[cdmCommonCodeNameEn] :");
							sbErrorData.append(stProductType);
							sbErrorData.append("\t");
							
//							String sErrorMessage = "NOT EXIST COMMOMCODE(Product Type)";
//							throw new Exception(sErrorMessage);
						}
						
						if(cdmStringUtil.isEmpty(sProductNameObjectId)) {
							
							sbErrorData.append("NOT EXIST COMMOMCODE(Product Name) :");
							sbErrorData.append("Product Name -Attribute[cdmCommonCodeNameEn] :");
							sbErrorData.append(stProductNameAndLev2);
							sbErrorData.append(" | attribute[cdmCommonTemp2] :");
							sbErrorData.append(stProductType);
							sbErrorData.append("\t");
//							String sErrorMessage = "NOT EXIST COMMOMCODE(Product Name)";
//							throw new Exception(sErrorMessage);
						}
						
						
						String projectGroupWhere = "attribute[cdmProjectCode] == '" + stProductNameAndLev2 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + stProjectTreeId + "' ";
//						String existLev2 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP, "", "", "", "", projectGroupWhere, selectList);
						
						String existLev2 = "";
						existLev2 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupWhere, "id", DUMP_DEFAULT);
						
						boolean checkExistProject = false;
						ContextUtil.startTransaction(context, true);
						if (cdmStringUtil.isEmpty(existLev2)) {} else { // lev 2 exist
							String projectGroupLev3Where = "attribute[cdmProjectCode] == '" + stCustomerAndLev3 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev2 + "'";
//							String existLev3 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP, "", "", "", "", projectGroupLev3Where, selectList);
							String existLev3 = "";
							existLev3 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev3Where, "id", DUMP_DEFAULT);
						
							if (cdmStringUtil.isEmpty(existLev3)) {} else {
								// lev3 exist
//								String projectGroupObjectWhere = "attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE + "] == '" + stProductType + "' && attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_VEHICLE_ATTRIBUTE + "] == '" + stVehicle + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
//								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDMCOMMONCODENAMEKO + "] == '" + stProductType + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE + "] == '" + stVehicle + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE + "] == '" +stProductNameAndLev2 +"' && from[cdmProjectGroupRelationshipCustomer].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE + "] == '" + stCustomerAndLev3 + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
//								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
//								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
								String projectGroupObjectWhere = "attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
//								String existLev4 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, "", "", "", "", projectGroupObjectWhere, selectList);
								String existLev4 = "";
								existLev4 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
								
								if(existLev4 == null){
									String errorMessage = "NOT EXIST PROEJCT OBJECT OBJECT.";
									throw new Exception(errorMessage);
								}
								
								if (cdmStringUtil.isEmpty(existLev4)) {}else{
//									Map requestArgLev4 = new HashMap();
//									requestArgLev4.put("objectId", existLev3);
//									requestArgLev4.put("Name", stLev4);
//									requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
//									requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
//		
//									requestArgLev4.put("Customer", stCustomerAndLev3);
//									requestArgLev4.put("ProductType", stProductType);
//									requestArgLev4.put("ProductName", stProductNameAndLev2);
//									requestArgLev4.put("Vehicle", stVehicle);
//									requestArgLev4.put("ProductNameObjectId", sProductNameObjectId);
//									requestArgLev4.put("ProductTypeObjectId", sProductTypeObjectId);
//									requestArgLev4.put("CustomerObjectId", sCustomerObjectId);
//									requestArgLev4.put("VehicleObjectId", sVehicleObjectId);
//									requestArgLev4.put("ProjectLeafId", stProject_Id);
//									requestArgLev4.put("sCustomer",stCustomerAndLev3 );
									
									DomainObject existLev4Dobj = new DomainObject(existLev4);
									//
//									if (!sProductNameObjectId.equals("")) {
//										MqlUtil.mqlCommand(context, "connect bus " + existLev4 + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME + " to " + sProductNameObjectId);
//									}
//									if (!sProductTypeObjectId.equals("")) {
//										MqlUtil.mqlCommand(context, "connect bus " + existLev4 + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE + " to " + sProductTypeObjectId);
//									}
//									if (!sCustomerObjectId.equals("")) {
//										MqlUtil.mqlCommand(context, "connect bus " + existLev4 + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER + " to " + sCustomerObjectId);
//									}
									if (!sVehicleObjectId.equals("")) {
										StringList slVehicleList = FrameworkUtil.split(sVehicleObjectId, ",");
										for (int vehicleNum = 0; vehicleNum < slVehicleList.size(); vehicleNum++) {
											String strVehicleObjectId = (String) slVehicleList.get(vehicleNum);
											if (!"".equals(strVehicleObjectId)) {
												MqlUtil.mqlCommand(context, "connect bus " + existLev4 + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE + " to " + strVehicleObjectId);
											}
										}
									}
									
									checkExistProject = true;
								}
							}
		
						}
						
						if(!checkExistProject){
							throw new Exception("not exist project");
						}else{
							
							successObjectCount ++;
						}
						
						
						multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. REAL NUMBER: \t"+stNumber+ "\t LINE NUMBER: \t " + sPhysicalNumberRows + " \t  CreateProjectLev4: \t "+stLev4 +"\t CreateProjectLev3:"+stCustomerAndLev3+" \t  CreateProjectLev2: \t "+stProductNameAndLev2 +" \t "+sbErrorData.toString());
						
					}else{
						String errorMessage = "NOT EXIST NECESSARY DATA";
						throw new Exception(errorMessage);
					}
					ContextUtil.commitTransaction(context);
				}catch(Exception e1){
					failObjectCount++;
					ContextUtil.abortTransaction(context);
					multiWriteMessageToFile(failedObjectidWriter, "LINE NUMBER: \t" + sPhysicalNumberRows+"\t EXCEPTION: \t" + e1.getMessage() );
					mulitWriteErrorToFile(errorStream, "LINE NUMBER: \t" + sPhysicalNumberRows + " \t EXCEPTION: \t" + e1.getMessage());
					e1.printStackTrace(errorStream);
				}
			}
			
			
		}catch(Exception e2){
//			multiWriteMessageToFile(logWriter, "LINE NUMBER: " + sPhysicalNumberRows+" | EXCEPTION : " + e2.getMessage() );
			mulitWriteErrorToFile(errorStream, "LINE NUMBER: " + sPhysicalNumberRows + " \t EXCEPTION:" + e2.getMessage());
			e2.printStackTrace(errorStream);
		
		}finally{
			multiWriteMessageToFile(logWriter, "==================================================================================== ");
			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, " Total Count:("+totalObjectCont +")   FAIL COUNT : ("+failObjectCount+")    SUCCESS COUNT : ("+successObjectCount+")    LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms             ");
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

			System.out.println("cdmCommonCodeMigration : addProjectGroupAndProject --> end." +cdmCommonExcel.getTimeStamp2() );
		}
	
	}
	
	/**
	
	 * 재연결 
	 * 1/10 update
	 * 상위 레벨 추가 
	 * 2레벨 PROD_DIV 
	 * 3레벨 PROD_DIV
	 * 4레벨 TDMX_CUSTOMER
	 * 
	 * 고쳐야할 대상 
	 * 	lev1 레벨 name
	 *  메인 시트명 
	 *  log name default  
	 * 
	 * 
	 * 레벨1 단계를 생성한다 이부분은 테스트용이며 추후 반드시 proejct Tree 로 변경해야한다 .(대소문자 확인 후 진행할것) 
	 * 테스트 단계에서는 ( name: TEST_CHANGE_LEV3 ) 명을 사용
	 * @param context
	 * @param arg
	 * @throws Exception
	 */
	public void addPGAndProject(Context context,String args[])throws Exception{

		System.out.println("cdmCommonCodeMigration : addPGAndProject --> start." +cdmCommonExcel.getTimeStamp2() );
		long startTime = System.currentTimeMillis();
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		
//		if(args.length != 1){
//			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//		}
//		String tempFileAndLocation = args[0];
//		String commonCodeFilePath = "";
//		String commonCodeFileName = "";
//		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
//		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
		Map paramMap = (HashMap)JPO.unpackArgs(args);
		String commonCodeFilePath = (String)paramMap.get("File_Location");
		String commonCodeFileName = (String)paramMap.get("File");
		if(cdmStringUtil.isEmpty(commonCodeFilePath) || cdmStringUtil.isEmpty(commonCodeFileName)){
			String errorMessage = "The file to read does not exist.";
			throw new Exception(errorMessage);
		}
		
		
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명
		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
		if (sTempArgs.length!=2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory  = sTempArgs[0];
		fileName		= sTempArgs[1];
		//로그 default 명 
		String logFileName 	= "CreateProject_TEST";//0117

		//읽을 메인 시트명
//		String sheetName 	= S_PROJECT_SHEET_NAME;//Project
		String sheetName 	= "TEST_Project3";//
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + FILE_SEPARATOR;
		}
		
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + FILE_SEPARATOR + OUTPUT_DIRECTORY + FILE_SEPARATOR + logFileName + "_"  + FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		
		
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		logFileName +="_"+fileName.substring(0, fileName.lastIndexOf("."));
		logFileName+="_"+formatTime;
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"     PROJECT MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		int successObjectCount     = 0;
		int failObjectCount 	   = 0;
		String sPhysicalNumberRows = "";
		int totalObjectCont        = 0;
		try{
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalObjectCont = physicalNumberRows-2;
			
			String   sWhere 		 = "";
			String   sSelect		 = "id";
			
//			project Tree (최상위 cdmSubProjectGroup 검색) ,type,name,revision,where,select,dump (검색조건) 
			String   stProjectTreeId = "";
//			stProjectTreeId = (String)getOnlySearchBus(context,S_SUBPROJECT_GROUP_TYPE, S_PROJECT_TOP_OBJECT_NAME, QUERY_WILDCARD,sWhere,sSelect,DUMP_DEFAULT);
			stProjectTreeId = (String)getOnlySearchBus(context,S_SUBPROJECT_GROUP_TYPE, "TEMPTest_DataToBeDeleted", QUERY_WILDCARD,sWhere,sSelect,DUMP_DEFAULT);
			 
			//cdmSubProjectGroup  (Project Tree 가 없으면 생성)
			if(cdmStringUtil.isEmpty(stProjectTreeId)){
				DomainObject dProjectTree = new DomainObject();
				
//				dProjectTree.createObject(context, S_SUBPROJECT_GROUP_TYPE, S_PROJECT_TOP_OBJECT_NAME, "-", "cdmProjectGroupPolicy", cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
				dProjectTree.createObject(context, S_SUBPROJECT_GROUP_TYPE, "TEMPTest_DataToBeDeleted", "-", "cdmProjectGroupPolicy", cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
				stProjectTreeId = (String)dProjectTree.getId(context);
			}
			// commoncode 2레벨 object 검색 start  
			HashMap<String,String> tempCommonCodeHm = new HashMap<String,String>();
			HashMap<String,String> commonCodeHm = new HashMap<String,String>();
			tempCommonCodeHm.put("commonCodeVehicleIdLev2"      , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Vehicle' \"" );
			tempCommonCodeHm.put("commonCodeProductGroupIdLev2" , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Product Group Name'\" " );
			tempCommonCodeHm.put("commonCodeProductDivIdLev2"   , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Product Div'  \"" );
			tempCommonCodeHm.put("commonCodeCustomerIdLev2"   , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Customer'  \"" );
			
			for (Iterator iterator = tempCommonCodeHm.keySet().iterator(); iterator.hasNext();) {
				
				String stCommonCodeKey = (String) iterator.next();
				String stCommonCodeValue= (String)tempCommonCodeHm.get(stCommonCodeKey);
				String stCommonCodeMql = MqlUtil.mqlCommand(context, "temp query bus cdmCommonCode * * where "+stCommonCodeValue+" select id dump | ");
				
				StringList commonCodeMqlResult = FrameworkUtil.split(stCommonCodeMql, "|");
				String stLev2CommonCode = "";
				
				if(commonCodeMqlResult.size() >2 ){
					stLev2CommonCode = (String)commonCodeMqlResult.get(3);
					commonCodeHm.put(stCommonCodeKey, stLev2CommonCode);
				}else{
					String errorMessage = "NOT EXIST COMMONCODE OBJECT.";
					throw new Exception(errorMessage);
				}
			}
			String tempLev2CommonCodeVehicleId     	 = (String)commonCodeHm.get("commonCodeVehicleIdLev2");
			String tempLev2CommonCodeProductGroupId  = (String)commonCodeHm.get("commonCodeProductGroupIdLev2");
			String tempLev2CommonCodeProductTypeId 	 = (String)commonCodeHm.get("commonCodeProductDivIdLev2");
			String tempLev2CommonCodeCustomerId      = (String)commonCodeHm.get("commonCodeCustomerIdLev2");
			
			/*데이타는 ROW 3줄 부터 시작*/
			for (int i = 2; i < physicalNumberRows; i++) {
				StringBuffer sbErrorData = new StringBuffer(""); 
				try{
					XSSFRow row = sheet.getRow(i);
					sPhysicalNumberRows = String.valueOf(i+1);
					
					if (row == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL) \t 1";
						throw new Exception(errorMessage);
					}
					
					
					XSSFCell cell_0 = row.getCell(0);// 순번
					XSSFCell cell_1 = row.getCell(1);// TDMX_ID
					XSSFCell cell_2 = row.getCell(2);// TDM_DESCRIPTION
					XSSFCell cell_4 = row.getCell(4);// PROD_Type
					XSSFCell cell_5 = row.getCell(5);// PROD_Name
					XSSFCell cell_6 = row.getCell(6);// TDMX_CUSTOMER
					XSSFCell cell_7 = row.getCell(7);// CN_VEHICLE
					XSSFCell cell_9 = row.getCell(9);// SYSTEMPROD
					
					if (cell_2 != null  && cell_4 != null && cell_5 != null && cell_7 != null && cell_6 != null ) {
						String stNumber                 = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_0));
						String stProject_Id             = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_1));
						String stProjectLev5		    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_2));
//						String stProductType 		    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_4));
						String stProductTypeAndLev2	    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_4));
//						String stProductNameAndLev2     = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_5));
						String stProductNameAndLev3     = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_5));
//						String stCustomerAndLev3 	    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_6));
						String stCustomerAndLev4 	    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_6));
						String stVehicle 			    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_7));
						String stLev2	   				= cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_9));
						String sss= "";
						int number = Integer.parseInt(stNumber);
						
						if(cdmStringUtil.isEmpty(stProjectLev5)){
							sbErrorData.append("NOT EXIST DATA. (CELL_2 EMPTY): " );
							sbErrorData.append(stProjectLev5);
							sbErrorData.append("\t");
						}
						if(cdmStringUtil.isEmpty(stProductTypeAndLev2)){
							sbErrorData.append("NOT EXIST DATA. (CELL_4 EMPTY): ");
							sbErrorData.append(stProductTypeAndLev2);
							sbErrorData.append("\t");
						}
						if(cdmStringUtil.isEmpty(stProductNameAndLev3)){
							sbErrorData.append("NOT EXIST DATA. (CELL_5 EMPTY): ");
							sbErrorData.append(stProductNameAndLev3);
							sbErrorData.append("\t");
						}
						if(cdmStringUtil.isEmpty(stCustomerAndLev4)){
							sbErrorData.append("NOT EXIST DATA. (CELL_6 EMPTY)");
							sbErrorData.append(stCustomerAndLev4);
							sbErrorData.append("\t");
						}
						
						String sProductNameObjectId = "";
						String sProductTypeObjectId = "";
						String sCustomerObjectId 	= "";
						String sVehicleObjectId 	= "";

						// Product Group
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeProductGroupId)) {
							String productGroupIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stProductNameAndLev3 + "' && attribute[cdmCommonTemp2]=='" + stProductTypeAndLev2 + "' \" dump |";
							sProductNameObjectId = expandCommonCodeMql(context, tempLev2CommonCodeProductGroupId, productGroupIddWhere, "S");
	
						}
	
						/* Product Type */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeProductTypeId) ) {
							String productDivIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stProductTypeAndLev2 + "' \" dump |";
							sProductTypeObjectId = expandCommonCodeMql(context, tempLev2CommonCodeProductTypeId, productDivIddWhere, "S");
	
						}
						
						/* CUSTOMER */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeCustomerId) ) {
							String productCustomerIdWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCode] == '" + stCustomerAndLev4 + "' \" dump |";
							sCustomerObjectId = expandCommonCodeMql(context, tempLev2CommonCodeCustomerId, productCustomerIdWhere, "S");
						}
						
						/* VEHICLE */
						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeVehicleId) ) {
							String productVehicleIdWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCode]=='" + stVehicle + "' && to[cdmCommonCodeRelationship].from.attribute[cdmCommonCode]=='"+stCustomerAndLev4+ "' \" dump |";
							sVehicleObjectId = expandCommonCodeMql(context, tempLev2CommonCodeVehicleId, productVehicleIdWhere, "S");
						}

						
						if(cdmStringUtil.isEmpty(sVehicleObjectId)) {
							sbErrorData.append("NOT EXIST COMMOMCODE(Vehicle) :");
							sbErrorData.append("Vehicle -Attribute[CommonCode] :");
							sbErrorData.append(stVehicle);
							sbErrorData.append(" | Vehicle -to[].from.Attribute[CommonCode] :");
							sbErrorData.append(stCustomerAndLev4);
							sbErrorData.append("\t");
						}
						
						if(cdmStringUtil.isEmpty(sCustomerObjectId)) {
							
							sbErrorData.append("NOT EXIST COMMOMCODE(Customer) :");
							sbErrorData.append("Customer -Attribute[CommonCode] :");
							sbErrorData.append(stCustomerAndLev4);
							sbErrorData.append("\t");
							
						}
						
						if(cdmStringUtil.isEmpty(sProductTypeObjectId)) {
							
							sbErrorData.append("NOT EXIST COMMOMCODE(Product Type) :");
							sbErrorData.append("Product Type -Attribute[cdmCommonCodeNameEn] :");
							sbErrorData.append(stProductTypeAndLev2);
							sbErrorData.append("\t");
							
						}
						
						if(cdmStringUtil.isEmpty(sProductNameObjectId)) {
							
							sbErrorData.append("NOT EXIST COMMOMCODE(Product Name) :");
							sbErrorData.append("Product Name -Attribute[cdmCommonCodeNameEn] :");
							sbErrorData.append(stProductNameAndLev3);
							sbErrorData.append(" | attribute[cdmCommonTemp2] :");
							sbErrorData.append(stProductTypeAndLev2);
							sbErrorData.append("\t");
						}
						
						
						String projectGroupLLev2Where = "attribute[cdmProjectCode] == '" + stLev2 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + stProjectTreeId + "' ";
						String existLev2 = "";
						existLev2 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLLev2Where, "id", DUMP_DEFAULT);
						
//						if(existLev2 ==null){
//							String errorMessage = "NOT EXIST PROEJCT GROUP LEV2 OBJECT.";
//							throw new Exception(errorMessage);
//						}
						
						ContextUtil.startTransaction(context, true);
						if (cdmStringUtil.isEmpty(existLev2)) {
							
							
							Map requestArg = new HashMap();
							requestArg.put("objectId", stProjectTreeId);
							requestArg.put("Title", stLev2);
							requestArg.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
							requestArg.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
		
							Map createLev2Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArg), Map.class);
							String createLev2Id = (String) createLev2Map.get("id");
							if(cdmStringUtil.isEmpty(createLev2Id)){
								String errorMessage = "NOT CREATE LEVEL2 OBJECT.";
								throw new Exception(errorMessage);
							}
		
							String projectGroupLev3Where = "attribute[cdmProjectCode] == '" + stProductNameAndLev3 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev2Id + "' ";

							String existLev3 = "";
							existLev3 		 = getOnlySearchBus(context,S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev3Where, "id", DUMP_DEFAULT);
							
							if(existLev3 == null){
								String errorMessage = "NOT EXIST PROEJCT GROUP LEV3 OBJECT.";
								throw new Exception(errorMessage);
							}
							
							if (cdmStringUtil.isEmpty(existLev3)) {
								// lev 3 not exist
								Map requestArgLev3 = new HashMap();
								requestArgLev3.put("objectId", createLev2Id);
								requestArgLev3.put("Title", stProductNameAndLev3);
								requestArgLev3.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
								requestArgLev3.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
								
//								
								Map createLev3Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArgLev3), Map.class);
								String createLev3Id = (String) createLev3Map.get("id");
								if(cdmStringUtil.isEmpty(createLev3Id)){
									String errorMessage = "NOT CREATE LEVEL3 OBJECT.";
									throw new Exception(errorMessage);
								}	
								
							
								String projectGroupLev4Where = "attribute[cdmProjectCode] == '" + stCustomerAndLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev3Id + "' ";
								
								String existLev4 = "";
								existLev4 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev4Where, "id", DUMP_DEFAULT);
								if(existLev4 == null){
									String errorMessage = "NOT EXIST PROEJCTGROUP OBJECT OBJECT.";
									throw new Exception(errorMessage);
								}
								
								if (cdmStringUtil.isEmpty(existLev4)) {
										
										Map requestArgLev4 = new HashMap();
										requestArgLev4.put("objectId", createLev3Id);
										requestArgLev4.put("Title", stCustomerAndLev4);
										requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
										requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
										Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArgLev4), Map.class);
										
										String createLev4Id = (String) createLev4Map.get("id");
										if(cdmStringUtil.isEmpty(createLev4Id)){
											String errorMessage = "NOT CREATE LEVEL4(Customer) OBJECT.";
											throw new Exception(errorMessage);
										}
										
										
//										String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev3Id + "' ";
										String projectGroupObjectWhere = "attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev4Id + "' ";
										String existLev5 = "";
										existLev5 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
									
									
										if (cdmStringUtil.isEmpty(existLev5)) {
											
											Map requestArgLev5 = new HashMap();
											requestArgLev5.put("objectId", createLev4Id);
											requestArgLev5.put("Name", stProjectLev5);
											requestArgLev5.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
											requestArgLev5.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
											
											requestArgLev5.put("ProductNameObjectId", sProductNameObjectId);
											requestArgLev5.put("ProductTypeObjectId", sProductTypeObjectId);
											requestArgLev5.put("CustomerObjectId", sCustomerObjectId);
											requestArgLev5.put("VehicleObjectId", sVehicleObjectId);
											requestArgLev5.put("ProjectLeafId", stProject_Id);
											
											requestArgLev5.put("sCustomer",stCustomerAndLev4 );
			
											Map createLev5Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev5), Map.class);
											String createLev5Id = "";
											createLev5Id = (String) createLev5Map.get("id");
											if(cdmStringUtil.isEmpty(createLev5Id)){
												String sErrorMessage = "NOT CREATE PROJECT LEV5.";
												throw new Exception(sErrorMessage);
											}
		
										}
									}else{
										// 레벨4 존재할경우 

										String projectGroupObjectWhere = "attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev4 + "' ";
										String existLev5 = "";
										existLev5 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
									
										if (cdmStringUtil.isEmpty(existLev5)) {
											//레벨 5 존재하지 않을경우 
											Map requestArgLev5 = new HashMap();
											requestArgLev5.put("objectId", existLev4);
											requestArgLev5.put("Name", stProjectLev5);
											requestArgLev5.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
											requestArgLev5.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
											
											requestArgLev5.put("ProductNameObjectId", sProductNameObjectId);
											requestArgLev5.put("ProductTypeObjectId", sProductTypeObjectId);
											requestArgLev5.put("CustomerObjectId", sCustomerObjectId);
											requestArgLev5.put("VehicleObjectId", sVehicleObjectId);
											requestArgLev5.put("ProjectLeafId", stProject_Id);
											
											requestArgLev5.put("sCustomer",stCustomerAndLev4 );
			
											Map createLev5Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev5), Map.class);
											String createLev5Id = "";
											createLev5Id = (String) createLev5Map.get("id");
											if(cdmStringUtil.isEmpty(createLev5Id)){
												String sErrorMessage = "NOT CREATE PROJECT LEV5.";
												throw new Exception(sErrorMessage);
											}
		
										}
										//
										
									}
							} else {
								//lev3 존재하는 경우
								String projectGroupLev4Where = "attribute[cdmProjectCode] == '" + stCustomerAndLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
								
								String existLev4 = "";
								existLev4 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev4Where, "id", DUMP_DEFAULT);
								if(existLev4 == null){
									String errorMessage = "NOT EXIST PROEJCTGROUP LEV4 OBJECT OBJECT.";
									throw new Exception(errorMessage);
								}
								
								//레벨4 없을때 
								if (cdmStringUtil.isEmpty(existLev4)) {
									
									Map requestArgLev4 = new HashMap();
									requestArgLev4.put("objectId", existLev3);
									requestArgLev4.put("Title", stCustomerAndLev4);
									requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
									requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
									Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArgLev4), Map.class);
									
									String createLev4Id = (String) createLev4Map.get("id");
									if(cdmStringUtil.isEmpty(createLev4Id)){
										String errorMessage = "NOT CREATE LEVEL4(Customer) OBJECT.";
										throw new Exception(errorMessage);
									}
									
									String projectGroupObjectWhere = "attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev4Id + "' ";
									String existLev5 = "";
									existLev5 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
								
								
									if (cdmStringUtil.isEmpty(existLev5)) {
										
										Map requestArgLev5 = new HashMap();
										requestArgLev5.put("objectId", createLev4Id);
										requestArgLev5.put("Name", stProjectLev5);
										requestArgLev5.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
										requestArgLev5.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
										
										requestArgLev5.put("ProductNameObjectId", sProductNameObjectId);
										requestArgLev5.put("ProductTypeObjectId", sProductTypeObjectId);
										requestArgLev5.put("CustomerObjectId", sCustomerObjectId);
										requestArgLev5.put("VehicleObjectId", sVehicleObjectId);
										requestArgLev5.put("ProjectLeafId", stProject_Id);
										
										requestArgLev5.put("sCustomer",stCustomerAndLev4 );
		
										Map createLev5Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev5), Map.class);
										String createLev5Id = "";
										createLev5Id = (String) createLev5Map.get("id");
										if(cdmStringUtil.isEmpty(createLev5Id)){
											String sErrorMessage = "NOT CREATE PROJECT LEV5.";
											throw new Exception(sErrorMessage);
										}
	
									}
								}else{
									// 레벨4 존재할경우 

									String projectGroupObjectWhere = "attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev4 + "' ";
									String existLev5 = "";
									existLev5 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
								
									if (cdmStringUtil.isEmpty(existLev5)) {
										//레벨 5 존재하지 않을경우 
										Map requestArgLev5 = new HashMap();
										requestArgLev5.put("objectId", existLev4);
										requestArgLev5.put("Name", stProjectLev5);
										requestArgLev5.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
										requestArgLev5.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
										
										requestArgLev5.put("ProductNameObjectId", sProductNameObjectId);
										requestArgLev5.put("ProductTypeObjectId", sProductTypeObjectId);
										requestArgLev5.put("CustomerObjectId", sCustomerObjectId);
										requestArgLev5.put("VehicleObjectId", sVehicleObjectId);
										requestArgLev5.put("ProjectLeafId", stProject_Id);
										
										requestArgLev5.put("sCustomer",stCustomerAndLev4 );
		
										Map createLev5Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev5), Map.class);
										String createLev5Id = "";
										createLev5Id = (String) createLev5Map.get("id");
										if(cdmStringUtil.isEmpty(createLev5Id)){
											String sErrorMessage = "NOT CREATE PROJECT LEV5.";
											throw new Exception(sErrorMessage);
										}
	
									}
									
								}
							}
						} else { // lev 2 exist
//							String projectGroupLev3Where = "attribute[cdmProjectCode] == '" + stCustomerAndLev3 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev2 + "'";
							String projectGroupLev3Where = "attribute[cdmProjectCode] == '" + stProductNameAndLev3 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev2 + "'";
							String existLev3 = "";
							existLev3 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev3Where, "id", DUMP_DEFAULT);
						
							if(existLev3 == null){
								String errorMessage = "NOT EXIST PROEJCTGROUP LEV3 OBJECT.";
								throw new Exception(errorMessage);
							}
							if (cdmStringUtil.isEmpty(existLev3)) {
								// lev 3 not exist
								if (cdmStringUtil.isNotEmpty(stCustomerAndLev4)) {
									Map requestArgLev3 = new HashMap();
									requestArgLev3.put("objectId", existLev2);
									requestArgLev3.put("Title", stProductNameAndLev3);
									requestArgLev3.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
									requestArgLev3.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
		
									Map createLev3Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArgLev3), Map.class);
									String createLev3Id = (String) createLev3Map.get("id");
									if(cdmStringUtil.isEmpty(createLev3Id)){
										String errorMessage = "NOT CREATE LEVEL3 OBJECT.";
										throw new Exception(errorMessage);
									}
//									String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" +
//											sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" +
//											sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+
//											sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" +  createLev3Id+ "' ";
									
									String projectGroupLev4ObjectWhere = "attribute[cdmCommonCode] == '" + stCustomerAndLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" +  createLev3Id+ "' ";
									String existLev4 = "";
									existLev4 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev4ObjectWhere, "id", DUMP_DEFAULT);
									
									if(existLev4 == null){
										String errorMessage = "NOT EXIST PROEJCTGROUPOBJECT OBJECT.";
										throw new Exception(errorMessage);
									}
									
									if (cdmStringUtil.isEmpty(existLev4)) {
										//레벨4 존재하지않는 경우 
										Map requestArgLev4 = new HashMap();
										requestArgLev4.put("objectId", createLev3Id);
										requestArgLev4.put("Title", stCustomerAndLev4);
										requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
										requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
										Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArgLev4), Map.class);
										
										String createLev4Id = (String) createLev4Map.get("id");
										if(cdmStringUtil.isEmpty(createLev4Id)){
											String errorMessage = "NOT CREATE LEVEL4(Customer) OBJECT.";
											throw new Exception(errorMessage);
										}
										
//												
										String projectGroupObjectWhere = "attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev4Id + "' ";
										String existLev5 = "";
										existLev5 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
										if (cdmStringUtil.isEmpty(stProjectLev5)) {
											//레벨 5존재하지않는 경우	
											Map requestArgLev5 = new HashMap();
											requestArgLev5.put("objectId", createLev4Id);
											requestArgLev5.put("Name", stProjectLev5);
											requestArgLev5.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
											requestArgLev5.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
		
											requestArgLev5.put("ProductNameObjectId", sProductNameObjectId);
											requestArgLev5.put("ProductTypeObjectId", sProductTypeObjectId);
											requestArgLev5.put("CustomerObjectId", sCustomerObjectId);
											requestArgLev5.put("VehicleObjectId", sVehicleObjectId);
											requestArgLev5.put("ProjectLeafId",stProject_Id );
		
											requestArgLev5.put("sCustomer",stCustomerAndLev4 );
											Map createLev5Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev5), Map.class);
											String createLev5Id = (String) createLev5Map.get("id");
											if(cdmStringUtil.isEmpty(createLev4Id)){
												String sErrorMessage = (String) createLev5Map.get("errorMessage");
												
												String errorMessage = "NOT CREATE LEV5 PROJECT. " + sErrorMessage;
												throw new Exception(errorMessage);
											}
										}
									}else{
										//레벨4 존재하는 경우 
										String projectGroupObjectWhere = "attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev4 + "' ";
										String existLev5 = "";
										existLev5 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
										if (cdmStringUtil.isEmpty(stProjectLev5)) {
											//레벨 5존재하지않는 경우	
											Map requestArgLev5 = new HashMap();
											requestArgLev5.put("objectId", existLev4);
											requestArgLev5.put("Name", stProjectLev5);
											requestArgLev5.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
											requestArgLev5.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
		
											requestArgLev5.put("ProductNameObjectId", sProductNameObjectId);
											requestArgLev5.put("ProductTypeObjectId", sProductTypeObjectId);
											requestArgLev5.put("CustomerObjectId", sCustomerObjectId);
											requestArgLev5.put("VehicleObjectId", sVehicleObjectId);
											requestArgLev5.put("ProjectLeafId",stProject_Id );
		
											requestArgLev5.put("sCustomer",stCustomerAndLev4 );
											Map createLev5Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev5), Map.class);
											String createLev5Id = (String) createLev5Map.get("id");
											if(cdmStringUtil.isEmpty(createLev5Id)){
												String sErrorMessage = (String) createLev5Map.get("errorMessage");
												
												String errorMessage = "NOT CREATE LEV5 PROJECT. " + sErrorMessage;
												throw new Exception(errorMessage);
											}
										}
									}
								
							  } 
							}else {
								// lev3 exist
								//!!
								String projectGroupLev4ObjectWhere = "attribute[cdmCommonCode] == '" + stCustomerAndLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" +  existLev3+ "' ";
								String existLev4 = "";
								existLev4 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev4ObjectWhere, "id", DUMP_DEFAULT);
								
								if(existLev4 == null){
									String errorMessage = "NOT EXIST PROEJCTGROUPOBJECT OBJECT.";
									throw new Exception(errorMessage);
								}
								
								if (cdmStringUtil.isEmpty(existLev4)) {
									//레벨4 존재하지않는 경우 
									Map requestArgLev4 = new HashMap();
									requestArgLev4.put("objectId", existLev3);
									requestArgLev4.put("Title", stCustomerAndLev4);
									requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
									requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
									Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArgLev4), Map.class);
									
									String createLev4Id = (String) createLev4Map.get("id");
									if(cdmStringUtil.isEmpty(createLev4Id)){
										String errorMessage = "NOT CREATE LEVEL4(Customer) OBJECT.";
										throw new Exception(errorMessage);
									}
									
//											
									String projectGroupObjectWhere = "attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev4Id + "' ";
									String existLev5 = "";
									existLev5 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
									//
									//
									if (cdmStringUtil.isEmpty(stProjectLev5)) {
										//레벨 5존재하지않는 경우	
										Map requestArgLev5 = new HashMap();
										requestArgLev5.put("objectId", createLev4Id);
										requestArgLev5.put("Name", stProjectLev5);
										requestArgLev5.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
										requestArgLev5.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
	
										requestArgLev5.put("ProductNameObjectId", sProductNameObjectId);
										requestArgLev5.put("ProductTypeObjectId", sProductTypeObjectId);
										requestArgLev5.put("CustomerObjectId", sCustomerObjectId);
										requestArgLev5.put("VehicleObjectId", sVehicleObjectId);
										requestArgLev5.put("ProjectLeafId",stProject_Id );
	
										requestArgLev5.put("sCustomer",stCustomerAndLev4 );
										Map createLev5Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev5), Map.class);
										String createLev5Id = (String) createLev5Map.get("id");
										if(cdmStringUtil.isEmpty(createLev5Id)){
											String sErrorMessage = (String) createLev5Map.get("errorMessage");
											
											String errorMessage = "NOT CREATE LEV5 PROJECT. " + sErrorMessage;
											throw new Exception(errorMessage);
										}
									}
								}else{
									//레벨4 존재하는 경우 
									String projectGroupObjectWhere = "attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev4 + "' ";
									String existLev5 = "";
									existLev5 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
									//
									if (cdmStringUtil.isEmpty(stProjectLev5)) {
										//레벨 5존재하지않는 경우	
										Map requestArgLev5 = new HashMap();
										requestArgLev5.put("objectId", existLev4);
										requestArgLev5.put("Name", stProjectLev5);
										requestArgLev5.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
										requestArgLev5.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
	
										requestArgLev5.put("ProductNameObjectId", sProductNameObjectId);
										requestArgLev5.put("ProductTypeObjectId", sProductTypeObjectId);
										requestArgLev5.put("CustomerObjectId", sCustomerObjectId);
										requestArgLev5.put("VehicleObjectId", sVehicleObjectId);
										requestArgLev5.put("ProjectLeafId",stProject_Id );
	
										requestArgLev5.put("sCustomer",stCustomerAndLev4 );
										Map createLev5Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev5), Map.class);
										String createLev5Id = (String) createLev5Map.get("id");
										if(cdmStringUtil.isEmpty(createLev5Id)){
											String sErrorMessage = (String) createLev5Map.get("errorMessage");
											
											String errorMessage = "NOT CREATE LEV5 PROJECT. " + sErrorMessage;
											throw new Exception(errorMessage);
										}
									}
								}
	
								
							}
		
						}
						
						successObjectCount ++;
						if(cdmStringUtil.isNotEmpty(sbErrorData.toString())){
							multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. LINE NUMBER: \t " + sPhysicalNumberRows +"\t  CreateProjectLev5: \t "+stProjectLev5 +"\t  CreateProjectLev4: \t"+ stCustomerAndLev4+" \t CreateProjectLev3 : \t "+stProductNameAndLev3 +"\t CreateProjectLev2:\t"+" Error \t"+sbErrorData.toString());
						}else{
							multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. LINE NUMBER: \t " + sPhysicalNumberRows +" \t  CreateProjectLev5: \t "+stProjectLev5 +"\t CreateProjectLev4:"+stCustomerAndLev4+" \t  CreateProjectLev3: \t"+stProductNameAndLev3 +"\t CreateProjectLev2: \t "+stLev2+"\t  | ");
						}
					}else{
						String errorMessage = "NOT EXIST NECESSARY DATA";
						throw new Exception(errorMessage);
					}
//					ContextUtil.abortTransaction(context);
					ContextUtil.commitTransaction(context);
				}catch(Exception e1){
					failObjectCount++;
					ContextUtil.abortTransaction(context);
					multiWriteMessageToFile(failedObjectidWriter, "LINE NUMBER: \t" + sPhysicalNumberRows+"\t EXCEPTION: \t" + e1.getMessage() );
					mulitWriteErrorToFile(errorStream, "LINE NUMBER: \t" + sPhysicalNumberRows + " \t EXCEPTION: \t" + e1.getMessage());
					e1.printStackTrace(errorStream);
				}
			}
			
			
		}catch(Exception e2){
			mulitWriteErrorToFile(errorStream, "LINE NUMBER: " + sPhysicalNumberRows + " \t EXCEPTION:" + e2.getMessage());
			e2.printStackTrace(errorStream);
		
		}finally{
			multiWriteMessageToFile(logWriter, "==================================================================================== ");
			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, " Total Count:("+totalObjectCont +")   FAIL COUNT : ("+failObjectCount+")    SUCCESS COUNT : ("+successObjectCount+")    LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms             ");
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

			System.out.println("cdmCommonCodeMigration : addProjectGroupAndProject --> end." +cdmCommonExcel.getTimeStamp2() );
		}
	
		
	}
	
	
	/**
	 * workspace namw 중복으로 인해 생성되지 못한 workspace 데이타들을 생성하고 project에 연결하는 작업 
	 * 이부분은 18일 이후에는 사용되지 않을예정 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void workpsaceCreateAndCreate(Context context,String args[])throws Exception{
		final HttpSession HttpServletRequest = null;
		System.out.println("cdmCommonCodeMigration : workpsaceCreateAndCreate --> start." +cdmCommonExcel.getTimeStamp2() );
		long startTime = System.currentTimeMillis();
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
//		Map paramMap = JPO.unpackArgs(args);
//		String tempFileAndLocation = (String)paramMap.get("File");
		
		if(args.length != 1){
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		String tempFileAndLocation = args[0];
		String commonCodeFilePath = "";
		String commonCodeFileName = "";
		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
		
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명
		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
		if (sTempArgs.length!=2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory  = sTempArgs[0];
		fileName		= sTempArgs[1];
		//로그 default 명 
		String logFileName 	= "workpsaceCreateAndCreate";

		//읽을 메인 시트명
		String sheetName 	= "ProjectAllList_NotWorspace";
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + FILE_SEPARATOR;
		}
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + FILE_SEPARATOR + OUTPUT_DIRECTORY + FILE_SEPARATOR + logFileName + FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		
		//
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;

		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"Workspace MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		int successObjectCount     = 0;
		int failObjectCount 	   = 0;
		String sPhysicalNumberRows = "";
		int totalObjectCont        = 0;
		//
		try {
			XSSFSheet sheet1 = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet1.getPhysicalNumberOfRows();
			totalObjectCont = physicalNumberRows-2;
			
			//
			
			for (int i = 2; i < physicalNumberRows; i++) {
				StringBuffer sbErrorData = new StringBuffer(""); 
				try{
					XSSFRow row = sheet1.getRow(i);
					sPhysicalNumberRows = String.valueOf(i+1);
					
					if (row == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL) \t 1";
						throw new Exception(errorMessage);
					}
					
					
					XSSFCell cell_0 = row.getCell(0);// 순번
					XSSFCell cell_1 = row.getCell(1);// TDMX_ID
					XSSFCell cell_2 = row.getCell(2);// TDM_DESCRIPTION
					XSSFCell cell_4 = row.getCell(4);// PROD_Type
					XSSFCell cell_5 = row.getCell(5);// PROD_Name
					XSSFCell cell_6 = row.getCell(6);// TDMX_CUSTOMER
					XSSFCell cell_7 = row.getCell(7);// CN_VEHICLE
					
					if (cell_5 != null && cell_2 != null && cell_7 != null && cell_6 != null && cell_4 != null) {
						String stNumber                 = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_0));
						String stProject_Id             = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_1));
						String stLev4 				    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_2));
						String stProductType 		    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_4));
						String stProductNameAndLev2     = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_5));
						String stCustomerAndLev3 	    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_6));
						String stVehicle 			    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_7));
						
						String strName = stLev4 ;
						String findProjectObj = "temp query bus $1 $2 $3 where $4 select $5 dump $6";
						String wherefindProject = "attribute[cdmProjectObjectIdM] =='"+stProject_Id+"'";
						String sFindMqlProject = MqlUtil.mqlCommand(context, findProjectObj, true, new String[] { "cdmProjectGroupObject", "*", "*", wherefindProject,"id" ,"|"});
						
						StringList sListFindProject = new StringList();
						sListFindProject = FrameworkUtil.split(sFindMqlProject, "|");
						String strProjectObjectId = "";
						if(sListFindProject.size()>2){
							strProjectObjectId = (String)sListFindProject.get(3);
						}
						
						int number = Integer.parseInt(stNumber);
			
						String sProjectDiv = "";
						String sArrayTempVehicle = "";
						String sOrg = "";
						String[] sArrayName = strName.split("-");
						if(sArrayName.length == 2 ){
						 sProjectDiv = ((String)sArrayName[0].trim());
						 sArrayTempVehicle = ((String)sArrayName[1].trim());
						 sOrg = stCustomerAndLev3 +" - "+sArrayTempVehicle;
						}
						ContextUtil.startTransaction(context, true);
						Workspace WorkspaceObj = (Workspace) DomainObject.newInstance(context, DomainConstants.TYPE_WORKSPACE, DomainConstants.TEAM);
						String strWorkspaceObjectId = "";
						// Workspace Create
						strWorkspaceObjectId = TeamUtil.autoRevision(context, HttpServletRequest, WorkspaceObj.TYPE_PROJECT, strName, WorkspaceObj.POLICY_PROJECT, context.getVault().getName());
						WorkspaceObj.setId(strProjectObjectId);
						WorkspaceObj.setDescription(context, strName);
						boolean checkOwner = false;
						boolean checkOrg = false;
						boolean checkProject = false;
						String sOwner = "";
						String findOrg = "list role $1 select $2 dump;";
						if (cdmStringUtil.isNotEmpty(sOrg) && cdmStringUtil.isNotEmpty(sProjectDiv)) {
							String str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sOrg, "isanorg" });
							if ("TRUE".equalsIgnoreCase(str2)) {
								findOrg = "list role $1 select $2 dump;";
								str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sProjectDiv, "isaproject" });
								if ("TRUE".equalsIgnoreCase(str2)) {
									checkOrg = true;
									checkProject = true;
								}
							}
						}
					WorkspaceObj.setOwnership(context, checkOwner, checkOrg, checkProject, sOwner, sOrg, sProjectDiv);
					WorkspaceObj.update(context);
		//			// Workspace - Project Connection
					DomainRelationship.connect(context, new DomainObject(strProjectObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_WORKSPACE, new DomainObject(strWorkspaceObjectId));
					
					ContextUtil.commitTransaction(context);
					}
				}catch(Exception e1){
					ContextUtil.abortTransaction(context);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			multiWriteMessageToFile(logWriter, "==================================================================================== ");
			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, " Total Count:("+totalObjectCont +")   FAIL COUNT : ("+failObjectCount+")    SUCCESS COUNT : ("+successObjectCount+")    LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms             ");
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

			System.out.println("cdmCommonCodeMigration : addProjectGroupAndProject --> end." +cdmCommonExcel.getTimeStamp2() );
		}
	}
	
	public void projOrgConnect(Context context,String args[])throws Exception{

		final HttpSession HttpServletRequest = null;
		System.out.println("cdmCommonCodeMigration : workpsaceCreateAndCreate --> start." +cdmCommonExcel.getTimeStamp2() );
		long startTime = System.currentTimeMillis();
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
//		Map paramMap = JPO.unpackArgs(args);
//		String tempFileAndLocation = (String)paramMap.get("File");
		
		if(args.length != 1){
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		String tempFileAndLocation = args[0];
		String commonCodeFilePath = "";
		String commonCodeFileName = "";
		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
		
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명
		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
		if (sTempArgs.length!=2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory  = sTempArgs[0];
		fileName		= sTempArgs[1];
		//로그 default 명 
		String logFileName 	= "Project";

		//읽을 메인 시트명
//		String sheetName 	= "ProjectAllList_NotWorspace";
		String sheetName 	= "Project";
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + FILE_SEPARATOR;
		}
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + FILE_SEPARATOR + OUTPUT_DIRECTORY + FILE_SEPARATOR + logFileName + FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		
		//
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;

		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"Workspace MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		int successObjectCount     = 0;
		int failObjectCount 	   = 0;
		String sPhysicalNumberRows = "";
		int totalObjectCont        = 0;
		//
		try {
			XSSFSheet sheet1 = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet1.getPhysicalNumberOfRows();
			totalObjectCont = physicalNumberRows-2;
			
			//
			
			for (int i = 2; i < physicalNumberRows; i++) {
				StringBuffer sbErrorData = new StringBuffer(""); 
				try{
					XSSFRow row = sheet1.getRow(i);
					sPhysicalNumberRows = String.valueOf(i+1);
					
					if (row == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL) \t 1";
						throw new Exception(errorMessage);
					}
					
					
					XSSFCell cell_0 = row.getCell(0);// 순번
					XSSFCell cell_1 = row.getCell(1);// TDMX_ID
					XSSFCell cell_2 = row.getCell(2);// TDM_DESCRIPTION
					XSSFCell cell_4 = row.getCell(4);// PROD_Type
					XSSFCell cell_5 = row.getCell(5);// PROD_Name
					XSSFCell cell_6 = row.getCell(6);// TDMX_CUSTOMER
					XSSFCell cell_7 = row.getCell(7);// CN_VEHICLE
					
					if (cell_5 != null && cell_2 != null && cell_7 != null && cell_6 != null && cell_4 != null) {
						String stNumber                 = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_0));
						String stProject_Id             = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_1));
						String stLev4 				    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_2));
						String stProductType 		    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_4));
						String stProductNameAndLev2     = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_5));
						String stCustomerAndLev3 	    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_6));
						String stVehicle 			    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_7));
						
						if("PRJ-0000961".equals(stProject_Id) || "PRJ-0000933".equals(stProject_Id)){
							continue;
						}
					
						String strName = stLev4 ;
						String findProjectObj = "temp query bus $1 $2 $3 where $4 select $5 $6 dump $7";
						String inputData = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_WORKSPACE+"].to.id"; 
						String wherefindProject = "attribute[cdmProjectObjectIdM] =='"+stProject_Id+"'";
//						String sFindMqlProject = MqlUtil.mqlCommand(context, findProjectObj, true, new String[] { "cdmProjectGroupObject", "*", "*", wherefindProject,"id" ,"|"});
						String sFindMqlProject = MqlUtil.mqlCommand(context, findProjectObj, true, new String[] { "cdmProjectGroupObject", "*", "*", wherefindProject,"id",inputData ,"|"});
						
						
						StringList sListFindProject = new StringList();
						sListFindProject = FrameworkUtil.split(sFindMqlProject, "|");
						String workspaceId = "";
						String projectId = "";
						if(sListFindProject.size()>2){
							projectId = (String)sListFindProject.get(3);
							workspaceId = (String)sListFindProject.get(4);
						}
						
						
						int number = Integer.parseInt(stNumber);
			
						String sProjectDiv = "";
						String sArrayTempVehicle = "";
						String sOrg = "";
						String[] sArrayName = strName.split("-");
						if(sArrayName.length == 2 ){
						 sProjectDiv = ((String)sArrayName[0].trim());
						 sArrayTempVehicle = ((String)sArrayName[1].trim());
						 sOrg = stCustomerAndLev3 +" - "+sArrayTempVehicle;
						}
						ContextUtil.startTransaction(context, true);
						String strWorkspaceObjectId = "";
						
						DomainObject projectDobj = new DomainObject();
						projectDobj.setId(projectId);
						
						DomainObject workspaceDobj = new DomainObject();
						workspaceDobj.setId(workspaceId);
						boolean checkOwner = false;
						boolean checkOrg = false;
						boolean checkProject = false;
						String sOwner = "";
						String findOrg = "list role $1 select $2 dump;";
						if (cdmStringUtil.isNotEmpty(sOrg) && cdmStringUtil.isNotEmpty(sProjectDiv)) {
							String str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sOrg, "isanorg" });
							if ("TRUE".equalsIgnoreCase(str2)) {
								findOrg = "list role $1 select $2 dump;";
								str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sProjectDiv, "isaproject" });
								if ("TRUE".equalsIgnoreCase(str2)) {
									checkOrg = true;
									checkProject = true;
								}
							}
						}
						projectDobj.setOwnership(context, checkOwner, checkOrg, checkProject, sOwner, sOrg, sProjectDiv);
						projectDobj.update(context);
						
						workspaceDobj.setOwnership(context, checkOwner, checkOrg, checkProject, sOwner, sOrg, sProjectDiv);
						workspaceDobj.update(context);
		//			// Workspace - Project Connection
//					DomainRelationship.connect(context, new DomainObject(strProjectObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_WORKSPACE, new DomainObject(strWorkspaceObjectId));
					
					ContextUtil.commitTransaction(context);
					}
				}catch(Exception e1){
					ContextUtil.abortTransaction(context);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}finally{
			multiWriteMessageToFile(logWriter, "==================================================================================== ");
			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, " Total Count:("+totalObjectCont +")   FAIL COUNT : ("+failObjectCount+")    SUCCESS COUNT : ("+successObjectCount+")    LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms             ");
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

			System.out.println("cdmCommonCodeMigration : addProjectGroupAndProject --> end." +cdmCommonExcel.getTimeStamp2() );
		}
	
	}
	
//	/**
//	 * 0109 lev2 변경요청으로인한 lev2 object 생성 
//	 * level 2 을위한 Product div 생성
//	 * 
//	 * @param context
//	 * @param args
//	 * @throws Exception
//	 */
//	public void connectLev2Add(Context context,String args[])throws Exception{
//
//		
//		System.out.println("cdmCommonCodeMigration : connectLev2Add --> start." +cdmCommonExcel.getTimeStamp2() );
//		long startTime = System.currentTimeMillis();
//		
//		String inputDirectory 			     = "";
//		String outputDirectory 			     = "";
//		String fileName 		       	     = "";
//		
//		PrintStream errorStream		         = null; 
//		File successLogFile 				 = null; 
//		File failedLogFile 				     = null;
//		
//		BufferedWriter logWriter 			 = null; 
//		BufferedWriter successObjectidWriter = null; 
//		BufferedWriter failedObjectidWriter  = null; 
//		
////		Map paramMap = (HashMap)JPO.unpackArgs(args);
////		String commonCodeFilePath = (String)paramMap.get("File_Location");
////		String commonCodeFileName = (String)paramMap.get("File");
////		if(cdmStringUtil.isEmpty(commonCodeFilePath) || cdmStringUtil.isEmpty(commonCodeFileName)){
////			String errorMessage = "The file to read does not exist.";
////			throw new Exception(errorMessage);
////		}
//		
//		if(args.length != 1){
//			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//		}
//		String tempFileAndLocation = args[0];
//		String commonCodeFilePath = "";
//		String commonCodeFileName = "";
//		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
//		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
//		
//		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명
////		String[] sTempArgs = {S_COMMONCODE_EXCEL_PATH,S_COMMONCODE_EXCEL_PATH_NAME};
//		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
//		if (sTempArgs.length!=2) {
//			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//		}
//		
//		inputDirectory  = sTempArgs[0];
//		fileName		= sTempArgs[1];
//		//로그 default 명 
//		String logFileName 	= "connectLev2";
//
//		//읽을 메인 시트명
//		String sheetName 	= S_PROJECT_SHEET_NAME;
//		
//		// documentDirectory does not ends with "/" add it
//		if (inputDirectory != null && !inputDirectory.endsWith(FILE_SEPARATOR)) {
//			inputDirectory = inputDirectory + FILE_SEPARATOR;
//		}
//		
//		// create a directory to add debug and error logs
//		outputDirectory = new File(inputDirectory).getParentFile() + FILE_SEPARATOR + OUTPUT_DIRECTORY + FILE_SEPARATOR + logFileName + "_" + cdmCommonExcel.getTimeStamp() + FILE_SEPARATOR;
//		File fileOutputDirectory = new File(outputDirectory);
//		if (!fileOutputDirectory.isDirectory()) {
//			fileOutputDirectory.mkdirs();
//		}
//		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
//		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));
//
//		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
//		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));
//
//		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
//		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
//		
//		multiWriteMessageToFile(logWriter,"====================================================================================");
//		multiWriteMessageToFile(logWriter,"     PROJECT MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
//		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory+fileName);
//		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
//		multiWriteMessageToFile(logWriter,"====================================================================================\n");
//		
//		int successObjectCount     = 0;
//		int failObjectCount 	   = 0;
//		String sPhysicalNumberRows = "";
//		int totalObjectCont        = 0;
//		try{
//			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
//			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
//			totalObjectCont = physicalNumberRows-2;
//			
//			// project find start 
//			String   sWhere 		 = "";
//			String   sSelect		 = "id";
//			
//			//type,name,revision,where,select,dump
//			String   stProjectTreeId = "";
//			stProjectTreeId = (String)getOnlySearchBus(context,S_SUBPROJECT_GROUP_TYPE, S_PROJECT_TOP_OBJECT_NAME, QUERY_WILDCARD,sWhere,sSelect,DUMP_DEFAULT);
//			 
//			
//			if(cdmStringUtil.isEmpty(stProjectTreeId)){
//				DomainObject dProjectTree = new DomainObject();
//				
//				dProjectTree.createObject(context, S_SUBPROJECT_GROUP_TYPE, S_PROJECT_TOP_OBJECT_NAME, "-", "cdmProjectGroupPolicy", cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//				stProjectTreeId = (String)dProjectTree.getId(context);
//			}
//			
//			HashMap<String,String> tempCommonCodeHm = new HashMap<String,String>();
//			HashMap<String,String> commonCodeHm = new HashMap<String,String>();
//			tempCommonCodeHm.put("commonCodeVehicleIdLev2"      , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Vehicle' \"" );
//			tempCommonCodeHm.put("commonCodeProductGroupIdLev2" , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Product Group Name'\" " );
//			tempCommonCodeHm.put("commonCodeProductDivIdLev2"   , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Product Div'  \"" );
//			tempCommonCodeHm.put("commonCodeCustomerIdLev2"   , " \"to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot' && attribute[cdmCommonCode] == 'Customer'  \"" );
//			
//			for (Iterator iterator = tempCommonCodeHm.keySet().iterator(); iterator.hasNext();) {
//				
//				String stCommonCodeKey = (String) iterator.next();
//				String stCommonCodeValue= (String)tempCommonCodeHm.get(stCommonCodeKey);
//				String stCommonCodeMql = MqlUtil.mqlCommand(context, "temp query bus cdmCommonCode * * where "+stCommonCodeValue+" select id dump | ");
//				
//				StringList commonCodeMqlResult = FrameworkUtil.split(stCommonCodeMql, "|");
//				String stLev2CommonCode = "";
//				
//				if(commonCodeMqlResult.size() >2 ){
//					stLev2CommonCode = (String)commonCodeMqlResult.get(3);
//					commonCodeHm.put(stCommonCodeKey, stLev2CommonCode);
//				}else{
//					String errorMessage = "NOT EXIST COMMONCODE OBJECT.";
//					throw new Exception(errorMessage);
//				}
//			}
//			String tempLev2CommonCodeVehicleId     	 = (String)commonCodeHm.get("commonCodeVehicleIdLev2");
//			String tempLev2CommonCodeProductGroupId  = (String)commonCodeHm.get("commonCodeProductGroupIdLev2");
//			String tempLev2CommonCodeProductTypeId 	 = (String)commonCodeHm.get("commonCodeProductDivIdLev2");
//			String tempLev2CommonCodeCustomerId      = (String)commonCodeHm.get("commonCodeCustomerIdLev2");
//			
//			StringBuffer sbCommonCodeLv2BusWhere = new StringBuffer();
//			sbCommonCodeLv2BusWhere.append("to[cdmProjectGroupObjectTypeRelationShip].from.name == 'Project Tree' ");
//			StringList commonCodeLv2BusSelect = new StringList();
//			commonCodeLv2BusSelect.add("id");
//			commonCodeLv2BusSelect.add("attribute[cdmProjectCode]");
//			
//			MapList lev2ProductDivMpList = DomainObject.findObjects(context, 
//										"cdmCommonCode", 
//										cdmConstantsUtil.QUERY_WILDCARD,
//										cdmConstantsUtil.QUERY_WILDCARD,
//										"*",
//										"*",
//										sbCommonCodeLv2BusWhere.toString(),
//										true,
//										commonCodeLv2BusSelect );
//			
//			Map commonCodeMap = new HashMap();
//			for (Iterator iterProductDiv = lev2ProductDivMpList.iterator(); iterProductDiv.hasNext();) {
//				Map	productDivMap = (Map) iterProductDiv.next();
//				String commonCodeId = (String)productDivMap.get("id");
//				String commonCodeAttr = (String)productDivMap.get("attribute[cdmProjectCode]");
//				
//				commonCodeMap.put(commonCodeAttr, commonCodeId);
//				
//				DomainObject dObj = new DomainObject();
//				dObj.setId(commonCodeId);
//				
//			}
//			
//			/*데이타는 ROW 3줄 부터 시작*/
//			for (int i = 2; i < physicalNumberRows; i++) {
//				StringBuffer sbErrorData = new StringBuffer(""); 
//				try{
//					XSSFRow row = sheet.getRow(i);
//					sPhysicalNumberRows = String.valueOf(i+1);
//					
//					if (row == null){
//						String errorMessage = "NOT EXIST DATA (ROW NULL) \t 1";
//						throw new Exception(errorMessage);
//					}
//					
//					
//					XSSFCell cell_0 = row.getCell(0);// 순번
//					XSSFCell cell_1 = row.getCell(1);// TDMX_ID
//					XSSFCell cell_2 = row.getCell(2);// TDM_DESCRIPTION
//					XSSFCell cell_4 = row.getCell(4);// PROD_Type
//					XSSFCell cell_5 = row.getCell(5);// PROD_Name
//					XSSFCell cell_6 = row.getCell(6);// TDMX_CUSTOMER
//					XSSFCell cell_7 = row.getCell(7);// CN_VEHICLE
//					
//					if (cell_5 != null && cell_2 != null && cell_7 != null && cell_6 != null && cell_4 != null) {
//						String stNumber                 = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_0));
//						String stProject_Id             = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_1));
//						String stLev4 				    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_2));
//						String stProductType 		    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_4));
//						String stProductNameAndLev2     = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_5));
//						String stCustomerAndLev3 	    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_6));
//						String stVehicle 			    = cdmCommonExcel.isVaildNullData((String)cdmCommonExcel.getCellValue(cell_7));
//						
//						
//						int number = Integer.parseInt(stNumber);
//						
//						if(cdmStringUtil.isEmpty(stLev4)){
//							sbErrorData.append("NOT EXIST DATA. (CELL_2 EMPTY): " );
//							sbErrorData.append(stLev4);
//							sbErrorData.append("\t");
//						}
//						if(cdmStringUtil.isEmpty(stProductType)){
//							sbErrorData.append("NOT EXIST DATA. (CELL_4 EMPTY): ");
//							sbErrorData.append(stProductType);
//							sbErrorData.append("\t");
//						}
//						if(cdmStringUtil.isEmpty(stProductNameAndLev2)){
//							sbErrorData.append("NOT EXIST DATA. (CELL_5 EMPTY): ");
//							sbErrorData.append(stProductNameAndLev2);
//							sbErrorData.append("\t");
//						}
//						if(cdmStringUtil.isEmpty(stCustomerAndLev3)){
//							sbErrorData.append("NOT EXIST DATA. (CELL_6 EMPTY)");
//							sbErrorData.append(stCustomerAndLev3);
//							sbErrorData.append("\t");
//						}
//						
//						String sProductNameObjectId = "";
//						String sProductTypeObjectId = "";
//						String sCustomerObjectId 	= "";
//						String sVehicleObjectId 	= "";
//
//						// Product Group
//						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeProductGroupId)) {
//							String productGroupIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stProductNameAndLev2 + "' && attribute[cdmCommonTemp2]=='" + stProductType + "' \" dump |";
//							sProductNameObjectId = expandCommonCodeMql(context, tempLev2CommonCodeProductGroupId, productGroupIddWhere, "S");
//	
//						}
//	
//						/* Product Type */
//						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeProductTypeId) ) {
//							String productDivIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stProductType + "' \" dump |";
//							sProductTypeObjectId = expandCommonCodeMql(context, tempLev2CommonCodeProductTypeId, productDivIddWhere, "S");
//	
//						}
//						
//						/* CUSTOMER */
//						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeCustomerId) ) {
//							String productCustomerIdWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCode] == '" + stCustomerAndLev3 + "' \" dump |";
//							sCustomerObjectId = expandCommonCodeMql(context, tempLev2CommonCodeCustomerId, productCustomerIdWhere, "S");
//						}
//						
//						/* VEHICLE */
//						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeVehicleId) ) {
//							String productVehicleIdWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCode]=='" + stVehicle + "' && to[cdmCommonCodeRelationship].from.attribute[cdmCommonCode]=='"+stCustomerAndLev3+ "' \" dump |";
//							sVehicleObjectId = expandCommonCodeMql(context, tempLev2CommonCodeVehicleId, productVehicleIdWhere, "S");
//						}
//
//						
//						if(cdmStringUtil.isEmpty(sVehicleObjectId)) {
//							sbErrorData.append("NOT EXIST COMMOMCODE(Vehicle) :");
//							sbErrorData.append("Vehicle -Attribute[CommonCode] :");
//							sbErrorData.append(stVehicle);
//							sbErrorData.append(" | Vehicle -to[].from.Attribute[CommonCode] :");
//							sbErrorData.append(stCustomerAndLev3);
//							sbErrorData.append("\t");
//						}
//						
//						if(cdmStringUtil.isEmpty(sCustomerObjectId)) {
//							
//							sbErrorData.append("NOT EXIST COMMOMCODE(Customer) :");
//							sbErrorData.append("Customer -Attribute[CommonCode] :");
//							sbErrorData.append(stCustomerAndLev3);
//							sbErrorData.append("\t");
//							
//						}
//						
//						if(cdmStringUtil.isEmpty(sProductTypeObjectId)) {
//							
//							sbErrorData.append("NOT EXIST COMMOMCODE(Product Type) :");
//							sbErrorData.append("Product Type -Attribute[cdmCommonCodeNameEn] :");
//							sbErrorData.append(stProductType);
//							sbErrorData.append("\t");
//						}
//						
//						if(cdmStringUtil.isEmpty(sProductNameObjectId)) {
//							
//							sbErrorData.append("NOT EXIST COMMOMCODE(Product Name) :");
//							sbErrorData.append("Product Name -Attribute[cdmCommonCodeNameEn] :");
//							sbErrorData.append(stProductNameAndLev2);
//							sbErrorData.append(" | attribute[cdmCommonTemp2] :");
//							sbErrorData.append(stProductType);
//							sbErrorData.append("\t");
//						}
//						
//						
//						String projectGroupWhere = "attribute[cdmProjectCode] == '" + stProductNameAndLev2 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + stProjectTreeId + "' ";
//						
//						String existLev2 = "";
//						existLev2 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupWhere, "id", DUMP_DEFAULT);
//						
//						if(existLev2 ==null){
//							String errorMessage = "NOT EXIST PROEJCT GROUP LEV2 OBJECT.";
//							throw new Exception(errorMessage);
//						}
//						
////						ContextUtil.startTransaction(context, true);
//						if (cdmStringUtil.isEmpty(existLev2)) {
//							
//							
//							Map requestArg = new HashMap();
//							requestArg.put("objectId", stProjectTreeId);
//							requestArg.put("Title", stProductNameAndLev2);
//							requestArg.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
//							requestArg.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
//		
////							Map createLev2Map = (Map) JPO.invoke(context, "cdmProjectGroup", null, "createProjectGroup", JPO.packArgs(requestArg), Map.class);
//							Map createLev2Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArg), Map.class);
//							String createLev2Id = (String) createLev2Map.get("id");
//							if(cdmStringUtil.isEmpty(createLev2Id)){
//								String errorMessage = "NOT CREATE LEVEL2 OBJECT.";
//								throw new Exception(errorMessage);
//							}
//		
//							String projectGroupLev3Where = "attribute[cdmProjectCode] == '" + stCustomerAndLev3 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev2Id + "' ";
////							String existLev3 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP, "", "", "", "", projectGroupLev3Where, selectList);
//							String existLev3 = "";
//							existLev3 		 = getOnlySearchBus(context,S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev3Where, "id", DUMP_DEFAULT);
//							
//							if(existLev3 == null){
//								String errorMessage = "NOT EXIST PROEJCT GROUP LEV3 OBJECT.";
//								throw new Exception(errorMessage);
//							}
//							
//							if (cdmStringUtil.isEmpty(existLev3)) {
//								// lev 3 not exist
//								Map requestArgLev3 = new HashMap();
//								requestArgLev3.put("objectId", createLev2Id);
//								requestArgLev3.put("Title", stCustomerAndLev3);
//								requestArgLev3.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
//								requestArgLev3.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
//								
////								
//								Map createLev3Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArgLev3), Map.class);
//								String createLev3Id = (String) createLev3Map.get("id");
//								if(cdmStringUtil.isEmpty(createLev3Id)){
//									String errorMessage = "NOT CREATE LEVEL3 OBJECT.";
//									throw new Exception(errorMessage);
//								}	
//								
////								String projectGroupObjectWhere = "attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE + "] == '" + stProductType + "'  && attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_VEHICLE_ATTRIBUTE + "] == '" + stVehicle + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev3Id + "' ";
////								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev3Id + "' ";
//								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev3Id + "' ";
////								String existLev4 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, "", "", "", "", projectGroupObjectWhere, selectList);
//								String existLev4 = "";
//								existLev4 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
//								if(existLev4 == null){
//									String errorMessage = "NOT EXIST PROEJCTGROUP OBJECT OBJECT.";
//									throw new Exception(errorMessage);
//								}
//								
//								if (cdmStringUtil.isEmpty(existLev4)) {
//									if (cdmStringUtil.isNotEmpty(stLev4)) {
//										Map requestArgLev4 = new HashMap();
//										requestArgLev4.put("objectId", createLev3Id);
//										requestArgLev4.put("Name", stLev4);
//										requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
//										requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
//										
////										requestArgLev4.put("Customer", stCustomerAndLev3);
////										requestArgLev4.put("ProductType", stProductType);
////										requestArgLev4.put("ProductName", stProductNameAndLev2);
////										requestArgLev4.put("Vehicle", stVehicle);
//										requestArgLev4.put("ProductNameObjectId", sProductNameObjectId);
//										requestArgLev4.put("ProductTypeObjectId", sProductTypeObjectId);
//										requestArgLev4.put("CustomerObjectId", sCustomerObjectId);
//										requestArgLev4.put("VehicleObjectId", sVehicleObjectId);
//										requestArgLev4.put("ProjectLeafId", stProject_Id);
//										
//										requestArgLev4.put("sCustomer",stCustomerAndLev3 );
//		
////										Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "cdmProjectGroupCreate", JPO.packArgs(requestArgLev4), Map.class);
//										Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
//										String createLev4Id = "";
//										createLev4Id = (String) createLev4Map.get("id");
//										if(cdmStringUtil.isEmpty(createLev4Id)){
//											String sErrorMessage = "NOT CREATE PROJECT LEV4.";
//											throw new Exception(sErrorMessage);
//										}
//		
//									}
//								}
//							} else {
//									
////									String projectGroupObjectWhere = "attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE + "] == '" + stProductType + "'  && attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_VEHICLE_ATTRIBUTE + "] == '" + stVehicle + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
//									String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
////									String existLev4 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, "", "", "", "", projectGroupObjectWhere, selectList);
//									String existLev4 = "";
//									existLev4 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
//									
//									if(existLev4 == null){
//										String errorMessage = "NOT EXIST PROEJCTGROUPOBJECT OBJECT.";
//										throw new Exception(errorMessage);
//									}
//									if (cdmStringUtil.isEmpty(existLev4)) {
//										if (cdmStringUtil.isNotEmpty(stLev4)) {
//											Map requestArgLev4 = new HashMap();
//											requestArgLev4.put("objectId", existLev3);
//											requestArgLev4.put("Name", stLev4);
//											requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
//											requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
//		
////											requestArgLev4.put("Customer", stCustomerAndLev3);
////											requestArgLev4.put("ProductType", stProductType);
////											requestArgLev4.put("ProductName", stProductNameAndLev2);
////											requestArgLev4.put("Vehicle", stVehicle);
//											requestArgLev4.put("ProductNameObjectId", sProductNameObjectId);
//											requestArgLev4.put("ProductTypeObjectId", sProductTypeObjectId);
//											requestArgLev4.put("CustomerObjectId", sCustomerObjectId);
//											requestArgLev4.put("VehicleObjectId", sVehicleObjectId);
//											requestArgLev4.put("ProjectLeafId",stProject_Id );
//		
//											requestArgLev4.put("sCustomer",stCustomerAndLev3 );
////											Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "cdmProjectGroupCreate", JPO.packArgs(requestArgLev4), Map.class);
//											Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
//											String createLev4Id = (String) createLev4Map.get("id");
//		
//										}
//									}
//								}
//						} else { // lev 2 exist
//							String projectGroupLev3Where = "attribute[cdmProjectCode] == '" + stCustomerAndLev3 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev2 + "'";
////							String existLev3 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP, "", "", "", "", projectGroupLev3Where, selectList);
//							String existLev3 = "";
//							existLev3 = getOnlySearchBus(context, S_SUBPROJECT_GROUP_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupLev3Where, "id", DUMP_DEFAULT);
//						
//							if(existLev3 == null){
//								String errorMessage = "NOT EXIST PROEJCTGROUP OBJECT.";
//								throw new Exception(errorMessage);
//							}
//							if (cdmStringUtil.isEmpty(existLev3)) {
//								// lev 3 not exist
//								if (cdmStringUtil.isNotEmpty(stCustomerAndLev3)) {
//									Map requestArgLev3 = new HashMap();
//									requestArgLev3.put("objectId", existLev2);
//									requestArgLev3.put("Title", stCustomerAndLev3);
//									requestArgLev3.put("TypeActual", cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP);
//									requestArgLev3.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
//		
//									Map createLev3Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProjectGroup", JPO.packArgs(requestArgLev3), Map.class);
//									String createLev3Id = (String) createLev3Map.get("id");
//									if(cdmStringUtil.isEmpty(createLev3Id)){
//										String errorMessage = "NOT CREATE LEVEL3 OBJECT.";
//										throw new Exception(errorMessage);
//									}
////									String projectGroupObjectWhere = "attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE + "] == '" + stProductType + "' && attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_VEHICLE_ATTRIBUTE + "] == '" + stVehicle + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + createLev3Id + "'";
//									String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" +
//											sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" +
//											sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+
////											sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" +  createLev3Id+ "' ";
//											sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" +  createLev3Id+ "' ";
//									
////									String existLev4 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, "", "", "", "", projectGroupObjectWhere, selectList);
//									String existLev4 = "";
//									existLev4 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
//									
//									if(existLev4 == null){
//										String errorMessage = "NOT EXIST PROEJCTGROUPOBJECT OBJECT.";
//										throw new Exception(errorMessage);
//									}
//									
//									if (cdmStringUtil.isEmpty(existLev4)) {
//										if (cdmStringUtil.isNotEmpty(stLev4)) {
//											Map requestArgLev4 = new HashMap();
//											requestArgLev4.put("objectId", createLev3Id);
//											requestArgLev4.put("Name", stLev4);
//											requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
//											requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
//		
////											requestArgLev4.put("Customer", stCustomerAndLev3);
////											requestArgLev4.put("ProductType", stProductType);
////											requestArgLev4.put("ProductName", stProductNameAndLev2);
////											requestArgLev4.put("Vehicle", stVehicle);
//											requestArgLev4.put("ProductNameObjectId", sProductNameObjectId);
//											requestArgLev4.put("ProductTypeObjectId", sProductTypeObjectId);
//											requestArgLev4.put("CustomerObjectId", sCustomerObjectId);
//											requestArgLev4.put("VehicleObjectId", sVehicleObjectId);
//											requestArgLev4.put("ProjectLeafId",stProject_Id );
//		
//											requestArgLev4.put("sCustomer",stCustomerAndLev3 );
//											Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
////											Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroup", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
//											String createLev4Id = (String) createLev4Map.get("id");
//											if(cdmStringUtil.isEmpty(createLev4Id)){
//												String sErrorMessage = (String) createLev4Map.get("errorMessage");
//												
//												String errorMessage = "NOT CREATE LEV4 PROJECT. " + sErrorMessage;
//												throw new Exception(errorMessage);
//											}
//										}
//									}
//								}
//							} else {
//								// lev3 exist
////								String projectGroupObjectWhere = "attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_PRODUCT_TYPE_ATTRIBUTE + "] == '" + stProductType + "' && attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_GROUP_VEHICLE_ATTRIBUTE + "] == '" + stVehicle + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
////								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDMCOMMONCODENAMEKO + "] == '" + stProductType + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE + "] == '" + stVehicle + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE + "] == '" +stProductNameAndLev2 +"' && from[cdmProjectGroupRelationshipCustomer].to.attribute[" + cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE + "] == '" + stCustomerAndLev3 + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
////								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectCode] == '" + stLev4 + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
//								String projectGroupObjectWhere = "from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to.id == '" + sProductTypeObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to.id == '" + sVehicleObjectId + "' && from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to.id == '"+sProductNameObjectId +"' && from[cdmProjectGroupRelationshipCustomer].to.id == '" + sCustomerObjectId + "' && attribute[cdmProjectObjectIdM] == '" + stProject_Id + "'  && to[cdmProjectGroupObjectTypeRelationShip].from.id == '" + existLev3 + "' ";
////								String existLev4 = uniqueCommonCodeAttribute(context, cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, "", "", "", "", projectGroupObjectWhere, selectList);
//								String existLev4 = "";
//								existLev4 = getOnlySearchBus(context, S_PROJECT_GROUP_OBJECT_TYPE, QUERY_WILDCARD, QUERY_WILDCARD, projectGroupObjectWhere, "id", DUMP_DEFAULT);
//								
//								if(existLev4 == null){
//									String errorMessage = "NOT EXIST PROEJCT OBJECT OBJECT.";
//									throw new Exception(errorMessage);
//								}
//								
//								if (cdmStringUtil.isEmpty(existLev4)) {
//									Map requestArgLev4 = new HashMap();
//									requestArgLev4.put("objectId", existLev3);
//									requestArgLev4.put("Name", stLev4);
//									requestArgLev4.put("TypeActual", cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT);
//									requestArgLev4.put("Policy", cdmConstantsUtil.POLICY_CDM_PROJECT_GROUP_POLICY);
//		
////									requestArgLev4.put("Customer", stCustomerAndLev3);
////									requestArgLev4.put("ProductType", stProductType);
////									requestArgLev4.put("ProductName", stProductNameAndLev2);
////									requestArgLev4.put("Vehicle", stVehicle);
//									requestArgLev4.put("ProductNameObjectId", sProductNameObjectId);
//									requestArgLev4.put("ProductTypeObjectId", sProductTypeObjectId);
//									requestArgLev4.put("CustomerObjectId", sCustomerObjectId);
//									requestArgLev4.put("VehicleObjectId", sVehicleObjectId);
//									requestArgLev4.put("ProjectLeafId", stProject_Id);
//									
//									requestArgLev4.put("sCustomer",stCustomerAndLev3 );
//									
//		
//									Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroupMigration", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
////									Map createLev4Map = (Map) JPO.invoke(context, "cdmProjectGroup", null, "createProject", JPO.packArgs(requestArgLev4), Map.class);
//									String createLev4Id = (String) createLev4Map.get("id");
//									if(cdmStringUtil.isEmpty( createLev4Id)){
//										String sErrorMessage = (String) createLev4Map.get("errorMessage");
//										String errorMessage = "NOT CREATE LEV4 PROJECT. " + sErrorMessage;
//										throw new Exception(errorMessage);
//									}
//								}else{
//									String errorMessage = "Not Create Lev4 Project. Already exist.";
//									throw new Exception(errorMessage);
//								}
//							}
//		
//						}
//						
//						successObjectCount ++;
//						if(cdmStringUtil.isNotEmpty(sbErrorData.toString())){
//							
//							multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. LINE NUMBER: \t " + sPhysicalNumberRows +"\t  CreateProjectLev4: \t "+stLev4 +"\t  CreateProjectLev3:"+stCustomerAndLev3+" \t  CreateProjectLev2: \t "+stProductNameAndLev2 +" \t  "+sbErrorData.toString());
//						}
//						multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. LINE NUMBER: \t " + sPhysicalNumberRows +" \t  CreateProjectLev4: \t "+stLev4 +"\t CreateProjectLev3:"+stCustomerAndLev3+" \t  CreateProjectLev2: \t "+stProductNameAndLev2 +" | ");
//						
//					}else{
//						String errorMessage = "NOT EXIST NECESSARY DATA";
//						throw new Exception(errorMessage);
//					}
////					ContextUtil.commitTransaction(context);
//				}catch(Exception e1){
//					failObjectCount++;
////					ContextUtil.abortTransaction(context);
//					multiWriteMessageToFile(failedObjectidWriter, "LINE NUMBER: \t" + sPhysicalNumberRows+"\t EXCEPTION: \t" + e1.getMessage() );
//					mulitWriteErrorToFile(errorStream, "LINE NUMBER: \t" + sPhysicalNumberRows + " \t EXCEPTION: \t" + e1.getMessage());
//					e1.printStackTrace(errorStream);
//				}
//			}
//			
//			
//		}catch(Exception e2){
////			multiWriteMessageToFile(logWriter, "LINE NUMBER: " + sPhysicalNumberRows+" | EXCEPTION : " + e2.getMessage() );
//			mulitWriteErrorToFile(errorStream, "LINE NUMBER: " + sPhysicalNumberRows + " \t EXCEPTION:" + e2.getMessage());
//			e2.printStackTrace(errorStream);
//		
//		}finally{
//			multiWriteMessageToFile(logWriter, "==================================================================================== ");
//			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
//			multiWriteMessageToFile(logWriter, " Total Count:("+totalObjectCont +")   FAIL COUNT : ("+failObjectCount+")    SUCCESS COUNT : ("+successObjectCount+")    LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms             ");
//			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
//			try {
//				if (null != logWriter)
//					logWriter.close();
//
//				if (null != errorStream)
//					errorStream.close();
//
//				if (null != successObjectidWriter)
//					successObjectidWriter.close();
//
//				if (null != failedObjectidWriter)
//					failedObjectidWriter.close();
//			} catch (IOException e) {
//				System.out.println("Exception while closing log stream " + e.getMessage());
//			}
//
//			System.out.println("cdmCommonCodeMigration : addProjectGroupAndProject --> end." +cdmCommonExcel.getTimeStamp2() );
//		}
//	
//	}
	
	
	

}


//################################################################################################################################################################
// 주석처리
//################################################################################################################################################################
///**
//* Project 관련 Excel 정보 enovia 로 삽입 
//* @param context
//* @param args
//* @throws Exception
//*/
/*public void insertProjectExcel(Context context ,String args[])throws Exception{
	Logger logger = Logger.getLogger("");
	logger.debug("${CLASSNAME} : insertProjectExcel() start ");
	try {
		String path = args[0];
		if(cdmStringUtil.isEmpty(path))
			throw new Exception();
		if(args.length>2)
			throw new Exception();
		
		 * 데이타 명 입력후 주석 풀고 진행 필요
		 * 
		String sheetName = ""; // 데이타를 삽입할 sheet 명 입력 필요 !
		XSSFSheet sheet = (XSSFSheet)cdmCommonExcel.getXssfSheet(context, path, sheetName);
		int physicalNumberRows = sheet.getPhysicalNumberOfRows();
		
		for (int i = 1; i < physicalNumberRows; i++) {
			XSSFRow row = sheet.getRow(i);
			
			if (row == null)
				continue;
			
			XSSFCell projectNameCell= row.getCell(0); //Project Name
			XSSFCell descriptionCell= row.getCell(1); //Description 
			XSSFCell productTypeCell= row.getCell(2); //attribute[cdmProjectGroupProductTypeAttribute] 
			XSSFCell productNameCell= row.getCell(3); //attribute[cdmProjectGroupProductNameAttribute]
			XSSFCell customerCell= row.getCell(4); //attribute[cdmProjectGroupCustomerAttribute]
			XSSFCell vehicleCell= row.getCell(5); //attribute[cdmProjectGroupVehicleAttribute]
			
			String tempName = String.valueOf(cdmCommonExcel.getCellValue(projectNameCell));
			String tempDescription = String.valueOf(cdmCommonExcel.getCellValue(descriptionCell));
			String tempProductType = String.valueOf(cdmCommonExcel.getCellValue(productTypeCell));
			String tempProductName = String.valueOf(cdmCommonExcel.getCellValue(productNameCell));
			String tempCustomer = String.valueOf(cdmCommonExcel.getCellValue(customerCell));
			String tempVehicle = String.valueOf(cdmCommonExcel.getCellValue(vehicleCell));
			
			//조건에 따라 policy 와 type 이 다름
			String policy = cdmConstantsUtil.POLICY_CDMPROJECTGROUPPOLICY;
			String type = cdmConstantsUtil.TYPE_CDMSUBPROJECTGROUP;
			String type = cdmConstantsUtil.TYPE_CDMPROJECTGROUPOBJECT;
			
			if(tempName==null || tempDescription==null || tempProductType==null || tempProductName==null || tempCustomer==null || tempVehicle ==null)
				continue;
			
			String parentId = "";
			Map<String,Object> requestArgs = new HashMap<String,Object>();
			requestArgs.put("objectId", parentId);
			requestArgs.put("Name", tempName);
			requestArgs.put("TypeActual", type);
			requestArgs.put("Policy", policy);
			requestArgs.put("Product Type", tempProductType);
			requestArgs.put("Product Name", tempProductName);
			requestArgs.put("Customer", tempCustomer);
			requestArgs.put("Vehicle", tempVehicle);
			
			if(type.equals(cdmConstantsUtil.TYPE_CDMSUBPROJECTGROUP)){
				Map createProjectGroupMap = (Map)JPO.invoke(context, "cdmProjectGroup", null, "cdmProjectGroupCreate", JPO.packArgs(requestArgs),Map.class);
			}else{
				
				Map createProjectGroupOjbectMap = (Map)JPO.invoke(context, "cdmProjectGroup", null, "cdmProjectGroupObjectCreate", JPO.packArgs(requestArgs),Map.class);
				
			}
		}
		
		
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}finally{
		logger.debug("${CLASSNAME} : insertProjectExcel() end ");	
	}
}
*/

///**
// * 
// * TDM_DESCRIPTION,CN_CODE,PRODUCT_TYPE,PROD_DIV  4가지 데이타가 유니크 하게 처리 
// * TDM_DESCRIPTION 은 description 
// * CN_CODE : attribute[cdmSubProjectGroupCode]
// * PRODUCT_TYPE : attribute[cdmProjectGroupProductTypeAttribute]
// * PROD_DIV: attribute[cdmProjectGroupProductNameAttribute]
// * CN_ACTIVATE : -1 일 경우  promote 
// * @param context
// * @param args
// * @throws Exception
// */
/* 	 public void addProductGroup(Context context, String args) throws Exception {
	String sheetName = "product group";
	String upperCommonCode = "Product Group";
	XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, args, sheetName);
	int physicalNumberRows = sheet.getPhysicalNumberOfRows();

	SelectList seletList = new SelectList();
	seletList.addId();
	seletList.add("attribute[cdmCommonAttributeCode]");

	String stWhere = "";
	MapList findMapList = DomainObject.findObjects(context, cdmConstantsUtil.TYPE_CDMSUBPROJECTGROUP, // type
			"Project Tree", // name
			cdmConstantsUtil.QUERY_WILDCARD, // rev
			cdmConstantsUtil.QUERY_WILDCARD, // owner
			cdmConstantsUtil.QUERY_WILDCARD, // vault
			stWhere, // where
			false, // expand
			seletList); // selectbus

	String upperProjectGroupId = "";
	for (int j = 0; j < findMapList.size(); j++) {
		Map findMap = (Map) findMapList.get(j);
		upperProjectGroupId = (String) findMap.get("id");
		break;
	}

	
	for (int i = 2; i < physicalNumberRows; i++) {
		XSSFRow row = sheet.getRow(i);

		if (row == null)
			continue;

		XSSFCell cell_2 = row.getCell(2);// TDM_DESCRIPTION
		XSSFCell cell_4 = row.getCell(4);// PROD_Type
		XSSFCell cell_5 = row.getCell(5);// PROD_Name
		XSSFCell cell_6 = row.getCell(6);// TDMX_CUSTOMER
		XSSFCell cell_7 = row.getCell(7);// CN_VEHICLE
		
		if (cell_5 != null && cell_2 !=null && cell_7 !=null && cell_6 !=null && cell_4 !=null){
			String stDescription = String.valueOf(cdmCommonExcel.getCellValue(cell_2)==null?"":cdmCommonExcel.getCellValue(cell_2));
			String stProductType =  String.valueOf(cdmCommonExcel.getCellValue(cell_4)==null?"":cdmCommonExcel.getCellValue(cell_4)).trim();
			String stPromoteName = String.valueOf(cdmCommonExcel.getCellValue(cell_5)==null?"":cdmCommonExcel.getCellValue(cell_5)).trim(); 
			String stCustomer = String.valueOf(cdmCommonExcel.getCellValue(cell_6)==null?"":cdmCommonExcel.getCellValue(cell_6)).trim();
			String stVehicle = String.valueOf(cdmCommonExcel.getCellValue(cell_7)==null?"":cdmCommonExcel.getCellValue(cell_7)).trim(); 
			
			System.out.println(stDescription);
			SelectList selectList = new SelectList();
			selectList.addId();
			
		}
	}
}
*/

//public void mxMain(Context context, String args[]) throws Exception {
//String arg = args[0];
//if(com.mando.util.cdmStringUtil.isEmpty(arg))
//	throw new Exception();
////addProjectGroupAndProject(context,args[0]);
//}
