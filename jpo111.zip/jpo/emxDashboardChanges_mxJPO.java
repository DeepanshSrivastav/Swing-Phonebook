import matrix.db.Context;


public class emxDashboardChanges_mxJPO extends emxDashboardChangesBase_mxJPO {
	
    /**
     * @param context
     * @param args
     * @throws Exception
     */
    public emxDashboardChanges_mxJPO(Context context, String[] args) throws Exception {
    	super(context, args);
    }  

}
