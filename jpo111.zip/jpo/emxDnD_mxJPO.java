/*
 *  ${CLASSNAME}.java
 *
 * Copyright (c) 1992-2015 Dassault Systemes.
 *
 * All Rights Reserved.
 * This program contains proprietary and trade secret information of
 * MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 */
import matrix.db.*;


public class emxDnD_mxJPO extends emxDnDBase_mxJPO{

    /**
     * @param context
     * @param args
     * @throws Exception
     */
    public emxDnD_mxJPO(Context context, String[] args) throws Exception {
    	super(context, args);
    }        
}
