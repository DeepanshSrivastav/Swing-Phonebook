import matrix.db.Context;


public class DECNewDataModelFindObjects_mxJPO extends DECNewDataModelFindObjectsBase_mxJPO
{
	public DECNewDataModelFindObjects_mxJPO (Context context, String[] args) throws Exception
    {
      super(context, args);
    }
}
