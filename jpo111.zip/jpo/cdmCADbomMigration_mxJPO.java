import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.beans.IEFIntegAccessUtil;
import com.matrixone.MCADIntegration.server.beans.MCADConfigObjectLoader;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.beans.MCADServerGeneralUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADGlobalConfigObject;
import com.matrixone.MCADIntegration.utils.MCADUtil;
import com.matrixone.apps.classification.AttributeGroup;
import com.matrixone.apps.classification.Classification;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainSymbolicConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.domain.util.mxBus;
import com.matrixone.apps.engineering.EBOMAutoSync;
import com.matrixone.apps.engineering.EBOMMarkup;
import com.matrixone.apps.engineering.EngineeringConstants;
import com.matrixone.apps.engineering.EngineeringUtil;
import com.matrixone.apps.engineering.PartFamily;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralConstants;
import com.matrixone.apps.library.PartLibrary;
import com.matrixone.apps.manufacturerequivalentpart.Part;
import com.matrixone.jdom.Element;
import com.matrixone.search.index.Config.formatIndexedType;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.BusinessType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.MatrixWriter;
import matrix.db.Policy;
import matrix.db.RelationshipType;
import matrix.db.StateRequirement;
import matrix.db.StateRequirementList;
import matrix.util.DateFormatUtil;
import matrix.util.List;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;
import com.mando.util.cdmCommonExcel;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

/**
 * part 이 존재하는 경우에 eng spec 이 붙여지는 경우로 생성된 migration
 *  
 *  
 * @author mj
 *
 */
public class cdmCADbomMigration_mxJPO {
	public BufferedWriter consoleWriter			 = null;
	public BufferedWriter logWriter 			 = null;
	
	public BufferedWriter successObjectidWriter  = null;
	public BufferedWriter failedObjectidWriter   = null;
	public BufferedWriter noExistFileWriter   = null;
	public BufferedWriter errorLogFile        	 = null;
	public BufferedWriter debugLogFile           = null;
	public BufferedReader bufferReader           = null;
	       
	public String inputDirectory 			= "";
	public String outputDirectory 			= "";
	public String fileName 		        	= "";
	        
	public String failedIdsLogsDirectory 	= "";
	public PrintStream errorStream		    = null;
	public File successLogFile 				= null;
	public File failedLogFile 				= null;
	public File noExistFile	   = null;
	public Integer sequenceInt ;
	
	public static final String Output_Directory = "MIGRATION_LOGS";
	public static final String sfileSeparator 							= "\\";
	public static final String sRel_Associated_Drawing                  = "Associated Drawing";
	public static final String sRel_CAD_SubComponent                    = "CAD SubComponent";
	
	public int  mxMain(Context context,String args[])throws Exception{
		return 0;
	}
	
	/**
	 * argTest 이라는 string[] 에 직접 입력하여  initializeM 호출
	 * 
	 * args[0] :inputDirectory 파일 경로 정보 (파일명 포함되지않음) 
	 * args[1] : file name
	 * @param context
	 * @param args
	 * @throws Exception
	 * 
	 * 검수 필요 parent child  의 type의  minor  에 모든 데이타에 . 포함되어 있는경우이므로 가능했음 (그렇지 않으면 변경해야함)
	 *  
	 */
	public void executeCadBOMMigration(Context context, String args[])throws Exception{
		long startTime = System.currentTimeMillis();
		
//		if(args.length!=1){
//			throw new Exception("The excel path does not exist.");
//		}
		String sFileLocationAndFileName = args[0];
//		Map paramMap = (Map)JPO.unpackArgs(args);
//		 fileLocation = (String)paramMap.get("File_Location");
//		 file= (String)paramMap.get("File");
//		String sFileLocationAndFileName = (String)paramMap.get("File");
		String fileLocation = "";
		String file = "";
		int sucessCount = 0;
		int failCount = 0;
		int totalCount = 0;
		fileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		file 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		
		
		System.out.println("[cdmCADbomMigration_mxJPO : executeCadBOMMigration] start ."+cdmCommonExcel.getTimeStamp2() );
		
		if(cdmStringUtil.isEmpty(fileLocation) && cdmStringUtil.isEmpty(file)){
			String errorMessage = " NOT EXIST INTPUT FILE LOCATION.";
			throw new Exception(errorMessage);
		}
		String logFileName = "Cadbom";
		
//		String[] argTest = {"C:\\temp\\Import_File\\CAD","20161005_CAD_BOM_FULL_01.txt"}; //읽을 파일경로 ,읽을 파일명  
		String[] argTest = {fileLocation,file}; //읽을 파일경로 ,읽을 파일명  
		initializeM(context,argTest,2,logFileName);      //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("CAD BOM DATA MIGRATION "+ getTimeStamp()+" \n");
		writeMessageToConsole("Reading input log file from : "+inputDirectory+fileName);
		writeMessageToConsole("Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		int lineNumber = 0;
		StringList stListHeader = new StringList();
		String recordRowNum     = "";
		String recordParentTDMXID     = "";
		String recordParentMajorREV     = "";
		String recordChildTDMXID     = "";
		String recordChildMajorREV     = "";
		MqlUtil.mqlCommand(context, "history off");
		boolean bCheckOff = false;
		try{
			
			
			MqlUtil.mqlCommand(context, "Trigger Off");
			bCheckOff = true;
			String stReadData = "";
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory+fileName),"euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null){
				StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
				
				if(lineNumber == 0){
					stListHeader = stListReadData ;
					writeNoExistFile(stReadData);
					writeFailToFile("errorDate \t errorNum \t"+stReadData);
					lineNumber++;
					continue;
				}
				lineNumber++;
				totalCount = lineNumber;
				
				try {
					/*헤더정보와 데이타 정보가 같은 사이즈가 아니면 에러 처리 */
					int headerSize	 = stListHeader.size();
					int readLineSize = stListReadData.size();
					
					
					if(headerSize!=readLineSize){
						String errorMessage = "NOT MATCH"+stListReadData.toString() +" || "+stListHeader.toString();
						throw new Exception(errorMessage);
					}

					LinkedHashMap<String, Object> linkedCadBomHM = new LinkedHashMap<String,Object>();
					
					for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {
						
						String stTempCadBomInfos = ((String) stListReadData.get(stListNum)).trim();
						String stTempCadBomInfosHeader = ((String) stListHeader.get(stListNum)).trim();
						stTempCadBomInfos = isVaildNullData(stTempCadBomInfos);
						linkedCadBomHM.put(stTempCadBomInfosHeader, stTempCadBomInfos);
	
					}
					
				
					recordRowNum = (String)linkedCadBomHM.get("NO");
					String sParent_CAD_ID  = (String)linkedCadBomHM.get("PAR_SID");
					String sParent_CAD_Rev  = (String)linkedCadBomHM.get("PAR_SREV");
					String sChild_CAD_ID   = (String)linkedCadBomHM.get("CHLD_SID");
					String sChild_CAD_REV   = (String)linkedCadBomHM.get("CHLD_SREV");
					
					String strParentType   = (String)linkedCadBomHM.get("PAR_TYPE");
					String strChildType   = (String)linkedCadBomHM.get("CHLD_TYPE");
					
					
					
					
//					if (!sParent_CAD_ID.startsWith("ASY-"))
//						continue;
					
					String sParentCADId    = "";
					String sChildCADId    = "";
					
					
					
					String strParentRevionSeq = sParent_CAD_Rev.replaceAll("\\..+", "");
					String strChildRevionSeq = sChild_CAD_REV.replaceAll("\\..+", "");
					
					String strParentRevionMinorSeq = "";
					String strChildRevionMinorSeq = "";
					
					
					
					StringList sListParentRevisionSequence = new StringList();
					sListParentRevisionSequence = FrameworkUtil.split(sParent_CAD_Rev, "\\..+");
					boolean bMinorParentRevision = false;
					
					String splitParentMinorRevision = "";
					if(sListParentRevisionSequence.size()>2){
						bMinorParentRevision = true;
						String sParentRevisionSequnceSplit = (String)sListParentRevisionSequence.get(2);
						Integer intergerParentRevisionSequence = Integer.parseInt(sParentRevisionSequnceSplit);
						intergerParentRevisionSequence = intergerParentRevisionSequence-1;
						splitParentMinorRevision = String.format("%01d", intergerParentRevisionSequence);
						
						String sTempParentRevisionSeqence = (String)sListParentRevisionSequence.get(0); 
						splitParentMinorRevision = sTempParentRevisionSeqence+"."+splitParentMinorRevision;
					}
					
					
					StringList sListChildRevisionSequence = new StringList();
					sListChildRevisionSequence = FrameworkUtil.split(sChild_CAD_REV, "\\..+");
					boolean bMinorChildRevision = false;
					
					String splitChildMinorRevision = "";
					if(sListChildRevisionSequence.size()>2){
						bMinorChildRevision = true;
						String sChildRevisionSequnceSplit = (String)sListChildRevisionSequence.get(2);
						Integer intergerChildRevisionSequence = Integer.parseInt(sChildRevisionSequnceSplit);
						intergerChildRevisionSequence = intergerChildRevisionSequence-1;
						splitChildMinorRevision = String.format("%01d", intergerChildRevisionSequence);
						
						String sTempChildRevisionSeqence = (String)sListChildRevisionSequence.get(0); 
						splitChildMinorRevision = sTempChildRevisionSeqence+"."+splitChildMinorRevision;
					}
					
					
					
					//
					ContextUtil.startTransaction(context, true);
				
					//
					boolean bSuceessCheck = false;
					if("MAJOR".equalsIgnoreCase(strParentType) && "MAJOR".equalsIgnoreCase(strChildType)) {
						
						
						
						//find parent MAJOR
						//find parent last  minor
						String sParentCADMql = "";
						sParentCADMql = "temp query bus 'CATPart,CATProduct' * "+strParentRevionSeq+" where \"attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID+"] == '"+sParent_CAD_ID+"' && (policy == '"+cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION +"') \" select id from[Latest Version].to.id dump |";
						String sParentCADResultMql = "";
						sParentCADResultMql = MqlUtil.mqlCommand(context, sParentCADMql);
						
						StringList sListParentCADResultMql = new StringList();
						sListParentCADResultMql = FrameworkUtil.split(sParentCADResultMql, "|");
						
						String strParent_MAJOR_oid = "";
						String strParent_minor_oid = "";
						
						if(sListParentCADResultMql.size()>2){
							
							strParent_MAJOR_oid = (String)sListParentCADResultMql.get(3);
							strParent_minor_oid = (String)sListParentCADResultMql.get(4);
						}	
						
						
						//find child MAJOR
						
						String sChildCADMql = "";
						sChildCADMql = "temp query bus 'CATPart,CATProduct' * "+strChildRevionSeq+" where \"attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID+"] == '"+sChild_CAD_ID+"' && (policy == '"+cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION +"') \" select id from[Latest Version].to.id dump |";
						
						String sChildCADResultMql = "";
						sChildCADResultMql = MqlUtil.mqlCommand(context, sChildCADMql);
						
						StringList sListChildADResultMql = new StringList();
						sListChildADResultMql = FrameworkUtil.split(sChildCADResultMql, "|");
						
						String strChild_MAJOR_oid = "";
						String strChild_minor_oid = "";
						
						if(sListChildADResultMql.size()>2){
							strChild_MAJOR_oid = (String)sListChildADResultMql.get(3);
							strChild_minor_oid = (String)sListChildADResultMql.get(4);
						}
						
						
						//find child last minor
						
						if(UIUtil.isNotNullAndNotEmpty(strChild_MAJOR_oid) && UIUtil.isNotNullAndNotEmpty(strParent_MAJOR_oid) ){
							
							DomainObject objParent = DomainObject.newInstance(context, strParent_MAJOR_oid);
							DomainObject objChild = DomainObject.newInstance(context, strChild_MAJOR_oid);
							
							/*  CATDRAWING OBJECT 은 하위에 CATPART ,CATPRODUCT을 붙일수 없다 ? */
							
							//connect parent MAJOR with child MAJOR
							DomainRelationship.connect(context, new DomainObject(strParent_MAJOR_oid), sRel_CAD_SubComponent, new DomainObject(strChild_MAJOR_oid));
						
							//connect parent minor with child minor
							DomainRelationship.connect(context, new DomainObject(strParent_minor_oid), sRel_CAD_SubComponent, new DomainObject(strChild_minor_oid));
							bSuceessCheck = true;
						}else{
							
							if(UIUtil.isNullOrEmpty(strParent_MAJOR_oid) || UIUtil.isNullOrEmpty(strChild_MAJOR_oid) ){
								if(UIUtil.isNotNullAndNotEmpty(strParent_MAJOR_oid) || UIUtil.isNullOrEmpty(strChild_MAJOR_oid)){
									writeNoExistFile("\t"+"\t"+sChild_CAD_ID+"\t"+sChild_CAD_REV);
									String errorMessage = "NOT EXIST CHILD CAD OBJECT. ";
									throw new Exception(errorMessage);
								}else if(UIUtil.isNullOrEmpty(strParent_MAJOR_oid) || UIUtil.isNotNullAndNotEmpty(strChild_MAJOR_oid) ){
									writeNoExistFile(sParent_CAD_ID+"\t"+sParent_CAD_Rev+"\t"+"\t");
									String errorMessage = "NOT EXIST PARENT CAD OBJECT. ";
									throw new Exception(errorMessage);
								}else if(UIUtil.isNullOrEmpty(strParent_MAJOR_oid) && UIUtil.isNullOrEmpty(strChild_MAJOR_oid) ){
									writeNoExistFile(sParent_CAD_ID+"\t"+sParent_CAD_Rev+"\t"+sChild_CAD_ID+"\t"+sChild_CAD_REV);
									String errorMessage = "NOT EXIST PARENT CAD AND CHILD OBJECT. ";
									throw new Exception(errorMessage);
								}
							
							}
						}
						
					} else if("MAJOR".equalsIgnoreCase(strParentType) && "minor".equalsIgnoreCase(strChildType)) {
						
						
						//find parent MAJOR
						
						String sParentCADMql = "";
						sParentCADMql = "temp query bus 'CATPart,CATProduct' * "+strParentRevionSeq+" where \"attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID+"] == '"+sParent_CAD_ID+"' && (policy == '"+cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION +"') \" select from[Latest Version].to.id  dump |";
						String sParentCADResultMql = "";
						sParentCADResultMql = MqlUtil.mqlCommand(context, sParentCADMql);
						
						StringList sListParentCADResultMql = new StringList();
						sListParentCADResultMql = FrameworkUtil.split(sParentCADResultMql, "|");
						
						String strParent_minor_oid = "";
						
						if(sListParentCADResultMql.size()>2){
						strParent_minor_oid = (String)sListParentCADResultMql.get(3);
						}
						
						//find parent last minor
						
						
						//find child minor
						String sChildCADMql = "";
						sChildCADMql = "temp query bus 'CATPart,CATProduct' * "+splitChildMinorRevision+" where \"attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID+"] == '"+sChild_CAD_ID+"' && (policy == '"+cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY +"') \" select id  dump |";
						
						String sChildCADResultMql = "";
						sChildCADResultMql = MqlUtil.mqlCommand(context, sChildCADMql);
						
						StringList sListChildADResultMql = new StringList();
						sListChildADResultMql = FrameworkUtil.split(sChildCADResultMql, "|");
						
						String strChild_minor_oid = "";
						
						if(sListChildADResultMql.size()>2){
							strChild_minor_oid = (String)sListChildADResultMql.get(3);
						}
						
						

						if(UIUtil.isNotNullAndNotEmpty(strParent_minor_oid) && UIUtil.isNotNullAndNotEmpty(strChild_minor_oid) ){
							
							DomainObject objParent = DomainObject.newInstance(context, strParent_minor_oid);
							DomainObject objChild = DomainObject.newInstance(context, strChild_minor_oid);
							
							//connect parent minor with child minor
							DomainRelationship.connect(context, new DomainObject(strParent_minor_oid), sRel_CAD_SubComponent, new DomainObject(strChild_minor_oid));
							bSuceessCheck = true;
						}else{
							
							if(UIUtil.isNullOrEmpty(strParent_minor_oid) || UIUtil.isNullOrEmpty(strChild_minor_oid) ){
								if(UIUtil.isNotNullAndNotEmpty(strParent_minor_oid) || UIUtil.isNullOrEmpty(strChild_minor_oid)){
									writeNoExistFile("\t"+"\t"+sChild_CAD_ID+"\t"+sChild_CAD_REV);
									String errorMessage = "NOT EXIST CHILD CAD OBJECT. ";
									throw new Exception(errorMessage);
								}else if(UIUtil.isNullOrEmpty(strParent_minor_oid) || UIUtil.isNotNullAndNotEmpty(strChild_minor_oid) ){
									writeNoExistFile(sParent_CAD_ID+"\t"+sParent_CAD_Rev+"\t"+"\t");
									String errorMessage = "NOT EXIST PARENT CAD OBJECT. ";
									throw new Exception(errorMessage);
								}else if(UIUtil.isNullOrEmpty(strParent_minor_oid) && UIUtil.isNullOrEmpty(strChild_minor_oid) ){
									writeNoExistFile(sParent_CAD_ID+"\t"+sParent_CAD_Rev+"\t"+sChild_CAD_ID+"\t"+sChild_CAD_REV);
									String errorMessage = "NOT EXIST PARENT CAD AND CHILD OBJECT. ";
									throw new Exception(errorMessage);
								}
							
							}
						}
						//connect parent last minor with child minor
						
						
						
						
					} else if("minor".equalsIgnoreCase(strParentType) && "MAJOR".equalsIgnoreCase(strChildType)) {
						
						//find parent minor
						String sParentCADMql = "";
						sParentCADMql = "temp query bus 'CATPart,CATProduct' * "+splitParentMinorRevision+" where \"attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID+"] == '"+sParent_CAD_ID+"' && (policy == '"+cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY +"') \" select id  dump |";
						
						String sParentCADResultMql = "";
						sParentCADResultMql = MqlUtil.mqlCommand(context, sParentCADMql);
						
						StringList sListParentADResultMql = new StringList();
						sListParentADResultMql = FrameworkUtil.split(sParentCADResultMql, "|");
						
						String strParent_minor_oid = "";
						
						if(sListParentADResultMql.size()>2){
							strParent_minor_oid = (String)sListParentADResultMql.get(3);
						}
						
						
						
						//find child MAJOR

						//find child last minor
						
						
						String sChildCADMql = "";
						sChildCADMql = "temp query bus 'CATPart,CATProduct' * "+strChildRevionSeq+" where \"attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID+"] == '"+sChild_CAD_ID+"' && (policy == '"+cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION +"') \" select id from[Latest Version].to.id dump |";
						
						String sChildCADResultMql = "";
						sChildCADResultMql = MqlUtil.mqlCommand(context, sChildCADMql);
						
						StringList sListChildCADResultMql = new StringList();
						sListChildCADResultMql = FrameworkUtil.split(sChildCADResultMql, "|");
						
						String strChild_major_oid = "";
						String strChild_Last_minor_oid = "";
						
						if(sListChildCADResultMql.size()>2){
							strChild_major_oid = (String)sListChildCADResultMql.get(3);
							strChild_Last_minor_oid = (String)sListChildCADResultMql.get(4);
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strParent_minor_oid) && UIUtil.isNotNullAndNotEmpty(strChild_Last_minor_oid) ){
							
							DomainObject objParent = DomainObject.newInstance(context, strParent_minor_oid);
							DomainObject objChild = DomainObject.newInstance(context, strChild_Last_minor_oid);
							
							//connect parent minor with child minor
							DomainRelationship.connect(context, new DomainObject(strParent_minor_oid), sRel_CAD_SubComponent, new DomainObject(strChild_Last_minor_oid));
							bSuceessCheck = true;
						}else{
							if(UIUtil.isNullOrEmpty(strParent_minor_oid) || UIUtil.isNullOrEmpty(strChild_Last_minor_oid) ){
								if(UIUtil.isNotNullAndNotEmpty(strParent_minor_oid) || UIUtil.isNullOrEmpty(strChild_Last_minor_oid)){
									writeNoExistFile("\t"+"\t"+sChild_CAD_ID+"\t"+sChild_CAD_REV);
									String errorMessage = "NOT EXIST CHILD CAD OBJECT. ";
									throw new Exception(errorMessage);
								}else if(UIUtil.isNullOrEmpty(strParent_minor_oid) || UIUtil.isNotNullAndNotEmpty(strChild_Last_minor_oid) ){
									writeNoExistFile(sParent_CAD_ID+"\t"+sParent_CAD_Rev+"\t"+"\t");
									String errorMessage = "NOT EXIST PARENT CAD OBJECT. ";
									throw new Exception(errorMessage);
								}else if(UIUtil.isNullOrEmpty(strParent_minor_oid) && UIUtil.isNullOrEmpty(strChild_Last_minor_oid) ){
									writeNoExistFile(sParent_CAD_ID+"\t"+sParent_CAD_Rev+"\t"+sChild_CAD_ID+"\t"+sChild_CAD_REV);
									String errorMessage = "NOT EXIST PARENT CAD AND CHILD OBJECT. ";
									throw new Exception(errorMessage);
								}
							
							}
						}
						//connect parent minor with child last minor
						
						
					} else if("minor".equalsIgnoreCase(strParentType) && "minor".equalsIgnoreCase(strChildType)) {
						
						//find parent minor
						String sParentCADMql = "";
						sParentCADMql = "temp query bus 'CATPart,CATProduct' * "+splitParentMinorRevision+" where \"attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID+"] == '"+sParent_CAD_ID+"' && (policy == '"+cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY +"') \" select id  dump |";
						
						String sParentCADResultMql = "";
						sParentCADResultMql = MqlUtil.mqlCommand(context, sParentCADMql);
						
						StringList sListParentADResultMql = new StringList();
						sListParentADResultMql = FrameworkUtil.split(sParentCADResultMql, "|");
						
						String strParent_minor_oid = "";
						
						if(sListParentADResultMql.size()>2){
							strParent_minor_oid = (String)sListParentADResultMql.get(3);
						}
						
						//find child minor
						String sChildCADMql = "";
						sChildCADMql = "temp query bus 'CATPart,CATProduct' * "+splitChildMinorRevision+" where \"attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID+"] == '"+sChild_CAD_ID+"' && (policy == '"+cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY +"') \" select id  dump |";
						
						String sChildCADResultMql = "";
						sChildCADResultMql = MqlUtil.mqlCommand(context, sChildCADMql);
						
						StringList sListChildCADResultMql = new StringList();
						sListChildCADResultMql = FrameworkUtil.split(sChildCADResultMql, "|");
						
						String strChild_minor_oid = "";
						if(sListChildCADResultMql.size()>2){
							strChild_minor_oid = (String)sListChildCADResultMql.get(3);
						}
						//connect parent minor with child minor
						if(UIUtil.isNotNullAndNotEmpty(strParent_minor_oid) && UIUtil.isNotNullAndNotEmpty(strChild_minor_oid) ){
							
							DomainObject objParent = DomainObject.newInstance(context, strParent_minor_oid);
							DomainObject objChild = DomainObject.newInstance(context, strChild_minor_oid);
							
							//connect parent minor with child minor
							DomainRelationship.connect(context, new DomainObject(strParent_minor_oid), sRel_CAD_SubComponent, new DomainObject(strChild_minor_oid));
							bSuceessCheck = true;
						}else{
							if(UIUtil.isNullOrEmpty(strParent_minor_oid) || UIUtil.isNullOrEmpty(strChild_minor_oid )){
								if(UIUtil.isNotNullAndNotEmpty(strParent_minor_oid) || UIUtil.isNullOrEmpty(strChild_minor_oid)){
									writeNoExistFile("\t"+"\t"+sChild_CAD_ID+"\t"+sChild_CAD_REV);
									String errorMessage = "NOT EXIST CHILD CAD OBJECT. ";
									throw new Exception(errorMessage);
								}else if(UIUtil.isNullOrEmpty(strParent_minor_oid) || UIUtil.isNotNullAndNotEmpty(strChild_minor_oid) ){
									writeNoExistFile(sParent_CAD_ID+"\t"+sParent_CAD_Rev+"\t"+"\t");
									String errorMessage = "NOT EXIST PARENT CAD OBJECT. ";
									throw new Exception(errorMessage);
								}else if(UIUtil.isNullOrEmpty(strParent_minor_oid) && UIUtil.isNullOrEmpty(strChild_minor_oid) ){
									writeNoExistFile(sParent_CAD_ID+"\t"+sParent_CAD_Rev+"\t"+sChild_CAD_ID+"\t"+sChild_CAD_REV);
									String errorMessage = "NOT EXIST PARENT CAD AND CHILD OBJECT. ";
									throw new Exception(errorMessage);
								}
							
							}
						}
					}
					
					ContextUtil.commitTransaction(context);
					if(bSuceessCheck){
						sucessCount++;
						writeSuccessToFile(recordRowNum+"\t"+sParent_CAD_ID+"\t"+sParent_CAD_Rev+"\t"+sChild_CAD_ID+"\t"+sChild_CAD_REV);
					}else{
						failCount++;
						writeMessageToConsole(recordRowNum+"\t"+sParent_CAD_ID+"\t"+sParent_CAD_Rev+"\t"+sChild_CAD_ID+"\t"+sChild_CAD_REV);
					}
					
				} catch (Exception exception) {
					
					failCount++;
					ContextUtil.abortTransaction(context);
					writeMessageToConsole("LineNum :\t"+recordRowNum+"\t " + exception.getMessage());
					writeErrorToFile("LineNum(#) \t"+recordRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " );
					exception.printStackTrace(errorStream);
					String errorMessage = exception.getMessage();
					if(UIUtil.isNotNullAndNotEmpty(errorMessage) && errorMessage.startsWith("CATDrawing (type) Data can not be bom configuration information")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"1"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(errorMessage) && errorMessage.startsWith("NOT EXIST PARENT CAD OBJECT. ")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"2"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(errorMessage) && errorMessage.startsWith("NOT EXIST CHILD CAD OBJECT. ")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(errorMessage) && errorMessage.startsWith("NOT EXIST PARENT CAD AND CHILD OBJECT. ")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"4"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(errorMessage) && errorMessage.startsWith("cdmImageDrawing(Type) can not be included in the to child or parent.")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"5"+"\t"+stReadData);
					}else if(UIUtil.isNullOrEmpty(errorMessage) && errorMessage.startsWith("cdmCADMiscellaneous (type) Data can not be bom configuration information.")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"6"+"\t"+stReadData);
					}
					
					else{
						
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t"+stReadData);
					}
					
					

				}finally{
					
				}
			}
			

		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("File CAD BOM Migration COMPLETED.                    ");
		writeMessageToConsole("====================================================================================\n");
	
		
		}catch(Exception exception)
		{
			
			writeMessageToConsole(" Exception occured : "+exception.getMessage() +"  LINE NUMBER: "+recordRowNum);
			exception.printStackTrace(errorStream);
		}
		finally {
			MqlUtil.mqlCommand(context, "history on");
			if(bCheckOff){
				MqlUtil.mqlCommand(context, "Trigger On");	
				bCheckOff = false;
			}
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms        "  );
			writeMessageToConsole("END TIME : "+cdmCommonExcel.getTimeStamp2() );
			
			writeMessageToConsole("sucessCount :("+sucessCount+") failCount :("+failCount+") Total Time :("+(totalCount-1)+")" );
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			System.out.println("[cdmCADbomMigration_mxJPO : executeCadBOMMigration] end ."+cdmCommonExcel.getTimeStamp2());
		}
	}
	
	
	/**
	 * null 발생시 "" 로 체크  
	 * @param data
	 * @return
	 */
	public String isVaildNullData(String data){
		return ((data == null || "null".equals(data)) ? "" : data.trim());
	}
	
	
    private boolean isValidData(String data) {
		return ((data == null || "null".equals(data)) ? 0 : data.trim().length()) > 0;
	}
    
	private void closeLogStream() throws IOException
	{
		try 
		{
			if(null != logWriter)
				logWriter.close();

			if(null != errorStream)
				errorStream.close();

			if(null != successObjectidWriter)
				successObjectidWriter.close();

			if(null != failedObjectidWriter)
				failedObjectidWriter.close();
			
			if(null != noExistFileWriter)
				noExistFileWriter.close();
		} 
		catch (IOException e) 
		{
			System.out.println("Exception while closing log stream "+e.getMessage());
		}
	}
	
	private void writeErrorToFile(String message)throws Exception{
		errorStream.write(message.getBytes("UTF-8"));
		errorStream.write("\n".getBytes("UTF-8"));
	}
	
	private void writeMessageToConsole(String message) throws Exception
	{
		writeMessageToLogFile(message);
	}

	private void writeMessageToLogFile(String message) throws Exception
	{
		logWriter.write( message + "\n");
		logWriter.flush();
		
	}
	
	private String getTimeStamp(){
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date)+"T"+ new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}
	
	public void writeFailToFile(String message) throws Exception{
		failedObjectidWriter.write( message + "\n");
		failedObjectidWriter.flush();
		
	}
	public void writeSuccessToFile(String message)throws Exception{
		successObjectidWriter.write(message + "\n");
		successObjectidWriter.flush();
	}
	
	public void writeNoExistFile(String message) throws Exception{
		noExistFileWriter.write( message + "\n");
		noExistFileWriter.flush();
		
	}
	
	/**
	 * args{inputDirectory, 
	 * 
	 * @param context
	 * @param args
	 * @param requestAgsNum
	 * @param logFileName
	 */
	private void initializeM(Context context,String args[],int requestAgsNum , String logFileName)throws Exception{

		sequenceInt			= 1;

		if (args.length != requestAgsNum )
		{
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}


		inputDirectory = args[0];

		// input file name
		fileName = args[1];
		
		// documentDirectory does not ends with "/" add it
		if(inputDirectory != null && !inputDirectory.endsWith(sfileSeparator))
		{
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + Output_Directory + sfileSeparator + logFileName  +"_"+   sfileSeparator;
        File fileOutputDirectory = new File(outputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName +="_"+fileName.substring(0,fileName.lastIndexOf("."))+"_"+formatTime;
        
		logWriter 			 	= new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		noExistFile             = new File(outputDirectory + logFileName + "_noExistLog" + ".txt");
		noExistFileWriter		= new BufferedWriter(new FileWriter(noExistFile,true));
	
	}
	
	
	
	public void Test(Context context, String arg[])throws Exception{
		
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	
	
	
	
}


