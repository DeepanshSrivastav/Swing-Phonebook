/*
**  DECNameGenerator
**
**  Copyright Dassault Systemes, 1992-2007.
**  All Rights Reserved.
**  This program contains proprietary and trade secret information of Dassault Systemes and its 
**  subsidiaries, Copyright notice is precautionary only
**  and does not evidence any actual or intended publication of such program
**
**  Program to generate autonames.
*/


import matrix.db.Context;

public class DECNameGenerator_mxJPO extends DECNameGeneratorBase_mxJPO
{
	public DECNameGenerator_mxJPO (Context context, String[] args) throws Exception
	{
	  super(context, args);
	}	
}

