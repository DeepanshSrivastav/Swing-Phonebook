import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmFTPUtil;
import com.mando.util.cdmOwnerRolesUtil;
import com.mando.util.cdmPropertiesUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.Job;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.FileList;
import matrix.db.JPO;
import matrix.util.Pattern;
import matrix.util.SelectList;
import matrix.util.StringList;

public class cdmDCR_mxJPO {

	/**
	 * @author jaehyun CreateDCR.
	 */
	@SuppressWarnings({ "unchecked", "deprecation", "rawtypes" })
	@com.matrixone.apps.framework.ui.CreateProcessCallable
	public Map createDCR(Context context, String[] args) throws Exception {
		Map returnMap = new HashMap();
		try {
			ContextUtil.startTransaction(context, true);
			
			SimpleDateFormat sdfFormat = new SimpleDateFormat ( "yyyy-", Locale.KOREA );
			Date date = new Date();
			String strYear = sdfFormat.format(date);
			
			HashMap paramMap 		= (HashMap) JPO.unpackArgs(args);
			String strType 			= (String) paramMap.get(cdmConstantsUtil.TEXT_TYPEACTUAL);
			String strName 			= (String) paramMap.get("Code");
			String strCDMOnly 		= (String) paramMap.get(cdmConstantsUtil.TEXT_CDMONLY);
			String strECTitle		= (String) paramMap.get(cdmConstantsUtil.TEXT_TITLE);
			String strProjectOID	= StringUtils.trimToEmpty((String) paramMap.get(cdmConstantsUtil.TEXT_PROJECTOID));
			
			// Number Generator, Auto Name
			DomainObject domECObj 	= new DomainObject();
			
			String ngType  = "eService Number Generator";
			String ngName  = "cdmECNumberGenerator";
			String ngRev   = "cdmEC";
			String ngVault = "eService Administration";
			
			
			BusinessObject numGenerator = new BusinessObject(ngType, ngName, ngRev, ngVault);
			int number = Integer.parseInt(numGenerator.getAttributeValues(context, "eService Next Number").getValue());
			domECObj.createObject(context, strType, strName, "-", cdmConstantsUtil.POLICY_CDM_EC_POLICY, "eService Production");

			numGenerator.setAttributeValue(context, "eService Next Number", String.valueOf(number+1));
			
			String strDCRObjectId = MqlUtil.mqlCommand(context, "print bus '" + strType + "' '" + String.format("X-"+strYear+"%05d", number) + "' - select id dump");
			
			if(! DomainConstants.EMPTY_STRING.equals(strProjectOID)){
				MqlUtil.mqlCommand(context, "connect bus '" + strProjectOID + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC + "' to " + strDCRObjectId);	
			}
				
			returnMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_EC_CATEGORY, strCDMOnly);
			returnMap.put("Title", strECTitle);
			
			domECObj.setAttributeValues(context, returnMap);

			returnMap.put("id", strDCRObjectId);
			ContextUtil.commitTransaction(context);

			return returnMap;

		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * GetTable Created. return Table.
	 */
	@SuppressWarnings("rawtypes")
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList mlDCRGetTable(Context context, String[] args) throws Exception {
		Map paramMap 				= JPO.unpackArgs(args);
		String strDCRObjectId 		= (String) paramMap.get("objectId");

		MapList mlAffectedItems 	= new MapList();
		DomainObject domDcrObj 		= new DomainObject(strDCRObjectId);
		StringList objectSelects 	= new StringList();
	
		objectSelects.add(DomainConstants.SELECT_ID);

		mlAffectedItems = domDcrObj.getRelatedObjects(context, 
													  DomainConstants.RELATIONSHIP_AFFECTED_ITEM, // Relationship
													  "*", // From Type name
													  objectSelects, // objects Select
													  null, // Rel selects
													  false, // to Direction
													  true, // from Direction
													  (short) 1, // recusion level
													  "", //objectWhere
													  "", //relationshipWhere
													  0); //limit
		
		return mlAffectedItems;
	}

	/**
	 * GetProjectTable return MapList cdmPart Table
	 */
	@SuppressWarnings("rawtypes")
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getExportTable(Context context, String[] args) throws Exception {
		Map paramMap 				= JPO.unpackArgs(args);
		String strDcrObjectId 		= (String) paramMap.get("objectId");
		String strWhere 			= "revision==last";

		DomainObject domDcrObj 		= new DomainObject(strDcrObjectId);
		MapList mlAffectedItems 	= new MapList();
		StringList objectSelects 	= new StringList();

		objectSelects.add(DomainConstants.SELECT_ID);

		mlAffectedItems = domDcrObj.getRelatedObjects(context, 
													  DomainConstants.RELATIONSHIP_AFFECTED_ITEM, // Relationship
													  cdmConstantsUtil.TYPE_CDMPART, // From Type name
													  objectSelects, // objects Select
													  null, // Rel selects
													  false, // to Direction
													  true, // from Direction
													  (short) 1, // recusion level
													  strWhere, 
													  "", 
													  0);
		return mlAffectedItems;
	}

	/**
	 * export parts to PLM System when DCR is not CDM Only
	 * 
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String setPLM2Export(Context context, String[] args) throws Exception {
		String strSuccess = cdmConstantsUtil.TEXT_SUCCESS;
		String strFail = cdmConstantsUtil.TEXT_FAIL;
		
		try {
			ContextUtil.startTransaction(context, true);

			Map paramMap = JPO.unpackArgs(args);
			String strDcrObjectId = (String) paramMap.get("objectId");
			String strCurrent 			= (String) paramMap.get(cdmConstantsUtil.TEXT_CURRENT);


			if (strCurrent.equals("Release")) {
				return strFail;
			}
			
			DomainObject domDcrObj = new DomainObject(strDcrObjectId);
			
			domDcrObj.setState(context, "Release");

			JPO.invoke(context, "cdmDCR", null, "PLMExportBackgroundJob", JPO.packArgs(paramMap), String.class);
			
			
			String strOwner = context.getUser();
			String strSiteName = MqlUtil.mqlCommand(context, "print person $1 select $2 dump $3", strOwner, "site.name", "|");

			if (StringUtils.isEmpty(strSiteName)) {
				strSiteName = "MDK";
			}
			
			domDcrObj.setAttributeValue(context, "cdmSiteName", strSiteName);
			
			
			
			
			ContextUtil.commitTransaction(context);
		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			e.printStackTrace();
			throw e;
		}
		return strSuccess;
	}

	
	
	/**
	 * create and start JOB for sending drawing to PLM
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public String PLMExportBackgroundJob(Context context, String[] args) throws Exception {
		Job job = null;
		try {
			Map paramMap = JPO.unpackArgs(args);
			String strECObjectId = (String) paramMap.get("objectId");

			String jponame = "dcmDCR";
			String methodName = "executeBackgroundJob";
			String[] params = { strECObjectId };

			job = new Job(jponame, methodName, params);

			job.setNotifyOwner("No");

			job.setTitle(MqlUtil.mqlCommand(context, "print bus $1 select name dump ", new String[] { strECObjectId }));
			job.createAndSubmit(context);

			
			ContextUtil.pushContext(context);
			DomainRelationship.connect(context, job, "cdmJobECO", new DomainObject(strECObjectId));
			ContextUtil.popContext(context);
			
			
		} catch (Exception ex) {
			job.setErrorMessage(ex.getMessage());
			ex.printStackTrace();
		} finally {

		}
		return "Succeeded";
	}
	
	
	/**
	 * send drawings to PLM
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void executeBackgroundJob(Context context, String[] args) throws Exception {

		try {
		    
			this.sendDrawingFilesToPLM(context, args);
			

			
		} catch (Exception e) {
			try {
				
				String strECObjectId = args[0];
				DomainObject ecDomObj = new DomainObject(strECObjectId);
				String strECO = ecDomObj.getInfo(context, DomainObject.SELECT_NAME);
				
				cdmEC_mxJPO cdmEC = new cdmEC_mxJPO();
				cdmEC.sendMail(context, new String[]{strECO});
			} catch (Exception ex) {
				System.out.println("Fail to send mail.");
			}
		}
	}

	
	
	

	/**
	 * Sends drawings(Auto CAD, NX Drawing, CAT Drawing with CGM and Auto CAD generated) which Affected Item has. 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void sendDrawingFilesToPLM(Context context, String[] args) throws Exception {
		try {
			String strECObjectId = args[0];
			System.out.println("strECObjectId      " + strECObjectId);

			SelectList selectStmts = new SelectList();
			selectStmts.add(DomainObject.SELECT_ID);
			selectStmts.add(DomainObject.SELECT_TYPE);
			selectStmts.add(DomainObject.SELECT_NAME);
			selectStmts.add(DomainObject.SELECT_REVISION);
			selectStmts.add("attribute[cdmDrawing_Parameter_Part_Number]");
			selectStmts.add("attribute[cdmDrawing_Parameter_Part_Revision]");

			
			SelectList selectRel = new SelectList();

			Pattern type2DPattern = new Pattern("CATDrawing");
			type2DPattern.addPattern("cdmNXDrawing");
			type2DPattern.addPattern("cdmAutoCAD");
			type2DPattern.addPattern("cdmSTEP");

			DomainObject ecDomObj = new DomainObject(strECObjectId);

			MapList mlCATDrawings = new MapList();
			MapList mlAutoCadNXDrawings = new MapList();
			
			
			MapList ml2DList = ecDomObj.getRelatedObjects(context, 
														DomainConstants.RELATIONSHIP_AFFECTED_ITEM, // relationship
														type2DPattern.getPattern(), // type
														selectStmts, // objects
														selectRel, // relationships
														false, // to
														true, // from
														(short) 1, // recurse
														null, // where
														null, // relationship where
														(short) 0); // limit

			
			
			
			for (Iterator iterator = ml2DList.iterator(); iterator.hasNext();) {
				
				Map obj2DMap = (Map) iterator.next();
				String strDRWType = (String) obj2DMap.get(DomainObject.SELECT_TYPE);

				String strPartNo = (String) obj2DMap.get("attribute[cdmDrawing_Parameter_Part_Number]");
				String strPartRevision = (String) obj2DMap.get("attribute[cdmDrawing_Parameter_Part_Revision]");

				obj2DMap.put("PartNo", strPartNo);
				obj2DMap.put("PartRevision", strPartRevision);
				
				// if type is CAT Drawing
				if ("CATDrawing".equals(strDRWType)) {
					mlCATDrawings.add(obj2DMap);

					// if type is Auto CAD or NX Drawing.
				} else if("cdmNXDrawing".equals(strDRWType) || "cdmAutoCAD".equals(strDRWType) || "cdmSTEP".equals(strDRWType)) {
					mlAutoCadNXDrawings.add(obj2DMap);
				}
			}
		
			

			String strWorkspace = context.createWorkspace() ;
			
			
//			mlCATDrawings = new MapList();
//			Map m = new HashMap();
//			m.put("PartNo", "TEST000001");
//			m.put("PartRevision", "B");
//			m.put("id", "47604.45839.53060.38082");
//			mlCATDrawings.add(m);
			

			// if Drawing Type is CAT Drawing, file format that it will be passed is CGM & Auto DWG where is Derived Output.
			for (int i = 0; i < mlCATDrawings.size(); i++) {

				Map obj2DMap = (Map)mlCATDrawings.get(i);
				String strDrawingId = (String) obj2DMap.get(DomainObject.SELECT_ID);
				
				
				String strPartNo = (String) obj2DMap.get("PartNo");
				String strPartRevision = (String) obj2DMap.get("PartRevision");
				

				if (StringUtils.isEmpty(strPartNo) || StringUtils.isEmpty(strPartRevision))
					continue;
				
				
				String strDerivedOutput = StringUtils.trimToEmpty(MqlUtil.mqlCommand(context, "print bus $1 select $2 dump", new String[] { strDrawingId, "from[" + cdmConstantsUtil.RELATIONSHIP_DERIVED_OUTPUT + "|to.format=='CGM'].to.id" }));

				if (StringUtils.isEmpty(strDerivedOutput))
					continue;

				DomainObject outputObj = new DomainObject(strDerivedOutput);
				FileList outFileList = outputObj.getFiles(context);
				

				outputObj.checkoutFiles(context, false, "CGM", outFileList, strWorkspace);
				
				
				// change file name to PartNo_PartRevision like "BC100A1100_A.cgm"
				for (Iterator iterator = outFileList.iterator(); iterator.hasNext();) {
					matrix.db.File objectFile = (matrix.db.File) iterator.next();

					String strFileName = objectFile.getName();
					String strNewFileName = strPartNo + "_" + strPartRevision + "." + strFileName.replaceAll(".+\\.", "");

					java.io.File physicalFile = new java.io.File(strWorkspace + "/" + strFileName);
					if (physicalFile.exists())
						physicalFile.renameTo(new java.io.File(strWorkspace + "/" + strNewFileName));
					
				}
				
				
				try{
					FileList fileList = outputObj.getFiles(context, "DWG");
					if(fileList.size() != 0){

						outputObj.checkoutFiles(context, false, "DWG", outFileList, strWorkspace);
	
						String strZipFileName = strPartNo+"_"+strPartRevision+ ".zip";
						
						
						cdmEC_mxJPO cdmEc = new cdmEC_mxJPO();
						cdmEc.compressDwgFile(strWorkspace, strZipFileName, outFileList);
						
					}
				}catch(Exception e){
					e.printStackTrace();
				}
				
				
			}

			
			
			
			// get AutoCAD or NX Drawing or STEP Files
			for (int i = 0; i < mlAutoCadNXDrawings.size(); i++) {

				
				Map obj2DMap = (Map)mlAutoCadNXDrawings.get(i);
				String strDrawingId = (String) obj2DMap.get(DomainObject.SELECT_ID);
				
				
				String strPartNo = (String) obj2DMap.get("PartNo");
				String strPartRevision = (String) obj2DMap.get("PartRevision");
				
				
				if (StringUtils.isEmpty(strPartNo) || StringUtils.isEmpty(strPartRevision))
					continue;
				
				
				DomainObject domDrawing = new DomainObject(strDrawingId);
				FileList fileList = domDrawing.getFiles(context);

				domDrawing.checkoutFiles(context, false, "generic", fileList, strWorkspace);
				
				
				// change file name to PartNo_PartRevision like "BC100A1100_A.dwg"
				for (Iterator iterator = fileList.iterator(); iterator.hasNext();) {
					matrix.db.File objectFile = (matrix.db.File) iterator.next();

					String strFileName = objectFile.getName();
					String strNewFileName = strPartNo + "_" + strPartRevision + "." + strFileName.replaceAll(".+\\.", "");

					java.io.File physicalFile = new java.io.File(strWorkspace + "/" + strFileName);
					if (physicalFile.exists())
						physicalFile.renameTo(new java.io.File(strWorkspace + "/" + strNewFileName));
				}
				
			}
			
			String strSiteName = ecDomObj.getInfo(context, "attribute[cdmSiteName]");
			if(StringUtils.isEmpty(strSiteName)) {
				strSiteName = "MDK";
			}
			
			String KEY_PLM_FTP_SERVER 		= strSiteName + "_" + "FTP_SERVER";
			String KEY_PLM_FTP_ID 			= strSiteName + "_" + "FTP_ID";
			String KEY_PLM_FTP_PASSWORD 	= strSiteName + "_" + "FTP_PASSWORD";
			String KEY_PLM_FTP_HOME 		= strSiteName + "_" + "FTP_HOME";
			
			String PLM_FTP_SERVER 			= cdmPropertiesUtil.getPropValue("FTP.properties", KEY_PLM_FTP_SERVER);
			String PLM_FTP_ID 				= cdmPropertiesUtil.getPropValue("FTP.properties", KEY_PLM_FTP_ID);
			String PLM_FTP_PASSWORD 		= cdmPropertiesUtil.getPropValue("FTP.properties", KEY_PLM_FTP_PASSWORD);
			String PLM_FTP_DERECTORY 		= cdmPropertiesUtil.getPropValue("FTP.properties", KEY_PLM_FTP_HOME);
			
			
//			String PLM_FTP_SERVER 		= cdmPropertiesUtil.getPropValue("FTP.properties", "MDK_FTP_SERVER");
//			String PLM_FTP_ID 			= cdmPropertiesUtil.getPropValue("FTP.properties", "MDK_FTP_ID");
//			String PLM_FTP_PASSWORD 	= cdmPropertiesUtil.getPropValue("FTP.properties", "MDK_FTP_PASSWORD");
//			String PLM_FTP_DERECTORY 	= cdmPropertiesUtil.getPropValue("FTP.properties", "MDK_FTP_HOME");
			
//			System.out.println("PLM_FTP_SERVER      " + PLM_FTP_SERVER);
//			System.out.println("PLM_FTP_ID          " + PLM_FTP_ID);
//			System.out.println("PLM_FTP_PASSWORD    " + PLM_FTP_PASSWORD);
//			System.out.println("PLM_FTP_DERECTORY   " + PLM_FTP_DERECTORY);

			cdmFTPUtil.FTPFileUpload(PLM_FTP_SERVER, PLM_FTP_ID, PLM_FTP_PASSWORD, strWorkspace, PLM_FTP_DERECTORY);//"/FILE/PLM_File/"
			System.out.println("================================== FTP FILE UPLOAD ==================================");
			
			
			//context.deleteWorkspace();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
	}
	
	
	
	
	
	
	/**
	 * export parts to PLM System DCR state Trigger
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
//	@SuppressWarnings({"rawtypes"})
//	public int setPLMExportPromote(Context context, String[] args) throws Exception {
//		String strDcrObjectId = args[0];
//		String strCurrent 		= "";
//
//		try {
//			ContextUtil.startTransaction(context, true);
//			DomainObject domDcrObj = new DomainObject(strDcrObjectId);
//
//			StringList objectSelects = new StringList();
//			objectSelects.add(DomainConstants.SELECT_ID);
//			objectSelects.add(DomainConstants.SELECT_CURRENT);
//
//			MapList mlDcrObjectList = domDcrObj.getRelatedObjects(context, 
//																  DomainConstants.RELATIONSHIP_AFFECTED_ITEM, // Relationship
//																  cdmConstantsUtil.TYPE_CATDrawing,  // From Type name
//																  objectSelects, // objects Select
//																  null, // Rel selects
//																  false,// to Direction
//																  true, // from Direction
//																  (short) 1, // recusion level
//																  "", 
//																  "", 
//																  0);
//
//			if (mlDcrObjectList != null) {
//				for (int i = 0; i < mlDcrObjectList.size(); i++) {
//					Map childMap 	= (Map) mlDcrObjectList.get(i);
//					strCurrent 		= (String) childMap.get(cdmConstantsUtil.TEXT_CURRENT);
//				}
//			}
//
//			if (strDcrObjectId != null && !strCurrent.equals("RELEASED") && !strCurrent.equals("OBSOLOTE") && !strCurrent.equals("Released")) {
//				for (int i = 0; i < mlDcrObjectList.size(); i++) {
//					String id 		= "";
//					Map tempMap 	= (Map) mlDcrObjectList.get(i);
//					id = (String)tempMap.get("id");
//					DomainObject domItemsId = new DomainObject(id);
//
//					ContextUtil.pushContext(context, null, null, null);
//					MqlUtil.mqlCommand(context, "trigger off", new String[]{});
//					
//					domItemsId.promote(context);
//					
//					MqlUtil.mqlCommand(context, "trigger on", new String[]{});
//					ContextUtil.popContext(context);
//				}
//			}
//			ContextUtil.commitTransaction(context);
//		} catch (Exception e) {
//			ContextUtil.abortTransaction(context);
//			e.printStackTrace();
//			throw e;
//		}
//		return 0;
//	}

	/**
	 * Code Search Created.2016.08.30
	 */
	@SuppressWarnings("deprecation")
	@com.matrixone.apps.framework.ui.ProgramCallable
	public String setCodeField(Context context, String[] args) throws Exception {
		Date date = new Date();
		SimpleDateFormat sdfYear = new SimpleDateFormat("yyyy-");
		String strYear = sdfYear.format(date);
		
		StringBuffer sbReturnString = new StringBuffer();
		int strNumber = Integer.parseInt(MqlUtil.mqlCommand(context, "print bus 'eService Number Generator' 'cdmECNumberGenerator' 'cdmEC' select attribute.value dump;"));
		String strName = "X-"+strYear+String.format("%05d", strNumber);

		sbReturnString.append("<input type=\"text\"  name=\"Code\" id=\"Code\" width=\"30\" readOnly=\"true\" value =\"" + strName + "\" >");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"checkbox\" name=\"btnRelatedECR\" value=\"Auto name\" checked=\"checked\" onclick=\"return false\" > Auto Name");
		sbReturnString.append("</input>");

		return sbReturnString.toString();
	}

	@SuppressWarnings("rawtypes")
	@com.matrixone.apps.framework.ui.ProgramCallable
	public String setProjectField(Context context, String[] args) throws Exception {

		String strProjectId = "";
		String projectName = cdmOwnerRolesUtil.getDefaultProject(context, context.getUser());
		String organizationName = cdmOwnerRolesUtil.getDefaultOrganization(context, context.getUser());

		String strProject = DomainConstants.EMPTY_STRING;
		if (!"".equals(projectName) && !"".equals(organizationName)) {
			strProject = projectName + " - " + organizationName;
			Map projectsMap = cdmOwnerRolesUtil.getProjectValues(context, projectName, organizationName);
			strProjectId = StringUtils.trimToEmpty((String) projectsMap.get(DomainConstants.SELECT_ID));
		}

		if (DomainConstants.EMPTY_STRING.equals(strProjectId)) {
			strProject = DomainConstants.EMPTY_STRING;
		}

		StringBuffer sbReturnString = new StringBuffer();
		sbReturnString.append("<input type=\"text\"  name=\"Project\" id=\"Project\" value=\"" + strProject + "\" width=\"30\" readOnly=\"true\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"button\" name=\"btnRelatedECR\" value=\"...\" onclick=\"javascript:window.open('../common/cdmPartLibraryChooser.jsp?fieldName=Project&amp;callbackFunction=showVehicleFocus&amp;header=emxEngineeringCentral.header.ProjectGroup&amp;multiSelect=false&amp;ShowIcons=true&amp;searchMode=ProjectGroup&amp;program=cdmPartLibrary:getProjectGroupFirstNode&amp;expandProgram=cdmPartLibrary:expandProjectGroupLowLankNode&amp;isFromSearch=false&amp;isNeededOId=false&amp;");
		sbReturnString.append("StringResourceFileId=emxEngineeringCentralStringResource&amp;displayKey=name&amp;rootNode=ProjectGroup&amp;fieldNameActual=ProjectGroup&amp;fieldNameDisplay=ProjectGroupDisplay&amp;fromPage=ProjectGroupForm&amp;firstLevelSelect=false&amp;secondLevel=false&amp;processURL=../engineeringcentral/cdmProjectSearchProcess.jsp', '', 'width=400', 'height=300')\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"hidden\" name=\"ProjectOID\" value=\"" + strProjectId + "\">");
		sbReturnString.append("</input>");

		return sbReturnString.toString();
		
	}

	/**
	 * CodeSearch Process for authority
	 * 
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "static-access" })
	@com.matrixone.apps.framework.ui.ExcludeOIDProgramCallable
	public StringList slCheckRelationship(Context context, String[] args) throws Exception {
		String strObjectId = "";
		StringList objectList = new StringList();
		try {
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_RELATIONSHIP_NAME);
			
			DomainObject domUserObj = new DomainObject();

	        StringBuffer strTypeBuffer = new StringBuffer();
	        strTypeBuffer.append(cdmConstantsUtil.TYPE_CATDrawing).append(",");
	        strTypeBuffer.append(cdmConstantsUtil.TYPE_CDMNXDRAWING).append(",");
	        strTypeBuffer.append(cdmConstantsUtil.TYPE_CDMAUTOCAD).append(",");
			
			StringBuffer strWhereBuffer = new StringBuffer();
	        strWhereBuffer.append("from[*");
	        //strWhereBuffer.append(EngineeringConstants.RELATIONSHIP_AFFECTED_ITEM);
	        strWhereBuffer.append("].id");
	        strWhereBuffer.append("!=");
	        strWhereBuffer.append("''");
			
			MapList mlRelCheck = domUserObj.findObjects(context, strTypeBuffer.toString(), DomainConstants.QUERY_WILDCARD, strWhereBuffer.toString(), objectSelects);
					

			for (int i = 0; i < mlRelCheck.size(); i++) {
				Map tempMap = (Map) mlRelCheck.get(i);
				strObjectId = (String) tempMap.get("id");

				objectList.add(strObjectId);
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return objectList;
	}

	/**
	 * Validation Check for Export
	 * 
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String exportValidate(Context context, String[] args) throws Exception {
		try {
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String strExportObjectId = (String) paramMap.get("objectId");
			String strWhere = "revision==last";

			DomainObject exportDObject = new DomainObject(strExportObjectId);

			// EC Part Check Start.
			MapList mlExportObjectList = new MapList();
			StringList objectSelects = new StringList();
			objectSelects.add(DomainConstants.SELECT_NAME);
			objectSelects.add(DomainConstants.SELECT_ID);
			objectSelects.add(DomainConstants.SELECT_RELATIONSHIP_NAME);
			objectSelects.add(DomainConstants.SELECT_REVISION);
			objectSelects.add("to[Associated Drawing].from.id");

			mlExportObjectList = exportDObject.getRelatedObjects(context, 
																 DomainConstants.RELATIONSHIP_AFFECTED_ITEM, // Relationship
																 "*", // From Type name
																 objectSelects, // objects Select
																 null, // Rel selects
																 false, // to Direction
																 true, // from Direction
																 (short) 1, // recusion level
																 strWhere, // where
																 "", 
																 0);

			// 2D Unlcok Check & Series Revision Check
			StringBuffer sbDrawingCheck = new StringBuffer(" ");
			StringBuffer sbRevisionCheck = new StringBuffer(" ");

			String strDrawingObjectName = "";
			String strPartRevision = "";
			String strDrawingId = "";
			String strSeriesRevision = "";
			String strSeriesName = "";
			String strPartCheck = "";

			
			// Validation start
			for (int i = 0; i < mlExportObjectList.size(); i++) {
				Map parentList = (Map) mlExportObjectList.get(i);
				strDrawingObjectName = (String) parentList.get("name");
				strPartRevision = (String) parentList.get("revision");
				strDrawingId = (String) parentList.get("id");
				strPartCheck = (String) parentList.get("to[Associated Drawing].from.id");
				
				// CAT Drawing, CAT Part. Locked --> Unlocked
				if (strDrawingObjectName == null || strPartCheck == null) {
					sbDrawingCheck.append("This object has no Drawing.\\n Please add to Drawing object.\\n\\n Object Name : " + strDrawingObjectName);
					return sbDrawingCheck.toString();
				} else {
					ContextUtil.pushContext(context, null, null, null);
					MqlUtil.mqlCommand(context, "trigger off", new String[]{});
					
					MqlUtil.mqlCommand(context, "unlock bus " + strPartCheck);
					MqlUtil.mqlCommand(context, "unlock bus " + strDrawingId);
					
					MqlUtil.mqlCommand(context, "trigger on", new String[]{});
					ContextUtil.popContext(context);
				}

				if (!"".equals(strDrawingId) && null != strDrawingId) {
					DomainObject domDrawingObj = new DomainObject(strDrawingId);

					MapList mlSeriesObjectList = new MapList();
					StringList seriesSelects = new StringList();

					seriesSelects.add(DomainConstants.SELECT_NAME);
					seriesSelects.add(DomainConstants.SELECT_REVISION);

					mlSeriesObjectList = domDrawingObj.getRelatedObjects(context, DomainConstants.RELATIONSHIP_PART_SPECIFICATION, // Relationship
							"*", // From Type name
							seriesSelects, // objects Select
							null, // Rel selects
							true, // to Direction
							false, // from Direction
							(short) 1, // recusion level
							strWhere, "", 0);

					for (int j = 0; j < mlSeriesObjectList.size(); j++) {
						Map seriesMap = (Map) mlSeriesObjectList.get(j);
						strSeriesName = (String) seriesMap.get("name");
						strSeriesRevision = (String) seriesMap.get("revision");

						if (!strPartRevision.equals(strSeriesRevision)) {
							sbRevisionCheck.append("Revisions do not match.\\n \\n Name : " + strSeriesName + " \\n Revision : " + strSeriesRevision);
							return sbRevisionCheck.toString();
						}
					}
				}

				StringBuffer sbParentList = new StringBuffer("");
				String strValuemlExportObject = "";
				String strObject = "";
				String strParentName = "";

				if (mlExportObjectList.size() > 0) {

					for (int j = 0; j < mlExportObjectList.size(); j++) {
						Map mlExportObjectMap = (Map) mlExportObjectList.get(j);
						strParentName = (String) mlExportObjectMap.get(cdmConstantsUtil.SELECT_NAME);
						Iterator iterParentObject = mlExportObjectMap.keySet().iterator();

						while (iterParentObject.hasNext()) {
							strObject = (String) iterParentObject.next();
							strValuemlExportObject = (String) mlExportObjectMap.get(strObject);

							if (cdmStringUtil.isEmpty(strValuemlExportObject)) {
								strObject = strObject.replaceAll("attribute", "");
								strObject = strObject.replaceAll("\\[", "");
								strObject = strObject.replaceAll("\\]", "");
								String strFieldRangeValues = EnoviaResourceBundle.getProperty(context, cdmConstantsUtil.TEXT_EMX_ENGINEERING_CENTRAL_STRING_RESOURCE, context.getSession().getLocale(), "emxEngineeringCentral.Label." + strObject);
								sbParentList.append(" Invalid Value : " + strFieldRangeValues + "\\n ");
							}
						}
						if (cdmStringUtil.isNotEmpty(sbParentList.toString())) {
							sbParentList.insert(0, " Check Properties. \\n \\n Object Name : " + strParentName + "\\n ");
							return sbParentList.toString();
						}
					}
				}
			}

			// EC Part Check End.

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return "Success";
	}
}
