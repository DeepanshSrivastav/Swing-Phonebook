import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.PropertyResourceBundle;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.mando.util.cdmCommonExcel;
import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkProperties;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.SelectList;
import matrix.util.StringList;

/**
 * 
 * @author mj ' cdmCommonCode' Migration JPO
 * 
 *         1.main 메서드 2.엑셀을 통한 데이타 삽입
 * 
 */
public class cdmCommonCodeMigration_mxJPO {

//	private Date date = new Date();
//	private SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
//	private String sDate = sdf.format(date);
	
	
	public static final String sOutput_Directory       = "MIGRATION_LOGS";
	public static final String sCommoncodeType        = "cdmCommonCode"; 
	public static final String sCommoncodeRel         = ""; 
	
	public static final String sfileSeparator 		  = "\\";
//	public static final String S_MIGRATION_PROPERTIES = "cdmMigrationStringResource";

	/** **********************************************************************
	 * object 생성여부 확인 
	 * 값이 있다면 object 의 id 값return, 값이 없다면 "" return  
	 * 
	 * @param context
	 * @param type
	 * @param name
	 * @param revision
	 * @param owner
	 * @param vault
	 * @param where
	 * @param selectList
	 * @return
	 * ********************************************************************** */
	private String uniqueCommonCodeAttribute(Context context, String type, String name, String revision, String owner, String vault, String where, SelectList selectList) {
		// TODO Auto-generated method stub
		String result = "";
		try {
			if (cdmStringUtil.isEmpty(type)) {
				type = cdmConstantsUtil.QUERY_WILDCARD;
			}
			if (cdmStringUtil.isEmpty(name)) {
				name = cdmConstantsUtil.QUERY_WILDCARD;
			}
			if (cdmStringUtil.isEmpty(revision)) {
				revision = cdmConstantsUtil.QUERY_WILDCARD;
			}
			if (cdmStringUtil.isEmpty(owner)) {
				owner = cdmConstantsUtil.QUERY_WILDCARD;
			}
			if (cdmStringUtil.isEmpty(vault)) {
				vault = cdmConstantsUtil.QUERY_WILDCARD;
			}
			if (cdmStringUtil.isEmpty(where)) {
				where = "";
			}
			if (selectList == null) {
				SelectList selectList2 = new SelectList();
				selectList2.addId();
				selectList = selectList2;
			}

			MapList findUniqueMapList = DomainObject.findObjects(context, cdmConstantsUtil.TYPE_CDMCOMMONCODE, // type
					name, // name
					revision, // rev
					owner, // owner
					vault, // vault
					where, // where
					false, // expand
					selectList); // selectb

			if (findUniqueMapList.size() > 0) {
				for (int i = 0; i < findUniqueMapList.size(); i++) {
					Map findUniqueMap = (Map) findUniqueMapList.get(i);
					String stFindUnique = (String) findUniqueMap.get("id");

					result = stFindUnique;
					break;
				}

			} else {
				result = "";
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	


	/**
	 * common object 삭제
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void deleteAllCommonCode(Context context, String args[]) throws Exception {
		try {

			/* 
			 * CommonCode  1 level  object 의 attribute[cdmCommonCode] 정보 
			 * customer,product Name,Org1,Vehicle,Org3,Org2,
			 * Project,Product Div,Product Group Type,
			 * Option3,Option1,Option2,Option5,Option6,Option4
			 * 
			 */
			
			String sRelationship = "cdmCommonCodeRelationship";
			String lev1CommonCodeMql = "temp query bus cdmCommonCode * * where name==CommonCodeRoot select from[" + sRelationship + "].to.id dump |";
			String lev1MqlResult = MqlUtil.mqlCommand(context, lev1CommonCodeMql);
			StringList stListTest = new StringList();

			StringList lev1StList = FrameworkUtil.split(lev1MqlResult, "|");
			
			if (lev1StList.size() > 2) {

				for (int lev1Num = 3; lev1Num < lev1StList.size(); lev1Num++) {
					String lev1Id = (String) lev1StList.get(lev1Num);
				
					
					String mql = "expand bus " + lev1Id + " from relationship " + sRelationship + " recurse to all select bus id attribute[cdmCommonCode] dump |";
					String mqlResult = MqlUtil.mqlCommand(context, mql);

					StringTokenizer tokenMqlResult = new StringTokenizer(mqlResult, "\n");
					stListTest.add(mqlResult);
					while (tokenMqlResult.hasMoreTokens()) {

						String stMqlResult = (String) tokenMqlResult.nextToken();
						StringList stListResult = null;
						stListResult = FrameworkUtil.split(stMqlResult, "|");

						String childId = (String) stListResult.get(6);
						DomainObject deleteObj = new DomainObject(childId);
						deleteObj.deleteObject(context);
					}
								
				}
				

				for (int lev1Num = 3; lev1Num < lev1StList.size(); lev1Num++) {
					String lev1Id = (String) lev1StList.get(lev1Num);
					DomainObject deleteObj = new DomainObject(lev1Id);
					deleteObj.deleteObject(context);

				}
		
			}
//			System.out.println(stListTest);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * Screen sheeet 에서 common Code lev1 생성 [type:cdmCommonCode name:autoName으로 생성 rev:-]
	 * 
	 * cell 0: 순번 
	 * cell 1: NameCode // attribute[cdmCommonCodeNameEn],attribute[cdmCommonCodeNameKo],attribute[cdmCommonCodeNameCn]
	 * cell 2: attribute[cdmCommonCode]
	 * cell 3: cdmCommonCode // 데이타 정보가 있으면 cell 2 정보 대신 사용 
	 * 엑셀 시트명 :Screen
	 * 
	 * DESCIRPTION: ROW 정보가 NULL 이면 에러 ,필수CELL 정보가 없으면 에러 
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void createScreenCommonCode(Context context, String args[]) throws Exception {
		Long startTime = System.currentTimeMillis();
		System.out.println("cdmCommonCodeMigration_mxJPO : createScreenCommonCode start"+cdmCommonExcel.getTimeStamp2());
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		
		String logFileName 				= "createScreenCommonCode";
		if(args.length != 1){
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		String tempFileAndLocation = args[0];
		
		String commonCodeFilePath = "";
		String commonCodeFileName = "";
		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
		
//		Map paramMap = (Map)JPO.unpackArgs(args);
//		String commonCodeFilePath = (String)paramMap.get("File_Location");
//		String commonCodeFileName = (String)paramMap.get("File");
		if(cdmStringUtil.isEmpty(commonCodeFilePath) || cdmStringUtil.isEmpty(commonCodeFileName)){
			String errorMessage = "The file to read does not exist.";
			throw new Exception(errorMessage);
		}
		
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명,읽을 메인 시트명
//		String[] sTempArgs = {"C:\\temp\\Import_File\\COMMONCODE","20160907_LIBv02.xlsx"};
//		String[] sTempArgs = {"C:\\temp\\Import_File\\COMMONCODE","2016_1122_1513_LIB_정리_v02_1125.xlsx"};
//		String[] sTempArgs = {"C:\\temp\\Import_File\\COMMONCODE","2016_1122_1513_LIB_v02.xlsx"};
//		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};

		inputDirectory  = commonCodeFilePath;
		fileName 		= commonCodeFileName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
			inputDirectory = inputDirectory + sfileSeparator;
		}
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + sOutput_Directory + sfileSeparator + logFileName + "_" + cdmCommonExcel.getTimeStamp() + sfileSeparator;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));
		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(successObjectidWriter,"====================================================================================");
		multiWriteMessageToFile(successObjectidWriter,"     COMMONCODE DATA MIGRATION  START TIME:"+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(successObjectidWriter,"		Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(successObjectidWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(successObjectidWriter,"====================================================================================\n");
		boolean bCheckTriggerOff = false;
		MqlUtil.mqlCommand(context, "Trigger Off");
		bCheckTriggerOff = true;
		int totalCount = 0;
		int failCount 	= 0;
		int successCount = 0;
		String sPhysicalNumberRows = "1";
		
		String sRecordTempNumber			 = "";
		String sRecordTempCommonCodeName  	= "";
		String sRecordTempCommonCode 	 	= "";
		String sRecordTempTempCommonCode	 = "";
		try {
			String sheetName = "Screen";
			Sheet sheet = (Sheet) cdmCommonExcel.getXssfSheet2(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalCount = physicalNumberRows -1 ;
			
			DomainObject commonCodeRootDObj = new DomainObject();
			String findRoot = "temp query bus \"cdmCommonCode\"  \"CommonCodeRoot\"  \"-\" select id dump |";
			String findRootMql = MqlUtil.mqlCommand(context, findRoot);
			if(cdmStringUtil.isEmpty(findRootMql)){
				commonCodeRootDObj.createObject(context, "cdmCommonCode", "CommonCodeRoot", "-", "cdmCommonCodePolicy", "eService Production");
			}
			for (int i = 1; i <= physicalNumberRows; i++) {
				Row row = sheet.getRow(i);
			
				try{
					if (row == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL) +\t 1";
						throw new Exception(errorMessage);
					}
					
				
					sPhysicalNumberRows = String.valueOf(i);
				/*
				 *  cell_0 은 순번
				 *  cell_1 은 attribute[cdmCommonCodeNameEn],attribute[cdmCommonCodeNameKo],attribute[cdmCommonCodeNameCn] 
				 *  cell_2 은 attribute[cdmCommonCode]
				 *  cell_3 은 attribute[cdmCommonCode] (데이타가 있으면  cell_2 의 데이타 무시 )
				 */
				
				Cell cell_0 = row.getCell(0);
				Cell cell_1 = row.getCell(1);
				Cell cell_2 = row.getCell(2);
				Cell cell_3 = row.getCell(3);

				if (cell_0 == null && cell_1 == null && cell_2 == null){
					String errorMessage = "NOT MAKE COMMONCODE. NOT EXIST DATA INFO. \t 2";
					throw new Exception(errorMessage);
				}
				
				String stNumber			 	= cdmCommonExcel.isVaildNullData(getCellValue2(cell_0));
				String stCommonCodeName 	= cdmCommonExcel.isVaildNullData(getCellValue2(cell_1));
				String stCommonCode 		= cdmCommonExcel.isVaildNullData(getCellValue2(cell_2));
				String stTempCommonCode		= cdmCommonExcel.isVaildNullData(getCellValue2(cell_3));
				
				
				sRecordTempNumber 			 = stNumber;
				sRecordTempCommonCodeName  	 = stCommonCodeName;
				sRecordTempCommonCode 	 	 = stCommonCode;
				sRecordTempTempCommonCode	 = stTempCommonCode;
				
				if(cdmStringUtil.isNotEmpty(stTempCommonCode)){
					stCommonCode = stTempCommonCode;
				}
				
				Map requestArgs2 = new HashMap();
				requestArgs2.put("Name", stCommonCode);
				requestArgs2.put("codeKo", stCommonCodeName);
				requestArgs2.put("codeEn", stCommonCodeName);
				requestArgs2.put("codeCn", stCommonCodeName);
				requestArgs2.put("checkMigration", "Y");
				requestArgs2.put("objectId", "");
				
				
				String sWhere = "attribute[cdmCommonCode]=='"+stCommonCode+"'  && attribute[cdmCommonCodeNameKo]=='"+stCommonCodeName+"' && attribute[cdmCommonCodeNameEn]=='"+stCommonCodeName+"' && attribute[cdmCommonCodeNameCn]=='"+stCommonCodeName+"' && to[cdmCommonCodeRelationship].from.name=='CommonCodeRoot'"; 
				String isCommonCodeMql = "temp query bus \"cdmCommonCode\" * * where \"" + sWhere+"\" select id "; 
				String isCommonCodeMqlResult = MqlUtil.mqlCommand(context, isCommonCodeMql);
//				if(cdmStringUtil.isEmpty(isCommonCodeMqlResult)){
				if(UIUtil.isNullOrEmpty(isCommonCodeMqlResult)){
					Map createdCommonCodeMap = (Map) JPO.invoke(context, "cdmCommonCodeMigration", null, "createObject", JPO.packArgs(requestArgs2), Map.class);  
//					System.out.println("createdCommonCodeMap"+createdCommonCodeMap);
					if(cdmStringUtil.isEmpty(createdCommonCodeMap.toString())){
						String errorMessage = "not make commonCode object";
						throw new Exception(errorMessage);
					}
				}else{
					String errorMessage = "already commonCode object. not create. \t"+"3";
					throw new Exception(errorMessage);
				}
				successCount++;
				successObjectidWriter.write(" SUCESS!!. LINE NUMBER: \t" + stNumber +" \t COMMONCODE NAME: \t"+stCommonCodeName+" \t COMMONCODE: \t"+stCommonCode+" \n");
				}catch(Exception e1){
					failCount++;
					multiWriteMessageToFile(failedObjectidWriter, sPhysicalNumberRows+"\t"+sRecordTempNumber+"\t"+sRecordTempCommonCodeName+"\t"+sRecordTempCommonCode+"\t"+sRecordTempTempCommonCode+"\t");
					mulitWriteErrorToFile(errorStream, "LINE NUMBER: " + sPhysicalNumberRows + " \t Exception: " + e1.getMessage());
					e1.printStackTrace(errorStream);
				}
			}
			multiWriteMessageToFile(successObjectidWriter, "====================================================================================");
			multiWriteMessageToFile(successObjectidWriter, "        File COMMONCODE Migration COMPLETED.                    ");
			multiWriteMessageToFile(successObjectidWriter, "====================================================================================\n");
		} catch (Exception e) {
			
			mulitWriteErrorToFile(errorStream, "LINE NUMBER: \t" + String.valueOf(sPhysicalNumberRows) + " \t Exception: " + e.getMessage());
			e.printStackTrace(errorStream);
			
		} finally {
			int totalCounts = successCount+failCount;
			multiWriteMessageToFile(successObjectidWriter, "====================================================================================");
			multiWriteMessageToFile(successObjectidWriter, "COMMON CODE MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() +"                  ");
			multiWriteMessageToFile(successObjectidWriter, "LEAD TIME:" + ((System.currentTimeMillis() - startTime)/1000)/60 + "ms                  ");
			multiWriteMessageToFile(successObjectidWriter,"	FAIL COUNT:("+ failCount + ")   SUCCESS COUNT:("+successCount+") TOTAL COUNT :("+totalCounts+")" );
			multiWriteMessageToFile(successObjectidWriter, "==================================================================================== \n");
			if(bCheckTriggerOff){
				MqlUtil.mqlCommand(context, "Trigger On");
			}
			try {

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				
				
				
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

			System.out.println("cdmCommonCodeMigration_mxJPO : createScreenCommonCode  END" +cdmCommonExcel.getTimeStamp2() );
		}
	}

	/**
	 * Customer 하위 common code 생성
	 * 
	 * object name 값이 CommonCodeRoot 인 object 와 연결된 attribute[cdmCommonCode]값이 
	 * customer 인 object의 하위에 생성된다.
	 * 데이타를 생성할때 attribute[checkMigration] 의 값을 Y로 설정한다.
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void createCustomerCommonCode(Context context, String args[]) throws Exception {
		System.out.println("cdmCommonCodeMigration_mxJPO : createCustomerCommonCode--> start "+cdmCommonExcel.getTimeStamp2());

		Long startTime = System.currentTimeMillis();
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String logFileName = "createCustomerCommonCode";
		
//		Map paramMap = (Map)JPO.unpackArgs(args);
		if(args.length != 1){
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		String tempFileAndLocation = args[0];
		//String commonCodeFilePath = (String)paramMap.get("File_Location");
		String commonCodeFilePath = "";
		String commonCodeFileName = "";
		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
		
//		String commonCodeFilePath = (String)paramMap.get("File_Location");
//		String commonCodeFileName = (String)paramMap.get("File");
		if(cdmStringUtil.isEmpty(commonCodeFilePath) || cdmStringUtil.isEmpty(commonCodeFileName)){
			String errorMessage = "The file to read does not exist.";
			throw new Exception(errorMessage);
		}
		
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명,읽을 메인 시트명
//		String[] sTempArgs = {"C:\\temp\\Import_File\\COMMONCODE","20160907_LIBv02.xlsx"};
//		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
	
		
		inputDirectory  = commonCodeFilePath;
		fileName		= commonCodeFileName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
			inputDirectory = inputDirectory + sfileSeparator;
		}
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + sOutput_Directory + sfileSeparator + logFileName + "_" + cdmCommonExcel.getTimeStamp() + sfileSeparator;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"     COMMONCODE DATA MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		boolean bCheckTriggerOff = false;
		MqlUtil.mqlCommand(context, "Trigger Off");
		bCheckTriggerOff = true;
		String sheetName = "Customer";
		String sPhysicalNumberRows  = "2"; 
		
		int totalCount = 0;
		int failCount = 0;
		int successCount = 0;
		String stRecordNumber = "";
		String stRecordCommonCodeName = "";
		try {
			
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalCount = physicalNumberRows-2;
			SelectList seletList = new SelectList();
			seletList.addId();
			seletList.add("attribute[cdmCommonCode]");
			
			/*commoncode의 레벨2 검색 */
			String stWhere = "attribute[cdmCommonCode]=='Customer' && to[cdmCommonCodeRelationship].from.name==CommonCodeRoot";
			MapList findCustomerMapList = DomainObject.findObjects(context, cdmConstantsUtil.TYPE_CDMCOMMONCODE, // type
					cdmConstantsUtil.QUERY_WILDCARD, // name
					cdmConstantsUtil.QUERY_WILDCARD, // rev
					cdmConstantsUtil.QUERY_WILDCARD, // owner
					cdmConstantsUtil.QUERY_WILDCARD, // vault
					stWhere, // where
					false, // expand
					seletList); // selectbus
			
			String stCustomerId = "";
			for (int i = 0; i < findCustomerMapList.size(); i++) {
				Map findCustomerMap = (Map) findCustomerMapList.get(i);
				stCustomerId = (String) findCustomerMap.get("id");
				break;
			}
			for (int i = 1; i <= physicalNumberRows; i++) {
				
				XSSFRow row = sheet.getRow(i);
				
				try{
				
					if (row == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL) \t 0";
						throw new Exception(errorMessage);
					}
				
					sPhysicalNumberRows = String.valueOf(i+1);
					/*
					 * cell_0 은 순번 
					 * cell_1 은 cdmCommonCodeNameEn 
					 * cell_2 은
					 * cdmCommonCodeNameKo,cdmCommonCodeNameCn,cdmCommonCodeNameEn,Name 
					 */

					XSSFCell cell_0 = row.getCell(0);
					XSSFCell cell_1 = row.getCell(1);
	
					if (cell_0 == null || cell_1 == null)
						continue;
	
					String stNumber			= cdmCommonExcel.isVaildNullData(getCellValue(cell_0));  
					String stCommonCodeName = cdmCommonExcel.isVaildNullData(getCellValue(cell_1));
					
					stRecordNumber		= stNumber;
					stRecordCommonCodeName = stCommonCodeName;
				
					Map requestArgs2 = new HashMap();
					requestArgs2.put("objectId", stCustomerId);
					requestArgs2.put("Name", stCommonCodeName);
					requestArgs2.put("codeKo", stCommonCodeName);
					requestArgs2.put("codeEn", stCommonCodeName);
					requestArgs2.put("codeCn", stCommonCodeName);
					requestArgs2.put("checkMigration", "Y");
					
//					Map createdCommonCodeMap = (Map) JPO.invoke(context, "cdmCommonCode", null, "createObject", JPO.packArgs(requestArgs2), Map.class);
					Map createdCommonCodeMap = (Map) JPO.invoke(context, "cdmCommonCodeMigration", null, "createObject", JPO.packArgs(requestArgs2), Map.class);
					if(cdmStringUtil.isEmpty(((String)createdCommonCodeMap.get("id")))){
						String errorMessage = "NOT CREATE CUSTOMER OBJECT. \t 1";
						throw new Exception(errorMessage);
					}
					multiWriteMessageToFile(successObjectidWriter, " SUCESS!!.  LINE NUMBER: \t" + sPhysicalNumberRows +"\t COUNT NUM: \t"+stNumber+" \t CREATE ATTRIBUTE NAME  : \t"+stCommonCodeName);
					multiWriteMessageToFile(logWriter, " SUCESS!!.  LINE NUMBER: \t" + sPhysicalNumberRows+"\t COUNT NUM: "+stNumber +"\t CREATE ATTRIBUTE NAME  : \t"+stCommonCodeName);
					successCount++;
					} catch (Exception e) {
						failCount++;
//						multiWriteMessageToFile(failedObjectidWriter, "EXCEPTION : LINE NUMBER: " + sPhysicalNumberRows);
						multiWriteMessageToFile(failedObjectidWriter, sPhysicalNumberRows+"\t"+stRecordNumber+"\t"+stRecordCommonCodeName);
						multiWriteMessageToFile(logWriter, "LINE NUMBER: " + sPhysicalNumberRows+" \t " + e.getMessage()  );
						mulitWriteErrorToFile(errorStream, "LINE NUMBER: " + sPhysicalNumberRows + "\t" + e.getMessage());
						e.printStackTrace(errorStream);
					}
				}

			multiWriteMessageToFile(logWriter, "====================================================================================");
			multiWriteMessageToFile(logWriter, "        File COMMONCODE Migration COMPLETED.                    ");
			multiWriteMessageToFile(logWriter, "====================================================================================\n");
		} catch (Exception e) {
			multiWriteMessageToFile(logWriter, "LINE NUMBER: " +sPhysicalNumberRows+ "\t"+ e.getMessage() );
//			mulitWriteErrorToFile(errorStream, "[${CLASSNAME} : createCustomerCommonCode] Exception occured.  LINE NUMBER: " + stNumber + "  " + e.getMessage());
			e.printStackTrace(errorStream);
		} finally {
			if(bCheckTriggerOff){
				MqlUtil.mqlCommand(context, "Trigger On");
			}
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, "LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms                  ");
			multiWriteMessageToFile(logWriter,"	FAIL COUNT:("+ failCount + ")   SUCCESS COUNT:("+successCount+") TOTAL COUNT :("+totalCount+")" );
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			System.out.println("${CLASS:dmCommonCodeMigration} : createCustomerCommonCode--> end. "+cdmCommonExcel.getTimeStamp2());
		}
	}

	/**
	 * Lib_Data sheet의 common code leve2 생성
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	public void createLibDataCommonCode(Context context, String args[]) throws Exception {
		System.out.println("cdmCommonCodeMigration : createLibDataCommonCode--> start "+cdmCommonExcel.getTimeStamp2());

		Long startTime = System.currentTimeMillis();
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String logFileName = "createLibDataCommonCode";
		
//		Map paramMap = (Map)JPO.unpackArgs(args);
//		String commonCodeFilePath = (String)paramMap.get("File_Location");
//		String commonCodeFileName = (String)paramMap.get("File");
		if(args.length != 1){
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		String tempFileAndLocation = args[0];
		String commonCodeFilePath = "";
		String commonCodeFileName = "";
		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);

		if(cdmStringUtil.isEmpty(commonCodeFilePath) || cdmStringUtil.isEmpty(commonCodeFileName)){
			String errorMessage = "The file to read does not exist.";
			throw new Exception(errorMessage);
		}
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명,읽을 메인 시트명
//		String[] sTempArgs = {"C:\\temp\\Import_File\\COMMONCODE","20160907_LIBv02.xlsx"};
		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
		if (sTempArgs.length!=2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory  = sTempArgs[0];
		fileName		= sTempArgs[1];
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
			inputDirectory = inputDirectory + sfileSeparator;
		}
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + sOutput_Directory + sfileSeparator + logFileName + "_" + cdmCommonExcel.getTimeStamp() + sfileSeparator;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter," lib COMMONCODE DATA MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"	Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"	Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		boolean bCheckTriggerOff = false;
		int failCount 	= 0;
		int successCount = 0;
		int totalCount = 0;
		
		String stRecordNumber 			    = "";
		String stRecordCommonCodeLev1Name   = "";
		String stRecordCommonCodeName 	    = "";
		String stRecordCommonCode 		    = "";
		String stRecordPromoteCheck 		= "";
		
		MqlUtil.mqlCommand(context, "Trigger Off");
		bCheckTriggerOff = true;
		String sheetName = "Lib_Data";
		String sPhysicalNumberRows = "2";
		try {
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalCount = physicalNumberRows-2;
			for (int physicalNumberRow = 1; physicalNumberRow < physicalNumberRows; physicalNumberRow++) {
				XSSFRow row = sheet.getRow(physicalNumberRow);
				try {
					if (row == null){
						String errorMessage = "NOT EXIST DATA. (ROW NULL) +\t 0";
						throw new Exception(errorMessage);
					}
					sPhysicalNumberRows = String.valueOf(physicalNumberRow);
					XSSFCell cell_0 = row.getCell(0);
					XSSFCell cell_1 = row.getCell(1);
					XSSFCell cell_2 = row.getCell(2);
					XSSFCell cell_3 = row.getCell(3);
					XSSFCell cell_4 = row.getCell(4);

					if (cell_0 == null && cell_1 == null)
						continue;

					String stNumber 				= cdmCommonExcel.isVaildNullData(getCellValue(cell_0));
					String stCommonCodeLev1Name 	= cdmCommonExcel.isVaildNullData(getCellValue(cell_1));
					String stCommonCodeName 		= cdmCommonExcel.isVaildNullData(getCellValue(cell_2));
					String stCommonCode 			= cdmCommonExcel.isVaildNullData(getCellValue(cell_3));
					String stPromoteCheck 			= cdmCommonExcel.isVaildNullData(getCellValue(cell_4));
					
					
					 stRecordNumber 			= stNumber;		
					 stRecordCommonCodeLev1Name = stCommonCodeLev1Name; 
					 stRecordCommonCodeName 	= stCommonCodeName ;
					 stRecordCommonCode 		= stCommonCode 	;
					 stRecordPromoteCheck 		= stPromoteCheck;
					
					SelectList seletList = new SelectList();
					seletList.addId();
					seletList.add("attribute[cdmCommonCode]");
					String lev1CommonCode = "";
					String stWhere = "attribute[cdmCommonCode]=='" + stCommonCodeLev1Name + "' && to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot'";
					String stFindLev1Id = "";

					String stFindLev1IdMql = MqlUtil.mqlCommand(context, "temp query bus \"cdmCommonCode\" *  * where \""+stWhere+"\" select id dump |");
					StringList stListFindLev1IdMqlResult = FrameworkUtil.split(stFindLev1IdMql, "|");
					if(stListFindLev1IdMqlResult.size()<2){
						/* **************************************************
						 * excel 파일에서 cell_1 필드는 COMMONCODE OBJECT 생성을
						 *  위한 필수 데이타이며 object 가 없다면 에러 발생.  
						 * ************************************************** */
						String errorMessage = "NOT EXIST COMMONCODE LEVEL 1 OBJECT.";
						throw new Exception(errorMessage);
					}
					stFindLev1Id = (String)stListFindLev1IdMqlResult.get(3);
					
					Map requestArgs = new HashMap();
					requestArgs.put("objectId"       , stFindLev1Id);
					requestArgs.put("Name"           , stCommonCode);
					requestArgs.put("codeKo"         , stCommonCodeName);
					requestArgs.put("codeEn"         , stCommonCodeName);
					requestArgs.put("codeCn"         , stCommonCodeName);
					requestArgs.put("checkMigration" , "Y");
					requestArgs.put("description" , "");
					
//					ContextUtil.startTransaction(context, true);
					Map createdCommonCodeMap = (Map) JPO.invoke(context, "cdmCommonCodeMigration", null, "createObject", JPO.packArgs(requestArgs), Map.class);
					
					String createCommonCodeId = (String) createdCommonCodeMap.get("id");
					
					if (UIUtil.isNotNullAndNotEmpty(stPromoteCheck) && "-1".equals(stPromoteCheck) && UIUtil.isNotNullAndNotEmpty(createCommonCodeId)) {
						DomainObject dObjCommonCode = new DomainObject();
						dObjCommonCode.setId(createCommonCodeId);
						dObjCommonCode.promote(context);

					}
//					ContextUtil.commitTransaction(context);
					multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. LINE NUMBER: \t" + sPhysicalNumberRows +",COUNT NUM: \t"+stNumber+"\t CREATE ATTRIBUTE NAME  :\t"+stCommonCodeName);
					multiWriteMessageToFile(logWriter, " SUCESS!!. LINE NUMBER: " + sPhysicalNumberRows+" \t COUNT NUM:"+stNumber);
					successCount++;
				}catch(Exception e1){
//					ContextUtil.abortTransaction(context);
					failCount++;
					multiWriteMessageToFile(failedObjectidWriter, sPhysicalNumberRows+"\t"+stRecordNumber +"\t"+stRecordCommonCodeLev1Name+"\t"+stRecordCommonCodeName +"\t"+stRecordCommonCode +"\t"+stRecordPromoteCheck +"\t");
					multiWriteMessageToFile(logWriter, "LINE NUMBER: " + sPhysicalNumberRows +"\t" +e1.getMessage()  );
					mulitWriteErrorToFile(errorStream, "LINE NUMBER: " + sPhysicalNumberRows + "\t" + e1.getMessage());
					e1.printStackTrace(errorStream);
				}
			}
			multiWriteMessageToFile(logWriter, "====================================================================================");
			multiWriteMessageToFile(logWriter, "        File COMMONCODE Migration COMPLETED.                    ");
			multiWriteMessageToFile(logWriter, "====================================================================================\n");
		} catch (Exception e) {
			multiWriteMessageToFile(logWriter, "LINE NUMBER: " + sPhysicalNumberRows + "\t" + e.getMessage());
			mulitWriteErrorToFile(errorStream, "LINE NUMBER: " + sPhysicalNumberRows + "\t" + e.getMessage());
			e.printStackTrace(errorStream);
		} finally {
			if(bCheckTriggerOff){
				MqlUtil.mqlCommand(context, "Trigger On");
			}
			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, "LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms             ");
			multiWriteMessageToFile(logWriter,"FAIL COUNT:("+ failCount + ")   SUCCESS COUNT:("+successCount+") TOTAL COUNT :("+totalCount+")" );
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			

			System.out.println("cdmCommonCodeMigration : createLibDataCommonCode--> end. "+cdmCommonExcel.getTimeStamp2());
		}
	}

	/**
	 * common code Product Group 하위 common code 생성
	 * 파일구성 
	 * 1레벨 CommonCode. name:CommonCodeRoot 
	 * 2레벨 CommonCode. attribute[cdmCommonCode]  ->Option 
	 * 3레벨 CommonCode. attribute[cdmCommonCode]  ->데이타 PROD_DIV 필드
	 * 4레벨 CommonCode. attribute[cdmCommonCode]  ->데이타 CN_CODE  필드 
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void createOptionCommonCode(Context context, String args[]) throws Exception {
		System.out.println("cdmCommonCodeMigration : createOptionCommonCode--> start "+cdmCommonExcel.getTimeStamp2());
		
		long startTime = System.currentTimeMillis();
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String logFileName = "createOptionCommonCode";
		
		String tempFileAndLocation = args[0];
		String commonCodeFilePath = "";
		String commonCodeFileName = "";
		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
//		Map paramMap = (Map)JPO.unpackArgs(args);
//		String commonCodeFilePath = (String)paramMap.get("File_Location");
//		String commonCodeFileName = (String)paramMap.get("File");
		
//		if(args.length != 1){
//			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//		}
		
		if(cdmStringUtil.isEmpty(commonCodeFilePath) || cdmStringUtil.isEmpty(commonCodeFileName)){
			String errorMessage = "The file to read does not exist.";
			throw new Exception(errorMessage);
		}
		
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명,읽을 메인 시트명
//		String[] sTempArgs = {"C:\\temp\\Import_File\\COMMONCODE","20160907_LIBv02.xlsx"};
		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
		if (sTempArgs.length!=2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory  = sTempArgs[0];
		fileName		= sTempArgs[1];
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
			inputDirectory = inputDirectory + sfileSeparator;
		}
		
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + sOutput_Directory + sfileSeparator + logFileName + "_" + cdmCommonExcel.getTimeStamp() + sfileSeparator;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"     OPTION COMMONCODE MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		int failCount 	= 0;
		int successCount = 0;
		int totalCount = 0;
		
		String stRecordNumber = "";
		String stRecordOptionDescription = "";
		String stRecordOptionCode = "";
		String stRecordCheckPromote = "";
		String stRecordProductDiv = "";
		try {
			MqlUtil.mqlCommand(context, "history off");
			/* ****************************************
			 * 현재 option 정보시트
			 * Option1, Option2, Option3, Option4, Option5, Option6 
			 * **************************************** */
			StringList stListOptionInfo = new StringList(6);
			stListOptionInfo.add("Option1");
			stListOptionInfo.add("Option2");
			stListOptionInfo.add("Option3");
			stListOptionInfo.add("Option4");
			stListOptionInfo.add("Option5"); 
			stListOptionInfo.add("Option6"); 
		
			
			for (int optionInfoCnt = 0; optionInfoCnt < stListOptionInfo.size(); optionInfoCnt++) {
				String sheetName 	   = ""; // sheet name
				String upperCommonCode = ""; // commoncode lev1

				String stTempOptionInfo = (String) stListOptionInfo.get(optionInfoCnt);
				sheetName = stTempOptionInfo;
				upperCommonCode = stTempOptionInfo;
				
				String sPhysicalNumberRows = "";
				try {
					
					XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory + fileName, sheetName);
					int physicalNumberRows = sheet.getPhysicalNumberOfRows();
					totalCount += (physicalNumberRows-2);
					/* ***********************************
					 * commoncode lev1 검색 start
					 * 검색한 object 하위에 object을 생성.
					 * *********************************** */
					String stWhere = "attribute[cdmCommonCode] == '" + upperCommonCode + "' && to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot'";
					String stFindOptionIdMql = MqlUtil.mqlCommand(context, "temp query bus \"cdmCommonCode\" * * where \""+stWhere +"\"  select id dump |");
					
					String upperOptionId = "";
					StringList stListFindOptionIdMqlResult = new StringList();
					stListFindOptionIdMqlResult = FrameworkUtil.split(stFindOptionIdMql, "|");
					
					if(stListFindOptionIdMqlResult.size()<2 ){
						String errorMessage = "NOT EXIST COMMONCODE LEVEL 1 OBJECT. \t 0";
						throw new Exception(errorMessage);
					}
					upperOptionId = (String)stListFindOptionIdMqlResult.get(3);
					
					/*commoncode lev1 검색 end */
					
					for (int i = 2; i < physicalNumberRows; i++) {
						XSSFRow row = sheet.getRow(i);
						try {
							sPhysicalNumberRows = String.valueOf(i);
							/*row가 null 이면 에러 처리 */
							if (row == null){
								String errorMessage = "NOT EXIST DATA. (ROW NULL) \t 1";
								throw new Exception(errorMessage);
							}
						
							XSSFCell cell_0 = row.getCell(0);// 순번
//							XSSFCell cell_1 = row.getCell(1);// CN_ID
							XSSFCell cell_2 = row.getCell(2);// 레벨4일 경우 attribute[cdmCommonCode]
							XSSFCell cell_3 = row.getCell(3);// attribute[cdmCommonCode]
							XSSFCell cell_4 = row.getCell(4);// [-1일 경우 promote]
							XSSFCell cell_5 = row.getCell(5);// PROD_DIV

							String stNumber 			= cdmCommonExcel.isVaildNullData(getCellValue(cell_0));
							stRecordNumber = stNumber;
							if(cell_2!=null){
								stRecordOptionDescription  = cdmCommonExcel.isVaildNullData(getCellValue(cell_2));
							}
							if(cell_3!=null){
								stRecordOptionCode = cdmCommonExcel.isVaildNullData(getCellValue(cell_3));
							}
							if(cell_4!=null){
								stRecordCheckPromote 		= cdmCommonExcel.isVaildNullData(getCellValue(cell_4));
							}
							if(cell_5!=null){
								stRecordProductDiv		= cdmCommonExcel.isVaildNullData(getCellValue(cell_5));
							}
						
							if (cell_2 !=null && cell_3 != null && cell_5 != null) {
//								ContextUtil.startTransaction(context, true);
								
//								String stNumber 			= cdmCommonExcel.isVaildNullData(getCellValue(cell_0));
								String stOptionDescription  = cdmCommonExcel.isVaildNullData(getCellValue(cell_2));
								String stTempOptionCode 	= cdmCommonExcel.isVaildNullData(getCellValue(cell_3));
								String stCheckPromote 		= cdmCommonExcel.isVaildNullData(getCellValue(cell_4));
								String stProductDiv			= cdmCommonExcel.isVaildNullData(getCellValue(cell_5));
								
								
								boolean bReplaceOptionCode = false;
								String  stOptionCode  = stTempOptionCode ; 
								
								String tempSymbolOptionCode = "";
								if(stTempOptionCode.indexOf("'") != -1 ){
									tempSymbolOptionCode 		= FrameworkUtil.findAndReplace(stTempOptionCode, "'", "?");
									bReplaceOptionCode  = true;
								}else if(stTempOptionCode.indexOf(",") != -1 ){
									tempSymbolOptionCode 		= FrameworkUtil.findAndReplace(stTempOptionCode, ",", "?");
									bReplaceOptionCode  = true;
								}
								
							
							// product Div 값이 없으면 option 및 product Div 생성하지않음 
							
							// 11/24/16
							// product Div 값이 없어도 생성 
							// product Div 의 값은 레벨2 의 attribute[cdmCommonCode] attribute[cdmCommonCodeTemp1]에 저장
							
							String duplicateId2 = "";
							String option2Where = "";
							if(bReplaceOptionCode){
								option2Where = "attribute[cdmCommonCode] ~= '" + tempSymbolOptionCode + "' && attribute[cdmCommonTemp1] == '"+stProductDiv+"' && to[cdmCommonCodeRelationship].from.id== '" + upperOptionId + "'";
							}else{
								option2Where = "attribute[cdmCommonCode] == '" + stOptionCode + "' && attribute[cdmCommonTemp1] == '"+stProductDiv+"' && to[cdmCommonCodeRelationship].from.id== '" + upperOptionId + "'";
							}
							
							String stFindDuplicate2IdMql = MqlUtil.mqlCommand(context, "temp query bus \"cdmCommonCode\" * * where \""+option2Where+"\"  select id attribute[cdmCommonCode] dump |") ;
							
							StringList stFindDuplicate2IdMqlResult 	= new StringList();
							if(!bReplaceOptionCode){
								stFindDuplicate2IdMqlResult = FrameworkUtil.split(stFindDuplicate2IdMql, "|");
								if(stFindDuplicate2IdMqlResult.size()>2){
									duplicateId2 = (String)stFindDuplicate2IdMqlResult.get(3);	
								}
							}else{
								stFindDuplicate2IdMqlResult = FrameworkUtil.split(stFindDuplicate2IdMql, "\n");
					    	 	
					    	 	for (Iterator findDuplicate2IdIerator = stFindDuplicate2IdMqlResult.iterator(); findDuplicate2IdIerator.hasNext();) {
					    	 		String findDuplicate2IdCodeIter = (String) findDuplicate2IdIerator.next();
								
									StringList stListfindDuplicate2Id =  FrameworkUtil.split(findDuplicate2IdCodeIter, "|");
									String stFindDuplicate2AttrCommonCode= (String)stListfindDuplicate2Id.get(4);
									
									if(cdmStringUtil.isNotEmpty(stFindDuplicate2AttrCommonCode) && stFindDuplicate2AttrCommonCode.equals(stOptionCode)){
										duplicateId2 = (String)stFindDuplicate2IdMqlResult.get(3);
										break;
									}else if(stFindDuplicate2AttrCommonCode !=null && stFindDuplicate2AttrCommonCode != "null" && cdmStringUtil.isEmpty(stFindDuplicate2AttrCommonCode) && stOptionCode.equals(stFindDuplicate2AttrCommonCode)){
										duplicateId2 = (String)stFindDuplicate2IdMqlResult.get(3);
										break;
					    	 		}
					    	 	}
							}
							
							if(cdmStringUtil.isNotEmpty(duplicateId2)){
								String errorMessage = "the object already exists. \t 2";
								throw new Exception(errorMessage);
							}
							Map requestArgs2 = new HashMap();
							requestArgs2.put("objectId", upperOptionId);
							requestArgs2.put("Name", stOptionCode);
							requestArgs2.put("codeKo", stOptionDescription);
							requestArgs2.put("codeEn", stOptionDescription);
							requestArgs2.put("codeCn", stOptionDescription);
							requestArgs2.put("temp1", stProductDiv);
							requestArgs2.put("checkMigration", "Y");
							Map createdCommonCodeMap3 = (Map) JPO.invoke(context, "cdmCommonCodeMigration", null, "createOptionObject", JPO.packArgs(requestArgs2), Map.class);
							String createIdLev3 = (String) createdCommonCodeMap3.get("id");
							DomainObject createLev3Obj = new DomainObject(createIdLev3);
							if ("-1".equals(stCheckPromote)) {
								createLev3Obj.promote(context);
							}
							
							multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. SHEETNAME: "+sheetName+"\t LineNum: \t" + sPhysicalNumberRows +"\t Sub_LineNum: \t"+stNumber);
//							multiWriteMessageToFile(logWriter, " SUCESS!!. SHEETNAME: "+sheetName+ "\t LineNum: \t" + sPhysicalNumberRows+"\t Sub_LineNum: \t"+stNumber);
							
//								//에러 발생 엑셀파일에 데이타가 없으면 에러 처리 
//								String errorMessage = "NOT MAKE OBJECT. PRODUCT DIV";
//								throw new Exception(errorMessage);
//								
//							}
//							ContextUtil.commitTransaction(context);
							successCount++;
						}else{
							failCount++;
							multiWriteMessageToFile(logWriter, "not exist filed infomation "+"\t"+sheetName+" \t"+sPhysicalNumberRows+"\t \t \t \t \t \t");
//							multiWriteMessageToFile(failedObjectidWriter, "\t"+sheetName+" \t" + sPhysicalNumberRows+"\t"+stRecordNumber+"\t"+stRecordOptionDescription  +"\t"+stRecordOptionCode +"\t"+stRecordCheckPromote +"\t"+stRecordProductDiv +"\t");
						}
						}catch(Exception e3){
//							ContextUtil.abortTransaction(context);
							failCount++;
							//sheetName realNumberRow excelRow 
							multiWriteMessageToFile(failedObjectidWriter, "\t"+sheetName+" \t" + sPhysicalNumberRows+"\t"+stRecordNumber+"\t"+stRecordOptionDescription  +"\t"+stRecordOptionCode +"\t"+stRecordCheckPromote +"\t"+stRecordProductDiv +"\t");
//							multiWriteMessageToFile(logWriter, " Exception: " + e3.getMessage() + " SHEETNAME: "+sheetName+"  LINE NUMBER: " + sPhysicalNumberRows);
							mulitWriteErrorToFile(errorStream, "SHEETNAME: \t"+sheetName+"\t LineNum: \t" + sPhysicalNumberRows + "\t" + e3.getMessage());
							e3.printStackTrace(errorStream);
						}finally{
							stRecordNumber = "";
							stRecordOptionDescription = "";
							stRecordOptionCode = "";
							stRecordProductDiv = "";
							stRecordCheckPromote = "";
						}
					}
				} catch (Exception e2) {
					e2.printStackTrace(errorStream);
					
				}
			}
			multiWriteMessageToFile(logWriter, "====================================================================================");
			multiWriteMessageToFile(logWriter, "        File COMMONCODE Migration COMPLETED.                    ");
			multiWriteMessageToFile(logWriter, "====================================================================================\n");
			
		} catch (Exception e) {

//			FileWriter errorFW = null;
//			StringBuffer errorMessage = new StringBuffer();
//			errorMessage.append(stNumber).append("|").append(stOptionDescription).append("|").append(stOptionCode).append("|").append(stCheckPromote).append("|").append(stCProductDiv).append("|").append(" \n");
//
//			String errorFile = "errorOptionCommonCodeFile_" + sDate + ".txt";
//			errorFW = new FileWriter(directory + cdmCommonExcel.BACKSLASH + errorFile, true);
//			errorFW.write(errorMessage.toString());
//			errorFW.flush();
//			errorFW.close();
			multiWriteMessageToFile(logWriter, " Exception: " + e.getMessage() );
			mulitWriteErrorToFile(errorStream, " Exception: "+e.getMessage());
			e.printStackTrace(errorStream);
		} finally {
			MqlUtil.mqlCommand(context, "history on");
			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, "LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms             ");
			multiWriteMessageToFile(logWriter,"	FAIL COUNT:("+ failCount + ")   SUCCESS COUNT:("+successCount+") TOTAL COUNT :("+totalCount+")" );
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

			System.out.println("cdmCommonCodeMigration : createOptionCommonCode--> end."  +cdmCommonExcel.getTimeStamp());
		}
	}
	
	/**
	 * 
	 * @param context
	 * @param arg
	 * @throws Exception
	 */
	public Map createOptionObject(Context context,String args[])throws Exception{

		try {
			Map paramMap = JPO.unpackArgs(args);
//			System.out.println(paramMap);
			
			String checkMigration = (String)paramMap.get("checkMigration");
			
			String objectId = (String)paramMap.get("objectId");
			String code = (String)paramMap.get("Name");
			String codeKo = (String)paramMap.get("codeKo");
			String codeEn = (String)paramMap.get("codeEn");
			String codeCn = (String)paramMap.get("codeCn");
			//add js.hyun 2016.08.23 start
			String temp1 = (String)paramMap.get("temp1") == null ? "" : (String)paramMap.get("temp1");
			String temp2 = (String)paramMap.get("temp2") == null ? "" : (String)paramMap.get("temp2");
			String temp3 = (String)paramMap.get("temp3") == null ? "" : (String)paramMap.get("temp3");
			//add js.hyun 2016.08.23 end
			String description = (String)paramMap.get("description");

			//add js.hyun 2016.08.23 start
			String ngType = "eService Number Generator";
			String ngName = "cdmCommonCodeNumberGenerator";
			String ngRev = "cdmCommonCode";
			String ngVault = "eService Administration";
			BusinessObject numGenerator = new BusinessObject(ngType, ngName, ngRev, ngVault);
			int name = Integer.parseInt(numGenerator.getAttributeValues(context, "eService Next Number").getValue());
			//add js.hyun 2016.08.23 end
			
			DomainObject domObj = new DomainObject();
			domObj.createObject(context, 
								"cdmCommonCode",
								String.format("CC-%010d", name), 
								"-", 
								"cdmCommonCodePolicy", 
								"eService Production");
			
			//add js.hyun 2016.08.23 start
			numGenerator.setAttributeValue(context, "eService Next Number", String.valueOf(name+1));
			//add js.hyun 2016.08.23 end
			
			Map attrMap = new HashMap();
			//add js.hyun 2016.08.23 start
			attrMap.put("cdmCommonCode", code);
			attrMap.put("cdmCommonTemp1", temp1);
			attrMap.put("cdmCommonTemp2", temp2);
			attrMap.put("cdmCommonTemp3", temp3);
			//add js.hyun 2016.08.23 end
			attrMap.put("cdmCommonCodeNameKo", codeKo);
			attrMap.put("cdmCommonCodeNameEn", codeEn);
			attrMap.put("cdmCommonCodeNameCn", codeCn);
			
			if(cdmStringUtil.isNotEmpty(checkMigration) && "Y".equals(checkMigration)){
				attrMap.put("cdmCheckMigration", checkMigration);
			}
			
			domObj.setAttributeValues(context, attrMap);
			domObj.setDescription(context, description);
			
			//if objectId is SPACE, emxTable is null and emxIndentedTable id ""(SPACE) 
			if(objectId == null || "".equals(objectId)){
//				BusinessObject rootObj = new BusinessObject("cdmCommonCode", "CommonCodeRoot", "-", "eService Production");
//				objectId = rootObj.getObjectId(context);
				
				String mqlId = MqlUtil.mqlCommand(context, "temp query bus \"cdmCommonCode\" \"CommonCodeRoot\"  \"-\" select id dump |");
				objectId = (String)FrameworkUtil.split(mqlId, "|").get(3);
				System.out.println("objectId: "+objectId);
			}
			
			domObj.setRelatedObject(context, 
									"cdmCommonCodeRelationship", 
									false, 
									objectId);
			
			Map createdIdMap = new HashMap();
			createdIdMap.put("id", domObj.getId(context));
			
			return createdIdMap;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	
	}
	
	
	public void createProductGroupCommonCode(Context context,String args[]) throws Exception{
		System.out.println("cdmCommonCodeMigration : createProductGroupCommonCode--> start "+cdmCommonExcel.getTimeStamp2());

		long startTime = System.currentTimeMillis();
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String logFileName = "createProductGroupCommonCode";
//		Map paramMap = (Map)JPO.unpackArgs(args);
//		String commonCodeFilePath = (String)paramMap.get("File_Location");
//		String commonCodeFileName = (String)paramMap.get("File");
//		if(args.length != 1){
//			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//		}
		String tempFileAndLocation = args[0];
		
		String commonCodeFilePath = "";
		String commonCodeFileName = "";
		commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
		commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);

		if(cdmStringUtil.isEmpty(commonCodeFilePath) || cdmStringUtil.isEmpty(commonCodeFileName)){
			String errorMessage = "The file to read does not exist. \t 0";
			throw new Exception(errorMessage);
		}
		// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명,읽을 메인 시트명
//		String[] sTempArgs = {"C:\\temp\\Import_File\\COMMONCODE","20160907_LIBv02.xlsx"};
		String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
		if (sTempArgs.length!=2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory  = sTempArgs[0];
		fileName		= sTempArgs[1];
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
			inputDirectory = inputDirectory + sfileSeparator;
		}
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + sOutput_Directory + sfileSeparator + logFileName + "_" + cdmCommonExcel.getTimeStamp() + sfileSeparator;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"PRODUCTGROUP COMMONCODE MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");

		int failCount 	= 0;
		int successCount = 0;
		int totalCount = 0;
		
		String stRecordNumber			= "";
		String stRecordCodeDescription  = "";
		String stRecordCommonCode 	    = "";
		String stRecordCheckPromote 	= "";
		String stRecordAttributeTmp1 	= "";
		String stRecordAttributeTmp2 	= "";
		
		
		//
		try {
			MqlUtil.mqlCommand(context, "history off");
			String sheetName = "product group";
//			String upperCommonCode = "product group";
			String upperCommonCode = "Product Group Name";
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			String sPhysicalNumberRows = "";
			String stWhere = "attribute[cdmCommonCode]=='" + upperCommonCode + "' && to[cdmCommonCodeRelationship].from.name=='CommonCodeRoot'";
			String upperProjectGroupId = "";
			totalCount =physicalNumberRows -2;
			String upperProjectGroupIdMql = MqlUtil.mqlCommand(context, "temp query bus \"cdmCommonCode\" * * where \""+stWhere+"\" select id attribute[cdmCommonCode] dump |" );
			
			StringList upperProjectGroupIdMqlResult = new StringList();
			upperProjectGroupIdMqlResult = FrameworkUtil.split(upperProjectGroupIdMql, "|");
			if(upperProjectGroupIdMqlResult.size()>2){
				upperProjectGroupId = (String)upperProjectGroupIdMqlResult.get(3);
			}

			for (int i = 2; i < physicalNumberRows; i++) {
				XSSFRow row = sheet.getRow(i);
				sPhysicalNumberRows = String.valueOf(i);
				try{
					
					if (row == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL) \t 1";
						throw new Exception(errorMessage);
					}
					
					XSSFCell cell_0 = row.getCell(0);// number
					XSSFCell cell_1 = row.getCell(1);// desription
					XSSFCell cell_2 = row.getCell(2);// Cn_ID
					XSSFCell cell_3 = row.getCell(3);// promote check
					XSSFCell cell_4 = row.getCell(4);// temp1
					XSSFCell cell_5 = row.getCell(5);// temp2
	
//					if (!(cell_0 != null && cell_1 != null && cell_3 != null && cell_4 != null)) {
//						String stErrorMessage = "";
//						throw new Exception(stErrorMessage);
//					}
					
					
					if (cell_0 != null && cell_1 != null && cell_3 != null && cell_4 != null) {
						String stNumber				= cdmCommonExcel.isVaildNullData(getCellValue(cell_0));
						String stCodeDescription 	= cdmCommonExcel.isVaildNullData(getCellValue(cell_1));
						String stCommonCode 		= cdmCommonExcel.isVaildNullData(getCellValue(cell_2));
						String stCheckPromote 		= cdmCommonExcel.isVaildNullData(getCellValue(cell_3));
						String stAttributeTmp1 		= cdmCommonExcel.isVaildNullData(getCellValue(cell_4));
						String stAttributeTmp2 		= cdmCommonExcel.isVaildNullData(getCellValue(cell_5));					
						
						stRecordNumber			= stNumber;			
						stRecordCodeDescription = stCodeDescription;
						stRecordCommonCode 	    = stCommonCode; 	
						stRecordCheckPromote 	= stCheckPromote; 	
						stRecordAttributeTmp1 	= stAttributeTmp1; 	
						stRecordAttributeTmp2 	= stAttributeTmp2; 	
						
						
						/*modify by 9/27/16 start  attribute[cdmCommonCode] 조건 제거 */
	//					String pgWhere = "to[cdmCommonCodeRelationship].from.id=='"+upperProjectGroupId+"' && attribute[cdmCommonCodeNameKo]=='" + stCodeDescription + "' && attribute[cdmCommonCode]=='" + stCommonCode + "' && attribute[cdmCommonTemp1]=='" + stAttributeTmp1 + "' && attribute[cdmCommonTemp2]=='" + stAttributeTmp2 + "'";
						/*modify by 9/27/16 end */
						String pgWhere = "to[cdmCommonCodeRelationship].from.id=='"+upperProjectGroupId+"' && "
											+ "attribute[cdmCommonCodeNameKo]=='" + stCodeDescription + "' && "
											+ "attribute[cdmCommonTemp1]=='" + stAttributeTmp1 + "' && "
											+ "attribute[cdmCommonTemp2]=='" + stAttributeTmp2 + "'";
						
						String existPGId = "";
						String existPGFindMql = MqlUtil.mqlCommand(context, "temp query bus \"cdmCommonCode\"  * * where \""+pgWhere+"\" select id dump |");
						StringList existPGFindMqlResult = new StringList();
						existPGFindMqlResult = FrameworkUtil.split(existPGFindMql, "|");
					
						if(existPGFindMqlResult.size()>2){
							existPGId = (String)existPGFindMqlResult.get(3);
						}
						
						if (cdmStringUtil.isEmpty(existPGId)) {
	
							Map requestArgs = new HashMap();
							requestArgs.put("objectId", upperProjectGroupId);
							requestArgs.put("Name", stCommonCode);
							requestArgs.put("codeKo", stCodeDescription);
							requestArgs.put("codeEn", stCodeDescription);
							requestArgs.put("codeCn", stCodeDescription);
							requestArgs.put("temp1", stAttributeTmp1);
							requestArgs.put("temp2", stAttributeTmp2);
							requestArgs.put("checkMigration", "Y");
							
//							ContextUtil.startTransaction(context, true);
							Map createdCommonCodeMap2 = (Map) JPO.invoke(context, "cdmCommonCodeMigration", null, "createObject", JPO.packArgs(requestArgs), Map.class);
							String createId = (String) createdCommonCodeMap2.get("id");
							DomainObject createObj = new DomainObject(createId);
							
							if ("-1".equals(stCheckPromote)) {
								createObj.promote(context);
							}
							//
//							ContextUtil.commitTransaction(context);
							successCount++;
							multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. SHEETNAME: "+sheetName+" LINE NUMBER: " + sPhysicalNumberRows +",SUB LINE NUM: "+stNumber);
							multiWriteMessageToFile(logWriter, " SUCESS!!. SHEETNAME: "+sheetName+ " LINE NUMBER: " + sPhysicalNumberRows+" , SUB LINE NUM:"+stNumber);
						} else {
							String stErrorMessage = "ALREADY EXIST OBJECT \t 2";
							throw new Exception(stErrorMessage);
							/*modify by 9/27/16  추후를 위해 주석처리 */  
							//데이타가 같지만 current -1인것을 우위 로 둔다 cdmCommonCode 도 변경 
//							if("-1".equals(stCheckPromote)){
//								DomainObject dObj = new DomainObject(existPGId);
//								String currentName= dObj.getCurrentState(context).getName();
//								
//								if("Inactive".equals(currentName)){
//									dObj.promote(context);
//									dObj.setAttributeValue(context, "cdmCommonCode",stCommonCode );
//								}
//								
//							}
							/*modify by 9/27/16 end */  
						}
					
					}
				}catch(Exception e2){
//					ContextUtil.abortTransaction(context);
					failCount++;
					multiWriteMessageToFile(failedObjectidWriter, "SheetName: \t"+sheetName+" \t" + sPhysicalNumberRows+"\t"+stRecordNumber+"\t"+stRecordCodeDescription+"\t"+stRecordCommonCode+"\t"+stRecordCheckPromote+"\t"+stRecordAttributeTmp1+"\t"+stRecordAttributeTmp2+"\t" );
					multiWriteMessageToFile(logWriter, "SheetName: \t"+sheetName+"\t" + sPhysicalNumberRows+"\t " + e2.getMessage() );
					mulitWriteErrorToFile(errorStream, "SheetName: \t"+sheetName+"\t" + sPhysicalNumberRows + "\t" + e2.getMessage());
					e2.printStackTrace(errorStream);
				}
					
			}
		} catch (Exception e) {
			multiWriteMessageToFile(logWriter, " Exception: " + e.getMessage() );
			e.printStackTrace(errorStream);
		} finally {
			MqlUtil.mqlCommand(context, "history on");
			multiWriteMessageToFile(logWriter, "==================================================================================== ");
			multiWriteMessageToFile(logWriter, "MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, "LEAD TIME:" + (System.currentTimeMillis() - startTime) / 1000/60 + "ms             ");
			multiWriteMessageToFile(logWriter,"	FAIL COUNT:("+ failCount + ")   SUCCESS COUNT:("+successCount+") TOTAL COUNT :("+totalCount+")" );
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

			System.out.println("cdmCommonCodeMigration : createProductGroupCommonCode--> end."+cdmCommonExcel.getTimeStamp2());

		}
	}

	/**
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void createVehicleCommonCode(Context context , String args[])throws Exception{
			System.out.println("cdmCommonCodeMigration : createVehicleCommonCode--> start "+cdmCommonExcel.getTimeStamp2());

			long startTime = System.currentTimeMillis();
			String inputDirectory 			     = "";
			String outputDirectory 			     = "";
			String fileName 		       	     = "";
			
			PrintStream errorStream		         = null; 
			File successLogFile 				 = null; 
			File failedLogFile 				     = null;
			
			BufferedWriter logWriter 			 = null; 
			BufferedWriter successObjectidWriter = null; 
			BufferedWriter failedObjectidWriter  = null; 
			
			String logFileName = "createVehicleCommonCode";
			
//			Map paramMap = (Map)JPO.unpackArgs(args);
//			String commonCodeFilePath = (String)paramMap.get("File_Location");
//			String commonCodeFileName = (String)paramMap.get("File");
			if(args.length != 1){
				throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
			}
			String tempFileAndLocation = args[0];
			String commonCodeFilePath = "";
			String commonCodeFileName = "";
			commonCodeFilePath 	= tempFileAndLocation.substring(0,tempFileAndLocation.lastIndexOf(File.separator));
			commonCodeFileName 	= tempFileAndLocation.substring(tempFileAndLocation.lastIndexOf(File.separator)+1);
			
			if(cdmStringUtil.isEmpty(commonCodeFilePath) || cdmStringUtil.isEmpty(commonCodeFileName)){
				String errorMessage = "The file to read does not exist.";
				throw new Exception(errorMessage);
			}
			
			// 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명,읽을 메인 시트명
//			String[] sTempArgs = {"C:\\temp\\Import_File\\COMMONCODE","20160907_LIBv02.xlsx"};
			String[] sTempArgs = {commonCodeFilePath,commonCodeFileName};
//			if (sTempArgs.length!=2) {
//				throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//			}
			
			inputDirectory  = sTempArgs[0];
			fileName		= sTempArgs[1];
			
			// documentDirectory does not ends with "/" add it
			if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
				inputDirectory = inputDirectory + sfileSeparator;
			}
			
			// create a directory to add debug and error logs
			outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + sOutput_Directory + sfileSeparator + logFileName + "_" + cdmCommonExcel.getTimeStamp() + sfileSeparator;
			File fileOutputDirectory = new File(outputDirectory);
			if (!fileOutputDirectory.isDirectory()) {
				fileOutputDirectory.mkdirs();
			}
			logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
			errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

			successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
			successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

			failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
			failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
			
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"     OPTION COMMONCODE MIGRATION  START TIME: "+ cdmCommonExcel.getTimeStamp()+"  \n");
			multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory+fileName);
			multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
			multiWriteMessageToFile(logWriter,"====================================================================================\n");

			String sheetName = "Lib_Data_Vehicle";
			int successCount = 0; 
			int failCount 	 = 0;
			int totalCount   = 0;
			
			String stRecordNumber 			   =  "";
			String stRecordCodeDescription	   =  "";
			String stRecordCommonCodeLev3 	   =  "";
			String stRecordCheckPromote 		= "";
			String stRecordCodeLev2 			= "";
			String stRecordCommonCodeLev2		= "";
			String stRecordCommonCodeNameLev2  =  "";
			
			
			boolean bCheckTriggerOff = false;
			MqlUtil.mqlCommand(context, "Trigger Off");
			bCheckTriggerOff = true;
			try {
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			String sPhysicalNumberRows = "";
			String stlVehicleId = "";
			
			String stWhere = "attribute[cdmCommonCode] == 'Vehicle' && to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot'";
			String stSearchstlVehicleMql = MqlUtil.mqlCommand(context, "temp query bus \"cdmCommonCode\" * * where \""+stWhere+ "\" select id dump |");
			
			StringList sListSearchstlVehicleMql = new StringList();
			sListSearchstlVehicleMql = FrameworkUtil.split(stSearchstlVehicleMql, "|");

			if(sListSearchstlVehicleMql.size()>2){
				stlVehicleId = (String)sListSearchstlVehicleMql.get(3);
			}else{
				String errorMessage = "NOT EXIST VEHICLE OBJECT. \t 0";
				throw new Exception(errorMessage);
			}
			totalCount = physicalNumberRows-2;
			for (int i = 2; i < physicalNumberRows; i++) {
				XSSFRow row = sheet.getRow(i);
				sPhysicalNumberRows = String.valueOf(i);
				try {
					if (row == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL) \t 1";
						throw new Exception(errorMessage);	
					}
						

					XSSFCell cell_0 = row.getCell(0);
					XSSFCell cell_1 = row.getCell(1);
					XSSFCell cell_2 = row.getCell(2);
					XSSFCell cell_3 = row.getCell(3);
					XSSFCell cell_4 = row.getCell(4);
					XSSFCell cell_5 = row.getCell(5);
					XSSFCell cell_6 = row.getCell(6);

					if (cell_1 != null && cell_4 != null) {

						String stNumber 			= cdmCommonExcel.isVaildNullData(getCellValue(cell_0));
						String stCodeDescription	= cdmCommonExcel.isVaildNullData(getCellValue(cell_1));
						String stCommonCodeLev3 	= cdmCommonExcel.isVaildNullData(getCellValue(cell_2));
						String stCheckPromote 		= cdmCommonExcel.isVaildNullData(getCellValue(cell_3));
						String stCodeLev2 			= cdmCommonExcel.isVaildNullData(getCellValue(cell_4));
						String stCommonCodeLev2		= cdmCommonExcel.isVaildNullData(getCellValue(cell_5));
						String stCommonCodeNameLev2	= cdmCommonExcel.isVaildNullData(getCellValue(cell_6));

						stRecordNumber 			      = stNumber 			;
						stRecordCodeDescription	      = stCodeDescription	;
						stRecordCommonCodeLev3 	      = stCommonCodeLev3 	;
						stRecordCheckPromote 		  = stCheckPromote 		;
						stRecordCodeLev2 			  = stCodeLev2 			;
						stRecordCommonCodeLev2		  = stCommonCodeLev2	;	
						stRecordCommonCodeNameLev2    = stCommonCodeNameLev2;	
						
						HashMap requestArgs = new HashMap<>();
						requestArgs.put("objectId", stlVehicleId);
						requestArgs.put("Name", stCodeLev2);
						requestArgs.put("codeKo", stCodeLev2);
						requestArgs.put("codeEn", stCodeLev2);
						requestArgs.put("codeCn", stCodeLev2);
						requestArgs.put("checkMigration", "Y");

						if (cdmStringUtil.isEmpty(stCodeLev2)) {
							String errorMessage = "NOT MAKE VEHICLE OBJECT .(CELL_2 EMPTY) \t 2";
							throw new Exception(errorMessage);

						}

//						ContextUtil.startTransaction(context, true);
						DomainObject vehicleDObj = new DomainObject(stlVehicleId);
						String vehicle2Where = " attribute[cdmCommonCode]=='" + stCodeLev2 + "' ";

						String vehicleLev2Id = "";
						// String stSearchstlVehicleLev2Mql =
						// MqlUtil.mqlCommand(context, "temp query bus
						// \"cdmCommonCode\" * * where \""+vehicle2Where+ "\"
						// select id dump |");
						String stSearchstlVehicleLev2Mql = MqlUtil.mqlCommand(context, "expand bus \"" + stlVehicleId + "\" from relationship cdmCommonCodeRelationship recurse to 1 select bus id where \"" + vehicle2Where + "\" dump |");
						StringList sListSearchstlVehicleLev2MqlResult = new StringList();
						sListSearchstlVehicleLev2MqlResult = FrameworkUtil.split(stSearchstlVehicleLev2Mql, "|");

						if (sListSearchstlVehicleLev2MqlResult.size() > 2) {
							vehicleLev2Id = (String) sListSearchstlVehicleLev2MqlResult.get(6);
						}

						if (UIUtil.isNotNullAndNotEmpty(vehicleLev2Id)) {
							Map requestArgs2 = new HashMap();
							requestArgs2.put("objectId", vehicleLev2Id);
							requestArgs2.put("Name", stCommonCodeLev3);
							requestArgs2.put("codeKo", stCodeDescription);
							requestArgs2.put("codeEn", stCodeDescription);
							requestArgs2.put("codeCn", stCodeDescription);
							requestArgs2.put("checkMigration", "Y");

							Map createdCommonCodeMap2 = (Map) JPO.invoke(context, "cdmCommonCodeMigration", null, "createObject", JPO.packArgs(requestArgs2), Map.class);
							String createLeafId = (String) createdCommonCodeMap2.get("id");
							
							if(cdmStringUtil.isEmpty(createLeafId)){
								String errorMessage = "NOT CREATE LEAF VEHICLE CODE. \t 3";
								throw new Exception(errorMessage);
							}
							DomainObject createLeafDobj = new DomainObject(createLeafId);

							if ("-1".equals(stCheckPromote)) {
								createLeafDobj.promote(context);
							}
						} else {
							Map createdCommonCodeMap = (Map) JPO.invoke(context, "cdmCommonCodeMigration", null, "createObject", JPO.packArgs(requestArgs), Map.class);
							
							String createId = (String) createdCommonCodeMap.get("id");
							if(cdmStringUtil.isEmpty(createId)){
								String errorMessage = "NOT CREATE LEVEL 2 VEHICLE CODE. \t 4"; //리프 commoncode 의 한단계위의 object가 존재하지 않으면 에러 
								throw new Exception(errorMessage);
							}
							
							DomainObject createDobj = new DomainObject(createId);

							Map requestArgs2 = new HashMap();
							requestArgs2.put("objectId", createId);
							requestArgs2.put("Name", stCommonCodeLev3);
							requestArgs2.put("codeKo", stCodeDescription);
							requestArgs2.put("codeEn", stCodeDescription);
							requestArgs2.put("codeCn", stCodeDescription);
							requestArgs2.put("checkMigration", "Y");
							Map createdCommonCodeMap2 = (Map) JPO.invoke(context, "cdmCommonCodeMigration", null, "createObject", JPO.packArgs(requestArgs2), Map.class);
							String createLeafId = (String) createdCommonCodeMap2.get("id");
							DomainObject createLeafDobj = new DomainObject(createLeafId);
							if ("-1".equals(stCheckPromote)) {
								createLeafDobj.promote(context);
							}
						}
//						ContextUtil.commitTransaction(context);
						successCount++;
						multiWriteMessageToFile(successObjectidWriter, " SUCESS!!. SHEETNAME: \t" + sheetName + "\t LINE NUMBER: \t" + sPhysicalNumberRows + "\t COUNT NUM: \t" + stNumber);
						multiWriteMessageToFile(logWriter, " SUCESS!!. SHEETNAME: \t" + sheetName + "\t LINE NUMBER: \t" + sPhysicalNumberRows + " \t COUNT NUM:\t" + stNumber);
					} else {
						String errorMessage = "NOT MAKE OBJECT( CELL_0 ,CELL_4  :COUNT NUM OR CUSTOMER FIELD EMPTY \t 4 )";
						throw new Exception(errorMessage);
					}

				}catch(Exception e2){
//					ContextUtil.abortTransaction(context);
					failCount++;
					multiWriteMessageToFile(failedObjectidWriter, sheetName+"\t" + sPhysicalNumberRows+"\t" + stRecordNumber +"\t" +stRecordCodeDescription+"\t" +stRecordCommonCodeLev3 +"\t" +stRecordCheckPromote+"\t"+stRecordCodeLev2+"\t" +stRecordCommonCodeLev2+"\t"+stRecordCommonCodeNameLev2 +"\t");
					multiWriteMessageToFile(logWriter, "sheetName: "+sheetName+"\t" + sPhysicalNumberRows + " \t" + e2.getMessage());
					mulitWriteErrorToFile(errorStream, "sheetName: "+sheetName+"\t" + sPhysicalNumberRows + " \t" + e2.getMessage());
					e2.printStackTrace(errorStream);
				}
			}
		}catch(Exception e) {
			multiWriteMessageToFile(logWriter, "sheetName: "+sheetName+"\t" + e.getMessage());
			mulitWriteErrorToFile(errorStream, "sheetName: "+sheetName+"\t" + e.getMessage());
			e.printStackTrace(errorStream);
		}finally{
			if(bCheckTriggerOff){
				MqlUtil.mqlCommand(context, "Trigger On");
				bCheckTriggerOff = false;
			}
			multiWriteMessageToFile(logWriter, "==================================================================================== ");
			multiWriteMessageToFile(logWriter, "		MIGRATION CLOSE TIME:  " + cdmCommonExcel.getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, "		MIGRATION LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms   ");
			multiWriteMessageToFile(logWriter, "		TATAL COUNT ("+totalCount +")    FAIL COUNT: ("+failCount +")    SUCCESS COUNT: ("+successCount+")        ");
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			try {
				if (null != logWriter)
						logWriter.close();

					if (null != errorStream)
						errorStream.close();

					if (null != successObjectidWriter)
						successObjectidWriter.close();

					if (null != failedObjectidWriter)
						failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

			System.out.println("cdmCommonCodeMigration : createVehicleCommonCode--> end.  "+cdmCommonExcel.getTimeStamp2());
		}
	}
	
	
	/**
	 * type에따른 cell value
	 * @param cell
	 * @return
	 * @throws Exception
	 */
	public String getCellValue(XSSFCell cell) throws Exception {
		String st = new String("");
		try {
			if (cell == null)
				return "";

			switch (cell.getCellType()) {

			case XSSFCell.CELL_TYPE_NUMERIC:

//				if (HSSFDateUtil.isCellDateFormatted(cell)) {
//					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd H:mm");
//					st = formatter.format(cell.getDateCellValue());
//				} else {
					double numbericCellValue = cell.getNumericCellValue();
					 int intNumbericCellValue = (int)numbericCellValue;
					String value = String.valueOf(intNumbericCellValue);
//					StringList stListValue = FrameworkUtil.split(value, ".");
//					if (stListValue.size() > 1) {
//						String endSt = (String) stListValue.get(1);
//						value = endSt.equals("0") ? (String) stListValue.get(0) : value;
//					}
//
					st = value;
//				}

				break;

			case XSSFCell.CELL_TYPE_FORMULA:

				st = String.valueOf(cell.getCellFormula());

				break;

			case XSSFCell.CELL_TYPE_STRING:

				st = String.valueOf(cell.getStringCellValue());

				break;

			case XSSFCell.CELL_TYPE_BLANK:

				st = "";
				
				break;

			case XSSFCell.CELL_TYPE_ERROR:

				st = String.valueOf(cell.getErrorCellValue());
				break;

			default:
				break;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return st;

	}
	
	/**
	 * type에따른 cell value
	 * @param cell
	 * @return
	 * @throws Exception
	 */
	public String getCellValue2(Cell cell) throws Exception {
		String st = new String("");
		try {
			if (cell == null)
				return "";

			switch (cell.getCellType()) {

			case Cell.CELL_TYPE_NUMERIC:

//				if (HSSFDateUtil.isCellDateFormatted(cell)) {
//					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd H:mm");
//					st = formatter.format(cell.getDateCellValue());
//				} else {
					double numbericCellValue = cell.getNumericCellValue();
					String value = String.valueOf(numbericCellValue);
//					StringList stListValue = FrameworkUtil.split(value, ".");
//					if (stListValue.size() > 1) {
//						String endSt = (String) stListValue.get(1);
//						value = endSt.equals("0") ? (String) stListValue.get(0) : value;
//					}
//
					st = value;
//				}

				break;

			case Cell.CELL_TYPE_FORMULA:

				st = String.valueOf(cell.getCellFormula());

				break;

			case Cell.CELL_TYPE_STRING:

				st = String.valueOf(cell.getStringCellValue());

				break;

			case Cell.CELL_TYPE_BLANK:

				st = "";
				
				break;

			case XSSFCell.CELL_TYPE_ERROR:

				st = String.valueOf(cell.getErrorCellValue());
				break;

			default:
				break;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return st;

	}
	
	private void mulitWriteErrorToFile(PrintStream pStrem , String message) throws Exception {
		pStrem.write(message.getBytes("UTF-8"));
		pStrem.write("\n".getBytes("UTF-8"));
		pStrem.flush();
	}
	private void multiWriteMessageToFile(BufferedWriter buff, String message) throws Exception {
		buff.write(message + "\n");
		buff.flush();

	}
	
	public Map createObject(Context context, String[] args) {
		try {
			Map paramMap = JPO.unpackArgs(args);
//			System.out.println(paramMap);
			/*9/5/16 modify mj.kim start */
			String checkMigration = (String)paramMap.get("checkMigration");
			/*9/5/16 modify mj.kim end */
			String objectId = (String)paramMap.get("objectId");
			String code = (String)paramMap.get("Name");
			String codeKo = (String)paramMap.get("codeKo");
			String codeEn = (String)paramMap.get("codeEn");
			String codeCn = (String)paramMap.get("codeCn");
			//add js.hyun 2016.08.23 start
			String temp1 = (String)paramMap.get("temp1") == null ? "" : (String)paramMap.get("temp1");
			String temp2 = (String)paramMap.get("temp2") == null ? "" : (String)paramMap.get("temp2");
			String temp3 = (String)paramMap.get("temp3") == null ? "" : (String)paramMap.get("temp3");
			//add js.hyun 2016.08.23 end
			String description = (String)paramMap.get("description");

			//add js.hyun 2016.08.23 start
			String ngType = "eService Number Generator";
			String ngName = "cdmCommonCodeNumberGenerator";
			String ngRev = "cdmCommonCode";
			String ngVault = "eService Administration";
			BusinessObject numGenerator = new BusinessObject(ngType, ngName, ngRev, ngVault);
			int name = Integer.parseInt(numGenerator.getAttributeValues(context, "eService Next Number").getValue());
			//add js.hyun 2016.08.23 end
			
			DomainObject domObj = new DomainObject();
			domObj.createObject(context, 
								"cdmCommonCode",
								String.format("CC-%010d", name), 
								"-", 
								"cdmCommonCodePolicy", 
								"eService Production");
			
			//add js.hyun 2016.08.23 start
			numGenerator.setAttributeValue(context, "eService Next Number", String.valueOf(name+1));
			//add js.hyun 2016.08.23 end
			
			Map attrMap = new HashMap();
			//add js.hyun 2016.08.23 start
			attrMap.put("cdmCommonCode", code);
			attrMap.put("cdmCommonTemp1", temp1);
			attrMap.put("cdmCommonTemp2", temp2);
			attrMap.put("cdmCommonTemp3", temp3);
			//add js.hyun 2016.08.23 end
			attrMap.put("cdmCommonCodeNameKo", codeKo);
			attrMap.put("cdmCommonCodeNameEn", codeEn);
			attrMap.put("cdmCommonCodeNameCn", codeCn);
			/*  9/5/16 modify mj.kim start  */
			if(cdmStringUtil.isNotEmpty(checkMigration) && "Y".equals(checkMigration)){
				attrMap.put("cdmCheckMigration", checkMigration);
			}
			/*  9/5/16 modify mj.kim end  */
			domObj.setAttributeValues(context, attrMap);
			domObj.setDescription(context, description);
			
			//if objectId is SPACE, emxTable is null and emxIndentedTable id ""(SPACE) 
			if(objectId == null || "".equals(objectId)){
//				BusinessObject rootObj = new BusinessObject("cdmCommonCode", "CommonCodeRoot", "-", "eService Production");
				String mqlId = MqlUtil.mqlCommand(context, "temp query bus \"cdmCommonCode\" \"CommonCodeRoot\"  \"-\" select id dump |");
				objectId = (String)FrameworkUtil.split(mqlId, "|").get(3);
//				System.out.println("objectId "+objectId);
//				objectId = rootObj.getObjectId(context);
			}
			
			domObj.setRelatedObject(context, 
									"cdmCommonCodeRelationship", 
									false, 
									objectId);
			
			Map createdIdMap = new HashMap();
			createdIdMap.put("id", domObj.getId(context));
			
			return createdIdMap;
		} catch (Exception e) {
			
			e.printStackTrace();
			
			return null;
		}
	}

}
