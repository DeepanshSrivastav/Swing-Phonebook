import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;

import com.mando.util.cdmCommonExcel;
import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.RelationshipType;
import matrix.util.SelectList;
import matrix.util.StringList;

/**
 * user migration을 위한 JPO 페이지
 * 
 * 0. 파일을 사용하기위한 context 정보 획득 필요 
 * 	  bat파일 혹은 스케줄러에 담아서 있어야할지 확인 필요
 * 
 * 1. 파일 추출
 * 	   파일 위치 고정 필요
 * 	   파일 이름 rule 필요
 * 
 * 2. 정보 validation
 * 		파일 존재여부
 * 		기준 정보에 따른 데이타 확인 필요 
 * 		log 정보 필요  (위치관련 조정 필요할수 있음)
 * 		 파일에 오류 에 따른 validation 필요 ( 데이타 null 및 엑셀에 존재하는 오류 관련 )
 * 		
 * 3. object 생성
 * 		Company 하위에서 User 생성 
 *		Business Unit 하위에서 User 생성
 *			데이타 생성시 relationship, owner, attribute 확인 필요
 *			필수 정보 요청 및 확인 , 없다면 대책 필요
 *			다국어가 어떤정보에 있는지 확인 필요
 *		파일을 추가 하는 경우 파일명 관련 확인 필요 
 * 
 * 4. export 하는 경우(생략될수 있음) 
 * 	 	저장될 위치 확인 필요 
 * 		
 * 5. 생성 후 log 파일 생성
 * 		저장될 위치 확인 필요 
 * 
 * 
 * company 찾는 경우
 * 유저의 권한정보 확인 구성 how ?? 필수 정보
 * 유저가 특정 company unit에서  추가될경우   
 * 
 *  9/6 
 * java console로 진행할경우 데이타가 깨짐 
 * mql로 실행해서 넣었음 
 * 
 * @author mj
 *
 */
public class cdmPersonMigration_mxJPO {
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void mxMain(Context context, String args[]) throws Exception {
		try {
			
			System.out.println("cdmPersonMigration_mxJPO mehtod ~");
			Map paramMap = new HashMap();
			paramMap.put("path", "");
			createPerson(context,JPO.packArgs(paramMap));
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	

	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void createPerson(Context context, String args[]) throws Exception {
		Date date = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		String sDate = sdf.format(date);
		
		String stLogin = ""; 
		String stNameKO = "";
		String stTitle = "";
		String stEmail = "";
		
		Map paramMap = (Map)JPO.unpackArgs(args);
		String path = (String)paramMap.get("path");
		String errorDirectory= (String)paramMap.get("errorDirectory"); //log 저장 위치
		String createDirectory = (String)paramMap.get("createDirectory"); //log 저장 위치
		String sheetName = (String)paramMap.get("sheetName");

		
//		path =  "C:\\temp\\Import_File\\20160901_user_info_00.xlsx"; // user infomation
//		createDirectory = "C:\\temp\\confirm_File"; // attrute group, part Family
//		errorDirectory = "C:\\temp\\confirm_File"; // attrute group, part Family
		boolean createCheck = false;
		
		try {

			if (cdmStringUtil.isEmpty(sheetName)) {
				sheetName = "Sheet1";
			}
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, path, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();

			MapList companyNameMapList = new MapList();

			String companyName = "";
			String tempCompanyName = "Company Name";
			SelectList companySelectList = new SelectList();
			companySelectList.addId();

			companyNameMapList = DomainObject.findObjects(context, cdmConstantsUtil.TYPE_COMPANY, tempCompanyName, "*", "*", "eService Production", "", "", true, companySelectList, (short) 0);
			for (Iterator companyIterator = companyNameMapList.iterator(); companyIterator.hasNext();) {
				Map companyMap = (Map) companyIterator.next();
				companyName = (String) companyMap.get("id");
				break;
			}
			
			for (int i = 1; i <= physicalNumberRows; i++) {
				createCheck = false;

				XSSFRow row = sheet.getRow(i);
				if (row == null)
					continue;

				XSSFCell cell_1 = row.getCell(1);
				XSSFCell cell_2 = row.getCell(2);
				XSSFCell cell_3 = row.getCell(3);
				XSSFCell cell_4 = row.getCell(4);

				/* login name korean, title division e mail */
				stLogin = String.valueOf(cdmCommonExcel.getCellValue(cell_1));
				stNameKO = String.valueOf(cdmCommonExcel.getCellValue(cell_2)).trim();
				stTitle = String.valueOf(cdmCommonExcel.getCellValue(cell_3)).trim();
				stEmail = String.valueOf(cdmCommonExcel.getCellValue(cell_4)) == "null" ? "" : String.valueOf(cdmCommonExcel.getCellValue(cell_4)).trim();

				String sMql = "eval expr 'count TRUE' on temp query bus 'Person' '" + stLogin + "' - ";
				String sMqlReturn = MqlUtil.mqlCommand(context, sMql);

				int mqlResultInteger = Integer.valueOf(sMqlReturn);
				String sFirstName = "";
				String sLastName = "";
				if (cdmStringUtil.isEmpty(stNameKO)) {
					stNameKO = "";
				} else {
					sFirstName = stNameKO.substring(0, 1);
					sLastName = stNameKO.substring(1);
				}
				
				if (mqlResultInteger == 0) {
					if (cdmStringUtil.isEmpty(stNameKO)) {
						stNameKO = "";
					} else {
						sFirstName = stNameKO.substring(0, 1);
						sLastName = stNameKO.substring(1);
					}

					String eService_Production = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;

					String strEmployeeRole = PropertyUtil.getSchemaProperty(context, "role_Employee");
					String employeeSymbolicName = FrameworkUtil.getAliasForAdmin(context, "role", strEmployeeRole, true);
					String strBasicUserRole = PropertyUtil.getSchemaProperty(context, "role_BasicUser");

					String strRoles = employeeSymbolicName;
					String basicUserRole = FrameworkUtil.getAliasForAdmin(context, "role", strBasicUserRole, true);
					// strRoles += " " + basicUserRole;

					String str1 = "{" + strRoles + "}";
					String str2 = "{" + "" + "}";
					String str3 = "0"; // 0이 아니면 0보다 큰값이여야하며 그럴경우 mail 전송된다.
					String stPwd = "";
					if (cdmStringUtil.isEmpty(stPwd)) {
						stPwd = stLogin;
					}
					String sPersonId = "";
					String sResult = "";
					String sError = "";

					MQLCommand mqlcommand = new MQLCommand();
					mqlcommand.open(context);

					/*
					 * EX. execute program eServicecommonCreatePerson.tcl
					 * "abcde" "" "" "0" "eService Production" "abcde@naver.com"
					 * "true" ""; loginName,password, {" strRoles "},
					 * sLimit,strVault,emailAddress,"FALSE",{strGroups}
					 */
					String sMqlCreatePerson = "execute program eServicecommonCreatePerson.tcl  \"" + stLogin + "\" \"" + stPwd + "\" " + str1 + " \"" + str3 + "\" \"" + eService_Production + "\" \"" + stEmail + "\" \"" + "FALSE" + "\" " + str2;

					mqlcommand.executeCommand(context, sMqlCreatePerson);
					sResult = mqlcommand.getResult();
					sError = mqlcommand.getError();
					mqlcommand.close(context);

					StringTokenizer localStringTokenizer = new StringTokenizer(sResult, "|");
					String str6 = localStringTokenizer.nextToken().trim();
					sPersonId = localStringTokenizer.nextToken().trim();

					com.matrixone.apps.common.Person objPerson = new com.matrixone.apps.common.Person(sPersonId);

					BusinessObject busPerson = new BusinessObject(sPersonId);
					String strEmployeeRel = PropertyUtil.getSchemaProperty(context, "relationship_Employee");

					BusinessObject busCompany = new BusinessObject(companyName);
					busCompany.open(context);
					busPerson.connect(context, new RelationshipType(strEmployeeRel), false, busCompany);

					createCheck = true;
					
					Map requestMap = new HashMap();
					requestMap.put("Email Address", stEmail);
					requestMap.put("First Name", sFirstName);
					requestMap.put("Last Name", sLastName);
					requestMap.put("Title", stTitle);
					
					 objPerson.setAttributeValues(context, requestMap);
					// 룰 정보 추가
					// ComponentsUtil.assignPersonToGroups(context, sCompanyId,
					// sPersonName, roleList);
				} else {}

				FileWriter fw = null;
				StringBuffer errorMessage = new StringBuffer();
				errorMessage.append(stLogin).append("|").append(stNameKO).append("|").append(stTitle).append("|").append(stEmail).append("|createCheck-").append(createCheck).append(" \n");

				String createFile = "createCheckPersonFile_" + sDate + ".txt";
				fw = new FileWriter(errorDirectory + cdmCommonExcel.BACKSLASH + createFile, true);
				fw.write(errorMessage.toString());
				fw.flush();
				fw.close();

			}

		}catch( Exception e ){
			e.printStackTrace();
			FileWriter fw = null;
			StringBuffer errorMessage = new StringBuffer();
			errorMessage.append(stLogin).append("|").append(stNameKO).append("|").append(stTitle).append("|").append(stEmail).append("|createCheck-").append(createCheck).append(" \n");
			
			String errorFile = "errorPersonFile_" + sDate + ".txt";
			fw = new FileWriter(errorDirectory + cdmCommonExcel.BACKSLASH + errorFile, true);
			fw.write(errorMessage.toString());
			fw.flush();
			fw.close();
//			throw new Exception( "ERROR :: create Person :: " + e.getMessage()  );
			
		}
		System.out.println("eeee");
	
	}
	 
	
	
}