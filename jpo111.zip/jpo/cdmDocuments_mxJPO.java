import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import org.apache.poi.util.SystemOutLogger;

import com.mando.util.cdmConstantsUtil;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.engineering.PartDefinition;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.RelationshipList;
import matrix.util.SelectList;
import matrix.util.StringList;

public class cdmDocuments_mxJPO {
	public MapList getAllDocuments(Context context, String[] args) throws Exception {
		try {
			StringBuffer objectWhere = new StringBuffer();
			objectWhere.append("attribute[");
			objectWhere.append(CommonDocument.ATTRIBUTE_IS_VERSION_OBJECT);
			objectWhere.append("] == False && owner ==\"");
			objectWhere.append(context.getUser());
			objectWhere.append("\"");
			SelectList selectList = new SelectList();
			selectList.addId();
			// get all Documents of type Document
			MapList result = DomainObject.findObjects(context, "Document", "*", objectWhere.toString(), selectList);
			return result;
		} catch (Exception exp) {
			throw new Exception(exp.toString());
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void setExtensionAttribute(Context context, String[] args) {
		try {
			Map paramMap = JPO.unpackArgs(args);

			String objectId 	= (String) paramMap.get("objectId");
			String type 		= (String) paramMap.get("type");
			String projectId 	= (String) paramMap.get("project");
			String partId 		= (String) paramMap.get("part");
			String documentType = (String) paramMap.get("documentType");
			String scale 		= (String) paramMap.get("scale");
			String titleType 	= (String) paramMap.get("titleType");
			String pageSize 	= (String) paramMap.get("pageSize");
			String mass 		= (String) paramMap.get("mass");
			String surface 		= (String) paramMap.get("surface");
			String material 	= (String) paramMap.get("material");

			DomainObject document = new DomainObject(objectId);

			if (projectId != null && !"".equals(projectId)) {
				document.setRelatedObject(context, "cdmDocumentsProjectRelationship", true, projectId);
			}

			Map attrDoc = new HashMap();

			attrDoc.put("cdmDocumentsDocumentType", documentType);

			try {
				if ("cdmNXDrawing".equals(type) || "cdmAutoCAD".equals(type) || "cdmNXPart".equals(type)) {
					
					if ("cdmNXDrawing".equals(type) || "cdmAutoCAD".equals(type)) {

						attrDoc.put("cdmDocumentsScale", scale);
						attrDoc.put("cdmDocumentsTitleType", titleType);
						attrDoc.put("cdmDocumentsPageSize", pageSize);
						
						String strDocObjName = document.getInfo(context, DomainObject.SELECT_NAME);
						String strDrwNo = strDocObjName.replaceAll("\\-.+", "");

						attrDoc.put("cdmDrawingNo", strDrwNo);
						
					} else if ("cdmNXPart".equals(type)) {

						attrDoc.put("cdmDocumentsMass", mass);
						attrDoc.put("cdmDocumentsSurface", surface);
						attrDoc.put("cdmDocumentsMaterial", material);
					}
					
					document.setState(context, "IN_WORK");
					
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				// MqlUtil.mqlCommand(context, true, "trigger on", true);
			}

			document.setAttributeValues(context, attrDoc);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * CheckIn Trigger
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds no arguments [0] should be ${OBJECTID} [1] should be
	 *            ${FILENAME_ORIGINAL} [2] should be ${FORMAT} [3] should be
	 *            ${FILENAME}
	 * @author jh.Lee
	 */
	public void fileCheckInTrigger(matrix.db.Context context, String[] args) throws Exception {
		try {
			System.out.println("fileCheckInTrigger ============================= START");
			String strObjectId = args[0];
			String strOriginalFileName = args[1];
			String strFormat = args[2];
			String strFileName = args[3];
			String strWorkspacePath = context.createWorkspace();
			String strUser = context.getUser();
			System.out.println("strUser                   =     " + strUser);
			System.out.println("strWorkspacePath          =     " + strWorkspacePath);
			System.out.println("strObjectId               =     " + strObjectId);
			System.out.println("strOriginalFileName       =     " + strOriginalFileName);
			System.out.println("strFormat                 =     " + strFormat);
			System.out.println("strFileName               =     " + strFileName);

			DomainObject domObj = new DomainObject(strObjectId);
			domObj.checkoutFile(context, false, strFormat, strOriginalFileName, strWorkspacePath);
			/*
			 * encodeing...
			 */
			MqlUtil.mqlCommand(context, "delete bus \"" + strObjectId + "\" format " + strFormat + " file \"" + strOriginalFileName + "\"");
			domObj.checkinFile(context, false, false, null, strFormat, "STORE", strOriginalFileName, strWorkspacePath);

			File file = new File(strWorkspacePath, strOriginalFileName);
			file.delete();
			context.deleteWorkspace();

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * CheckOut Trigger
	 * 
	 * @param context
	 *            the eMatrix <code>Context</code> object
	 * @param args
	 *            holds no arguments [0] should be ${OBJECTID} [1] should be
	 *            ${FILENAME_ORIGINAL} [2] should be ${FORMAT} [3] should be
	 *            ${FILENAME}
	 * @author jh.Lee
	 */
	public void fileCheckOutTrigger(matrix.db.Context context, String[] args) throws Exception {
		try {
			System.out.println("fileCheckOutTrigger ============================= START");
			String strObjectId = args[0];
			String strOriginalFileName = args[1];
			String strFormat = args[2];
			String strFileName = args[3];
			String strWorkspacePath = context.createWorkspace();
			String strUser = context.getUser();
			System.out.println("fileCheckOutTrigger...");
			System.out.println("strUser                   =     " + strUser);
			System.out.println("strWorkspacePath          =     " + strWorkspacePath);
			System.out.println("strObjectId               =     " + strObjectId);
			System.out.println("strOriginalFileName       =     " + strOriginalFileName);
			System.out.println("strFormat                 =     " + strFormat);
			System.out.println("strFileName               =     " + strFileName);

			/*
			 * decodeing...
			 */
			DomainObject object = new DomainObject(strObjectId);
			object.checkinFile(context, false, false, null, strFormat, "STORE", strOriginalFileName, strWorkspacePath);
			String srcFile = strWorkspacePath + File.separator + strOriginalFileName;
			File file = new File(srcFile);
			file.delete();
			context.deleteWorkspace();

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	@SuppressWarnings({ "rawtypes", "deprecation" })
	public String setDocumentsPartField(Context context, String[] args) throws Exception {
		StringBuffer sbReturnString = new StringBuffer();
		String strPartName = "";
		String strPartId = "";

		try {
			ContextUtil.startTransaction(context, true);
			Map programMap = JPO.unpackArgs(args);
			Map paramMap = (Map) programMap.get("requestMap");

			// 현재 Document.
			String strDocumentId = (String) paramMap.get("copyObjectId");
			DomainObject domDocumentId = new DomainObject(strDocumentId);
			
			// Previous Document.
			String prevDocumentId = domDocumentId.getInfo(context, "previous.id");
			String prevDocumentCurrent = domDocumentId.getInfo(context, "previous.current");
			
			// 현재 Document에 연결 된 Part Current.
			String strCurrent = MqlUtil.mqlCommand(context, "print bus " + strDocumentId + " select to["+DomainConstants.RELATIONSHIP_PART_SPECIFICATION +"].from.current dump");
			
			// Previous Documents가 있는 경우.
			if(!"".equals(prevDocumentId) && prevDocumentId != null && "Preliminary".equals(prevDocumentCurrent)){
				strPartName = MqlUtil.mqlCommand(context, "print bus " + prevDocumentId + " select to["+DomainConstants.RELATIONSHIP_PART_SPECIFICATION +"].from.name dump");
				strPartId 	= MqlUtil.mqlCommand(context, "print bus " + prevDocumentId + " select to["+DomainConstants.RELATIONSHIP_PART_SPECIFICATION +"].from.id dump");
			
			// Previous Documents가 없는 경우.
			}else if("Preliminary".equals(strCurrent)){
				strPartName = MqlUtil.mqlCommand(context, "print bus " + strDocumentId + " select to["+DomainConstants.RELATIONSHIP_PART_SPECIFICATION +"].from.name dump");
				strPartId 	= MqlUtil.mqlCommand(context, "print bus " + strDocumentId + " select to["+DomainConstants.RELATIONSHIP_PART_SPECIFICATION +"].from.id dump");
			}
			
			// Field 출력
			if (!DomainConstants.EMPTY_STRING.equals(strPartName)) {
				sbReturnString.append("<input type=\"text\"  name=\"Part\" id=\"Part\" value=\"" + strPartName + "\" width=\"50\" readOnly=\"true\">");
				sbReturnString.append("</input>");
				sbReturnString.append("<input type=\"hidden\" name=\"PartId\" value=\"" + strPartId + "\">");
				sbReturnString.append("</input>");
			} else {
				sbReturnString.append("<input type=\"text\"  name=\"Part\" id=\"Part\" value=\"Invalid Part's State.\" width=\"50\" readOnly=\"true\">");
				sbReturnString.append("</input>");
			}

			ContextUtil.commitTransaction(context);
		} catch (Exception e) {
			// TODO: handle exception
			ContextUtil.abortTransaction(context);
		}
		return sbReturnString.toString();

	}
	
	
	
	/**
	 * executes this when cdmMadoCADModel is revised.
	 * 
	 * disconnect REL "Part Specification"
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void floatPartSpecification(Context context, String[] args) throws Exception {
		
		String strDrawingType = args[0];  //${TYPE}
		String strDrawingId = args[1];    //${OBJECTID}
		String strNewDrawingId = args[2]; //${NEWOBJECTID}
		
		ContextUtil.pushContext(context, null, null, null);

		try {
			MqlUtil.mqlCommand(context, "trigger off", new String[]{});
			
			if ("cdmAutoCAD".equals(strDrawingType) || "cdmNXDrawing".equals(strDrawingType)) {  
				
			
				DomainObject doDrawing = new DomainObject(strDrawingId);
				StringList slPartSpecRels = doDrawing.getInfoList(context, "to["+DomainConstants.RELATIONSHIP_PART_SPECIFICATION+"].id");
				
				for (Iterator iterator = slPartSpecRels.iterator(); iterator.hasNext();) {
					String strPartSpecId = (String) iterator.next();
					DomainRelationship doRel = new DomainRelationship(strPartSpecId);
					doRel.open(context);
					
					DomainObject doPart = new DomainObject(doRel.getFrom());
					String strPartCurrent = doPart.getInfo(context, DomainObject.SELECT_CURRENT);
					
					if( "Preliminary".equals(strPartCurrent)) {
						
						doRel.remove(context);
						DomainRelationship.connect(context, doPart, DomainConstants.RELATIONSHIP_PART_SPECIFICATION, new DomainObject(strNewDrawingId));
						
					}
				}
			
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		} finally {
			
			MqlUtil.mqlCommand(context, "trigger on", new String[]{});
			ContextUtil.popContext(context);
		}
		
		
	}

	
	/**
	 * 
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int updatePartDrawingNo(Context context, String[] args) throws Exception {
		
		/**
		 *   'eService Program Argument 1' '${FROMOBJECTID}'
             'eService Program Argument 2' '${TOOBJECTID}'
		 */
		try {

			String strFromObjectId = args[0]; // Part
			String strToObjectId = args[1]; // Document

			
			DomainObject doDocument = new DomainObject(strToObjectId);

			String strDRWType = doDocument.getInfo(context, DomainObject.SELECT_TYPE);
			String strDRWNo = doDocument.getInfo(context, "attribute[cdmDrawingNo]");

			if ("cdmNXDrawing".equals(strDRWType) || "cdmAutoCAD".equals(strDRWType)) {

				DomainObject doPart = new DomainObject(strFromObjectId);
				System.out.println("strDRWNo     >>>>>     " + strDRWNo);
				doPart.setAttributeValue(context, "cdmPartDrawingNo", strDRWNo);
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return 0;

	
		
	}
	
	
}
