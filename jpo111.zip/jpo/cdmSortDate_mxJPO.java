import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;

import matrix.db.Context;


public class cdmSortDate_mxJPO extends emxCommonBaseComparator_mxJPO {

	
	public cdmSortDate_mxJPO (Context context, String[] args) throws Exception {
	}

	/**
	  * Default Constructor.
	  */
	public cdmSortDate_mxJPO () {
	}

	@Override
	public int compare(Object object1, Object object2) {
		Map map1 = (Map)object1;
		Map map2 = (Map)object2;

		/*Get sort info keys*/
		Map sortKeys = getSortKeys();

		String keyName = (String) sortKeys.get("name");
		String keyDir  = (String) sortKeys.get("dir");

		//* values will be retrieved for the lower case column names, this has been done to get actual data displayed in html output
		//* If the value for lower case key is null, then get column values for original column name passed.

		String stringValue1 = (String) map1.get(keyName); 
		String stringValue2 = (String) map2.get(keyName);

		boolean str1Empty = isEmpty(stringValue1);
		boolean str2Empty = isEmpty(stringValue2);

		//* If both values are null or empty diff =  0
		//* If first string is null or empty diff = -1
		//* If second string is null or empty diff = 1
		//* If both the strings are not empty then compare the strings
		int diff = 0; 
		try {
			diff = str1Empty && str2Empty ?  0 : str1Empty ? -1 : str2Empty ?  1 : getDiffDate(stringValue1, stringValue2);
		} catch (Exception e) {
			throw new RuntimeException(e.getMessage());
		}

		//If the direction is not ascending, then invert the sign of 'diff' value 
		return ("ascending".equals(keyDir)? diff : -diff);
	}

	private boolean isEmpty(String checkValue) {
		return (checkValue == null || checkValue.equals("")); 
	}

	private int getDiffDate(String sValue1, String sValue2) throws Exception {
		SimpleDateFormat digDateFormat = new SimpleDateFormat("yyyy. M. d HH:mm:ss");
		Date date1 = digDateFormat.parse(sValue1);
		Date date2 = digDateFormat.parse(sValue2);
		return date1.compareTo(date2);
	}
}
