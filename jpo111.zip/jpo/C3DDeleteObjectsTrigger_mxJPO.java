/*
**  ${CLASSNAME}.java
**
**  Copyright Dassault Systemes, 1992-2015.
**  All Rights Reserved.
**  This program contains proprietary and trade secret information of Dassault Systemes and its 
**  subsidiaries, Copyright notice is precautionary only
**  and does not evidence any actual or intended publication of such program
**
**	Whenever the C3DViewable relationship gets deleted then it will trigger a Delete Override trigger,
**  which will call this program. This JPO will take care of deleting C3DViewable and its connected C3DAutoVueMarkups objects.
**  This JPO accepts three arguments, From side object ID, To side object ID and 
**  Relationship ID for the objects connected by C3DViewale relationship.
*/
import matrix.db.Context;

public class C3DDeleteObjectsTrigger_mxJPO extends C3DDeleteObjectsTriggerBase_mxJPO {
    public C3DDeleteObjectsTrigger_mxJPO() {
        super();
    }

    public C3DDeleteObjectsTrigger_mxJPO(Context  iContext, String[] iArguments) /*throws Exception*/ {
        super(iContext,iArguments);
    }
}

