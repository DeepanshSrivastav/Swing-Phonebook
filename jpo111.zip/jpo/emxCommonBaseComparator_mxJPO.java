/*
**	emxCommonBaseComparator
**
**  Copyright (c) 1992-2015 Dassault Systemes.
**  All Rights Reserved.
**  This program contains proprietary and trade secret information of MatrixOne,
**  Inc.  Copyright notice is precautionary only
**  and does not evidence any actual or intended publication of such program
**
*/

/**
 * The <code>emxCommonBaseComparator</code> class contains methods of emxCommonBaseComparatorBase.
 *
 * @version AEF 10.0.1.0 - Copyright (c) 2003, MatrixOne, Inc.
 */

public abstract class emxCommonBaseComparator_mxJPO extends emxCommonBaseComparatorBase_mxJPO
{
}

