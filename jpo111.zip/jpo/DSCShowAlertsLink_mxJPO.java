/*
**  DSCShowAlertsLink
**
**  Copyright Dassault Systemes, 1992-2007.
**  All Rights Reserved.
**  This program contains proprietary and trade secret information of Dassault Systemes and its 
**  subsidiaries, Copyright notice is precautionary only
**  and does not evidence any actual or intended publication of such program
**
** 
*/

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessObjectWithSelectList;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class DSCShowAlertsLink_mxJPO extends DSCShowAlertLinkBase_mxJPO {
	private String localeLanguage							= null;
	private HashMap integrationNameGCOTable					= null;
	private MCADServerResourceBundle serverResourceBundle	= null;
	private IEFGlobalCache cache							= null;
	private MCADMxUtil util					= null;

	public DSCShowAlertsLink_mxJPO(Context context, String[] args) throws Exception
	{
		 super(context, args);
	}

	/**
	 * OOTB Override
	 */
	@Override
	public Object getHtmlStringForFrameworkTable(Context context, String[] args) throws Exception {
		HashMap paramMap = (HashMap)JPO.unpackArgs(args);  
		MapList relBusObjPageList = (MapList)paramMap.get("objectList");
		localeLanguage = (String)paramMap.get("languageStr");  	
		String portalName = (String)paramMap.get("portCmdName");	

		HashMap paramList = (HashMap)paramMap.get("paramList");			
		integrationNameGCOTable = (HashMap)paramList.get("GCOTable");

		if(localeLanguage == null)
			localeLanguage = (String)paramList.get("languageStr");

		if(integrationNameGCOTable == null)
			integrationNameGCOTable = (HashMap)paramMap.get("GCOTable");

		if(integrationNameGCOTable == null) {}

		return getHtmlStringForTable(context, relBusObjPageList, portalName);
	}
	
	private Object getHtmlStringForTable(Context context, MapList relBusObjPageList, String portalName) throws Exception {
		Vector columnCellContentList	= new Vector();
		String sUseMinor				= "";

		serverResourceBundle			= new MCADServerResourceBundle(localeLanguage);
		cache							= new IEFGlobalCache();
		util							= new MCADMxUtil(context, serverResourceBundle, cache);

		//HashMap ebomTNRebomConfigObjMap = new HashMap();

		String[] objIds = new String[relBusObjPageList.size()];
		
		for (int i = 0; i < relBusObjPageList.size(); i++) {
			Map objDetails = (Map)relBusObjPageList.get(i);
			objIds[i] = (String)objDetails.get("id");
			
			// Designer Central 10.6.0.1
			sUseMinor = (String)objDetails.get("UseMinor");
		}

		try {
			String renameToolTip	       = serverResourceBundle.getString("mcadIntegration.Server.AltText.AlertRename");
			String replaceToolTip	       = serverResourceBundle.getString("mcadIntegration.Server.AltText.AlertReplace");
			String batchProcessorToolTip   = serverResourceBundle.getString("mcadIntegration.Server.AltText.AlertBatchRename");
			String markupToolTip           = serverResourceBundle.getString("mcadIntegration.Server.AltText.AlertMarkup");
			String partToolTip             = serverResourceBundle.getString("mcadIntegration.Server.AltText.AlertPart");
			String baselineToolTip         = serverResourceBundle.getString("mcadIntegration.Server.AltText.AlertBaseline");

			// [B] modify by jtkim 2016-01-09
			// [NAV-001] Added image related to alerts column.
			String drawingToolTip         = serverResourceBundle.getString("mcadIntegration.Server.AltText.AlertDrawing");
			String catPartToolTip         = serverResourceBundle.getString("mcadIntegration.Server.AltText.Alert3DPart");
			// [E] modify by jtkim 2016-01-09

			StringList busSelectionList = getBusSelectionList(context, util);

			BusinessObjectWithSelectList buslWithSelectionList = BusinessObject.getSelectBusinessObjectData(context, objIds, busSelectionList);

			for (int i = 0; i < buslWithSelectionList.size(); i++) {			
				BusinessObjectWithSelect busObjectWithSelect = (BusinessObjectWithSelect)buslWithSelectionList.elementAt(i);

				StringBuffer htmlBuffer = new StringBuffer();
				String integrationName	= null;

				String objectId = busObjectWithSelect.getSelectData("id");
				String integrationSource = busObjectWithSelect.getSelectData(ATTR_SOURCE);
				boolean isConnectToBaseLine = false;

				if (integrationSource != null) {
					StringTokenizer integrationSourceTokens = new StringTokenizer(integrationSource, "|");

					if (integrationSourceTokens.hasMoreTokens())
						integrationName  = integrationSourceTokens.nextToken();
				}

				if (integrationName != null) {
				//	MCADGlobalConfigObject gco = (MCADGlobalConfigObject)integrationNameGCOTable.get(integrationName);
					if (null == cache) {
						cache = new IEFGlobalCache();
					}

					//MCADServerGeneralUtil serverGeneralUtil1 = new MCADServerGeneralUtil(context, gco, serverResourceBundle, cache);

					String checkoutHref = "javascript:checkoutWithValidation('" + integrationName + "', '" + objectId + "', '', '', '')";

					boolean isReplacementDone = false;
					isReplacementDone = isObjectReplaced(context, busObjectWithSelect);

					if (sUseMinor != null && sUseMinor.equals("true"))
						objectId = busObjectWithSelect.getSelectData(SELECT_ON_MAJOR + "last." + SELECT_ON_ACTIVE_MINOR + "id");

					boolean isUpdate = false;
					boolean isAssociatedDesignRenamed = false;
					isUpdate = isObjectRenamed(context, busObjectWithSelect);

					// [B] modify by jtkim 2016-01-09
					// [NAV-001] Added image related to alerts column.
					boolean hasDrawing = false;
					String drawingId = busObjectWithSelect.getSelectData("from[" + cdmConstantsUtil.RELATIONSHIP_ASSOCIATED_DRAWING + "].to.id");
					if (cdmStringUtil.isNotEmpty(drawingId)) hasDrawing = true;

					boolean has3dPart = false;
					String catPartId = busObjectWithSelect.getSelectData("to[" + cdmConstantsUtil.RELATIONSHIP_ASSOCIATED_DRAWING + "].from.id");
					if (cdmStringUtil.isNotEmpty(catPartId)) has3dPart = true;
					// [E] modify by jtkim 2016-01-09

//					if(gco.isBatchProcessorForRenameEnabled())
//						isAssociatedDesignRenamed	= isAssociatedDesignRenamed(context , busObjectWithSelect);

					if (true == isUpdate) {
						htmlBuffer.append(getFeatureIconContent(checkoutHref, "iconAlertChanged.gif", renameToolTip));
					}
//					else if(true == isAssociatedDesignRenamed)
//					{
//						htmlBuffer.append(getFeatureIconContent(checkoutHref, "iconAlertChanged.gif", batchProcessorToolTip));
//					}
					if (true == isReplacementDone) {
						htmlBuffer.append(getFeatureIconContent(checkoutHref, "iconStatusChanged.gif", replaceToolTip));
					}

					// show the Markup alert
					String hasMarkups = "false";
					hasMarkups = busObjectWithSelect.getSelectData(IS_MARKUPS_EXIST);

					if (hasMarkups.equalsIgnoreCase("false")) {
						hasMarkups = busObjectWithSelect.getSelectData(SELECT_ON_ACTIVE_MINOR + IS_MARKUPS_EXIST);
					}
				
					if (hasMarkups.equalsIgnoreCase("true")) {
						htmlBuffer.append(getFeatureIconContent(checkoutHref, "iconAlertMarkup.gif", markupToolTip));
					}				

							
					// show the Part alert
//					IEFEBOMConfigObject ebomConfigObject1 = null;

//					String sEBOMRegistryTNR = gco.getEBOMRegistryTNR();
					
//					if(!ebomTNRebomConfigObjMap.containsKey(sEBOMRegistryTNR))
//					{
//					StringTokenizer token = new StringTokenizer(sEBOMRegistryTNR, "|");
//
//					if(token.countTokens() >= 3)
//					{
//						String sEBOMRConfigObjType			= (String) token.nextElement();
//						String sEBOMRConfigObjName			= (String) token.nextElement();
//						String sEBOMRConfigObjRev			= (String) token.nextElement();
//					
//						ebomConfigObject	= new IEFEBOMConfigObject(context, sEBOMRConfigObjType, sEBOMRConfigObjName, sEBOMRConfigObjRev);
//
//							ebomTNRebomConfigObjMap.put(sEBOMRegistryTNR, ebomConfigObject);
//						} 
//					} 
//					else
//						ebomConfigObject = (IEFEBOMConfigObject) ebomTNRebomConfigObjMap.get(sEBOMRegistryTNR);

					String assignPartToMajor = "true";//ebomConfigObject.getConfigAttributeValue(IEFEBOMConfigObject.ATTR_ASSIGN_PART_TO_MAJOR);[NDM]
					
					String partObjId = busObjectWithSelect.getSelectData(SELECT_ON_SPC_PART + "id");

					if (((partObjId.equals("")) || (partObjId == null)) && ("false".equalsIgnoreCase(assignPartToMajor))) {
						partObjId  = busObjectWithSelect.getSelectData(SELECT_ON_ACTIVE_MINOR + SELECT_ON_SPC_PART + "id");
					}

					// [B] modify by jtkim 2016-01-09
					// [NAV-001] Added image related to alerts column.
					if (partObjId != null && !partObjId.equals("")) {
						if (partObjId.indexOf("") > -1) {
							StringList partIdList = FrameworkUtil.split(partObjId, "");
							for (Iterator partItr = partIdList.listIterator(); partItr.hasNext();) {
								htmlBuffer.append(getDrawingIconContent((String) partItr.next(), "iconAlertPart.gif", partToolTip));
							}
						} else {
							htmlBuffer.append(getDrawingIconContent(partObjId, "iconAlertPart.gif", partToolTip));
						}
//						htmlBuffer.append(getFeatureIconContent(checkoutHref, "iconAlertPart.gif", partToolTip));
					}
					// [E] modify by jtkim 2016-01-09

					isConnectToBaseLine = isDesignBaselined(context , busObjectWithSelect);
					if (isConnectToBaseLine) {						
						htmlBuffer.append(getFeatureIconContent(checkoutHref, "iconSmallBaseline.gif", baselineToolTip));
					}

					// [B] modify by jtkim 2016-01-09
					// [NAV-001] Added image related to alerts column.
					if (hasDrawing) {
						if (drawingId.indexOf("") > -1) {
							StringList drawingIdList = FrameworkUtil.split(drawingId, "");
							for (Iterator drwItr = drawingIdList.listIterator(); drwItr.hasNext();) {
								htmlBuffer.append(getDrawingIconContent((String) drwItr.next(), "iconSmallCATDrawing.gif", drawingToolTip));
							}
						} else {
							htmlBuffer.append(getDrawingIconContent(drawingId, "iconSmallCATDrawing.gif", drawingToolTip));
						}
					}
						

					if (has3dPart) {
						if (catPartId.indexOf("") > -1) {
							StringList cadPartIdList = FrameworkUtil.split(catPartId, "");
							for (Iterator cadPartItr = cadPartIdList.listIterator(); cadPartItr.hasNext();) {
								htmlBuffer.append(getDrawingIconContent((String) cadPartItr.next(), "iconSmallCATPart.gif", catPartToolTip));
							}
						} else {
							htmlBuffer.append(getDrawingIconContent(catPartId, "iconSmallCATPart.gif", catPartToolTip));
						}
					}
					// [E] modify by jtkim 2016-01-09

					columnCellContentList.add(htmlBuffer.toString());
				} else {
					columnCellContentList.add(htmlBuffer.toString());
				}
			}
		}
		catch(Exception e) 
		{
			e.printStackTrace();
			throw e;
		}
		
		return columnCellContentList;
	}

	protected StringList getBusSelectionList(Context context, MCADMxUtil util) throws Exception {
		REL_VERSION_OF				= MCADMxUtil.getActualNameForAEFData(context, "relationship_VersionOf");
		REL_ACTIVE_VERSION			= MCADMxUtil.getActualNameForAEFData(context, "relationship_ActiveVersion");
		REL_MARKUP					= MCADMxUtil.getActualNameForAEFData(context, "relationship_Markup");
		REL_PART_SPECIFICATION		= MCADMxUtil.getActualNameForAEFData(context, "relationship_PartSpecification");
		REL_DECBASELINE				= MCADMxUtil.getActualNameForAEFData(context, "relationship_DesignBaseline");
		SELECT_ON_MAJOR				= "from[" + REL_VERSION_OF + "].to.";
		SELECT_ON_ACTIVE_MINOR			= "from[" + REL_ACTIVE_VERSION + "].to.";
		SELECT_ON_SPC_PART			= "to[" + REL_PART_SPECIFICATION + "].from.";
		SELECT_ON_BASELINE			= "from[" + REL_DECBASELINE + "].to.";

		BASELINE_ID				= SELECT_ON_BASELINE + "id";

		IS_MARKUPS_EXIST			= "from[" + REL_MARKUP + "]";

		ATTR_SOURCE				= "attribute[" + MCADMxUtil.getActualNameForAEFData(context, "attribute_Source") + "]";
		ATTR_IS_REPLACEMENTDONE			= "attribute[" + MCADMxUtil.getActualNameForAEFData(context, "attribute_DSC-IsReplacementDone") + "]";
		ATTR_RENAMED_FROM			= "attribute[" + MCADMxUtil.getActualNameForAEFData(context, "attribute_RenamedFrom") + "]";

		StringList busSelectionList = new StringList();
			
		busSelectionList.addElement("id");
		busSelectionList.addElement("type");

		busSelectionList.addElement(ATTR_SOURCE); //To get Integrations name
		busSelectionList.addElement(SELECT_ON_MAJOR + "last." + SELECT_ON_ACTIVE_MINOR + "id");

		busSelectionList.addElement(ATTR_IS_REPLACEMENTDONE); //IsReplacementDone default.
		busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + ATTR_IS_REPLACEMENTDONE); //IsReplacementDone from major.
		busSelectionList.addElement(SELECT_ON_MAJOR + SELECT_ON_ACTIVE_MINOR + ATTR_IS_REPLACEMENTDONE); //IsReplacementDone from minor.

		busSelectionList.addElement(BASELINE_ID);//baseline on Major
		busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + BASELINE_ID); // Baseline On Active Minor

		busSelectionList.addElement(ATTR_RENAMED_FROM); //IsRenamed default.
		busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + ATTR_RENAMED_FROM); //IsRenamed from major.
		busSelectionList.addElement(SELECT_ON_MAJOR + "last." + SELECT_ON_ACTIVE_MINOR + ATTR_RENAMED_FROM); //IsRenamed from minor.

		busSelectionList.addElement(IS_MARKUPS_EXIST); //Markup List.
		busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + IS_MARKUPS_EXIST); //Markup List.

		busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + SELECT_ON_SPC_PART + "id"); //Part Id.
		busSelectionList.addElement(SELECT_ON_SPC_PART + "id"); //Part Id.
		IS_VERSION_OBJ = MCADMxUtil.getActualNameForAEFData(context,"attribute_IsVersionObject");
		SELECT_ISVERSIONOBJ = "attribute["+IS_VERSION_OBJ+"]";	
		busSelectionList.addElement(SELECT_ISVERSIONOBJ);

		// [B] modify by jtkim 2016-01-09
		// [NAV-001] Added image related to alerts column.
		busSelectionList.addElement("from[" + cdmConstantsUtil.RELATIONSHIP_ASSOCIATED_DRAWING + "].to.id");
		busSelectionList.addElement("to[" + cdmConstantsUtil.RELATIONSHIP_ASSOCIATED_DRAWING + "].from.id");
		// [E] modify by jtkim 2017-01-09
		return busSelectionList;
	}
		
	private String getFeatureIconContent(String href, String featureImage, String toolTop) {
		StringBuffer featureIconContent = new StringBuffer();
		
		featureIconContent.append("<a><img src=\"../iefdesigncenter/images/");
		featureIconContent.append(featureImage);
		featureIconContent.append("\" border=\"0\" title=\"");
		featureIconContent.append(toolTop);
		featureIconContent.append("\"/></a>");

		return featureIconContent.toString();
	}

	private String getDrawingIconContent(String objectId, String featureImage, String toolTop) {
		StringBuffer featureIconContent = new StringBuffer();
		
		featureIconContent.append("<a href=\"javascript:showNonModalDialog('../common/emxTree.jsp?mode=insert&amp;suiteKey=IEFDesignCenter&amp;targetLocation=popup&amp;objectId=");
		featureIconContent.append(objectId);
		featureIconContent.append("','875','550')\">");

		if (featureImage.indexOf("iconAlertPart") > -1) {
			featureIconContent.append("<img src=\"../iefdesigncenter/images/");
		} else {
			featureIconContent.append("<img src=\"../common/images/");
		}
		
		featureIconContent.append(featureImage);
		featureIconContent.append("\" border=\"0\" title=\"");
		featureIconContent.append(toolTop);
		featureIconContent.append("\"/></a>");

		return featureIconContent.toString();
	}
	
}
