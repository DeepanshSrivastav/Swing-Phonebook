import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.beans.MCADServerGeneralUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADGlobalConfigObject;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.Relationship;
import matrix.db.RelationshipType;
import matrix.util.StringList;

public class cdmOrCADUtil_mxJPO {
	public cdmOrCADUtil_mxJPO (Context context, String[] args) throws Exception {
	}
	
	public cdmOrCADUtil_mxJPO () throws Exception {
	}

	/**
	 * OrCAD_004
	 * OrCAD Check In 시 파일명 수정 Function.
	 * OrCAD Object Name으로 파일명 수정. [Object Name].DSN
	 */
	@SuppressWarnings({ "rawtypes" })
	public Map renameFile(Context context, String[] args) throws Exception {
		Map paramMap = JPO.unpackArgs(args);
		return renameFile(context, paramMap);
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map renameFile(Context context, Map inputMap) throws Exception {
		Map resultMap = new HashMap();
		resultMap.put("MESSAGE", "");

		try {
            String orCadOid = (String) inputMap.get("ORCAD_OID");
            String fileName = (String) inputMap.get("fileName");
			
            DomainObject orcadObj = DomainObject.newInstance(context, orCadOid);
            
            String renameFile = getOrCADFileName(context, orcadObj);
            
            if (fileName.equals(renameFile)) {
            	resultMap.put("renameFile", renameFile);
            	return resultMap;
            }
            
        	String isPropagaterename		= "!propagaterename";
        	StringBuffer mqlCommand			= new StringBuffer();
        	mqlCommand.append("mod bus ");
        	mqlCommand.append(orCadOid);
        	mqlCommand.append(" rename ");
        	mqlCommand.append("format \"");
        	mqlCommand.append("DSN");
        	mqlCommand.append("\" " + isPropagaterename);
        	mqlCommand.append(" file \"");
        	mqlCommand.append(fileName);
        	mqlCommand.append("\" \"");
        	mqlCommand.append(renameFile);
        	mqlCommand.append("\"");
        
        	MqlUtil.mqlCommand(context, mqlCommand.toString().trim());
        	
        	resultMap.put("renameFile", renameFile);
		} catch (Exception e) {
			e.printStackTrace();
            resultMap.put("MESSAGE", e.toString());        
		}
		return resultMap;
	}
	
	public String getOrCADFileName(Context context, String objectId) throws Exception {
		String resultValue = "";
		
		try {
			
			if (cdmStringUtil.isEmpty(objectId)) return "";
			
			DomainObject orCADObject = DomainObject.newInstance(context, objectId);
			resultValue = getOrCADFileName(context, orCADObject);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultValue;
	}
	
	@SuppressWarnings("rawtypes")
	public String getOrCADFileName(Context context, DomainObject orCADObject) throws Exception {
		String resultValue = "";
		
		try {
			
			if (orCADObject == null) return resultValue;
			
			StringList busSelect = new StringList();
			busSelect.add(cdmConstantsUtil.SELECT_NAME);
			Map infoMap = orCADObject.getInfo(context, busSelect);
			String name = (String) infoMap.get(cdmConstantsUtil.SELECT_NAME);
			
			if (cdmStringUtil.isEmpty(name)) return resultValue;
			
			resultValue = name + ".DSN";
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultValue;
	}
	
	/**
	 * OrCAD_004
	 * OrCAD 최초 Check In 시 Version Object 생성
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map createMinorObject(Context context, String[] args) throws Exception {
		
		Map resultMap = new HashMap();
		resultMap.put("MESSAGE", "");        
		try {
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String fileName = (String) paramMap.get("fileName");
			String objectId = (String) paramMap.get("ORCAD_OID");
			
			DomainObject orcadDom = DomainObject.newInstance(context, objectId);
			
			
			MCADGlobalConfigObject globalConfigObject = (MCADGlobalConfigObject) paramMap.get("GCO");
			MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) paramMap.get("languageStr"));
			IEFGlobalCache cache = new IEFGlobalCache();
			MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
			MCADServerGeneralUtil generalUtil = new MCADServerGeneralUtil(context, globalConfigObject, resourceBundle, cache);
			String minorPolicy = mxUtil.getRelatedPolicy(context, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION);
			String minorRevString = mxUtil.getFirstVersionStringForStream("A");
			String minObjId	= generalUtil.createAndConnectToMinorObject(context, minorRevString, true, orcadDom, globalConfigObject, true, false, minorPolicy);
			
			DomainObject minObject = DomainObject.newInstance(context, minObjId);
			minObject.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_TITLE, fileName);

			resultMap.put("newRevisionId", minObjId);
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("MESSAGE", e.toString());
		}
		return resultMap;
	}
	
	/**
	 * OrCAD_004 OrCAD Check In시 Version Object Revise Function.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map reviseMinorObject(Context context, String[] args) {
		Map resultMap = new HashMap();
		resultMap.put("message", "");
		boolean isTran = false;
		try {
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String targetObjectId = (String) paramMap.get("ORCAD_OID");

			DomainObject majorObject = DomainObject.newInstance(context, targetObjectId);

			String activeMinorObjectId = getActiveMinorObjectId(context, majorObject);
			DomainObject activeMinorObject = DomainObject.newInstance(context, activeMinorObjectId);

			StringList slBusSelect = new StringList();
			slBusSelect.add(cdmConstantsUtil.SELECT_REVISION);
			slBusSelect.add(cdmConstantsUtil.SELECT_VAULT);

			Map activeMinorInfoMap = activeMinorObject.getInfo(context, slBusSelect);

			String activeMinorRevision = (String) activeMinorInfoMap.get(cdmConstantsUtil.SELECT_REVISION);
			String activeMinorVault = (String) activeMinorInfoMap.get(cdmConstantsUtil.SELECT_VAULT);
			String nextRevision = getNextVersionString(activeMinorRevision);

			ContextUtil.startTransaction(context, true);
			isTran = true;

			BusinessObject newRevisionObject = activeMinorObject.revise(context, nextRevision, activeMinorVault);

			ContextUtil.commitTransaction(context);
			isTran = false;

			String newRevisionObjectId = newRevisionObject.getObjectId(context);
			resultMap.put("newRevisionId", newRevisionObjectId);

			// Move File To Minor Object
			moveFileToMinorObject(context, targetObjectId, activeMinorObjectId);

		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("MESSAGE", e.toString());
			if (isTran) ContextUtil.abortTransaction(context);
		}

		return resultMap;
	}

	/**
	 * Get Active Version Object
	 * @param context
	 * @param majorObject
	 * @return
	 * @throws Exception
	 */
	public String getActiveMinorObjectId(Context context, String[] args) throws Exception {
		Map paramMap = JPO.unpackArgs(args);
		String majorId = (String) paramMap.get("ORCAD_OID");
		return getActiveMinorObjectId(context, majorId);
	}
	
	public String getActiveMinorObjectId(Context context, String majorId) throws Exception {
		DomainObject majorObj = DomainObject.newInstance(context, majorId);
		return getActiveMinorObjectId(context, majorObj);
	}
	
    public String getActiveMinorObjectId(Context context, DomainObject majorObject) throws Exception {
    	String resultValue = "";
    	
    	try {
    		
    		resultValue = majorObject.getInfo(context, "from[" + cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION + "].to." + cdmConstantsUtil.SELECT_ID);
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	return resultValue;
    }
    
	/**
	 * Get Major Object Id
	 * @param context
	 * @param majorObject
	 * @return
	 * @throws Exception
	 */
    public String getMajorObjectId(Context context, String minorId) throws Exception {
    	DomainObject minorObj = DomainObject.newInstance(context, minorId);
    	return getMajorObjectId(context, minorObj);
    }
    
    public String getMajorObjectId(Context context, DomainObject minorObj) throws Exception {
    	String resultValue = "";
    	
    	try {
    		
    		resultValue = minorObj.getInfo(context, "from[" + cdmConstantsUtil.RELATIONSHIP_VERSION_OF + "].to." + cdmConstantsUtil.SELECT_ID);
    		
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	return resultValue;
    }
    
    /**
     * OrCAD_004
     * OrCAD Version Object Next Revision.
     */
	public String getNextVersionString(String paramString) {
		String str1 = "";

		int i = paramString.lastIndexOf(".");
		String str2;
		if (i == -1) {
			str2 = "Cannot create the next version string";
		} else {
			str2 = paramString.substring(0, i + 1);
			String str3 = paramString.substring(i + 1);
			int j = Integer.parseInt(str3);
			++j;
			String str4 = Integer.toString(j);
			str1 = new StringBuilder().append(str2).append(str4).toString();
		}
		return str1;
	}
	
	@SuppressWarnings("rawtypes")
	public StringList includePartList (Context context, String[] args) throws Exception {
    	StringList slExcludeList = new StringList();
    	
    	try {
    		MapList mapList = DomainObject.findObjects( context,
    													cdmConstantsUtil.TYPE_CDM_ELECTRONIC_PART + "," + cdmConstantsUtil.TYPE_CDM_ELECTRONIC_ASSEMBLY_PART,
              											"*",
              											"from[" + cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION + "]=='False'",
              											new StringList(cdmConstantsUtil.SELECT_ID));
    		
    		for (Iterator itr = mapList.listIterator(); itr.hasNext();) {
    			Map tempMap = (Map) itr.next();
    			
    			slExcludeList.add(tempMap.get(cdmConstantsUtil.SELECT_ID));
    		}
    	} catch (Exception e) {
    		e.printStackTrace();
    	}
    	
    	
    	return slExcludeList;
    }
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public HashMap getOrCADDesignTemplate(Context context, String[] args) throws Exception {
		HashMap resultMap = new HashMap();
		try {
			String sBusWhere = "";

			StringList actualValue  = new StringList();
	        StringList displayValue   = new StringList();
			StringList slBusSelect = new StringList();
			slBusSelect.add(cdmConstantsUtil.SELECT_ID);
			slBusSelect.add(cdmConstantsUtil.SELECT_NAME);
			

			MapList templateList = DomainObject.findObjects(	context,
																cdmConstantsUtil.TYPE_CDMORCADDESIGNTEMPLATE,       // type
																cdmConstantsUtil.QUERY_WILDCARD,            // name
																cdmConstantsUtil.QUERY_WILDCARD,            // rev
																cdmConstantsUtil.QUERY_WILDCARD,            // owner
																cdmConstantsUtil.QUERY_WILDCARD,           	// vault
																sBusWhere, 									// where
																false,                                   	// expand
																slBusSelect);                            	// selectbus
			
			Map tempMap = null;
			for (Iterator itr = templateList.listIterator(); itr.hasNext();) {
				tempMap = (Map) itr.next();
				actualValue.add(tempMap.get(cdmConstantsUtil.SELECT_ID));
				displayValue.add(tempMap.get(cdmConstantsUtil.SELECT_NAME));
			}
	          
			resultMap.put("field_choices", actualValue);
			resultMap.put("field_display_choices", displayValue);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultMap;
	}
	
	/**
	 * CAD SubComponent의 모든 연결을 Disconnect 한다.
	 * @param context
	 * @param id
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map disconnectOrCADBOM(Context context, String id) throws Exception {
		Map resultMap = new HashMap();
		resultMap.put("msg", "");
		try {
			
			if (cdmStringUtil.isNullString(id)) return resultMap;
			
			DomainObject parentObj = DomainObject.newInstance(context, id);
			
    		StringList selBusSelect = new StringList();
    		StringList selRelSelect = new StringList();
    		selRelSelect.add(cdmConstantsUtil.SELECT_RELATIONSHIP_ID);

    		String sBusWhere = "";
    		String sRelWhere = "";
    		MapList childList = parentObj.getRelatedObjects(	context,
																cdmConstantsUtil.RELATIONSHIP_CAD_SUBCOMPONENT,
																cdmConstantsUtil.TYPE_CDMORCADPRODUCT + "," + cdmConstantsUtil.TYPE_CDMORCADPART,
																selBusSelect,
																selRelSelect,
																false,
																true,
																(short) 0,
																sBusWhere,
																sRelWhere,
																0
															);
    		
    		
    		Map childMap = null;
    		String relId = null;
    		for (Iterator itr = childList.iterator(); itr.hasNext();) {
    			childMap = (Map) itr.next();
    			relId = (String) childMap.get(cdmConstantsUtil.SELECT_RELATIONSHIP_ID);
    			
    			Relationship cadRel = new Relationship(relId);
    			parentObj.disconnect(context, cadRel);
    		}
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultMap;
	}
	
	/**
	 * Major Version에 있는 File을 Minor Version으로 이동한다.
	 * @param context
	 * @param majorId
	 * @param minorId
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public Map moveFileToMinorObject(Context context, String majorId, String minorId) throws Exception {
		Map resultMap = new HashMap();

		try {
			
			String majorFormat = MqlUtil.mqlCommand(context, "print businessobject $1 select format dump $2", new String[] { majorId, "|" });
			StringList majorFormatList = FrameworkUtil.split(majorFormat, "|");

			String format = null;
			for (Iterator itr = majorFormatList.listIterator(); itr.hasNext();) {
				format = (String) itr.next();
				MqlUtil.mqlCommand(context, "modify businessobject $1 move format $2 from $3 format $4", new String[] { minorId, format, majorId, format });
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultMap;
	}
	
	/**
	 * Minor Version에 있는 File을 Major Version으로 이동한다.
	 * @param context
	 * @param majorId
	 * @param minorId
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public Map moveFileToMajorObject(Context context, String majorId, String minorId) throws Exception {
		Map resultMap = new HashMap();

		try {
			
			String minorFormat = MqlUtil.mqlCommand(context, "print businessobject $1 select format dump $2", new String[] { minorId, "|" });
			StringList minorFormatList = FrameworkUtil.split(minorFormat, "|");

			String format = null;
			for (Iterator itr = minorFormatList.listIterator(); itr.hasNext();) {
				format = (String) itr.next();
				MqlUtil.mqlCommand(context, "modify businessobject $1 move format $2 from $3 format $4", new String[] { majorId, format, minorId, format });
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultMap;
	}
	
	/**
	 * Minor Version을 Active / Latest Version으로 연결한다.
	 * @param context
	 * @param minorId
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map setActiveVersionObject(Context context, String minorId) throws Exception {
		Map resultMap = new HashMap();
		resultMap.put("msg", "");
		try {
			if (cdmStringUtil.isEmpty(minorId)) return resultMap;
			DomainObject minorObj = DomainObject.newInstance(context, minorId);
			resultMap = setActiveVersionObject(context, minorObj);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultMap;
	}
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map setActiveVersionObject(Context context, DomainObject minorObj) throws Exception {
		Map resultMap = new HashMap();
		resultMap.put("msg", "");
		try {
			
			String majorId = getMajorObjectId(context, minorObj);
			DomainObject majorObj = DomainObject.newInstance(context, majorId);
			
			DomainRelationship.connect(context, majorObj, new RelationshipType(cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION), minorObj);
			DomainRelationship.connect(context, majorObj, new RelationshipType(cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION), minorObj);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultMap;
	}
	
	/**
	 * 해당 Object의 특정 Format의 특정 File 을 지운다.
	 * @param context
	 * @param objectId
	 * @param format
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	public Map deleteFile(Context context, String objectId, String format, String fileName) throws Exception {
		Map resultMap = new HashMap();
		resultMap.put("msg", "");
		try {
			
			String str = "delete bus $1 format $2 file $3";
			MqlUtil.mqlCommand(context, str, new String[] { objectId, format, fileName });
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultMap;
	}
	
	/**
	 * 해당 Object의 모든 File을 지운다.
	 * @param context
	 * @param objectId
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map deleteFile(Context context, String objectId) throws Exception {
		Map resultMap = new HashMap();
		resultMap.put("msg", "");
		try {
			
			String objectFormat = MqlUtil.mqlCommand(context, "print businessobject $1 select format dump $2", new String[] { objectId, "|" });
			StringList objectFormatList = FrameworkUtil.split(objectFormat, "|");

			String format = null;
			for (Iterator itr = objectFormatList.listIterator(); itr.hasNext();) {
				format = (String) itr.next();
				deleteFile(context, objectId, format, "all");
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultMap;
	}
	
	/**
	 * Major Object와 Version Of Relationship으로 연결된 Minor Object List Return
	 * @param context
	 * @param majorId
	 * @return
	 * @throws Exception
	 */
	public MapList getMinorObjectList(Context context, String majorId) throws Exception {
		return getMinorObjectList(context, DomainObject.newInstance(context, majorId));
	}
	
	public MapList getMinorObjectList(Context context, DomainObject majorObject) throws Exception {
		MapList resultList = new MapList();

		try {

			StringList selBusSelect = new StringList();
			selBusSelect.add(cdmConstantsUtil.SELECT_ID);

			StringList selRelSelect = new StringList();

			String sBusWhere = "";
			String sRelWhere = "";

			MapList objList = majorObject.getRelatedObjects(	context,
																cdmConstantsUtil.RELATIONSHIP_VERSION_OF,
																cdmConstantsUtil.QUERY_WILDCARD,
																selBusSelect,
																selRelSelect,
																true,
																false,
																(short) 0,
																sBusWhere,
																sRelWhere,
																0
															);

			Map tempMap = null;
			for (Iterator itr = objList.listIterator(); itr.hasNext();) {
				tempMap = (Map) itr.next();

				if (resultList.contains(tempMap)) continue;

				resultList.add(tempMap);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

    public Map connectPreVersionBOM(Context context, String majorId, String preVersionId) throws Exception {
    	return connectPreVersionBOM(context, DomainObject.newInstance(context, majorId), DomainObject.newInstance(context, preVersionId));
    }
    
    @SuppressWarnings("rawtypes")
	public Map connectPreVersionBOM(Context context, DomainObject majorObj, DomainObject preVersionObj) throws Exception {
    	Map resultMap = new HashMap();
    	
    	try {
    		MapList childList = getCADSubComponentList(context, preVersionObj);
    		
    		String childId = null;
    		String reference = null;
    		DomainRelationship connecRel = null;
    		
    		for (Iterator itr = childList.listIterator(); itr.hasNext();) {
    			Map childMap = (Map) itr.next();
    			childId = (String) childMap.get(cdmConstantsUtil.SELECT_ID);
    			reference = (String) childMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_REFERENCE_DESIGNATOR);
    			
    			DomainObject childObj = DomainObject.newInstance(context, childId);
        		connecRel = DomainRelationship.connect(context, majorObj, new RelationshipType(cdmConstantsUtil.RELATIONSHIP_CAD_SUBCOMPONENT), childObj);

        		Map setAttrMap = new HashMap();
        		setAttrMap.put(cdmConstantsUtil.ATTRIBUTE_REFERENCE_DESIGNATOR, reference);
        		setAttrMap.put(cdmConstantsUtil.ATTRIBUTE_QUANTITY, "1");
        		
        		connecRel.setAttributeValues(context, setAttrMap);
    		}
    		
		} catch (Exception e) {
			e.printStackTrace();
		}
    	return resultMap;
    }
    
    public MapList getCADSubComponentList(Context context, DomainObject parentObj) throws Exception {
    	MapList resultList = new MapList();
    	
    	StringList selBusSelect = new StringList();
    	selBusSelect.add(cdmConstantsUtil.SELECT_ID);
    	
    	StringList selRelSelect = new StringList();
    	selRelSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_REFERENCE_DESIGNATOR);
    	
    	String sBusWhere = "";
    	String sRelWhere = "";
    	
    	resultList = parentObj.getRelatedObjects(	context,
													cdmConstantsUtil.RELATIONSHIP_CAD_SUBCOMPONENT,
													cdmConstantsUtil.TYPE_CDMORCADPART,
													selBusSelect,
													selRelSelect,
													false,
													true,
													(short) 0,
													sBusWhere,
													sRelWhere,
													0
												);
		
		return resultList;
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map getOrCADMaster(Context context, String firstObjectId) throws Exception {
		Map resultMap = new HashMap();
		String masterId = "";
		try {
			DomainObject orcadObject = DomainObject.newInstance(context, firstObjectId);
			String firstPartName = orcadObject.getInfo(context, cdmConstantsUtil.SELECT_NAME);
			firstPartName = firstPartName + "-Master";

			
			String queryResult = MqlUtil.mqlCommand(context, "temp query bus " + cdmConstantsUtil.TYPE_CDMORCADMASTER + " " + firstPartName + " * where \"revision==last&&policy=='Design TEAM Definition'\" select id dump");
			if (cdmStringUtil.isNotNullString(queryResult)) {
				StringList queryResultList = FrameworkUtil.split(queryResult, ",");
				masterId = (String) queryResultList.get(3);
				
			} else {
				// Create Object
				DomainObject orcadMasterDom = DomainObject.newInstance(context);
				orcadMasterDom.createObject(	context,
												cdmConstantsUtil.TYPE_CDMORCADMASTER,
												firstPartName,
												"A",
												cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION,
												cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
	
				// Set Attribute
				Map updateMap = new HashMap();
				updateMap.put("Source", "MxCATIAV5");
				updateMap.put(cdmConstantsUtil.ATTRIBUTE_TITLE, firstPartName);
	
				cdmUtil_mxJPO.setAttributeMap(context, updateMap, cdmConstantsUtil.TYPE_CDMORCADMASTER, orcadMasterDom);
				masterId = orcadMasterDom.getObjectId();
			}
			resultMap.put("MasterId", masterId);
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("MESSAGE", e.toString());
		}
		return resultMap;
	}
}
