/*
**  DSCDerivedOutputsTableData
**
**  Copyright Dassault Systemes, 1992-2007.
**  All Rights Reserved.
**  This program contains proprietary and trade secret information of Dassault Systemes and its 
**  subsidiaries, Copyright notice is precautionary only
**  and does not evidence any actual or intended publication of such program
**	
**  This  is a JPO which act as a data source for rendering data in to a custom table .
**	Using this JPO program  developer can  create their own column definitions and can return
**	tabledata in a  CustomMapList  which stores each row of table as Map objects.
*/
import java.util.HashMap;
import java.util.Vector;

import com.mando.util.cdmConstantsUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADUrlUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;

import matrix.db.Context;
import matrix.db.JPO;

 
public class DSCDerivedOutputsTableData_mxJPO extends DSCDerivedOutputsTableDataBase_mxJPO
{	

    /**
	   * Constructor.
	   *
	   * @param context the eMatrix <code>Context</code> object
	   * @param args holds no arguments
	   * @throws Exception if the operation fails
	   * @since Sourcing V6R2008-2
	   */
	public DSCDerivedOutputsTableData_mxJPO (Context context, String[] args) throws Exception
	{
	  super(context, args);
	}

	/**
	 * OOTB Override
	 */
//	public Object getActionLinks(Context context, String[] args) throws Exception {
//		Vector columnCellContentList	= new Vector();
//		StringBuffer htmlBuffer			= new StringBuffer();
//		HashMap paramMap				= (HashMap)JPO.unpackArgs(args);  
//
//		paramMap.put("displayCheckout", "true");
//		paramMap.put("displayViewer", "true");
//
//		MapList relBusObjPageList	= (MapList)paramMap.get("objectList");
//		integrationNameGCOTable		= (HashMap)paramMap.get("GCOTable");
//
//		serverResourceBundle		= new MCADServerResourceBundle(localeLanguage);
//		cache						= new IEFGlobalCache();
//		util						= new MCADMxUtil(context, serverResourceBundle, cache);
//
//		for (int i = 0; i < relBusObjPageList.size(); i++) {
//			String fileName = null;
//			
//			try {
//				HashMap objDetails		= (HashMap)relBusObjPageList.get(i);
//				String objectId			= (String)objDetails.get("id");
//
//				// String integrationName	= util.getIntegrationName(objectId);
//				htmlBuffer				= new StringBuffer();
//				fileName					= (String) objDetails.get("FileName");
//
//				String format			= (String)objDetails.get("format");
//				String hexfileName		= MCADUrlUtil.hexEncode(fileName);
//				String checkoutHref		= "../iefdesigncenter/DSCComponentCheckoutWrapper.jsp?"+ "objectId=" + objectId + "&amp;action=download" + "&amp;format=" + format + "&amp;fileName=" + hexfileName + "&amp;refresh=false&amp;";
//
//				String checkoutToolTip	= serverResourceBundle.getString("mcadIntegration.Server.AltText.Download");
//				checkoutHref				= "javascript:openWindow('"+ checkoutHref + "')";
//
//				htmlBuffer.append(getFeatureIconContent(checkoutHref, "../../common/images/iconActionDownload.gif", checkoutToolTip));
//
//				// [B] modify by jtkim 2017-01-25
//				// [AUTOVIEW-001] Fixed to show only the key type.
//				DomainObject busObj = DomainObject.newInstance(context, objectId);
//				String busTypeName = busObj.getInfo(context, cdmConstantsUtil.SELECT_TYPE);
//				if (cdmConstantsUtil.TYPE_CDMNXDRAWING.equals(busTypeName)) htmlBuffer.append(getViewerURL(context, objectId, format, fileName));
//				// [E] modify by jtkim 2017-01-25
//			} catch(Exception e) {
//			}
//			columnCellContentList.add(htmlBuffer.toString());
//		}
//		return columnCellContentList;
//	}
}
