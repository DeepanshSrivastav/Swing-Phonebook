/*
 ** ${CLASS:MarketingFeature}
 **
 ** Copyright (c) 1993-2015 Dassault Systemes. All Rights Reserved.
 ** This program contains proprietary and trade secret information of
 ** Dassault Systemes.
 ** Copyright notice is precautionary only and does not evidence any actual
 ** or intended publication of such program
 */

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.TreeMap;

import org.apache.commons.lang3.StringUtils;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.Policy;
import matrix.db.StateRequirement;
import matrix.db.StateRequirementList;
import matrix.util.StringList;

/**
 * The <code>emxPart</code> class contains code for the "Part" business type.
 *
 * @version EC 9.5.JCI.0 - Copyright (c) 2002, MatrixOne, Inc.
 */
  public class emxPart_mxJPO extends emxPartBase_mxJPO
  {
      /**
       * Constructor.
       *
       * @param context the eMatrix <code>Context</code> object.
       * @param args holds no arguments.
       * @throws Exception if the operation fails.
       * @since EC 9.5.JCI.0.
       */

	public emxPart_mxJPO(Context context, String[] args) throws Exception {
		super(context, args);
	}

	
	/**
	 * It does not allow that Proto Part have Production Part as parent
	 * @param context
	 * @param args
	 * @return
	 */
	public int checkIfChildIsProto(Context context, String[] args) throws Exception {
		
		/**
		 *   'eService Program Argument 1' '${FROMOBJECTID}'
        'eService Program Argument 2' '${TOOBJECTID}'
		 */
		try {
			
			String strFromObjectId = args[0]; // parent Part
			String strToObjectId = args[1];   // child Part
			
			DomainObject doParentPart = new DomainObject(strFromObjectId);
			String strParentPhase 		= doParentPart.getInfo(context, "attribute[cdmPartPhase]");
			String strParentType 		= doParentPart.getInfo(context, DomainObject.SELECT_TYPE);
			String strParentCurrent 	= doParentPart.getInfo(context, DomainObject.SELECT_CURRENT);
			String strParentEoObjectId 	= doParentPart.getInfo(context, "to[Affected Item].from.id");
			
			
			DomainObject doChildPart = new DomainObject(strToObjectId);
			String strChildPhase 		= doChildPart.getInfo(context, "attribute[cdmPartPhase]");
			String strChildType 		= doChildPart.getInfo(context, DomainObject.SELECT_TYPE);
			String strChildCurrent 		= doChildPart.getInfo(context, DomainObject.SELECT_CURRENT);
			String strPreviousId 		= StringUtils.trimToEmpty(doChildPart.getInfo(context, "previous.id"));
			String strChildEoObjectId 	= doChildPart.getInfo(context, "to[Affected Item].from.id");
			

			if(cdmConstantsUtil.TYPE_CDMMECHANICALPART.equals(strParentType)) {
			
				if ("Production".equals(strParentPhase)) {
					
					if("Proto".equals(strChildPhase)) {
						
						String strErrorMessage = EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(),"emxEngineeringCentral.Alert.ProtoChildPart");
						throw new FrameworkException(strErrorMessage);
						
					}
					
				}
	
				
				if ("Proto".equals(strParentPhase)) {
					
					if(! "Release".equals(strChildCurrent)){

						if("Production".equals(strChildPhase) && "".equals(strPreviousId)) {
							
							String strErrorMessage = "New Production Part cannot be add as child below Proto Part.";
							throw new FrameworkException(strErrorMessage);
							
						}
						
					}
					
				}
			
			}
			
			
			if(cdmConstantsUtil.TYPE_CDMPHANTOMPART.equals(strParentType)) {
				
				DomainObject parentEoObj = new DomainObject(strParentEoObjectId);
				String strEOType = (String) parentEoObj.getInfo(context, "type");
				
				if("cdmPEO".equals(strEOType)) {
					
					if( "Production".equals(strChildPhase) ) {
						String strErrorMessage = "This part does not correspond to the eotype of the PhantomPart";
						throw new FrameworkException(strErrorMessage);
					}
					
				} else {
					
					if( "Proto".equals(strChildPhase) ) {
						String strErrorMessage = "This part does not correspond to the eotype of the PhantomPart";
						throw new FrameworkException(strErrorMessage);
					}
					
				}
				
			}
			
			
			// Phantom Part cannot be child part.
			if(cdmConstantsUtil.TYPE_CDMPHANTOMPART.equals(strChildType)) {
				String strErrorMessage = EnoviaResourceBundle.getProperty(context,"emxEngineeringCentralStringResource",context.getLocale(),"emxEngineeringCentral.Alert.PhantomNoChild");
				throw new FrameworkException(strErrorMessage);
			}
			
			
			// Parent part must not have same part as child.
			StringList slChildPart = doParentPart.getInfoList(context, "from[EBOM].to.id");
			
			if(slChildPart.contains(strToObjectId)) {
				String strErrorMessage = EnoviaResourceBundle.getProperty(context,"emxEngineeringCentralStringResource",context.getLocale(),"emxEngineeringCentral.Alert.notallowsamechild");
				throw new FrameworkException(strErrorMessage);
			}
			
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}

		return 0;

	}
	
	/**
	 * reset drawing no in child part when deleting EBOM connection.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public int removeDrawingNo(Context context, String[] args) throws Exception {
		
		/**
		 *   'eService Program Argument 1' '${FROMOBJECTID}'
         *	 'eService Program Argument 2' '${TOOBJECTID}'
		 */
		try {
			
			String strFromObjectId = args[0]; // parent Part
			String strToObjectId = args[1];   // child Part
			
			DomainObject doParentPart = new DomainObject(strFromObjectId);
			String strParentType = doParentPart.getInfo(context, DomainObject.SELECT_TYPE);
			
			// Phantom Part cannot be child part.
			if(cdmConstantsUtil.TYPE_CDMPHANTOMPART.equals(strParentType)) {
				
				DomainObject doChildPart = new DomainObject(strToObjectId);
				doChildPart.setAttributeValue(context, "cdmPartDrawingNo", "");
			}

			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		
		return 0;
		
	}
	
	
	
	 /**
	   * Checks that the Specification which is going to be connected to Part is having states
	   * "Review", "Approved" and "Released". If any spec object not having these states, it cannot
	   * be added as "Part Specification". Also, "Review" should not be the first state.
	   *
	   * @param context the eMatrix <code>Context</code> object.
	   *
	   * @return int 0-success 1-failure.
	   * @throws Exception if the operation fails.
	   * @since EC 10-6
	   */
	    public int ensureSpecificationStates(Context context, String[] args) throws Exception
	    {
	    	
	    	//do not delete.
	    	//overrides original check method.
	    	return 0;
	    }

	    

	/**
	 * add by jtkim 2017-01-26
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void setUpdatePhantomChildDrawingNo(Context context, String[] args) throws Exception {
		try {
			String fromObjectId = args[0];
			String toObjectId = args[1];

			if (cdmStringUtil.isNotEmpty(fromObjectId) && cdmStringUtil.isNotEmpty(toObjectId)) {
				DomainObject fromObj = DomainObject.newInstance(context, fromObjectId);
				DomainObject toObj = DomainObject.newInstance(context, toObjectId);

				StringList fromBusSelect = new StringList();
				fromBusSelect.add(cdmConstantsUtil.SELECT_TYPE);
				fromBusSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_DRAWING_NO);

				Map fromObjInfoMap = fromObj.getInfo(context, fromBusSelect);

				String fromType = (String) fromObjInfoMap.get(cdmConstantsUtil.SELECT_TYPE);
				if (cdmConstantsUtil.TYPE_CDMPHANTOMPART.equals(fromType)) {
					String drawingNo = (String) fromObjInfoMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_DRAWING_NO);
					toObj.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_DRAWING_NO, drawingNo);
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	public HashMap<String, String> getPartStateRangeValues(Context context, String[] args) throws Exception {
		HashMap<String, String> result = new HashMap<String, String>();
        String DisplayName = "";
        String langStr = context.getSession().getLanguage();
        Policy policy = new Policy(cdmConstantsUtil.POLICY_CDM_PART_POLICY);
        StateRequirementList stateRequirementList = policy.getStateRequirements(context);
        
        for (int i = 0; i < stateRequirementList.size(); i++) {
            
        	String stateName = (String) ((StateRequirement) stateRequirementList.get(i)).getName();
        	if(! result.containsKey(stateName)){
        		
            	if("Preliminary".equals(stateName)){
                	DisplayName = "Preliminary";
                }else if("Review".equals(stateName)){
                	DisplayName = "Review";
                }else if("Release".equals(stateName)){
                	DisplayName = "Release";
                }else if("Obsolete".equals(stateName)){
                	DisplayName = "Obsolete";
                }
            	
            }
            
            result.put(stateName, DisplayName);
            
        }
        
        TreeMap<String,String> tm = new TreeMap<String,String>(result);
        
        Iterator<String> iteratorKey = tm.keySet( ).iterator( );   
        //Iterator<String> iteratorKey = tm.descendingKeySet().iterator(); 
        while(iteratorKey.hasNext()){
            String key = iteratorKey.next();
            
        }
        
        return result;
    }
	
	
	public String getSearchProject(Context context, String[] args) throws Exception {
		
    	String objectId = args[0];
    	String selects  = args[1];
    	
    	System.out.println("!!!!!objectId     "+objectId);
    	System.out.println("!!!!!selects      "+selects);
    	
    	String strProject = "";
    	DomainObject  dObj = newInstance(context, objectId);
    	
    	if(! DomainConstants.EMPTY_STRING.equals(objectId)){
    		strProject = StringUtils.trimToEmpty( MqlUtil.mqlCommand(context, "print bus $1 select $2 dump", objectId, "to[cdmPartRelationProject].from.attribute[cdmProjectCode]") );
        }
    	System.out.println("!!!!!strProject      "+strProject);
    	
    	String selectedValue= dObj.getInfo(context, selects);
    	DomainObject doMemberFullName = new DomainObject(new BusinessObject(DomainObject.TYPE_PERSON, selectedValue, "-", "eService Production" ));
    	//strProject = doMemberFullName.getInfo(context, "attribute[First Name]");
    	
    	return strProject;
    }
	
	
	
	
	
}
