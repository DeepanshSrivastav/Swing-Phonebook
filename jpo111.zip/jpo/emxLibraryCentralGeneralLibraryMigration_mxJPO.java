import matrix.db.Context;


public class emxLibraryCentralGeneralLibraryMigration_mxJPO extends emxLibraryCentralGeneralLibraryMigrationBase_mxJPO
{
	public emxLibraryCentralGeneralLibraryMigration_mxJPO(Context context, String[] args) throws Exception
	{
		super(context, args);
	}
}
