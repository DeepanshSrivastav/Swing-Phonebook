import matrix.db.Context;

// ${CLASSNAME}.java
//
// Created on Aug 22, 2010
//
// Copyright (c) 2005 MatrixOne Inc.
// All Rights Reserved
// This program contains proprietary and trade secret information of
// MatrixOne, Inc.  Copyright notice is precautionary only and does
// not evidence any actual or intended publication of such program.
//

/**
 * @author SG2
 *
 * The <code>${CLASSNAME}</code> class/interface contains ...
 *
 * @version AEF 11.0.0.0 - Copyright (c) 2005, MatrixOne, Inc.
 */
public class emxDepartment_mxJPO extends emxDepartmentBase_mxJPO {

    public emxDepartment_mxJPO(Context context, String[] args) throws Exception {
        super(context, args);
    }

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

}
