/*
**  DSC_GetBatchProcessorDetails
**
**  Copyright Dassault Systemes, 1992-2007.
**  All Rights Reserved.
**  This program contains proprietary and trade secret information of Dassault Systemes and its 
**  subsidiaries, Copyright notice is precautionary only
**  and does not evidence any actual or intended publication of such program
**
**  Program to store the user and queue information for batch processor.
*/
 
public class DSC_GetBatchProcessorDetails_mxJPO extends DSC_GetBatchProcessorDetailsBase_mxJPO
{
	/**
	   * Constructor.
	   *
	   * @since Sourcing V6R2008-2
	   */
	public DSC_GetBatchProcessorDetails_mxJPO ()
	{
	  super();
	}
	
}
