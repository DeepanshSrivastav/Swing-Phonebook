/*
**  DSCShowActionsLink
**
**  Copyright Dassault Systemes, 1992-2007.
**  All Rights Reserved.
**  This program contains proprietary and trade secret information of Dassault Systemes and its 
**  subsidiaries, Copyright notice is precautionary only
**  and does not evidence any actual or intended publication of such program
**
**  Program to display Checkout Icon
*/
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.Vector;

import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.MCADServerSettings;
import com.matrixone.MCADIntegration.server.beans.IEFIntegAccessUtil;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADAppletServletProtocol;
import com.matrixone.MCADIntegration.utils.MCADGlobalConfigObject;
import com.matrixone.MCADIntegration.utils.UUID;
import com.matrixone.apps.domain.util.MapList;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessObjectWithSelectList;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

 
public class DSCShowActionsLink_mxJPO extends DSCShowActionsLinkBase_mxJPO
{

    /**
	   * Constructor.
	   *
	   * @param context the eMatrix <code>Context</code> object
	   * @param args holds no arguments
	   * @throws Exception if the operation fails
	   * @since Sourcing V6R2008-2
	   */
	public DSCShowActionsLink_mxJPO (Context context, String[] args) throws Exception
	{
	  super(context, args);
	}

	protected Object getHtmlStringForTable(Context context, MapList relBusObjPageList, String portalName) throws Exception
	{		
		Vector columnCellContentList	= new Vector();
		String sUseMinor				= "";
		HashMap formatViewerMap			= new HashMap();

		serverResourceBundle			= new MCADServerResourceBundle(localeLanguage);
		cache							= new IEFGlobalCache();
		util							= new IEFIntegAccessUtil(context, serverResourceBundle, cache);

		String[] objIds					= new String[relBusObjPageList.size()];

		for(int i =0; i<relBusObjPageList.size(); i++)
		{
			Map objDetails	= (Map)relBusObjPageList.get(i);
			objIds[i]		= (String)objDetails.get("id");			

			// Designer Central 10.6.0.1			
			sUseMinor = (String)objDetails.get("UseMinor");
		}

		try
		{
			Vector assignedIntegrations = util.getAssignedIntegrations(context);

			String openToolTip			= serverResourceBundle.getString("mcadIntegration.Server.AltText.Open");
			String downloadToolTip		= serverResourceBundle.getString("mcadIntegration.Server.AltText.Download");
			String lockUnlockToolTip	= serverResourceBundle.getString("mcadIntegration.Server.AltText.LockUnlock");
			String  subscribeToolTip	= serverResourceBundle.getString("mcadIntegration.Server.AltText.Subscribe");

			REL_VERSION_OF				= MCADMxUtil.getActualNameForAEFData(context, "relationship_VersionOf");
			REL_ACTIVE_VERSION			= MCADMxUtil.getActualNameForAEFData(context, "relationship_ActiveVersion");
			REL_DERIVED_OUTPUT			= MCADMxUtil.getActualNameForAEFData(context, "relationship_DerivedOutput");
			REL_VIEWABLE				= MCADMxUtil.getActualNameForAEFData(context, "relationship_Viewable");
			REL_AFFECTED_ITEM			= MCADMxUtil.getActualNameForAEFData(context, "relationship_AffectedItem");
			REL_CHANGE_AFFECTED_ITEM	= MCADMxUtil.getActualNameForAEFData(context, "relationship_ChangeAffectedItem");

			String ecoType				= MCADMxUtil.getActualNameForAEFData(context, "type_ECO");
			String sTypeCA = MCADMxUtil.getActualNameForAEFData(context,"type_ChangeAction");

			SELECT_ON_MAJOR				= "from[" + REL_VERSION_OF + "].to.";
			SELECT_ON_ACTIVE_MINOR		= "from[" + REL_ACTIVE_VERSION + "].to.";		
			SELECT_ON_DERIVED_OUTPUT	= "from[" + REL_DERIVED_OUTPUT + "].to.";
			SELECT_ON_VIEWABLE			= "from[" + REL_VIEWABLE + "].to.";
			SELECT_ON_ECO				= "to[" + REL_AFFECTED_ITEM + "].from[" + ecoType + "].";
			SELECT_ON_CA				= "to[" + REL_CHANGE_AFFECTED_ITEM + "].from[" + sTypeCA + "].";

			REL_VAULTED_DOCUMENTS		= MCADMxUtil.getActualNameForAEFData(context, "relationship_VaultedDocuments");
			TYPE_WORKSPACE_VAULT 		= MCADMxUtil.getActualNameForAEFData(context, "type_ProjectVault");
			GET_VAULT_IDS 				= "to[" + this.REL_VAULTED_DOCUMENTS + "].from[" + this.TYPE_WORKSPACE_VAULT + "].id";

			ATTR_SOURCE					= "attribute[" + MCADMxUtil.getActualNameForAEFData(context, "attribute_Source") + "]";
			ATTR_TITLE					= "attribute[" + MCADMxUtil.getActualNameForAEFData(context, "attribute_Title") + "]";
			ATTR_CAD_TYPE				= "attribute[" + MCADMxUtil.getActualNameForAEFData(context, "attribute_CADType") + "]";

			StringList busSelectionList = new StringList();

			busSelectionList.addElement("id");
			busSelectionList.addElement("logicalid");
			busSelectionList.addElement("physicalid");
			busSelectionList.addElement("name");
			busSelectionList.addElement("revision");
			busSelectionList.addElement(ATTR_TITLE);
			busSelectionList.addElement("type");
			busSelectionList.addElement("format.file.name");
			busSelectionList.addElement("format.file.format");

			busSelectionList.addElement(ATTR_SOURCE); //To get Integrations name.
			busSelectionList.addElement(ATTR_CAD_TYPE); 
			busSelectionList.addElement(SELECT_ON_MAJOR + "id"); //Major object id.
			busSelectionList.addElement(SELECT_ON_MAJOR + "logicalid"); //Major logical id.
			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + "id"); //Minor ID
			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + "type");

			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + "format.file.name");
			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + "format.file.format");

			busSelectionList.addElement(SELECT_ON_MAJOR + "format.file.name");
			busSelectionList.addElement(SELECT_ON_MAJOR + "format.file.format");

			busSelectionList.addElement("locked"); //To get Integrations name.
			busSelectionList.addElement(SELECT_ON_MAJOR + "locked"); //from Minor.

			busSelectionList.addElement(SELECT_ON_ECO + "id");// For ECO Icon
			busSelectionList.addElement(SELECT_ON_CA + "id");// For ECO Icon
			
			busSelectionList.addElement(SELECT_ON_DERIVED_OUTPUT + "id"); //DerivedOutput Id.
			busSelectionList.addElement(SELECT_ON_DERIVED_OUTPUT + "type");//DerivedOutput obj type.
			busSelectionList.addElement(SELECT_ON_DERIVED_OUTPUT + "format.file.name");
			busSelectionList.addElement(SELECT_ON_DERIVED_OUTPUT + "format.file.format");
			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + SELECT_ON_DERIVED_OUTPUT + "id"); //DerivedOutput Id.
			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + SELECT_ON_DERIVED_OUTPUT + "format.file.name");
			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + SELECT_ON_DERIVED_OUTPUT + "format.file.format");

			busSelectionList.addElement(SELECT_ON_VIEWABLE + "id"); //DerivedOutput Id.
			busSelectionList.addElement(SELECT_ON_VIEWABLE + "type"); //DerivedOutput obj type.
			busSelectionList.addElement(SELECT_ON_VIEWABLE + "format.file.name");
			busSelectionList.addElement(SELECT_ON_VIEWABLE + "format.file.format");
			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + SELECT_ON_VIEWABLE + "id"); //DerivedOutput Id.
			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + SELECT_ON_VIEWABLE  + "type"); //DerivedOutput obj type.
			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + SELECT_ON_VIEWABLE + "format.file.name");
			busSelectionList.addElement(SELECT_ON_ACTIVE_MINOR + SELECT_ON_VIEWABLE + "format.file.format");

			busSelectionList.addElement(GET_VAULT_IDS);
			busSelectionList.addElement(SELECT_ON_MAJOR + GET_VAULT_IDS);

			IS_VERSION_OBJ = MCADMxUtil.getActualNameForAEFData(context,"attribute_IsVersionObject");
			SELECT_ISVERSIONOBJ = "attribute["+IS_VERSION_OBJ+"]";	
			busSelectionList.addElement(SELECT_ISVERSIONOBJ);

			BusinessObjectWithSelectList buslWithSelectionList = BusinessObject.getSelectBusinessObjectData(context, objIds, busSelectionList);			

			for(int i = 0; i < buslWithSelectionList.size(); i++)
			{
				BusinessObjectWithSelect busObjectWithSelect = (BusinessObjectWithSelect)buslWithSelectionList.elementAt(i);

				StringBuffer htmlBuffer = new StringBuffer();
				String integrationName	= null;

				String objectId				= busObjectWithSelect.getSelectData("id");
				String integrationSource	= busObjectWithSelect.getSelectData(ATTR_SOURCE);

				if(integrationSource != null)
				{
					StringTokenizer integrationSourceTokens = new StringTokenizer(integrationSource, "|");

					if(integrationSourceTokens.hasMoreTokens())
						integrationName  = integrationSourceTokens.nextToken();
				}

				if(integrationName != null && integrationNameGCOTable.containsKey(integrationName) && assignedIntegrations.contains(integrationName))
				{
					MCADGlobalConfigObject gco	= (MCADGlobalConfigObject)integrationNameGCOTable.get(integrationName);

					if(null == cache)
					{
						cache	= new IEFGlobalCache();
					}

					String majorObjectId		= "";
					String ecoObjId				= "";
					String caObjId				= ""; 
					String canShowLockUnlock	= "";

					String objID				= objectId;
					
					majorObjectId				= objectId;
					String sIsVersion 			= busObjectWithSelect.getSelectData(SELECT_ISVERSIONOBJ);
					boolean isVersion 			= Boolean.valueOf(sIsVersion).booleanValue();
					//boolean isMajor				= util.isMajorObject(context ,objID); //[NDM] : H68
					StringList ecoList = busObjectWithSelect.getSelectDataList(SELECT_ON_ECO + "id");
					if(ecoList != null){
						ecoObjId				= (String) ecoList.lastElement();
					} 
					StringList caList = busObjectWithSelect.getSelectDataList(SELECT_ON_CA + "id");
					if(caList != null){
						caObjId				= (String) caList.lastElement();
					}

					//[NDM]
					if(!isVersion)
					{
						majorObjectId		= objectId;
						canShowLockUnlock	= busObjectWithSelect.getSelectData("locked");

						// Designer Central 10.6.0.1
						if(sUseMinor != null && sUseMinor.equals("true"))
							objectId = busObjectWithSelect.getSelectData(SELECT_ON_ACTIVE_MINOR + "id");
						// Designer Central 10.6.0.1
					}
					else
					{
						majorObjectId		= busObjectWithSelect.getSelectData(SELECT_ON_MAJOR + "id");
						//ecoObjId			= busObjectWithSelect.getSelectData(SELECT_ON_SPC_PART + "id");
						canShowLockUnlock	= busObjectWithSelect.getSelectData(SELECT_ON_MAJOR + "locked");
					}

					// add subscription icon
					// [B] modify by jtkim 2017-02-06
					// [ACTION-002] Remove Subscription
//					htmlBuffer.append(addSubscriptionLink(context, majorObjectId, integrationName, subscribeToolTip));
					// [E] modify by jtkim 2017-02-06

					// [NDM] QWJ
					htmlBuffer.append(addDownloadStructureLink(context, objectId, isVersion));

					String jpoName	= gco.getFeatureJPO("OpenFromWeb");

					if(null != jpoName && !"".equals(jpoName))	
					{
						//add open from web link
						htmlBuffer.append(addOpenFromWebLink(context, busObjectWithSelect, gco, integrationName, objID, jpoName, openToolTip ));
					}

					// Check for connected ECO and disply of ECO icon
//					if(!ecoObjId.equals("")) 
//					{
//						htmlBuffer.append(addECOLink(context, ecoObjId,  integrationName));
//					}
					if(!ecoObjId.equals("") || !caObjId.equals("")){
						htmlBuffer.append(addChangeManagementLink(context, ecoObjId, caObjId));
					}

					//Lock/UnLock Icon
					if(!isVersion) //[NDM] H68: not to show lock/unlock icon for minor
					{
					if(!canShowLockUnlock.equals("")) 
					{
						canShowLockUnlock = "TRUE|" + canShowLockUnlock;
					}
					//canShowLockUnlock = executeLinkJPO(context, majorObjectId, integrationName) ;
					htmlBuffer.append(addLockUnlockLink(context, majorObjectId, integrationName, canShowLockUnlock, lockUnlockToolTip));
					}
					htmlBuffer.append(addViewerLink(context, objectId, integrationName, formatViewerMap, busObjectWithSelect));
				}
				else
				{
					htmlBuffer.append(addSubscriptionLink(context, objectId,  "", subscribeToolTip));

					if(showFileDownloadIcon(context, objectId))
					{

						String checkoutURL				= "../components/emxCommonDocumentPreCheckout.jsp?objectId=" + objectId + "&amp;action=download&amp;Target Location=popup";
						htmlBuffer.append(getFeatureIconContent(checkoutURL, "../common/images/iconActionDownload.gif", downloadToolTip,"popup"));

						String actionURL = null;						
						integrationName	= util.getIntegrationName(context, objectId);

						if(integrationName != null && integrationNameGCOTable.containsKey(integrationName))
						{
							actionURL				= addViewerLink(context, objectId, integrationName, formatViewerMap, busObjectWithSelect);
							htmlBuffer.append(actionURL);
						}

					}
				}

				columnCellContentList.add(htmlBuffer.toString());
			}
		}
		catch(Exception e)
		{

		}
		return columnCellContentList;
	}

	// [NDM] QWJ
	private String addDownloadStructureLink(Context context, String objectId, boolean isVersionedObject) 
	{
		String downloadStructureToolTip	= serverResourceBundle.getString("mcadIntegration.Server.AltText.DownloadStructure");
		
		// [NDM] QWJ
		String downloadStructureURL			= "../integrations/DSCMCADGenericActionsProcess.jsp?action=DownloadStructure" + "&amp;Target Location=hiddenFrame" + "&amp;emxTableRowId=" + objectId + "&amp;isVersionedObject=" + isVersionedObject+"&amp;fromLocation=Table";
		String downloadStructureIcon		= "../common/images/iconActionDownload.gif";
		
		String url = getFeatureIconContent(downloadStructureURL, downloadStructureIcon, downloadStructureToolTip, "listHidden");
		
		return url;
	}

	private String addOpenFromWebLink(Context context, BusinessObjectWithSelect busObjectWithSelect, MCADGlobalConfigObject gco, String integrationName, String objectId, String jpoName, String openToolTip) throws Exception
	{
		String returnVal = "";
		try
		{
			Hashtable jpoArgsTable = new Hashtable();
			jpoArgsTable.put(MCADServerSettings.GCO_OBJECT, gco);
			jpoArgsTable.put(MCADServerSettings.LANGUAGE_NAME, serverResourceBundle.getLanguageName());
			jpoArgsTable.put(MCADServerSettings.OBJECT_ID, objectId);
			jpoArgsTable.put(MCADAppletServletProtocol.INTEGRATION_NAME, integrationName);
			jpoArgsTable.put(MCADServerSettings.OPERATION_UID, UUID.getNewUUIDString());
			jpoArgsTable.put("selectionList", busObjectWithSelect);
			jpoArgsTable.put("featureName", MCADGlobalConfigObject.FEATURE_OPEN);

			String[] args 		= JPO.packArgs(jpoArgsTable);

			Hashtable result 	= (Hashtable) JPO.invoke(context, jpoName, new String[] {}, "execute", args, Hashtable.class);
			String hrefLink		= (String) result.get("hrefString");

			String href			= "../integrations/IEFCustomProtocolHandler.jsp?hreflink=" + hrefLink + "&amp;integrationname=" + integrationName;
			String featureImage	= "../iefdesigncenter/images/iconActionCheckOut.gif";

			returnVal			= getFeatureIconContent(href ,featureImage , openToolTip , "listHidden");

		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return returnVal;

	}
}
