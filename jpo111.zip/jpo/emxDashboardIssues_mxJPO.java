import matrix.db.Context;


/**
 * @author G1F
 *
 */
public class emxDashboardIssues_mxJPO extends emxDashboardIssuesBase_mxJPO {
    /**
     * @param context
     * @param args
     * @throws Exception
     */
    public emxDashboardIssues_mxJPO(Context context, String[] args) throws Exception {
    	super(context, args);
    } 

}
