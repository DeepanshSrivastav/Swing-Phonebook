import java.util.HashMap;

import com.mando.util.cdmConstantsUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MapList;

import matrix.db.Context;
import matrix.db.JPO;

public class cdmAdminNotice_mxJPO {
	public cdmAdminNotice_mxJPO (Context context, String[] args) throws Exception {
		
	}
	
	
	public MapList CreateMyTest(Context context, String[] args)
	{
		MapList mapList = new  MapList();
		return mapList;
	}
	
	
	
	public MapList getNoticeList(Context context, String[] args)
	{
		
		String strType;
		
		//strType  = "TEST_cdmOrCADProduct";
		
		strType = cdmConstantsUtil.TYPE_CDMADMINNOTICE;
		//strType = "TEST_cdmOrCADProduct";
		MapList mapList = new  MapList();
		matrix.util.StringList selectObjs = new matrix.util.StringList();
		selectObjs.add(cdmConstantsUtil.SELECT_ID);
		
		
		   try {
			 mapList = DomainObject.findObjects(context, strType,
			           "*", "*", "*", "*", "",
			           false, selectObjs);
		} catch (FrameworkException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); 
		}
		
	return mapList;
	}
	
	public MapList getMyRelatedTest(Context context, String[] args)
	{
		MapList childList = new MapList();
		/*
		
		try {
			
			// HashMap paramMap                = (HashMap) JPO.unpackArgs(args);            
	            
	            String oTempID = (String) paramMap.get("objectId");
			
			
			
			 DomainObject parentObj = DomainObject.newInstance(context, oTempID);
				
				
				matrix.util.StringList selBusSelect = new matrix.util.StringList();
				matrix.util.StringList selRelSelect = new matrix.util.StringList();
				
				selRelSelect.add(cdmConstantsUtil.SELECT_RELATIONSHIP_ID);

				String sBusWhere = "";
				String sRelWhere = "";//cdmConstantsUtil.SELECT_ATTRIBUTE_REFERENCE_DESIGNATOR + "==" + reference;
				 childList = parentObj.getRelatedObjects(	context,
						"cdmTestRelationship"	,										
						//cdmConstantsUtil.RELATIONSHIP_CAD_SUBCOMPONENT,
																	cdmConstantsUtil.TYPE_PART,
																	selBusSelect,
																	selRelSelect,
																	false,
																	true,
																	(short) 0,
																	sBusWhere,
																	sRelWhere,
																	0
																);
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		*/
		
		
		
		
	
		
		return childList;
		
	}
	
	
	
	
	
}
