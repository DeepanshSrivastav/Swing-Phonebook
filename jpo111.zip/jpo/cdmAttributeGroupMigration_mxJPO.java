import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.classification.AttributeGroup;
import com.matrixone.apps.classification.Classification;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.StringUtil;
import com.matrixone.apps.domain.util.mxType;
import com.matrixone.apps.engineering.EngineeringConstants;
import com.matrixone.apps.engineering.PartFamily;

import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralCommon;
import com.matrixone.apps.library.LibraryCentralConstants;
import com.matrixone.apps.library.PartLibrary;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectList;
import matrix.db.BusinessType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.RelationshipType;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;

import com.dassault_systemes.cv.query.expand.cv_query_builder.option.Select;
import com.mando.util.cdmCommonExcel;

/* ***********************************************************************************
 * 원본 ${CLASS:cdmClassificationMigration}   바탕으로 코드 수정한것임
 * ${CLASS:cdmClassificationMigration} 는 반영하지않을 예정
 *   addAttrubute             // attribute 생성 
 *   createAttributeGroup     // Attribute Group 생성
 *   preRemoveAttributeGroup  // attribute group remove 
 * 
 *********************************************************************************** */

public class cdmAttributeGroupMigration_mxJPO {
	
	public static final String S_ATTRIBUTE_GROUP_PREFIX 	                = "cdm";
	public static final String S_FILE_SEPARATOR 	     	                = "\\";
	public static final String S_UNDER_LINE    	     		                = "_";
	public static final String S_PROPERTIESFILE             ="com/mando/migration/cdmMigrationStringResource";
//	public static final String S_ATTRIBUTE_MIGRATION_FLAG 	= "cdmMigrationFlag";
	public static final String S_ATTRIBUTE_MIGRATION_CHECK 	= "cdmCheckMigration";
	public static final String S_TYPE_PART_FAMILY 			= "Part Family";
	public static final String S_POLICY_CLASSIFICATION 		= "Classification";
	public static final String SELECT_ACTIVE_VERSION_ID = "relationship[Active Version].to.id";
	public void mxMain(Context context, String args[]) throws Exception {
		try {
			if (args == null || args.length < 0)
				throw new Exception();
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}
	
	/**
	 * Description: 
	 * error:
	 * 	read file path file name and sheet name value empty :Wrong number of arguments or arguments with wrong values!"
	 * 	row value: null  					   				:"THERE IS NO INFORMATION IN THE EXCEL SHEET."
	 * 	row request value empty			   					:"THERE IS NO REQUIRED INFORMATION IN THE EXCEL SHEET." 
	 *	same attribute exist                 				: ALREADY EXIST ATTRIBUTE.
	 *  
	 * attribute 'name'        prefix set.  cdm
	 * attribute 'description' prefix set.  cdm:
	 * 
	 * 생성한 attribute는 log 파일 폴더 하위에 Attribute_MQL 이란 폴더안에 mql 파일으로 기록함 
	 *    
	 * 엑셀로 된 데이타 중 data 탭의 정보로 attribute을 생성하며 
	 * 엑셀 정보는 A,B,C(순번,기존명,영문명) 열 의 데이타로 존재하며 모두 데이타가 있어야 attribute 생성된다. 
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "deprecation"})
	public void addAttrubute(Context context, String args[]) throws Exception {

		Long startTime =System.currentTimeMillis() ;
		System.out.println("cdmAttributeGroupMigration_mxJPO : addAttribute() start  "+getTimeStamp());
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		String sheetName                     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String logFileName = "addAttrubuteM";
		
		String attributeGroupExcelPath 		= "";
		String attributeGroupExcelName 		= "";
		String attributeGroupDataSheetName 	= "";
		String attributeGroupDataOutputDir 	= "";
		String outputAttribute_MQL 	= "";
		
		//Test for intput path  start 
//		Map paramMap = new HashMap();
//		paramMap = (Map) JPO.unpackArgs(args);
//		String sFileLocationAndFileName = (String)paramMap.get("fileData");
		//Test for intput path  end
		
		//EX: C:\\temp\\Import_File\\ATTRIBUTE_GROUP\\20161129_002_DM_SPEC_NAME.xlsx 
		String sFileLocationAndFileName = args[0];
		
		// sheet 명
		String Attribute_Group_Excel_Attribute_Data_Sheet_Name = "data";  
		attributeGroupExcelPath 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf(File.separator));
		attributeGroupExcelName 	= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf(File.separator)+1);
		attributeGroupDataSheetName = Attribute_Group_Excel_Attribute_Data_Sheet_Name;
		attributeGroupDataOutputDir = "MIGRATION_LOGS"; 
		outputAttribute_MQL = "Attribute_MQL";
		
//		Properties prop = new Properties();
//		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
//		attributeGroupExcelPath 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Path"));
//		attributeGroupExcelName 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Name"));
//		attributeGroupDataSheetName			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Attribute_Data_Sheet_Name"));
//		attributeGroupDataOutputDir 		= cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
//		outputAttribute_MQL					= cdmStringUtil.convertISOtoUTF8((String)prop.get("OUTPUT_ATTRIBUTE_MQL"));
		
		
		// read file path ,read file Name sheet
		if (cdmStringUtil.isEmpty(attributeGroupExcelPath) || cdmStringUtil.isEmpty(attributeGroupExcelName) || cdmStringUtil.isEmpty(attributeGroupDataSheetName) || cdmStringUtil.isEmpty(attributeGroupDataOutputDir)) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory = attributeGroupExcelPath;
		fileName       = attributeGroupExcelName;
		sheetName      = attributeGroupDataSheetName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + S_FILE_SEPARATOR + attributeGroupDataOutputDir + S_FILE_SEPARATOR + logFileName + "_" +  S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		String createdAttributeDirectory = new File(inputDirectory).getParentFile() + S_FILE_SEPARATOR + attributeGroupDataOutputDir + S_FILE_SEPARATOR +outputAttribute_MQL  + "_" +  S_FILE_SEPARATOR;
		File fileOutputCreatedAttributeDirectory = new File(createdAttributeDirectory);
		if (!fileOutputCreatedAttributeDirectory.isDirectory()) {
			fileOutputCreatedAttributeDirectory.mkdirs();
		}
		
//		fileName = args[1];
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		String fileOutputCreatedAttributeDirectoryPath = fileOutputCreatedAttributeDirectory.getPath();
		
		int successCount = 0;
		int failCount 	 = 0;
		int totalCount   = 0;
		String sRowNum = "";
		String sRecordDescription = "";
		String sRecordName = "";
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"     ADD ATTRIBUTE DATA MIGRATION "+ getTimeStamp()+"  \n");
		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
	
		try {
			XSSFSheet addAttributeSheet = null;
			addAttributeSheet = cdmCommonExcel.getXssfSheet(context, inputDirectory + fileName, sheetName);
			
			int physicalNumberRows = addAttributeSheet.getPhysicalNumberOfRows();
			totalCount = physicalNumberRows-1;
			for (int i = 1; i < physicalNumberRows; i++) {
				boolean bCheckOff = false;
				try {
					XSSFRow row = addAttributeSheet.getRow(i);
					
//					sRowNum = String.valueOf(i+1);
					if (row == null){
						String errorMessage= "THERE IS NO INFORMATION IN THE EXCEL SHEET.";
						throw new Exception(errorMessage);
					}
				
					XSSFCell cell_Location    = row.getCell(0);
					XSSFCell cell_Description = row.getCell(1);
					XSSFCell cell_Name        = row.getCell(2);
					if (cell_Location == null ||( cell_Description == null && cell_Name == null)){
						String errorMessage= "THERE IS NO REQUIRED INFORMATION IN THE EXCEL SHEET.";
						throw new Exception(errorMessage);
					}
					
					String sLocation = getCellValue(cell_Location);
					if(UIUtil.isNullOrEmpty(sLocation)){
						sLocation = "";
					}
					sRowNum = sLocation ; 
					
					String stDecription = getCellValue(cell_Description);
					stDecription = isVaildNullData(stDecription);
					
					String stName = getCellValue(cell_Name);
					stName = isVaildNullData(stName);
					
					sRecordDescription = stDecription;
					sRecordName = stName;
					
					stName = "cdm" + stName;
					stDecription = "cdm:" + stDecription;

					StringBuffer stringBuff = new StringBuffer();
					stringBuff.append("list attribute \"" + stName + "\" select name dump |");

					String mqlResult = MqlUtil.mqlCommand(context, stringBuff.toString());
					StringList commandList = FrameworkUtil.split(mqlResult, "|");

					if (commandList.size() > 0) {
						String errorMessage = " ALREADY EXIST ATTRIBUTE. ATTRIBUTE NAME:" + stName;
						throw new Exception(errorMessage);

					} else {
						ContextUtil.startTransaction(context, true);
						MqlUtil.mqlCommand(context, "Trigger off");
						MqlUtil.mqlCommand(context, "history off");
						bCheckOff = true;
						StringBuffer stBuffCreateAttr = new StringBuffer();

						stBuffCreateAttr.append("add attribute \"" + stName + "\"");
						stBuffCreateAttr.append(" description  \"" + stDecription + "\"");
						stBuffCreateAttr.append(" type string  ;");

						StringBuffer stBuffPropertyAttr = new StringBuffer();
						String attributeName = "attribute_" + stName;

						stBuffPropertyAttr.append("add property \"" + attributeName + " \" on program eServiceSchemaVariableMapping.tcl to attribute \"" + stName + "\" ;");

						MqlUtil.mqlCommand(context, stBuffCreateAttr.toString());
						MqlUtil.mqlCommand(context, stBuffPropertyAttr.toString());

						StringBuffer stBufPrintAttribute = new StringBuffer();
						
						stBufPrintAttribute.append("print attribute \""+stName+"\"  output "+fileOutputCreatedAttributeDirectoryPath+File.separator+stName+".mql");
					
						MqlUtil.mqlCommand(context,stBufPrintAttribute.toString());
						MqlUtil.mqlCommand(context, "Trigger on");
						MqlUtil.mqlCommand(context, "history on");
						bCheckOff = false;

						ContextUtil.commitTransaction(context);
						successCount ++;
						multiWriteMessageToFile(successObjectidWriter, "LINE NUMBER: \t" + sRowNum +"\t ATTRIBUTE NAME \t"+stName+"\t"+stDecription);
					}
					

				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failCount++;
					multiWriteMessageToFile(logWriter, "Line Number: " + sRowNum + "\t" + sRecordDescription+"\t"+sRecordName+"\t"+exception.getMessage());
					multiWriteMessageToFile(failedObjectidWriter, "" + sRowNum+ "\t "+sRecordDescription+"\t"+sRecordName);
					
					mulitWriteErrorToFile(errorStream, "Line Number: " + sRowNum + "\t" + exception.getMessage());
					exception.printStackTrace(errorStream);
				}finally{
					if(bCheckOff){
						MqlUtil.mqlCommand(context, "Trigger on");
						MqlUtil.mqlCommand(context, "history on");
					}
				}

			}
			multiWriteMessageToFile(logWriter, "====================================================================================");
			multiWriteMessageToFile(logWriter, "        File add ATTRIBUTE Migration COMPLETED.                    ");
			multiWriteMessageToFile(logWriter, "====================================================================================\n");
			
		} catch (Exception e) {
			
			multiWriteMessageToFile(failedObjectidWriter, "LINE NUMBER: " + sRowNum +"| Exception: " + e.getMessage() );
			mulitWriteErrorToFile(errorStream, "LINE NUMBER: " + sRowNum + " | \t Exception" + e.getMessage());
			multiWriteMessageToFile(logWriter, "LINE NUMBER: " + sRowNum+" | \t Exception: " + e.getMessage() );
			e.printStackTrace(errorStream);
		} finally {
			multiWriteMessageToFile(logWriter, "====================================================================================");
			multiWriteMessageToFile(logWriter, "ADD ATTRIBUTE MIGRATION CLOSE TIME:  " + getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, "LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms                  ");
			multiWriteMessageToFile(logWriter, "FAIL COUNT: (" + failCount +")  SUCCESS COUNT:("+ successCount+")  TOTAL COUNT:("+totalCount+")               ");
			
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			System.out.println("cdmAttributeGroupMigration_mxJPO : addAttribute() end "+getTimeStamp());
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
		}
	}
	

	
	/**
	 * 9/1/16 
	 *  
	 * attribute group  
	 *  
	 * attribute Group name rule
	 * prefix : cdm  
	 * header CN_CODE
	 * Separator : -
	 * ex.  cdmBC226_WASHER SPRING
	 * 
	 * @param context :context information
	 * @param arg     :excel path 
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes", "deprecation" })
	public void createAttributeGroup(Context context,String[] arg)throws Exception{
		long startTime = System.currentTimeMillis();
		System.out.println("cdmAttributeGroupMigration_mxJPO:createAttributeGroup start ."+getTimeStamp());
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String logFileName = "createAttributeGroup";
		
		String tempAttributeGroupPath 				= "";
		String tempAttributeGroupName 				= "";
		String tempAttributeGroupDataSheetName 		= "";
		String tempAttributeGroupOriginalSheetName 	= "";
		String tempAttributeGroupOutputDir		 	= "";
		
		String sFileLocationAndFileName = arg[0];
		
		// sheet 명
		tempAttributeGroupPath 				= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf(File.separator));
		tempAttributeGroupName 				= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf(File.separator)+1);
		tempAttributeGroupDataSheetName 	= "data";
		tempAttributeGroupOriginalSheetName = "original";
		tempAttributeGroupOutputDir 		= "MIGRATION_LOGS"; 
		
//		Properties prop = new Properties();
//		prop 								= cdmCommonExcel.getProperty(S_PROPERTIESFILE);
//		tempAttributeGroupPath 			    = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Path"));
//		tempAttributeGroupName 			    = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Name"));
//		tempAttributeGroupDataSheetName     = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Attribute_Data_Sheet_Name"));
//		tempAttributeGroupOriginalSheetName = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Original_Sheet_Name"));
//		tempAttributeGroupOutputDir			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
		
		
		if(cdmStringUtil.isEmpty(tempAttributeGroupPath) || cdmStringUtil.isEmpty(tempAttributeGroupName) || cdmStringUtil.isEmpty(tempAttributeGroupOutputDir)){
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		//하나의 엑셀파일에 2시트를 사용 
		String sAttributeCheckSheetName = tempAttributeGroupDataSheetName;
		String sheetName                = tempAttributeGroupOriginalSheetName;
		
		inputDirectory = tempAttributeGroupPath;
		fileName 	   = tempAttributeGroupName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + S_FILE_SEPARATOR + tempAttributeGroupOutputDir + S_FILE_SEPARATOR + logFileName + "_" +  S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		String sRowNum = "";
		int totalCount = 0;
		int successCount = 0;
		int failCount 	 = 0;
		
		String sRecordPF = "";
		String sRecordAG = "";
		multiWriteMessageToFile(logWriter,"========================================================================================================================");
		multiWriteMessageToFile(logWriter,"CREATE ATTRIBUTEGROUP  "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(logWriter,"	Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"	Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"========================================================================================================================\n");
		try {
			MqlUtil.mqlCommand(context, "history off");
			Map attributeCheckMap = new HashMap();
			
			XSSFSheet attributeCheckSheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context,  inputDirectory+fileName,sAttributeCheckSheetName );
			if(attributeCheckSheet == null){
				String errorMessage = "Excel sheet information is null.";
				throw new Exception(errorMessage);
			}
			int attributeCheckSheetPhysicalNumberRows = attributeCheckSheet.getPhysicalNumberOfRows();
			
			for (int i = 1; i <= attributeCheckSheetPhysicalNumberRows; i++) {

					XSSFRow attributeCheckSheetRow = attributeCheckSheet.getRow(i);

					if (attributeCheckSheetRow == null)
						continue;

					XSSFCell cell_InputData     = attributeCheckSheetRow.getCell(1);    // input
					XSSFCell cell_AttributeName = attributeCheckSheetRow.getCell(2);    // cell_AttributeName
					
					String sInputData     = getCellValue(cell_InputData);
					String sAttributeName = getCellValue(cell_AttributeName);
					
					sInputData     = isVaildNullData(sInputData);
					sAttributeName = isVaildNullData(sAttributeName);
					if(cdmStringUtil.isEmpty(sInputData) || cdmStringUtil.isEmpty(sAttributeName)){
						continue;
					}
					attributeCheckMap.put(sInputData,sAttributeName);
			}
			
			
			XSSFSheet attributeGroupSheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context,  inputDirectory+fileName, sheetName);
			int attributeGroupSheetphysicalNumberRows = attributeGroupSheet.getPhysicalNumberOfRows();
			//
			totalCount = attributeGroupSheetphysicalNumberRows-1;
			
			for (int s = 1; s < attributeGroupSheetphysicalNumberRows; s++) {
				boolean bCheckOff = false;
				try{
					XSSFRow row = attributeGroupSheet.getRow(s);
					sRowNum = String.valueOf(s+1);	
//					if((s+1)>1304){
//						break;
//					}
//					if((s+1)<1304){
//						continue;
//					}
					
					if (row == null){
						String errorMessage= "THERE IS NO INFORMATION IN THE EXCEL SHEET.";
						throw new Exception(errorMessage);
					}
					
					XSSFCell cell_PF = row.getCell(0);// Part Family
					XSSFCell cell_AG = row.getCell(1);// attribute_Group

					String sPartFamilyName = getCellValue(cell_PF);
					String sAttributeGroup = getCellValue(cell_AG);

					sRecordPF	  = sPartFamilyName;
					sRecordAG 	  = sAttributeGroup;
					
					sPartFamilyName = isVaildNullData(sPartFamilyName);
					sAttributeGroup = isVaildNullData(sAttributeGroup);
					
//					if (cdmStringUtil.isNotEmpty(sPartFamilyName) && cdmStringUtil.isNotEmpty(sAttributeGroup)) {
					if (cdmStringUtil.isNotEmpty(sPartFamilyName) ) {

						int physicalCells = row.getPhysicalNumberOfCells();
						// each row  CN_SPEC_NAME_01~30 info map 
						StringList stRowList = new StringList();
						for (int j = 4; j <= physicalCells; j++) {

							XSSFCell attributeCell = row.getCell(j);
							if (attributeCell == null)
								continue;

							String sAttributeCell = getCellValue(attributeCell);
							sAttributeCell = isVaildNullData(sAttributeCell);

							if (cdmStringUtil.isEmpty(sAttributeCell))
								continue;

							/*
							 * ********************************************************************************************************
							 *  data sheet 
							 *  data Information on the sheet original Removes redundant information on the sheet original
							 *  CN_SPEC_NAME_01~30 field.
							 * ********************************************************************************************************
							 */
							String attributeCellValue = (String) attributeCheckMap.get(sAttributeCell);
							if (cdmStringUtil.isEmpty(attributeCellValue)) {
								String errorMessage = "DATA SHEET DIDNT RECODRD ATTRIBUTE DATA. ";
								throw new Exception(errorMessage);
							}
							
							// duplication check 
							if(!stRowList.contains(attributeCellValue)){
								stRowList.add(attributeCellValue);
							}
							
						}
			
						String description = "";
						if(UIUtil.isNotNullAndNotEmpty(sAttributeGroup)){
							description = sAttributeGroup;
						}
						String sAttributeValue = ""; 
//						String sPartFamilyAndAttributeGroupName = S_ATTRIBUTE_GROUP_PREFIX + sPartFamilyName + S_UNDER_LINE + sAttributeGroup;
						String sPartFamilyAndAttributeGroupName = sPartFamilyName ;
						
						for (Iterator sTemptAttributeIterator = stRowList.iterator(); sTemptAttributeIterator.hasNext();) {
							String stTempAttributeValue = S_ATTRIBUTE_GROUP_PREFIX + (String) sTemptAttributeIterator.next();
							sAttributeValue = "".equalsIgnoreCase(sAttributeValue) ? stTempAttributeValue : sAttributeValue.trim() + "|" + stTempAttributeValue.trim();
						}

						/* Attribute Group create check */
//						String checkAttributeGroup = "immediatederivative[" + sPartFamilyAndAttributeGroupName + "]";
//						String checkCreateAttribute = "list interface $1 select $2 dump $3";
//						String checkMqlResult = MqlUtil.mqlCommand(context, checkCreateAttribute, DomainConstants.INTERFACE_CLASSIFICATION_ATTRIBUTE_GROUPS, checkAttributeGroup, "|");

						String sClassificationAttributeGroups = PropertyUtil.getSchemaProperty("interface_ClassificationAttributeGroups");
						String checkAttributeGroup = "derived[" + sClassificationAttributeGroups + "]";
						String checkCreateAttribute = "list interface $1 select $2 dump $3";
						String checkMqlResult = MqlUtil.mqlCommand(context, checkCreateAttribute, sPartFamilyAndAttributeGroupName, checkAttributeGroup, "|");
						StringList sListMqlResult = new StringList();
						sListMqlResult = FrameworkUtil.split(checkMqlResult, "|");
						
						boolean bAttributeGroupMqlResult = false;
						if(sListMqlResult.size()>0){
							bAttributeGroupMqlResult = true;
						}
						
						if (!bAttributeGroupMqlResult) {
							ContextUtil.pushContext(context);
							Classification classification = new Classification();
							classification.createAttributeGroup(context, sPartFamilyAndAttributeGroupName, description, sAttributeValue);
							ContextUtil.popContext(context);
						} else {
							String errorMessage = "ALREADY ATTRIBUTE GROUP EXIST. ";
							throw new Exception(errorMessage);
						}

						//cdmAttributeGroupObject create start 
						DomainObject domObj = new DomainObject();

						MqlUtil.mqlCommand(context, "Trigger Off");
						bCheckOff = true;
						domObj.createObject(context, "cdmAttributeGroupObject", sPartFamilyAndAttributeGroupName, "-", "cdmAttributeGroupObjectPolicy", "eService Production");
						domObj.setAttributeValue(context, "cdmDescription", sAttributeValue);
						
						StringBuffer strBuffer = new StringBuffer();
						String[] attributesArray = sAttributeValue.split("\\|");
						int iAttrSize = attributesArray.length;
						for(int k=0; k<iAttrSize; k++){
							if(! "".equals(strBuffer.toString())){
								strBuffer.append("|");
								strBuffer.append(attributesArray[k]);
								strBuffer.append(",");
								strBuffer.append(String.valueOf(k+1));
							}else{
								if(k != 0){
									strBuffer.append("|");
								}
								strBuffer.append(attributesArray[k]);
								strBuffer.append(",");
								strBuffer.append(String.valueOf(k+1));
							}
						}
						domObj.setAttributeValue(context, "cdmAttributeGroupSequence", strBuffer.toString());
						domObj.setAttributeValue(context, "cdmCheckMigration", "Y");
						
						MqlUtil.mqlCommand(context, "Trigger On");
						bCheckOff = false;
						//cdmAttributeGroupObject create end
						
						successCount++;
						multiWriteMessageToFile(successObjectidWriter,sRowNum+"\t"+sRecordPF +"\t"+sRecordAG);
					} else {
						String errorMessage = "SHEET DATA NOT EXIST FILE DATA (CN_CODE). ";
						throw new Exception(errorMessage);

					}
				}catch(Exception e2){
					failCount++;
					multiWriteMessageToFile(logWriter, sRowNum+ "\t"+sRecordPF+"\t"+ e2.getMessage());
					mulitWriteErrorToFile( errorStream,"LINE NUMBER: "+sRowNum+"\t "+sRecordPF+"\t"+ e2.getMessage());
					e2.printStackTrace(errorStream);
					multiWriteMessageToFile(failedObjectidWriter,sRowNum+  "\t"+ sRecordPF+"\t"+sRecordAG);
				}finally{
					if(bCheckOff){
						MqlUtil.mqlCommand(context, "Trigger On");
					}
				}
			}
			
			
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"        File CREATE ATTRIBUTEGROUP OBJECT Migration COMPLETED.                    ");
			multiWriteMessageToFile(logWriter,"====================================================================================\n");
		} catch (Exception e) {
			e.printStackTrace();
			throw new FrameworkException(e.toString());
		}finally{
			multiWriteMessageToFile(logWriter,"========================================================================================================================");
			multiWriteMessageToFile(logWriter,"	CREATE ATTRIBUTEGROUP OBJECT MIGRATION CLOSE TIME:  "+getTimeStamp()+"          \n"  );
			multiWriteMessageToFile(logWriter,"	SUCCESS COUNT: ("+successCount+ ")"+"  FAIL COUNT: ("+failCount+")  Total Count: ("+totalCount+")"+" LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + " ms" );
			multiWriteMessageToFile(logWriter,"========================================================================================================================\n");
			
			MqlUtil.mqlCommand(context, "history on");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			System.out.println(" cdmAttributeGroupMigration_mxJPO : createAttributeGroup() finish ");
		}
	}
	
//	/**
//	 * Part Family create
//	 * attribute[cdmCheckMigration]  
//	 * @param context
//	 * @param args
//	 * @throws Exception
//	 */
//	@SuppressWarnings({ "unchecked", "rawtypes" })
//	public HashMap createPartFamily(Context context,String args[])throws Exception{
//		HashMap resultMap = new HashMap();
//		Map hm = (Map)JPO.unpackArgs(args);
//		try {
//			String sPartFaimly = (String) hm.get("pfName");
//			StringList stListPF = new StringList(5);
//
//			HashMap paramMap = new HashMap();
//			paramMap.put("TypeActual", LibraryCentralConstants.TYPE_PART_FAMILY);
//			paramMap.put("Policy", LibraryCentralConstants.POLICY_CLASSIFICATION);
//			paramMap.put("Name", sPartFaimly);
//			paramMap.put("Vault", cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//
//			Map partFamilyCreateMap = (Map) JPO.invoke(context, "emxPartFamily", null, "createPartFamilyJPO", JPO.packArgs(paramMap), Map.class);
//			String createPartFamily = (String) partFamilyCreateMap.get("id");
//			DomainObject dObjPF = new DomainObject();
//			dObjPF.setId(createPartFamily);
//			System.out.println("createPartFamily >>" + createPartFamily);
//			dObjPF.setAttributeValue(context, "cdmCheckMigration", "Y");
//			resultMap.put("partFamilyId", dObjPF.getObjectId());
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return resultMap;
//	}
	
	
	/**
	 * remove AttributeGroup
	 * 
	 * Description:
	 * 	Specific Part Family object  Specific  Attribute Group  remove 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void removeAttributeGroup(Context context,String args[])throws Exception{
		try {
		
			Map paramMap = (Map)JPO.unpackArgs(args);
			String parentName = (String)paramMap.get("sPF");
			Object attributeGroup = (Object)paramMap.get("attributeGroup");
			String sAttributeGroup = "";
			if(attributeGroup instanceof String){
				sAttributeGroup = String.valueOf(attributeGroup);
			}
			String parentId = "";
			String type = LibraryCentralConstants.TYPE_PART_FAMILY;
		
			String name = parentName;
			SelectList selectList = new SelectList();
			selectList.addId();

			MapList partFamilyMapList = DomainObject.findObjects(context, 
					type, 
					name, 
					"*", 
					"*", 
					"eService Production", 
					"",
					"",
					true, 
					selectList, 
					(short)0);
			
			for (Iterator iterator = partFamilyMapList.iterator(); iterator.hasNext();) {
				Map partFamily = (HashMap) iterator.next();
				parentId = (String)partFamily.get("id");
				break;
			}
			StringList strAttrList = new StringList(sAttributeGroup);
	        com.matrixone.apps.classification.Classification cls = (com.matrixone.apps.classification.Classification)DomainObject.newInstance (context, parentId, "Classification");

	        cls.removeAttributeGroups(context, strAttrList);
	        
	        
		} catch (Exception e) {
			e.printStackTrace();
			
		}
	}
	
	
	/**
	 * AttributeGroup delete
	 * 
	 * Description :
	 * 	Can not delete if data is being used 
	 *   
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "unused", "deprecation" })
	public void deleteAttributeGroup(Context context,String args[])throws Exception{
		
		long startTime = System.currentTimeMillis();
		
		System.out.println("[cdmAttributeGroupMigration_mxJPO : deleteAttributeGroup] start. "+getTimeStamp() );
//		String[] tempArg = {"C:\\temp\\Import_File\\ATTRIBUTE_GROUP","20160818_002 DM_SPEC_NAME.xlsx","원본"};
		
//		String[] tempArg = {S_ATTRIBUTE_GROUP_EXCEL_PATH,S_ATTRIBUTE_GROUP_EXCEL_NAME,S_ATTRIBUTE_GROUP_EXCEL_ORIGINAL_SHEET_NAME};
		String tempAttributeGroupExcelPath 				= "";
		String tempAttributeGroupExcelName 				= "";
		String tempAttributeGroupExcelOriginalSheetName = "";
		String tempAttributeGroupDataOutputDir = "";
		
		Properties prop = new Properties();
		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
		
		tempAttributeGroupExcelPath 			  = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Path"));
		tempAttributeGroupExcelName 			  = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Name"));
		tempAttributeGroupExcelOriginalSheetName  = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Original_Sheet_Name"));
		tempAttributeGroupDataOutputDir 		  = cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
		
		if (cdmStringUtil.isEmpty(tempAttributeGroupExcelPath) || cdmStringUtil.isEmpty(tempAttributeGroupExcelName) || cdmStringUtil.isEmpty(tempAttributeGroupExcelOriginalSheetName) || cdmStringUtil.isEmpty(tempAttributeGroupDataOutputDir) ) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		String logFileName 							= "deleteAttributeGroup";
		PrintStream deleteAttributeGroupErrorStream = null;
		File deleteAttributeGroupSuccessLogFile     = null;
		File deleteAttributeGroupFailedLogFile      = null;
		
		BufferedWriter successObjectBuffer    = null;
		BufferedWriter failObjectBuffer       = null;

		String outputDirectory 					= "";
		String inputDirectory       			= "";
		
		
		inputDirectory         = tempAttributeGroupExcelPath;
		String fileName        = tempAttributeGroupExcelName;
		String sheetName       = tempAttributeGroupExcelOriginalSheetName;
		
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}
		
		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile().getParent() + S_FILE_SEPARATOR + tempAttributeGroupDataOutputDir + S_FILE_SEPARATOR + logFileName + "_" + getTimeStamp() + S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		deleteAttributeGroupErrorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));
		deleteAttributeGroupSuccessLogFile = new File(outputDirectory + logFileName + "_SuccessLineNumber.log");
		successObjectBuffer = new BufferedWriter(new FileWriter(deleteAttributeGroupSuccessLogFile, true));

		deleteAttributeGroupFailedLogFile = new File(outputDirectory + logFileName + "_FailedObjectLineNumber" + ".log");
		failObjectBuffer = new BufferedWriter(new FileWriter(deleteAttributeGroupFailedLogFile, true));
		multiWriteMessageToFile(successObjectBuffer, "====================================================================================");
		multiWriteMessageToFile(successObjectBuffer, "	DELETE ATTRIBUTE GROUP  "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(successObjectBuffer, "	Reading input log file from : "+ inputDirectory);
		multiWriteMessageToFile(successObjectBuffer, "	Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(successObjectBuffer, "====================================================================================");
		multiWriteMessageToFile(failObjectBuffer,"[cdmAttributeGroupMigration_mxJPO : deleteAttributeGroup] ");
		mulitWriteErrorToFile(deleteAttributeGroupErrorStream,"[cdmAttributeGroupMigration_mxJPO : deleteAttributeGroup]");
		String sLineNumber = "";
		String sLineCN_CODE = "";
//		String sDeleteAG_Name = "";
		
		int sucessCount = 0;
		int failCount   = 0;
		int totalCount  = 0;
		try {

			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory + fileName, sheetName);
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();

			totalCount = physicalNumberRows-1;

			for (int s = 1; s < physicalNumberRows; s++) {
				sLineNumber = String.valueOf(s + 1);
				XSSFRow row = sheet.getRow(s);
				try {
					if(s%300==1){
						successObjectBuffer.flush();
						failObjectBuffer.flush();
					}
					
					if (row == null) {
						String errorMessage = "THERE IS NO INFORMATION IN THE EXCEL SHEET.";
						throw new Exception(errorMessage);
					}
					
					XSSFCell cell_PF = row.getCell(0);// Part Family
					XSSFCell cell_AG = row.getCell(1);// attribute_Group

					String sPartFamilyName = getCellValue(cell_PF);
					String sAttributeGroup = getCellValue(cell_AG);

					sPartFamilyName = isVaildNullData(sPartFamilyName);
					sAttributeGroup = isVaildNullData(sAttributeGroup);
					
					if (!(cdmStringUtil.isNotEmpty(sPartFamilyName) && cdmStringUtil.isNotEmpty(sAttributeGroup))) {
						String errorMessage = "THE INFORMATION PART FAMILY OR ATTRIBUTE GROUP DOES NOT EXIST IN THE EXCEL SHEET.";
						throw new Exception(errorMessage);
					}
						
					String attributeGroup = S_ATTRIBUTE_GROUP_PREFIX + sPartFamilyName + S_UNDER_LINE + sAttributeGroup;
					sLineCN_CODE = attributeGroup;
					AttributeGroup AG = new AttributeGroup();
					
					String sCheckExistAG = ""; 
					sCheckExistAG = MqlUtil.mqlCommand(context, "list interface \""+attributeGroup+"\"  ");
					
					if(cdmStringUtil.isNotEmpty(sCheckExistAG)){
						AG.setName(attributeGroup);
						/* AttributeGroup Check availability elsewhere */
						int countClassifiedItems = 0;
						
						countClassifiedItems = (int)AG.getNumberOfEndItemsWhereUsed(context);
						if (countClassifiedItems >= 1) {
							String errorMessage = "ATTRIBUTE GROUP ALREADY USED.";
							throw new Exception(errorMessage);
						}else{
							AG.delete(context);
						}
					}else{
						String errorMessage = "NOT EXIST ATTRIBUTE GROUP OBJECT.";
						throw new Exception(errorMessage);
					}
					
					// String tempName = Name;
					String sAttributeGroupObjectFindMql = "temp query bus \"cdmAttributeGroupObject\"  \"" + attributeGroup + "\"  * select id dump | ";
					String sAttributeGroupObjectFindMqlResult =	MqlUtil.mqlCommand(context, sAttributeGroupObjectFindMql);
					
					StringList sListAttributeGroupObjectFindMqlResult = new 	StringList();
					sListAttributeGroupObjectFindMqlResult = FrameworkUtil.split(sAttributeGroupObjectFindMqlResult, "|");
					
					if (sListAttributeGroupObjectFindMqlResult.size() > 2) {
						String sAttributeGroupObjectFindId = (String)sListAttributeGroupObjectFindMqlResult.get(3); 
						DomainObject dObjAttributeGroupObject = DomainObject.newInstance(context);
						dObjAttributeGroupObject.setId(sAttributeGroupObjectFindId);
						ContextUtil.startTransaction(context, true);
						dObjAttributeGroupObject.deleteObject(context);
						ContextUtil.commitTransaction(context);
					}
					
					sucessCount++;
					multiWriteMessageToFile(successObjectBuffer, " SUCESS!! LINE NUMBER: "+sLineNumber+"|AG NAME: "+attributeGroup );
					
				} catch (Exception e1) {
					ContextUtil.abortTransaction(context);
					failCount++;
					multiWriteMessageToFile(failObjectBuffer," LINE NUMBER: "+sLineNumber + "|EXCEPTION OCCUERED: "+e1.getMessage());
					mulitWriteErrorToFile(deleteAttributeGroupErrorStream,"LINE NUMBER: "+sLineNumber );
					e1.printStackTrace(deleteAttributeGroupErrorStream);
				}
			}

			multiWriteMessageToFile(successObjectBuffer, "====================================================================================");
			multiWriteMessageToFile(successObjectBuffer, "        File  Migration COMPLETED.                    ");
			multiWriteMessageToFile(successObjectBuffer, "====================================================================================");

		} catch (Exception e) {
			e.printStackTrace(deleteAttributeGroupErrorStream);
		}finally{
			multiWriteMessageToFile(successObjectBuffer,"====================================================================================");
			multiWriteMessageToFile(successObjectBuffer,"		DELETE ATTRIBUTEGROUP OBJECT CLOSE TIME:  "+getTimeStamp()+"          "  );
			multiWriteMessageToFile(successObjectBuffer,"		LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000 + " second         "  );
			multiWriteMessageToFile(successObjectBuffer,"		SUCCESS COUNT: ("+ sucessCount+")   FAIL COUNT: ("+failCount+")  TOTLA COUNT: ("+totalCount+")" );
			multiWriteMessageToFile(successObjectBuffer,"==================================================================================== \n");
			
			try {
				if (null != deleteAttributeGroupErrorStream )
					deleteAttributeGroupErrorStream .close();

				if (null != successObjectBuffer)
					successObjectBuffer.close();

				if (null != failObjectBuffer)
					failObjectBuffer.close();
				
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			System.out.println("cdmAttributeGroupMigration_mxJPO : deleteAttributeGroup() end ");
		}
	}
	
	/**
	 * Attribute group remove
	 * 
	 *  REMOVE connection of ATTRIBUTE GROUP connected with Part Family based on original sheet.
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes" })
	public void checkAndRemoveAndAttributeGroup(Context context, String args[])throws Exception{
		
		long startTime = System.currentTimeMillis();
		
		System.out.println("[cdmAttributeGroupMigration_mxJPO : checkAndRemoveAndAttributeGroup] start. "+getTimeStamp() );
		Properties prop = new Properties();
		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
		String tempAttributeGroupExcelPath = "";
		String tempAttributeGroupExcelName = "";
		String tempAttributeGroupExcelOriginalSheetName = "";
		String tempAttributeGroupDataOutputDir = "";
		
		tempAttributeGroupExcelPath 			 = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Path"));
		tempAttributeGroupExcelName 			 = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Name"));
		tempAttributeGroupExcelOriginalSheetName = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Original_Sheet_Name"));
		tempAttributeGroupDataOutputDir 		 = cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
		
//		String[] tempArg = {"C:\\temp\\Import_File\\ATTRIBUTE_GROUP","20160818_002 DM_SPEC_NAME.xlsx","원본"};
//		String OUTPUT_FOLDER = "MIGRATION_LOGS";
		String logFileName 							= "removeAttributeGroup";
		PrintStream removeAttributeGroupErrorStream = null;
		File removeAttributeGroupSuccessLogFile     = null;
		File removeAttributeGroupFailedLogFile      = null;
		
		BufferedWriter removeSuccessObjectBuffer    = null;
		BufferedWriter removeFailObjectBuffer       = null;

		String removeOutputDirectory 				= "";
		String removeInputDirectory       			= "";
		
		if (cdmStringUtil.isEmpty(tempAttributeGroupExcelPath) || cdmStringUtil.isEmpty(tempAttributeGroupExcelName) || cdmStringUtil.isEmpty(tempAttributeGroupExcelOriginalSheetName) || cdmStringUtil.isEmpty(tempAttributeGroupDataOutputDir) ) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		removeInputDirectory         = tempAttributeGroupExcelPath;
		String removeFileName        = tempAttributeGroupExcelName;
		String removeSheetName       = tempAttributeGroupExcelOriginalSheetName;
		
		
		if (removeInputDirectory != null && !removeInputDirectory.endsWith(S_FILE_SEPARATOR)) {
			removeInputDirectory = removeInputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
//		removeOutputDirectory = new File(removeInputDirectory).getParentFile().getParent() + S_FILE_SEPARATOR + "confirm_File" + S_FILE_SEPARATOR + logFileName + "_" + getTimeStamp() + S_FILE_SEPARATOR;
		removeOutputDirectory = new File(removeInputDirectory).getParentFile().getParent() + S_FILE_SEPARATOR + tempAttributeGroupDataOutputDir + S_FILE_SEPARATOR + logFileName + "_" + getTimeStamp() + S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(removeOutputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		removeAttributeGroupErrorStream = new PrintStream(new FileOutputStream(new File(removeOutputDirectory + logFileName + "_ErrorLog.log")));
		removeAttributeGroupSuccessLogFile = new File(removeOutputDirectory + logFileName + "_SuccessIds.log");
		removeSuccessObjectBuffer = new BufferedWriter(new FileWriter(removeAttributeGroupSuccessLogFile, true));

		removeAttributeGroupFailedLogFile = new File(removeOutputDirectory + logFileName + "_FailedObjectids" + ".log");
		removeFailObjectBuffer = new BufferedWriter(new FileWriter(removeAttributeGroupFailedLogFile, true));
		multiWriteMessageToFile(removeSuccessObjectBuffer, "====================================================================================");
		multiWriteMessageToFile(removeSuccessObjectBuffer, "     REMOVE ATTRIBUTE GROUP  "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(removeSuccessObjectBuffer, "	 Reading input log file from : "+ removeInputDirectory);
		multiWriteMessageToFile(removeSuccessObjectBuffer, "	 Writing Log files to: " + removeOutputDirectory );
		multiWriteMessageToFile(removeSuccessObjectBuffer, "====================================================================================");
		mulitWriteErrorToFile(removeAttributeGroupErrorStream,"[cdmAttributeGroupMigration_mxJPO : checkAndRemoveAndAttributeGroup]");
		String sLineNumber = "";
		String sLineCN_CODE = "";
		
		int sucessCount = 0;
		int failCount   = 0;
		int totalCount  = 0;
		
		try {
			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, removeInputDirectory+removeFileName,removeSheetName );
			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
			
			totalCount = physicalNumberRows ;
			
			for (int s = 1; s <= physicalNumberRows; s++) {
				XSSFRow row = sheet.getRow(s);
				sLineNumber = String.valueOf(s+1);
				try {
					
					if (row == null){
						String errorMessage= "THERE IS NO INFORMATION IN THE EXCEL SHEET.";
						throw new Exception(errorMessage);
					}
					
					XSSFCell cell_PF = row.getCell(0);// Part Family
					XSSFCell cell_AG = row.getCell(1);// attribute_Group

					String sPartFamilyName = getCellValue(cell_PF);
					String sAttributeGroup = getCellValue(cell_AG);

					sPartFamilyName = isVaildNullData(sPartFamilyName);
					sAttributeGroup = isVaildNullData(sAttributeGroup);
					
					sLineCN_CODE = sPartFamilyName;
					
					if (cdmStringUtil.isNotEmpty(sPartFamilyName) && cdmStringUtil.isNotEmpty(sAttributeGroup)) {
						String attributeGroup = S_ATTRIBUTE_GROUP_PREFIX + sPartFamilyName + S_UNDER_LINE + sAttributeGroup;

//						Map attributeInfoMap = new HashMap();
//						attributeInfoMap.put("sPF", sPartFamilyName);
//						attributeInfoMap.put("attributeGroup", attributeGroup);
//						JPO.invoke(context, "cdmAttributeGroupMigration", null, "removeAttributeGroup", JPO.packArgs(attributeInfoMap));
						ContextUtil.startTransaction(context, true);
						String type = cdmConstantsUtil.TYPE_PART_FAMILY;
//						String sFindPFMql = "temp query bus '"+type+"' '"+attributeGroup+"' *  select id dump | ";
						String sFindPFMql = "temp query bus \""+type+"\" '"+sPartFamilyName+"*'  *  where \"attribute[cdmCheckMigration]== 'Y' \" select id dump | ";
						String sFindPFMqlResult = MqlUtil.mqlCommand(context, sFindPFMql);
						
						StringList sListFindPFMqlResult  = new StringList(); 
						sListFindPFMqlResult = FrameworkUtil.split(sFindPFMqlResult, "\n");
						
						if(sListFindPFMqlResult.size()<2){
							String errorMessage = "NOT EXIST PART FAMILY OBJECT.";
							throw new Exception(errorMessage);
						}
						
						String partFamilyId = "";
						
						StringList strAttrList = new StringList(attributeGroup);
						for (Iterator findPFIterator = sListFindPFMqlResult.iterator(); findPFIterator.hasNext();) {
							String sPFIter = (String) findPFIterator.next();

							StringList sListPFIter = FrameworkUtil.split(sPFIter, "|");
							partFamilyId = (String) sListPFIter.get(3);

							com.matrixone.apps.classification.Classification cls = (com.matrixone.apps.classification.Classification) DomainObject.newInstance(context, partFamilyId, "Classification");
							cls.removeAttributeGroups(context, strAttrList);
						}
				        ContextUtil.commitTransaction(context);
				        sucessCount ++;
				        multiWriteMessageToFile(removeSuccessObjectBuffer, "SUCESS!! Line Number: "+sLineNumber +" Name: "+sLineCN_CODE);
					}else{
						String errorMessage = "THERE IS NO (PART FAMILY,ATTRIBUTE GROUP) INFORMATION IN THE EXCEL SHEET.";
						throw new Exception(errorMessage);
					}
				}catch(Exception e2){
					ContextUtil.abortTransaction(context);
					failCount ++;
					multiWriteMessageToFile(removeFailObjectBuffer, "Line Number: "+sLineNumber+ " Name: "+sLineCN_CODE+" Exception occured: "+e2.getMessage());
					mulitWriteErrorToFile(removeAttributeGroupErrorStream, "Line Number: "+sLineNumber+ " Name: "+sLineCN_CODE+"  Exception occured: "+e2.getMessage());
					e2.printStackTrace(removeAttributeGroupErrorStream);
				}
			}
			multiWriteMessageToFile(removeSuccessObjectBuffer, "====================================================================================");
			multiWriteMessageToFile(removeSuccessObjectBuffer,"        File  Migration COMPLETED.                    ");
			multiWriteMessageToFile(removeSuccessObjectBuffer,"====================================================================================\n");
			
		}catch(Exception e){
			
			mulitWriteErrorToFile(removeAttributeGroupErrorStream, "Line Number: "+sLineNumber+ " Exception occured: "+e.getMessage());
			e.printStackTrace(removeAttributeGroupErrorStream);
		}finally{
			multiWriteMessageToFile(removeSuccessObjectBuffer,"====================================================================================");
			multiWriteMessageToFile(removeSuccessObjectBuffer,"	REMOVE ATTRIBUTEGROUP OBJECT CLOSE TIME:  "+getTimeStamp()+"          "  );
			multiWriteMessageToFile(removeSuccessObjectBuffer,"	LEAD TIME: "+ ((System.currentTimeMillis() - startTime)/1000)  + "second         "  );
			multiWriteMessageToFile(removeSuccessObjectBuffer," SUCESSCOUNT: ("+sucessCount+")   FAILCOUNT: (" +failCount+")   TOTALCOUNT: ("+totalCount+")");
			multiWriteMessageToFile(removeSuccessObjectBuffer,"==================================================================================== \n");
			
			System.out.println("cdmAttributeGroupMigration_mxJPO : checkAndRemoveAndAttributeGroup() end " );
			try {
				if (null != removeAttributeGroupErrorStream )
					removeAttributeGroupErrorStream .close();

				if (null != removeSuccessObjectBuffer)
					removeSuccessObjectBuffer.close();

				if (null != removeFailObjectBuffer)
					removeFailObjectBuffer.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
		}
	}
	

	
	
	
	
	/**
	 *  create Part Family block code  
	 *  DESCRIPTION;
	 *  첫번째 시트를 사용하며 sheetName이 없으면 첫번째 시트의 데이타로 구성)
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void createPatFamilyForBlockCode(Context context,String args[])throws Exception{
		long startTime = System.currentTimeMillis();
		System.out.println("cdmClassificationMigration : createPatFamilyForBlockCode start. "+getTimeStamp());
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
	
		String sheetName   = "";
		String logFileName = "createPatFamily";
		
		String tempPartfamilyExcelPath = "";
		String tempPartfamilyExcelName = "";
		String tempOutputDir = "MIGRATION_LOGS";
		
		String sFileLocationAndFileName = args[0];
		
		// 엑셀 정보 
		tempPartfamilyExcelPath 				= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf(File.separator));
		tempPartfamilyExcelName 				= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf(File.separator)+1);
		
//		Properties prop = new Properties();
//		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
//		tempPartfamilyExcelPath 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("PART_FAMILY_EXCEL_PATH"));
//		tempPartfamilyExcelName 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("PART_FAMILY_EXCEL_NAME"));
//		tempOutputDir 						= cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
		
		if (cdmStringUtil.isEmpty(tempPartfamilyExcelPath) || cdmStringUtil.isEmpty(tempPartfamilyExcelName) || cdmStringUtil.isEmpty(tempOutputDir) ) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}

		inputDirectory = tempPartfamilyExcelPath;
		fileName 	   = tempPartfamilyExcelName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + S_FILE_SEPARATOR + tempOutputDir + S_FILE_SEPARATOR + logFileName + "_" +  S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		String sRowNum = "";
		
		int successRowCount = 0;
		int failRowCount = 0;
		int totalRowCount = 0;
		multiWriteMessageToFile(logWriter,"======================================================================================================================");
		multiWriteMessageToFile(logWriter,"     CREATE PART FAMILY  "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"======================================================================================================================");
		
		String sRecordCompany			= "";  		
		String sRecordProductCode 	  	= "";
		String sRecordProductCodeName 	= "";
		String sRecordBlockCode 		= "";
		String sRecordBlockCodeName	  	= "";

		try {
			MqlUtil.mqlCommand(context, "history off");
			Sheet sheet = (Sheet) cdmCommonExcel.getXssfSheet2(context, inputDirectory+fileName, sheetName);
			int sheetPhysicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalRowCount = sheetPhysicalNumberRows-1;
			//part Library 
			for (int i = 1; i < sheetPhysicalNumberRows; i++) {
				Row sheetRow = sheet.getRow(i);
				boolean checkTriggerOff = false;
				try{
					sRowNum         = String.valueOf(i+1);
					if (sheetRow == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL)";
						throw new Exception(errorMessage);
					}
					
					Cell cell_1 = sheetRow.getCell(1);
					Cell cell_2 = sheetRow.getCell(2);
					Cell cell_3 = sheetRow.getCell(3);
					Cell cell_4 = sheetRow.getCell(4);
					Cell cell_5 = sheetRow.getCell(5);
				   
					String sCompany  		    = getCellValue2(cell_1);
					String sProductCode 	   	= getCellValue2(cell_2);
					String sProductCodeName 	= getCellValue2(cell_3);
					String sBlockCode 			= getCellValue2(cell_4);
					String sBlockCodeName		= getCellValue2(cell_5);
				   
					if(cdmStringUtil.isEmpty(sCompany) || cdmStringUtil.isEmpty(sProductCode) || cdmStringUtil.isEmpty(sProductCodeName) || cdmStringUtil.isEmpty(sBlockCode)||cdmStringUtil.isEmpty(sBlockCodeName)){
						String errorMessage = "REQUIRED DATA DOES NOT EXIST.";
						throw new Exception(errorMessage);
					}
					
					sRecordCompany			  = sCompany;  		
					sRecordProductCode 	      = sProductCode; 	
					sRecordProductCodeName    = sProductCodeName; 
					sRecordBlockCode 		  = sBlockCode; 		
					sRecordBlockCodeName	  = sBlockCodeName;	
					
				   if(!"Global R&D".equals(sCompany)){
					   String errorMessage = "IT IS NOT A MIGRATION TARGET.";
					   throw new Exception(errorMessage);
				   }
				   MqlUtil.mqlCommand(context, "Trigger Off");
				   checkTriggerOff = true;
				   
				   ContextUtil.startTransaction(context, true);
				   // part family rule have to apply
//				   String sPartFamilyNameLev1 = sCompany;
//				   String sPartFamilyNameLev2 = sProductCode+":"+sProductCodeName;
//				   String sPartFamilyNameLev3 = sProductCode+sBlockCode+":"+sBlockCodeName;
				   
//				   cdmPartFamilyBlockCodeName
//				   cdmPartFamilyProductCodeName
				   
				   String sPFlev1 = sCompany;
				   String sPFlev2 = sProductCode+":"+sProductCodeName;
				   String sPFlev3 = sProductCode+sBlockCode+":"+sBlockCodeName;
				   
				   String sTempsPFlev2 = "";
				   boolean checkSpecialSymbolsTempsPFlev2 = false; 
				   if(sPFlev2.contains(",")){
					   sTempsPFlev2 = sPFlev2.replaceAll(",", "?");
					   checkSpecialSymbolsTempsPFlev2 = true;
				   }

				   if(sPFlev2.contains("'") ){
					   sTempsPFlev2 = sPFlev2.replaceAll("'", "?");
					   checkSpecialSymbolsTempsPFlev2 = true;
				   }
				   
				   
				   String sTempsPFlev3 = "";
				   boolean checkSpecialSymbolsTempsPFlev3 = false;  
				   if(sPFlev3.contains(",") ){
					   sTempsPFlev3 = sPFlev3.replaceAll(",", "?");
					   checkSpecialSymbolsTempsPFlev3 = true;
				   }
				   
				   if(sPFlev3.contains("'") ){
					   sTempsPFlev3 = sPFlev3.replaceAll("'", "?");
					   checkSpecialSymbolsTempsPFlev3 = true;
				   }
				   
				   
//				   String checkPartFamily = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \""+sPartFamilyNameLev1 +"\"  \"*\"  select id dump |  ";
				   String checkPartFamily = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \"*\"  \"*\" where \"attribute[cdmPartFamilyBlockCodeName]=='"+sCompany+"'\" select id dump |  ";
				   String checkPartFamilyResult = MqlUtil.mqlCommand(context, checkPartFamily);
					if (cdmStringUtil.isEmpty(checkPartFamilyResult)) {

						com.matrixone.apps.library.PartFamily partFamilyLev1 = new com.matrixone.apps.library.PartFamily();
						String sAutoNameLev1Name = DomainObject.getAutoGeneratedName(context, "type_PartFamily", "");
						partFamilyLev1.createObject(context, S_TYPE_PART_FAMILY, sAutoNameLev1Name, null, S_POLICY_CLASSIFICATION, "eService Production");

						partFamilyLev1.setAttributeValue(context,S_ATTRIBUTE_MIGRATION_CHECK, "Y");
						partFamilyLev1.setAttributeValue(context,"cdmPartFamilyBlockCodeName", sPFlev1);
						String sPartFamilyIdLev1 = partFamilyLev1.getId(context);
						//
						String strParentType="";
				    	String strClassName="";
				    	String strClassType="";
				    	
			            DomainObject domainObj = new DomainObject();
			            domainObj.setId(sPartFamilyIdLev1);
			            strClassType  =  domainObj.getInfo(context,DomainObject.SELECT_TYPE);
			            BusinessType busType = new BusinessType(strClassType,context.getVault());
			            strParentType= busType.getParent(context);
			            strClassName  =  domainObj.getInfo(context,DomainObject.SELECT_NAME);
			            java.util.Date sysDate = new Date();
			            long lTime = sysDate.getTime();
			            String strInterfaceName = domainObj.getInfo(context, "physicalid");
			            try{
			                String strMQL       =  "add interface $1 type all";
			                ContextUtil.pushContext(context);

			                MqlUtil.mqlCommand(context, strMQL, strInterfaceName);

			                strMQL      = "modify bus $1 $2 $3";
			                MqlUtil.mqlCommand(context, strMQL, sPartFamilyIdLev1,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE, strInterfaceName);

			                if(strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_LIBRARIES))
			                {
			                    strMQL      = "modify interface $1 derived $2";
			                    MqlUtil.mqlCommand(context, strMQL, strInterfaceName,LibraryCentralConstants.INTERFACE_CLASSIFICATION_TAXONOMIES);
			                }

						}catch(Exception e)
						{
							e.printStackTrace();
							throw e;
						}finally{
							ContextUtil.popContext(context);
						}
			            try{
			    			Map argsHash = new HashMap();
			    			String[] tempArg = JPO.packArgs(argsHash);
			    			String mqlString="list program $1";
			    			String output=MqlUtil.mqlCommand(context, mqlString,"emxPLMDictionaryProgram");
			    			if(UIUtil.isNotNullAndNotEmpty(output)){
			    				JPO.invoke(context, "emxPLMDictionaryProgram", null, "invalidateCache", tempArg,Integer.class);
			    			}
			    		}catch (MatrixException e) {
			    			throw e;
			    		}
			            
			            
			    		String attOriginator = "Originator";
			    		String sUser = context.getUser();
			            StringBuffer argBuffer = new StringBuffer(100);
			            argBuffer.append("modify bus ");
			    		argBuffer.append(sPartFamilyIdLev1);
			    		argBuffer.append(" \"");
			    		argBuffer.append(attOriginator);
			    		argBuffer.append("\" \"");
			    		argBuffer.append(sUser);
			    		argBuffer.append("\"");
			    		String arguments[] = new String[1];
			    		arguments[0] = argBuffer.toString();
			    		emxUtil_mxJPO utilityClass = new emxUtil_mxJPO(context, null);
			    		utilityClass.executeMQLCommands(context, arguments);
						
						//
						
					}
					
					String checkPartFamilyLev2 = "";
				    if(checkSpecialSymbolsTempsPFlev2){
//					   checkPartFamilyLev2 = "temp query bus 'Part Family' \""+sTempPartFamilyNameLev2 +"\"  \"*\"  select name dump |  ";
					   checkPartFamilyLev2 = "temp query bus 'Part Family' \"*\"  \"*\" where \"attribute[cdmPartFamilyBlockCodeName] ~= '"+sTempsPFlev2+"'\"  select attribute[cdmPartFamilyBlockCodeName] dump |  ";
				    }else{
//				    	checkPartFamilyLev2 = "temp query bus 'Part Family' \""+sPartFamilyNameLev2 +"\"  \"*\"  select name dump |  ";
				    	checkPartFamilyLev2 = "temp query bus 'Part Family' \"*\"  \"*\" where \"attribute[cdmPartFamilyBlockCodeName] == '"+sPFlev2+"'\"  select attribute[cdmPartFamilyBlockCodeName] dump |  ";
				    }
				   String checkPartFamilyLev2Result = MqlUtil.mqlCommand(context, checkPartFamilyLev2);
				   
				   StringList sListCheckPartFamilyLev2Result = new StringList();
				   sListCheckPartFamilyLev2Result = FrameworkUtil.split(checkPartFamilyLev2Result, "|");
				   boolean bExistPartFamilyLev2Result = false;
				   
				   if (sListCheckPartFamilyLev2Result.size()>2 && checkSpecialSymbolsTempsPFlev2) {
					   StringList sListCheckSpecialSymbolPartFamilyLev2Result = new StringList();   
					   sListCheckSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(checkPartFamilyLev2Result, "\n");
						for (Iterator iterSpecialSymbol = sListCheckSpecialSymbolPartFamilyLev2Result.iterator(); iterSpecialSymbol.hasNext();) {
							String sSpecialSymbolPartFamilyLev2Result = (String) iterSpecialSymbol.next();
							StringList sListSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev2Result, "|");
							String tempPartFamily2Name = (String) sListSpecialSymbolPartFamilyLev2Result.get(3);
							if (cdmStringUtil.isNotEmpty(tempPartFamily2Name) && tempPartFamily2Name.equals(sPFlev2)) {
								bExistPartFamilyLev2Result = true;
							}

						}
					   
				   }
					if (sListCheckPartFamilyLev2Result.size()<2 || (!bExistPartFamilyLev2Result &&checkSpecialSymbolsTempsPFlev2)) {
						com.matrixone.apps.library.PartFamily partFamilyLev2 = new com.matrixone.apps.library.PartFamily();
//						partFamilyLev2.createObject(context, S_TYPE_PART_FAMILY, sPartFamilyNameLev2, null, S_POLICY_CLASSIFICATION, "eService Production");
						String sAutoNamePFlev2 = DomainObject.getAutoGeneratedName(context, "type_PartFamily", "");
						partFamilyLev2.createObject(context, S_TYPE_PART_FAMILY, sAutoNamePFlev2, null, S_POLICY_CLASSIFICATION, "eService Production");
						partFamilyLev2.setAttributeValue(context, S_ATTRIBUTE_MIGRATION_CHECK, "Y");
						partFamilyLev2.setAttributeValue(context, "cdmPartFamilyBlockCodeName", sPFlev2);
						
						String sPartFamilyIdLev2 = partFamilyLev2.getId(context);
						
						String strParentType="";
				    	String strClassName="";
				    	String strClassType="";
				    	
			            DomainObject domainObj = new DomainObject();
			            domainObj.setId(sPartFamilyIdLev2);
			            strClassType  =  domainObj.getInfo(context,DomainObject.SELECT_TYPE);
			            BusinessType busType = new BusinessType(strClassType,context.getVault());
			            strParentType= busType.getParent(context);
			            strClassName  =  domainObj.getInfo(context,DomainObject.SELECT_NAME);
			            java.util.Date sysDate = new Date();
			            long lTime = sysDate.getTime();
			            String strInterfaceName = domainObj.getInfo(context, "physicalid");
			            try{
			                String strMQL       =  "add interface $1 type all";
			                ContextUtil.pushContext(context);

			                MqlUtil.mqlCommand(context, strMQL, strInterfaceName);

			                strMQL      = "modify bus $1 $2 $3";
			                MqlUtil.mqlCommand(context, strMQL, sPartFamilyIdLev2,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE, strInterfaceName);

			                if(strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_LIBRARIES))
			                {
			                    strMQL      = "modify interface $1 derived $2";
			                    MqlUtil.mqlCommand(context, strMQL, strInterfaceName,LibraryCentralConstants.INTERFACE_CLASSIFICATION_TAXONOMIES);
			                }

						}catch(Exception e)
						{
							e.printStackTrace();
							throw e;
						}finally{
							ContextUtil.popContext(context);
						}
			            try{
			    			Map argsHash = new HashMap();
			    			String[] tempArg = JPO.packArgs(argsHash);
			    			String mqlString="list program $1";
			    			String output=MqlUtil.mqlCommand(context, mqlString,"emxPLMDictionaryProgram");
			    			if(UIUtil.isNotNullAndNotEmpty(output)){
			    				JPO.invoke(context, "emxPLMDictionaryProgram", null, "invalidateCache", tempArg,Integer.class);
			    			}
			    		}catch (MatrixException e) {
			    			throw e;
			    		}
			            
			            
			    		String attOriginator = "Originator";
			    		String sUser = context.getUser();
			            StringBuffer argBuffer = new StringBuffer(100);
			            argBuffer.append("modify bus ");
			    		argBuffer.append(sPartFamilyIdLev2);
			    		argBuffer.append(" \"");
			    		argBuffer.append(attOriginator);
			    		argBuffer.append("\" \"");
			    		argBuffer.append(sUser);
			    		argBuffer.append("\"");
			    		String arguments[] = new String[1];
			    		arguments[0] = argBuffer.toString();
			    		emxUtil_mxJPO utilityClass = new emxUtil_mxJPO(context, null);
			    		utilityClass.executeMQLCommands(context, arguments);
						
						//
						
					}
				   
					
					// ===
					String checkPartFamilyLev3 = "";
				    if(checkSpecialSymbolsTempsPFlev3){
//					   checkPartFamilyLev2 = "temp query bus 'Part Family' \""+sTempPartFamilyNameLev2 +"\"  \"*\"  select name dump |  ";
				    	checkPartFamilyLev3 = "temp query bus 'Part Family' \"*\"  \"*\" where \"attribute[cdmPartFamilyBlockCodeName] ~= '"+sTempsPFlev3+"'\"  select attribute[cdmPartFamilyBlockCodeName] dump |  ";
				    }else{
//				    	checkPartFamilyLev2 = "temp query bus 'Part Family' \""+sPartFamilyNameLev2 +"\"  \"*\"  select name dump |  ";
				    	checkPartFamilyLev3 = "temp query bus 'Part Family' \"*\"  \"*\" where \"attribute[cdmPartFamilyBlockCodeName] == '"+sPFlev3+"'\"  select attribute[cdmPartFamilyBlockCodeName] dump |  ";
				    }
				   String checkPartFamilyLev3Result = MqlUtil.mqlCommand(context, checkPartFamilyLev3);
				   
				   StringList sListCheckPartFamilyLev3Result = new StringList();
				   sListCheckPartFamilyLev3Result = FrameworkUtil.split(checkPartFamilyLev3Result, "|");
				   boolean bExistPartFamilyLev3Result = false;
				   
				   if (sListCheckPartFamilyLev3Result.size()>2 && checkSpecialSymbolsTempsPFlev3) {
					   StringList sListCheckSpecialSymbolPartFamilyLev3Result = new StringList();   
					   sListCheckSpecialSymbolPartFamilyLev3Result = FrameworkUtil.split(checkPartFamilyLev3Result, "\n");
						for (Iterator iterSpecialLev3Symbol = sListCheckSpecialSymbolPartFamilyLev3Result.iterator(); iterSpecialLev3Symbol.hasNext();) {
							String sSpecialSymbolPartFamilyLev3Result = (String) iterSpecialLev3Symbol.next();
							StringList sListSpecialSymbolPartFamilyLev3Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev3Result, "|");
							String tempPartFamily3Name = (String) sListSpecialSymbolPartFamilyLev3Result.get(3);
							if (cdmStringUtil.isNotEmpty(tempPartFamily3Name) && tempPartFamily3Name.equals(sPFlev3)) {
								bExistPartFamilyLev3Result = true;
							}

						}
					   
				   }
					
					// ==
//				   String checkPartFamilyLev3 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \""+sPartFamilyNameLev3 +"\"  \"*\"  select id dump |  ";
//				   String checkPartFamilyLev3 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \"*\"  \"*\" where \"attribute[cdmPartFamilyBlockCodeName] == '"+sPFlev3+"'\" select id dump |  ";
//				   String checkPartFamilyLev3Result = MqlUtil.mqlCommand(context, checkPartFamilyLev3);
				   
//					if (cdmStringUtil.isEmpty(checkPartFamilyLev3Result) ) {
				   if (sListCheckPartFamilyLev3Result.size()<2 || (!bExistPartFamilyLev3Result &&checkSpecialSymbolsTempsPFlev3)) {
//						PartFamily partFamilyLev3 = new PartFamily();
//						partFamilyLev3.createPartFamily(context, S_TYPE_PART_FAMILY, sPartFamilyNameLev3, null, S_POLICY_CLASSIFICATION, "eService Production");
						
						com.matrixone.apps.library.PartFamily partFamilyLev3 = new com.matrixone.apps.library.PartFamily();
//						partFamilyLev3.createObject(context, S_TYPE_PART_FAMILY, sPartFamilyNameLev3, null, S_POLICY_CLASSIFICATION, "eService Production");
						String sAutoNamePFlev3 = DomainObject.getAutoGeneratedName(context, "type_PartFamily", "");
						partFamilyLev3.createObject(context, S_TYPE_PART_FAMILY, sAutoNamePFlev3, null, S_POLICY_CLASSIFICATION, "eService Production");
						
						partFamilyLev3.setAttributeValue(context, "cdmDescription", sBlockCodeName);
						partFamilyLev3.setAttributeValue(context, "cdmPartFamilyBlockCodeName", sPFlev3);
						partFamilyLev3.setAttributeValue(context, S_ATTRIBUTE_MIGRATION_CHECK, "Y");
						
						String sPartFamilyIdLev3 = partFamilyLev3.getId(context);
						
						//
						String strParentType="";
				    	String strClassName="";
				    	String strClassType="";
				    	
			            DomainObject domainObj = new DomainObject();
			            domainObj.setId(sPartFamilyIdLev3);
			            strClassType  =  domainObj.getInfo(context,DomainObject.SELECT_TYPE);
			            BusinessType busType = new BusinessType(strClassType,context.getVault());
			            strParentType= busType.getParent(context);
			            strClassName  =  domainObj.getInfo(context,DomainObject.SELECT_NAME);
			            java.util.Date sysDate = new Date();
			            long lTime = sysDate.getTime();
			            String strInterfaceName = domainObj.getInfo(context, "physicalid");
			            try{
			                String strMQL       =  "add interface $1 type all";
			                ContextUtil.pushContext(context);

			                MqlUtil.mqlCommand(context, strMQL, strInterfaceName);

			                strMQL      = "modify bus $1 $2 $3";
			                MqlUtil.mqlCommand(context, strMQL, sPartFamilyIdLev3,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE, strInterfaceName);

			                if(strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_LIBRARIES))
			                {
			                    strMQL      = "modify interface $1 derived $2";
			                    MqlUtil.mqlCommand(context, strMQL, strInterfaceName,LibraryCentralConstants.INTERFACE_CLASSIFICATION_TAXONOMIES);
			                }

						}catch(Exception e)
						{
							e.printStackTrace();
							throw e;
						}finally{
							ContextUtil.popContext(context);
						}
			            try{
			    			Map argsHash = new HashMap();
			    			String[] tempArg = JPO.packArgs(argsHash);
			    			String mqlString="list program $1";
			    			String output=MqlUtil.mqlCommand(context, mqlString,"emxPLMDictionaryProgram");
			    			if(UIUtil.isNotNullAndNotEmpty(output)){
			    				JPO.invoke(context, "emxPLMDictionaryProgram", null, "invalidateCache", tempArg,Integer.class);
			    			}
			    		}catch (MatrixException e) {
			    			throw e;
			    		}
			            
			            
			    		String attOriginator = "Originator";
			    		String sUser = context.getUser();
			            StringBuffer argBuffer = new StringBuffer(100);
			            argBuffer.append("modify bus ");
			    		argBuffer.append(sPartFamilyIdLev3);
			    		argBuffer.append(" \"");
			    		argBuffer.append(attOriginator);
			    		argBuffer.append("\" \"");
			    		argBuffer.append(sUser);
			    		argBuffer.append("\"");
			    		String arguments[] = new String[1];
			    		arguments[0] = argBuffer.toString();
			    		emxUtil_mxJPO utilityClass = new emxUtil_mxJPO(context, null);
			    		utilityClass.executeMQLCommands(context, arguments);
						
						//
						
					}
				   ContextUtil.commitTransaction(context);
				   
				   successRowCount++;
				   multiWriteMessageToFile(successObjectidWriter,sRowNum+"\t"+sCompany +"\t"+sProductCode+"\t"+sProductCodeName+"\t"+sBlockCode+"\t"+sBlockCodeName  );
				   checkTriggerOff = false;
				   MqlUtil.mqlCommand(context, "Trigger On");
				}catch(Exception e1){
					failRowCount++;
					ContextUtil.abortTransaction(context);
					mulitWriteErrorToFile( errorStream," LINE NUMBER: "+sRowNum+"\t"+sRecordProductCodeName +"\t"+sRecordBlockCode +"\t"+ sRecordBlockCodeName+"\t" + e1.getMessage());
					multiWriteMessageToFile(logWriter,sRowNum+"\t"+sRecordProductCode +"\t"+sRecordProductCodeName +"\t"+sRecordBlockCode +"\t"+ sRecordBlockCodeName+"\t" + e1.getMessage());
					e1.printStackTrace(errorStream);
					
					multiWriteMessageToFile(failedObjectidWriter, sRowNum+"\t"+sRecordCompany+"\t"+sRecordProductCode +"\t"+sRecordProductCodeName +"\t"+sRecordBlockCode +"\t"+ sRecordBlockCodeName);
				}finally{
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "Trigger On");
						checkTriggerOff = false;
					}
				}
				
			
			}
			multiWriteMessageToFile(logWriter,"======================================================================================================================");
			multiWriteMessageToFile(logWriter,"	File CREATE PARTFAMILY OBJECT Migration COMPLETED.                    ");
			multiWriteMessageToFile(logWriter,"======================================================================================================================\n");

		} catch (Exception e) {
			e.printStackTrace(errorStream);
			
		}finally{
			multiWriteMessageToFile(logWriter,"======================================================================================================================");
			multiWriteMessageToFile(logWriter,"	CREATE PARTFAMILY OBJECT CLOSE TIME:  "+getTimeStamp()+"          \n"  );
			multiWriteMessageToFile(logWriter,"	CREATE PARTFAMILY OBJECT MIGRATION LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms        "  );
			multiWriteMessageToFile(logWriter,"	SUCCESS ROW: ("+ successRowCount+") FAIL ROW:("+failRowCount+") TOTAL ROW: ("+totalRowCount +")               "  );
			multiWriteMessageToFile(logWriter,"======================================================================================================================\n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			MqlUtil.mqlCommand(context, "history on");
			System.out.println(" cdmAttributeGroupMigration_mxJPO : createPatFamilyForBlockCode() finish "+getTimeStamp());
		}
	}
	
	
//	/**
//	 * Part Family Connect
//	 * 
//	 * @param context
//	 * @param args
//	 * @throws Exception
//	 */
//	public void connectPartFamily(Context context,String args[])throws Exception{
//		long startTime = System.currentTimeMillis();
//		System.out.println("${CLASSNAME} : connectPartFamily -start"+getTimeStamp());
//		
//		String inputDirectory 			     = "";
//		String outputDirectory 			     = "";
//		String fileName 		       	     = "";
//		
//		PrintStream errorStream		         = null; 
//		File successLogFile 				 = null; 
//		File failedLogFile 				     = null;
//		
//		BufferedWriter logWriter 			 = null; 
//		BufferedWriter successObjectidWriter = null; 
//		BufferedWriter failedObjectidWriter  = null; 
//		
//		String logFileName = "connectPartFamily";
//		
//		String sheetName   = "";
//		String tempPartFamilyExcelPath = "";
//		String tempPartFamilyExcelName = "";
//		String tempOutputDir = "";
////		String[] sTempArgs = {"C:\\temp\\Import_File\\PART_FAMILY","20160819_Block code List_20160203.xls"};
////		String[] sTempArgs = {S_PART_FAMILY_EXCEL_PATH,S_PART_FAMILY_EXCEL_NAME};
//		Properties prop = new Properties();
//		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
//		tempPartFamilyExcelPath 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("PART_FAMILY_EXCEL_PATH"));
//		tempPartFamilyExcelName 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("PART_FAMILY_EXCEL_NAME"));
//		tempOutputDir 						= cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
//		
//		if (cdmStringUtil.isEmpty(tempPartFamilyExcelPath) || cdmStringUtil.isEmpty(tempPartFamilyExcelName) || cdmStringUtil.isEmpty(tempOutputDir)) {
//			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//		}
//		
//		inputDirectory = tempPartFamilyExcelPath;
//		fileName 	   = tempPartFamilyExcelName;
//		
//		// documentDirectory does not ends with "/" add it
//		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
//			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
//		}
//		// create a directory to add debug and error logs
//		outputDirectory = new File(inputDirectory).getParentFile().getParent() + S_FILE_SEPARATOR + tempOutputDir + S_FILE_SEPARATOR + logFileName + "_" + getTimeStamp() + S_FILE_SEPARATOR;
//		File fileOutputDirectory = new File(outputDirectory);
//		if (!fileOutputDirectory.isDirectory()) {
//			fileOutputDirectory.mkdirs();
//		}
//		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
//		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));
//
//		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
//		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));
//
//		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
//		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
//		
//		String sRowNum = "";
//		int successCount 	= 0;
//		int failCount 		= 0;
//		int totalCount 		= 0;
//		multiWriteMessageToFile(logWriter,"====================================================================================");
//		multiWriteMessageToFile(logWriter,"	CONNECT PARTFAMILY OBJECT AND PARTFAMILY OBJECT  "+ getTimeStamp()+" \n");
//		multiWriteMessageToFile(logWriter,"	Reading input log file from : "+inputDirectory);
//		multiWriteMessageToFile(logWriter,"	Writing Log files to: " + outputDirectory );
//		multiWriteMessageToFile(logWriter,"====================================================================================\n");
//		try {
//
//			Sheet sheet = (Sheet) cdmCommonExcel.getXssfSheet2(context, inputDirectory+fileName, sheetName);
//			int sheetPhysicalNumberRows = sheet.getPhysicalNumberOfRows();
//			totalCount = sheetPhysicalNumberRows-1;
//			/* Part Library id search*/
//			String sPartLibraryName = "Block_Code";
//			StringList sPLQueryResultList = null;
//			String sPLQuery = "temp query bus \"Part Library\" * *  where \" name=='" + sPartLibraryName + "' \"  select id dump |";
//			String mqlResult= MqlUtil.mqlCommand(context,  sPLQuery);
//			sPLQueryResultList = FrameworkUtil.split(mqlResult, "|");
//			String sPLId= (String)sPLQueryResultList.get(3);
//			for (int i = 1; i < sheetPhysicalNumberRows; i++) {
//				boolean checkTriggeroff = false; 
//				Row sheetRow = sheet.getRow(i);
//				try {
//					
//					sRowNum = String.valueOf(i+1);
//					if (sheetRow == null){
//						String errorMessage = "NOT EXIST DATA (ROW NULL)";
//						throw new Exception(errorMessage);	
//					}
//		
////					Cell cell_0 = sheetRow.getCell(0);
//					Cell cell_1 = sheetRow.getCell(1);
//					Cell cell_2 = sheetRow.getCell(2);
//					Cell cell_3 = sheetRow.getCell(3);
//					Cell cell_4 = sheetRow.getCell(4);
//					Cell cell_5 = sheetRow.getCell(5);
//
////					String sNumber       	= getCellValue(cell_0);
//					String sCompany 	 	= getCellValue2(cell_1);
//					String sProductCode 	= getCellValue2(cell_2);
//					String sProductCodeName = getCellValue2(cell_3);
//					String sBlockCode 		= getCellValue2(cell_4);
//					String sBlockCodeName 	= getCellValue2(cell_5);
//
////					sNumber 			= isVaildNullData(sNumber);
//					sCompany 			= isVaildNullData(sCompany);
//					sProductCode 		= isVaildNullData(sProductCode);
//					sProductCodeName 	= isVaildNullData(sProductCodeName);
//					sBlockCode 			= isVaildNullData(sBlockCode);
//					sBlockCodeName 		= isVaildNullData(sBlockCodeName);
//
//					String sPartFamilyNameLev1 = sCompany;
//					String sPartFamilyNameLev2 = sProductCode + ":" + sProductCodeName ;
//					String sPartFamilyNameLev3 = sProductCode + sBlockCode + ":" + sBlockCodeName ;
//
//					 if(!"Global R&D".equals(sCompany)){
//						   String errorMessage = "IT IS NOT A MIGRATION TARGET.";
//						   throw new Exception(errorMessage);
//					}
//					 
//					String sTempPartFamilyNameLev2 = "";
//					boolean checkSpecialSymbolPartFamilyNameLev2 = false; 
//					
//					if (sPartFamilyNameLev2.contains(",")) {
//						sTempPartFamilyNameLev2 = sPartFamilyNameLev2.replaceAll(",", "?");
//						checkSpecialSymbolPartFamilyNameLev2 = true;
//					}
//					if (sPartFamilyNameLev2.contains("'")) {
//						sTempPartFamilyNameLev2 = sPartFamilyNameLev2.replaceAll("'", "?");
//						checkSpecialSymbolPartFamilyNameLev2 = true;
//					}
//					
//					String sTempsPFlev3 = "";
//					boolean checkSpecialSymbolsTempsPFlev3 = false;  
//					if(sPartFamilyNameLev3.contains(",") ){
//					   sTempsPFlev3 = sPartFamilyNameLev3.replaceAll(",", "?");
//					   checkSpecialSymbolsTempsPFlev3 = true;
//					}
//					
//					if(sPartFamilyNameLev3.contains("'") ){
//					   sTempsPFlev3 = sPartFamilyNameLev3.replaceAll("'", "?");
//					   checkSpecialSymbolsTempsPFlev3 = true;
//					}
//					//
//					
//					DomainObject childLev1Obj = new DomainObject();
//					DomainObject childLev2Obj = new DomainObject();
//					DomainObject childLev3Obj = new DomainObject();
//					
//					
//					
////					String checkRelationshipLev1 = "temp query bus 'Part Family' \"" + sPartFamilyNameLev1 + "\"  *  where to[Subclass]==False select id dump |";
//					String checkRelationshipLev1 = "temp query bus 'Part Family' \"*\"  \"*\"  where \" attribute[cdmPartFamilyBlockCodeName] == '"+sPartFamilyNameLev1+"' && to[Subclass] == 'False' \" select id dump |";
//					String checkRealtionshipLev1Result = MqlUtil.mqlCommand(context, checkRelationshipLev1);
//					MqlUtil.mqlCommand(context, "Trigger Off");
//					checkTriggeroff = true;
////					ContextUtil.startTransaction(context, true);
//					if (cdmStringUtil.isNotEmpty(checkRealtionshipLev1Result)) {	
//						String sCheckRealtionshipLev1Result = "";
//						StringList stListCheckRealtionshipLev1Result = FrameworkUtil.split(checkRealtionshipLev1Result, "|");
//						sCheckRealtionshipLev1Result = (String) stListCheckRealtionshipLev1Result.get(3);
//
//						if (cdmStringUtil.isNotEmpty(sCheckRealtionshipLev1Result)) {
//							DomainRelationship connectRel = null;
//							DomainObject partLibraryObj = new DomainObject(sPLId);
//							childLev1Obj.setId(sCheckRealtionshipLev1Result);
//							connectRel = DomainRelationship.connect(context, partLibraryObj, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), childLev1Obj);
//							
//							//trigger start
//							//
//							String[] constructor = {null};
//							String parentObjectId =sPLId; //from 
//					        String childObjectId = sCheckRealtionshipLev1Result;  //to 
//					        Map aMap = new HashMap();
//					        aMap.put ("objectId", parentObjectId);
//					        aMap.put ("relationship", LibraryCentralConstants.RELATIONSHIP_SUBCLASS); //rel
//					        String objectName=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_NAME);
//					        String objectRevision=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_REVISION);
//					        String parentPhysicalId=LibraryCentralCommon.getPhysicalIdforObject(context,parentObjectId);
//					        if(!(objectRevision.equals(parentPhysicalId))){
////					            
//					        	  String mqlQuery="modify bus $1 revision $2 name $3 ";
//					              ContextUtil.pushContext(context);
//					              MqlUtil.mqlCommand(context, mqlQuery, childObjectId,parentPhysicalId,objectName);
//					              ContextUtil.popContext(context);
//					        }
//							//
//					        
//					        //
//
//				            String strFromObjectId = sPLId;
//				            String strToObjectId = sCheckRealtionshipLev1Result;
//				            DomainObject childObj = new DomainObject(strToObjectId);
//				            DomainObject parentObj = new DomainObject(strFromObjectId);
//				            String strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//				            String strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//
//
//				            // This block is to check whether the parent object, which the classification object is added with Subclass Relationship
//				            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
//				            // with the object.  The Classifications(Part Family) created to prior to the installation will not have any interfaces associated
//				            // With them.
//				            if(strParentInterface == null || "".equals(strParentInterface) || "null".equals(strParentInterface)) {
//				                try {
//				                    if(createInterfaceObject(context, strFromObjectId) == 0) {
//				                        strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//				                        //If this object is type of LIBRARIES, it will have interface, and will not come into this block.
//				                        //If this object is type of PartFamily and it is created without Library Central installed, that will fall into this block
//				                        //that is why inheriting this interface with INTERFACE_CLASSIFICATION_ORPHANS
//				                        String cmd = "modify interface $1 derived $2";
//				                        MqlUtil.mqlCommand(context, cmd, true, strParentInterface, LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
//
//				                        //Get all classified items connected to it and implement the interface on all classified items
//				                        SelectList selectStmts = new SelectList(1);
//				                        selectStmts.addElement(DomainObject.SELECT_ID);
//				                        MapList result = new MapList();
//				                        result = (MapList)parentObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
//				                        int iSize = result.size();
//				                        Map tempMap;
//				                        String strObjectId;
//				                        for (int k=0;k<iSize;k++ )
//				                        {
//				                            implementInterfaceOnClassifiedItem(context, strFromObjectId, ((String)((Map)result.get(k)).get("id")));
//
//				                        }
//
//				                    }
//				                } catch(Exception ex) {
//				                    throw ex;
//				                }
//				            }
//				            // This block is to check whether the classification object,
//				            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
//				            // with the object.  The Classifications(Part Family) created to prior to the installation of Library Central or created in
//				            // previous versions will not have any interfaces associated with them.
//				            if(strChildInterface == null || "".equals(strChildInterface) || "null".equals(strChildInterface)) {
//				                try {
//				                    if(createInterfaceObject(context, strToObjectId) == 0) {
//				                        strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//
//				                        //Get all classified items connected to it and implement the interface on all classified items
//				                        SelectList selectStmts = new SelectList(1);
//				                        selectStmts.addElement(DomainObject.SELECT_ID);
//				                        MapList result = new MapList();
//				                        result = (MapList)childObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
//				                        int iSize = result.size();
//				                        for (int k=0;k<iSize;k++ )
//				                        {
//				                            implementInterfaceOnClassifiedItem(context, strToObjectId, ((String)((Map)result.get(k)).get("id")));
//				                        }
//
//				                    }
//				                } catch(Exception ex) {
//				                    throw ex;
//				                }
//				            }
//
//
//				            try{
//				                // The approach here is as follows:
//				                // Get everything that the child's interface is derived from
//				                // directly; To that list, add the new parent's interface;
//				                // remove mxsysLCOrphans.
//				                // The resulting set is what child's interface will be derived from.
//				                // This may seem over-complicated, but it is necessary in
//				                // conjunction with the optional Multiple Classification Module in
//				                // order to avoid attribute data loss.
//				                String cmd = "print interface $1 select derived dump $2";
//				                String currentParentsCSL = MqlUtil.mqlCommand(context,cmd,true, strChildInterface, ",").trim();
//
//				                StringList currentParentsList = FrameworkUtil.split(currentParentsCSL, ",");
//				                currentParentsList.addElement(strParentInterface);
//				                currentParentsList.remove(LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
//				                String[] parentInterfaces   = new String[currentParentsList.size()+1];
//				                parentInterfaces[0]         = strChildInterface;
//				                StringBuffer sbQuery        = new StringBuffer("modify interface $1 derived");
//				                for (int j = 0 ; j < currentParentsList.size() ; j++) {
//				                    sbQuery.append(" $").append(j+2).append(",");
//				                    parentInterfaces[j+1] = (String)currentParentsList.get(j);
//				                }
//				                cmd = sbQuery.substring(0, sbQuery.lastIndexOf(","));
//
//				                String result = MqlUtil.mqlCommand(context, cmd, true, parentInterfaces);
//
//
//				            }catch(Exception e)
//				            {
//				                e.printStackTrace();
//				                throw e;
//				            }
//
//				            
//				            String connectTclProg =  "emxUpdateCountOnSubclassConnectDisconnect.tcl";
//				            String updateCountConnection = "execute program \""+connectTclProg+"\"  \"" +sCheckRealtionshipLev1Result + "\" " +  "\"" +sPLId+ "\"";
//				            MQLCommand mqlcommand = new MQLCommand();
//							mqlcommand.open(context);
//					        mqlcommand.executeCommand(context, updateCountConnection);
//							String sResult = mqlcommand.getResult();
//							String sError = mqlcommand.getError();
//							mqlcommand.close(context);
//				            //
//							//trigger end
//						}
//
//					}
//					String checkRelationshipLev2 = "";
//					boolean checkSpecialSymbolRelationshipLev2 = false;
//					if(checkSpecialSymbolPartFamilyNameLev2){
////						checkRelationshipLev2 = "temp query bus 'Part Family' \"" + sTempPartFamilyNameLev2 + "\"  *  where to[Subclass]==False select name id dump |";
//						checkRelationshipLev2 = "temp query bus 'Part Family' \"*\"  *  where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+ sTempPartFamilyNameLev2+"' && to[Subclass] == 'False' \" select attribute[cdmPartFamilyBlockCodeName] id dump |";
//					}else{
////						 checkRelationshipLev2 = "temp query bus 'Part Family' \"" + sPartFamilyNameLev2 + "\"  *  where to[Subclass]==False select name id dump |";
//						 checkRelationshipLev2 = "temp query bus 'Part Family' *   *  where \" attribute[cdmPartFamilyBlockCodeName] == '"+ sPartFamilyNameLev2+"' &&  to[Subclass] == 'False' \" select attribute[cdmPartFamilyBlockCodeName] id dump |";
//						
//					}
//					// String checkRelationshipLev2 = "temp query bus 'Part Family' * * where to[Subclass]==False && name == '"+sPartFamilyNameLev2+"' select id dump |";
//					String checkRealtionshipLev2Result = MqlUtil.mqlCommand(context, checkRelationshipLev2);
//
//					//
//					String tempPartFamily2Id = "";
//					StringList sListCheckRealtionshipLev2Result = new StringList();
//					sListCheckRealtionshipLev2Result = FrameworkUtil.split(checkRealtionshipLev2Result, "|");
//					  
//					if (sListCheckRealtionshipLev2Result.size()>2 && checkSpecialSymbolPartFamilyNameLev2) {
//						
//						StringList sListCheckSpecialSymbolPartFamilyLev2Result = new StringList();   
//						sListCheckSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(checkRealtionshipLev2Result, "\n");
//						for (Iterator iterSpecialSymbol = sListCheckSpecialSymbolPartFamilyLev2Result.iterator(); iterSpecialSymbol.hasNext();) {
//							String sSpecialSymbolPartFamilyLev2Result = (String) iterSpecialSymbol.next();
//							StringList sListSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev2Result, "|");
//							String tempPartFamily2Attr = (String) sListSpecialSymbolPartFamilyLev2Result.get(3);
//							if (cdmStringUtil.isNotEmpty(tempPartFamily2Attr) && tempPartFamily2Attr.equals(sPartFamilyNameLev2)) {
//								checkSpecialSymbolRelationshipLev2 = true;
//								tempPartFamily2Id = (String) sListSpecialSymbolPartFamilyLev2Result.get(4);
//								break;
//							}
//
//						}
//					   
//					}
//					//
//					
//					if (cdmStringUtil.isNotEmpty(checkRealtionshipLev2Result) || (checkSpecialSymbolRelationshipLev2 && checkSpecialSymbolPartFamilyNameLev2)) {
//						String sCheckRealtionshipLev2Result = "";
//						StringList stListCheckRealtionshipLev2Result = FrameworkUtil.split(checkRealtionshipLev2Result, "|");
//						sCheckRealtionshipLev2Result = (String) stListCheckRealtionshipLev2Result.get(4);
//						
//						if((checkSpecialSymbolRelationshipLev2 && checkSpecialSymbolPartFamilyNameLev2)){
//							sCheckRealtionshipLev2Result = tempPartFamily2Id;
//						}
//						DomainRelationship connectRel = null;
//						String sLev1PartFamilyId = "";
////						String sLev1PartFamilyInfoMql = "temp query bus 'Part Family' \"" + sPartFamilyNameLev1 + "\"  *  select id dump |";
//						String sLev1PartFamilyInfoMql = "temp query bus 'Part Family' *  *  where \" attribute[cdmPartFamilyBlockCodeName]=='"+sPartFamilyNameLev1+"' \" select id dump |";
//						String sLev1PartFamilyInfoMqlResult = MqlUtil.mqlCommand(context, sLev1PartFamilyInfoMql);
//						StringList stListLev1PartFamilyInfoMqlResult = FrameworkUtil.split(sLev1PartFamilyInfoMqlResult, "|");
//						sLev1PartFamilyId = (String) stListLev1PartFamilyInfoMqlResult.get(3);
//
//						DomainObject partFamilyLev1Obj = new DomainObject();
//						partFamilyLev1Obj.setId(sLev1PartFamilyId);
//						childLev2Obj.setId(sCheckRealtionshipLev2Result);
//						
//						connectRel = DomainRelationship.connect(context, partFamilyLev1Obj, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), childLev2Obj);
//						
//						
//						//trigger start
//						//
//						String[] constructor = {null};
//						String parentObjectId = sLev1PartFamilyId; //from 
//				        String childObjectId = sCheckRealtionshipLev2Result;  //to 
//				        Map aMap = new HashMap();
//				        aMap.put ("objectId", parentObjectId);
//				        aMap.put ("relationship", LibraryCentralConstants.RELATIONSHIP_SUBCLASS); //rel
//				        String objectName=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_NAME);
//				        String objectRevision=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_REVISION);
//				        String parentPhysicalId=LibraryCentralCommon.getPhysicalIdforObject(context,parentObjectId);
//				        if(!(objectRevision.equals(parentPhysicalId))){
////				            
//				        	  String mqlQuery="modify bus $1 revision $2 name $3 ";
//				              ContextUtil.pushContext(context);
//				              MqlUtil.mqlCommand(context, mqlQuery, childObjectId,parentPhysicalId,objectName);
//				              ContextUtil.popContext(context);
//				        }
//						//
//				        
//				        //
//
//			            String strFromObjectId = sLev1PartFamilyId;
//			            String strToObjectId = sCheckRealtionshipLev2Result;
//			            DomainObject childObj = new DomainObject(strToObjectId);
//			            DomainObject parentObj = new DomainObject(strFromObjectId);
//			            String strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//			            String strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//
//
//			            // This block is to check whether the parent object, which the classification object is added with Subclass Relationship
//			            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
//			            // with the object.  The Classifications(Part Family) created to prior to the installation will not have any interfaces associated
//			            // With them.
//			            if(strParentInterface == null || "".equals(strParentInterface) || "null".equals(strParentInterface)) {
//			                try {
//			                    if(createInterfaceObject(context, strFromObjectId) == 0) {
//			                        strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//			                        //If this object is type of LIBRARIES, it will have interface, and will not come into this block.
//			                        //If this object is type of PartFamily and it is created without Library Central installed, that will fall into this block
//			                        //that is why inheriting this interface with INTERFACE_CLASSIFICATION_ORPHANS
//			                        String cmd = "modify interface $1 derived $2";
//			                        MqlUtil.mqlCommand(context, cmd, true, strParentInterface, LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
//
//			                        //Get all classified items connected to it and implement the interface on all classified items
//			                        SelectList selectStmts = new SelectList(1);
//			                        selectStmts.addElement(DomainObject.SELECT_ID);
//			                        MapList result = new MapList();
//			                        result = (MapList)parentObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
//			                        int iSize = result.size();
//			                        Map tempMap;
//			                        String strObjectId;
//			                        for (int k=0;k<iSize;k++ )
//			                        {
//			                            implementInterfaceOnClassifiedItem(context, strFromObjectId, ((String)((Map)result.get(k)).get("id")));
//
//			                        }
//
//			                    }
//			                } catch(Exception ex) {
//			                    throw ex;
//			                }
//			            }
//			            // This block is to check whether the classification object,
//			            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
//			            // with the object.  The Classifications(Part Family) created to prior to the installation of Library Central or created in
//			            // previous versions will not have any interfaces associated with them.
//			            if(strChildInterface == null || "".equals(strChildInterface) || "null".equals(strChildInterface)) {
//			                try {
//			                    if(createInterfaceObject(context, strToObjectId) == 0) {
//			                        strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//
//			                        //Get all classified items connected to it and implement the interface on all classified items
//			                        SelectList selectStmts = new SelectList(1);
//			                        selectStmts.addElement(DomainObject.SELECT_ID);
//			                        MapList result = new MapList();
//			                        result = (MapList)childObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
//			                        int iSize = result.size();
//			                        for (int k=0;k<iSize;k++ )
//			                        {
//			                            implementInterfaceOnClassifiedItem(context, strToObjectId, ((String)((Map)result.get(k)).get("id")));
//			                        }
//
//			                    }
//			                } catch(Exception ex) {
//			                    throw ex;
//			                }
//			            }
//
//
//			            try{
//			                // The approach here is as follows:
//			                // Get everything that the child's interface is derived from
//			                // directly; To that list, add the new parent's interface;
//			                // remove mxsysLCOrphans.
//			                // The resulting set is what child's interface will be derived from.
//			                // This may seem over-complicated, but it is necessary in
//			                // conjunction with the optional Multiple Classification Module in
//			                // order to avoid attribute data loss.
//			                String cmd = "print interface $1 select derived dump $2";
//			                String currentParentsCSL = MqlUtil.mqlCommand(context,cmd,true, strChildInterface, ",").trim();
//
//			                StringList currentParentsList = FrameworkUtil.split(currentParentsCSL, ",");
//			                currentParentsList.addElement(strParentInterface);
//			                currentParentsList.remove(LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
//			                String[] parentInterfaces   = new String[currentParentsList.size()+1];
//			                parentInterfaces[0]         = strChildInterface;
//			                StringBuffer sbQuery        = new StringBuffer("modify interface $1 derived");
//			                for (int j = 0 ; j < currentParentsList.size() ; j++) {
//			                    sbQuery.append(" $").append(j+2).append(",");
//			                    parentInterfaces[j+1] = (String)currentParentsList.get(j);
//			                }
//			                cmd = sbQuery.substring(0, sbQuery.lastIndexOf(","));
//
//			                String result = MqlUtil.mqlCommand(context, cmd, true, parentInterfaces);
//
//
//			            }catch(Exception e)
//			            {
//			                e.printStackTrace();
//			                throw e;
//			            }
//
//			            
//			            String connectTclProg =  "emxUpdateCountOnSubclassConnectDisconnect.tcl";
//			            String updateCountConnection = "execute program \""+connectTclProg+"\"  \"" +sCheckRealtionshipLev2Result + "\" " +  "\"" +sLev1PartFamilyId+ "\"";
//			            MQLCommand mqlcommand = new MQLCommand();
//						mqlcommand.open(context);
//				        mqlcommand.executeCommand(context, updateCountConnection);
//						String sResult = mqlcommand.getResult();
//						String sError = mqlcommand.getError();
//						mqlcommand.close(context);
//			            //
//						//trigger end
//					}
//
//					// ==
//					String checkRelationshipLev3 = "";
//					boolean checkSpecialSymbolRelationshipLev3 = false;
//					if(checkSpecialSymbolsTempsPFlev3){
////						checkRelationshipLev2 = "temp query bus 'Part Family' \"" + sTempPartFamilyNameLev2 + "\"  *  where to[Subclass]==False select name id dump |";
//						checkRelationshipLev3 = "temp query bus 'Part Family' \"*\"  *  where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+ sTempsPFlev3+"' && to[Subclass] == 'False' \" select attribute[cdmPartFamilyBlockCodeName] id dump |";
//					}else{
////						 checkRelationshipLev2 = "temp query bus 'Part Family' \"" + sPartFamilyNameLev2 + "\"  *  where to[Subclass]==False select name id dump |";
//						checkRelationshipLev3 = "temp query bus 'Part Family' *   *  where \" attribute[cdmPartFamilyBlockCodeName] == '"+ sPartFamilyNameLev3+"' &&  to[Subclass] == 'False' \" select attribute[cdmPartFamilyBlockCodeName] id dump |";
//						
//					}
//					// String checkRelationshipLev2 = "temp query bus 'Part Family' * * where to[Subclass]==False && name == '"+sPartFamilyNameLev2+"' select id dump |";
//					String checkRealtionshipLev3Result = MqlUtil.mqlCommand(context, checkRelationshipLev3);
//
//					//
//					String tempPartFamily3Id = "";
//					StringList sListCheckRealtionshipLev3Result = new StringList();
//					sListCheckRealtionshipLev3Result = FrameworkUtil.split(checkRealtionshipLev3Result, "|");
//					  
//					if (sListCheckRealtionshipLev3Result.size()>2 && checkSpecialSymbolsTempsPFlev3) {
//						
//						StringList sListCheckSpecialSymbolPartFamilyLev3Result = new StringList();   
//						sListCheckSpecialSymbolPartFamilyLev3Result = FrameworkUtil.split(checkRealtionshipLev3Result, "\n");
//						for (Iterator iterSpecialLev3Symbol = sListCheckSpecialSymbolPartFamilyLev3Result.iterator(); iterSpecialLev3Symbol.hasNext();) {
//							String sSpecialSymbolPartFamilyLev3Result = (String) iterSpecialLev3Symbol.next();
//							StringList sListSpecialSymbolPartFamilyLev3Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev3Result, "|");
//							String tempPartFamily3Attr = (String) sListSpecialSymbolPartFamilyLev3Result.get(3);
//							if (cdmStringUtil.isNotEmpty(tempPartFamily3Attr) && tempPartFamily3Attr.equals(sPartFamilyNameLev3)) {
//								checkSpecialSymbolRelationshipLev3 = true;
//								tempPartFamily3Id = (String) sListSpecialSymbolPartFamilyLev3Result.get(4);
//								break;
//							}
//
//						}
//					   
//					}else{
//						if(sListCheckRealtionshipLev3Result.size()>2 ){
//							tempPartFamily3Id = (String) sListCheckRealtionshipLev3Result.get(4);
//						}
//					}
//					//
//					
//					// ==
////					String checkRelationshipLev3 = "temp query bus 'Part Family' \"" + sPartFamilyNameLev3 + "\"  *  where to[Subclass]==False select id dump |";
////					String checkRealtionshipLev3Result = MqlUtil.mqlCommand(context, checkRelationshipLev3);
////					if (cdmStringUtil.isNotEmpty(checkRealtionshipLev3Result)) {
//
//					if (cdmStringUtil.isNotEmpty(checkRealtionshipLev3Result) || (checkSpecialSymbolRelationshipLev3 && checkSpecialSymbolsTempsPFlev3)) {
//						String sCheckRealtionshipLev3Result = "";
//						StringList stListCheckRealtionshipLev3Result = FrameworkUtil.split(checkRealtionshipLev3Result, "|");
//						sCheckRealtionshipLev3Result = (String) stListCheckRealtionshipLev3Result.get(4);
//
//						DomainRelationship connectRel = null;
//						String sLev2PartFamilyId = "";
//						String sLev2PartFamilyInfoMql = "";
//						if(checkSpecialSymbolPartFamilyNameLev2){
////							sLev2PartFamilyInfoMql = "temp query bus 'Part Family' \"" + sTempPartFamilyNameLev2 + "\"  *  select name id dump |";
//							sLev2PartFamilyInfoMql = "temp query bus 'Part Family' *  *  where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+ sTempPartFamilyNameLev2+"' \" select  attribute[cdmPartFamilyBlockCodeName] id dump |";
//						}else{
////							sLev2PartFamilyInfoMql = "temp query bus 'Part Family' \"" + sPartFamilyNameLev2 + "\"  *  select name id dump |";
//							sLev2PartFamilyInfoMql = "temp query bus 'Part Family' *  * where \" attribute[cdmPartFamilyBlockCodeName] == '"+ sPartFamilyNameLev2+"' \" select  attribute[cdmPartFamilyBlockCodeName] id dump |";
//							
//						}
//						
//						String sLev2PartFamilyInfoMqlResult = MqlUtil.mqlCommand(context, sLev2PartFamilyInfoMql);
//						StringList stListLev2PartFamilyInfoMqlResult = FrameworkUtil.split(sLev2PartFamilyInfoMqlResult, "|");
//						
//						if(checkSpecialSymbolPartFamilyNameLev2){
//							if (stListLev2PartFamilyInfoMqlResult.size()>2 ) {
//								
//								StringList sListCheckSpecialSymbolPartFamilyLev2Result = new StringList();   
//								sListCheckSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(sLev2PartFamilyInfoMqlResult, "\n");
//								for (Iterator iterSpecialSymbol = sListCheckSpecialSymbolPartFamilyLev2Result.iterator(); iterSpecialSymbol.hasNext();) {
//									String sSpecialSymbolPartFamilyLev2Result = (String) iterSpecialSymbol.next();
//									StringList sListSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev2Result, "|");
//									String tempPartFamily2Attr = (String) sListSpecialSymbolPartFamilyLev2Result.get(3);
//									
//									if (cdmStringUtil.isNotEmpty(tempPartFamily2Attr) && tempPartFamily2Attr.equals(sPartFamilyNameLev2)) {
//										checkSpecialSymbolRelationshipLev2 = true;
//										sLev2PartFamilyId = (String) sListSpecialSymbolPartFamilyLev2Result.get(4);
//										break;
//									}
//
//								}
//							
//							}
//						}else{
//							sLev2PartFamilyId = (String) stListLev2PartFamilyInfoMqlResult.get(4);
//						}
//						
//						DomainObject partFamilyLev2Obj = new DomainObject();
//						partFamilyLev2Obj.setId(sLev2PartFamilyId);
//						childLev3Obj.setId(sCheckRealtionshipLev3Result);
//						
//						connectRel = DomainRelationship.connect(context, partFamilyLev2Obj, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), childLev3Obj);
//						
//						
//						//trigger start
//						//
//						String[] constructor = {null};
//						String parentObjectId = sLev2PartFamilyId; //from 
//				        String childObjectId = sCheckRealtionshipLev3Result;  //to 
//				        Map aMap = new HashMap();
//				        aMap.put ("objectId", parentObjectId);
//				        aMap.put ("relationship", LibraryCentralConstants.RELATIONSHIP_SUBCLASS); //rel
//				        String objectName=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_NAME);
//				        String objectRevision=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_REVISION);
//				        String parentPhysicalId=LibraryCentralCommon.getPhysicalIdforObject(context,parentObjectId);
//				        if(!(objectRevision.equals(parentPhysicalId))){
////				            
//				        	  String mqlQuery="modify bus $1 revision $2 name $3 ";
//				              ContextUtil.pushContext(context);
//				              MqlUtil.mqlCommand(context, mqlQuery, childObjectId,parentPhysicalId,objectName);
//				              ContextUtil.popContext(context);
//				        }
//						//
//				        
//				        //
//
//			            String strFromObjectId = sLev2PartFamilyId;
//			            String strToObjectId = sCheckRealtionshipLev3Result;
//			            DomainObject childObj = new DomainObject(strToObjectId);
//			            DomainObject parentObj = new DomainObject(strFromObjectId);
//			            String strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//			            String strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//
//
//			            // This block is to check whether the parent object, which the classification object is added with Subclass Relationship
//			            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
//			            // with the object.  The Classifications(Part Family) created to prior to the installation will not have any interfaces associated
//			            // With them.
//			            if(strParentInterface == null || "".equals(strParentInterface) || "null".equals(strParentInterface)) {
//			                try {
//			                    if(createInterfaceObject(context, strFromObjectId) == 0) {
//			                        strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//			                        //If this object is type of LIBRARIES, it will have interface, and will not come into this block.
//			                        //If this object is type of PartFamily and it is created without Library Central installed, that will fall into this block
//			                        //that is why inheriting this interface with INTERFACE_CLASSIFICATION_ORPHANS
//			                        String cmd = "modify interface $1 derived $2";
//			                        MqlUtil.mqlCommand(context, cmd, true, strParentInterface, LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
//
//			                        //Get all classified items connected to it and implement the interface on all classified items
//			                        SelectList selectStmts = new SelectList(1);
//			                        selectStmts.addElement(DomainObject.SELECT_ID);
//			                        MapList result = new MapList();
//			                        result = (MapList)parentObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
//			                        int iSize = result.size();
//			                        Map tempMap;
//			                        String strObjectId;
//			                        for (int k=0;k<iSize;k++ )
//			                        {
//			                            implementInterfaceOnClassifiedItem(context, strFromObjectId, ((String)((Map)result.get(k)).get("id")));
//
//			                        }
//
//			                    }
//			                } catch(Exception ex) {
//			                    throw ex;
//			                }
//			            }
//			            // This block is to check whether the classification object,
//			            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
//			            // with the object.  The Classifications(Part Family) created to prior to the installation of Library Central or created in
//			            // previous versions will not have any interfaces associated with them.
//			            if(strChildInterface == null || "".equals(strChildInterface) || "null".equals(strChildInterface)) {
//			                try {
//			                    if(createInterfaceObject(context, strToObjectId) == 0) {
//			                        strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//
//			                        //Get all classified items connected to it and implement the interface on all classified items
//			                        SelectList selectStmts = new SelectList(1);
//			                        selectStmts.addElement(DomainObject.SELECT_ID);
//			                        MapList result = new MapList();
//			                        result = (MapList)childObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
//			                        int iSize = result.size();
//			                        for (int k=0;k<iSize;k++ )
//			                        {
//			                            implementInterfaceOnClassifiedItem(context, strToObjectId, ((String)((Map)result.get(k)).get("id")));
//			                        }
//
//			                    }
//			                } catch(Exception ex) {
//			                    throw ex;
//			                }
//			            }
//
//
//			            try{
//			                // The approach here is as follows:
//			                // Get everything that the child's interface is derived from
//			                // directly; To that list, add the new parent's interface;
//			                // remove mxsysLCOrphans.
//			                // The resulting set is what child's interface will be derived from.
//			                // This may seem over-complicated, but it is necessary in
//			                // conjunction with the optional Multiple Classification Module in
//			                // order to avoid attribute data loss.
//			                String cmd = "print interface $1 select derived dump $2";
//			                String currentParentsCSL = MqlUtil.mqlCommand(context,cmd,true, strChildInterface, ",").trim();
//
//			                StringList currentParentsList = FrameworkUtil.split(currentParentsCSL, ",");
//			                currentParentsList.addElement(strParentInterface);
//			                currentParentsList.remove(LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
//			                String[] parentInterfaces   = new String[currentParentsList.size()+1];
//			                parentInterfaces[0]         = strChildInterface;
//			                StringBuffer sbQuery        = new StringBuffer("modify interface $1 derived");
//			                for (int j = 0 ; j < currentParentsList.size() ; j++) {
//			                    sbQuery.append(" $").append(j+2).append(",");
//			                    parentInterfaces[j+1] = (String)currentParentsList.get(j);
//			                }
//			                cmd = sbQuery.substring(0, sbQuery.lastIndexOf(","));
//
//			                String result = MqlUtil.mqlCommand(context, cmd, true, parentInterfaces);
//
//
//			            }catch(Exception e)
//			            {
//			                e.printStackTrace();
//			                throw e;
//			            }
//
//			            
//			            String connectTclProg =  "emxUpdateCountOnSubclassConnectDisconnect.tcl";
//			            String updateCountConnection = "execute program \""+connectTclProg+"\"  \"" +sCheckRealtionshipLev3Result + "\" " +  "\"" +sLev2PartFamilyId+ "\"";
//			            MQLCommand mqlcommand = new MQLCommand();
//						mqlcommand.open(context);
//				        mqlcommand.executeCommand(context, updateCountConnection);
//						String sResult = mqlcommand.getResult();
//						String sError = mqlcommand.getError();
//						mqlcommand.close(context);
//			            //
//						//trigger end
//					}
//					
////					ContextUtil.commitTransaction(context);
//					MqlUtil.mqlCommand(context, "Trigger On");
//					checkTriggeroff = false;
//					
////					multiWriteMessageToFile(logWriter," MODIFY SUCESS!!.  LINE NUMBER: "+sRowNum);
//					multiWriteMessageToFile(successObjectidWriter,"MODIFY SUCESS: LINE NUMBER: "+sRowNum);
//					successCount++;
//				}catch(Exception e4){
////					ContextUtil.abortTransaction(context);
//					failCount++;
////					multiWriteMessageToFile(logWriter,"Line Number: "+sRowNum+ " Exception occured: " + e4.getMessage());
//					mulitWriteErrorToFile( errorStream,"Line Number: "+sRowNum+" Exception : " + e4.getMessage());
//					e4.printStackTrace(errorStream);
//					multiWriteMessageToFile(failedObjectidWriter,"LINE NUMBER: "+sRowNum+  "Exception : "+e4.getMessage());
//				}finally{
//					if(checkTriggeroff){
//						MqlUtil.mqlCommand(context, "Trigger On");
//					}
//					
//				}
//			}
//			multiWriteMessageToFile(logWriter,"====================================================================================");
//			multiWriteMessageToFile(logWriter,"	File CONNECT PARTFAMILY OBJECT AND PARTFAMILY OBJECT Migration COMPLETED.                    ");
//			multiWriteMessageToFile(logWriter,"====================================================================================");
//		} catch (Exception e) {
//			multiWriteMessageToFile(logWriter,"Line Number: "+sRowNum+ " Exception : " + e.getMessage());
//			mulitWriteErrorToFile( errorStream,"[${CLASSNAME} : connectPartFamily]  Line Number: "+sRowNum+" Exception : " + e.getMessage());
//			e.printStackTrace(errorStream);
//			
//			e.printStackTrace();
//		}finally{
//			multiWriteMessageToFile(logWriter,"====================================================================================");
//			multiWriteMessageToFile(logWriter,"	CONNECT PARTFAMILY OBJECT AND PARTFAMILY OBJECT END TIME:  "+getTimeStamp()+"          "  );
//			multiWriteMessageToFile(logWriter,"	CONNECT PARTFAMILY OBJECT AND PARTFAMILY OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000 + " second                \n"  );
//			multiWriteMessageToFile(logWriter,"	SUCCESS COUNT: ("+successCount+")  FAIL COUNT: ("+failCount+")  TOTAL COUNT: ("+totalCount+")        "  );
//			multiWriteMessageToFile(logWriter,"==================================================================================== \n");
//			System.out.println(" ${CLASSNAME} : connectPartFamily() finish "+getTimeStamp());
//			try {
//				if (null != logWriter)
//					logWriter.close();
//
//				if (null != errorStream)
//					errorStream.close();
//
//				if (null != successObjectidWriter)
//					successObjectidWriter.close();
//
//				if (null != failedObjectidWriter)
//					failedObjectidWriter.close();
//			} catch (IOException e) {
//				System.out.println("Exception while closing log stream " + e.getMessage());
//			}
//		}
//	
//	}
	
	/**
	 * 
	 * Part Family 와 Attribute Group 연결
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void connectPFandAG(Context context,String args[])throws Exception{
		String Output_Directory ="MIGRATION_LOGS";
		long startTime = System.currentTimeMillis();
		System.out.println("cdmAttributeGroupMigration : connectPFandAG() Start . startTime :"+cdmCommonExcel.getTimeStamp());
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String tempPartFamilyExcelPath = "";
		String tempPartFamilyExcelName = "";
		String tempOutputDir		   = "";
		
		
		String tempMappingBlockCodePath = "";
		String tempMappingBlockCodeName = "";
		
		String sFileLocationAndFileName = args[0];
		Map paramMap = new HashMap();
//		paramMap = (Map) JPO.unpackArgs(args);
//		String sFileLocationAndFileName = (String)paramMap.get("fileData");
		tempMappingBlockCodePath 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		tempMappingBlockCodeName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		String logFileName 				= "connectAttributeGroupAndPartFamily";
		String sheetName 				= "Data_Customer";
		
		inputDirectory = tempMappingBlockCodePath;
		fileName 	   = tempMappingBlockCodeName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + S_FILE_SEPARATOR +Output_Directory  + S_FILE_SEPARATOR + logFileName + "_" +  S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		String sRowNum = "";
		int successCount = 0;
		int failCount = 0;
		int totalCount = 0;
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"	CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY OBJECT "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(logWriter,"	Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"	Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		try {
			MqlUtil.mqlCommand(context, "history off");
			//mapping info 
			HashMap<String,String> blockCodeHm = new HashMap<String,String>();
			
			Sheet sheet = (Sheet) cdmCommonExcel.getXssfSheet2(context, inputDirectory + fileName, sheetName);
			
			String sRecoredBlockCodeAG = "";
			String sRecoredBlockCodePF = "";
			String sRecoredBlockCodeDescription = "";
			
			int blockCodeSheetPhysicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalCount = blockCodeSheetPhysicalNumberRows-1;
			for (int blockCodeCnt = 1; blockCodeCnt < blockCodeSheetPhysicalNumberRows; blockCodeCnt++) {
				Row blockCodeSheetRow = sheet.getRow(blockCodeCnt);
				sRowNum = String.valueOf(blockCodeCnt+1);
				try{
					
				if (blockCodeSheetRow == null){
					continue;
				}

				
				Cell blockCodeCell_0 = blockCodeSheetRow.getCell(0); 	//BLOCK_ID
				Cell blockCodeCell_1 = blockCodeSheetRow.getCell(1);    // PART_NO
				Cell blockCodeCell_2 = blockCodeSheetRow.getCell(2);    // PART_Description
				

				String stBlockCodeAG 			= getCellValue2(blockCodeCell_0);
				String stBlockCodePF 			= getCellValue2(blockCodeCell_1);
				String stBlockCodePFDescription = getCellValue2(blockCodeCell_2);
				
				stBlockCodeAG 			= isVaildNullData(stBlockCodeAG);
				stBlockCodePF 			= isVaildNullData(stBlockCodePF);
				stBlockCodePFDescription = isVaildNullData(stBlockCodePFDescription);
				
				sRecoredBlockCodeAG = stBlockCodeAG;
				sRecoredBlockCodePF = stBlockCodePF;
				sRecoredBlockCodeDescription = stBlockCodePFDescription;
				
				String sQuery = "temp query bus 'Part Family'  *  *  where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+stBlockCodePF+":*' \"  select  id attribute[cdmPartFamilyBlockCodeName] dump |";
				String sQueryMql= MqlUtil.mqlCommand(context, sQuery);

				StringList  sListQueryMql = new StringList();
				sListQueryMql = FrameworkUtil.split(sQueryMql, "\n");
				if(cdmStringUtil.isEmpty(sQueryMql)){
					String errorMessage= "NOT EXIST PART FAMILY";
					throw new Exception(errorMessage);
				}
				ContextUtil.startTransaction(context, true);
//				for (Iterator iterator = sListQueryMql.iterator(); iterator.hasNext();) {
				boolean dupleBlockCokdeCheck = false;
				if(sListQueryMql.size()>2){
					dupleBlockCokdeCheck = true; 
				}
				boolean connectCheckAG = false;
				for (int cnt = 0;cnt<sListQueryMql.size();cnt++) {
					String sQueryPFs = (String) sListQueryMql.get(cnt);
					
					String stPartFamilyId = "";
					String stPartFamilyDescription = "";
					StringList sListQuery = new StringList();
					sListQuery = FrameworkUtil.split(sQueryPFs, "|");
					
					stPartFamilyId = (String)sListQuery.get(3);
					stPartFamilyDescription = (String)sListQuery.get(4);
//					if(dupleBlockCokdeCheck){
//						if(!stPartFamilyDescription.equalsIgnoreCase(stBlockCodePFDescription)){
//							continue;
//						}else{
//							connectCheckAG = true;
//						}
//					}
				
					com.matrixone.apps.classification.Classification clsObject = (com.matrixone.apps.classification.Classification) DomainObject.newInstance(context, stPartFamilyId, "Classification");
					StringList slAttributeGroup = new StringList(); // 
	
					slAttributeGroup.add(stBlockCodeAG);
					
					String interfaceDerivedCheck = "list interface \"" + stBlockCodeAG + "\"  ";
					String interfaceDeriveMqlResult = MqlUtil.mqlCommand(context, interfaceDerivedCheck);
					if(cdmStringUtil.isEmpty(interfaceDeriveMqlResult)){
						String errorMessage = "NOT EXIST AG";
						throw new Exception(errorMessage);
					}
					
					clsObject.addAttributeGroups(context, slAttributeGroup);
				}
				
				if(!connectCheckAG && dupleBlockCokdeCheck){
					throw new Exception("Not match description \t"+sRowNum+"\t"+stBlockCodeAG+"\t"+stBlockCodePF+"\t"+stBlockCodePFDescription);
				}else{
					successCount++;
					
				}
				ContextUtil.commitTransaction(context);
				multiWriteMessageToFile(successObjectidWriter,"SUCCESS. \t" + sRowNum+"\t"+stBlockCodeAG+"\t"+stBlockCodePF+"\t"+stBlockCodePFDescription);
				}catch(Exception e2){
					ContextUtil.abortTransaction(context);
					failCount++;
					mulitWriteErrorToFile( errorStream,"LINE NUMBER: \t"+sRowNum+"\t FAIL OCCURED:" + e2.getMessage());
					e2.printStackTrace(errorStream);
					
					String message = e2.getMessage();
					if(UIUtil.isNotNullAndNotEmpty(message ) && message.startsWith("Not match description")){
//						multiWriteMessageToFile(failedObjectidWriter,"1 LINE NUMBER: \t " + sRowNum+"\t FAIL OCCURED: \t "+e2.getMessage());
						multiWriteMessageToFile(failedObjectidWriter,"1 LINE NUMBER: \t " + sRowNum+"\t"+sRecoredBlockCodeAG+"\t"+sRecoredBlockCodePF+"\t"+sRecoredBlockCodeDescription+" FAIL OCCURED: \t "+e2.getMessage());
					}else if(UIUtil.isNotNullAndNotEmpty(message ) && message.startsWith("NOT EXIST AG")){
						multiWriteMessageToFile(failedObjectidWriter,"2 LINE NUMBER: \t " + sRowNum+"\t"+sRecoredBlockCodeAG+"\t"+sRecoredBlockCodePF+"\t"+sRecoredBlockCodeDescription+" FAIL OCCURED: \t "+e2.getMessage());
					}else if(UIUtil.isNotNullAndNotEmpty(message ) && message.startsWith("NOT EXIST PART FAMILY")){
						
						multiWriteMessageToFile(failedObjectidWriter,"3 LINE NUMBER: \t " + sRowNum+"\t"+sRecoredBlockCodeAG+"\t"+sRecoredBlockCodePF+"\t"+sRecoredBlockCodeDescription+" FAIL OCCURED: \t "+e2.getMessage());
					}else{
						multiWriteMessageToFile(failedObjectidWriter,"0 LINE NUMBER: \t " + sRowNum+"\t"+sRecoredBlockCodeAG+"\t"+sRecoredBlockCodePF+"\t"+sRecoredBlockCodeDescription+" FAIL OCCURED: \t "+e2.getMessage());
					}
					
				}
			
			}
			
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"      File CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY OBJECT Migration COMPLETED.    ");
			multiWriteMessageToFile(logWriter,"====================================================================================\n");
			
		} catch (Exception e) {
//			multiWriteMessageToFile(failedObjectidWriter,"Line Number: "+sRowNum+ " Exception occured: " + e.getMessage());
			mulitWriteErrorToFile( errorStream,"LINE NUMBER: \t"+sRowNum+"\t EXCEPTION : " + e.getMessage());
		}finally{
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"	CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY END TIME:  "+cdmCommonExcel.getTimeStamp2() +"          "  );
			multiWriteMessageToFile(logWriter,"	LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + " second                 "  );
			multiWriteMessageToFile(logWriter," SUCCESS COUNT: ("+successCount+") FAILCOUNT: ("+failCount+")  TOTAL COUNT: ("+totalCount+")              "  );
			multiWriteMessageToFile(logWriter,"==================================================================================== \n");
			System.out.println(" cdmAttributeGroupMigration_mxJPO : connectPFandAG() finish "+cdmCommonExcel.getTimeStamp2());
			MqlUtil.mqlCommand(context, "history on");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
		}	
		
	}
	
	/**
	 * 
	 * ag 을 가지고 있으며 Block code List 을 가지고 있는경우 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void connectPFandAGBlockCodeList(Context context,String args[])throws Exception{
		String Output_Directory ="MIGRATION_LOGS";
		long startTime = System.currentTimeMillis();
		System.out.println("cdmAttributeGroupMigration : connectPFandAGBlockCodeList() Start . startTime :"+getTimeStamp());
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String tempMappingBlockCodePath = "";
		String tempMappingBlockCodeName = "";
		
		String sFileLocationAndFileName = args[0];

		tempMappingBlockCodePath 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		tempMappingBlockCodeName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		String logFileName 				= "connectPFandAGBlockCodeList";
		String sheetName 				= "Data_Customer";
		
		
		inputDirectory = tempMappingBlockCodePath;
		fileName 	   = tempMappingBlockCodeName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + S_FILE_SEPARATOR +Output_Directory  + S_FILE_SEPARATOR + logFileName + "_" + S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logFileName+=tempMappingBlockCodeName+"_"+getTimeStamp();
		
		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		int sRowNum = 0;
		int successCount = 0;
		int failCount = 0;
		int totalCount = 0;
		multiWriteMessageToFile(failedObjectidWriter,inputDirectory+fileName);
		mulitWriteErrorToFile( errorStream,inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"	CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY OBJECT "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(logWriter,"	Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"	Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		try {
			String type = "Part Library";
			String name = "Block Code";
			SelectList selectList = new SelectList();
			selectList.addId();
			String sWhere = "";
			MapList mListPL = new MapList();
			mListPL = DomainObject.findObjects(context, type, name, "*", "*", "eService Production", "", sWhere, true, selectList, (short) 0);
			String plId = "";
			for (int jj = 0; jj < mListPL.size(); jj++) {
				Map map = (Map) mListPL.get(jj);
				plId = (String) map.get("id");
			}
			selectList.add("attribute[cdmPartFamilyBlockCodeName]");
			MapList mListBlockCode = new MapList();
			SelectList relSelects = new SelectList();
			// String sWhereExp = "attribute[cdmPartFamilyBlockCodeName] != ''
			// && attribute[cdmCheckMigration] == 'Y' ";
//			String sWhereExp = "attribute[cdmPartFamilyBlockCodeName] != '' ";
			String sWhereExp = "attribute[cdmPartFamilyBlockCodeName] != '' && attribute[cdmPartFamilyBlockCodeName]~='*:*' ";
			DomainObject dObjPL = new DomainObject(plId);
			mListBlockCode = dObjPL.getRelatedObjects(context, "Subclass", // relationship
																			// pattern
					"Part Family", // object pattern
					selectList, // object selects
					relSelects, // relationship selects
					false, // to direction
					true, // from direction
					(short) 0, // recursion level
					sWhereExp, // object where clause
					""); // relationship where clause

			DomainObject dObj = new DomainObject();
			for (Iterator iterBlockCode = mListBlockCode.iterator(); iterBlockCode.hasNext();) {
				sRowNum++;
				totalCount++;
				String sBlockCodeData = "";
				String tempBlockCodeName = "";
				String tempBlockCodeId = "";
				try {
					Map mapBlockCode = (Map) iterBlockCode.next();
					sBlockCodeData= mapBlockCode.toString();
					String blockCodeNameId = (String) mapBlockCode.get("id");
					String blockCodeNameAttr = (String) mapBlockCode.get("attribute[cdmPartFamilyBlockCodeName]");
					StringList splitBlockCodeNameAttr = new StringList();
					splitBlockCodeNameAttr = (StringList) FrameworkUtil.split(blockCodeNameAttr, ":");
					String blcokCodeName = (String) splitBlockCodeNameAttr.get(0);

					tempBlockCodeName = blockCodeNameId;
					tempBlockCodeId = blockCodeNameAttr;
					String interfaceDerivedCheck = "list interface \"" + blcokCodeName + "\"  ";
					String interfaceDeriveMqlResult = MqlUtil.mqlCommand(context, interfaceDerivedCheck);
					if (cdmStringUtil.isEmpty(interfaceDeriveMqlResult)) {
						String errorMessage = "NOT EXIST AG";
						// interface 없는것 따로 기록 할것
						throw new Exception(errorMessage);
					}
					com.matrixone.apps.classification.Classification clsObject = (com.matrixone.apps.classification.Classification) DomainObject.newInstance(context, blockCodeNameId, "Classification");
					StringList slAttributeGroup = new StringList(); //
					slAttributeGroup.add(blcokCodeName);
					clsObject.addAttributeGroups(context, slAttributeGroup);

					ContextUtil.commitTransaction(context);
					successCount++;
					multiWriteMessageToFile(successObjectidWriter,sRowNum+"\t"+blockCodeNameAttr+"\t"+blcokCodeName);
				} catch (Exception e2) {
					ContextUtil.abortTransaction(context);
					failCount++;
					mulitWriteErrorToFile(errorStream, cdmCommonExcel.getTimeStamp2() +"\t"+ sRowNum + "\t"+tempBlockCodeName+"\t"+tempBlockCodeId+ "\t" +e2.getMessage());
					e2.printStackTrace(errorStream);
					multiWriteMessageToFile(failedObjectidWriter, sRowNum+"\t"+sBlockCodeData);
				}
			}

			multiWriteMessageToFile(logWriter, "====================================================================================");
			multiWriteMessageToFile(logWriter, "      File CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY OBJECT Migration COMPLETED.    ");
			multiWriteMessageToFile(logWriter, "====================================================================================\n");

		} catch (Exception e) {
			mulitWriteErrorToFile( errorStream,"LINE NUMBER: "+sRowNum+"| EXCEPTION : " + e.getMessage());
		}finally{
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"	CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY END TIME:  "+getTimeStamp()+"          "  );
			multiWriteMessageToFile(logWriter,"	CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000 + " second                 "  );
			multiWriteMessageToFile(logWriter," SUCCESS COUNT: ("+successCount+") FAILCOUNT: ("+failCount+")  TOTAL COUNT: ("+totalCount+")              "  );
			multiWriteMessageToFile(logWriter,"==================================================================================== \n");
			System.out.println(" cdmAttributeGroupMigration_mxJPO : connectPFandAG() finish "+cdmCommonExcel.getTimeStamp2());
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
		}	
		
	}
	
	
	/**
	 * migration Part Library 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void createPL(Context context,String args[])throws Exception{
		try {
			String name = "Block_Code";
			String title = "Migration";
			String checkPLQuery = "eval expr 'count TRUE' on temp query bus \"Part Library\" * *  where \" name=='" + name + "' \"";
			String mqlResult= MqlUtil.mqlCommand(context, checkPLQuery);
			int intResult = Integer.valueOf(mqlResult.trim());
			
			if (intResult == 0) {
				DomainObject objPartLibrary = new DomainObject();
				objPartLibrary.createObject(context, LibraryCentralConstants.TYPE_PART_LIBRARY, "Block_Code", "-", LibraryCentralConstants.POLICY_LIBRARIES, "eService Production");
//				objPartLibrary.setAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_TITLE, title);

			}
		} catch (Exception e) {
			e.printStackTrace();
			// TODO: handle exception
		}
	}
	
//	/**
//	 * 10.11.16
//	 * attribute check 
//	 * @param context
//	 * @param args
//	 * @throws Exception
//	 */
//	public void checkAttributes(Context context,String[] arg)throws Exception{
//		try {
//
//			String path = "C:\\temp\\Import_File\\20160818_002 DM_SPEC_NAME.xlsx";
//			String stArg = "";
//			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, path, "원본");
//
//			int physicalNumberRows = sheet.getPhysicalNumberOfRows();
//			LinkedHashMap hm = new LinkedHashMap();
//			int checkCount1 = 1;
//			for (int i = 1; i < physicalNumberRows; i++) {
//				XSSFRow row = sheet.getRow(i);
//				if (row == null)
//					continue;
//
//				int physicalCellNumber = row.getPhysicalNumberOfCells();
//				
//				
//				for (int physicalCellCnt = 4; physicalCellCnt < physicalCellNumber; physicalCellCnt++) {
//					XSSFCell xssfCell = row.getCell(physicalCellCnt);
//					String tempCellInfo = "";
//					tempCellInfo = (String) cdmCommonExcel.getCellValue(xssfCell);
//					if (cdmStringUtil.isNotEmpty(tempCellInfo)) {
//						tempCellInfo = tempCellInfo.trim();
//						
//						String tempMapValue = (String)hm.get(tempCellInfo);
//						if(cdmStringUtil.isEmpty(tempMapValue)){
//							hm.put(tempCellInfo, String.valueOf(checkCount1));
//							checkCount1++;
//						}
//						
//					}
//
//				}
//
//			}
////			System.out.println("hm -->>>"+hm.toString());
//			LinkedHashMap hm2 = new LinkedHashMap();
//			XSSFSheet sheet2 = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, path, "데이타");
//			int physicalNumberRows2 = sheet2.getPhysicalNumberOfRows();
//			int checkCount2 = 1;
//			for (int j = 1 ;j < physicalNumberRows2; j++) {
//				XSSFRow row2 = sheet2.getRow(j);
//				if (row2 == null)
//					continue;
//
//				XSSFCell xssfCell2_1 = row2.getCell(1);
//				XSSFCell xssfCell2_2= row2.getCell(2);
//				String tempCellInfo2_1 = "";
//				String tempCellInfo2_2 = "";
//				tempCellInfo2_1 = (String) cdmCommonExcel.getCellValue(xssfCell2_1);
//				tempCellInfo2_2 = (String) cdmCommonExcel.getCellValue(xssfCell2_2);
//				
//				tempCellInfo2_1 = tempCellInfo2_1.trim();
//				tempCellInfo2_2 = tempCellInfo2_2.trim();
//				
//				hm2.put(tempCellInfo2_1, tempCellInfo2_2);
//				
//			}
//			
//			int cnt = 1;
//			LinkedHashMap< String, String> existLinkedHM = new LinkedHashMap<String,String>();
//			LinkedHashMap< String, String> notExistLinkedHM = new LinkedHashMap<String,String>();
//			for (Iterator iterator = hm.keySet().iterator(); iterator.hasNext();) {
//				String	stKey = (String) iterator.next();
//				String stTempValue = ""; 
//				stTempValue = (String)hm2.get(stKey);
//				if(cdmStringUtil.isNotEmpty(stTempValue)){
//					existLinkedHM.put(stKey, stTempValue);
//				}else{
//					notExistLinkedHM.put(stKey, String.valueOf(cnt+1));
//					cnt++;
//				}
//				
//			}
//			System.out.println("existLinkedHM -->>>"+existLinkedHM.toString());
//			System.out.println("notExistLinkedHM -->>>"+notExistLinkedHM.toString());
//			 
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//	}
	
	
	/**
	 *  attribute group 수정 
	 *	
	 *	Description: 
	 *		If there is no attribute after the attribute check Delete the attribute and rearrange it.   
	 *  
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void modifyAttributeGroup(Context context ,String args[])throws Exception{
		long startTime = System.currentTimeMillis();
		System.out.println("modifyAttributeGroup start"+getTimeStamp());
	
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String logFileName = "modifyAttributeGroup";
		
		String tempAttributeGroupExcelOriginalSheetName = "";
		String tempAttributeGroupExcelDataSheetName 	= "";
		String tempAttributeGroupExcelPath 				= "";
		String tempAttributeGroupExcelName 				= "";
		String tempAttributeGroupDataOutputDir 			= "";
		
		Properties prop = new Properties();
		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
		tempAttributeGroupExcelOriginalSheetName = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Original_Sheet_Name"));
		tempAttributeGroupExcelDataSheetName 	 = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Attribute_Data_Sheet_Name"));
		tempAttributeGroupExcelPath  	 		 = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Path"));
		tempAttributeGroupExcelName  	 		 = cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Name"));
		tempAttributeGroupDataOutputDir  		 = cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
		
//		String[] sTempArgs = {"C:\\temp\\Import_File\\ATTRIBUTE_GROUP","20161019_002 DM_SPEC_NAME_1025.xlsx"};
		
		if(cdmStringUtil.isEmpty(tempAttributeGroupExcelOriginalSheetName) || cdmStringUtil.isEmpty(tempAttributeGroupExcelDataSheetName) || cdmStringUtil.isEmpty(tempAttributeGroupExcelPath) || cdmStringUtil.isEmpty(tempAttributeGroupExcelName)) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		String sheetName 				= tempAttributeGroupExcelOriginalSheetName;
		String sAttributeCheckSheetName = tempAttributeGroupExcelDataSheetName;
		
		inputDirectory = tempAttributeGroupExcelPath;
		fileName 	   = tempAttributeGroupExcelName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile().getParent() + S_FILE_SEPARATOR + "tempAttributeGroupDataOutputDir" + S_FILE_SEPARATOR + logFileName + "_" + getTimeStamp() + S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		String sRowNum = "";
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"     CREATE ATTRIBUTEGROUP  "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory);
		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		try {
			Map attributeCheckMap = new HashMap();
			
			XSSFSheet attributeCheckSheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context,  inputDirectory+fileName,sAttributeCheckSheetName );
			int attributeCheckSheetPhysicalNumberRows = attributeCheckSheet.getPhysicalNumberOfRows();
			
			for (int i = 1; i <= attributeCheckSheetPhysicalNumberRows; i++) {

					XSSFRow attributeCheckSheetRow = attributeCheckSheet.getRow(i);
					
					if (attributeCheckSheetRow == null)
						continue;

					XSSFCell cell_InputData     = attributeCheckSheetRow.getCell(1);    // input
					XSSFCell cell_AttributeName = attributeCheckSheetRow.getCell(2);    // cell_AttributeName
					
					String sInputData     = getCellValue(cell_InputData);
					String sAttributeName = getCellValue(cell_AttributeName);
					
					sInputData = isVaildNullData(sInputData);
					sAttributeName = isVaildNullData(sAttributeName);
					
					attributeCheckMap.put(sInputData,sAttributeName);
			}
			
			
			XSSFSheet attributeGroupSheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context,  inputDirectory+fileName, sheetName);
			int attributeGroupSheetphysicalNumberRows = attributeGroupSheet.getPhysicalNumberOfRows();

			SelectList seletList = new SelectList();
			seletList.addId();
			
			for (int s = 1; s <= attributeGroupSheetphysicalNumberRows; s++) {
				XSSFRow row = attributeGroupSheet.getRow(s);
				
				if (row == null)
					continue;
 
				try{
					sRowNum = String.valueOf(s+1);
					XSSFCell cell_PF = row.getCell(0);// Part Family
					XSSFCell cell_AG = row.getCell(1);// attribute_Group

					String sPartFamilyName = getCellValue(cell_PF);
					String sAttributeGroup = getCellValue(cell_AG);

					sPartFamilyName = isVaildNullData(sPartFamilyName);
					sAttributeGroup = isVaildNullData(sAttributeGroup);

					if (cdmStringUtil.isNotEmpty(sPartFamilyName) && cdmStringUtil.isNotEmpty(sAttributeGroup)) {

						int physicalCells = row.getPhysicalNumberOfCells();
						// each row CN_SPEC_NAME_01~30  map 
						StringList sListAttrbutesData = new StringList();
						for (int j = 4; j <= physicalCells; j++) {

							XSSFCell attributeCell = row.getCell(j);
							if (attributeCell == null)
								continue;

							String sAttributeCell  = getCellValue(attributeCell);
							sAttributeCell         = isVaildNullData(sAttributeCell);

							if (cdmStringUtil.isEmpty(sAttributeCell))
								continue;

							/*
							 * ***************************************************************************************************************************
							 * 	The existing name column in the data sheet is the information from which the duplicate CN_SPEC_NAME_01 ~ 30 columns 
							 * 		of the original sheet have been removed.
							 *	If the key value of the map from the data sheet is sAttributeCell information from the original sheet, 
							 *		an error occurs if the value does not exist.  
							 * ****************************************************************************************************************************
							 */
							String attributeCellValue = (String) attributeCheckMap.get(sAttributeCell);
							if (cdmStringUtil.isEmpty(attributeCellValue)) {
								String errorMessage = "DATA SHEET DIDNT RECODRD ATTRIBUTE DATA. ";
								throw new Exception(errorMessage);
							}
							attributeCellValue = S_ATTRIBUTE_GROUP_PREFIX+attributeCellValue;
							
							//Data duplication is excluded. 
							if(sListAttrbutesData.contains(attributeCellValue)){
//								String errorMessage = "DUPLICATION ATTRIBUTE DATA.";
//								throw new Exception(errorMessage);
							}else{
								sListAttrbutesData.add(attributeCellValue);
							}
						}

						String description = "";
						String sAttributeValue = "";
						
						/*attributeGroup Name is Data that combines the data in the column(code block ,description) .*/
						String sPartFamilyAndAttributeGroupName = S_ATTRIBUTE_GROUP_PREFIX + sPartFamilyName + S_UNDER_LINE + sAttributeGroup;

						for (int  rowCnt = 0; rowCnt<sListAttrbutesData.size(); rowCnt++) {
							String stTempAttributeValue = S_ATTRIBUTE_GROUP_PREFIX + (String) sListAttrbutesData.get(rowCnt);
							sAttributeValue = "".equalsIgnoreCase(sAttributeValue) ? stTempAttributeValue : sAttributeValue.trim() + "|" + stTempAttributeValue.trim();
						}

						/* Attribute Group create check */
//						String checkAttributeGroup = "immediatederivative[" + sPartFamilyAndAttributeGroupName + "]";
//						String checkCreateAttribute = "list interface $1 select $2 dump $3";
//						String checkMqlResult = MqlUtil.mqlCommand(context, checkCreateAttribute, DomainConstants.INTERFACE_CLASSIFICATION_ATTRIBUTE_GROUPS, checkAttributeGroup, "|");
						
						String sClassificationAttributeGroups = PropertyUtil.getSchemaProperty("interface_ClassificationAttributeGroups");
						String checkAttributeGroup = "derived[" + sClassificationAttributeGroups + "]";
						String checkCreateAttribute = "list interface $1 select $2 dump $3";
						String checkMqlResult = MqlUtil.mqlCommand(context, checkCreateAttribute, sPartFamilyAndAttributeGroupName, checkAttributeGroup, "|");
						StringList sListMqlResult = new StringList();
						sListMqlResult = FrameworkUtil.split(checkMqlResult, "|");
						boolean bAttributeGroupMqlResult = false;
						
						if(sListMqlResult.size()>0){
							bAttributeGroupMqlResult = true;
						}
						ContextUtil.startTransaction(context, true);
						
						if (!bAttributeGroupMqlResult) {
							String errorMessage = "NOT EXIST ATTRIBUTE GROUP. ";
							throw new Exception(errorMessage);
						} else {
							
							AttributeGroup AG = new AttributeGroup();
							AG.setName(sPartFamilyAndAttributeGroupName);
							
							String strAGQuery    		  = "list interface $1 select attribute dump $2";
							String strAGQueryResult       = MqlUtil.mqlCommand(context, strAGQuery, sPartFamilyAndAttributeGroupName,"|");
							StringList sListAGQueryResult = new StringList();
							sListAGQueryResult = FrameworkUtil.split(strAGQueryResult, "|");
							
							StringList sListCurrentAttributeName = new StringList();
							for (int currentAttributeCnt =0; currentAttributeCnt< sListAGQueryResult.size(); currentAttributeCnt++) {
								String strAttributeName = (String) sListAGQueryResult.get(currentAttributeCnt);
//								if(strAttributeName.startsWith(sAttributeGroupPrefix)){
								sListCurrentAttributeName.add(strAttributeName);
//								}
							}
							sListCurrentAttributeName.sort();
							 /*
							  * ****************************************************************************************
							  * After confirming the same, correct it. If they are the same, do not modify them. 
							  * ****************************************************************************************
							  * */
							StringList sListSortstAttributeData = new StringList();
							for (Iterator rowListIterator = sListAttrbutesData.iterator(); rowListIterator.hasNext();) {
								String stRowListForSort = (String) rowListIterator.next();
								sListSortstAttributeData.add(stRowListForSort);
							}
							sListSortstAttributeData.sort();
//							boolean bModifyAGCheck		 		= sListCurrentAttributeName.equals(sListSortstRowList);
//							boolean bModifyAGCheck		 		= sListAttrbutesData.equals(sListCurrentAttributeName);
//							boolean bModifyAGCheck		 		= sListAttrbutesData.equals(sListAGQueryResult);
							boolean bModifyAGCheck		 		= sListSortstAttributeData.equals(sListCurrentAttributeName);
							boolean bmodifyAttributeS 	 		= false;
							boolean bEqualAttributeGroupObject  = true;
							/*Delete existing attributes and add attributes.*/

							if (!bModifyAGCheck) {
								
								if(sListAGQueryResult.size()>0){
									AG.removeAttributes(context, sListAGQueryResult);
								}
								AG.addAttributes(context, sListAttrbutesData);
								bmodifyAttributeS = true;
							}else{
								
								BusinessObject bo = new BusinessObject("cdmAttributeGroupObject", sPartFamilyAndAttributeGroupName, "-", "eService Production");
								String stAttributeGroupObjectId = bo.getObjectId(context);
								DomainObject domObjAttributeGroup = new DomainObject(stAttributeGroupObjectId);
								String strDescription = domObjAttributeGroup.getAttributeValue(context, "cdmDescription");
								String[] strDescriptionArray = strDescription.split("\\|");
								StringList sListDescription = new StringList();
								
								for (int descriptionCnt = 0; descriptionCnt < strDescriptionArray.length; descriptionCnt++) {
									String strTempDescription = strDescriptionArray[descriptionCnt];
									sListDescription.add(strTempDescription);
									
								}
								
								bEqualAttributeGroupObject = sListAttrbutesData.equals(sListDescription);
							}
						
							if (bmodifyAttributeS || !bEqualAttributeGroupObject) {
							
							/*
							 * ************************************************************************************************************* 
							 * 	cdmAttributeGroupObject attribute modify
							 * 	Description and attribute [cdmAttributeGroupSequence] to remove existing information and add attributes 
							 *  *************************************************************************************************************
							 */  
								int iAttrSize = sListAttrbutesData.size();
								BusinessObject boAttributeGroup = new BusinessObject("cdmAttributeGroupObject", sPartFamilyAndAttributeGroupName, "-", "eService Production");
								String objectIdAttributeGroup = boAttributeGroup.getObjectId(context);
								DomainObject domObjAttributeGroup = new DomainObject(objectIdAttributeGroup);
								
								StringBuffer strBuffer = new StringBuffer();
								StringBuffer strSequenceBuffer = new StringBuffer();
								int iAttributeSize = 1;
								
								for(int i=0; i<iAttrSize; i++){
									String strAttribute = (String)sListAttrbutesData.get(i);
									if(! "".equals(strBuffer.toString())){
										strBuffer.append("|");
										strBuffer.append(strAttribute);
										
										strSequenceBuffer.append("|");
										strSequenceBuffer.append(strAttribute);
										strSequenceBuffer.append(",");
										strSequenceBuffer.append(String.valueOf(iAttributeSize+i));
									}else{
										if(i != 0){
											strBuffer.append("|");
										}
										strBuffer.append(strAttribute);
										
										strSequenceBuffer.append(strAttribute);
										strSequenceBuffer.append(",");
										strSequenceBuffer.append(String.valueOf(iAttributeSize+i));
									}
								}
								domObjAttributeGroup.setAttributeValue(context, "cdmDescription", strBuffer.toString());
								domObjAttributeGroup.setAttributeValue(context, "cdmAttributeGroupSequence", strSequenceBuffer.toString());
								
							}else{
								String errorMessage = "EXIST ATTRIBUTE OBJECT EQUAL DATA. ATTRIBUTEGROUP OBJECT EQUAL: "+bEqualAttributeGroupObject;
								throw new Exception(errorMessage);
							}
						
						}
					
						ContextUtil.commitTransaction(context);
						multiWriteMessageToFile(logWriter," MODIFY SUCESS!!.  LINE NUMBER: "+sRowNum);
						multiWriteMessageToFile(successObjectidWriter,"MODIFY SUCESS: LINE NUMBER: "+sRowNum);
					} else {
						String errorMessage = "SHEET DATA NOT EXIST FILE DATA (CN_CODE,TDM_DESCRIPTION) ";
						throw new Exception(errorMessage);

					}
				}catch(Exception e2){
					ContextUtil.abortTransaction(context);
					multiWriteMessageToFile(logWriter,"Line Number: "+sRowNum+ " Exception occured: " + e2.getMessage());
					mulitWriteErrorToFile( errorStream,"[cdmAttributeGroupMigration_mxJPO : modifyAttributeGroup]  Line Number: "+sRowNum+" Exception occured: " + e2.getMessage());
					e2.printStackTrace(errorStream);
					multiWriteMessageToFile(failedObjectidWriter,"[cdmAttributeGroupMigration_mxJPO : modifyAttributeGroup] fail occured. LINE NUMBER: " + sRowNum);
				}
			}
					
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"        File CREATE ATTRIBUTEGROUP OBJECT Migration COMPLETED.                    ");
			multiWriteMessageToFile(logWriter,"====================================================================================\n");
		} catch (Exception e) {
			e.printStackTrace();
			throw new FrameworkException(e.toString());
		}finally{
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"		 CREATE ATTRIBUTEGROUP OBJECT MIGRATION CLOSE TIME:  "+getTimeStamp()+"          \n"  );
			multiWriteMessageToFile(logWriter,"		LEAD TIME:"+ (System.currentTimeMillis() - startTime) + "                  "  );
			multiWriteMessageToFile(logWriter,"==================================================================================== \n");
			System.out.println(" cdmAttributeGroupMigration_mxJPO : modifyAttributeGroup() finish ");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
		}
	}
	
	
	/**
	 * 11.03.16 
	 * description input
	 * 
	 *PART FAMILY modify 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void modifyPG(Context context,String args[])throws Exception{
		String sheetName   = "";
		String[] sTempArgs = {"C:\\temp\\Import_File\\PART_FAMILY","20160819_Block code List_20160203.xls"};
		
		if (sTempArgs.length != 2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		String inputDirectory  = sTempArgs[0];
		String fileName 	   = sTempArgs[1];
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}
		
		String sRowNum = "";
		String sSheetPhysicalNumberRows = "";
		try {

			Sheet xssfSheet = (Sheet) cdmCommonExcel.getXssfSheet2(context, inputDirectory+fileName, sheetName);
			int sheetPhysicalNumberRows = xssfSheet.getPhysicalNumberOfRows();
			
			/* Part Library id search*/
			String sPartLibraryName = "Migration_Data";
			StringList sPLQueryResultList = null;
			String sPLQuery = "temp query bus \"Part Library\" * *  where \" name=='" + sPartLibraryName + "' \"  select id dump |";
			String mqlResult= MqlUtil.mqlCommand(context,  sPLQuery);
			sPLQueryResultList = FrameworkUtil.split(mqlResult, "|");
			String sPLId= (String)sPLQueryResultList.get(3);
			
			for (int i = 1; i <= sheetPhysicalNumberRows; i++) {
//				XSSFRow sheetRow = xssfSheet.getRow(i);
				Row sheetRow = xssfSheet.getRow(i);
				sSheetPhysicalNumberRows = String.valueOf(i);
				if (sheetRow == null)
					continue;
				try {
					sRowNum         = String.valueOf(i+1);
//					XSSFCell cell_0 = sheetRow.getCell(0);
					Cell cell_1 = sheetRow.getCell(1);
					Cell cell_2 = sheetRow.getCell(2);
					Cell cell_3 = sheetRow.getCell(3);
					Cell cell_4 = sheetRow.getCell(4);
					Cell cell_5 = sheetRow.getCell(5);

//					String sNumber       	= getCellValue(cell_0);
					String sCompany 	 	= getCellValue2(cell_1);
					String sProductCode 	= getCellValue2(cell_2);
					String sProductCodeName = getCellValue2(cell_3);
					String sBlockCode 		= getCellValue2(cell_4);
					String sBlockCodeName 	= getCellValue2(cell_5);

//					sNumber 			= isVaildNullData(sNumber);
					sCompany 			= isVaildNullData(sCompany);
					sProductCode 		= isVaildNullData(sProductCode);
					sProductCodeName 	= isVaildNullData(sProductCodeName);
					sBlockCode 			= isVaildNullData(sBlockCode);
					sBlockCodeName 		= isVaildNullData(sBlockCodeName);

					sProductCodeName = FrameworkUtil.findAndReplace(sProductCodeName, ",", "?");
					if(!sCompany.equals("Global R&D")){
						continue;
					}
					// //part family rule have name rule
					// String sPartFamilyNameLev1 = "";
					// String sPartFamilyNameLev2 = "";
					// String sPartFamilyNameLev3 = "";

//					String sPartFamilyNameLev1 = sCompany;
//					String sPartFamilyNameLev2 = sProductCode + ":" + sProductCodeName + "(" + sCompany + ")";
					String sPartFamilyNameLev3 = sProductCode + sBlockCode + ":" + sBlockCodeName + "(" + sCompany + ")";
					
					String sCheckBlockCode ="";
					String sPartFamilyLev3Id = "";
					boolean bCheckBlockCode = false;
					if(sBlockCode.indexOf(",") != -1){
						bCheckBlockCode = true;
						sCheckBlockCode 		= FrameworkUtil.findAndReplace(sBlockCode, ",", "?");
						String sTempPartFamilyNameLev3 = sProductCode + sCheckBlockCode + ":" + sBlockCodeName + "(" + sCompany + ")";
						String checkStWhere = "name ~= '"+sTempPartFamilyNameLev3+"'";
						String stSearchPartFamily = MqlUtil.mqlCommand(context, "temp query bus \"Part Family\"  *  * where \""+ checkStWhere+"\" select id name dump |" );
						
						if(cdmStringUtil.isEmpty(stSearchPartFamily)){
							String errorMessage = "NOT EXIST PART FAMILY.LINE NUMBER:" +sSheetPhysicalNumberRows;
							throw new Exception(errorMessage);
							
						}
						
						StringList stSearchPartFamilyMql = new StringList();
						stSearchPartFamilyMql = FrameworkUtil.split(stSearchPartFamily, "\n");
						for (Iterator iterator = stSearchPartFamilyMql.iterator(); iterator.hasNext();) {
							String sTempPartFamilyInfos = (String) iterator.next();
							StringList sListTempPartFamilyInfo =  FrameworkUtil.split(sTempPartFamilyInfos, "|");
							String sTempPartFamilyName = (String)sListTempPartFamilyInfo.get(4);
							
							if(cdmStringUtil.isNotEmpty(sTempPartFamilyName) && sTempPartFamilyName.equals(sBlockCode)){
								sPartFamilyLev3Id = (String)sListTempPartFamilyInfo.get(3);
								break;
							}
							
						}
						
					}else{
						String stSearchPartFamily = MqlUtil.mqlCommand(context, "temp query bus \"Part Family\"  \""+sPartFamilyNameLev3 +"\"  * select id dump |" );
						StringList stSearchPartFamilyMql = new StringList();
						stSearchPartFamilyMql = FrameworkUtil.split(stSearchPartFamily, "|");
						sPartFamilyLev3Id = (String)stSearchPartFamilyMql.get(3);
					}
					ContextUtil.startTransaction(context, true);
					DomainObject dObj = new DomainObject(sPartFamilyLev3Id);
					System.out.println( "LINE NUMBER :"+sSheetPhysicalNumberRows+"   "+dObj.getName(context));
					
					dObj.setAttributeValue(context, "cdmDescription", sBlockCodeName);
					dObj.setAttributeValue(context, "cdmCheckMigration", "Y");
					
					
					
					
					ContextUtil.commitTransaction(context);
				}catch(Exception e2){
					ContextUtil.abortTransaction(context);
					e2.printStackTrace();
				}
			}
			
		}catch(Exception e3){
			e3.printStackTrace();
		}finally{
			System.out.println("end ");
		}

	}
	
	

	/**
	 *  
	 * migration attribute delete
	 * @param context
	 * @param arg
	 * @throws Exception
	 */
	public void deleteAttribute(Context context,String arg[])throws Exception{
		long startTime = System.currentTimeMillis();
		System.out.println("cdmAttributeGroupMigration_mxJPO:deleteAttribute -start ");
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		 
		BufferedWriter logWriter    	= null; //whole log
		BufferedWriter successbfWriter  = null; //success data  
		BufferedWriter failbfWriter    	= null; //fail data 
		PrintStream errorStream 		= null; //fail reason 
		String logFileName 				= "deleteAttribute"; // log file default name 
		Properties prop = new Properties();
		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
		String sheetName= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Attribute_Data_Sheet_Name"));

		if(cdmStringUtil.isEmpty(sheetName)){
			String errorMessage = "The sheet information is inappropriate.";
			throw new Exception(errorMessage);
		}
		String inputDirectory 	= "";
		String fileName         = "";
		String outputDirectory 	= "";
		
//		String[] sTempArgs = {"C:\\temp\\Import_File\\ATTRIBUTE_GROUP","20161019_002 DM_SPEC_NAME_1025.xlsx"};
		String[] sTempArgs = {"C:\\temp\\Import_File\\ATTRIBUTE_GROUP","20161107_002_DM_SPEC_NAME.xlsx",sheetName};
		
		if (sTempArgs.length != 2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory = sTempArgs[0];
		fileName = sTempArgs[1];
		
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
//		String outputDirectory2 = new File(inputDirectory).getParentFile().getParent();
//		System.out.println("outputDirectory2 -->"+outputDirectory2);
		outputDirectory = new File(inputDirectory).getParentFile().getParent() + S_FILE_SEPARATOR + "MIGRATION_LOGS" + S_FILE_SEPARATOR + logFileName + "_" + getTimeStamp() + S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile 	= new File(outputDirectory + logFileName + "_SuccessLog.log");
		successbfWriter 	= new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile 	= new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failbfWriter 		= new BufferedWriter(new FileWriter(failedLogFile, true));
		
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"     DELETE ATTRIBUTE  "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory);
		multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		mulitWriteErrorToFile( errorStream,"[cdmAttributeGroupMigration_mxJPO:deleteAttribute]");
		multiWriteMessageToFile(failbfWriter,"[cdmAttributeGroupMigration_mxJPO:deleteAttribute]");
		
		String sRowCount      = "";
		String sRowName      = "";
		
		int successRowDatas = 0;
		int failRowDatas   = 0;
		int totalRow = 0;
		
		try {
			
			XSSFSheet attributeSheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context,  inputDirectory+fileName,sheetName );
			int attributeSheetPhysicalNumberRows = attributeSheet.getPhysicalNumberOfRows();
			totalRow = attributeSheetPhysicalNumberRows;
			//Data presence from row 2. header presence  row 1
			for (int i = 1; i <= attributeSheetPhysicalNumberRows; i++) {
				try {
					

					if(i!= 0 && i/500 ==1){
						logWriter.flush();
						successbfWriter.flush();
						failbfWriter.flush();
					}
					
					sRowCount = String.valueOf(i+ 1) ;
					XSSFRow attributeCheckSheetRow = attributeSheet.getRow(i);

					if (attributeCheckSheetRow == null) {
						String errorMessage = "SHEET ROW IS NULL ";
						throw new Exception(errorMessage);

					}

					// XSSFCell cell_rowCount = attributeCheckSheetRow.getCell(0);   // row data
					XSSFCell cell_AttributeName = attributeCheckSheetRow.getCell(2); // 

					String sExcelAttributeName = getCellValue(cell_AttributeName);
					sExcelAttributeName = isVaildNullData(sExcelAttributeName);

					if (cdmStringUtil.isEmpty(sExcelAttributeName)) {
						String errorMessage = "THERE IS NO DATA IN THE ATTRIBUTE FIELD OF THE SHEET.";
						throw new Exception(errorMessage);
					}
					sRowName = sExcelAttributeName;
					String sAttributeName = S_ATTRIBUTE_GROUP_PREFIX + sExcelAttributeName;
					ContextUtil.startTransaction(context, true);
					String existAttributeMql = "list attribute \"" + sAttributeName + "\"";
					MqlUtil.mqlCommand(context, existAttributeMql);
					
					if(cdmStringUtil.isEmpty(existAttributeMql)){
						String errorMessage = "NOT EXIST ATTRIBUTE.";
						throw new Exception(errorMessage);
					}
					String deleteAttributeMql = "delete attribute \"" + sAttributeName + "\"";
					MqlUtil.mqlCommand(context, deleteAttributeMql);

					ContextUtil.commitTransaction(context);
					multiWriteMessageToFile(logWriter," DELETE SUCESS!!.  LINE NUM: "+sRowCount +"NAME:"+sRowName);
					multiWriteMessageToFile(successbfWriter,"DELETE SUCESS: LINE NUM: "+sRowCount+"NAME:"+sRowName);
					successRowDatas ++;
				}catch(Exception e1){
					failRowDatas++;
					ContextUtil.abortTransaction(context);
					multiWriteMessageToFile(logWriter,"LINE NUM: "+sRowCount+ " NAME:"+sRowName+" ERROR OCCURED: " + e1.getMessage());
					mulitWriteErrorToFile( errorStream,"LINE NUM: "+sRowCount+" ERROR OCCURED: " + e1.getMessage());
					e1.printStackTrace(errorStream);
					multiWriteMessageToFile(failbfWriter,"ERROR OCCURED. LINE NUM: " + sRowCount+"NAME:"+sRowName);
					
					
				}
			}
			
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"        File CREATE ATTRIBUTEGROUP OBJECT Migration COMPLETED.                    ");
			multiWriteMessageToFile(logWriter,"====================================================================================\n");
		} catch (Exception e) {
			multiWriteMessageToFile(failbfWriter,"ERROR OCCURED. LINE NUM: " + sRowCount);
			e.printStackTrace(errorStream);		
			
		}finally{
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter," DELETE ATTRIBUTE MIGRATION CLOSE TIME:  "+getTimeStamp()+"          \n"  );
			multiWriteMessageToFile(logWriter,"		 LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000 + " SECOND              "  );
			multiWriteMessageToFile(logWriter,"		 FAIL COUNT: ("+failRowDatas + ")   SUCESS COUNT: ("+successRowDatas+")  TOTAL ROW COUNT: ("+totalRow+")    "  );
			multiWriteMessageToFile(logWriter,"==================================================================================== \n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successbfWriter)
					successbfWriter.close();
				
				if (null != failbfWriter)
					failbfWriter.close();

			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			System.out.println("cdmAttributeGroupMigration_mxJPO:deleteAttribute -end ");
		}
	}
	
	/**
	 * Part Family delete
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void deletePartFamily(Context context,String args[])throws Exception{
		String logFileName = "deletePartFamily";
		PrintStream errorstream = null;
		String outputDirectory  = "";
		String inputDirectory  = "";
		try {
			Properties prop = new Properties();
			prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
			String tempAttributeGroupExcelPath 		= "";
			String tempAttributeGroupDataOutputDir 	= "";
			
			tempAttributeGroupExcelPath 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Path"));
			tempAttributeGroupDataOutputDir 		= cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
	//		String[] sTempArgs = {S_ATTRIBUTE_GROUP_EXCEL_PATH};
			if (cdmStringUtil.isEmpty(tempAttributeGroupExcelPath) || cdmStringUtil.isEmpty(tempAttributeGroupDataOutputDir)) {
				throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
			}
			inputDirectory = tempAttributeGroupExcelPath;
			
			if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
				inputDirectory = inputDirectory + S_FILE_SEPARATOR;
			}
	
			// create a directory to add debug and error logs
			outputDirectory = new File(inputDirectory).getParentFile().getParent() + S_FILE_SEPARATOR + tempAttributeGroupDataOutputDir + S_FILE_SEPARATOR + logFileName + "_" + getTimeStamp() + S_FILE_SEPARATOR;
			File fileOutputDirectory = new File(outputDirectory);
			if (!fileOutputDirectory.isDirectory()) {
				fileOutputDirectory.mkdirs();
			}
			errorstream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));
		
//			String sMql = MqlUtil.mqlCommand(context, "temp query bus \"Part Family\" * * where \"attribute[cdmMigrationFlag] == 'Y' \" select id dump |  ");
			String sMql = MqlUtil.mqlCommand(context, "temp query bus \"Part Family\" * * where \"attribute[cdmCheckMigration]=='Y' \" select id dump |  ");
//			String sMql = MqlUtil.mqlCommand(context, "temp query bus \"Part Family\" * * where \"name ~= '*(Global R&D*' \" select id dump |  ");
			StringList sListMql = new StringList();
			sListMql = FrameworkUtil.split(sMql, "\n");
			
			for (Iterator mqlIterator = sListMql.iterator(); mqlIterator.hasNext();) {
				try {
					
					String tempPartFamily = (String) mqlIterator.next();
					StringList tempResultList2 = StringUtil.split(tempPartFamily, "|");
					String sPartFamilyId = (String) tempResultList2.get(3);
					sPartFamilyId = sPartFamilyId.trim();

					DomainObject dObjPartFamily = DomainObject.newInstance(context, sPartFamilyId);
					dObjPartFamily.deleteObject(context);

				} catch (Exception e) {
					e.printStackTrace(errorstream);
				}

			}
		} catch (Exception e) {
			e.printStackTrace(errorstream);
		}finally {
			if(errorstream!=null){
				errorstream.close();
			}
		}
		
	}
	
	
	/**
	 * 11.16
	 * temp attribute decription modify 
	 * @param context
	 * @param args
	 */
	public void modifyAttribute(Context context,String[] args)throws Exception{

		
		Long startTime =System.currentTimeMillis() ;
		System.out.println("cdmAttributeGroupMigration_mxJPO : modifyAttribute() start  "+getTimeStamp());
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		String sheetName                     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		int successCount = 0;
		int failCount 	 = 0;
		int totalCount   = 0;
		String sRowNum = "";
		
		String logFileName = "modifyAttrubute";
		
		String tempAttributeGroupExcelPath 		        = "";
		String tempAttributeGroupExcelName 		        = "";
		String tempAttributeGroupDataOutputDir 	        = "";
		String tempAttributeGroupExcelDataSheetName 	= "";
		try {
			Properties prop = new Properties();
			prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
			
			tempAttributeGroupExcelPath 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Path"));
			tempAttributeGroupExcelName 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Name"));
			tempAttributeGroupDataOutputDir 		= cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
			tempAttributeGroupExcelDataSheetName	= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Attribute_Data_Sheet_Name"));
			// read file path ,read file Name sheet
	//		String[] sTempArgs = {"C:\\temp\\Import_File\\ATTRIBUTE_GROUP","20161107_002_DM_SPEC_NAME.xlsx","데이타"};
	//		String[] sTempArgs = {"C:\\temp\\Import_File\\ATTRIBUTE_GROUP","20161019_002 DM_SPEC_NAME_1025.xlsx","데이타"};
	//		String[] sTempArgs = {"C:\\temp\\Import_File\\ATTRIBUTE_GROUP","20161019_002 DM_SPEC_NAME.xlsx","데이타"};
			
			
	
			if (cdmStringUtil.isEmpty(tempAttributeGroupExcelPath) || cdmStringUtil.isEmpty(tempAttributeGroupExcelName) || cdmStringUtil.isEmpty(tempAttributeGroupDataOutputDir) || cdmStringUtil.isEmpty(tempAttributeGroupExcelDataSheetName)) {
				throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
			}
			inputDirectory = tempAttributeGroupExcelPath;
			fileName       = tempAttributeGroupExcelName;
			sheetName      = tempAttributeGroupExcelDataSheetName;
			// documentDirectory does not ends with "/" add it
			if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
				inputDirectory = inputDirectory + S_FILE_SEPARATOR;
			}
	
			// create a directory to add debug and error logs
			outputDirectory = new File(inputDirectory).getParentFile().getParent() + S_FILE_SEPARATOR + tempAttributeGroupDataOutputDir + S_FILE_SEPARATOR + logFileName + "_" + getTimeStamp() + S_FILE_SEPARATOR;
			File fileOutputDirectory = new File(outputDirectory);
			if (!fileOutputDirectory.isDirectory()) {
				fileOutputDirectory.mkdirs();
			}
			logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.log", true));
			errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.log")));
	
			successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
			successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));
	
			failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".log");
			failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
			
			mulitWriteErrorToFile(errorStream, "[cdmAttributeGroupMigration_mxJPO : addAttribute] ");
			multiWriteMessageToFile(failedObjectidWriter, "[cdmAttributeGroupMigration_mxJPO : addAttribute]");
			
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"     modify ATTRIBUTE DATA MIGRATION "+ getTimeStamp()+"  \n");
			multiWriteMessageToFile(logWriter,"		Reading input log file from : "+inputDirectory);
			multiWriteMessageToFile(logWriter,"		Writing Log files to: " + outputDirectory );
			multiWriteMessageToFile(logWriter,"====================================================================================\n");
	
		
			XSSFSheet addAttributeSheet = null;
			addAttributeSheet = cdmCommonExcel.getXssfSheet(context, inputDirectory + fileName, sheetName);
			
			int physicalNumberRows = addAttributeSheet.getPhysicalNumberOfRows();
			totalCount = physicalNumberRows-1;
			for (int i = 1; i < physicalNumberRows; i++) {
				try {
					XSSFRow row = addAttributeSheet.getRow(i);
					sRowNum = String.valueOf(i+1);
					if (row == null){
						String errorMessage= "THERE IS NO INFORMATION IN THE EXCEL SHEET.";
						throw new Exception(errorMessage);
					}
					
				
					if(i!= 0 && i%500 ==0){
						logWriter.flush();
						successObjectidWriter.flush();
						failedObjectidWriter.flush();
					}
					
					XSSFCell cell_Location    = row.getCell(0);
					XSSFCell cell_Description = row.getCell(1);
					XSSFCell cell_Name        = row.getCell(2);
					if (cell_Location == null ||( cell_Description == null && cell_Name == null)){
						String errorMessage= "THERE IS NO REQUIRED INFORMATION IN THE EXCEL SHEET.";
						throw new Exception(errorMessage);
					}
					
					String stDecription = getCellValue(cell_Description);
					String stName = getCellValue(cell_Name);

					stDecription = isVaildNullData(stDecription);
					stName = isVaildNullData(stName);
					
					stName = "cdm" + stName;
					stDecription = "cdm:" + stDecription;
					System.out.println("stDecription :"+stDecription);
					
					StringBuffer stringBuff = new StringBuffer();
					stringBuff.append("list attribute \"" + stName + "\" select name dump |");

					String mqlResult = MqlUtil.mqlCommand(context, stringBuff.toString());
					StringList commandList = FrameworkUtil.split(mqlResult, "|");

					if (commandList.size() > 0) {
						StringBuffer stBuffModifyAttr = new StringBuffer();
						stBuffModifyAttr.append("mod attribute \"" +stName+"\" ");
						stBuffModifyAttr.append(" description  \"" +stDecription+"\" " );
						MqlUtil.mqlCommand(context, stBuffModifyAttr.toString());
						successCount ++;
					} 

				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failCount++;
//					multiWriteMessageToFile(logWriter, "Line Number: " + sRowNum + "| Exception : " + exception.getMessage());
					mulitWriteErrorToFile(errorStream, "Line Number: " + sRowNum + "| Exception : " + exception.getMessage());
					exception.printStackTrace(errorStream);
					multiWriteMessageToFile(failedObjectidWriter, "LINE NUMBER: " + sRowNum + "| Exception : " + exception.getMessage());
				}

			}
			multiWriteMessageToFile(logWriter, "====================================================================================");
			multiWriteMessageToFile(logWriter, "        File modify ATTRIBUTE Migration COMPLETED.                    ");
			multiWriteMessageToFile(logWriter, "====================================================================================\n");
			
		} catch (Exception e) {
			
			multiWriteMessageToFile(failedObjectidWriter, "LINE NUMBER: " + sRowNum);
//			mulitWriteErrorToFile(errorStream, "[${CLASSNAME} : addAttribute] Exception occured.  LINE NUMBER: " + sRowNum + "  " + e.getMessage());
			multiWriteMessageToFile(logWriter, " Exception : " + e.getMessage() + "| LINE NUMBER: " + sRowNum);
			e.printStackTrace(errorStream);
		} finally {
			multiWriteMessageToFile(logWriter, "====================================================================================");
			multiWriteMessageToFile(logWriter, "MODIFY ATTRIBUTE MIGRATION CLOSE TIME:  " + getTimeStamp() + "                  ");
			multiWriteMessageToFile(logWriter, "	LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000 + "ms                  ");
			multiWriteMessageToFile(logWriter, "	FAILCOUNT: (" + failCount +")  SUCCESSCOUNT:("+ successCount+")  TOTAL COUNT:("+totalCount+")               ");
			
			multiWriteMessageToFile(logWriter, "==================================================================================== \n");
			System.out.println("cdmAttributeGroupMigration_mxJPO : modifyAttribute() end ");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
		}
	
		
	}
	
	
	/**
	 * 
	 * name rule:
	 * 1 level   "ElectronicPart" + product code Name
	 * 2 level   product code + product code Name
	 * 3 level   product code + block code +":"+ block code name
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void createPartFamilyForElectronicPart(Context context,String args[])throws Exception{

		System.out.println("cdmClassificationMigration : createPartFamilyForElectronicPart start. "+getTimeStamp());
		long startTime = System.currentTimeMillis();
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
	
		String sheetName   = "custom_20161121";
		String logFileName = "createPatFamilyForElectronicPart";
		
		String tempPartfamilyExcelPath = "";
		String tempPartfamilyExcelName = "";
		String tempOutputDir = "MIGRATION_LOGS";
		
		String sFileLocationAndFileName = args[0];
		
		// 엑셀 정보 
		tempPartfamilyExcelPath 				= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf(File.separator));
		tempPartfamilyExcelName 				= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf(File.separator)+1);
		
//		Properties prop = new Properties();
//		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
//		
//		tempPartfamilyExcelPath 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("PART_FAMILY_ELECTRONICPART_EXCEL_PATH"));
//		tempPartfamilyExcelName 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("PART_FAMILY_ELECTRONICPART_EXCEL_NAME"));
//		tempOutputDir 						= cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
		
		if (cdmStringUtil.isEmpty(tempPartfamilyExcelPath) || cdmStringUtil.isEmpty(tempPartfamilyExcelName) || cdmStringUtil.isEmpty(tempOutputDir) ) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}

		inputDirectory = tempPartfamilyExcelPath;
		fileName 	   = tempPartfamilyExcelName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile().getParent() + S_FILE_SEPARATOR + tempOutputDir + S_FILE_SEPARATOR + logFileName + "_" +  S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		String sRowNum = "";
		
		int successRowCount = 0;
		int failRowCount = 0;
		int totalRowCount = 0;
		multiWriteMessageToFile(failedObjectidWriter,"[cdmAttributeGroupMigration_mxJPO : createPatFamilyForBlockCode]");
		multiWriteMessageToFile(logWriter,"======================================================================================================================");
		multiWriteMessageToFile(logWriter,"CREATE PART FAMILY  "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(logWriter,"Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"======================================================================================================================");
		
		boolean checkTriggerOff = false;
		boolean checkhistroyoff = false;
		try {

			XSSFSheet sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, inputDirectory+fileName, sheetName);
			int sheetPhysicalNumberRows = sheet.getPhysicalNumberOfRows();
			
			totalRowCount = sheetPhysicalNumberRows-1;
			//part Library 
			String stPartLibraryId = "";
			String stPartLibraryName = "Electronic_Parts";
			String stMqlPartLibrary = "temp query bus $1  $2 $3 select $4 dump $5 ";
			String stMqlPartLibraryResult = MqlUtil.mqlCommand(context, stMqlPartLibrary, new String[] { LibraryCentralConstants.TYPE_PART_LIBRARY, stPartLibraryName, cdmConstantsUtil.QUERY_WILDCARD,"id","|"});
			StringList stListMqlPartLibraryResult = new StringList();
			stListMqlPartLibraryResult = FrameworkUtil.split(stMqlPartLibraryResult, "|");
			
			MqlUtil.mqlCommand(context, "Trigger Off");
			checkTriggerOff = true;
			MqlUtil.mqlCommand(context, "history off");
			checkhistroyoff = true;
			
			if(stListMqlPartLibraryResult.size()<2){
				PartLibrary partLibrary = new PartLibrary();
				partLibrary.createObject(context, LibraryCentralConstants.TYPE_PART_LIBRARY, stPartLibraryName, null, "Libraries", "eService Production");
				stPartLibraryId = partLibrary.getId(context);
				//
				String strParentType="";
		    	String strClassName="";
		    	String strClassType="";
		    	
	            DomainObject domainObj = new DomainObject();
	            domainObj.setId(stPartLibraryId);
	            strClassType  =  domainObj.getInfo(context,DomainObject.SELECT_TYPE);
	            BusinessType busType = new BusinessType(strClassType,context.getVault());
	            strParentType= busType.getParent(context);
	            strClassName  =  domainObj.getInfo(context,DomainObject.SELECT_NAME);
	            java.util.Date sysDate = new Date();
	            long lTime = sysDate.getTime();
	            String strInterfaceName = domainObj.getInfo(context, "physicalid");
	            try{
	                String strMQL       =  "add interface $1 type all";
	                ContextUtil.pushContext(context);

	                MqlUtil.mqlCommand(context, strMQL, strInterfaceName);

	                strMQL      = "modify bus $1 $2 $3";
	                MqlUtil.mqlCommand(context, strMQL, stPartLibraryId,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE, strInterfaceName);

	                if(strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_LIBRARIES))
	                {
	                    strMQL      = "modify interface $1 derived $2";
	                    MqlUtil.mqlCommand(context, strMQL, strInterfaceName,LibraryCentralConstants.INTERFACE_CLASSIFICATION_TAXONOMIES);
	                }

				}catch(Exception e)
				{
					e.printStackTrace();
					throw e;
				}finally{
					ContextUtil.popContext(context);
				}
	            try{
	    			Map argsHash = new HashMap();
	    			String[] tempArg = JPO.packArgs(argsHash);
	    			String mqlString="list program $1";
	    			String output=MqlUtil.mqlCommand(context, mqlString,"emxPLMDictionaryProgram");
	    			if(UIUtil.isNotNullAndNotEmpty(output)){
	    				JPO.invoke(context, "emxPLMDictionaryProgram", null, "invalidateCache", tempArg,Integer.class);
	    			}
	    		}catch (MatrixException e) {
	    			throw e;
	    		}
	            
	            
	    		String attOriginator = "Originator";
	    		String sUser = context.getUser();
	            StringBuffer argBuffer = new StringBuffer(100);
	            argBuffer.append("modify bus ");
	    		argBuffer.append(stPartLibraryId);
	    		argBuffer.append(" \"");
	    		argBuffer.append(attOriginator);
	    		argBuffer.append("\" \"");
	    		argBuffer.append(sUser);
	    		argBuffer.append("\"");
	    		String arguments[] = new String[1];
	    		arguments[0] = argBuffer.toString();
	    		emxUtil_mxJPO utilityClass = new emxUtil_mxJPO(context, null);
	    		utilityClass.executeMQLCommands(context, arguments);
				//
			}else{
				stPartLibraryId = (String)stListMqlPartLibraryResult.get(3);
			}
			
			
			
			//Header information is located on line 1
			for (int i = 1; i < sheetPhysicalNumberRows; i++) {
				XSSFRow sheetRow = sheet.getRow(i);
				try{
					sRowNum         = String.valueOf(i+1);
					if (sheetRow == null){
						String errorMessage = "NOT EXIST DATA (ROW NULL)";
						throw new Exception(errorMessage);
					}
					
					
					XSSFCell cell_0 = sheetRow.getCell(0); //Tree Depth
					XSSFCell cell_1 = sheetRow.getCell(1); // 
					XSSFCell cell_2 = sheetRow.getCell(2); //
					XSSFCell cell_3 = sheetRow.getCell(3); //
					XSSFCell cell_4 = sheetRow.getCell(4); // 
				   
					String sTreeDepth  		     =  isVaildNullData(getCellValue(cell_0));
					String sClassificationCode1  = 	isVaildNullData(getCellValue(cell_1));
					String sElectronicPartName1  = 	isVaildNullData(getCellValue(cell_2));
					String sClassificationCode2  = 	isVaildNullData(getCellValue(cell_3));
					String sElectronicPartName2  = 	isVaildNullData(getCellValue(cell_4));
				   
					if(cdmStringUtil.isEmpty(sTreeDepth) || cdmStringUtil.isEmpty(sClassificationCode1) || cdmStringUtil.isEmpty(sElectronicPartName1) ){
						String errorMessage = "REQUIRED DATA DOES NOT EXIST.";
						throw new Exception(errorMessage);
					}
					
					
					String sPartFamilyIdLev1 = ""; 
					String sPartFamilyIdLev2 = ""; 
					String sPartFamilyIdLev3 = ""; 
				   
				   // part family rule have to apply
				   String sPartFamilyNameLev1 = "ElectronicPart";
				   String sPartFamilyNameLev2 = sClassificationCode1+":"+sElectronicPartName1;
				   String sPartFamilyNameLev3 = sClassificationCode1+sClassificationCode2+":"+sElectronicPartName2;
				   
				   String sTempPartFamilyNameLev2 = "";
				   boolean checkSpecialSymbolPartFamilyNameLev2 = false; 
				   if(sPartFamilyNameLev2.contains(",")){
					   sTempPartFamilyNameLev2 = sPartFamilyNameLev2.replaceAll(",", "?");
					   checkSpecialSymbolPartFamilyNameLev2 = true;
				   }
				   if(sPartFamilyNameLev2.contains("'")){
					   sTempPartFamilyNameLev2 = sPartFamilyNameLev2.replaceAll("'", "?");
					   checkSpecialSymbolPartFamilyNameLev2 = true;
				   }
				   
				   String sTempPartFamilyNameLev3 = "";
				   boolean checkSpecialSymbolPartFamilyNameLev3 = false; 
				   if(sPartFamilyNameLev3.contains(",")){
					   sTempPartFamilyNameLev3 = sPartFamilyNameLev3.replaceAll(",", "?");
					   checkSpecialSymbolPartFamilyNameLev3 = true;
				   }
				   if(sPartFamilyNameLev3.contains("'")){
					   sTempPartFamilyNameLev3 = sPartFamilyNameLev3.replaceAll("'", "?");
					   checkSpecialSymbolPartFamilyNameLev3 = true;
				   }
				   //
				   
				   DomainRelationship connectRel = null;
				   if("1".equals(sTreeDepth)){
//					  String partFamilyLevel1 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \""+sPartFamilyNameLev1 +"\" \"*\" where\" attribute[cdm]=='"+sPartFamilyNameLev1+"'\" select id dump | ";
					  String partFamilyLevel1 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \"*\" \"*\"  where \" attribute[cdmPartFamilyBlockCodeName] == '"+sPartFamilyNameLev1+"' \" select id dump | ";
					  String partFamilyLevel1Result = MqlUtil.mqlCommand(context, partFamilyLevel1);
					  StringList checkPartFamilyLevel1 = FrameworkUtil.split(partFamilyLevel1Result, "|");
					   
					  if (checkPartFamilyLevel1.size()<2  ) {
						  
							com.matrixone.apps.library.PartFamily partFamilyLev1 = new com.matrixone.apps.library.PartFamily();
							String sAutoNameLev1 = DomainObject.getAutoGeneratedName(context, "type_PartFamily", "");
							partFamilyLev1.createObject(context, S_TYPE_PART_FAMILY, sAutoNameLev1, null, S_POLICY_CLASSIFICATION, "eService Production");
							partFamilyLev1.setAttributeValue(context,S_ATTRIBUTE_MIGRATION_CHECK, "Y");
							partFamilyLev1.setAttributeValue(context,"cdmPartFamilyBlockCodeName", sPartFamilyNameLev1);
							
							sPartFamilyIdLev1 = partFamilyLev1.getId(context);
							
							//
							String strParentType="";
					    	String strClassName="";
					    	String strClassType="";
					    	
				            DomainObject domainObj = new DomainObject();
				            domainObj.setId(sPartFamilyIdLev1);
				            strClassType  =  domainObj.getInfo(context,DomainObject.SELECT_TYPE);
				            BusinessType busType = new BusinessType(strClassType,context.getVault());
				            strParentType= busType.getParent(context);
				            strClassName  =  domainObj.getInfo(context,DomainObject.SELECT_NAME);
				            java.util.Date sysDate = new Date();
				            long lTime = sysDate.getTime();
				            String strInterfaceName = domainObj.getInfo(context, "physicalid");
				            try{
				                String strMQL       =  "add interface $1 type all";
				                ContextUtil.pushContext(context);

				                MqlUtil.mqlCommand(context, strMQL, strInterfaceName);

				                strMQL      = "modify bus $1 $2 $3";
				                MqlUtil.mqlCommand(context, strMQL, sPartFamilyIdLev1,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE, strInterfaceName);

				                if(strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_LIBRARIES))
				                {
				                    strMQL      = "modify interface $1 derived $2";
				                    MqlUtil.mqlCommand(context, strMQL, strInterfaceName,LibraryCentralConstants.INTERFACE_CLASSIFICATION_TAXONOMIES);
				                }

							}catch(Exception e)
							{
								e.printStackTrace();
								throw e;
							}finally{
								ContextUtil.popContext(context);
							}
				            try{
				    			Map argsHash = new HashMap();
				    			String[] tempArg = JPO.packArgs(argsHash);
				    			String mqlString="list program $1";
				    			String output=MqlUtil.mqlCommand(context, mqlString,"emxPLMDictionaryProgram");
				    			if(UIUtil.isNotNullAndNotEmpty(output)){
				    				JPO.invoke(context, "emxPLMDictionaryProgram", null, "invalidateCache", tempArg,Integer.class);
				    			}
				    		}catch (MatrixException e) {
				    			throw e;
				    		}
				            
				            
				    		String attOriginator = "Originator";
				    		String sUser = context.getUser();
				            StringBuffer argBuffer = new StringBuffer(100);
				            argBuffer.append("modify bus ");
				    		argBuffer.append(sPartFamilyIdLev1);
				    		argBuffer.append(" \"");
				    		argBuffer.append(attOriginator);
				    		argBuffer.append("\" \"");
				    		argBuffer.append(sUser);
				    		argBuffer.append("\"");
				    		String arguments[] = new String[1];
				    		arguments[0] = argBuffer.toString();
				    		emxUtil_mxJPO utilityClass = new emxUtil_mxJPO(context, null);
				    		utilityClass.executeMQLCommands(context, arguments);
							//
							
							
							DomainObject dObjPFLev1 = new DomainObject();
							dObjPFLev1.setId(sPartFamilyIdLev1);
							DomainObject dObjPLLev1 = new DomainObject();
							dObjPLLev1.setId(stPartLibraryId);
							boolean checkPL = dObjPLLev1.exists(context);
							
							connectRel = DomainRelationship.connect(context, dObjPLLev1, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), dObjPFLev1);
							
							
							//
							String[] constructor = {null};
							String parentObjectId=stPartLibraryId; //from 
					        String childObjectId= sPartFamilyIdLev1;  //to 
					        Map aMap = new HashMap();
					        aMap.put ("objectId", parentObjectId);
					        aMap.put ("relationship", LibraryCentralConstants.RELATIONSHIP_SUBCLASS); //rel
					        String objectName=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_NAME);
					        String objectRevision=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_REVISION);
					        String parentPhysicalId=LibraryCentralCommon.getPhysicalIdforObject(context,parentObjectId);
					        if(!(objectRevision.equals(parentPhysicalId))){
//					            
					        	  String mqlQuery="modify bus $1 revision $2 name $3 ";
					              ContextUtil.pushContext(context);
					              MqlUtil.mqlCommand(context, mqlQuery, childObjectId,parentPhysicalId,objectName);
					              ContextUtil.popContext(context);
					        }
							//
					        
					        //

				            String strFromObjectId = stPartLibraryId;
				            String strToObjectId = sPartFamilyIdLev1;
				            DomainObject childObj = new DomainObject(strToObjectId);
				            DomainObject parentObj = new DomainObject(strFromObjectId);
				            String strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
				            String strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);


				            // This block is to check whether the parent object, which the classification object is added with Subclass Relationship
				            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
				            // with the object.  The Classifications(Part Family) created to prior to the installation will not have any interfaces associated
				            // With them.
				            if(strParentInterface == null || "".equals(strParentInterface) || "null".equals(strParentInterface)) {
				                try {
				                    if(createInterfaceObject(context, strFromObjectId) == 0) {
				                        strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
				                        //If this object is type of LIBRARIES, it will have interface, and will not come into this block.
				                        //If this object is type of PartFamily and it is created without Library Central installed, that will fall into this block
				                        //that is why inheriting this interface with INTERFACE_CLASSIFICATION_ORPHANS
				                        String cmd = "modify interface $1 derived $2";
				                        MqlUtil.mqlCommand(context, cmd, true, strParentInterface, LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);

				                        //Get all classified items connected to it and implement the interface on all classified items
				                        SelectList selectStmts = new SelectList(1);
				                        selectStmts.addElement(DomainObject.SELECT_ID);
				                        MapList result = new MapList();
				                        result = (MapList)parentObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
				                        int iSize = result.size();
				                        Map tempMap;
				                        String strObjectId;
				                        for (int k=0;k<iSize;k++ )
				                        {
				                            implementInterfaceOnClassifiedItem(context, strFromObjectId, ((String)((Map)result.get(k)).get("id")));

				                        }

				                    }
				                } catch(Exception ex) {
				                    throw ex;
				                }
				            }
				            // This block is to check whether the classification object,
				            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
				            // with the object.  The Classifications(Part Family) created to prior to the installation of Library Central or created in
				            // previous versions will not have any interfaces associated with them.
				            if(strChildInterface == null || "".equals(strChildInterface) || "null".equals(strChildInterface)) {
				                try {
				                    if(createInterfaceObject(context, strToObjectId) == 0) {
				                        strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);

				                        //Get all classified items connected to it and implement the interface on all classified items
				                        SelectList selectStmts = new SelectList(1);
				                        selectStmts.addElement(DomainObject.SELECT_ID);
				                        MapList result = new MapList();
				                        result = (MapList)childObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
				                        int iSize = result.size();
				                        for (int k=0;k<iSize;k++ )
				                        {
				                            implementInterfaceOnClassifiedItem(context, strToObjectId, ((String)((Map)result.get(k)).get("id")));
				                        }

				                    }
				                } catch(Exception ex) {
				                    throw ex;
				                }
				            }


				            try{
				                // The approach here is as follows:
				                // Get everything that the child's interface is derived from
				                // directly; To that list, add the new parent's interface;
				                // remove mxsysLCOrphans.
				                // The resulting set is what child's interface will be derived from.
				                // This may seem over-complicated, but it is necessary in
				                // conjunction with the optional Multiple Classification Module in
				                // order to avoid attribute data loss.
				                String cmd = "print interface $1 select derived dump $2";
				                String currentParentsCSL = MqlUtil.mqlCommand(context,cmd,true, strChildInterface, ",").trim();

				                StringList currentParentsList = FrameworkUtil.split(currentParentsCSL, ",");
				                currentParentsList.addElement(strParentInterface);
				                currentParentsList.remove(LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
				                String[] parentInterfaces   = new String[currentParentsList.size()+1];
				                parentInterfaces[0]         = strChildInterface;
				                StringBuffer sbQuery        = new StringBuffer("modify interface $1 derived");
				                for (int j = 0 ; j < currentParentsList.size() ; j++) {
				                    sbQuery.append(" $").append(j+2).append(",");
				                    parentInterfaces[j+1] = (String)currentParentsList.get(j);
				                }
				                cmd = sbQuery.substring(0, sbQuery.lastIndexOf(","));

				                String result = MqlUtil.mqlCommand(context, cmd, true, parentInterfaces);


				            }catch(Exception e)
				            {
				                e.printStackTrace();
				                throw e;
				            }

				            
				            String connectTclProg =  "emxUpdateCountOnSubclassConnectDisconnect.tcl";
				            String updateCountConnection = "execute program \""+connectTclProg+"\"  \"" +sPartFamilyIdLev1 + "\" " +  "\"" +stPartLibraryId+ "\"";
				            MQLCommand mqlcommand = new MQLCommand();
							mqlcommand.open(context);
					        mqlcommand.executeCommand(context, updateCountConnection);
							String sResult = mqlcommand.getResult();
							String sError = mqlcommand.getError();
							mqlcommand.close(context);
				            //
							
							
						}else{
//							sPartFamilyIdLev1 = checkPartFamilyLevel1.
							sPartFamilyIdLev1 = (String)checkPartFamilyLevel1.get(3);
//							String errorMessage ="object with the same name already exists";
//							throw new Exception(errorMessage);
						}
					  
				   }else if("2".equals(sTreeDepth)){
					   
//					   String partFamilyLevel1 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \""+sPartFamilyNameLev1 +"\"  \"*\"  select id dump | ";
					   String partFamilyLevel1 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \"*\"  \"*\"  where \" attribute[cdmPartFamilyBlockCodeName] == '"+sPartFamilyNameLev1+"' \"  select id dump | ";
					   String partFamilyLevel1Result = MqlUtil.mqlCommand(context, partFamilyLevel1);
					   StringList checkPartFamilyLevel1 = FrameworkUtil.split(partFamilyLevel1Result, "|");
					   if(checkPartFamilyLevel1.size()>2){
						   sPartFamilyIdLev1 = (String)checkPartFamilyLevel1.get(3);
					   }else{
						   String errorMessage ="level 1 object not exist.";
						   throw new Exception(errorMessage);

					   }
					   
					   
//					   String partFamilyLevel2 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \""+sPartFamilyNameLev2 +"\"  \"*\"  select id dump | ";
					   String partFamilyLevel2 = "";
					   if(checkSpecialSymbolPartFamilyNameLev2){
						   partFamilyLevel2 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \"*\"  \"*\" where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+sTempPartFamilyNameLev2+"' \" select attribute[cdmPartFamilyBlockCodeName]  id dump | ";
					   }else{
						   partFamilyLevel2 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \"*\"  \"*\" where \" attribute[cdmPartFamilyBlockCodeName] == '"+sPartFamilyNameLev2+"' \"  select attribute[cdmPartFamilyBlockCodeName]  id dump | ";
					   }
					   
					   String partFamilyLevel2Result = MqlUtil.mqlCommand(context, partFamilyLevel2);
					   StringList checkPartFamilyLevel2 = FrameworkUtil.split(partFamilyLevel2Result, "|");
					   boolean checkExistSpecialSymbolPartFamilyNameLev2 = false;
					   if(checkSpecialSymbolPartFamilyNameLev2 && checkPartFamilyLevel2.size() > 2){
						   //
						   StringList sListCheckSpecialSymbolPartFamilyLev2Result = new StringList();   
						   sListCheckSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(partFamilyLevel2Result, "\n");
							for (Iterator iterSpecialSymbol = sListCheckSpecialSymbolPartFamilyLev2Result.iterator(); iterSpecialSymbol.hasNext();) {
								String sSpecialSymbolPartFamilyLev2Result = (String) iterSpecialSymbol.next();
								StringList sListSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev2Result, "|");
								String tempPartFamily2Attr = (String) sListSpecialSymbolPartFamilyLev2Result.get(3);
								if (cdmStringUtil.isNotEmpty(tempPartFamily2Attr) && tempPartFamily2Attr.equals(sPartFamilyNameLev2)) {
									checkExistSpecialSymbolPartFamilyNameLev2 = true;
									break;
								}
							}
						   
					   }
					   
						if (checkPartFamilyLevel2.size() < 2 && !checkExistSpecialSymbolPartFamilyNameLev2) {
							
							com.matrixone.apps.library.PartFamily partFamilyLev2 = new com.matrixone.apps.library.PartFamily();
							String sAutoNameLev2 = DomainObject.getAutoGeneratedName(context, "type_PartFamily", ""); 
							partFamilyLev2.createObject(context, S_TYPE_PART_FAMILY, sAutoNameLev2, null, S_POLICY_CLASSIFICATION, "eService Production");
//							partFamilyLev2.createObject(context, S_TYPE_PART_FAMILY, sPartFamilyNameLev2, null, S_POLICY_CLASSIFICATION, "eService Production");
							partFamilyLev2.setAttributeValue(context, S_ATTRIBUTE_MIGRATION_CHECK, "Y");
							partFamilyLev2.setAttributeValue(context, "cdmPartFamilyBlockCodeName", sPartFamilyNameLev2);

							sPartFamilyIdLev2 = partFamilyLev2.getId(context);

							//
							String strParentType = "";
							String strClassName = "";
							String strClassType = "";

							DomainObject domainObj = new DomainObject();
							domainObj.setId(sPartFamilyIdLev2);
							strClassType = domainObj.getInfo(context, DomainObject.SELECT_TYPE);
							BusinessType busType = new BusinessType(strClassType, context.getVault());
							strParentType = busType.getParent(context);
							strClassName = domainObj.getInfo(context, DomainObject.SELECT_NAME);
							java.util.Date sysDate = new Date();
							long lTime = sysDate.getTime();
							String strInterfaceName = domainObj.getInfo(context, "physicalid");
							try {
								String strMQL = "add interface $1 type all";
								ContextUtil.pushContext(context);

								MqlUtil.mqlCommand(context, strMQL, strInterfaceName);

								strMQL = "modify bus $1 $2 $3";
								MqlUtil.mqlCommand(context, strMQL, sPartFamilyIdLev2, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE, strInterfaceName);

								if (strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_LIBRARIES)) {
									strMQL = "modify interface $1 derived $2";
									MqlUtil.mqlCommand(context, strMQL, strInterfaceName, LibraryCentralConstants.INTERFACE_CLASSIFICATION_TAXONOMIES);
								}

							} catch (Exception e) {
								e.printStackTrace();
								throw e;
							} finally {
								ContextUtil.popContext(context);
							}
							try {
								Map argsHash = new HashMap();
								String[] tempArg = JPO.packArgs(argsHash);
								String mqlString = "list program $1";
								String output = MqlUtil.mqlCommand(context, mqlString, "emxPLMDictionaryProgram");
								if (UIUtil.isNotNullAndNotEmpty(output)) {
									JPO.invoke(context, "emxPLMDictionaryProgram", null, "invalidateCache", tempArg, Integer.class);
								}
							} catch (MatrixException e) {
								throw e;
							}

							String attOriginator = "Originator";
							String sUser = context.getUser();
							StringBuffer argBuffer = new StringBuffer(100);
							argBuffer.append("modify bus ");
							argBuffer.append(sPartFamilyIdLev2);
							argBuffer.append(" \"");
							argBuffer.append(attOriginator);
							argBuffer.append("\" \"");
							argBuffer.append(sUser);
							argBuffer.append("\"");
							String arguments[] = new String[1];
							arguments[0] = argBuffer.toString();
							emxUtil_mxJPO utilityClass = new emxUtil_mxJPO(context, null);
							utilityClass.executeMQLCommands(context, arguments);
							//

							DomainObject dObjPFLev1 = new DomainObject();
							dObjPFLev1.setId(sPartFamilyIdLev1);

							DomainObject dObjPFLev2 = new DomainObject();
							dObjPFLev2.setId(sPartFamilyIdLev2);

							connectRel = DomainRelationship.connect(context, dObjPFLev1, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), dObjPFLev2);

							//
							String[] constructor = { null };
							String parentObjectId = sPartFamilyIdLev1; // from
							String childObjectId = sPartFamilyIdLev2; // to
							Map aMap = new HashMap();
							aMap.put("objectId", parentObjectId);
							aMap.put("relationship", LibraryCentralConstants.RELATIONSHIP_SUBCLASS); // rel
							String objectName = new DomainObject(childObjectId).getInfo(context, DomainConstants.SELECT_NAME);
							String objectRevision = new DomainObject(childObjectId).getInfo(context, DomainConstants.SELECT_REVISION);
							String parentPhysicalId = LibraryCentralCommon.getPhysicalIdforObject(context, parentObjectId);
							if (!(objectRevision.equals(parentPhysicalId))) {
								// changeRevisiontoPhysicalId(context,childObjectId,objectName,parentPhysicalId);
								String mqlQuery = "modify bus $1 revision $2 name $3 ";
								ContextUtil.pushContext(context);
								MqlUtil.mqlCommand(context, mqlQuery, childObjectId, parentPhysicalId, objectName);
								ContextUtil.popContext(context);
							}
							//

							//

							String strFromObjectId = sPartFamilyIdLev1;
							String strToObjectId = sPartFamilyIdLev2;
							DomainObject childObj = new DomainObject(strToObjectId);
							DomainObject parentObj = new DomainObject(strFromObjectId);
							String strParentInterface = parentObj.getAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
							String strChildInterface = childObj.getAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);

							// This block is to check whether the parent object,
							// which the classification object is added with
							// Subclass Relationship
							// has an interface associated with it, if it does
							// not have an interface associated with it will
							// create an interface and associate
							// with the object. The Classifications(Part Family)
							// created to prior to the installation will not
							// have any interfaces associated
							// With them.
							if (strParentInterface == null || "".equals(strParentInterface) || "null".equals(strParentInterface)) {
								try {
									if (createInterfaceObject(context, strFromObjectId) == 0) {
										strParentInterface = parentObj.getAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
										// If this object is type of LIBRARIES,
										// it will have interface, and will not
										// come into this block.
										// If this object is type of PartFamily
										// and it is created without Library
										// Central installed, that will fall
										// into this block
										// that is why inheriting this interface
										// with INTERFACE_CLASSIFICATION_ORPHANS
										String cmd = "modify interface $1 derived $2";
										MqlUtil.mqlCommand(context, cmd, true, strParentInterface, LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);

										// Get all classified items connected to
										// it and implement the interface on all
										// classified items
										SelectList selectStmts = new SelectList(1);
										selectStmts.addElement(DomainObject.SELECT_ID);
										MapList result = new MapList();
										result = (MapList) parentObj.getRelatedObjects(context, LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM, LibraryCentralConstants.QUERY_WILDCARD, selectStmts, new StringList(), false, true, (short) 1, null, null);
										int iSize = result.size();
										Map tempMap;
										String strObjectId;
										for (int k = 0; k < iSize; k++) {
											implementInterfaceOnClassifiedItem(context, strFromObjectId, ((String) ((Map) result.get(k)).get("id")));

										}

									}
								} catch (Exception ex) {
									throw ex;
								}
							}
							// This block is to check whether the classification
							// object,
							// has an interface associated with it, if it does
							// not have an interface associated with it will
							// create an interface and associate
							// with the object. The Classifications(Part Family)
							// created to prior to the installation of Library
							// Central or created in
							// previous versions will not have any interfaces
							// associated with them.
							if (strChildInterface == null || "".equals(strChildInterface) || "null".equals(strChildInterface)) {
								try {
									if (createInterfaceObject(context, strToObjectId) == 0) {
										strChildInterface = childObj.getAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);

										// Get all classified items connected to
										// it and implement the interface on all
										// classified items
										SelectList selectStmts = new SelectList(1);
										selectStmts.addElement(DomainObject.SELECT_ID);
										MapList result = new MapList();
										result = (MapList) childObj.getRelatedObjects(context, LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM, LibraryCentralConstants.QUERY_WILDCARD, selectStmts, new StringList(), false, true, (short) 1, null, null);
										int iSize = result.size();
										for (int k = 0; k < iSize; k++) {
											implementInterfaceOnClassifiedItem(context, strToObjectId, ((String) ((Map) result.get(k)).get("id")));
										}

									}
								} catch (Exception ex) {
									throw ex;
								}
							}

							try {
								// The approach here is as follows:
								// Get everything that the child's interface is
								// derived from
								// directly; To that list, add the new parent's
								// interface;
								// remove mxsysLCOrphans.
								// The resulting set is what child's interface
								// will be derived from.
								// This may seem over-complicated, but it is
								// necessary in
								// conjunction with the optional Multiple
								// Classification Module in
								// order to avoid attribute data loss.
								String cmd = "print interface $1 select derived dump $2";
								String currentParentsCSL = MqlUtil.mqlCommand(context, cmd, true, strChildInterface, ",").trim();

								StringList currentParentsList = FrameworkUtil.split(currentParentsCSL, ",");
								currentParentsList.addElement(strParentInterface);
								currentParentsList.remove(LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
								String[] parentInterfaces = new String[currentParentsList.size() + 1];
								parentInterfaces[0] = strChildInterface;
								StringBuffer sbQuery = new StringBuffer("modify interface $1 derived");
								for (int j = 0; j < currentParentsList.size(); j++) {
									sbQuery.append(" $").append(j + 2).append(",");
									parentInterfaces[j + 1] = (String) currentParentsList.get(j);
								}
								cmd = sbQuery.substring(0, sbQuery.lastIndexOf(","));

								String result = MqlUtil.mqlCommand(context, cmd, true, parentInterfaces);

							} catch (Exception e) {
								e.printStackTrace();
								throw e;
							}

							String connectTclProg = "emxUpdateCountOnSubclassConnectDisconnect.tcl";
							String updateCountConnection = "execute program \"" + connectTclProg + "\"  \"" + sPartFamilyIdLev2 + "\" " + "\"" + sPartFamilyIdLev1 + "\"";
							MQLCommand mqlcommand = new MQLCommand();
							mqlcommand.open(context);
							mqlcommand.executeCommand(context, updateCountConnection);
							String sResult = mqlcommand.getResult();
							String sError = mqlcommand.getError();
							mqlcommand.close(context);
							
							//
						}else{
							String errorMessage ="level2 object with the same name already exists or level 1 object not exist.";
							throw new Exception(errorMessage);
					   }
				   }else if("3".equals(sTreeDepth)){
					   String partFamilyLevel2 =  "";
					   
					   if(checkSpecialSymbolPartFamilyNameLev2){
						   partFamilyLevel2 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \"*\"  \"*\" where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+sTempPartFamilyNameLev2+"' \"   select attribute[cdmPartFamilyBlockCodeName] id dump | ";
					   }else{
						   
						   partFamilyLevel2 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \"*\"  \"*\" where \" attribute[cdmPartFamilyBlockCodeName] == '"+sPartFamilyNameLev2+"' \"   select attribute[cdmPartFamilyBlockCodeName] id dump | ";
					   }
//					   String partFamilyLevel2 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \""+sPartFamilyNameLev2 +"\"  \"*\"  select id dump | ";
					   String partFamilyLevel2Result = MqlUtil.mqlCommand(context, partFamilyLevel2);
					   StringList checkPartFamilyLevel2 = FrameworkUtil.split(partFamilyLevel2Result, "|");
					   
					   boolean bExistCheckSpecialSymbolLevel2 = false;
					   if(checkSpecialSymbolPartFamilyNameLev2 && checkPartFamilyLevel2.size()>2){
						   //
						   StringList sListCheckSpecialSymbolPartFamilyLev2Result = new StringList();   
						   sListCheckSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(partFamilyLevel2Result, "\n");
							for (Iterator iterSpecialSymbol = sListCheckSpecialSymbolPartFamilyLev2Result.iterator(); iterSpecialSymbol.hasNext();) {
								String sSpecialSymbolPartFamilyLev2Result = (String) iterSpecialSymbol.next();
								StringList sListSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev2Result, "|");
								String tempPartFamily2Name = (String) sListSpecialSymbolPartFamilyLev2Result.get(3);
								if (cdmStringUtil.isNotEmpty(tempPartFamily2Name) && tempPartFamily2Name.equals(sPartFamilyNameLev2)) {
									sPartFamilyIdLev2 = (String) sListSpecialSymbolPartFamilyLev2Result.get(4);
									bExistCheckSpecialSymbolLevel2 = true;
									sPartFamilyIdLev2 = (String)checkPartFamilyLevel2.get(4);
									break;
								}
							}
						   //
					   }
					   
					   if(checkPartFamilyLevel2.size()>2 && !checkSpecialSymbolPartFamilyNameLev2){
						   sPartFamilyIdLev2 = (String)checkPartFamilyLevel2.get(4);
					   }else{
						  
						   if(!bExistCheckSpecialSymbolLevel2){
							   String errorMessage ="level 2 object not exist.";
							   throw new Exception(errorMessage);
						   }

					   }
					   
					   String partFamilyLevel3 = "";
					   if(checkSpecialSymbolPartFamilyNameLev3){
						   partFamilyLevel3 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \"*\"  \"*\" where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+sTempPartFamilyNameLev3+"' \"  select id dump | ";   
					   }else{
						   partFamilyLevel3 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \"*\"  \"*\" where \" attribute[cdmPartFamilyBlockCodeName] == '"+sPartFamilyNameLev3+"' \"  select id dump | ";
					   }
					   
//					   String partFamilyLevel3 = "temp query bus \""+S_TYPE_PART_FAMILY+"\"  \""+sPartFamilyNameLev3 +"\"  \"*\"  select id dump | ";
					   
					   String partFamilyLevel3Result = MqlUtil.mqlCommand(context, partFamilyLevel3);
					   StringList checkPartFamilyLevel3 = FrameworkUtil.split(partFamilyLevel3Result, "|");
					   //
					   boolean bExistCheckSpecialSymbolLevel3 = false;
					   if(checkSpecialSymbolPartFamilyNameLev3 && checkPartFamilyLevel3.size()>2){
						   //
						   StringList sListCheckSpecialSymbolPartFamilyLev3Result = new StringList();   
						   sListCheckSpecialSymbolPartFamilyLev3Result = FrameworkUtil.split(partFamilyLevel3Result, "\n");
							for (Iterator iterSpecialSymbol = sListCheckSpecialSymbolPartFamilyLev3Result.iterator(); iterSpecialSymbol.hasNext();) {
								String sSpecialSymbolPartFamilyLev3Result = (String) iterSpecialSymbol.next();
								StringList sListSpecialSymbolPartFamilyLev3Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev3Result, "|");
								String tempPartFamily3Attr = (String) sListSpecialSymbolPartFamilyLev3Result.get(3);
								if (cdmStringUtil.isNotEmpty(tempPartFamily3Attr) && tempPartFamily3Attr.equals(sPartFamilyNameLev3)) {
									bExistCheckSpecialSymbolLevel3 = true;
									break;
								}
							}
						   //
					   }
					   //
					   
						if (checkPartFamilyLevel3.size() < 2 || !bExistCheckSpecialSymbolLevel3) {
							
							com.matrixone.apps.library.PartFamily partFamilyLev3 = new com.matrixone.apps.library.PartFamily();
							String sAutoNameLev3 = DomainObject.getAutoGeneratedName(context, "type_PartFamily", "");
							partFamilyLev3.createObject(context, S_TYPE_PART_FAMILY, sAutoNameLev3, null, S_POLICY_CLASSIFICATION, "eService Production");
//							partFamilyLev3.createObject(context, S_TYPE_PART_FAMILY, sPartFamilyNameLev3, null, S_POLICY_CLASSIFICATION, "eService Production");
							partFamilyLev3.setAttributeValue(context, "cdmPartFamilyBlockCodeName", sPartFamilyNameLev3);
							partFamilyLev3.setAttributeValue(context, S_ATTRIBUTE_MIGRATION_CHECK, "Y");
							partFamilyLev3.setAttributeValue(context, "cdmDescription", sElectronicPartName2);
							sPartFamilyIdLev3 = partFamilyLev3.getId(context);

							//
							String strParentType = "";
							String strClassName = "";
							String strClassType = "";

							DomainObject domainObj = new DomainObject();
							domainObj.setId(sPartFamilyIdLev3);
							strClassType = domainObj.getInfo(context, DomainObject.SELECT_TYPE);
							BusinessType busType = new BusinessType(strClassType, context.getVault());
							strParentType = busType.getParent(context);
							strClassName = domainObj.getInfo(context, DomainObject.SELECT_NAME);
							java.util.Date sysDate = new Date();
							long lTime = sysDate.getTime();
							String strInterfaceName = domainObj.getInfo(context, "physicalid");
							try {
								String strMQL = "add interface $1 type all";
								ContextUtil.pushContext(context);

								MqlUtil.mqlCommand(context, strMQL, strInterfaceName);

								strMQL = "modify bus $1 $2 $3";
								MqlUtil.mqlCommand(context, strMQL, sPartFamilyIdLev3, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE, strInterfaceName);

								if (strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_LIBRARIES)) {
									strMQL = "modify interface $1 derived $2";
									MqlUtil.mqlCommand(context, strMQL, strInterfaceName, LibraryCentralConstants.INTERFACE_CLASSIFICATION_TAXONOMIES);
								}

							} catch (Exception e) {
								e.printStackTrace();
								throw e;
							} finally {
								ContextUtil.popContext(context);
							}
//							try {
//								Map argsHash = new HashMap();
//								String[] tempArg = JPO.packArgs(argsHash);
//								String mqlString = "list program $1";
//								String output = MqlUtil.mqlCommand(context, mqlString, "emxPLMDictionaryProgram");
//								if (UIUtil.isNotNullAndNotEmpty(output)) {
//									JPO.invoke(context, "emxPLMDictionaryProgram", null, "invalidateCache", tempArg, Integer.class);
//								}
//							} catch (MatrixException e) {
//								throw e;
//							}

							String attOriginator = "Originator";
							String sUser = context.getUser();
							StringBuffer argBuffer = new StringBuffer(100);
							argBuffer.append("modify bus ");
							argBuffer.append(sPartFamilyIdLev3);
							argBuffer.append(" \"");
							argBuffer.append(attOriginator);
							argBuffer.append("\" \"");
							argBuffer.append(sUser);
							argBuffer.append("\"");
							String arguments[] = new String[1];
							arguments[0] = argBuffer.toString();
							emxUtil_mxJPO utilityClass = new emxUtil_mxJPO(context, null);
							utilityClass.executeMQLCommands(context, arguments);
							//

							DomainObject dObjPFLev2 = new DomainObject();
							dObjPFLev2.setId(sPartFamilyIdLev2);

							DomainObject dObjPFLev3 = new DomainObject();
							dObjPFLev3.setId(sPartFamilyIdLev3);

							connectRel = DomainRelationship.connect(context, dObjPFLev2, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), dObjPFLev3);

							//
							String[] constructor = { null };
							String parentObjectId = sPartFamilyIdLev2; // from
							String childObjectId = sPartFamilyIdLev3; // to
							Map aMap = new HashMap();
							aMap.put("objectId", parentObjectId);
							aMap.put("relationship", LibraryCentralConstants.RELATIONSHIP_SUBCLASS); // rel
							String objectName = new DomainObject(childObjectId).getInfo(context, DomainConstants.SELECT_NAME);
							String objectRevision = new DomainObject(childObjectId).getInfo(context, DomainConstants.SELECT_REVISION);
							String parentPhysicalId = LibraryCentralCommon.getPhysicalIdforObject(context, parentObjectId);
							if (!(objectRevision.equals(parentPhysicalId))) {
								// changeRevisiontoPhysicalId(context,childObjectId,objectName,parentPhysicalId);
								String mqlQuery = "modify bus $1 revision $2 name $3 ";
								ContextUtil.pushContext(context);
								MqlUtil.mqlCommand(context, mqlQuery, childObjectId, parentPhysicalId, objectName);
								ContextUtil.popContext(context);
							}
							//

							//
							String strFromObjectId = sPartFamilyIdLev2;
							String strToObjectId = sPartFamilyIdLev3;
							DomainObject childObj = new DomainObject(strToObjectId);
							DomainObject parentObj = new DomainObject(strFromObjectId);
							String strParentInterface = parentObj.getAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
							String strChildInterface = childObj.getAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);

							// This block is to check whether the parent object,
							// which the classification object is added with
							// Subclass Relationship
							// has an interface associated with it, if it does
							// not have an interface associated with it will
							// create an interface and associate
							// with the object. The Classifications(Part Family)
							// created to prior to the installation will not
							// have any interfaces associated
							// With them.
							if (strParentInterface == null || "".equals(strParentInterface) || "null".equals(strParentInterface)) {
								try {
									if (createInterfaceObject(context, strFromObjectId) == 0) {
										strParentInterface = parentObj.getAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
										// If this object is type of LIBRARIES,
										// it will have interface, and will not
										// come into this block.
										// If this object is type of PartFamily
										// and it is created without Library
										// Central installed, that will fall
										// into this block
										// that is why inheriting this interface
										// with INTERFACE_CLASSIFICATION_ORPHANS
										String cmd = "modify interface $1 derived $2";
										MqlUtil.mqlCommand(context, cmd, true, strParentInterface, LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);

										// Get all classified items connected to
										// it and implement the interface on all
										// classified items
										SelectList selectStmts = new SelectList(1);
										selectStmts.addElement(DomainObject.SELECT_ID);
										MapList result = new MapList();
										result = (MapList) parentObj.getRelatedObjects(context, LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM, LibraryCentralConstants.QUERY_WILDCARD, selectStmts, new StringList(), false, true, (short) 1, null, null);
										int iSize = result.size();
										Map tempMap;
										String strObjectId;
										for (int k = 0; k < iSize; k++) {
											implementInterfaceOnClassifiedItem(context, strFromObjectId, ((String) ((Map) result.get(k)).get("id")));

										}

									}
								} catch (Exception ex) {
									throw ex;
								}
							}
							// This block is to check whether the classification
							// object,
							// has an interface associated with it, if it does
							// not have an interface associated with it will
							// create an interface and associate
							// with the object. The Classifications(Part Family)
							// created to prior to the installation of Library
							// Central or created in
							// previous versions will not have any interfaces
							// associated with them.
							if (strChildInterface == null || "".equals(strChildInterface) || "null".equals(strChildInterface)) {
								try {
									if (createInterfaceObject(context, strToObjectId) == 0) {
										strChildInterface = childObj.getAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);

										// Get all classified items connected to
										// it and implement the interface on all
										// classified items
										SelectList selectStmts = new SelectList(1);
										selectStmts.addElement(DomainObject.SELECT_ID);
										MapList result = new MapList();
										result = (MapList) childObj.getRelatedObjects(context, LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM, LibraryCentralConstants.QUERY_WILDCARD, selectStmts, new StringList(), false, true, (short) 1, null, null);
										int iSize = result.size();
										for (int k = 0; k < iSize; k++) {
											implementInterfaceOnClassifiedItem(context, strToObjectId, ((String) ((Map) result.get(k)).get("id")));
										}

									}
								} catch (Exception ex) {
									throw ex;
								}
							}

							try {
								// The approach here is as follows:
								// Get everything that the child's interface is
								// derived from
								// directly; To that list, add the new parent's
								// interface;
								// remove mxsysLCOrphans.
								// The resulting set is what child's interface
								// will be derived from.
								// This may seem over-complicated, but it is
								// necessary in
								// conjunction with the optional Multiple
								// Classification Module in
								// order to avoid attribute data loss.
								String cmd = "print interface $1 select derived dump $2";
								String currentParentsCSL = MqlUtil.mqlCommand(context, cmd, true, strChildInterface, ",").trim();

								StringList currentParentsList = FrameworkUtil.split(currentParentsCSL, ",");
								currentParentsList.addElement(strParentInterface);
								currentParentsList.remove(LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
								String[] parentInterfaces = new String[currentParentsList.size() + 1];
								parentInterfaces[0] = strChildInterface;
								StringBuffer sbQuery = new StringBuffer("modify interface $1 derived");
								for (int j = 0; j < currentParentsList.size(); j++) {
									sbQuery.append(" $").append(j + 2).append(",");
									parentInterfaces[j + 1] = (String) currentParentsList.get(j);
								}
								cmd = sbQuery.substring(0, sbQuery.lastIndexOf(","));

								String result = MqlUtil.mqlCommand(context, cmd, true, parentInterfaces);

							} catch (Exception e) {
								e.printStackTrace();
								throw e;
							}

							String connectTclProg = "emxUpdateCountOnSubclassConnectDisconnect.tcl";
							String updateCountConnection = "execute program \"" + connectTclProg + "\"  \"" + sPartFamilyIdLev2 + "\" " + "\"" + sPartFamilyIdLev3 + "\"";
							MQLCommand mqlcommand = new MQLCommand();
							mqlcommand.open(context);
							mqlcommand.executeCommand(context, updateCountConnection);
							String sResult = mqlcommand.getResult();
							String sError = mqlcommand.getError();
							mqlcommand.close(context);
							
							//
						}else{
						   String errorMessage ="level3 object with the same name already exists or level 2 object not exist.";
							throw new Exception(errorMessage);
					   }
				   }
					
				   
				   
				   multiWriteMessageToFile(successObjectidWriter,"SUCCESS. LINE NUMBER: "+sRowNum);
				   successRowCount++;
				}catch(Exception e1){
					failRowCount++;
//					ContextUtil.abortTransaction(context);
					
					multiWriteMessageToFile(logWriter,sRowNum+"\t " + e1.getMessage());
					mulitWriteErrorToFile( errorStream," LINE NUMBER: "+sRowNum+" \t " + e1.getMessage());
					e1.printStackTrace(errorStream);
					multiWriteMessageToFile(failedObjectidWriter,sRowNum+"\t " + e1.getMessage());
				}
			
			}
			
			multiWriteMessageToFile(logWriter,"======================================================================================================================");
			multiWriteMessageToFile(logWriter,"	File CREATE PARTFAMILY OBJECT Migration COMPLETED.                    ");
			multiWriteMessageToFile(logWriter,"======================================================================================================================\n");
		} catch (Exception e) {
			e.printStackTrace(errorStream);
		}finally{
			if(checkTriggerOff){
				MqlUtil.mqlCommand(context, "Trigger on");
				checkTriggerOff = false;
			}
			if(checkhistroyoff){
				MqlUtil.mqlCommand(context, "history on");
				checkhistroyoff = false;
			}
			
			multiWriteMessageToFile(logWriter,"======================================================================================================================");
			multiWriteMessageToFile(logWriter,"	CREATE PARTFAMILY OBJECT CLOSE TIME:  "+getTimeStamp()+"          \n"  );
			multiWriteMessageToFile(logWriter,"	CREATE PARTFAMILY OBJECT MIGRATION LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms       "  );
			multiWriteMessageToFile(logWriter,"	SUCCESS ROW: ("+ successRowCount+") FAIL ROW:("+failRowCount+") TOTAL ROW: ("+totalRowCount +")               "  );
			multiWriteMessageToFile(logWriter,"======================================================================================================================\n");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			
			System.out.println(" cdmAttributeGroupMigration_mxJPO : createPartFamilyForElectronicPart() finish ");
		}
	
	}
	
	/**
	 * @param data
	 * @return
	 */
	public String isVaildNullData(String data) {
		return ((data == null || "null".equals(data)) ? "" : data.trim());
	}

	private void mulitWriteErrorToFile(PrintStream pStrem , String message) throws Exception {
		pStrem.write(message.getBytes("UTF-8"));
		pStrem.write("\n".getBytes("UTF-8"));
		pStrem.flush();
//		return pStrem;
	}
	private void multiWriteMessageToFile(BufferedWriter buff, String message) throws Exception {
		buff.write(message + "\n");
		buff.flush();

	}
	private String getTimeStamp() {
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date) + "__" + new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}
	
	/**
	 * @param cell
	 * @return
	 * @throws Exception
	 */
	public static String getCellValue(XSSFCell cell) throws Exception {
		String st = new String("");
		try {
			if (cell == null)
				return "";

			switch (cell.getCellType()) {

			case XSSFCell.CELL_TYPE_NUMERIC:

				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd H:mm");
					st = formatter.format(cell.getDateCellValue());
				} else {
					double numbericCellValue = cell.getNumericCellValue();
					String value = String.valueOf(numbericCellValue);
					StringList stListValue = FrameworkUtil.split(value, ".");
					if (stListValue.size() > 1) {
						String endSt = (String) stListValue.get(1);
						value = endSt.equals("0") ? (String) stListValue.get(0) : value;
					}

					st = value;
				}

				break;

			case XSSFCell.CELL_TYPE_FORMULA:

				st = String.valueOf(cell.getCellFormula());

				break;

			case XSSFCell.CELL_TYPE_STRING:

				st = String.valueOf(cell.getStringCellValue());

				break;

			case XSSFCell.CELL_TYPE_BLANK:

				st = String.valueOf(cell.getBooleanCellValue());
				
				break;

			case XSSFCell.CELL_TYPE_ERROR:

				st = String.valueOf(cell.getErrorCellValue());
				break;

			default:
				break;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return st;

	}

	
	public static String getCellValue2(Cell cell) throws Exception {
		String st = new String("");
		try {
			if (cell == null)
				return "";

			switch (cell.getCellType()) {

			case Cell.CELL_TYPE_NUMERIC:

				if (HSSFDateUtil.isCellDateFormatted(cell)) {
					SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd H:mm");
					st = formatter.format(cell.getDateCellValue());
				} else {
					double numbericCellValue = cell.getNumericCellValue();
					String value = String.valueOf(numbericCellValue);
					StringList stListValue = FrameworkUtil.split(value, ".");
					if (stListValue.size() > 1) {
						String endSt = (String) stListValue.get(1);
						value = endSt.equals("0") ? (String) stListValue.get(0) : value;
					}

					st = value;
				}

				break;

			case Cell.CELL_TYPE_FORMULA:

				st = String.valueOf(cell.getCellFormula());

				break;

			case Cell.CELL_TYPE_STRING:

				st = String.valueOf(cell.getStringCellValue());

				break;

			case Cell.CELL_TYPE_BLANK:

				st = String.valueOf(cell.getBooleanCellValue());
				
				break;

			case XSSFCell.CELL_TYPE_ERROR:

				st = String.valueOf(cell.getErrorCellValue());
				break;

			default:
				break;

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return st;

	}
	

	
	
	 /**
     * Creates the interface Object
     *
     * @param context the eMatrix <code>Context</code> object
     * @param objectId the objectId
     * @return int 0 or 1 for Success or failure
     * @throws Exception if the operation fails
     */
    public int createInterfaceObject(Context context, String objectId) throws
        Exception
    {
    	String strParentType="";
    	String strClassName="";
    	String strClassType="";
        if(objectId != null && !"".equals(objectId) && !"null".equals(objectId))
        {
            DomainObject domainObj = new DomainObject();
            domainObj.setId(objectId);
            strClassType  =  domainObj.getInfo(context,DomainObject.SELECT_TYPE);
            BusinessType busType = new BusinessType(strClassType,context.getVault());
            strParentType= busType.getParent(context);
            strClassName  =  domainObj.getInfo(context,DomainObject.SELECT_NAME);
            java.util.Date sysDate = new Date();
            long lTime = sysDate.getTime();
            String strInterfaceName = domainObj.getInfo(context, "physicalid");
            try{
                String strMQL       =  "add interface $1 type all";
                ContextUtil.pushContext(context);

                MqlUtil.mqlCommand(context, strMQL, strInterfaceName);

                strMQL      = "modify bus $1 $2 $3";
                MqlUtil.mqlCommand(context, strMQL, objectId,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE, strInterfaceName);

                if(strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_LIBRARIES))
                {
                    strMQL      = "modify interface $1 derived $2";
                    MqlUtil.mqlCommand(context, strMQL, strInterfaceName,LibraryCentralConstants.INTERFACE_CLASSIFICATION_TAXONOMIES);
                }

			}catch(Exception e)
			{
				e.printStackTrace();
				throw e;
			}finally{
				ContextUtil.popContext(context);
			}
		}
//        try{
//            if(UIUtil.isNotNullAndNotEmpty(strClassType) && strClassType.equalsIgnoreCase(LibraryCentralConstants.TYPE_GENERAL_LIBRARY)){
//            	createLibraryFeatureReference(context,objectId,strClassName);
//           }
//
//        }catch (Exception e) {
//        	e.printStackTrace();
//        	throw e;
//			// TODO: handle exception
//		}
		//TO invalidate VPLM Cache
		try{
			Map argsHash = new HashMap();
			String[] args = JPO.packArgs(argsHash);
			String mqlString="list program $1";
			String output=MqlUtil.mqlCommand(context, mqlString,"emxPLMDictionaryProgram");
			if(UIUtil.isNotNullAndNotEmpty(output)){
				JPO.invoke(context, "emxPLMDictionaryProgram", null, "invalidateCache", args,Integer.class);
			}
		}catch (MatrixException e) {
			throw e;
		}
		finally{
			return 0;
		}
	}
    
    /**
     * Implements interface on Classified Items
     *
     * @param context the eMatrix <code>Context</code> object
     * @param parentId parrent objectID
     * @param objectId
     * @return int 0 or 1 for Success or failure
     * @throws Exception if the operation fails
     * @throws FrameworkException if the operation fails
     */
    public static String implementInterfaceOnClassifiedItem(Context context, String parentId, String objectId) throws
        Exception,FrameworkException
    {
        String strResult = "";
        DomainObject doObj = new DomainObject(parentId);
        String strInterface = doObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);

        try{
            String strMQL       = "print bus $1 select interface dump";
            strResult           = MqlUtil.mqlCommand(context, strMQL, objectId);
            ContextUtil.pushContext(context);

            if(strResult != null && strResult.indexOf(strInterface) == -1)
            {
                strMQL      = "modify bus $1 add interface $2";
                strResult   = MqlUtil.mqlCommand(context, strMQL, objectId,strInterface);

                if(strResult.indexOf(LibraryCentralConstants.INTERFACE_CLASSIFICATION_SEARCH_FILTER) != -1)
                {
                    strMQL      ="modify bus $1 remove interface $2";
                    strResult   = MqlUtil.mqlCommand(context, strMQL, objectId,LibraryCentralConstants.INTERFACE_CLASSIFICATION_SEARCH_FILTER);
                }

                //Changes Added for Designer Central - Integration
                DomainObject toObject = new DomainObject(objectId);
                String implementIntOnMinorObjs = EnoviaResourceBundle.getProperty(context,"emxLibraryCentral.MinorObjects.Classify");
                
                if(CommonDocument.TYPE_DOCUMENTS.equals(CommonDocument.getParentType(context, toObject.getInfo(context, DomainObject.SELECT_TYPE)))
                    && (implementIntOnMinorObjs != null && implementIntOnMinorObjs.equalsIgnoreCase("true"))){
                    //Get all version objects (minor objects)connected with Active Version relationship
                    StringList selectStmts = new StringList(2);
                    selectStmts.addElement(DomainObject.SELECT_ID);
                    selectStmts.addElement(SELECT_ACTIVE_VERSION_ID);
                    selectStmts.addElement("interface");
                    MapList result = (MapList)toObject.getRelatedObjects(context,
                                                                         CommonDocument.RELATIONSHIP_ACTIVE_VERSION,
                                                                         "*", selectStmts,
                                                                         new StringList(),
                                                                         false, true, (short)1, null, null);

                    String activeVersionId = "";
                    String implementedInterfaces = "";
                    if (result != null && result.size() > 0) {
                        for(int lCnt = 0; lCnt < result.size(); lCnt ++) {
                           Map objMap = (Map)result.get(lCnt);
                           activeVersionId = (String)objMap.get(DomainObject.SELECT_ID);

                           //check if there are more than one interfaces
                           //and act accordingly
                           Object interfaces = (Object)objMap.get("interface");

                           String interfaceStr = "";
                           StringList interfacesList = null;

                           boolean moreThanOneInterfaces = false;
                           boolean addInterface = false;

                           if(interfaces instanceof String)
                           {
                               interfaceStr = (String)interfaces;
                           }
                           else if(interfaces instanceof StringList)
                           {
                               moreThanOneInterfaces = true;
                               interfacesList = new StringList();
                               interfacesList = (StringList)interfaces;
                           }

                           if(!moreThanOneInterfaces &&
                              interfaceStr != null &&
                              interfaceStr.indexOf(strInterface) == -1)
                           {
                               addInterface = true;
                           }
                           else if(moreThanOneInterfaces &&
                                   interfacesList != null &&
                                   !interfacesList.contains(strInterface))
                           {
                               addInterface = true;
                           }

                           //The interface is new
                           if(addInterface)
                           {
                               BusinessObject activeVersionObject = new BusinessObject(activeVersionId);
                               activeVersionObject.open(context);
                               BusinessObjectList minorObjectList = activeVersionObject.getRevisions(context);
                               activeVersionObject.close(context);

                               for (int i = 0; i < minorObjectList.size(); i++)
                               {
                                   BusinessObject minorObject = (BusinessObject)minorObjectList.get(i);
                                   String versionObjectId = minorObject.getObjectId();

                                   strMQL       = "modify bus $1 add interface $2";
                                   strResult    = MqlUtil.mqlCommand(context, strMQL, versionObjectId, strInterface);
                               }
                           }
                        }
                   }
                }

                //End Changes
            }else{
                strResult = "0.0";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            strResult = "0.0";
            e.printStackTrace();
            throw e;
        }finally{
            ContextUtil.popContext(context);
        }
        return strResult;
    }
    
//    /**
//     * 
//     * Attribute Group  Description 추가 
//     * @param context
//     * @param args
//     * @throws Exception
//     */
//    public void updateAG(Context context,String args[])throws Exception{
//
//		long startTime = System.currentTimeMillis();
//		System.out.println("${CLASSNAME}:updateAG start ."+cdmCommonExcel.getTimeStamp2());
//		String inputDirectory 			     = "";
//		String outputDirectory 			     = "";
//		String fileName 		       	     = "";
//		
//		PrintStream errorStream		         = null; 
//		File successLogFile 				 = null; 
//		File failedLogFile 				     = null;
//		
//		BufferedWriter logWriter 			 = null; 
//		BufferedWriter successObjectidWriter = null; 
//		BufferedWriter failedObjectidWriter  = null; 
//		
//		String logFileName = "updateAttributeGroup";
//		
//		String sCDM_SpecName = args[0];
//		
//		String tempAttributeGroupPath = sCDM_SpecName.substring(0, sCDM_SpecName.lastIndexOf(File.separator));
//		String tempAttributeGroupName = sCDM_SpecName.substring(sCDM_SpecName.lastIndexOf(File.separator)+1);
//		String sheetName                = "custom_AG_DATA";
//		inputDirectory = tempAttributeGroupPath;
//		fileName 	   = tempAttributeGroupName;
//		
//		// documentDirectory does not ends with "/" add it
//		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
//			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
//		}
//		String sMIGRATION_LOGS = "MIGRATION_LOGS";
//		// create a directory to add debug and error logs
//		outputDirectory = new File(inputDirectory).getParentFile() + S_FILE_SEPARATOR + sMIGRATION_LOGS + S_FILE_SEPARATOR + logFileName + "_" +  S_FILE_SEPARATOR;
//		File fileOutputDirectory = new File(outputDirectory);
//		if (!fileOutputDirectory.isDirectory()) {
//			fileOutputDirectory.mkdirs();
//		}
//		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
//		formatTime = formatTime.replaceAll("-", "_");
//		formatTime = formatTime.replaceAll(":", "_");
//		
//		logFileName = "_"+ fileName+"_"+formatTime;
//				
//		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
//		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));
//
//		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
//		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));
//
//		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
//		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
//		
//		String sRowNum = "";
//		int totalCount = 0;
//		int successCount = 0;
//		int failCount 	 = 0;
//		
//		mulitWriteErrorToFile( errorStream,"[${CLASSNAME} : createAttributeGroup] ");
//		multiWriteMessageToFile(failedObjectidWriter,"[${CLASSNAME} : createAttributeGroup]");		
//		multiWriteMessageToFile(logWriter,"========================================================================================================================");
//		multiWriteMessageToFile(logWriter,"CREATE ATTRIBUTEGROUP  "+ getTimeStamp()+" \n");
//		multiWriteMessageToFile(logWriter,"	Reading input log file from : "+inputDirectory+fileName);
//		multiWriteMessageToFile(logWriter,"	Writing Log files to: " + outputDirectory );
//		multiWriteMessageToFile(logWriter,"========================================================================================================================\n");
//		try {
//			Map attributeCheckMap = new HashMap();
//			
//			XSSFSheet attributeGroupSheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context,  inputDirectory+fileName, sheetName);
//			int attributeGroupSheetphysicalNumberRows = attributeGroupSheet.getPhysicalNumberOfRows();
//			//
//			totalCount = attributeGroupSheetphysicalNumberRows-1;
//			
//			for (int s = 1; s <= attributeGroupSheetphysicalNumberRows; s++) {
//				boolean bCheckOff = false;
//				try{
//				XSSFRow row = attributeGroupSheet.getRow(s);
//					sRowNum = String.valueOf(s+1);	
//					
//					if (row == null){
//						String errorMessage= "THERE IS NO INFORMATION IN THE EXCEL SHEET.";
//						throw new Exception(errorMessage);
//					}
//					
//					XSSFCell cell_AGCode = row.getCell(0);// CN_CODE
//					XSSFCell cell_AGDescription = row.getCell(1);// TDM_DESCRIPTION
//
//					String sCellAG = getCellValue(cell_AGCode);
//					String sDescription = getCellValue(cell_AGDescription);
//
//					sCellAG = isVaildNullData(sCellAG);
//					sDescription = isVaildNullData(sDescription);
//					
//					if (cdmStringUtil.isNotEmpty(sCellAG) && cdmStringUtil.isNotEmpty(sDescription) ) {
//
//						String checkCreateAttribute = "list interface $1 select $2 dump ";
//						String checkMqlResult = MqlUtil.mqlCommand(context, checkCreateAttribute, sCellAG, "name");
//						
//						if(UIUtil.isNotNullAndNotEmpty(checkMqlResult)){
//							String updateAttributeGroup = "mod interface $1 description $2  ";
//							MqlUtil.mqlCommand(context, updateAttributeGroup, sCellAG, sDescription);
//						}
//						successCount++;
////						multiWriteMessageToFile(logWriter," SUCESS: LINE NUMBER: "+sRowNum+"| AG NAME: "+sPartFamilyAndAttributeGroupName);
//						multiWriteMessageToFile(successObjectidWriter," SUCESS: LINE NUMBER: "+sRowNum+" | AG NAME: "+sCellAG);
//					} else {
//						String errorMessage = "SHEET DATA NOT EXIST FILE DATA (CN_CODE). ";
//						throw new Exception(errorMessage);
//
//					}
//				}catch(Exception e2){
//					failCount++;
//					mulitWriteErrorToFile( errorStream,"LINE NUMBER: "+sRowNum);
//					e2.printStackTrace(errorStream);
//					multiWriteMessageToFile(failedObjectidWriter,"LINE NUMBER: " + sRowNum+  "\t  EXCEPTION: "+ e2.getMessage());
//				}finally{
//					if(bCheckOff){
//						MqlUtil.mqlCommand(context, "Trigger On");
//					}
//				}
//			}
//			
//			
//			multiWriteMessageToFile(logWriter,"====================================================================================");
//			multiWriteMessageToFile(logWriter,"        File CREATE ATTRIBUTEGROUP OBJECT Migration COMPLETED.                    ");
//			multiWriteMessageToFile(logWriter,"====================================================================================\n");
//		} catch (Exception e) {
//			e.printStackTrace();
//			throw new FrameworkException(e.toString());
//		}finally{
//			multiWriteMessageToFile(logWriter,"========================================================================================================================");
//			multiWriteMessageToFile(logWriter,"	CREATE ATTRIBUTEGROUP OBJECT MIGRATION CLOSE TIME:  "+getTimeStamp()+"          \n"  );
//			multiWriteMessageToFile(logWriter,"	SUCCESS COUNT: ("+successCount+ ")"+"  FAIL COUNT: ("+failCount+")  Total Count: ("+totalCount+")"+" LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000 + " second" );
//			multiWriteMessageToFile(logWriter,"========================================================================================================================\n");
//			
//			try {
//				if (null != logWriter)
//					logWriter.close();
//
//				if (null != errorStream)
//					errorStream.close();
//
//				if (null != successObjectidWriter)
//					successObjectidWriter.close();
//
//				if (null != failedObjectidWriter)
//					failedObjectidWriter.close();
//			} catch (IOException e) {
//				System.out.println("Exception while closing log stream " + e.getMessage());
//			}
//			System.out.println(" ${CLASSNAME} : createAttributeGroup() finish ");
//		}
//	
//    }
    
    
//    //
//    /**
//     * connectPartFamily 메서드에서 업데이트한 데이타 connectPartFamily은 사용하지 않을 예정 이지만 migration처리는 이
//     * 
//     * @param context
//     * @param args
//     * @throws Exception
//     */
//    public void connectPartFamilyBlockCode2(Context context,String args[])throws Exception{
//
//		long startTime = System.currentTimeMillis();
//		System.out.println("${CLASSNAME} : connectPartFamilyBlockCode2 -start"+getTimeStamp());
//		
//		String inputDirectory 			     = "";
//		String outputDirectory 			     = "";
//		String fileName 		       	     = "";
//		
//		PrintStream errorStream		         = null; 
//		File successLogFile 				 = null; 
//		File failedLogFile 				     = null;
//		
//		BufferedWriter logWriter 			 = null; 
//		BufferedWriter successObjectidWriter = null; 
//		BufferedWriter failedObjectidWriter  = null; 
//		
//		String logFileName = "connectPartFamilyBlockCode";
//		
//		String sheetName   = "";
//		String tempPartFamilyExcelPath = "";
//		String tempPartFamilyExcelName = "";
//		String tempOutputDir = "";
//		
//		String sFileLocationAndFileName = args[0];
//		
//		// excel info
//		tempPartFamilyExcelPath 				= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf(File.separator));
//		tempPartFamilyExcelName 				= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf(File.separator)+1);
//		tempOutputDir 		= "MIGRATION_LOGS"; 
//		
////		Properties prop = new Properties();
////		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
////		tempPartFamilyExcelPath 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("PART_FAMILY_EXCEL_PATH"));
////		tempPartFamilyExcelName 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("PART_FAMILY_EXCEL_NAME"));
////		tempOutputDir 						= cdmStringUtil.convertISOtoUTF8((String)prop.get("Output_Directory"));
//		
//		
//		if (cdmStringUtil.isEmpty(tempPartFamilyExcelPath) || cdmStringUtil.isEmpty(tempPartFamilyExcelName) || cdmStringUtil.isEmpty(tempOutputDir)) {
//			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//		}
//		
//		inputDirectory = tempPartFamilyExcelPath;
//		fileName 	   = tempPartFamilyExcelName;
//		
//		// documentDirectory does not ends with "/" add it
//		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
//			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
//		}
//		// create a directory to add debug and error logs
//		outputDirectory = new File(inputDirectory).getParentFile().getParent() + S_FILE_SEPARATOR + tempOutputDir + S_FILE_SEPARATOR + logFileName + "_" +  S_FILE_SEPARATOR;
//		File fileOutputDirectory = new File(outputDirectory);
//		if (!fileOutputDirectory.isDirectory()) {
//			fileOutputDirectory.mkdirs();
//		}
//		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
//		formatTime = formatTime.replaceAll("-", "_");
//		formatTime = formatTime.replaceAll(":", "_");
//		
//        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
//
//		
//		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
//		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));
//
//		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
//		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));
//
//		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
//		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
//		
//		String sRowNum = "";
//		int successCount 	= 0;
//		int failCount 		= 0;
//		int totalCount 		= 0;
//		
//		String sRecordCompany 			= "";
//		String sRecordProductCode 		= "";
//		String sRecordProductCodeName 	= "";
//		String sRecordBlockCode 		= "";
//		String sRecordBlockCodeName 	= "";
//		multiWriteMessageToFile(logWriter,"====================================================================================");
//		multiWriteMessageToFile(logWriter,"	CONNECT PARTFAMILY OBJECT AND PARTFAMILY OBJECT  "+ getTimeStamp()+" \n");
//		multiWriteMessageToFile(logWriter,"	Reading input log file from : "+inputDirectory+fileName);
//		multiWriteMessageToFile(logWriter,"	Writing Log files to: " + outputDirectory );
//		multiWriteMessageToFile(logWriter,"====================================================================================\n");
//		try {
//			
//			Sheet sheet = (Sheet) cdmCommonExcel.getXssfSheet2(context, inputDirectory+fileName, sheetName);
//			int sheetPhysicalNumberRows = sheet.getPhysicalNumberOfRows();
//			totalCount = sheetPhysicalNumberRows-1;
//			
//			/* Part Library id search*/
//			String sPartLibraryName = "Block_Code";
//			StringList sPLQueryResultList = null;
//			String sPLQuery = "temp query bus \"Part Library\" * *  where \" name=='" + sPartLibraryName + "' \"  select id dump |";
//			String mqlResult= MqlUtil.mqlCommand(context,  sPLQuery);
//			sPLQueryResultList = FrameworkUtil.split(mqlResult, "|");
//			String sPLId= (String)sPLQueryResultList.get(3);
//			
//			DomainObject partListBlockCodeDObj = new DomainObject(sPLId);
//			StringList selectPFList =  new StringList();
//			selectPFList.add("id");
//			selectPFList.add("attribute[cdmPartFamilyBlockCodeName]");
//			StringList relsectPFList =  new StringList();
//			String wherePF = "";
//			 MapList partFamilyList = partListBlockCodeDObj.getRelatedObjects(context, // Context context
//					 													"Subclass"   ,
//					                                                   "Part Family" , // String typePattern
//					                                                    true         , // boolean getTo
//					                                                    false        , // boolean getFrom
//					                                                    0            , // int recurseToLevel
//					                                                    selectPFList , // StringList objectSelects
//					                                                    relsectPFList, // StringList relationshipSelects
//					                                                    wherePF      , // String objectWhereClause
//					                                                    ""     		 , // String relationshipWhereClause
//																		0			 , // int limit
//															            null         , // String postRelPattern
//																		null		 , // String postTypePattern
//																		null	); 	   // Map postPatterns
//					 					       
//			HashMap hmPartFamily = new HashMap<>();
//			for (Iterator iterPFList = partFamilyList.iterator(); iterPFList.hasNext();) {
//				Map mapPF = (Map) iterPFList.next();
//				String blockCodeName = (String)mapPF.get("attribute[cdmPartFamilyBlockCodeName]");
//				String blockCodeId = (String)mapPF.get("id");
//				hmPartFamily.put(blockCodeName, blockCodeId);
//				
//			}
//			
//			for (int i = 1; i < sheetPhysicalNumberRows; i++) {
//				boolean checkTriggeroff = false; 
//				Row sheetRow = sheet.getRow(i);
//				try {
//					
//					sRowNum = String.valueOf(i+1);
//					if (sheetRow == null){
//						String errorMessage = "NOT EXIST DATA (ROW NULL)";
//						throw new Exception(errorMessage);	
//					}
//		
////					Cell cell_0 = sheetRow.getCell(0);  //
//					Cell cell_1 = sheetRow.getCell(1);  //법인
//					Cell cell_2 = sheetRow.getCell(2);  //제품코드
//					Cell cell_3 = sheetRow.getCell(3);  //제품코드명
//					Cell cell_4 = sheetRow.getCell(4);  //BLOCK 코드
//					Cell cell_5 = sheetRow.getCell(5);  //BLOCK 코드명
//
////					
//					String sCompany 	 	= getCellValue2(cell_1);
//					String sProductCode 	= getCellValue2(cell_2);
//					String sProductCodeName = getCellValue2(cell_3);
//					String sBlockCode 		= getCellValue2(cell_4);
//					String sBlockCodeName 	= getCellValue2(cell_5);
//
////					
//					sCompany 			= isVaildNullData(sCompany);
//					sProductCode 		= isVaildNullData(sProductCode);
//					sProductCodeName 	= isVaildNullData(sProductCodeName);
//					sBlockCode 			= isVaildNullData(sBlockCode);
//					sBlockCodeName 		= isVaildNullData(sBlockCodeName);
//
//					sRecordCompany 			= sCompany 			;
//					sRecordProductCode 		= sProductCode 		;
//					sRecordProductCodeName 	= sProductCodeName 	;
//					sRecordBlockCode 		= sBlockCode 		;
//					sRecordBlockCodeName 	= sBlockCodeName 	;
//					
//					
//					String sPartFamilyNameLev1 = sCompany;
//					String sPartFamilyNameLev2 = sProductCode + ":" + sProductCodeName ;
//					String sPartFamilyNameLev3 = sProductCode + sBlockCode + ":" + sBlockCodeName ;
//
//					 if(!"Global R&D".equals(sCompany)){
//						  String errorMessage = "IT IS NOT A MIGRATION TARGET.";
//						  throw new Exception(errorMessage);
//					}
//					 String lev1Id = (String)hmPartFamily.get(sPartFamilyNameLev1);
//					 if(UIUtil.isNullOrEmpty(lev1Id)){
//						 String errorMessage = "Part Family Lev1 does not exist.("+sPartFamilyNameLev2+")";
//						  throw new Exception(errorMessage);
//					 }
//					 
//					 String lev2Id = (String)hmPartFamily.get(sPartFamilyNameLev2);
//					 if(UIUtil.isNullOrEmpty(lev2Id)){
//						 String errorMessage = "Part Family Lev2 does not exist.("+sPartFamilyNameLev2+")";
//						  throw new Exception(errorMessage);
//					 }
//					 
//					 String lev3Id = (String)hmPartFamily.get(sPartFamilyNameLev3);
//					 if(UIUtil.isNullOrEmpty(lev3Id)){
//						 String errorMessage = "Part Family Lev3 does not exist.("+sPartFamilyNameLev3+")";
//						  throw new Exception(errorMessage);
//					 }
//					 
//					 DomainObject dObjLev1 = new DomainObject(lev1Id);
//					 DomainObject dObjLev2 = new DomainObject(lev2Id);
//					 DomainObject dObjLev3 = new DomainObject(lev3Id);
//					 
//					 String hasSubclassLev1 = "";
//					 String hasSubclassLev2 = "";
//					 String hasSubclassLev3 = "";
//					 
//					 hasSubclassLev1 = dObjLev1.getInfo(context, "to[Subclass]");
//					 hasSubclassLev2 = dObjLev2.getInfo(context, "to[Subclass]");
//					 hasSubclassLev3 = dObjLev3.getInfo(context, "to[Subclass]");
//					 
//					 MapList mListConnectPLOrPF = new MapList();
//					 Map mapConnectPLOrPF = new HashMap();
//					 if("False".equalsIgnoreCase(hasSubclassLev1)){
//						 DomainRelationship connectRel = null;
//						 DomainObject partLibraryObj = new DomainObject(sPLId);
//						 connectRel = DomainRelationship.connect(context, partLibraryObj, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), dObjLev1);
//						 mapConnectPLOrPF.put("fromId", sPLId);
//						 mapConnectPLOrPF.put("toId", lev1Id);
//						 mListConnectPLOrPF.add(mapConnectPLOrPF);
//					 }
//					 
//					 if("False".equalsIgnoreCase(hasSubclassLev2)){
//						 DomainRelationship connectRel2 = null;
//						 connectRel2 = DomainRelationship.connect(context, dObjLev1, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), dObjLev2);
//						 
//						 mapConnectPLOrPF.put("fromId", lev1Id);
//						 mapConnectPLOrPF.put("toId", lev2Id);
//						 mListConnectPLOrPF.add(mapConnectPLOrPF);
//					 }
//					 
//					 if("False".equalsIgnoreCase(hasSubclassLev3)){
//						 DomainRelationship connectRel3 = null;
//						 connectRel3 = DomainRelationship.connect(context, dObjLev2, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), dObjLev3);
//						 
//						 mapConnectPLOrPF.put("fromId", lev2Id);
//						 mapConnectPLOrPF.put("toId", lev3Id);
//						 mListConnectPLOrPF.add(mapConnectPLOrPF);
//					 }
//					 //
//						//trigger start
//						//
//					 for (int mListConnectPLOrPFCNT = 0;mListConnectPLOrPFCNT<mListConnectPLOrPF.size(); mListConnectPLOrPFCNT++) {
//						Map mapConnectedPLOrPF = (Map) mListConnectPLOrPF.get(mListConnectPLOrPFCNT);
//						String sFromId  = (String)mapConnectedPLOrPF.get("fromId");
//						String sToId 	= (String)mapConnectedPLOrPF.get("toId");
//						
//						String[] constructor = {null};
//						String parentObjectId =sFromId; //from 
//				        String childObjectId = sToId;  //to 
//				        Map aMap = new HashMap();
//				        aMap.put ("objectId", parentObjectId);
//				        aMap.put ("relationship", LibraryCentralConstants.RELATIONSHIP_SUBCLASS); //rel
//				        String objectName=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_NAME);
//				        String objectRevision=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_REVISION);
//				        String parentPhysicalId=LibraryCentralCommon.getPhysicalIdforObject(context,parentObjectId);
//						
//				        if(!(objectRevision.equals(parentPhysicalId))){
//				            
//				        	  String mqlQuery="modify bus $1 revision $2 name $3 ";
//				              ContextUtil.pushContext(context);
//				              MqlUtil.mqlCommand(context, mqlQuery, childObjectId,parentPhysicalId,objectName);
//				              ContextUtil.popContext(context);
//				        }
//				        String strFromObjectId = sFromId;
//			            String strToObjectId = sToId;
//			            DomainObject childObj = new DomainObject(strToObjectId);
//			            DomainObject parentObj = new DomainObject(strFromObjectId);
//			            String strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//			            String strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//			            
//			            // This block is to check whether the parent object, which the classification object is added with Subclass Relationship
//			            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
//			            // with the object.  The Classifications(Part Family) created to prior to the installation will not have any interfaces associated
//			            // With them.
//			            if(strParentInterface == null || "".equals(strParentInterface) || "null".equals(strParentInterface)) {
//			                try {
//			                    if(createInterfaceObject(context, strFromObjectId) == 0) {
//			                        strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//			                        //If this object is type of LIBRARIES, it will have interface, and will not come into this block.
//			                        //If this object is type of PartFamily and it is created without Library Central installed, that will fall into this block
//			                        //that is why inheriting this interface with INTERFACE_CLASSIFICATION_ORPHANS
//			                        String cmd = "modify interface $1 derived $2";
//			                        MqlUtil.mqlCommand(context, cmd, true, strParentInterface, LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
//
//			                        //Get all classified items connected to it and implement the interface on all classified items
//			                        SelectList selectStmts = new SelectList(1);
//			                        selectStmts.addElement(DomainObject.SELECT_ID);
//			                        MapList result = new MapList();
//			                        result = (MapList)parentObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
//			                        int iSize = result.size();
//			                        Map tempMap;
//			                        String strObjectId;
//			                        for (int k=0;k<iSize;k++ )
//			                        {
//			                            implementInterfaceOnClassifiedItem(context, strFromObjectId, ((String)((Map)result.get(k)).get("id")));
//
//			                        }
//
//			                    }
//			                } catch(Exception ex) {
//			                    throw ex;
//			                }
//			            }
//			            
//			            // This block is to check whether the classification object,
//			            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
//			            // with the object.  The Classifications(Part Family) created to prior to the installation of Library Central or created in
//			            // previous versions will not have any interfaces associated with them.
//			            if(strChildInterface == null || "".equals(strChildInterface) || "null".equals(strChildInterface)) {
//			                try {
//			                    if(createInterfaceObject(context, strToObjectId) == 0) {
//			                        strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//
//			                        //Get all classified items connected to it and implement the interface on all classified items
//			                        SelectList selectStmts = new SelectList(1);
//			                        selectStmts.addElement(DomainObject.SELECT_ID);
//			                        MapList result = new MapList();
//			                        result = (MapList)childObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
//			                        int iSize = result.size();
//			                        for (int k=0;k<iSize;k++ )
//			                        {
//			                            implementInterfaceOnClassifiedItem(context, strToObjectId, ((String)((Map)result.get(k)).get("id")));
//			                        }
//
//			                    }
//			                } catch(Exception ex) {
//			                    throw ex;
//			                }
//			            }
//
//			            try{
//			                // The approach here is as follows:
//			                // Get everything that the child's interface is derived from
//			                // directly; To that list, add the new parent's interface;
//			                // remove mxsysLCOrphans.
//			                // The resulting set is what child's interface will be derived from.
//			                // This may seem over-complicated, but it is necessary in
//			                // conjunction with the optional Multiple Classification Module in
//			                // order to avoid attribute data loss.
//			                String cmd = "print interface $1 select derived dump $2";
//			                String currentParentsCSL = MqlUtil.mqlCommand(context,cmd,true, strChildInterface, ",").trim();
//
//			                StringList currentParentsList = FrameworkUtil.split(currentParentsCSL, ",");
//			                currentParentsList.addElement(strParentInterface);
//			                currentParentsList.remove(LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
//			                String[] parentInterfaces   = new String[currentParentsList.size()+1];
//			                parentInterfaces[0]         = strChildInterface;
//			                StringBuffer sbQuery        = new StringBuffer("modify interface $1 derived");
//			                for (int j = 0 ; j < currentParentsList.size() ; j++) {
//			                    sbQuery.append(" $").append(j+2).append(",");
//			                    parentInterfaces[j+1] = (String)currentParentsList.get(j);
//			                }
//			                cmd = sbQuery.substring(0, sbQuery.lastIndexOf(","));
//
//			                String result = MqlUtil.mqlCommand(context, cmd, true, parentInterfaces);
//
//
//			            }catch(Exception e)
//			            {
//			                e.printStackTrace();
//			                throw e;
//			            }
//			            
//			            String connectTclProg =  "emxUpdateCountOnSubclassConnectDisconnect.tcl";
//			            String updateCountConnection = "execute program \""+connectTclProg+"\"  \"" +sToId + "\" " +  "\"" +sPLId+ "\"";
//			            MQLCommand mqlcommand = new MQLCommand();
//						mqlcommand.open(context);
//				        mqlcommand.executeCommand(context, updateCountConnection);
//						String sResult = mqlcommand.getResult();
//						String sError = mqlcommand.getError();
//						mqlcommand.close(context);
//			            
//			            
//			            
//					 }
//					//trigger end	
//				        //
//			            
//			          
//			            
//
//			            
//
//			           
//			            //
//
//					 //
//					 
//					 
//					// change end 
//					 
////					String sTempPartFamilyNameLev2 = "";
////					boolean checkSpecialSymbolPartFamilyNameLev2 = false; 
////					
////					if (sPartFamilyNameLev2.contains(",")) {
////						sTempPartFamilyNameLev2 = sPartFamilyNameLev2.replaceAll(",", "?");
////						checkSpecialSymbolPartFamilyNameLev2 = true;
////					}
////					if (sPartFamilyNameLev2.contains("'")) {
////						sTempPartFamilyNameLev2 = sPartFamilyNameLev2.replaceAll("'", "?");
////						checkSpecialSymbolPartFamilyNameLev2 = true;
////					}
////					
////					String sTempsPFlev3 = "";
////					boolean checkSpecialSymbolsTempsPFlev3 = false;  
////					if(sPartFamilyNameLev3.contains(",") ){
////					   sTempsPFlev3 = sPartFamilyNameLev3.replaceAll(",", "?");
////					   checkSpecialSymbolsTempsPFlev3 = true;
////					}
////					
////					if(sPartFamilyNameLev3.contains("'") ){
////					   sTempsPFlev3 = sPartFamilyNameLev3.replaceAll("'", "?");
////					   checkSpecialSymbolsTempsPFlev3 = true;
////					}
////					//
////					
////					DomainObject childLev1Obj = new DomainObject();
////					DomainObject childLev2Obj = new DomainObject();
////					DomainObject childLev3Obj = new DomainObject();
////					
////					
////					
//////					String checkRelationshipLev1 = "temp query bus 'Part Family' \"" + sPartFamilyNameLev1 + "\"  *  where to[Subclass]==False select id dump |";
////					String checkRelationshipLev1 = "temp query bus 'Part Family' \"*\"  \"*\"  where \" attribute[cdmPartFamilyBlockCodeName] == '"+sPartFamilyNameLev1+"' && to[Subclass] == 'False' \" select id dump |";
////					String checkRealtionshipLev1Result = MqlUtil.mqlCommand(context, checkRelationshipLev1);
////					MqlUtil.mqlCommand(context, "Trigger Off");
////					checkTriggeroff = true;
//////					ContextUtil.startTransaction(context, true);
////					if (cdmStringUtil.isNotEmpty(checkRealtionshipLev1Result)) {	
////						String sCheckRealtionshipLev1Result = "";
////						StringList stListCheckRealtionshipLev1Result = FrameworkUtil.split(checkRealtionshipLev1Result, "|");
////						sCheckRealtionshipLev1Result = (String) stListCheckRealtionshipLev1Result.get(3);
////
////						if (cdmStringUtil.isNotEmpty(sCheckRealtionshipLev1Result)) {
////							DomainRelationship connectRel = null;
////							DomainObject partLibraryObj = new DomainObject(sPLId);
////							childLev1Obj.setId(sCheckRealtionshipLev1Result);
////							connectRel = DomainRelationship.connect(context, partLibraryObj, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), childLev1Obj);
////							
////							//trigger start
////							//
////							String[] constructor = {null};
////							String parentObjectId =sPLId; //from 
////					        String childObjectId = sCheckRealtionshipLev1Result;  //to 
////					        Map aMap = new HashMap();
////					        aMap.put ("objectId", parentObjectId);
////					        aMap.put ("relationship", LibraryCentralConstants.RELATIONSHIP_SUBCLASS); //rel
////					        String objectName=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_NAME);
////					        String objectRevision=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_REVISION);
////					        String parentPhysicalId=LibraryCentralCommon.getPhysicalIdforObject(context,parentObjectId);
////					        if(!(objectRevision.equals(parentPhysicalId))){
//////					            
////					        	  String mqlQuery="modify bus $1 revision $2 name $3 ";
////					              ContextUtil.pushContext(context);
////					              MqlUtil.mqlCommand(context, mqlQuery, childObjectId,parentPhysicalId,objectName);
////					              ContextUtil.popContext(context);
////					        }
////							//
////					        
////					        //
////
////				            String strFromObjectId = sPLId;
////				            String strToObjectId = sCheckRealtionshipLev1Result;
////				            DomainObject childObj = new DomainObject(strToObjectId);
////				            DomainObject parentObj = new DomainObject(strFromObjectId);
////				            String strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////				            String strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////
////
////				            // This block is to check whether the parent object, which the classification object is added with Subclass Relationship
////				            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
////				            // with the object.  The Classifications(Part Family) created to prior to the installation will not have any interfaces associated
////				            // With them.
////				            if(strParentInterface == null || "".equals(strParentInterface) || "null".equals(strParentInterface)) {
////				                try {
////				                    if(createInterfaceObject(context, strFromObjectId) == 0) {
////				                        strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////				                        //If this object is type of LIBRARIES, it will have interface, and will not come into this block.
////				                        //If this object is type of PartFamily and it is created without Library Central installed, that will fall into this block
////				                        //that is why inheriting this interface with INTERFACE_CLASSIFICATION_ORPHANS
////				                        String cmd = "modify interface $1 derived $2";
////				                        MqlUtil.mqlCommand(context, cmd, true, strParentInterface, LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
////
////				                        //Get all classified items connected to it and implement the interface on all classified items
////				                        SelectList selectStmts = new SelectList(1);
////				                        selectStmts.addElement(DomainObject.SELECT_ID);
////				                        MapList result = new MapList();
////				                        result = (MapList)parentObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
////				                        int iSize = result.size();
////				                        Map tempMap;
////				                        String strObjectId;
////				                        for (int k=0;k<iSize;k++ )
////				                        {
////				                            implementInterfaceOnClassifiedItem(context, strFromObjectId, ((String)((Map)result.get(k)).get("id")));
////
////				                        }
////
////				                    }
////				                } catch(Exception ex) {
////				                    throw ex;
////				                }
////				            }
////				            // This block is to check whether the classification object,
////				            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
////				            // with the object.  The Classifications(Part Family) created to prior to the installation of Library Central or created in
////				            // previous versions will not have any interfaces associated with them.
////				            if(strChildInterface == null || "".equals(strChildInterface) || "null".equals(strChildInterface)) {
////				                try {
////				                    if(createInterfaceObject(context, strToObjectId) == 0) {
////				                        strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////
////				                        //Get all classified items connected to it and implement the interface on all classified items
////				                        SelectList selectStmts = new SelectList(1);
////				                        selectStmts.addElement(DomainObject.SELECT_ID);
////				                        MapList result = new MapList();
////				                        result = (MapList)childObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
////				                        int iSize = result.size();
////				                        for (int k=0;k<iSize;k++ )
////				                        {
////				                            implementInterfaceOnClassifiedItem(context, strToObjectId, ((String)((Map)result.get(k)).get("id")));
////				                        }
////
////				                    }
////				                } catch(Exception ex) {
////				                    throw ex;
////				                }
////				            }
////
////
////				            try{
////				                // The approach here is as follows:
////				                // Get everything that the child's interface is derived from
////				                // directly; To that list, add the new parent's interface;
////				                // remove mxsysLCOrphans.
////				                // The resulting set is what child's interface will be derived from.
////				                // This may seem over-complicated, but it is necessary in
////				                // conjunction with the optional Multiple Classification Module in
////				                // order to avoid attribute data loss.
////				                String cmd = "print interface $1 select derived dump $2";
////				                String currentParentsCSL = MqlUtil.mqlCommand(context,cmd,true, strChildInterface, ",").trim();
////
////				                StringList currentParentsList = FrameworkUtil.split(currentParentsCSL, ",");
////				                currentParentsList.addElement(strParentInterface);
////				                currentParentsList.remove(LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
////				                String[] parentInterfaces   = new String[currentParentsList.size()+1];
////				                parentInterfaces[0]         = strChildInterface;
////				                StringBuffer sbQuery        = new StringBuffer("modify interface $1 derived");
////				                for (int j = 0 ; j < currentParentsList.size() ; j++) {
////				                    sbQuery.append(" $").append(j+2).append(",");
////				                    parentInterfaces[j+1] = (String)currentParentsList.get(j);
////				                }
////				                cmd = sbQuery.substring(0, sbQuery.lastIndexOf(","));
////
////				                String result = MqlUtil.mqlCommand(context, cmd, true, parentInterfaces);
////
////
////				            }catch(Exception e)
////				            {
////				                e.printStackTrace();
////				                throw e;
////				            }
////
////				            
////				            String connectTclProg =  "emxUpdateCountOnSubclassConnectDisconnect.tcl";
////				            String updateCountConnection = "execute program \""+connectTclProg+"\"  \"" +sCheckRealtionshipLev1Result + "\" " +  "\"" +sPLId+ "\"";
////				            MQLCommand mqlcommand = new MQLCommand();
////							mqlcommand.open(context);
////					        mqlcommand.executeCommand(context, updateCountConnection);
////							String sResult = mqlcommand.getResult();
////							String sError = mqlcommand.getError();
////							mqlcommand.close(context);
////				            //
////							//trigger end
////						}
////
////					}
////					String checkRelationshipLev2 = "";
////					boolean checkSpecialSymbolRelationshipLev2 = false;
////					if(checkSpecialSymbolPartFamilyNameLev2){
//////						checkRelationshipLev2 = "temp query bus 'Part Family' \"" + sTempPartFamilyNameLev2 + "\"  *  where to[Subclass]==False select name id dump |";
////						checkRelationshipLev2 = "temp query bus 'Part Family' \"*\"  *  where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+ sTempPartFamilyNameLev2+"' && to[Subclass] == 'False' \" select attribute[cdmPartFamilyBlockCodeName] id dump |";
////					}else{
//////						 checkRelationshipLev2 = "temp query bus 'Part Family' \"" + sPartFamilyNameLev2 + "\"  *  where to[Subclass]==False select name id dump |";
////						 checkRelationshipLev2 = "temp query bus 'Part Family' *   *  where \" attribute[cdmPartFamilyBlockCodeName] == '"+ sPartFamilyNameLev2+"' &&  to[Subclass] == 'False' \" select attribute[cdmPartFamilyBlockCodeName] id dump |";
////						
////					}
////					// String checkRelationshipLev2 = "temp query bus 'Part Family' * * where to[Subclass]==False && name == '"+sPartFamilyNameLev2+"' select id dump |";
////					String checkRealtionshipLev2Result = MqlUtil.mqlCommand(context, checkRelationshipLev2);
////
////					//
////					String tempPartFamily2Id = "";
////					StringList sListCheckRealtionshipLev2Result = new StringList();
////					sListCheckRealtionshipLev2Result = FrameworkUtil.split(checkRealtionshipLev2Result, "|");
////					  
////					if (sListCheckRealtionshipLev2Result.size()>2 && checkSpecialSymbolPartFamilyNameLev2) {
////						
////						StringList sListCheckSpecialSymbolPartFamilyLev2Result = new StringList();   
////						sListCheckSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(checkRealtionshipLev2Result, "\n");
////						for (Iterator iterSpecialSymbol = sListCheckSpecialSymbolPartFamilyLev2Result.iterator(); iterSpecialSymbol.hasNext();) {
////							String sSpecialSymbolPartFamilyLev2Result = (String) iterSpecialSymbol.next();
////							StringList sListSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev2Result, "|");
////							String tempPartFamily2Attr = (String) sListSpecialSymbolPartFamilyLev2Result.get(3);
////							if (cdmStringUtil.isNotEmpty(tempPartFamily2Attr) && tempPartFamily2Attr.equals(sPartFamilyNameLev2)) {
////								checkSpecialSymbolRelationshipLev2 = true;
////								tempPartFamily2Id = (String) sListSpecialSymbolPartFamilyLev2Result.get(4);
////								break;
////							}
////
////						}
////					   
////					}
////					//
////					
////					if (cdmStringUtil.isNotEmpty(checkRealtionshipLev2Result) || (checkSpecialSymbolRelationshipLev2 && checkSpecialSymbolPartFamilyNameLev2)) {
////						String sCheckRealtionshipLev2Result = "";
////						StringList stListCheckRealtionshipLev2Result = FrameworkUtil.split(checkRealtionshipLev2Result, "|");
////						sCheckRealtionshipLev2Result = (String) stListCheckRealtionshipLev2Result.get(4);
////						
////						if((checkSpecialSymbolRelationshipLev2 && checkSpecialSymbolPartFamilyNameLev2)){
////							sCheckRealtionshipLev2Result = tempPartFamily2Id;
////						}
////						DomainRelationship connectRel = null;
////						String sLev1PartFamilyId = "";
//////						String sLev1PartFamilyInfoMql = "temp query bus 'Part Family' \"" + sPartFamilyNameLev1 + "\"  *  select id dump |";
////						String sLev1PartFamilyInfoMql = "temp query bus 'Part Family' *  *  where \" attribute[cdmPartFamilyBlockCodeName]=='"+sPartFamilyNameLev1+"' \" select id dump |";
////						String sLev1PartFamilyInfoMqlResult = MqlUtil.mqlCommand(context, sLev1PartFamilyInfoMql);
////						StringList stListLev1PartFamilyInfoMqlResult = FrameworkUtil.split(sLev1PartFamilyInfoMqlResult, "|");
////						sLev1PartFamilyId = (String) stListLev1PartFamilyInfoMqlResult.get(3);
////
////						DomainObject partFamilyLev1Obj = new DomainObject();
////						partFamilyLev1Obj.setId(sLev1PartFamilyId);
////						childLev2Obj.setId(sCheckRealtionshipLev2Result);
////						
////						connectRel = DomainRelationship.connect(context, partFamilyLev1Obj, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), childLev2Obj);
////						
////						
////						//trigger start
////						//
////						String[] constructor = {null};
////						String parentObjectId = sLev1PartFamilyId; //from 
////				        String childObjectId = sCheckRealtionshipLev2Result;  //to 
////				        Map aMap = new HashMap();
////				        aMap.put ("objectId", parentObjectId);
////				        aMap.put ("relationship", LibraryCentralConstants.RELATIONSHIP_SUBCLASS); //rel
////				        String objectName=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_NAME);
////				        String objectRevision=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_REVISION);
////				        String parentPhysicalId=LibraryCentralCommon.getPhysicalIdforObject(context,parentObjectId);
////				        if(!(objectRevision.equals(parentPhysicalId))){
//////				            
////				        	  String mqlQuery="modify bus $1 revision $2 name $3 ";
////				              ContextUtil.pushContext(context);
////				              MqlUtil.mqlCommand(context, mqlQuery, childObjectId,parentPhysicalId,objectName);
////				              ContextUtil.popContext(context);
////				        }
////						//
////				        
////				        //
////
////			            String strFromObjectId = sLev1PartFamilyId;
////			            String strToObjectId = sCheckRealtionshipLev2Result;
////			            DomainObject childObj = new DomainObject(strToObjectId);
////			            DomainObject parentObj = new DomainObject(strFromObjectId);
////			            String strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////			            String strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////
////
////			            // This block is to check whether the parent object, which the classification object is added with Subclass Relationship
////			            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
////			            // with the object.  The Classifications(Part Family) created to prior to the installation will not have any interfaces associated
////			            // With them.
////			            if(strParentInterface == null || "".equals(strParentInterface) || "null".equals(strParentInterface)) {
////			                try {
////			                    if(createInterfaceObject(context, strFromObjectId) == 0) {
////			                        strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////			                        //If this object is type of LIBRARIES, it will have interface, and will not come into this block.
////			                        //If this object is type of PartFamily and it is created without Library Central installed, that will fall into this block
////			                        //that is why inheriting this interface with INTERFACE_CLASSIFICATION_ORPHANS
////			                        String cmd = "modify interface $1 derived $2";
////			                        MqlUtil.mqlCommand(context, cmd, true, strParentInterface, LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
////
////			                        //Get all classified items connected to it and implement the interface on all classified items
////			                        SelectList selectStmts = new SelectList(1);
////			                        selectStmts.addElement(DomainObject.SELECT_ID);
////			                        MapList result = new MapList();
////			                        result = (MapList)parentObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
////			                        int iSize = result.size();
////			                        Map tempMap;
////			                        String strObjectId;
////			                        for (int k=0;k<iSize;k++ )
////			                        {
////			                            implementInterfaceOnClassifiedItem(context, strFromObjectId, ((String)((Map)result.get(k)).get("id")));
////
////			                        }
////
////			                    }
////			                } catch(Exception ex) {
////			                    throw ex;
////			                }
////			            }
////			            // This block is to check whether the classification object,
////			            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
////			            // with the object.  The Classifications(Part Family) created to prior to the installation of Library Central or created in
////			            // previous versions will not have any interfaces associated with them.
////			            if(strChildInterface == null || "".equals(strChildInterface) || "null".equals(strChildInterface)) {
////			                try {
////			                    if(createInterfaceObject(context, strToObjectId) == 0) {
////			                        strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////
////			                        //Get all classified items connected to it and implement the interface on all classified items
////			                        SelectList selectStmts = new SelectList(1);
////			                        selectStmts.addElement(DomainObject.SELECT_ID);
////			                        MapList result = new MapList();
////			                        result = (MapList)childObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
////			                        int iSize = result.size();
////			                        for (int k=0;k<iSize;k++ )
////			                        {
////			                            implementInterfaceOnClassifiedItem(context, strToObjectId, ((String)((Map)result.get(k)).get("id")));
////			                        }
////
////			                    }
////			                } catch(Exception ex) {
////			                    throw ex;
////			                }
////			            }
////
////
////			            try{
////			                // The approach here is as follows:
////			                // Get everything that the child's interface is derived from
////			                // directly; To that list, add the new parent's interface;
////			                // remove mxsysLCOrphans.
////			                // The resulting set is what child's interface will be derived from.
////			                // This may seem over-complicated, but it is necessary in
////			                // conjunction with the optional Multiple Classification Module in
////			                // order to avoid attribute data loss.
////			                String cmd = "print interface $1 select derived dump $2";
////			                String currentParentsCSL = MqlUtil.mqlCommand(context,cmd,true, strChildInterface, ",").trim();
////
////			                StringList currentParentsList = FrameworkUtil.split(currentParentsCSL, ",");
////			                currentParentsList.addElement(strParentInterface);
////			                currentParentsList.remove(LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
////			                String[] parentInterfaces   = new String[currentParentsList.size()+1];
////			                parentInterfaces[0]         = strChildInterface;
////			                StringBuffer sbQuery        = new StringBuffer("modify interface $1 derived");
////			                for (int j = 0 ; j < currentParentsList.size() ; j++) {
////			                    sbQuery.append(" $").append(j+2).append(",");
////			                    parentInterfaces[j+1] = (String)currentParentsList.get(j);
////			                }
////			                cmd = sbQuery.substring(0, sbQuery.lastIndexOf(","));
////
////			                String result = MqlUtil.mqlCommand(context, cmd, true, parentInterfaces);
////
////
////			            }catch(Exception e)
////			            {
////			                e.printStackTrace();
////			                throw e;
////			            }
////
////			            
////			            String connectTclProg =  "emxUpdateCountOnSubclassConnectDisconnect.tcl";
////			            String updateCountConnection = "execute program \""+connectTclProg+"\"  \"" +sCheckRealtionshipLev2Result + "\" " +  "\"" +sLev1PartFamilyId+ "\"";
////			            MQLCommand mqlcommand = new MQLCommand();
////						mqlcommand.open(context);
////				        mqlcommand.executeCommand(context, updateCountConnection);
////						String sResult = mqlcommand.getResult();
////						String sError = mqlcommand.getError();
////						mqlcommand.close(context);
////			            //
////						//trigger end
////					}
////
////					// ==
////					String checkRelationshipLev3 = "";
////					boolean checkSpecialSymbolRelationshipLev3 = false;
////					if(checkSpecialSymbolsTempsPFlev3){
//////						checkRelationshipLev2 = "temp query bus 'Part Family' \"" + sTempPartFamilyNameLev2 + "\"  *  where to[Subclass]==False select name id dump |";
////						checkRelationshipLev3 = "temp query bus 'Part Family' \"*\"  *  where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+ sTempsPFlev3+"' && to[Subclass] == 'False' \" select attribute[cdmPartFamilyBlockCodeName] id dump |";
////					}else{
//////						 checkRelationshipLev2 = "temp query bus 'Part Family' \"" + sPartFamilyNameLev2 + "\"  *  where to[Subclass]==False select name id dump |";
////						checkRelationshipLev3 = "temp query bus 'Part Family' *   *  where \" attribute[cdmPartFamilyBlockCodeName] == '"+ sPartFamilyNameLev3+"' &&  to[Subclass] == 'False' \" select attribute[cdmPartFamilyBlockCodeName] id dump |";
////						
////					}
////					// String checkRelationshipLev2 = "temp query bus 'Part Family' * * where to[Subclass]==False && name == '"+sPartFamilyNameLev2+"' select id dump |";
////					String checkRealtionshipLev3Result = MqlUtil.mqlCommand(context, checkRelationshipLev3);
////
////					//
////					String tempPartFamily3Id = "";
////					StringList sListCheckRealtionshipLev3Result = new StringList();
////					sListCheckRealtionshipLev3Result = FrameworkUtil.split(checkRealtionshipLev3Result, "|");
////					  
////					if (sListCheckRealtionshipLev3Result.size()>2 && checkSpecialSymbolsTempsPFlev3) {
////						
////						StringList sListCheckSpecialSymbolPartFamilyLev3Result = new StringList();   
////						sListCheckSpecialSymbolPartFamilyLev3Result = FrameworkUtil.split(checkRealtionshipLev3Result, "\n");
////						for (Iterator iterSpecialLev3Symbol = sListCheckSpecialSymbolPartFamilyLev3Result.iterator(); iterSpecialLev3Symbol.hasNext();) {
////							String sSpecialSymbolPartFamilyLev3Result = (String) iterSpecialLev3Symbol.next();
////							StringList sListSpecialSymbolPartFamilyLev3Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev3Result, "|");
////							String tempPartFamily3Attr = (String) sListSpecialSymbolPartFamilyLev3Result.get(3);
////							if (cdmStringUtil.isNotEmpty(tempPartFamily3Attr) && tempPartFamily3Attr.equals(sPartFamilyNameLev3)) {
////								checkSpecialSymbolRelationshipLev3 = true;
////								tempPartFamily3Id = (String) sListSpecialSymbolPartFamilyLev3Result.get(4);
////								break;
////							}
////
////						}
////					   
////					}else{
////						if(sListCheckRealtionshipLev3Result.size()>2 ){
////							tempPartFamily3Id = (String) sListCheckRealtionshipLev3Result.get(4);
////						}
////					}
////					
////					
//					// ==
////					String checkRelationshipLev3 = "temp query bus 'Part Family' \"" + sPartFamilyNameLev3 + "\"  *  where to[Subclass]==False select id dump |";
////					String checkRealtionshipLev3Result = MqlUtil.mqlCommand(context, checkRelationshipLev3);
////					if (cdmStringUtil.isNotEmpty(checkRealtionshipLev3Result)) {
//
////					if (cdmStringUtil.isNotEmpty(checkRealtionshipLev3Result) || (checkSpecialSymbolRelationshipLev3 && checkSpecialSymbolsTempsPFlev3)) {
////						String sCheckRealtionshipLev3Result = "";
////						StringList stListCheckRealtionshipLev3Result = FrameworkUtil.split(checkRealtionshipLev3Result, "|");
////						sCheckRealtionshipLev3Result = (String) stListCheckRealtionshipLev3Result.get(4);
////
////						DomainRelationship connectRel = null;
////						String sLev2PartFamilyId = "";
////						String sLev2PartFamilyInfoMql = "";
////						if(checkSpecialSymbolPartFamilyNameLev2){
//////							sLev2PartFamilyInfoMql = "temp query bus 'Part Family' \"" + sTempPartFamilyNameLev2 + "\"  *  select name id dump |";
////							sLev2PartFamilyInfoMql = "temp query bus 'Part Family' *  *  where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+ sTempPartFamilyNameLev2+"' \" select  attribute[cdmPartFamilyBlockCodeName] id dump |";
////						}else{
//////							sLev2PartFamilyInfoMql = "temp query bus 'Part Family' \"" + sPartFamilyNameLev2 + "\"  *  select name id dump |";
////							sLev2PartFamilyInfoMql = "temp query bus 'Part Family' *  * where \" attribute[cdmPartFamilyBlockCodeName] == '"+ sPartFamilyNameLev2+"' \" select  attribute[cdmPartFamilyBlockCodeName] id dump |";
////							
////						}
////						
////						String sLev2PartFamilyInfoMqlResult = MqlUtil.mqlCommand(context, sLev2PartFamilyInfoMql);
////						StringList stListLev2PartFamilyInfoMqlResult = FrameworkUtil.split(sLev2PartFamilyInfoMqlResult, "|");
////						
////						if(checkSpecialSymbolPartFamilyNameLev2){
////							if (stListLev2PartFamilyInfoMqlResult.size()>2 ) {
////								
////								StringList sListCheckSpecialSymbolPartFamilyLev2Result = new StringList();   
////								sListCheckSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(sLev2PartFamilyInfoMqlResult, "\n");
////								for (Iterator iterSpecialSymbol = sListCheckSpecialSymbolPartFamilyLev2Result.iterator(); iterSpecialSymbol.hasNext();) {
////									String sSpecialSymbolPartFamilyLev2Result = (String) iterSpecialSymbol.next();
////									StringList sListSpecialSymbolPartFamilyLev2Result = FrameworkUtil.split(sSpecialSymbolPartFamilyLev2Result, "|");
////									String tempPartFamily2Attr = (String) sListSpecialSymbolPartFamilyLev2Result.get(3);
////									
////									if (cdmStringUtil.isNotEmpty(tempPartFamily2Attr) && tempPartFamily2Attr.equals(sPartFamilyNameLev2)) {
////										checkSpecialSymbolRelationshipLev2 = true;
////										sLev2PartFamilyId = (String) sListSpecialSymbolPartFamilyLev2Result.get(4);
////										break;
////									}
////
////								}
////							
////							}
////						}else{
////							sLev2PartFamilyId = (String) stListLev2PartFamilyInfoMqlResult.get(4);
////						}
////						
////						DomainObject partFamilyLev2Obj = new DomainObject();
////						partFamilyLev2Obj.setId(sLev2PartFamilyId);
////						childLev3Obj.setId(sCheckRealtionshipLev3Result);
////						
////						connectRel = DomainRelationship.connect(context, partFamilyLev2Obj, new RelationshipType(LibraryCentralConstants.RELATIONSHIP_SUBCLASS), childLev3Obj);
////						
////						
////						//trigger start
////						//
////						String[] constructor = {null};
////						String parentObjectId = sLev2PartFamilyId; //from 
////				        String childObjectId = sCheckRealtionshipLev3Result;  //to 
////				        Map aMap = new HashMap();
////				        aMap.put ("objectId", parentObjectId);
////				        aMap.put ("relationship", LibraryCentralConstants.RELATIONSHIP_SUBCLASS); //rel
////				        String objectName=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_NAME);
////				        String objectRevision=new DomainObject(childObjectId).getInfo(context,DomainConstants.SELECT_REVISION);
////				        String parentPhysicalId=LibraryCentralCommon.getPhysicalIdforObject(context,parentObjectId);
////				        if(!(objectRevision.equals(parentPhysicalId))){
//////				            
////				        	  String mqlQuery="modify bus $1 revision $2 name $3 ";
////				              ContextUtil.pushContext(context);
////				              MqlUtil.mqlCommand(context, mqlQuery, childObjectId,parentPhysicalId,objectName);
////				              ContextUtil.popContext(context);
////				        }
////						//
////				        
////				        //
////
////			            String strFromObjectId = sLev2PartFamilyId;
////			            String strToObjectId = sCheckRealtionshipLev3Result;
////			            DomainObject childObj = new DomainObject(strToObjectId);
////			            DomainObject parentObj = new DomainObject(strFromObjectId);
////			            String strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////			            String strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////
////
////			            // This block is to check whether the parent object, which the classification object is added with Subclass Relationship
////			            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
////			            // with the object.  The Classifications(Part Family) created to prior to the installation will not have any interfaces associated
////			            // With them.
////			            if(strParentInterface == null || "".equals(strParentInterface) || "null".equals(strParentInterface)) {
////			                try {
////			                    if(createInterfaceObject(context, strFromObjectId) == 0) {
////			                        strParentInterface = parentObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////			                        //If this object is type of LIBRARIES, it will have interface, and will not come into this block.
////			                        //If this object is type of PartFamily and it is created without Library Central installed, that will fall into this block
////			                        //that is why inheriting this interface with INTERFACE_CLASSIFICATION_ORPHANS
////			                        String cmd = "modify interface $1 derived $2";
////			                        MqlUtil.mqlCommand(context, cmd, true, strParentInterface, LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
////
////			                        //Get all classified items connected to it and implement the interface on all classified items
////			                        SelectList selectStmts = new SelectList(1);
////			                        selectStmts.addElement(DomainObject.SELECT_ID);
////			                        MapList result = new MapList();
////			                        result = (MapList)parentObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
////			                        int iSize = result.size();
////			                        Map tempMap;
////			                        String strObjectId;
////			                        for (int k=0;k<iSize;k++ )
////			                        {
////			                            implementInterfaceOnClassifiedItem(context, strFromObjectId, ((String)((Map)result.get(k)).get("id")));
////
////			                        }
////
////			                    }
////			                } catch(Exception ex) {
////			                    throw ex;
////			                }
////			            }
////			            // This block is to check whether the classification object,
////			            // has an interface associated with it, if it does not have an interface associated with it will create an interface and associate
////			            // with the object.  The Classifications(Part Family) created to prior to the installation of Library Central or created in
////			            // previous versions will not have any interfaces associated with them.
////			            if(strChildInterface == null || "".equals(strChildInterface) || "null".equals(strChildInterface)) {
////			                try {
////			                    if(createInterfaceObject(context, strToObjectId) == 0) {
////			                        strChildInterface = childObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
////
////			                        //Get all classified items connected to it and implement the interface on all classified items
////			                        SelectList selectStmts = new SelectList(1);
////			                        selectStmts.addElement(DomainObject.SELECT_ID);
////			                        MapList result = new MapList();
////			                        result = (MapList)childObj.getRelatedObjects(context,LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM,LibraryCentralConstants.QUERY_WILDCARD,selectStmts,new StringList(),false, true, (short)1, null, null);
////			                        int iSize = result.size();
////			                        for (int k=0;k<iSize;k++ )
////			                        {
////			                            implementInterfaceOnClassifiedItem(context, strToObjectId, ((String)((Map)result.get(k)).get("id")));
////			                        }
////
////			                    }
////			                } catch(Exception ex) {
////			                    throw ex;
////			                }
////			            }
////
////
////			            try{
////			                // The approach here is as follows:
////			                // Get everything that the child's interface is derived from
////			                // directly; To that list, add the new parent's interface;
////			                // remove mxsysLCOrphans.
////			                // The resulting set is what child's interface will be derived from.
////			                // This may seem over-complicated, but it is necessary in
////			                // conjunction with the optional Multiple Classification Module in
////			                // order to avoid attribute data loss.
////			                String cmd = "print interface $1 select derived dump $2";
////			                String currentParentsCSL = MqlUtil.mqlCommand(context,cmd,true, strChildInterface, ",").trim();
////
////			                StringList currentParentsList = FrameworkUtil.split(currentParentsCSL, ",");
////			                currentParentsList.addElement(strParentInterface);
////			                currentParentsList.remove(LibraryCentralConstants.INTERFACE_CLASSIFICATION_ORPHANS);
////			                String[] parentInterfaces   = new String[currentParentsList.size()+1];
////			                parentInterfaces[0]         = strChildInterface;
////			                StringBuffer sbQuery        = new StringBuffer("modify interface $1 derived");
////			                for (int j = 0 ; j < currentParentsList.size() ; j++) {
////			                    sbQuery.append(" $").append(j+2).append(",");
////			                    parentInterfaces[j+1] = (String)currentParentsList.get(j);
////			                }
////			                cmd = sbQuery.substring(0, sbQuery.lastIndexOf(","));
////
////			                String result = MqlUtil.mqlCommand(context, cmd, true, parentInterfaces);
////
////
////			            }catch(Exception e)
////			            {
////			                e.printStackTrace();
////			                throw e;
////			            }
////
////			            
////			            String connectTclProg =  "emxUpdateCountOnSubclassConnectDisconnect.tcl";
////			            String updateCountConnection = "execute program \""+connectTclProg+"\"  \"" +sCheckRealtionshipLev3Result + "\" " +  "\"" +sLev2PartFamilyId+ "\"";
////			            MQLCommand mqlcommand = new MQLCommand();
////						mqlcommand.open(context);
////				        mqlcommand.executeCommand(context, updateCountConnection);
////						String sResult = mqlcommand.getResult();
////						String sError = mqlcommand.getError();
////						mqlcommand.close(context);
////			            //
////						//trigger end
////					}
//					
////					ContextUtil.commitTransaction(context);
//					MqlUtil.mqlCommand(context, "Trigger On");
//					checkTriggeroff = false;
//					
//					multiWriteMessageToFile(successObjectidWriter,"MODIFY SUCESS: LINE NUMBER: "+sRowNum);
//					successCount++;
//				}catch(Exception e4){
////					ContextUtil.abortTransaction(context);
//					failCount++;
//					multiWriteMessageToFile(logWriter,"Line Number: "+sRowNum+ "\t"+ e4.getMessage());
//					mulitWriteErrorToFile( errorStream,"Line Number: "+sRowNum+"\t" + e4.getMessage());
//					e4.printStackTrace(errorStream);
//					multiWriteMessageToFile(failedObjectidWriter,sRowNum+"\t");
//				}finally{
//					if(checkTriggeroff){
//						MqlUtil.mqlCommand(context, "Trigger On");
//					}
//					
//				}
//			}
//			multiWriteMessageToFile(logWriter,"====================================================================================");
//			multiWriteMessageToFile(logWriter,"	File CONNECT PARTFAMILY OBJECT AND PARTFAMILY OBJECT Migration COMPLETED.                    ");
//			multiWriteMessageToFile(logWriter,"====================================================================================");
//		} catch (Exception e) {
//			multiWriteMessageToFile(logWriter,"Line Number: "+sRowNum+ " Exception : " + e.getMessage());
//			mulitWriteErrorToFile( errorStream,"[${CLASSNAME} : connectPartFamily]  Line Number: "+sRowNum+" Exception : " + e.getMessage());
//			e.printStackTrace(errorStream);
//			
//			e.printStackTrace();
//		}finally{
//			multiWriteMessageToFile(logWriter,"====================================================================================");
//			multiWriteMessageToFile(logWriter,"	CONNECT PARTFAMILY OBJECT AND PARTFAMILY OBJECT END TIME:  "+getTimeStamp()+"          "  );
//			multiWriteMessageToFile(logWriter,"	CONNECT PARTFAMILY OBJECT AND PARTFAMILY OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000 + " second                \n"  );
//			multiWriteMessageToFile(logWriter,"	SUCCESS COUNT: ("+successCount+")  FAIL COUNT: ("+failCount+")  TOTAL COUNT: ("+totalCount+")        "  );
//			multiWriteMessageToFile(logWriter,"==================================================================================== \n");
//			System.out.println(" ${CLASSNAME} : connectPartFamily() finish "+getTimeStamp());
//			try {
//				if (null != logWriter)
//					logWriter.close();
//
//				if (null != errorStream)
//					errorStream.close();
//
//				if (null != successObjectidWriter)
//					successObjectidWriter.close();
//
//				if (null != failedObjectidWriter)
//					failedObjectidWriter.close();
//			} catch (IOException e) {
//				System.out.println("Exception while closing log stream " + e.getMessage());
//			}
//		}
//	
//	
//    }
    
    /**
     * attribute group 와 pf 
     * 수정 1월 
     * @param context
     * @param args
     * @throws Exception
     */
    public void connectAGAndPF2(Context context,String args[])throws Exception{

		String Output_Directory ="MIGRATION_LOGS";
		long startTime = System.currentTimeMillis();
		System.out.println("cdmAttributeGroupMigration : connectAGAndPF2() Start . startTime :"+cdmCommonExcel.getTimeStamp());
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String tempPartFamilyExcelPath = "";
		String tempPartFamilyExcelName = "";
		String tempOutputDir		   = "";
		
		
		String tempMappingBlockCodePath = "";
		String tempMappingBlockCodeName = "";
		
		String sFileLocationAndFileName = args[0];
//		Map paramMap = new HashMap();
//		paramMap = (Map) JPO.unpackArgs(args);
//		String sFileLocationAndFileName = (String)paramMap.get("fileData");
		tempMappingBlockCodePath 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		tempMappingBlockCodeName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		String logFileName 				= "connectAttributeGroupAndPartFamily";
		String sheetName 				= "Data_Customer";
		
		inputDirectory = tempMappingBlockCodePath;
		fileName 	   = tempMappingBlockCodeName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + S_FILE_SEPARATOR +Output_Directory  + S_FILE_SEPARATOR + logFileName + "_" +  S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		String sRowNum = "";
		int successCount = 0;
		int failCount = 0;
		int totalCount = 0;
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"	CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY OBJECT "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(logWriter,"	Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"	Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		
		try {
			MqlUtil.mqlCommand(context, "history off");
			//mapping info 
			HashMap<String,String> blockCodeHm = new HashMap<String,String>();
			
			Sheet sheet = (Sheet) cdmCommonExcel.getXssfSheet2(context, inputDirectory + fileName, sheetName);
			
			String sRecoredBlockCodeAG = "";
			String sRecoredBlockCodePF = "";
			String sRecoredBlockCodeDescription = "";
			
			int blockCodeSheetPhysicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalCount = blockCodeSheetPhysicalNumberRows-1;
			
			//
			String topPF = "Global R&D:Global R&D";
			MapList findPartFamily = new MapList();
			String findType = "Part Family";
			String sBusWhere = "attribute[cdmPartFamilyBlockCodeName]!= '' && attribute[cdmPartFamilyBlockCodeName]=='" + topPF + "' ";
			StringList slBusSelect = new StringList();
			slBusSelect.add("id");
			slBusSelect.add("attribute[cdmPartFamilyBlockCodeName]");

			findPartFamily = DomainObject.findObjects(context, findType, // type
					cdmConstantsUtil.QUERY_WILDCARD, // name
					cdmConstantsUtil.QUERY_WILDCARD, // rev
					cdmConstantsUtil.QUERY_WILDCARD, // owner
					cdmConstantsUtil.QUERY_WILDCARD, // vault
					sBusWhere, // where
					false, // expand
					slBusSelect); // selectbus

			String partFamilyTopId = "";
			for (Iterator findPFIter = findPartFamily.iterator(); findPFIter.hasNext();) {
				Map finsPFMap = (Map) findPFIter.next();
				partFamilyTopId = (String) finsPFMap.get("id");

			}

			String sRelType = "Subclass";
			StringList seList = new StringList();
			seList.add("id");
			seList.add("attribute[cdmPartFamilyBlockCodeName]");

			String findPFMql = "expand bus $1 from relationship $2 recurse to end   select bus $3 $4 dump $5";
			String mqlResult = MqlUtil.mqlCommand(context, findPFMql, partFamilyTopId, "Subclass", "id", "attribute[cdmPartFamilyBlockCodeName]", "|");

			StringList sListMqlPF = new StringList();
			sListMqlPF = FrameworkUtil.split(mqlResult, "\n");

			HashMap resultMap = new HashMap();
			for (int blockCodePFCount = 0; blockCodePFCount < sListMqlPF.size(); blockCodePFCount++) {
				String sPFInfo = (String) sListMqlPF.get(blockCodePFCount);
				StringList sListPFInfo = new StringList();

				sListPFInfo = FrameworkUtil.split(sPFInfo, "|");
				String sBlockCodeOid = (String) sListPFInfo.get(6);
				String sTempBlockCode = (String) sListPFInfo.get(7);
				String sBlockCode = sTempBlockCode.substring(0, 5);

				String duplicateBlockCode = (String) resultMap.get(sBlockCode) == null || (String) resultMap.get(sBlockCode) == "null" ? "" : (String) resultMap.get(sBlockCode);
				if (UIUtil.isNotNullAndNotEmpty(duplicateBlockCode)) {
					duplicateBlockCode += ",";
					duplicateBlockCode += sBlockCodeOid;
					resultMap.put(sBlockCode, duplicateBlockCode);
				} else {
					resultMap.put(sBlockCode, sBlockCodeOid);
				}
				resultMap.put(sTempBlockCode, sBlockCodeOid);

			}
			//
			boolean bIsDoublePartFamily = false;
			for (int blockCodeCnt = 1; blockCodeCnt < blockCodeSheetPhysicalNumberRows; blockCodeCnt++) {
				Row blockCodeSheetRow = sheet.getRow(blockCodeCnt);
				sRowNum = String.valueOf(blockCodeCnt+1);
				try{
					
				if (blockCodeSheetRow == null){
					continue;
				}

				
				Cell blockCodeCell_0 = blockCodeSheetRow.getCell(0); 	//BLOCK_ID
				Cell blockCodeCell_1 = blockCodeSheetRow.getCell(1);    // PART_NO
				Cell blockCodeCell_2 = blockCodeSheetRow.getCell(2);    // PART_Description
				

				String stBlockCodeAG 			= getCellValue2(blockCodeCell_0);
				String stBlockCodePF 			= getCellValue2(blockCodeCell_1);
				String stBlockCodePFDescription = getCellValue2(blockCodeCell_2);
				
				stBlockCodeAG 			= isVaildNullData(stBlockCodeAG);
				stBlockCodePF 			= isVaildNullData(stBlockCodePF);
				stBlockCodePFDescription = isVaildNullData(stBlockCodePFDescription);
				
				sRecoredBlockCodeAG = stBlockCodeAG;
				sRecoredBlockCodePF = stBlockCodePF;
				sRecoredBlockCodeDescription = stBlockCodePFDescription;
				
//				String sPartFamilyBlockCodeName = stBlockCodePF+":"+stBlockCodePFDescription;
				String sPFId = (String)resultMap.get(stBlockCodePF);
				StringList sListPF = new StringList();
				sListPF = FrameworkUtil.split(sPFId, ",");
				int sSizePF = sListPF.size();
				boolean bPartFamilyExist = false;
				boolean bNotPartFamilyExist = false;
				String stPartFamilyId = "";
				if(sSizePF>1){
					bIsDoublePartFamily = true;
					for (Iterator iterator = sListPF.iterator(); iterator.hasNext();) {
						String sPF = (String) iterator.next();
						if(UIUtil.isNotNullAndNotEmpty(stBlockCodePFDescription)){
							String sPFBlockCodeNameID = (String)resultMap.get(stBlockCodePF+":"+stBlockCodePFDescription);
							if(sPF.equals(sPFBlockCodeNameID)){
								stPartFamilyId = sPF;
								bPartFamilyExist = true;
								break;
							}
						}
							
					}
					if(!bPartFamilyExist){
						stPartFamilyId = (String)sListPF.get(0);
						bPartFamilyExist = true;
						bNotPartFamilyExist = true;
					}
				}else if(sSizePF==1){
					stPartFamilyId = (String)sListPF.get(0);
					bPartFamilyExist = true;
				} else{
					String errorMessage= "NOT EXIST PART FAMILY";
					throw new Exception(errorMessage);
				}
				
				
//				String sQuery = "temp query bus 'Part Family'  *  *  where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+stBlockCodePF+":*' \"  select  id attribute[cdmPartFamilyBlockCodeName] dump |";
//				String sQueryMql= MqlUtil.mqlCommand(context, sQuery);
//
//				StringList  sListQueryMql = new StringList();
//				sListQueryMql = FrameworkUtil.split(sQueryMql, "\n");
//				if(cdmStringUtil.isEmpty(sQueryMql)){
//					String errorMessage= "NOT EXIST PART FAMILY";
//					throw new Exception(errorMessage);
//				}
				
				ContextUtil.startTransaction(context, true);
//				for (Iterator iterator = sListQueryMql.iterator(); iterator.hasNext();) {
//				boolean dupleBlockCokdeCheck = false;
//				if(sListQueryMql.size()>2){
//					dupleBlockCokdeCheck = true; 
//				}
				boolean connectCheckAG = false;
//				for (int cnt = 0;cnt<sListQueryMql.size();cnt++) {
//					String sQueryPFs = (String) sListQueryMql.get(cnt);
//					
//					String stPartFamilyId = "";
//					String stPartFamilyDescription = "";
//					StringList sListQuery = new StringList();
//					sListQuery = FrameworkUtil.split(sQueryPFs, "|");
//					
//					stPartFamilyId = (String)sListQuery.get(3);
//					stPartFamilyDescription = (String)sListQuery.get(4);
//					if(dupleBlockCokdeCheck){
//						if(!stPartFamilyDescription.equalsIgnoreCase(stBlockCodePFDescription)){
//							continue;
//						}else{
//							connectCheckAG = true;
//						}
//					}
				
					com.matrixone.apps.classification.Classification clsObject = (com.matrixone.apps.classification.Classification) DomainObject.newInstance(context, stPartFamilyId, "Classification");

					// attribute group 확인 
					String interfaceDerivedCheck = "list interface \"" + stBlockCodeAG + "\"  ";
					String interfaceDeriveMqlResult = MqlUtil.mqlCommand(context, interfaceDerivedCheck);
					if(cdmStringUtil.isEmpty(interfaceDeriveMqlResult)){
						String errorMessage = "NOT EXIST AG";
						throw new Exception(errorMessage);
					}
					// pf 에 attribute group 여부 확인 
					StringList stListGetAttributeGroup = new StringList();
					
					stListGetAttributeGroup = clsObject.getAttributeGroups(context, false);
					if(stListGetAttributeGroup.contains(stBlockCodeAG)){
						connectCheckAG = true;
					}
					// attribute 추가 
					if(!connectCheckAG){
						StringList slAttributeGroup = new StringList();  
						slAttributeGroup.add(stBlockCodeAG);
						clsObject.addAttributeGroups(context, slAttributeGroup);
					}
//				}
				
				if(connectCheckAG ){
//					throw new Exception("already attributeGroup exist. \t"+sRowNum+"\t"+stBlockCodeAG+"\t"+stBlockCodePF+"\t"+stBlockCodePFDescription);
					throw new Exception("already attributeGroup exist. \t"+sRowNum+"\t"+stBlockCodeAG+"\t"+stBlockCodePF+"\t"+stBlockCodePFDescription);
				}else{
					successCount++;
					
				}
				ContextUtil.commitTransaction(context);
				multiWriteMessageToFile(successObjectidWriter,"SUCCESS."+bIsDoublePartFamily+"\t"+bNotPartFamilyExist+"\t"+ sRowNum+"\t"+stBlockCodeAG+"\t"+stBlockCodePF+"\t"+stBlockCodePFDescription);
				}catch(Exception e2){
					ContextUtil.abortTransaction(context);
					failCount++;
					mulitWriteErrorToFile( errorStream,"LINE NUMBER: \t"+sRowNum+"\t FAIL OCCURED:" + e2.getMessage());
					e2.printStackTrace(errorStream);
					
					String message = e2.getMessage();
					if(UIUtil.isNotNullAndNotEmpty(message ) && message.startsWith("already attributeGroup exist.")){
						multiWriteMessageToFile(failedObjectidWriter,"1 LINE NUMBER: \t " + sRowNum+"\t"+sRecoredBlockCodeAG+"\t"+sRecoredBlockCodePF+"\t"+sRecoredBlockCodeDescription+"\t FAIL OCCURED: \t "+e2.getMessage());
					}else if(UIUtil.isNotNullAndNotEmpty(message ) && message.startsWith("NOT EXIST AG")){
						multiWriteMessageToFile(failedObjectidWriter,"2 LINE NUMBER: \t " + sRowNum+"\t"+sRecoredBlockCodeAG+"\t"+sRecoredBlockCodePF+"\t"+sRecoredBlockCodeDescription+"\t FAIL OCCURED: \t "+e2.getMessage());
					}else if(UIUtil.isNotNullAndNotEmpty(message ) && message.startsWith("NOT EXIST PART FAMILY")){
						multiWriteMessageToFile(failedObjectidWriter,"3 LINE NUMBER: \t " + sRowNum+"\t"+sRecoredBlockCodeAG+"\t"+sRecoredBlockCodePF+"\t"+sRecoredBlockCodeDescription+"\t FAIL OCCURED: \t "+e2.getMessage());
					}else{
						multiWriteMessageToFile(failedObjectidWriter,"0 LINE NUMBER: \t " + sRowNum+"\t"+sRecoredBlockCodeAG+"\t"+sRecoredBlockCodePF+"\t"+sRecoredBlockCodeDescription+"\t FAIL OCCURED: \t "+e2.getMessage());
					}
					
				}finally{
					bIsDoublePartFamily = false;
				}
			
			}
			
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"      File CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY OBJECT Migration COMPLETED.    ");
			multiWriteMessageToFile(logWriter,"====================================================================================\n");
			
		} catch (Exception e) {
//			multiWriteMessageToFile(failedObjectidWriter,"Line Number: "+sRowNum+ " Exception occured: " + e.getMessage());
			mulitWriteErrorToFile( errorStream,"LINE NUMBER: \t"+sRowNum+"\t EXCEPTION : " + e.getMessage());
		}finally{
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"	CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY END TIME:  "+cdmCommonExcel.getTimeStamp2() +"          "  );
			multiWriteMessageToFile(logWriter,"	LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + " second                 "  );
			multiWriteMessageToFile(logWriter," SUCCESS COUNT: ("+successCount+") FAILCOUNT: ("+failCount+")  TOTAL COUNT: ("+totalCount+")              "  );
			multiWriteMessageToFile(logWriter,"==================================================================================== \n");
			System.out.println(" cdmAttributeGroupMigration_mxJPO : connectAGAndPF2() finish "+cdmCommonExcel.getTimeStamp2());
			MqlUtil.mqlCommand(context, "history on");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
		}	
		
	
    }
    
    /**
     * interface 추가 
     * @param context
     * @param args
     * @throws Exception
     */
    public void addInterfacePart(Context context,String args[])throws Exception{


		String Output_Directory ="MIGRATION_LOGS";
		long startTime = System.currentTimeMillis();
		System.out.println("cdmAttributeGroupMigration : addInterfacePart() Start . startTime :"+cdmCommonExcel.getTimeStamp());
		
		String inputDirectory 			     = "";
		String outputDirectory 			     = "";
		String fileName 		       	     = "";
		
		PrintStream errorStream		         = null; 
		File successLogFile 				 = null; 
		File failedLogFile 				     = null;
		
		BufferedWriter logWriter 			 = null; 
		BufferedWriter successObjectidWriter = null; 
		BufferedWriter failedObjectidWriter  = null; 
		
		String tempPartFamilyExcelPath = "";
		String tempPartFamilyExcelName = "";
		String tempOutputDir		   = "";
		
		
		String tempMappingBlockCodePath = "";
		String tempMappingBlockCodeName = "";
		
		String sFileLocationAndFileName = args[0];
//		Map paramMap = new HashMap();
//		paramMap = (Map) JPO.unpackArgs(args);
//		
		tempMappingBlockCodePath 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		tempMappingBlockCodeName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		String logFileName 				= "addInterface";
		String sheetName 				= "Data_PF";
		
		inputDirectory = tempMappingBlockCodePath;
		fileName 	   = tempMappingBlockCodeName;
		
		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(S_FILE_SEPARATOR)) {
			inputDirectory = inputDirectory + S_FILE_SEPARATOR;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + S_FILE_SEPARATOR +Output_Directory  + S_FILE_SEPARATOR + logFileName + "_" +  S_FILE_SEPARATOR;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));
		
		String sRowNum = "";
		int successCount = 0;
		int failCount = 0;
		int totalCount = 0;
		multiWriteMessageToFile(logWriter,"====================================================================================");
		multiWriteMessageToFile(logWriter,"	CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY OBJECT "+ getTimeStamp()+" \n");
		multiWriteMessageToFile(logWriter,"	Reading input log file from : "+inputDirectory+fileName);
		multiWriteMessageToFile(logWriter,"	Writing Log files to: " + outputDirectory );
		multiWriteMessageToFile(logWriter,"====================================================================================\n");
		StringList sListData = new StringList();
		try {
			MqlUtil.mqlCommand(context, "history off");
			//mapping info 
//			HashMap<String,String> blockCodeHm = new HashMap<String,String>();
			
			Sheet sheet = (Sheet) cdmCommonExcel.getXssfSheet2(context, inputDirectory + fileName, sheetName);
			
			String sRecordPFNo = "";
			String sRecordPFId = "";
			
			int PFSheetPhysicalNumberRows = sheet.getPhysicalNumberOfRows();
			totalCount = PFSheetPhysicalNumberRows-1;
			
			for (int partfamilyCnt = 1; partfamilyCnt < PFSheetPhysicalNumberRows; partfamilyCnt++) {
				Row blockCodeSheetRow = sheet.getRow(partfamilyCnt);
				sRowNum = String.valueOf(partfamilyCnt+1);
				try{
					
				if (blockCodeSheetRow == null){
					continue;
				}

				
				Cell blockCodeCell_0 = blockCodeSheetRow.getCell(0); 	//BLOCK_ID
				Cell blockCodeCell_1 = blockCodeSheetRow.getCell(1);    // PART_NO
				

				String stPARTFAMILY_NO 			= getCellValue2(blockCodeCell_0);
				String stPARTFAMMILY_ID 		= getCellValue2(blockCodeCell_1);
				
				
				stPARTFAMILY_NO 			= isVaildNullData(stPARTFAMILY_NO);
				stPARTFAMMILY_ID 			= isVaildNullData(stPARTFAMMILY_ID);
				
				if(UIUtil.isNullOrEmpty(stPARTFAMMILY_ID)){
					continue;
				}
				sRecordPFNo = stPARTFAMILY_NO;
				sRecordPFId = stPARTFAMMILY_ID;
				
				ContextUtil.startTransaction(context, true);
				boolean connectCheckAG = false;
				
				com.matrixone.apps.classification.Classification clsObject = (com.matrixone.apps.classification.Classification) DomainObject.newInstance(context, stPARTFAMMILY_ID, "Classification");
				// 연결된 part 확인 
				StringList sListPart = (StringList)clsObject.getInfoList(context, "from[Classified Item].to.id");
				
				int partCount = 0;
				for (int cnt = 0; cnt < sListPart.size(); cnt++) {
					String partId = (String)sListPart.get(cnt);
					sListData.add(partId);
					if("47604.45839.46236.23748".equals(partId)){
						continue;
					}
					partCount++;
					implementInterfaceOnClassifiedItem(context,stPARTFAMMILY_ID,partId);
				}
				//interface 추가 
				
				ContextUtil.commitTransaction(context);
				successCount++;
				// row num / pf no / pf id / pf connected part count / part List 
				multiWriteMessageToFile(successObjectidWriter,"SUCCESS. "+"\t"+sRowNum+"\t"+sRecordPFNo+"\t"+sRecordPFId+"\t"+partCount+"\t"+sListData.toString());
				}catch(Exception e2){
					ContextUtil.abortTransaction(context);
					failCount++;
					mulitWriteErrorToFile( errorStream,"LINE NUMBER: \t"+sRowNum+"\t FAIL OCCURED:" + e2.getMessage());
					e2.printStackTrace(errorStream);
					
					String message = e2.getMessage();
					if(UIUtil.isNotNullAndNotEmpty(message ) && message.startsWith("already attributeGroup exist.")){
						multiWriteMessageToFile(failedObjectidWriter,"1 LINE NUMBER: \t " + sRowNum+"\t"+sRecordPFNo+"\t"+sRecordPFId+"\t"+sListData.toString()+"\t FAIL OCCURED: \t "+e2.getMessage());
					}else if(UIUtil.isNotNullAndNotEmpty(message ) && message.startsWith("NOT EXIST AG")){
						multiWriteMessageToFile(failedObjectidWriter,"2 LINE NUMBER: \t " + sRowNum+"\t"+sRecordPFNo+"\t"+sRecordPFId+"\t"+sListData.toString()+"\t FAIL OCCURED: \t "+e2.getMessage());
					}else if(UIUtil.isNotNullAndNotEmpty(message ) && message.startsWith("NOT EXIST PART FAMILY")){
						multiWriteMessageToFile(failedObjectidWriter,"3 LINE NUMBER: \t " + sRowNum+"\t"+sRecordPFNo+"\t"+sRecordPFId+"\t"+sListData.toString()+"\t FAIL OCCURED: \t "+e2.getMessage());
					}else{
						multiWriteMessageToFile(failedObjectidWriter,"0 LINE NUMBER: \t " + sRowNum+"\t"+sRecordPFNo+"\t"+sRecordPFId+"\t"+sListData.toString()+"\t FAIL OCCURED: \t "+e2.getMessage());
					}
					
				}finally{
					sListData = new StringList("");
					sRecordPFId = "";
					sRecordPFNo = "";
				}
			
			}
			
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"      File CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY OBJECT Migration COMPLETED.    ");
			multiWriteMessageToFile(logWriter,"====================================================================================\n");
			
		} catch (Exception e) {
//			multiWriteMessageToFile(failedObjectidWriter,"Line Number: "+sRowNum+ " Exception occured: " + e.getMessage());
			mulitWriteErrorToFile( errorStream,"LINE NUMBER: \t"+sRowNum+"\t EXCEPTION : " + e.getMessage());
		}finally{
			multiWriteMessageToFile(logWriter,"====================================================================================");
			multiWriteMessageToFile(logWriter,"	CONNECT ATTRIBUTEGROUP OBJECT AND PARTFAMILY END TIME:  "+cdmCommonExcel.getTimeStamp2() +"          "  );
			multiWriteMessageToFile(logWriter,"	LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + " second                 "  );
			multiWriteMessageToFile(logWriter," SUCCESS COUNT: ("+successCount+") FAILCOUNT: ("+failCount+")  TOTAL COUNT: ("+totalCount+")              "  );
			multiWriteMessageToFile(logWriter,"==================================================================================== \n");
			System.out.println(" cdmAttributeGroupMigration_mxJPO : addInterfacePart() finishTime "+cdmCommonExcel.getTimeStamp2());
			MqlUtil.mqlCommand(context, "history on");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
		}	
		
	
    
    }
    //
    
    
    
//############################################################################################################################
//############################################################################################################################
//	/**
//	 * @param context
//	 * @param args
//	 * @return
//	 * @throws Exception
//	 */
//	public String modifyObjectAttributeGroup(Context context, String[]args) throws Exception {
//		HashMap programMap      = (HashMap)JPO.unpackArgs(args);
//        String parentId = (String)programMap.get("parentId");
//        StringList slAttrList = (StringList)programMap.get("slAttrList");
//		try{
//			ContextUtil.startTransaction(context, true);
//			int iAttrSize = slAttrList.size();
//			BusinessObject bo = new BusinessObject("cdmAttributeGroupObject", parentId, "-", "eService Production");
//			String objectId = bo.getObjectId(context);
//			DomainObject domObj = new DomainObject(objectId);
//			
//			StringBuffer strBuffer = new StringBuffer();
//			StringBuffer strSequenceBuffer = new StringBuffer();
//			int iAttributeSize = 1;
//			
//			for(int i=0; i<iAttrSize; i++){
//				String strAttribute = (String)slAttrList.get(i);
//				if(! "".equals(strBuffer.toString())){
//					strBuffer.append("|");
//					strBuffer.append(strAttribute);
//					
//					strSequenceBuffer.append("|");
//					strSequenceBuffer.append(strAttribute);
//					strSequenceBuffer.append(",");
//					strSequenceBuffer.append(String.valueOf(iAttributeSize+i));
//				}else{
//					if(i != 0){
//						strBuffer.append("|");
//					}
//					strBuffer.append(strAttribute);
//					
//					strSequenceBuffer.append(strAttribute);
//					strSequenceBuffer.append(",");
//					strSequenceBuffer.append(String.valueOf(iAttributeSize+i));
//				}
//			}
//			domObj.setAttributeValue(context, "cdmDescription", strBuffer.toString());
//			domObj.setAttributeValue(context, "cdmAttributeGroupSequence", strSequenceBuffer.toString());
//			ContextUtil.commitTransaction(context);
//			return "success";
//		}catch(Exception e){
//			e.printStackTrace();
//			ContextUtil.abortTransaction(context);
//			return "error";
//		}
//	}
	
//	public void test(Context context,String args[])throws Exception{

		/*try{
			AttributeGroup AG = new AttributeGroup();
			String attrGrpNameTEST = "TESTATTRIBUTEGROUP_1026";
			String strQuery    		  = "list interface $1 select attribute dump $2";
			String strQueryResult      = MqlUtil.mqlCommand(context, strQuery, attrGrpNameTEST,"|");
			StringList sListQueryResult = new StringList();
			sListQueryResult = FrameworkUtil.split(strQueryResult, "|");
			
			AG.setName(attrGrpNameTEST);
			for (Iterator iterator = sListQueryResult.iterator(); iterator.hasNext();) {
				String strAttributeName = (String) iterator.next();
				StringList sListAttributeName = new StringList();
				sListAttributeName.add(strAttributeName);
				if(strAttributeName.startsWith(sAttributeGroupPrefix)){
					
					AG.removeAttributes(context, sListAttributeName);
					System.out.println("strAttributeName ===>"+strAttributeName.toString());
				}
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}*/
		
//	}
	
//	/**
//	 * location info :C:\\temp\\Import_File
//	 * 
//	 * excel file L BOM_BC10047800_H_03_0920.xlsx
//	 * sheet name :BOM_Migration
//	 * @param context
//	 * @param args
//	 * @throws Exception
//	 */
//	@SuppressWarnings({ "unchecked", "rawtypes" })
//	public void createPartMigration(Context context,String args[])throws Exception{
//		long startTime = System.currentTimeMillis();
//		FileWriter fw = null;
//		try {
//			Map requestMap = JPO.unpackArgs(args);
//			String path = (String) requestMap.get("path");
//			String directory = (String) requestMap.get("directory"); 
//			String sheetName = (String) requestMap.get("sheetName"); 
//																	
//			if (cdmStringUtil.isEmpty(path))
//				throw new Exception();
//			
//			if(cdmStringUtil.isEmpty(sheetName)){
//				sheetName = "BOM_Migration";
//			}
//			
//			XSSFSheet xssfSheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, path, sheetName);
//			int sheetPhysicalNumberRows = xssfSheet.getPhysicalNumberOfRows();
//			MapList partSheetMapList = new MapList();
//			for (int i = 1; i <= sheetPhysicalNumberRows; i++) {
//				XSSFRow xssfEBOMSheetRow = xssfSheet.getRow(i);
//				Map partSheetMap = new HashMap();
//				if (xssfEBOMSheetRow == null)
//					continue;
//				
//				XSSFCell cell_BOM_LV = xssfEBOMSheetRow.getCell(2); //BOM_LV 
////				XSSFCell cell_ = xssfEBOMSheetRow.getCell(3); 
////				XSSFCell cell_ = xssfEBOMSheetRow.getCell(4); 
////				XSSFCell cell_ = xssfEBOMSheetRow.getCell(5); 
////				XSSFCell cell_ = xssfEBOMSheetRow.getCell(6); 
//				
//				XSSFCell cell_RelTDM_UOM = xssfEBOMSheetRow.getCell(7); //TDM_UOM  ,Unit of Measure
////				XSSFCell cell_RelECO_Number = xssfEBOMSheetRow.getCell(8); //CN_ECO_NUMBER ,ECO_NUMBER
//				XSSFCell cell_RelQuantity = xssfEBOMSheetRow.getCell(9); ///CN_QUANTITY  ,Quantity
//				
//				
//				XSSFCell cell_CLS_NAME = xssfEBOMSheetRow.getCell(10); //CLS_NAME
//				XSSFCell cell_OBJECT_ID = xssfEBOMSheetRow.getCell(11); //OBJECT_ID
//				
////				XSSFCell cell_CLASS_ID= xssfEBOMSheetRow.getCell(12); //CLASS_ID
//				XSSFCell cell_CN_ID = xssfEBOMSheetRow.getCell(13); //CN_ID ,Part No
//				XSSFCell cell_REVISION = xssfEBOMSheetRow.getCell(14);  //REVISION
//				XSSFCell cell_STATE = xssfEBOMSheetRow.getCell(15); //STATE
//				XSSFCell cell_CreateDate = xssfEBOMSheetRow.getCell(16); //Create Date , Creation Date
//				XSSFCell cell_USER_OBJECT_ID = xssfEBOMSheetRow.getCell(17); //USER_OBJECT_ID ,create By 
//				XSSFCell cell_USER_ID_MOD = xssfEBOMSheetRow.getCell(18); //USER_ID_MOD,Modified by
//				XSSFCell cell_MODIFICATION_DATE = xssfEBOMSheetRow.getCell(19); //MODIFICATION_DATE ,Last Mod.
//				XSSFCell cell_TDM_DESCRIPTION = xssfEBOMSheetRow.getCell(20); //TDM_DESCRIPTION,Part Name
//				XSSFCell cell_TDM_UOM = xssfEBOMSheetRow.getCell(21); //TDM_UOM ,Unit of Measure
//				XSSFCell cell_PHASE = xssfEBOMSheetRow.getCell(22); //PHASE ,Phase
//				XSSFCell cell_PAR_REVISION = xssfEBOMSheetRow.getCell(23); //PAR_REVISION
//				XSSFCell cell_APPROVAL_DATE = xssfEBOMSheetRow.getCell(24); //APPROVAL_DATE
//				
////				XSSFCell cell_REVISION_STG = xssfEBOMSheetRow.getCell(25); //REVISION_STG
////				XSSFCell cell_TDM_ORG_USER_ID = xssfEBOMSheetRow.getCell(26); //TDM_ORG_USER_ID ,First Revision creator
//				
//				XSSFCell cell_TDM_ORG_CREATEDATE = xssfEBOMSheetRow.getCell(27); //TDM_ORG_CREATEDATE
//				XSSFCell cell_TDM_APPROVED_BY = xssfEBOMSheetRow.getCell(28); //TDM_APPROVED_BY
//				
////				XSSFCell cell_TDM_ORIGIN_ID = xssfEBOMSheetRow.getCell(29); //TDM_ORIGIN_ID 
//				
//				XSSFCell cell_CN_PROJECT = xssfEBOMSheetRow.getCell(30); //CN_PROJECT ,PROJECT
//				XSSFCell cell_CN_PRODUCT_NAME = xssfEBOMSheetRow.getCell(31); //CN_PRODUCT_NAME
//				XSSFCell cell_CN_PART_GROUP = xssfEBOMSheetRow.getCell(32); //CN_PART_GROUP
//				
//				XSSFCell cell_CN_PART_NAME = xssfEBOMSheetRow.getCell(33); //CN_PART_NAME
//				XSSFCell cell_CN_WEIGHT = xssfEBOMSheetRow.getCell(34); //CN_WEIGHT
//				
//				XSSFCell cell_CN_ESTIMATED_WEIGHT = xssfEBOMSheetRow.getCell(35); //CN_ESTIMATED_WEIGHT ,Estimated Weight
//				XSSFCell cell_CN_WEIGHT_UNIT = xssfEBOMSheetRow.getCell(36); //CN_WEIGHT_UNIT ,WEIGHT_UNIT
//				XSSFCell cell_CN_TOP_ITEM = xssfEBOMSheetRow.getCell(37); //CN_TOP_ITEM
//				XSSFCell cell_CN_PHANTOM_ITEM = xssfEBOMSheetRow.getCell(40); //CN_PHANTOM_ITEM ,Phantom Part
//				XSSFCell cell_CN_ITEM_TYPE = xssfEBOMSheetRow.getCell(41); //CN_ITEM_TYPE 
//				XSSFCell cell_CN_SERVICE_ITEM = xssfEBOMSheetRow.getCell(42); //CN_SERVICE_ITEM
//				XSSFCell cell_CN_ITEM_MATERIAL = xssfEBOMSheetRow.getCell(43); //CN_ITEM_MATERIAL ,MATERIAL
//				
////				XSSFCell cell_CN_ITEM_UPDATE_FROM_ERP = xssfEBOMSheetRow.getCell(44); //CN_ITEM_UPDATE_FROM_ERP
//				
//				XSSFCell cell_CN_COST = xssfEBOMSheetRow.getCell(45); //CN_COST,Publiching Target
//				
////				XSSFCell cell_CN_CURRENCY = xssfEBOMSheetRow.getCell(46); //CN_CURRENCY
//				
//				XSSFCell cell_CN_COMMENTS = xssfEBOMSheetRow.getCell(47); //CN_COMMENTS ,cdmDescription
//				XSSFCell cell_CN_OEM_PART_NUMBER = xssfEBOMSheetRow.getCell(48); //CN_OEM_PART_NUMBER,cdmPartOEMItemNumber
//				XSSFCell cell_EC_NAME = xssfEBOMSheetRow.getCell(49); //EC_NAME
//				XSSFCell cell_CN_ECO_NUMBER = xssfEBOMSheetRow.getCell(51); //CN_ECO_NUMBER, cdmPartECONumber
//				XSSFCell cell_CN_PRODUCT_GROUP = xssfEBOMSheetRow.getCell(51); //CN_PRODUCT_GROUP ,cdmProductGroupForPart
//				XSSFCell cell_CN_SERIES_ITEM = xssfEBOMSheetRow.getCell(52); //CN_SERIES_ITEM , cdmSeriesItem
//				
//				XSSFCell cell_CN_VEHICLE = xssfEBOMSheetRow.getCell(53); //CN_VEHICLE ,cdmPartVehicle
//				XSSFCell cell_CN_CUSTOMER = xssfEBOMSheetRow.getCell(54); //CN_CUSTOMER ,cdmCustomerForPart
//				XSSFCell cell_CN_SIZE = xssfEBOMSheetRow.getCell(55); //CN_SIZE ,cdmPartSize
//				XSSFCell cell_CN_SURFACE_TREATMENT = xssfEBOMSheetRow.getCell(56); //CN_SURFACE_TREATMENT ,cdmPartSurfaceTreatment
//				XSSFCell cell_CN_SURFACE_AREA = xssfEBOMSheetRow.getCell(57); //CN_SURFACE_AREA ,cdmPartSurface
//				XSSFCell cell_CN_ITEM_TYPE1 = xssfEBOMSheetRow.getCell(58); //CN_ITEM_TYPE1 ,Approval Type 
//				
//				XSSFCell cell_CN_MATERIAL = xssfEBOMSheetRow.getCell(59); //CN_MATERIAL ,
//				
//				XSSFCell cell_CN_ORG1 = xssfEBOMSheetRow.getCell(60); //CN_ORG1 ,Org 1
//				XSSFCell cell_CN_ORG2 = xssfEBOMSheetRow.getCell(61); //CN_ORG2 ,Org 2
//				XSSFCell cell_CN_ORG3 = xssfEBOMSheetRow.getCell(62); //CN_ORG3 ,Org 3
//				XSSFCell cell_CN_ORG = xssfEBOMSheetRow.getCell(63); //CN_ORG ,cdmMCA_Org
//				XSSFCell cell_CN_MCA_INOUT = xssfEBOMSheetRow.getCell(64); //CN_MCA_INOUT ,cdmMCA_BOM_Management
//				XSSFCell cell_CN_MCA_PART_TYPE_REF = xssfEBOMSheetRow.getCell(65); //CN_MCA_PART_TYPE_REF ,cdmMCA_Part_Type
//				XSSFCell cell_CN_OPTION1 = xssfEBOMSheetRow.getCell(66); //CN_OPTION1 ,cdmPartOption1
//				XSSFCell cell_CN_OPTION2 = xssfEBOMSheetRow.getCell(67); //CN_OPTION2 ,cdmPartOption2
//				XSSFCell cell_CN_OPTION3 = xssfEBOMSheetRow.getCell(68); //CN_OPTION3 ,cdmPartOption3
//				XSSFCell cell_CN_OPTION4 = xssfEBOMSheetRow.getCell(69); //CN_OPTION4 ,cdmPartOption4
//				XSSFCell cell_CN_OPTION5 = xssfEBOMSheetRow.getCell(70); //CN_OPTION5 ,cdmPartOption5
//				XSSFCell cell_CN_OPTION6 = xssfEBOMSheetRow.getCell(71); //CN_OPTION6 ,cdmPartOption6
//				XSSFCell cell_CN_OPTION7 = xssfEBOMSheetRow.getCell(72); //CN_OPTION7 ,cdmPartOption7
//				XSSFCell cell_CN_OPTION_ETC = xssfEBOMSheetRow.getCell(73); //CN_OPTION_ETC ,cdmPartOptionETC
//				XSSFCell cell_CN_IS_CASTING = xssfEBOMSheetRow.getCell(74); //CN_IS_CASTING , cdmPartIsCasting
//				XSSFCell cell_CN_OPTION_DESC = xssfEBOMSheetRow.getCell(75); //CN_OPTION_DESC ,cdmPartOptionDescription
//				XSSFCell cell_CN_FOR_MAC = xssfEBOMSheetRow.getCell(76); //CN_FOR_MAC 
//				XSSFCell cell_CN_FOR_MIL = xssfEBOMSheetRow.getCell(77); //CN_FOR_MIL
//				XSSFCell cell_CN_FOR_MIS = xssfEBOMSheetRow.getCell(78); //CN_FOR_MIS
//				XSSFCell cell_CN_FOR_MMT = xssfEBOMSheetRow.getCell(79); //CN_FOR_MMT
//				//cdmPartInvestor = cell_CN_FOR_MAC,cell_CN_FOR_MIL,cell_CN_FOR_MMT
//				XSSFCell cell_CN_REAL_WEIGHT = xssfEBOMSheetRow.getCell(80); //CN_REAL_WEIGHT ,cdmPartRealWeight
//				XSSFCell cell_CN_COUNTRY = xssfEBOMSheetRow.getCell(81); //CN_COUNTRY ,cdmCountry
//				
//				XSSFCell cell_CN_PRODUCT_DIV = xssfEBOMSheetRow.getCell(82); //CN_PRODUCT_DIV
//				XSSFCell cell_CN_GLOBAL_LOCAL = xssfEBOMSheetRow.getCell(83); //CN_GLOBAL_LOCAL ,cdmPartGlobal
//				
//				XSSFCell cell_CN_PROJECT_CODE = xssfEBOMSheetRow.getCell(84); //CN_PROJECT_CODE
//				XSSFCell cell_CN_OPTION_DRAWING = xssfEBOMSheetRow.getCell(85); //CN_OPTION_DRAWING
//				XSSFCell cell_CN_FOR_DRAWING_FINISH = xssfEBOMSheetRow.getCell(86); //CN_FOR_DRAWING_FINISH
//				XSSFCell cell_CN_FOR_DRAWING_SIZE = xssfEBOMSheetRow.getCell(87); //CN_FOR_DRAWING_SIZE
//				XSSFCell cell_CN_FOR_DRAWING_REMARK = xssfEBOMSheetRow.getCell(88); //CN_FOR_DRAWING_REMARK ,cdmPartERPInterface
//				XSSFCell cell_CN_ITEM_TYPE2 = xssfEBOMSheetRow.getCell(89); //CN_ITEM_TYPE2 ,cdmPartItemType
//				XSSFCell cell_CN_APPLY_PARTLIST = xssfEBOMSheetRow.getCell(90); //CN_APPLY_PARTLIST 
//				XSSFCell cell_CN_PREVIOUS_PART = xssfEBOMSheetRow.getCell(91); //CN_PREVIOUS_PART
//				XSSFCell cell_CN_COMPLEX_BODY = xssfEBOMSheetRow.getCell(92); //CN_COMPLEX_BODY
//				XSSFCell cell_CN_MAIN_PART_NUMBER = xssfEBOMSheetRow.getCell(93); //CN_MAIN_PART_NUMBER
//				XSSFCell cell_CN_VEHICLE_DESC = xssfEBOMSheetRow.getCell(94); //CN_VEHICLE_DESC
//				XSSFCell cell_CN_VEHICLE_CODE = xssfEBOMSheetRow.getCell(95); //CN_VEHICLE_CODE
//				XSSFCell cell_CN_DRAWING_NO = xssfEBOMSheetRow.getCell(96); //CN_DRAWING_NO ,cdmPartDrawingNo
//				XSSFCell cell_CN_SUB_ID = xssfEBOMSheetRow.getCell(97); //CN_SUB_ID ,cdmSub_Id
//				XSSFCell cell_CN_CHANGE_REASON = xssfEBOMSheetRow.getCell(98); //CN_CHANGE_REASON ,cdmPartChangeReason
//				XSSFCell cell_CN_SURFACE_TREATMENT_KEYIN = xssfEBOMSheetRow.getCell(99); //CN_SURFACE_TREATMENT_KEYIN
//				XSSFCell cell_CN_OVERSEAS_ORG6 = xssfEBOMSheetRow.getCell(100); //CN_OVERSEAS_ORG6 ,cdmMCP_Org
//				XSSFCell cell_CN_OVERSEAS_ORG6_PART_TYPE = xssfEBOMSheetRow.getCell(101); //CN_OVERSEAS_ORG6_PART_TYPE ,cdmMCP_Part_Type
//				XSSFCell cell_CN_OVERSEAS_ORG6_INOUT = xssfEBOMSheetRow.getCell(102); //CN_OVERSEAS_ORG6_INOUT ,cdmMCP_BOM_Management
//				/*CAD Weight(㎏)*/
////				XSSFCell cell_CN_OVERSEAS_ORG6_INOUT = xssfEBOMSheetRow.getCell(103); //CAD Weight(㎏)
//				 
//				 
//				/* String 데이타 */
//				String stPartNo =  (String) cdmCommonExcel.getCellValue(cell_CN_ID)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ID)).trim(); //attribute[cdmPartNo]
//				String stRevision =  (String) cdmCommonExcel.getCellValue(cell_REVISION)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_REVISION)).trim(); // revision 
//				String stState =  (String) cdmCommonExcel.getCellValue(cell_STATE)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_STATE)).trim(); // state 
//			
//				String stCreateDate  =  (String) cdmCommonExcel.getCellValue(cell_CreateDate)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CreateDate)).trim(); //create Date 
//				String stCreateUser =  (String) cdmCommonExcel.getCellValue(cell_USER_OBJECT_ID)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_USER_OBJECT_ID)).trim();// createUser
//				String stModifiedUser  =  (String) cdmCommonExcel.getCellValue(cell_USER_ID_MOD)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_USER_ID_MOD)).trim(); // cdmModifiedbyForPart
//				String stModificationDate =  (String) cdmCommonExcel.getCellValue(cell_MODIFICATION_DATE)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_MODIFICATION_DATE)).trim(); //modification_date
//				String stPartName =  (String) cdmCommonExcel.getCellValue(cell_TDM_DESCRIPTION)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_TDM_DESCRIPTION)).trim(); // attribute[cdmPartName]
//				String stUOM  =  (String) cdmCommonExcel.getCellValue(cell_TDM_UOM)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_TDM_UOM)).trim(); //attribute[Unit of Measure]
//				String stPhase =  (String) cdmCommonExcel.getCellValue(cell_PHASE)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_PHASE)).trim(); // attribute[cdmPartPhase]
//				String stPreviousRevision =  (String) cdmCommonExcel.getCellValue(cell_PAR_REVISION)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_PAR_REVISION)).trim(); //cdmPreviousRevision
//				String stApprovalDate  =  (String) cdmCommonExcel.getCellValue(cell_APPROVAL_DATE)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_APPROVAL_DATE)).trim(); //APPROVAL_DATE
//				String stOrgCreateDate =  (String) cdmCommonExcel.getCellValue(cell_TDM_ORG_CREATEDATE)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_TDM_ORG_CREATEDATE)).trim(); // attribute[cdmOrgCreateDate]
//			
//				String stApprovedUser =  (String) cdmCommonExcel.getCellValue(cell_TDM_APPROVED_BY)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_TDM_APPROVED_BY)).trim(); //cdmApprovedUserForPart
//				String stProject =  (String) cdmCommonExcel.getCellValue(cell_CN_PROJECT)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_PROJECT)).trim(); //attribute[cdmPartProject]
//			
//				String stProductName =  (String) cdmCommonExcel.getCellValue(cell_CN_PRODUCT_NAME)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_PRODUCT_NAME)).trim(); // attribute[cdmProductNameForPart]
//				String stcPartGroup =  (String) cdmCommonExcel.getCellValue(cell_CN_PART_GROUP)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_PART_GROUP)).trim(); // attribute[cdmPartGroupForPart] 
//				
//				String stPartName2 =  (String) cdmCommonExcel.getCellValue(cell_CN_PART_NAME)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_PART_NAME)).trim(); // CN_PART_NAME
//				String stWeight2 =  (String) cdmCommonExcel.getCellValue(cell_CN_WEIGHT)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_WEIGHT)).trim(); //attribute[cdmWeight2ForPart]
//				
//				/*EstimatedWeight*/ 
//				String stEstimatedWeight =  (String) cdmCommonExcel.getCellValue(cell_CN_ESTIMATED_WEIGHT)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ESTIMATED_WEIGHT)).trim(); // attribute[cdmPartEstimatedWeight]
//				String stEstimatedWeightUnit =  (String) cdmCommonExcel.getCellValue(cell_CN_WEIGHT_UNIT)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_WEIGHT_UNIT)).trim(); //EstimatedWeight Unit 
//				
//				String stTopItem =  (String) cdmCommonExcel.getCellValue(cell_CN_TOP_ITEM)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_TOP_ITEM)).trim(); //attribute[cdmTopItemForPart]
//				String stPhantomItem =  (String) cdmCommonExcel.getCellValue(cell_CN_PHANTOM_ITEM)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_PHANTOM_ITEM)).trim(); //attribute[cdmPhantomPartCheck]
//				String stPartType =  (String) cdmCommonExcel.getCellValue(cell_CN_ITEM_TYPE)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ITEM_TYPE)).trim(); // attribute[cdmPartType]
//				String stServiceItem =  (String) cdmCommonExcel.getCellValue(cell_CN_SERVICE_ITEM)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_SERVICE_ITEM)).trim(); //attribute[cdmServiceItem]
//				String stPartMaterial =  (String) cdmCommonExcel.getCellValue(cell_CN_ITEM_MATERIAL)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ITEM_MATERIAL)).trim(); //attribute[cdmPartMaterial]
//				String stPartPublishingTarget =  (String) cdmCommonExcel.getCellValue(cell_CN_COST)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_COST)).trim(); //attribute[cdmPartPublishingTarget]
//				String stDescription =  (String) cdmCommonExcel.getCellValue(cell_CN_COMMENTS)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_COMMENTS)).trim(); //cdmDescription
//				String stPartOEMItemNumber =  (String) cdmCommonExcel.getCellValue(cell_CN_OEM_PART_NUMBER)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OEM_PART_NUMBER)).trim(); //attribute[cdmPartOEMItemNumber]
//				String stECName =  (String) cdmCommonExcel.getCellValue(cell_EC_NAME)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_EC_NAME)).trim(); //attribute[cdmECNameForPart]
//				String stECONumber =  (String) cdmCommonExcel.getCellValue(cell_CN_ECO_NUMBER)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ECO_NUMBER)).trim(); //attribute[cdmPartECONumber]
//				String stProductGroup =  (String) cdmCommonExcel.getCellValue(cell_CN_PRODUCT_GROUP)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_PRODUCT_GROUP)).trim(); //attribute[cdmProductGroupForPart]
//				
//				String stSeriesItem =  (String) cdmCommonExcel.getCellValue(cell_CN_SERIES_ITEM)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_SERIES_ITEM)).trim(); //attribute[cdmSeriesItem]
//				String stVehicle =  (String) cdmCommonExcel.getCellValue(cell_CN_VEHICLE)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_VEHICLE)).trim(); //attribute[cdmPartVehicle]
//				String stCustomerForPart =  (String) cdmCommonExcel.getCellValue(cell_CN_CUSTOMER)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_CUSTOMER)).trim(); //attribute[cdmCustomerForPart]
//				String stSize =  (String) cdmCommonExcel.getCellValue(cell_CN_SIZE)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_SIZE)).trim(); //attribute[cdmPartSize]
//				String stSurfaceTreatment =  (String) cdmCommonExcel.getCellValue(cell_CN_SURFACE_TREATMENT)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_SURFACE_TREATMENT)).trim(); //attribute[cdmPartSurfaceTreatment]
//				String stPartSurface =  (String) cdmCommonExcel.getCellValue(cell_CN_SURFACE_AREA)=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_SURFACE_AREA)).trim(); //attribute[cdmPartSurface]
//				String stcPartApprovalType =  (String) cdmCommonExcel.getCellValue(cell_CN_ITEM_TYPE1 )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ITEM_TYPE1)).trim(); //attribute[cdmPartApprovalType]
//				
//				String stMaterial2 =  (String) cdmCommonExcel.getCellValue(cell_CN_MATERIAL                 )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_MATERIAL                 )).trim(); //attribute[cdmMaterial2ForPart]
//				String stPartOrg1 =  (String) cdmCommonExcel.getCellValue(cell_CN_ORG1                     )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ORG1                     )).trim(); //attribute[cdmPartOrg1]
//				String stPartOrg2  =  (String) cdmCommonExcel.getCellValue(cell_CN_ORG2                     )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ORG2                     )).trim(); //attribute[cdmPartOrg2]
//				String stPartOrg3 =  (String) cdmCommonExcel.getCellValue(cell_CN_ORG3                     )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ORG3                     )).trim(); //attribute[cdmPartOrg3]
//				String stMCAOrg =  (String) cdmCommonExcel.getCellValue(cell_CN_ORG                      )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ORG                      )).trim();  //attribute[cdmMCAOrg]
//				String stMCABOMManagement =  (String) cdmCommonExcel.getCellValue(cell_CN_MCA_INOUT                )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_MCA_INOUT                )).trim(); //attribute[cdmMCABOMManagement]
//				String stMCAPartType =  (String) cdmCommonExcel.getCellValue(cell_CN_MCA_PART_TYPE_REF        )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_MCA_PART_TYPE_REF        )).trim(); //attribute[cdmMCAPartType]
//				String stPartOption1 =  (String) cdmCommonExcel.getCellValue(cell_CN_OPTION1                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OPTION1                  )).trim(); //attribute[cdmPartOption1]
//				String stPartOption2 =  (String) cdmCommonExcel.getCellValue(cell_CN_OPTION2                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OPTION2                  )).trim(); //attribute[cdmPartOption2]
//				String stPartOption3 =  (String) cdmCommonExcel.getCellValue(cell_CN_OPTION3                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OPTION3                  )).trim(); //attribute[cdmPartOption3]
//				String stPartOption4 =  (String) cdmCommonExcel.getCellValue(cell_CN_OPTION4                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OPTION4                  )).trim(); //attribute[cdmPartOption4]
//				String stPartOption5 =  (String) cdmCommonExcel.getCellValue(cell_CN_OPTION5                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OPTION5                  )).trim(); //attribute[cdmPartOption5]
//				String stPartOption6 =  (String) cdmCommonExcel.getCellValue(cell_CN_OPTION6                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OPTION6                  )).trim(); //attribute[cdmPartOption6]
//				String stPartOption7 =  (String) cdmCommonExcel.getCellValue(cell_CN_OPTION7                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OPTION7                  )).trim(); //attribute[cdmPartOption7]
//				String stPartOptionETC =  (String) cdmCommonExcel.getCellValue(cell_CN_OPTION_ETC               )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OPTION_ETC               )).trim(); //attribute[cdmPartOptionETC]
//				String stPartIsCasting =  (String) cdmCommonExcel.getCellValue(cell_CN_IS_CASTING               )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_IS_CASTING               )).trim(); //attribute[cdmPartIsCasting]
//				String stPartOptionDescription =  (String) cdmCommonExcel.getCellValue(cell_CN_OPTION_DESC              )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OPTION_DESC              )).trim();  //attribute[cdmPartOptionDescription]
//				String stMAC =  (String) cdmCommonExcel.getCellValue(cell_CN_FOR_MAC                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_FOR_MAC                  )).trim();  //attribute[strInvestor]
//				String stMIL =  (String) cdmCommonExcel.getCellValue(cell_CN_FOR_MIL                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_FOR_MIL                  )).trim();  //attribute[strInvestor]
//				String stMIS =  (String) cdmCommonExcel.getCellValue(cell_CN_FOR_MIS                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_FOR_MIS                  )).trim();  //attribute[cdmMISForPart]
//				String stMMT =  (String) cdmCommonExcel.getCellValue(cell_CN_FOR_MMT                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_FOR_MMT                  )).trim();  //attribute[strInvestor]
//				//cdmPartInvestor = cell_CN_FOR_MAC,cell_CN_FOR_MIL,cell_CN_FOR_MMT
//				String stPartRealWeight =  (String) cdmCommonExcel.getCellValue(cell_CN_REAL_WEIGHT              )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_REAL_WEIGHT              )).trim(); //attribute[cdmPartRealWeight]
//				String stCountry =  (String) cdmCommonExcel.getCellValue(cell_CN_COUNTRY                  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_COUNTRY                  )).trim();   //attribute[cdmCountry]
//				String stPartProductType =  (String) cdmCommonExcel.getCellValue(cell_CN_PRODUCT_DIV              )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_PRODUCT_DIV              )).trim(); //attribute[cdmPartProductType]
//				String stPartGlobal =  (String) cdmCommonExcel.getCellValue(cell_CN_GLOBAL_LOCAL             )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_GLOBAL_LOCAL             )).trim(); //attribute[cdmPartGlobal]
//				String stProjectCodeForPart =  (String) cdmCommonExcel.getCellValue(cell_CN_PROJECT_CODE             )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_PROJECT_CODE             )).trim(); //attribute[cdmProjectCodeForPart]
//				String stcdmOptionDrawingForPart =  (String) cdmCommonExcel.getCellValue(cell_CN_OPTION_DRAWING           )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OPTION_DRAWING           )).trim(); //attribute[cdmOptionDrawingForPart]
//				
//				String stDrawingFinishForPart =  (String) cdmCommonExcel.getCellValue(cell_CN_FOR_DRAWING_FINISH       )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_FOR_DRAWING_FINISH       )).trim(); //attribute[cdmDrawingFinishForPart]
//				String stDrawingSize =  (String) cdmCommonExcel.getCellValue(cell_CN_FOR_DRAWING_SIZE         )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_FOR_DRAWING_SIZE         )).trim(); //attribute[cdmDrawingSizeForPart]
//				String stPartERPInterface =  (String) cdmCommonExcel.getCellValue(cell_CN_FOR_DRAWING_REMARK       )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_FOR_DRAWING_REMARK       )).trim(); //attribute[cdmPartERPInterface]
//				String stPartItemType =  (String) cdmCommonExcel.getCellValue(cell_CN_ITEM_TYPE2               )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_ITEM_TYPE2               )).trim(); //attribute[cdmPartItemType]
//				String stApplyPartListForPart =  (String) cdmCommonExcel.getCellValue(cell_CN_APPLY_PARTLIST           )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_APPLY_PARTLIST           )).trim();  //attribute[cdmApplyPartListForPart]
//				String stPreviousPart =  (String) cdmCommonExcel.getCellValue(cell_CN_PREVIOUS_PART            )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_PREVIOUS_PART            )).trim(); //attribute[cdmPreviousPart]
//				String stComplexBody =  (String) cdmCommonExcel.getCellValue(cell_CN_COMPLEX_BODY             )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_COMPLEX_BODY             )).trim(); //cdmComplexBodyForPart
//				String stMainPartNumberForPart =  (String) cdmCommonExcel.getCellValue(cell_CN_MAIN_PART_NUMBER         )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_MAIN_PART_NUMBER         )).trim(); //attribute[cdmMainPartNumberForPart]
//				String cdmPartVehicleTemp1 =  (String) cdmCommonExcel.getCellValue(cell_CN_VEHICLE_DESC             )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_VEHICLE_DESC             )).trim(); //attribute[cdmPartVehicle] 대체
////				String  =  (String) cdmCommonExcel.getCellValue(cell_CN_VEHICLE_CODE             )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_VEHICLE_CODE             )).trim();
//				String stPartDrawingNo =  (String) cdmCommonExcel.getCellValue(cell_CN_DRAWING_NO               )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_DRAWING_NO               )).trim(); //attribute[cdmPartDrawingNo]
//				String stSubIdForPart =  (String) cdmCommonExcel.getCellValue(cell_CN_SUB_ID                   )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_SUB_ID                   )).trim(); //cdmSubIdForPart
//				String stPartChangeReason  =  (String) cdmCommonExcel.getCellValue(cell_CN_CHANGE_REASON            )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_CHANGE_REASON            )).trim(); // attribute[cdmPartChangeReason]
//				String stSurfaceTreatmentKeyin =  (String) cdmCommonExcel.getCellValue(cell_CN_SURFACE_TREATMENT_KEYIN  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_SURFACE_TREATMENT_KEYIN  )).trim(); //attribute[stSurfaceTreatmentKeyin]
//				String stMCPOrg =  (String) cdmCommonExcel.getCellValue(cell_CN_OVERSEAS_ORG6            )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OVERSEAS_ORG6            )).trim(); //attribute[cdmMCPOrg]
//				String stMCPPartType =  (String) cdmCommonExcel.getCellValue(cell_CN_OVERSEAS_ORG6_PART_TYPE  )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OVERSEAS_ORG6_PART_TYPE  )).trim(); //cdmMCPPartType
//				String stMCPBOMManagement =  (String) cdmCommonExcel.getCellValue(cell_CN_OVERSEAS_ORG6_INOUT      )=="null"?"":((String) cdmCommonExcel.getCellValue(cell_CN_OVERSEAS_ORG6_INOUT      )).trim(); //cdmMCPBOMManagement
//
//				
//			
//		
//				Map paramMap = (Map) JPO.unpackArgs(args);
//				HashMap attributeInfoMap = new HashMap();
//
//				attributeInfoMap.put("TypeActual", "");
//				attributeInfoMap.put("Phase", "");
//				attributeInfoMap.put("PartNo", "");
//				attributeInfoMap.put("Vehicle", "");
//				attributeInfoMap.put("PartName", "");
//				attributeInfoMap.put("Project", "");
//				attributeInfoMap.put("ApprovalType", "");
//				attributeInfoMap.put("PartType", "");
//				attributeInfoMap.put("Global", "");
//				attributeInfoMap.put("DrawingNo", "");
//				attributeInfoMap.put("UnitOfMeasure", ""); // TDM_UOM
//				attributeInfoMap.put("ECONumber", ""); // CN_ECO_NUMBER
//				attributeInfoMap.put("ItemType", "");
//				attributeInfoMap.put("OEMItemNumber", "");
//				attributeInfoMap.put("Comments", "");
//				attributeInfoMap.put("ChangeReason", "");
//				attributeInfoMap.put("Org1", "");
//				attributeInfoMap.put("Org2", "");
//				attributeInfoMap.put("Org3", "");
//				attributeInfoMap.put("ProductType", "");
//				attributeInfoMap.put("ERPInterface", "");
//				attributeInfoMap.put("Surface", "");
//				attributeInfoMap.put("EstimatedWeight", "");
//				attributeInfoMap.put("Material", "");
//				attributeInfoMap.put("RealWeight", "");
//				attributeInfoMap.put("Size", "");
//				attributeInfoMap.put("CADWeight", "");
//				attributeInfoMap.put("SurfaceTreatment", "");
//				attributeInfoMap.put("IsCasting", "");
//				attributeInfoMap.put("Option1", "");
//				attributeInfoMap.put("Option2", "");
//				attributeInfoMap.put("Option3", "");
//				attributeInfoMap.put("Option4", "");
//				attributeInfoMap.put("Option5", "");
//				attributeInfoMap.put("Option6", "");
//				attributeInfoMap.put("OptionETC", "");
//				attributeInfoMap.put("OptionDescription", "");
//				attributeInfoMap.put("PublishingTarget", "");
//				attributeInfoMap.put("Investor", "");
//				attributeInfoMap.put("ProjectType", "");
//				attributeInfoMap.put("cdmPartVehicle", "");
//
//				DomainObject partObj = new DomainObject();
//				try {
//					String strType = "cdmMechanicalPart";
//					if (cdmConstantsUtil.TEXT_PROTO.equals(stPhase)) {
//						partObj.createObject(context, strType, stPartNo, "01", "cdmPartDevelopmentPolicy", "eService Production");
//						// partObj.setAttributeValues(context, attributes);
//					} else if (cdmConstantsUtil.TEXT_PRODUCTION.equals(stPhase)) {
//						partObj.createObject(context, strType, stPartNo, "A", "cdmPartProductionPolicy", "eService Production");
//						// partObj.setAttributeValues(context, attributes);
//					}
//				} catch (Exception e1) {
//					e1.printStackTrace();
//				}
//		    	
//			
//			}
//		} catch (Exception e) {
//			// TODO: handle exception
//		}
//	}
}


