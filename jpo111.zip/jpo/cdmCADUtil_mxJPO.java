import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmJsonDataUtil;
import com.mando.util.cdmPropertiesUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class cdmCADUtil_mxJPO {
	public cdmCADUtil_mxJPO (Context context, String[] args) throws Exception {
	}
	
	public cdmCADUtil_mxJPO () throws Exception {
	}

	public Context getEnoviaContext() throws Exception {
		Context context = null;
		try {
			context = ContextUtil.getAnonymousContext();
			ContextUtil.pushContext(context);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return context;
	}

	/**
	 * Function to obtain the number of part connected to CAD object and part specification.
	 * Extract the previous value from "-" in New Name passed to Param and return it.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public String getSpecificationPartNumber(Context context, String[] args) throws Exception {
		Map paramMap = JPO.unpackArgs(args);
		return getSpecificationPartNumber(context, paramMap);
	}

	public String getSpecificationPartNumber(Context context, Map paramMap) throws Exception {
		String result = "";

		try {
			String newName = (String) paramMap.get("newName");
			String match = "[^\uAC00-\uD7A3xfe0-9a-zA-Z\\-]";
			newName = newName.replaceAll(match, "_");
			newName = newName.replace(" ", "-");

			if (newName.indexOf("-") > -1) {
				result = newName.substring(0, newName.indexOf("-"));
			} else if(newName.indexOf("_") > -1) {
				result = newName.substring(0, newName.indexOf("_"));
			}else {
				result = newName;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return result;
	}

	/**
	 * Return the EBOM list of the parent object passed to the parameter.
	 * @param context
	 * @param parentObj
	 * @return
	 * @throws Exception
	 */
	public MapList getEbomList(Context context, DomainObject parentObj) throws Exception {
		MapList resultList = new MapList();
		try {
			StringList busSelect = new StringList();
			busSelect.add(cdmConstantsUtil.SELECT_ID);
			busSelect.add(cdmConstantsUtil.SELECT_NAME);
			busSelect.add(cdmConstantsUtil.SELECT_TYPE);
			busSelect.add(cdmConstantsUtil.SELECT_REVISION);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_NAME);
			busSelect.add(cdmConstantsUtil.SELECT_REVISION);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_MATERIAL);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_OEM_ITEM_NUMBER);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_APPLY_PART_LIST);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_APPLY_SIZE_LIST);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_SIZE);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_APPLY_SURFACE_TREATMENT_LIST);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_SURFACE_TREATMENT);
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_OEM_ITEM_NUMBER);
			
			busSelect.add("to[" + cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE + "].from." + cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_COMMON_CODE);

			StringList relSelect = new StringList();
			relSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_QUANTITY);
			relSelect.add(cdmConstantsUtil.SELECT_FROM_ID);
			relSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_FIND_NUMBER);

			String busWhere = "";

			parentObj.open(context);
			System.out.println(">>>> parentObj.EBOM START :: " + parentObj.getName());
			resultList = parentObj.getRelatedObjects(	context,
														cdmConstantsUtil.RELATIONSHIP_EBOM,
														cdmConstantsUtil.TYPE_PART,
														busSelect,
														relSelect,
														false,
														true,
														(short)0,
														busWhere,
														null,
														0);
			System.out.println(">>>> parentObj.EBOM E N D :: " + parentObj.getName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultList;
	}

	/**
	 * The cdmPartDrawingNo value of the Part Type returns a list of parts that are the same as the Parameter name.
	 * @param context
	 * @param name
	 * @return
	 * @throws Exception
	 */
	public MapList getAssyList(Context context, String type, String name, String revision) throws Exception {
		MapList resultList = new MapList();

		if (cdmStringUtil.isEmpty(name)) return resultList;
		StringBuffer sbBusWhere = new StringBuffer();
		sbBusWhere.append("(");
		sbBusWhere.append(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_DRAWING_NO).append("=='").append(name).append("'");
		sbBusWhere.append("||");
		sbBusWhere.append(cdmConstantsUtil.SELECT_NAME).append("=='").append(name).append("'").append(")");
		sbBusWhere.append("&&");
		sbBusWhere.append("type!='");
		sbBusWhere.append(cdmConstantsUtil.TYPE_CDMPHANTOMPART);
		sbBusWhere.append("'");

		if ("last".equals(revision) || cdmStringUtil.isEmpty(revision)) {
			revision = "*";
			sbBusWhere.append("&&");
			sbBusWhere.append("revision==last");
		}

		if (cdmStringUtil.isEmpty(type)) type = cdmConstantsUtil.TYPE_PART;

		StringList busSelect = new StringList();
		busSelect.add(cdmConstantsUtil.SELECT_NAME);
		busSelect.add(cdmConstantsUtil.SELECT_ID);
		busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_NAME);
		busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_OEM_ITEM_NUMBER);

		if (isPhantomPart(context, type, name, revision)) {
			String partId = getObjectId(context, type, name, revision);
			DomainObject partObj = DomainObject.newInstance(context, partId);
			resultList = partObj.getRelatedObjects(	context,
													cdmConstantsUtil.RELATIONSHIP_EBOM,
													cdmConstantsUtil.TYPE_PART,
													busSelect,
													null,
													false,
													true,
													(short)0,
													sbBusWhere.toString(),
													null,
													0);
		} else {
			resultList = DomainObject.findObjects(	context,
					type, 
					cdmConstantsUtil.QUERY_WILDCARD,
					revision,
					"*",
					"*",
					sbBusWhere.toString(),
					true,
					busSelect );
		}

		resultList.sort(cdmConstantsUtil.SELECT_NAME, "ascending", "string");
		return resultList;
	}

	public void initCountMap(Map countMap, MapList assyList, MapList ebomList) throws Exception {
		try {
			Map assyMap = null;
			Map ebomMap = null;
			
			String assyId = null;
			String ebomId = null;
			for (Iterator assyItr = assyList.listIterator(); assyItr.hasNext();) {
				assyMap = (Map) assyItr.next();
				assyId = (String) assyMap.get(cdmConstantsUtil.SELECT_ID);

				for (Iterator ebomItr = ebomList.listIterator(); ebomItr.hasNext();) {
					ebomMap = (Map) ebomItr.next();
					ebomId = (String) ebomMap.get(cdmConstantsUtil.SELECT_ID);

					if (countMap.containsKey(assyId + ebomId)) continue;

					countMap.put(assyId + ebomId, "-");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void setItemNo(MapList childMapList, Map infoMap) throws Exception {
		try {

			childMapList.addSortKey(cdmConstantsUtil.SELECT_LEVEL, "ascending", "String");
			childMapList.addSortKey(cdmConstantsUtil.SELECT_NAME, "ascending", "String");
			childMapList.sort();
			
			String preLevel = "1";
			String level = null;
			String childItemNo = null;
			String parentItemNo = null;
			String childObjectId = null;
			String parentObjectId = null;
			int itemIndex = 0;

			Map childMap = null;
			Map parentMap = null;

			StringList itemNoList = new StringList();

			for (Iterator childItr = childMapList.listIterator(); childItr.hasNext();) {
				Map tempMap = (Map) childItr.next();
				level = (String) tempMap.get(cdmConstantsUtil.SELECT_LEVEL);

				childObjectId = (String) tempMap.get(cdmConstantsUtil.SELECT_ID);
				childMap = (Map) infoMap.get(childObjectId);
				childItemNo = (String) childMap.get("ITEM_NO");

				if (cdmStringUtil.isNotEmpty(childItemNo)) continue;

				parentObjectId = (String) tempMap.get(cdmConstantsUtil.SELECT_FROM_ID);
				parentMap = (Map) infoMap.get(parentObjectId);
				if (parentMap != null) parentItemNo = (String) parentMap.get("ITEM_NO");

				if (preLevel.equals(level) == false) {
					itemIndex = 0;
					preLevel = level;
				}

				if ("1".equals(level)) {
					childItemNo = String.format("%010d", ++itemIndex);
				} else {
					childItemNo = parentItemNo + "-";
					int lastSeq = 1;
					while (true) {
						if (itemNoList.contains(childItemNo + String.format("%010d", lastSeq)) == false) break;
						lastSeq++;
					}
					childItemNo = childItemNo + String.format("%010d", lastSeq);
				}
				itemNoList.add(childItemNo);
				childMap.put("ITEM_NO", childItemNo);
				tempMap.put("ITEM_NO", childItemNo);
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings("unchecked")
	public void setSkipItemNo(MapList childMapList, Map infoMap) throws Exception {
		try {

			String preLevel = "1";
			String level = null;
			String childItemNo = null;
			String parentItemNo = null;
			String childObjectId = null;
			String parentObjectId = null;
			String checkPartList = null;
			int itemIndex = 0;

			Map childMap = null;
			Map parentMap = null;

			StringList itemNoList = new StringList();

			for (Iterator childItr = childMapList.listIterator(); childItr.hasNext();) {
				Map tempMap = (Map) childItr.next();
				level = (String) tempMap.get(cdmConstantsUtil.SELECT_LEVEL);
				checkPartList = (String) tempMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_APPLY_PART_LIST);

				childObjectId = (String) tempMap.get(cdmConstantsUtil.SELECT_ID);
				childMap = (Map) infoMap.get(childObjectId);
				childItemNo = (String) childMap.get("ITEM_NO");

				if ("false".equals(checkPartList)) {
					childMap.put("ITEM_NO", "99999");
					tempMap.put("ITEM_NO", "99999");
					continue;
				}
				parentObjectId = (String) tempMap.get(cdmConstantsUtil.SELECT_FROM_ID);
				parentMap = (Map) infoMap.get(parentObjectId);
				if (parentMap != null) parentItemNo = (String) parentMap.get("ITEM_NO");

//				if (preLevel.equals(level) == false) {
//					itemIndex = 0;
//					preLevel = level;
//				}

				if ("1".equals(level)) {
					childItemNo = String.format("%010d", ++itemIndex);
				} else {
					childItemNo = parentItemNo + "-";
					int lastSeq = 1;
					while (true) {
						if (itemNoList.contains(childItemNo + String.format("%010d", lastSeq)) == false) break;
						lastSeq++;
					}
					childItemNo = childItemNo + String.format("%010d", lastSeq);
				}
				itemNoList.add(childItemNo);
				childMap.put("ITEM_NO", childItemNo);
				tempMap.put("ITEM_NO", childItemNo);
			}

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	public Map getAttributeGroupValueMap(Context context, String partId) throws Exception {
		Map resultMap = new HashMap();
		try {

			DomainObject partObj = DomainObject.newInstance(context, partId);
			String partFamilyId = partObj.getInfo(context, "to[" + cdmConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM + "].from.id");

			if (cdmStringUtil.isEmpty(partFamilyId)) return resultMap;

			DomainObject partFamilyObj = DomainObject.newInstance(context, partFamilyId);
			String strSysInterface = partFamilyObj.getAttributeValue(context, DomainConstants.ATTRIBUTE_MXSYSINTERFACE);

			String strMQL = "print interface $1 select derived dump";
			String resStr = MqlUtil.mqlCommand(context, strMQL, true, strSysInterface);
			StringList slResultList   = FrameworkUtil.split(resStr, ",");
			int iResultSize = slResultList.size();
			if (iResultSize == 0) return resultMap;

			for (int i = 0; i < iResultSize; i++) {
				String strAttributeGroupObjectName = (String) slResultList.get(i);
				String strExists = MqlUtil.mqlCommand(context, "print bus cdmAttributeGroupObject \""+strAttributeGroupObjectName+"\" - select exists dump");
				
				if ("FALSE".equals(strExists)) continue;
				
				String mqlValue = MqlUtil.mqlCommand(context, "print bus cdmAttributeGroupObject \""+strAttributeGroupObjectName+"\" - select attribute[cdmAttributeGroupSequence] dump");
				String[] mqlValueArray = mqlValue.split("\\|");
				for (int k = 0; k < mqlValueArray.length; k++) {
					Map map = new HashMap();
					String[] resultArray = mqlValueArray[k].split(",");
					String attrName     = resultArray[0];
					resultMap.put(attrName, partObj.getAttributeValue(context, attrName));
//					partObj.setAttributeValue(context, attrName, partObj.getName() + "_" + k);
				}
			}
//			partObj.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_NAME, "PartName_" + partObj.getName());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultMap;
	}

	public MapList getAttributeGroupValues(Context context, String partId) throws Exception {
		MapList resultMapList = new MapList();
		try {

			DomainObject partObj = DomainObject.newInstance(context, partId);
			String partFamilyId = partObj.getInfo(context, "to[" + cdmConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM + "].from.id");

			if (cdmStringUtil.isEmpty(partFamilyId)) return resultMapList;

			DomainObject partFamilyObj = DomainObject.newInstance(context, partFamilyId);
			String strSysInterface = partFamilyObj.getAttributeValue(context, DomainConstants.ATTRIBUTE_MXSYSINTERFACE);

			String strMQL = "print interface $1 select derived dump";
			String resStr = MqlUtil.mqlCommand(context, strMQL, true, strSysInterface);
			StringList slResultList   = FrameworkUtil.split(resStr, ",");
			int iResultSize = slResultList.size();
			if (iResultSize == 0) return resultMapList;

			int iCnt = 0;
			StringList dupAttrNameList = new StringList();
			for (int i = 0; i < iResultSize; i++) {
				String strAttributeGroupObjectName = (String) slResultList.get(i);
				String strExists = MqlUtil.mqlCommand(context, "print bus cdmAttributeGroupObject \""+strAttributeGroupObjectName+"\" - select exists dump");
				
				if ("FALSE".equals(strExists)) continue;
				
				String mqlValue = MqlUtil.mqlCommand(context, "print bus cdmAttributeGroupObject \""+strAttributeGroupObjectName+"\" - select attribute[cdmAttributeGroupSequence] dump");
				String[] mqlValueArray = mqlValue.split("\\|");
				for (int k = 0; k < mqlValueArray.length; k++) {
		    		Map map = new HashMap();
		    		String[] resultArray = mqlValueArray[k].split(",");
		    		String attrName     = resultArray[0];
		    		if (dupAttrNameList.contains(attrName)) continue;
		    		String attrSequence = resultArray[1];
		    		map.put("attrName", attrName);
		    		map.put("attrSequence", attrSequence);
		    		map.put("attrValue", partObj.getAttributeValue(context, attrName));
		    		resultMapList.add(map);
		    		dupAttrNameList.add(attrName);
		    	}
		    	resultMapList.sort("attrSequence", "ascending", "integer");
		    	iCnt ++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultMapList;
	}

	public LinkedHashMap setListSortMap(MapList paramMapList, Map paramMap) throws Exception {
		LinkedHashMap resultMap = new LinkedHashMap();
		try {

			paramMapList.sort("ITEM_NO", "ascending", "String");

			Map tempMap = null;
			Map targetMap = null;
			String objectId = null;
			int seq = 1;
			for (Iterator itr = paramMapList.listIterator(); itr.hasNext();) {
				tempMap = (Map) itr.next();
				objectId = (String) tempMap.get(cdmConstantsUtil.SELECT_ID);
				targetMap = (Map) paramMap.get(objectId);
				if (targetMap != null) {
					tempMap.put("inSeq", seq);
					resultMap.put(objectId, targetMap);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultMap;
	}

	public String getObjectId(Context context, String type, String name, String revision) throws Exception {
		String returnValue = "";
		try {
			String busWhere = "";
			if ("last".equals(revision)) {
				revision = "*";
				busWhere = "revision==last";
			}

			StringList busSelect = new StringList();
			busSelect.add(cdmConstantsUtil.SELECT_ID);

			MapList findList = DomainObject.findObjects(	context,
															type, 
															name, 
															revision,
															"*",
															"*",
															busWhere,
															true,
															busSelect );

			if (findList.size() > 1) return returnValue + "Duplicate Part Number.";

			if (findList.size() > 0) {
				Map infoMap = (Map) findList.get(0);
				returnValue = (String) infoMap.get(cdmConstantsUtil.SELECT_ID);
			} else {
				returnValue = returnValue + "Object is not Exist.";
			}
		} catch (Exception e) {
			throw e;
		}
		return returnValue;
	}

	public boolean isPhantomPart(Context context, String type, String name, String revision) throws Exception {
		try {
			if (cdmStringUtil.isEmpty(type + name + revision)) return false;

			String objectId = getObjectId(context, type, name, revision);
			DomainObject partObj = DomainObject.newInstance(context, objectId);

			String partType = partObj.getInfo(context, cdmConstantsUtil.SELECT_TYPE);

			if (cdmConstantsUtil.TYPE_CDMPHANTOMPART.equals(partType)) return true;
		} catch (Exception e) {
			throw e;
		}
		return false;
	}

	public String getPartNumber(Context context, String[] args) throws Exception {
		Map paramMap = JPO.unpackArgs(args);
		return getPartNumber(context, paramMap);
	}
	public String getPartNumber(Context context, Map paramMap) throws Exception {
		String strPartNumber = "";
		try {
			String propertyFile = "config/mybatis/config.properties";
			String plmPartUrl = "PLM_PARTS_URL";
			String blockCode = (String) getMapStringData(paramMap, "blockCode");
			String partNumber = (String) getMapStringData(paramMap, "partNumber");
			String prePartNumber = (String) getMapStringData(paramMap, "prePartNumber");

			// Skip Start "_" Part Number 
			if (partNumber.indexOf("_") == 1) return partNumber;
			if (partNumber.indexOf("-") > -1) partNumber = partNumber.substring(0, partNumber.indexOf("-"));
			if (prePartNumber.indexOf("-") > -1) prePartNumber = prePartNumber.substring(0, prePartNumber.indexOf("-"));
			if (blockCode.indexOf(":") > -1) blockCode = blockCode.substring(0, blockCode.indexOf(":"));

			// [B] Delete PLM Part Number
			if (partNumber.equals(prePartNumber) == false && cdmStringUtil.isNotEmpty(prePartNumber)) {
				StringBuffer strParamBuffer = new StringBuffer();
				// partNumber=BC22401800&uid=mandoAdmin
				strParamBuffer.append("uid=").append(context.getUser());
				strParamBuffer.append("&partNumber=").append(prePartNumber);
				String strUrl = cdmPropertiesUtil.getPropValue(propertyFile, "PLM_DEL_PART_URL");
				String strJsonObject = (String) cdmJsonDataUtil.getJSON(strUrl + strParamBuffer.toString());
				String strResultInfo = cdmJsonDataUtil.getJSONResultData(strJsonObject, "RESULT");
				System.out.println(">>>> Delete PLM Part No :: " + strJsonObject);
				if ("FAIL".equals(strResultInfo)){
					String errorMsg = cdmJsonDataUtil.getJSONResultData(strJsonObject, "ERRMSG");
					return errorMsg;
				}
			}
			// [E] Delete PLM Part Number

			// [B] Create PLM Part Number
			StringBuffer strParamBuffer = new StringBuffer();
			if (cdmStringUtil.isEmpty(partNumber)) {
				strParamBuffer.append("uid=").append(context.getUser());
				strParamBuffer.append("&blockCode=").append(blockCode);//Block Code
				strParamBuffer.append("&count=1");
				strParamBuffer.append("&serialYn=N");
				strParamBuffer.append("&specificationYn=N");
			} else {
				plmPartUrl = "PLM_PART_URL";
				strParamBuffer.append("uid=").append(context.getUser());
				strParamBuffer.append("&partNumber=").append(partNumber);
			}

			String strUrl = cdmPropertiesUtil.getPropValue(propertyFile, plmPartUrl);
			String strJsonObject = (String) cdmJsonDataUtil.getJSON(strUrl + strParamBuffer.toString());
			String strResultInfo = cdmJsonDataUtil.getJSONResultData(strJsonObject, "RESULT" );
			if("SUCCESS".equals(strResultInfo)){
				if (cdmStringUtil.isNotEmpty(partNumber)) {
					strPartNumber = cdmJsonDataUtil.getJSONResultData(strJsonObject, "PARTNUMBER");
				} else {
					strPartNumber = cdmJsonDataUtil.getJSONResultArrayData(strJsonObject, "DATA", 0);
				}

				blockCode = strPartNumber.substring(0, 5);
				Map pfInfoMap = getPartFamilyInfo(context, blockCode);
				String partName = (String) pfInfoMap.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_FAMILY_BLOCK_CODE_NAME);
				if (partName.indexOf(":") > -1) partName = partName.substring(partName.indexOf(":") + 1, partName.length());
				strPartNumber = strPartNumber + "-" + partName;
				String match = "[^\uAC00-\uD7A3xfe0-9a-zA-Z\\-]";
				strPartNumber = strPartNumber.replaceAll(match, "_");
				strPartNumber = strPartNumber.replace(" ", "_");
				System.out.println("strPartNumber     :     "+strPartNumber);
				
			}
			// [E] Create PLM Part Number
		} catch (Exception e) {
			e.printStackTrace();
		}
		return strPartNumber;
	}

	public Map getPartFamilyInfo(Context context, String blockCode) throws Exception {
		Map resultMap = new HashMap();
		try {
			StringBuffer sbBusWhere = new StringBuffer();
			sbBusWhere.append(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_FAMILY_BLOCK_CODE_NAME);
			sbBusWhere.append("~=");
			sbBusWhere.append("'").append(blockCode).append("*'");

			StringList busSelect = new StringList();
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_FAMILY_BLOCK_CODE_NAME);
			busSelect.add(cdmConstantsUtil.SELECT_ID);

			MapList pfList = DomainObject.findObjects(	context,
														cdmConstantsUtil.TYPE_PART_FAMILY, 
														cdmConstantsUtil.QUERY_WILDCARD,
														cdmConstantsUtil.QUERY_WILDCARD,
														"*",
														"*",
														sbBusWhere.toString(),
														true,
														busSelect );

			if (pfList.size() > 0) {
				resultMap = (Map) pfList.get(0);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return resultMap;
	}

	@SuppressWarnings({ "unchecked", "rawtypes", "unused" })
	public void setInitAttribute(Context context, String[] args) throws Exception {
		try {
			String objectId = args[0];
			String partSpecName = null;
			
			StringList targetCADType = new StringList();
			targetCADType.add(cdmConstantsUtil.TYPE_CATPRODUCT);
			targetCADType.add(cdmConstantsUtil.TYPE_CATPART);
			targetCADType.add(cdmConstantsUtil.TYPE_CATDrawing);
			targetCADType.add(cdmConstantsUtil.TYPE_CDMNXDRAWING);
			targetCADType.add(cdmConstantsUtil.TYPE_CDMAUTOCAD);

			if (cdmStringUtil.isEmpty(objectId)) return;

			DomainObject cadObject = DomainObject.newInstance(context, objectId);

			StringList selCatiaBusSelect = new StringList();
			selCatiaBusSelect.add(cdmConstantsUtil.SELECT_NAME);
			selCatiaBusSelect.add(cdmConstantsUtil.SELECT_TYPE);
			selCatiaBusSelect.add(cdmConstantsUtil.SELECT_POLICY);

			Map cadInfoMap = cadObject.getInfo(context, selCatiaBusSelect);

			String catiaObjectName = (String) cadInfoMap.get(cdmConstantsUtil.SELECT_NAME);
			String catiaType = (String) cadInfoMap.get(cdmConstantsUtil.SELECT_TYPE);
			String catiaPolicy = (String) cadInfoMap.get(cdmConstantsUtil.SELECT_POLICY);

			if (targetCADType.contains(catiaType) == false) return;
			if (cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY.equals(catiaPolicy)) return;

			// [B] modify by jtkim 2017-02-07
			Map updateMap = new HashMap();
			// [CREATE_CATIA-001] CATIA Drawing Number Attribute Update
			Map paramMap = new HashMap();
			paramMap.put("newName", catiaObjectName);
			partSpecName = getSpecificationPartNumber(context, paramMap);
			cadObject.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_DRAWING_NO, partSpecName);
			// [E] modify by jtkim 2017-02-07


			// [B] modify by jtkim 2017-01-06
			// [PARTSPEC-001] When creating CATIA Object Drawing No, connect with EBOM Part.
			String mqlResult = MqlUtil.mqlCommand(context, "temp query bus Part \"" + partSpecName + "\" * where revision==last select id current dump");
			if (cdmStringUtil.isEmpty(mqlResult)) return;

			// [0] : type, [1] : name, [2] : revision, [3] : id, [4] : current
			StringList resultList = FrameworkUtil.split(mqlResult, ",");
			String ePartType = (String) resultList.get(0);
			String ePartId = (String) resultList.get(3);
			String current = (String) resultList.get(4);

			if (cdmStringUtil.isEmpty(ePartId)) return;

			DomainObject ebomPartObj = DomainObject.newInstance(context, ePartId);
			StringList partSpecTypeList = ebomPartObj.getInfoList(context, "from[Part Specification].to.type");

			if (cdmConstantsUtil.STATE_CDM_PARTPOLICY_POLICY_PRELIMINARY.equals(current) == false) return;
			if (partSpecTypeList.contains(catiaType)) return;

			if (cdmConstantsUtil.TYPE_CATDrawing.equals(catiaType)) {
				ebomPartObj.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_DRAWING_NO, partSpecName);
			}

			if (cdmConstantsUtil.TYPE_CDMPHANTOMPART.equals(ePartType)) {
				if (cdmConstantsUtil.TYPE_CATPRODUCT.equals(catiaType) || cdmConstantsUtil.TYPE_CATPART.equals(catiaType)) {
					cadObject.setAttributeValue(context, "IEF-EBOMSync-PartTypeAttribute", cdmConstantsUtil.TYPE_CDMPHANTOMPART);
				}

				ebomPartObj.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_DRAWING_NO, partSpecName);
			}
			DomainRelationship.connect(context, ePartId, cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION, objectId, false);
			// [E] modify by jtkim 2017-01-06


		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Object getMapStringData(Map paramMap, String key) throws Exception {
		Object valueObj = null;
		try {
			valueObj = paramMap.get(key) == null ? "" : paramMap.get(key);
		} catch (Exception e) {
			e.printStackTrace();
			return e.toString();
		}
		return valueObj;
	}
	
	public void setPartSpecConnection(Context context, String[] args) throws Exception {
		try {
			String objectId = args[0];
			StringList cadType = new StringList();
			cadType.add(cdmConstantsUtil.TYPE_CATPRODUCT);
			cadType.add(cdmConstantsUtil.TYPE_CATPART);
			cadType.add(cdmConstantsUtil.TYPE_CATDrawing);

			if (cdmStringUtil.isNotEmpty(objectId)) {
				DomainObject cadObject = DomainObject.newInstance(context, objectId);

				StringList selBusSelect = new StringList();
				selBusSelect.add(cdmConstantsUtil.SELECT_NAME);
				selBusSelect.add(cdmConstantsUtil.SELECT_TYPE);
				selBusSelect.add(cdmConstantsUtil.SELECT_POLICY);

				Map cadInfoMap = cadObject.getInfo(context, selBusSelect);
				String catiaObjectName = (String) cadInfoMap.get(cdmConstantsUtil.SELECT_NAME);
				String type = (String) cadInfoMap.get(cdmConstantsUtil.SELECT_TYPE);
				String policy = (String) cadInfoMap.get(cdmConstantsUtil.SELECT_POLICY);
				boolean isContinue = true;
				if (cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY.equals(policy) == false) {
					if (cadType.contains(type)) {
						Map paramMap = new HashMap();
						paramMap.put("newName", catiaObjectName);
						catiaObjectName = getSpecificationPartNumber(context, paramMap);
					}
					cadObject.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_DRAWING_NO, catiaObjectName);
	
					// [B] modify by jtkim 2017-01-06
					// [PARTSPEC-002] Connected with EBOM Part when CATIA Object Revise.
					String mqlResult = MqlUtil.mqlCommand(context, "temp query bus Part \"" + catiaObjectName + "\" * where revision==last select id current dump");
					if (cdmStringUtil.isNotEmpty(mqlResult)) {
	
						// [0] : type, [1] : name, [2] : revision, [3] : id, [4] : current
						StringList resultList = FrameworkUtil.split(mqlResult, ",");
				 		String ePartId = (String) resultList.get(3);
						String current = (String) resultList.get(4);

						DomainObject ebomPartObj = DomainObject.newInstance(context, ePartId);
						StringList partSpecTypeList = ebomPartObj.getInfoList(context, "from[Part Specification].to.type");

						DomainObject eCadObj = DomainObject.newInstance(context, objectId);
						eCadObj.open(context);
						String catiaType = (String) eCadObj.getTypeName();
//						if (partSpecTypeList.contains(arg0))

						if (cdmConstantsUtil.STATE_CDM_PARTPOLICY_POLICY_PRELIMINARY.equals(current) == false) isContinue = false;
						if (partSpecTypeList.contains(catiaType)) isContinue = false;
						if (cdmStringUtil.isEmpty(ePartId)) isContinue = false;

						if (isContinue) DomainRelationship.connect(context, ePartId, cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION, objectId, false);
					}
					// [E] modify by jtkim 2017-01-06
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void cadObjectAttrUpdate(Context context, String[] args) throws Exception {
		try {
			StringList targetAttrName = new StringList();
			targetAttrName.add(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS);

			String objectId = args[0];
			String attrNm 	= args[1];
			String attrVal	= args[2];

			if (targetAttrName.contains(attrNm) == false) return;

			// [B] modify by jtkim 2017-02-13

			DomainObject cadObject = DomainObject.newInstance(context, objectId);

			String copyCADName = "";
			String partName = "";

			Map paramMap = new HashMap();
			Map updateMap = new HashMap();
			try {
				switch (attrNm) {
					// [CREATE_CATIA-002] CATIA Weight decimal round 2 digits
					case "cdmDocumentsMass":
						float fDocumentMass = Float.parseFloat(attrVal);
						double dDocumentMass = Math.round(fDocumentMass * 100) / 100.0;
						cadObject.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS, dDocumentMass + "");
						break;
					default:
						break;
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			// [E] modify by jtkim 2017-02-13
		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void copyAttributeUpdate(Context context, String[] args) throws Exception {
		try {
			StringList selBusList = new StringList();
			selBusList.add(cdmConstantsUtil.SELECT_NAME);
			String objectId = args[0];

			if (cdmStringUtil.isEmpty(objectId)) return;
			// [B] modify by jtkim 2017-02-13
			// [CREATE_CATIA-002] CATIA Weight decimal round 2 digits
			DomainObject copyObject = DomainObject.newInstance(context, objectId);

			Map copyInfoMap = copyObject.getInfo(context, selBusList);

			String copyCADName = (String) copyInfoMap.get(cdmConstantsUtil.SELECT_NAME);
			Map paramMap = new HashMap();
			paramMap.put("newName", copyCADName);

			String partName = getSpecificationPartNumber(context, paramMap);
			
			Map updateMap = new HashMap();
			updateMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DRAWING_NO, partName);
			updateMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_NOMENCLATURE, partName);
			copyObject.setAttributeValues(context, updateMap);
			// [E] modify by jtkim 2017-02-13
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
}
