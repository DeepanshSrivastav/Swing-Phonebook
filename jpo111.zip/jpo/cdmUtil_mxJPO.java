import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.mxType;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

public class cdmUtil_mxJPO {
    /**
     * ReadOnly Textbox HTML
     * @param context
     * @param args
     * @return
     * @throws Exception
     */
    @SuppressWarnings({ "rawtypes", "unused" })
	public String getReadOnlyTextboxForCreateHtmlOutput (Context context, String[] args) throws Exception {
    	String sbReturn = "";
    	
    	HashMap programMap = (HashMap) JPO.unpackArgs(args);
    	HashMap fieldMap = (HashMap) programMap.get("fieldMap");
    	HashMap settingMap = (HashMap) fieldMap.get("settings");
    	
    	String strFieldName = (String) fieldMap.get("name");
    	String size = (String) settingMap.get("Field Size");
    	if (cdmStringUtil.isEmpty(size)) size = "20";
    	sbReturn = "<input name='" + strFieldName + "' title='" + strFieldName + "' id='" + strFieldName + "' value='' type='text' size='" + size + "' readOnly='true'/>";

    	return sbReturn;
    }

    /**
     * ReadOnly Textbox HTML
     * @param context
     * @param args
     * @return
     * @throws Exception
     */
    public String getReadOnlyTextboxHtmlOutput (Context context, String[] args) throws Exception {
    	StringBuffer sbReturn = new StringBuffer();
    	
    	HashMap programMap = (HashMap) JPO.unpackArgs(args);
    	HashMap fieldMap = (HashMap) programMap.get("fieldMap");
    	String strFieldName = (String) fieldMap.get("name");
    	HashMap paramMap = (HashMap) programMap.get("paramMap");
    	
    	HashMap requestMap = (HashMap) programMap.get("requestMap");
    	String sMode = (String) requestMap.get("mode");
    	
    	String sSelect = (String) fieldMap.get("expression_businessobject");
    	if (cdmStringUtil.isEmpty(sSelect)) return sbReturn.toString();
    	
    	String sObjectId = (String) paramMap.get("objectId");
    	DomainObject documentObject = DomainObject.newInstance(context, sObjectId);
    	String sValue = documentObject.getInfo(context, sSelect);

    	if (sMode != null && "edit".equals(sMode)) {
    		sbReturn.append("<input name='" + strFieldName + "fieldValue' type='hidden' value='" + sValue + "'/>");
        	sbReturn.append("<input readOnly name='" + strFieldName + "' title='" + strFieldName + "' id='" + strFieldName + "' value='" + sValue + "' size='40' readOnly='true'/>");
    	} else {
    		sbReturn.append(sValue);
    	}

    	return sbReturn.toString();
    }

	/***
	 * @param context
	 * @param parameterMap
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("unchecked")
	public static Map<String,String> setAttributeMap(Context context, Map<String,Object> map, String typeName, DomainObject obj)throws Exception{
		HashMap<String,String> newObjAttrMap = new HashMap<String,String>();
		try{
			MapList attrMapList = mxType.getAttributes(context, typeName);
			Iterator<Map<String,String>> itr = attrMapList.iterator();
			while(itr.hasNext()) {
				Map<String,String> itrMap = (Map<String,String>)itr.next();
				String attrName = (String)itrMap.get("name");
				String attrValue = (String)map.get(attrName);
				if(!UIUtil.isNullOrEmpty(attrValue)) {
					newObjAttrMap.put(attrName, attrValue);
				}
			}
			if(obj != null){
				obj.setAttributeValues(context, newObjAttrMap);
			}
			return newObjAttrMap;
		}catch(Exception ex){
			throw ex;
		}
	}
	
	@SuppressWarnings("rawtypes")
	public StringList excludeConnectedObjects(Context context, String[] args) throws Exception {
		StringList resultList = new StringList();
		
		try {
			
			Map programMap = (Map) JPO.unpackArgs(args);
	        String parentId = (String) programMap.get("objectId");
	        String relName = (String) programMap.get("relName");
	        String from = (String) programMap.get("from");
			
	        boolean isTo = true;
	        boolean isFrom = false;
	        
            if (cdmStringUtil.isEmpty(parentId)) return resultList;
            if (cdmStringUtil.isEmpty(relName)) return resultList;
            
            if (cdmStringUtil.isNotEmpty(from) && "true".equals(from)) {
            	isTo = false;
            	isFrom = true;
            }
            
            
            StringList selBusSelect = new StringList();
            selBusSelect.add(cdmConstantsUtil.SELECT_ID);

            StringList selRelSelect = new StringList();
            
            String sBusWhere = "";
            String sRelWhere = "";
            
            DomainObject obj = DomainObject.newInstance(context, parentId);
            
            MapList connectList = obj.getRelatedObjects(	context,
            												PropertyUtil.getSchemaProperty(context,relName),
            												cdmConstantsUtil.QUERY_WILDCARD,
															selBusSelect,
															selRelSelect,
															isTo,
															isFrom,
															(short) 0,
															sBusWhere,
															sRelWhere,
															0
														);

            Map tempMap = new HashMap();
            String connectId = "";
            for (int i = 0; i < connectList.size(); i++) {
            	tempMap = (Map) connectList.get(i);
            	connectId = (String) tempMap.get(cdmConstantsUtil.SELECT_ID);
            	resultList.add(connectId);
            }

		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultList;
	}
	
	/**
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public boolean checkLocked(Context context, String args[]) throws Exception {
		boolean isLocked = false;
		
		try {
	        if (args == null || args.length < 1) throw (new IllegalArgumentException());

	        HashMap programMap   = (HashMap) JPO.unpackArgs(args);
	        String objectId = (String) programMap.get("objectId");
	        String contextUser = context.getUser();
	        String locker = "";
	        
	        DomainObject obj = DomainObject.newInstance(context, objectId);
	        
	        isLocked = obj.isLocked(context);
	        
	        if (isLocked == false) return true;
	        
	        locker = obj.getInfo(context, cdmConstantsUtil.SELECT_LOCKER);
	        
	        if (contextUser.equals(locker)) return true;
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return isLocked;
	}
}
