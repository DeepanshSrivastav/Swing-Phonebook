/*
**  DSCShowRelationshipDetailsLink
**
**  @ Dassault Systemes, 2002-2007.  All rights reserved.
**
**  Program to display Relationship Details Icon
*/

import matrix.db.Context;

public class DSCShowRelationshipDetailsLink_mxJPO extends DSCShowRelationshipDetailsLinkBase_mxJPO
{
	/**
	   * Constructor.
	   *
	   * @since Sourcing V6R2008-2
	*/
	public DSCShowRelationshipDetailsLink_mxJPO(Context context, String[] args) throws Exception
	{
          super(context, args);
	}
}
