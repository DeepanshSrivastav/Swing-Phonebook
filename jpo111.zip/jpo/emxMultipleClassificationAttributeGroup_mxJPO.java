import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Vector;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.classification.Classification;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.XSSUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

/**
 * Copyright (c) 1992-2015 Dassault Systemes. All Rights Reserved. This program
 * contains proprietary and trade secret information of MatrixOne,Inc.
 * Copyright notice is precautionary only and does not evidence any actual or
 * intended publication of such program.
 *
 * FileName : "$RCSfile: ${CLASSNAME}.java.rca $"
 * Author   : "$Author: przemek $
 * Version  : "$Revision: 1.6 $"
 * Date     : "$Date: Wed Oct 22 16:54:23 2008 $"
 * static const char RCSID[] = "$Id: ${CLASSNAME}.java.rca 1.6 Wed Oct 22 16:54:23 2008 przemek Experimental przemek $"
 */

public class emxMultipleClassificationAttributeGroup_mxJPO extends emxMultipleClassificationAttributeGroupBase_mxJPO
{

    public emxMultipleClassificationAttributeGroup_mxJPO () throws Exception {
        super();
    }

    /**
     * This method creates Attribute Group
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds the following input arguments
     *        0 - New Value (Attribute Group Name)
     *        1 - Description (optional)
     *        2 - Attributes (optional)
     * @throws Exception if the operation fails
     */
    public void createAttributeGroup(Context context, String[] args) throws Exception {
        try {
        	ContextUtil.startTransaction(context, true);
            HashMap programMap      = (HashMap)JPO.unpackArgs(args);
            HashMap paramMap        = (HashMap)programMap.get("paramMap");
            HashMap requestMap      = (HashMap)programMap.get("requestMap");
            String newName          = (String) paramMap.get("New Value");
            String description      = ((String[])requestMap.get("Description"))[0];
            String attributes       = ((String[])requestMap.get("Attributes"))[0];
            description             = FrameworkUtil.findAndReplace(description,"\n","");
            description             = FrameworkUtil.findAndReplace(description,"\r","");
            
            Classification classification = new Classification();
            classification.createAttributeGroup(context, newName, description, attributes);
            /*modify by 9/5/16 mj.kim start */
            String checkMigration = "";
            /*modify by 9/5/16 mj.kim end */
            
            createObjectAttributeGroup(context, newName, description, attributes,checkMigration);
            ContextUtil.commitTransaction(context);
        } catch(Exception ex) {
        	ContextUtil.abortTransaction(context);
            throw new FrameworkException(ex.toString());
        }
    }
    
    
    /**
     * create by 9/5/16 mj.kim
     * 다른 JPO에서 createObjectAttributeGroup 사용하기 위한 method
     * @param context
     * @param args
     * @throws Exception
     */
	public void tempCreateObjectAttributeGroup(Context context, String args[]) throws Exception {
		try {
			Map hm = (Map)JPO.unpackArgs(args);
			String sAttributeName = (String)hm.get("attributeName");
			String sDescription = (String)hm.get("description");
			String sAttributes = (String)hm.get("attributes");
			String migrationCheck = "Y";
			
			createObjectAttributeGroup(context, sAttributeName, sDescription, sAttributes,migrationCheck);
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
    
	
	private void createObjectAttributeGroup(Context context, String newName, String description, String attributes,String migrationCheck) throws Exception {
		System.out.println("newName      :  "+newName);
		System.out.println("description  :  "+description);
		System.out.println("attributes   :  "+attributes);
		/*modify by 9/5/16 mj.kim start */
		System.out.println("migrationCheck   :  "+migrationCheck);
		/*modify by 9/5/16 mj.kim end */
		DomainObject domObj = new DomainObject();
		try{
			domObj.createObject(context, "cdmAttributeGroupObject", newName, "-", "cdmAttributeGroupObjectPolicy", "eService Production");
			domObj.setAttributeValue(context, "cdmDescription", attributes);
			
			StringBuffer strBuffer = new StringBuffer();
			String[] attributesArray = attributes.split("\\|");
			int iAttrSize = attributesArray.length;
			for(int k=0; k<iAttrSize; k++){
				if(! "".equals(strBuffer.toString())){
					strBuffer.append("|");
					strBuffer.append(attributesArray[k]);
					strBuffer.append(",");
					strBuffer.append(String.valueOf(k+1));
				}else{
					if(k != 0){
						strBuffer.append("|");
					}
					strBuffer.append(attributesArray[k]);
					strBuffer.append(",");
					strBuffer.append(String.valueOf(k+1));
				}
			}
			domObj.setAttributeValue(context, "cdmAttributeGroupSequence", strBuffer.toString());
			/*modify by 9/5/16 mj.kim start */
			if(cdmStringUtil.isNotEmpty(migrationCheck) && "Y".equals(migrationCheck)){
				domObj.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, migrationCheck);	
			}
			/*modify by 9/5/16 mj.kim end */
		} catch (Exception e){
			e.printStackTrace();
		}
	}
	
	public String modifyObjectAttributeGroup(Context context, String[]args) throws Exception {
		HashMap programMap      = (HashMap)JPO.unpackArgs(args);
        String parentId = (String)programMap.get("parentId");
        StringList slAttrList = (StringList)programMap.get("slAttrList");
        
		try{
			ContextUtil.startTransaction(context, true);
			int iAttrSize = slAttrList.size();
			BusinessObject bo = new BusinessObject("cdmAttributeGroupObject", parentId, "-", "eService Production");
			String objectId = bo.getObjectId(context);
			DomainObject domObj = new DomainObject(objectId);
			String strDescription = domObj.getAttributeValue(context, "cdmDescription");
			String strAttributeGroupSequence = domObj.getAttributeValue(context, "cdmAttributeGroupSequence");
			String[] strDescriptionArray = strDescription.split("\\|");
			int iAttributeSize = strDescriptionArray.length;
			iAttributeSize = iAttributeSize + 1;
			
			StringBuffer strBuffer = new StringBuffer();
			StringBuffer strSequenceBuffer = new StringBuffer();
			strBuffer.append(strDescription);
			strSequenceBuffer.append(strAttributeGroupSequence);
			
			for(int i=0; i<iAttrSize; i++){
				String strAttribute = (String)slAttrList.get(i);
				if(! "".equals(strBuffer.toString())){
					strBuffer.append("|");
					strBuffer.append(strAttribute);
					
					strSequenceBuffer.append("|");
					strSequenceBuffer.append(strAttribute);
					strSequenceBuffer.append(",");
					strSequenceBuffer.append(String.valueOf(iAttributeSize+i));
				}else{
					if(i != 0){
						strBuffer.append("|");
					}
					strBuffer.append(strAttribute);
					
					strSequenceBuffer.append(strAttribute);
					strSequenceBuffer.append(",");
					strSequenceBuffer.append(String.valueOf(iAttributeSize+i));
				}
			}
			domObj.setAttributeValue(context, "cdmDescription", strBuffer.toString());
			domObj.setAttributeValue(context, "cdmAttributeGroupSequence", strSequenceBuffer.toString());
			ContextUtil.commitTransaction(context);
			return "success";
		}catch(Exception e){
			e.printStackTrace();
			ContextUtil.abortTransaction(context);
			return "error";
		}
	}
	
	public String removeObjectAttributeGroup(Context context, String[]args) throws Exception {
		HashMap programMap      = (HashMap)JPO.unpackArgs(args);
        String parentId = (String)programMap.get("parentId");
        StringList slAttrList = (StringList)programMap.get("strAttrList");
        
		try{
			ContextUtil.startTransaction(context, true);
			int iAttrSize = slAttrList.size();
			BusinessObject bo = new BusinessObject("cdmAttributeGroupObject", parentId, "-", "eService Production");
			String objectId = bo.getObjectId(context);
			DomainObject domObj = new DomainObject(objectId);
			String strDescription = domObj.getAttributeValue(context, "cdmDescription");
			String strAttributeGroupSequence = domObj.getAttributeValue(context, "cdmAttributeGroupSequence");
			
			String[] strDescriptionArray = strDescription.split("\\|");
			int iAttributeSize = strDescriptionArray.length;
			for(int k=0; k<iAttributeSize; k++){
				String strDescriptionAttribute = strDescriptionArray[k];
				for(int h=0; h<iAttrSize; h++){
					String sAttribute = (String)slAttrList.get(h);
					String sFrontDelimitAttribute = sAttribute + "|";
					String sBackDelimitAttribute = "|" + sAttribute;
					if(strDescription.contains(sFrontDelimitAttribute)){
						strDescription = strDescription.replace(sFrontDelimitAttribute, "");
					}else if(strDescription.contains(sBackDelimitAttribute)){
						strDescription = strDescription.replace(sBackDelimitAttribute, "");
					}else if(sAttribute.equals(strDescriptionAttribute)){
						strDescription = strDescription.replace(sAttribute, "");
					}
				}
			}
			domObj.setAttributeValue(context, "cdmDescription", strDescription);
			
			String[] strAttributeGroupSequenceArray = strAttributeGroupSequence.split("\\|");
			int iAttrSequenceSize = strAttributeGroupSequenceArray.length;
			for(int i=0; i<iAttrSequenceSize; i++){
				String strAttributeGroupAndSequence = strAttributeGroupSequenceArray[i];
				for(int j=0; j<iAttrSize; j++){
					String sAttribute = (String)slAttrList.get(j);
					
					String[] sAttributeArray = strAttributeGroupAndSequence.split(",");
					String strRepace = ","+sAttributeArray[1];
					sAttribute = sAttribute.replace("|", "");
					sAttribute = sAttribute + strRepace;
					
					String sFrontDelimitAttribute = sAttribute + "|";
					String sBackDelimitAttribute = "|" + sAttribute;
					
					if(strAttributeGroupSequence.contains(sFrontDelimitAttribute)){
						strAttributeGroupSequence = strAttributeGroupSequence.replace(sFrontDelimitAttribute, "");
					}else if(strAttributeGroupSequence.contains(sBackDelimitAttribute)){
						strAttributeGroupSequence = strAttributeGroupSequence.replace(sBackDelimitAttribute, "");
					}else if(sAttribute.equals(strAttributeGroupAndSequence)){
						strAttributeGroupSequence = strAttributeGroupSequence.replace(sAttribute, "");
					}
				}
			}
			
			domObj.setAttributeValue(context, "cdmAttributeGroupSequence", strAttributeGroupSequence);
			ContextUtil.commitTransaction(context);
			return "success";
		}catch(Exception e){
			e.printStackTrace();
			ContextUtil.abortTransaction(context);
			return "error";
		}
	}
	
	/**
     * Gets the list of HTML string for each Attributes type for UI display
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds the following list of arguments:
     *  0 - objectList the list of Attributes
     * @return Vector list of HTML string for each Attribute type
     * @throws exception if the operation fails
     */
    public Vector getAttributeGroupSequence(Context context, String[] args) throws Exception {
        Vector columnValues = new Vector();
        try {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            Map paramList = (HashMap) programMap.get("paramList");
            String objectName = (String) paramList.get("treeLabel");
            MapList objList = (MapList) programMap.get("objectList");
            
            BusinessObject bo = new BusinessObject("cdmAttributeGroupObject", objectName, "-", "eService Production");
            String objId = bo.getObjectId(context);
			DomainObject domObj = new DomainObject(objId);
			String strDescriptionSequence = domObj.getAttributeValue(context, "cdmAttributeGroupSequence");
			String[] strDescriptionSequenceArray = strDescriptionSequence.split("\\|");
            
            int iObjSize = objList.size();
            for(int i=0; i<iObjSize; i++){
            	Map map = (Map)objList.get(i);
            	String strAttrName = (String)map.get("name");
            	
            	for(int k=0; k<strDescriptionSequenceArray.length; k++){
            		String[] strAttributeSequenceArray = strDescriptionSequenceArray[k].split(",");
            		if(strAttributeSequenceArray[0].equals(strAttrName)){
            			columnValues.addElement(strAttributeSequenceArray[1]);
            		}
            	}
            }
            
        } catch (Exception ex) {
        	ex.printStackTrace();
            throw new Exception(ex.getMessage());
        }
        return columnValues;
    }
    
    public void updateAttributeGroupSequence(Context context, String[] args) throws Exception {
    	try {
    		ContextUtil.startTransaction(context, true);
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            HashMap paramMap        = (HashMap)programMap.get("paramMap");
            HashMap requestMap      = (HashMap)programMap.get("requestMap");
            
            String newValue   = (String)paramMap.get("New Value");
            String objectId   = (String)paramMap.get("objectId");
            String objectName = (String)requestMap.get("objectName");
//            System.out.println("newValue     :    "+newValue);
//            System.out.println("objectId     :    "+objectId);
//            System.out.println("objectName   :    "+objectName);
            BusinessObject bo = new BusinessObject("cdmAttributeGroupObject", objectName, "-", "eService Production");
            String objId = bo.getObjectId(context);
			DomainObject domObj = new DomainObject(objId);
			String strDescription = domObj.getAttributeValue(context, "cdmDescription");
			String strDescriptionSequence = domObj.getAttributeValue(context, "cdmAttributeGroupSequence");
			
			StringBuffer strBuffer = new StringBuffer();
			String[] strDescriptionArray = strDescriptionSequence.split("\\|");
			for(int i=0; i<strDescriptionArray.length; i++){
				String strDescriptionAttribute = strDescriptionArray[i];
				String[] strDescriptionAttributeArray = strDescriptionAttribute.split(",");
				String strSequence = strDescriptionAttributeArray[1];
				
				if(objectId.equals(strDescriptionAttributeArray[0])){
					
					strSequence = strSequence.replace(strSequence, newValue);
					StringBuffer sBuf = new StringBuffer();
					sBuf.append(strDescriptionAttributeArray[0]);
					sBuf.append(",");
					sBuf.append(strSequence);
					if(! "".equals(strBuffer.toString())){
						strBuffer.append("|");
						strBuffer.append(sBuf);
					}else{
						if(i != 0){
							strBuffer.append("|");
						}
						strBuffer.append(sBuf);
					}
				}else{
					if(! "".equals(strBuffer.toString())){
						strBuffer.append("|");
						strBuffer.append(strDescriptionAttribute);
					}else{
						if(i != 0){
							strBuffer.append("|");
						}
						strBuffer.append(strDescriptionAttribute);
					}
				}
			}
			
			domObj.setAttributeValue(context, "cdmAttributeGroupSequence", strBuffer.toString());
			ContextUtil.commitTransaction(context);
    	}catch (Exception e){
    		e.printStackTrace();
    		ContextUtil.abortTransaction(context);
    	}    
    }
    
    /**
     * Gets all the attributes associated with a particular Attribute Group.
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds the following list of arguments:
     *  0 - objectName the ObjectName
     * @return MapList with the details of Attributes related to the Attribute Group
     * @throws exception if the operation fails
     */
    @com.matrixone.apps.framework.ui.ProgramCallable
    public MapList getRelatedAttributes(Context context, String[] args) throws Exception {
        try {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            String strCharSet =  (String )programMap.get("charSet");
            String objectName = (String) programMap.get("objectName");

            // Fixed for bug# 319190
            if(null == strCharSet ) {
              strCharSet = "UTF-8";
            }
            //Added for Bug No 333702 Dated 6/5/2007 Begin
            //Added for Bug No 333702 Dated 6/5/2007 Ends.
            //objectName = FrameworkUtil.decodeURL(objectName, strCharSet);

            String result = "";
            MapList returnList  = new MapList();
            String strQuery     = "";
            strQuery            = "list interface $1 select $2 $3 dump $4";
            try {
                result = MqlUtil.mqlCommand(context, strQuery, objectName,"attribute.name","attribute.owner",",");
                
                String mqlValue = MqlUtil.mqlCommand(context, "print bus cdmAttributeGroupObject '"+objectName+"' - select attribute[cdmAttributeGroupSequence] dump");
                
                if ((result != null) && !(result.equals(""))) {
                    returnList = new MapList();
                    
                    StringList attrObjectList = FrameworkUtil.split(mqlValue, "|");
                        
                    String attrName = "";
                    String attrSequence = "";
                    int iObjSize = attrObjectList.size();
                    for(int i=0; i<iObjSize; i++){
                        HashMap objectMap = new HashMap();
                        String value = (String)attrObjectList.get(i);
                        String[] valueArray = value.split(",");
                        attrName = valueArray[0];
                        attrSequence = valueArray[1];
                        
                        objectMap.put("sequence", attrSequence);
                        objectMap.put("name", attrName);
                        objectMap.put("id", attrName);
                        returnList.add(objectMap);
                    }
                    returnList.sort("sequence", "ascending", "integer");
                }
            } catch (Exception ex) {
                throw ex;
            }
            return returnList;
        } catch (Exception ex) {
            throw ex;
        }
    }
    
    /**
     * Gets the list of HTML string for each Attributes Display Name for UI display
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds the following list of arguments:
     *  0 - uiType the UI Type
     *  1 - languageStr the language
     * @return Vector list of HTML string for each Attribute Display name
     * @throws exception if the operation fails
     */
    public Vector getAttributeName(Context context, String[] args)
            throws Exception {
        Vector columnValues = new Vector();
        try {
            HashMap programMap = (HashMap) JPO.unpackArgs(args);
            MapList objList = (MapList) programMap.get("objectList");
            objList.sort("sequence", "ascending", "integer");
            HashMap map;
            String strLanguageStr = ((String) ((HashMap) programMap.get("paramList")).get("languageStr"));
            Iterator itr = objList.iterator();
            while (itr.hasNext()) {
                map = (HashMap) itr.next();
                //AttributeType att = new AttributeType((String) map.get("id"));
                StringBuffer strI18nAttributeName = new StringBuffer();
                strI18nAttributeName.append("<img align=\"top\" SRC=\"images/iconSmallAttribute.gif\"></img><span class='object'>");
                strI18nAttributeName.append(XSSUtil.encodeForHTML(context, i18nNow.getAttributeI18NString((String)map.get("name"), strLanguageStr)));
                strI18nAttributeName.append("</span>");
                columnValues.addElement(strI18nAttributeName.toString());
            }
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
        return columnValues;
    }
    
}
