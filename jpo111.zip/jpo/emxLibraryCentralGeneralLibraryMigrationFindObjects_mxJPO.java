import matrix.db.Context;


public class emxLibraryCentralGeneralLibraryMigrationFindObjects_mxJPO extends emxLibraryCentralGeneralLibraryMigrationFindObjectsBase_mxJPO
{
	public emxLibraryCentralGeneralLibraryMigrationFindObjects_mxJPO(Context context, String[] args) throws Exception
	{
		super(context, args);
	}
}
