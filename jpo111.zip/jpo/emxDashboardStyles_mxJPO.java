import matrix.db.Context;


public class emxDashboardStyles_mxJPO extends emxDashboardStylesBase_mxJPO {
	
    /**
     * @param context
     * @param args
     * @throws Exception
     */
    public emxDashboardStyles_mxJPO(Context context, String[] args) throws Exception {
    	super(context, args);
    } 

}
