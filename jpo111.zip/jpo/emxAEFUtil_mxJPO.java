import matrix.db.Context;

// ${CLASSNAME}.java
//
// Created on Jul 31, 2007
//
// Copyright (c) 2005-2015 Dassault Systemes.
// All Rights Reserved
// This program contains proprietary and trade secret information of
// MatrixOne, Inc.  Copyright notice is precautionary only and does
// not evidence any actual or intended publication of such program.
//

/**
 * @author ixk
 *
 * The <code>${CLASSNAME}</code> class/interface contains ...
 *
 * @version AEF 11.0.0.0 - Copyright (c) 2005, MatrixOne, Inc.
 */
public class emxAEFUtil_mxJPO extends emxAEFUtilBase_mxJPO {

     /**
     * Whats up?
     * @param context
     * @param args
     * @throws Exception
     */
    public emxAEFUtil_mxJPO(Context context, String[] args)throws Exception
    {
        super(context,args);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub

    }

}
