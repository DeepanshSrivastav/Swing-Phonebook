/*
**  DSCViewableFile
**
**  Copyright Dassault Systemes, 1992-2007.
**  All Rights Reserved.
**  This program contains proprietary and trade secret information of Dassault Systemes and its 
**  subsidiaries, Copyright notice is precautionary only
**  and does not evidence any actual or intended publication of such program
**
*/
import matrix.db.Context;

 public class DSCViewableFile_mxJPO  extends DSCViewableFileBase_mxJPO
{
	/**
	   * Constructor.
	   *
	   * @since Sourcing V6R2008-2
	   */
	   /*
	public ${CLASSNAME} () throws Exception
	{
	  super();
	}
	*/

	public DSCViewableFile_mxJPO(Context context, String[] args) throws Exception
	{
          super(context, args);
	}
    
}
