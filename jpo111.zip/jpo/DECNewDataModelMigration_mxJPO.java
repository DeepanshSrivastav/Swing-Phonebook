import matrix.db.Context;


public class DECNewDataModelMigration_mxJPO extends DECNewDataModelMigrationBase_mxJPO
{
	public DECNewDataModelMigration_mxJPO(Context context, String[] args) throws Exception
    {
	      super(context, args);
	}
}
