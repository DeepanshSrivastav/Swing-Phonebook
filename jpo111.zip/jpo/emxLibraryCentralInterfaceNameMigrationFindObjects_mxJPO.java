import matrix.db.Context;


public class emxLibraryCentralInterfaceNameMigrationFindObjects_mxJPO extends emxLibraryCentralInterfaceNameMigrationFindObjectsBase_mxJPO
{
	public emxLibraryCentralInterfaceNameMigrationFindObjects_mxJPO(Context context, String[] args) throws Exception
	{
		super(context, args);
	}
}

