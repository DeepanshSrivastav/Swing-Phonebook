import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FilenameFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.RandomAccessFile;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.nio.channels.FileChannel;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import javax.xml.bind.DatatypeConverter;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeTypeList;
import matrix.db.BusinessObject;
import matrix.db.BusinessType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.Policy;
import matrix.db.Relationship;
import matrix.db.RelationshipItr;
import matrix.db.RelationshipList;
import matrix.db.RelationshipType;
import matrix.db.StateRequirement;
import matrix.db.StateRequirementList;
import matrix.util.MatrixException;
import matrix.util.StringItr;
import matrix.util.StringList;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.BooleanUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.math.NumberUtils;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.poifs.filesystem.POIFSFileSystem;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.CellRangeAddress;
import org.xml.sax.InputSource;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainSymbolicConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.domain.util.mxAttr;
import com.matrixone.apps.domain.util.mxBus;
import com.matrixone.apps.domain.util.mxType;
import com.matrixone.apps.framework.ui.UICache;
import com.matrixone.apps.framework.ui.UIForm;
import com.matrixone.apps.framework.ui.UIMenu;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UITable;
import com.matrixone.jdom.Document;
import com.matrixone.jdom.Element;
import com.matrixone.jdom.JDOMException;
import com.matrixone.jdom.input.SAXBuilder;
import com.matrixone.jdom.output.Format;
import com.matrixone.jdom.output.XMLOutputter;
import com.matrixone.jdom.xpath.XPath;
 

/**

 * explanation

 *

 * find schema (ex)

 * execute program  emxSchemaUtil href '';
 *

 * make schema (ex)

 * execute program emxSchemaUtil Table    '';
 * execute program emxSchemaUtil Form     '';
 * execute program emxSchemaUtil command  '';
 * execute program emxSchemaUtil menu     '';
 *

 * result location (ex)

 * C:\Documents and Settings\Administrator\Local Settings\Temp

 * ==> you can find location. it's method

 * 1. open cmd

 * 2. set temp (enter)

 */

 

/**

 * @author sangwon Jeon

 *

 */

public class cdmSchemaUtil_mxJPO {

 

    private static final String CODE = "code";
    private static final String FIND_TRIGGER = "trigger";
    private static final String FIND_HREF = "href";
    private static final String EXPRESSIONTYPE = "expressiontype";
    private static final String EXPRESSION = "expression";
    private static final String DUMP = "dump";
    private static final String DOT = ".";
    private static final String SYSTEM = "system";
    private static final String SELECT = "select";
    private static final String SEMI_COLON = ";";
    private static final String VALUE = "value";
    private static final String PROPERTIES = "properties";
    private static final String PROPERTY = "property";
    private static final String SETTING = "setting";
    private static final String SETTINGS = "settings";
    private static final String UPDATE = "update";
    private static final String RANGE = "range";
    private static final String ALT = "alt";
    private static final String PRINT_TABLE = "print table ";
    private static final String PRINT_FORM = "print form ";
    private static final String LABEL = "label";
    private static final String NAME = "name";
    private static final String SORTTYPE = "sorttype";
    private static final String HREF = "href";
    private static final String DOUBLE_QUOTE = "\"";
    private static final String COLUMN = "column";
    private static final String FIELD = "field";
    private static final String TAB = "\t";
    private static final String _TAB = "    ";
    private static final String RECORDSEP = "\n";
    private static final String SCHEMA_TABLE = "Table";
    private static final String SCHEMA_FORM = "Form";
    private static final String SCHEMA_COMMAND = "command";
    private static final String SCHEMA_MENU = "menu";
    private static final String SCHEMA_INSTALL = "install";
    private static final String SCHEMA_CHANNEL = "channel";
    private static final String SCHEMA_RELATIONSHIP = "relationship";
    private static final String SCHEMA_RELATIONSHIP_DETAIL = "relationship_detail";
    private static final String SCHEMA_ATTRIBUTE = "attribute";
    private static final String SCHEMA_TYPE = "type";
    private static final String SCHEMA_POLICY = "policy";
    private static final String SPACE = " ";
    //private static final String DOUBLE_QUOTE = "\"";
    private static final String SINGLE_QUOTE = "'";
    public static final String START_SQUARE_BRACKET = "[";
    public static final String END_SQUARE_BRACKET = "]";
    public static final String START_ANGLE_BRACKET = "{";
    public static final String END_ANGLE_BRACKET = "}";
    public static final String START_ROUND_BRACKET = "(";
    public static final String END_ROUND_BRACKET = ")";
    public static final String AND = " && ";
    public static final String OR = " || ";
    public static final String EQ = " == ";
    public static final String NEQ = " != ";
    private static String TEMP_DIR = null;
    private static String EXPORT_DIR = null;
    private static StringBuffer REMOVE_SCHMA = new StringBuffer();
    private static StringBuffer EXPORT_SCHMA = new StringBuffer();
    private static StringBuffer IMPORT_SCHMA = new StringBuffer();
    private static StringBuffer STRING_RESOURCE = new StringBuffer();
    private static final String TRIGGER_TYPE = "eService Trigger Program Parameters";
    private static String TEMP_TRIGGER_NAME = null;
    private static String TEMP_TRIGGER_REV = null;
    private static final String SELECT_SEPERATOR = "|";
 

    /**

    * Export

    */

    private static boolean isDateRemove = false;
 

 

    /**

    *

    */

    public cdmSchemaUtil_mxJPO() {

        //System.out.println("emxSchemaUtil_mxJPO.emxSchemaUtil${CLASS:mxJPO.emxSchemaUtil}()");
        TEMP_DIR = System.getenv("TEMP");
    }

 

    /**

    * @param args

    */

    public static void mxMain(Context context, String[] args) throws Exception {
        System.out.println("cdmSchemaUtil_mxJPO.mxMain()");
        try {

            String mqlCmd = "";
            if (args == null) {
                throw new IllegalArgumentException();
            }

            if (args.length < 2) {
                throw new IllegalArgumentException();
            }

            if( args.length >= 3 ) {
                TEMP_DIR = args[2];
            }

 
            String sSchemaType = args[0];
 
            for(String arg: args){
                System.out.println(" arg : " + arg);
            }

 

            if (SCHEMA_TABLE.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = getTableMQL(context, args[1]);
            } else if (SCHEMA_FORM.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = getFormMQL(context, args[1]);
            } else if (FIND_HREF.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = findCommandNMenu(context, args[1]);
            } else if (FIND_TRIGGER.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = findTrigger(context, args[1]);
            } else if (SCHEMA_COMMAND.equalsIgnoreCase(sSchemaType)){

                mqlCmd = getCommandMQL(context, args[1]);
            } else if (SCHEMA_MENU.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = getMenuMQL(context, args[1]);
            } else if (SCHEMA_CHANNEL.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = getChannelMQL(context, args[1]);
            } else if (SCHEMA_RELATIONSHIP.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = getRelationshipMQL(context, args[1], false);
            } else if (SCHEMA_RELATIONSHIP_DETAIL.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = getRelationshipMQL(context, args[1], true);
            } else if (SCHEMA_ATTRIBUTE.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = getAttributeMQL(context, args[1]);
            } else if (SCHEMA_TYPE.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = getTypeMQL(context, args[1]);
            } else if (SCHEMA_POLICY.equalsIgnoreCase(sSchemaType)) {

                mqlCmd = getPolicyMQL(context, args[1]);
            } else if (SCHEMA_INSTALL.equalsIgnoreCase(sSchemaType)) {

                EXPORT_DIR = TEMP_DIR + File.separator + "MQL" + File.separator;
                REMOVE_SCHMA = new StringBuffer();
                EXPORT_SCHMA = new StringBuffer();
                IMPORT_SCHMA = new StringBuffer();
                STRING_RESOURCE = new StringBuffer();
 

                schemaMigration(context, args[1]);
            }

        } catch (IllegalArgumentException ie) {

            System.out.println("\n\n"+ie.toString());
            System.out.println("\nUsage) exec prog emxSchemaUtil ADMIN_TYPE ADMIN_TYPE_NAME [OUTPUT_DIR]\n");
            System.out.println("\t- ADMIN_TYPE : command, form, menu, table, trigger");
            System.out.println("\t- ADMIN_TYPE_NAME : administrative object's name like ENCSearchMenu");
            System.out.println("\t- OUTPUT : output directory. Default is "+System.getenv("TEMP")+"\n");
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

    public static void getCreateTriggerMQL(Context context, String[] args) throws Exception {

 

        try {

            System.out.println(TEMP_DIR);
            TEMP_DIR = "d://";
            System.out.println(TEMP_DIR);
            String sTriggerName   = args[0];
            String sTriggerRevision = args[1];
 

            if( args.length > 2 )

                TEMP_DIR = args[2];
 

            if( StringUtils.contains(sTriggerRevision, ".mql") ){

                sTriggerRevision = StringUtils.remove(sTriggerRevision, ".mql");
            }

 

            TEMP_TRIGGER_NAME = sTriggerName;
            TEMP_TRIGGER_REV = sTriggerRevision;
 

            String sCmdBase = new StringBuilder("print bus 'eService Trigger Program Parameters' ").append(sTriggerName).append(SPACE).append(sTriggerRevision).toString();
 

            System.out.println("Base mql : " + sCmdBase);
 

            //                         String triggerObjectId = StringUtils.substringAfter(MqlUtil.mqlCommand(context, new StringBuilder(sCmdBase).append(" select id").toString()), "=").trim();
            //                         System.out.println("triggerObjectId : " + triggerObjectId);
            //

            //                         DomainObject triggerObject = DomainObject.newInstance(context);
            //                         triggerObject.setId(triggerObjectId);
            //

            //                         Map attrMap = triggerObject.getAttributeMap(context);
            //                         Iterator attrKeyItr = attrMap.keySet().iterator();
            //                         while(attrKeyItr.hasNext()){

            //                                    String attrName = (String) attrKeyItr.next();
            //                                    String attrValue = (String) attrMap.get(attrName);
            //

            //                                    System.out.println(attrName + " : " + attrValue);
            //                         }

            //

            //                         Map triggerInf = triggerObject.getInfo(context, new StringList(new String[]{"policy", "vault", "owner"}));
            //

            //                         System.out.println(" attrMap : " + attrMap);
            //                         System.out.println(" triggerInf : " + triggerInf);
 

            String sCmdSelMehod = new StringBuilder(sCmdBase).append(" select attribute[eService Method Name].value").toString();
            String sCmdProgArg1 = new StringBuilder(sCmdBase).append(" select attribute[eService Program Argument 1].value").toString();
 

            String mqlRetProgArg1 = MqlUtil.mqlCommand(context, sCmdProgArg1);
 

            mqlRetProgArg1 = StringUtils.substringAfter(mqlRetProgArg1, "=").trim();
 

            String sMethodName = StringUtils.substringAfter(MqlUtil.mqlCommand(context, sCmdSelMehod), "=").trim();

            StringBuffer sb = new StringBuffer();
            sb.append("#del bus 'eService Trigger Program Parameters' '").append(sTriggerName).append("' '").append(sTriggerRevision).append("';").append(RECORDSEP);
            sb.append("add bus 'eService Trigger Program Parameters' '").append(sTriggerName).append("' '").append(sTriggerRevision).append("'").append(RECORDSEP);
            sb.append(_TAB).append("policy 'eService Trigger Program Policy'").append(RECORDSEP);
            sb.append(_TAB).append("vault 'eService Administration'").append(RECORDSEP);
            sb.append(_TAB).append("owner 'creator'").append(RECORDSEP);
            sb.append(_TAB).append("state 'Active' schedule ''").append(RECORDSEP);
            sb.append(_TAB).append(_TAB).append("'eService Sequence Number' '").append(getTriggerAttrValue(context, "eService Sequence Number")).append("'").append(RECORDSEP);
            sb.append(_TAB).append(_TAB).append("'eService Program Name' '").append(getTriggerAttrValue(context, "eService Program Name")).append("'").append(RECORDSEP);
 

            if( StringUtils.isNotBlank(sMethodName) ) {

                sb.append(_TAB).append(_TAB).append("'eService Method Name' '").append(sMethodName).append("'").append(RECORDSEP);
            }

 

            sb.append(_TAB).append(_TAB).append("'eService Constructor Arguments' '").append(getTriggerAttrValue(context, "eService Constructor Arguments")).append("'").append(RECORDSEP);
 

            // ==========================================

            // eService Program Argument 1 ~ 15 Check.

            for (int i = 1; i <= 15; i++) {

                String attrName = "eService Program Argument " + i;
                String sCmdProgArg = new StringBuilder(sCmdBase).append(" select attribute[").append(attrName).append("].value").toString();
                String sMqlRetPrgArg = MqlUtil.mqlCommand(context, sCmdProgArg);
                String attrValue = StringUtils.substringAfter(sMqlRetPrgArg, "=").trim();
 

                if( StringUtils.isNotBlank(attrValue) ) {

                    sb.append(_TAB).append(_TAB).append("'").append(attrName).append("' '").append(attrValue).append("'").append(RECORDSEP);
                }

            }

 

            sb.append(";").append(RECORDSEP);
            sb.append("promote bus 'eService Trigger Program Parameters' '").append(sTriggerName).append("' '").append(sTriggerRevision).append("';").append(RECORDSEP);
 

            // #promote bus 'eService Trigger Program Parameters' 'PolicyECPartStateApprovedPromoteAction' 'AutoPromoteVPLMToShared';
 

            saveFile(sTriggerName+"_"+sTriggerRevision, sb);
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

 

    private static String getTriggerAttrValue(Context context, String sAttr) throws Exception {

        String rv = getAttributeValue(context, TRIGGER_TYPE, TEMP_TRIGGER_NAME, TEMP_TRIGGER_REV, sAttr);
        return StringUtils.isBlank(rv) ? "" : rv;
    }

 

    private static String getAttributeValue(Context context, String sType, String sName, String sRev, String attrName) throws Exception {

        return StringUtils.substringAfter(MqlUtil.mqlCommand(context, new StringBuilder("print bus '").append(sType).append("' '").append(sName).append("' '").append(sRev).append("' select attribute[").append(attrName).append("].value").toString()), "=").trim();
    }

 

 

    public static String findTrigger(Context context, String href) throws Exception{

        try {

            StringBuffer sb = new StringBuffer();
            String strResult = "";
 

 

            sb.append("temp query bus ").append(SPACE).append("'eService Trigger Program Parameters'").append(SPACE).append("*").append(SPACE).append("*").append(SPACE).append(SELECT).append(SPACE).append("attribute.value").append(SPACE).append(DUMP).append(SEMI_COLON);
            String mqlRet = MqlUtil.mqlCommand(context, sb.toString());
            StringList commandList = FrameworkUtil.split(mqlRet, RECORDSEP);
 

 

            StringList adminList = new StringList();
            adminList.addAll(commandList);
            StringItr adminItr = new StringItr(adminList);
            HashMap adminInfo = new HashMap();
 

            while(adminItr.next()){

                String adminHref = adminItr.obj();
                //System.out.println("adminHref="+adminHref);
                StringList tempList = FrameworkUtil.split(adminHref, "|");
                //System.out.println("adminHref.indexOf(href)="+adminHref.indexOf(href));
                if( adminHref.indexOf(href) != -1 ){

                    strResult = strResult + tempList.get(0) + RECORDSEP;
                }

            }

            saveFile("Find Trigger", new StringBuffer(strResult));
            return strResult;
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

    public static String findCommandNMenu(Context context, String href) throws Exception{

        try {

            StringBuffer sb = new StringBuffer();
            String strResult = "";
 

 

            sb.append("list").append(SPACE).append("command").append(SPACE).append("*").append(SPACE).append(SELECT).append(SPACE).append(NAME).append(SPACE).append("label").append(SPACE).append(HREF).append(SPACE).append("setting[].value").append(SPACE).append(DUMP).append(SEMI_COLON);
            String mqlRet = MqlUtil.mqlCommand(context, sb.toString());
            StringList commandList = FrameworkUtil.split(mqlRet, RECORDSEP);
            //System.out.println("sb="+sb);
            sb.setLength(0);
            sb.append("list").append(SPACE).append("menu").append(SPACE).append("*").append(SPACE).append(SELECT).append(SPACE).append(NAME).append(SPACE).append("label").append(SPACE).append(HREF).append(SPACE).append("setting[].value").append(SPACE).append(DUMP).append(SEMI_COLON);
            mqlRet = MqlUtil.mqlCommand(context, sb.toString());
            StringList menuList = FrameworkUtil.split(mqlRet, RECORDSEP);
 

 

            StringList adminList = new StringList();
            adminList.addAll(commandList);
            adminList.addAll(menuList);
            StringItr adminItr = new StringItr(adminList);
            HashMap adminInfo = new HashMap();
 

            StringBuffer sbResult = new StringBuffer();
            while(adminItr.next()){

                String adminHref = adminItr.obj();
                //System.out.println("adminHref="+adminHref);
                //StringList tempList = FrameworkUtil.split(adminHref, ",");
                //System.out.println("adminHref.indexOf(href)="+adminHref.indexOf(href));
                if( adminHref.indexOf(href) != -1 ){

                    strResult = strResult + adminHref + RECORDSEP;
                    sbResult.append(adminHref).append(RECORDSEP);
                }

            }

            saveFile("Find Href_" + href + "_" + new SimpleDateFormat("yyyyMMddhhmmss").format(new Date()), sbResult);
            return strResult;
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

    /**

    * @param context

    * @param sName

    * @return

    * @throws Exception

    */

    public static String getTableMQL(Context context, String[] sNames) throws Exception{

        for (int i = 0; i < sNames.length; i++) {

            System.out.println("sNames : " + sNames[i]);
            cdmSchemaUtil_mxJPO.getTableMQL(context, sNames[i]);
        }

        return "";
    }

    public static String getTableMQL(Context context, String sName) throws Exception{

        System.out.println("emxSchemaUtil_mxJPO.getTableMQL()");
 

        if( StringUtils.contains(sName, ".mql") )

            sName = StringUtils.remove(sName, ".mql");
 

        //loadTable(context, sName);
 

 

        try {

            StringBuffer sb = new StringBuffer();
            UITable uiTableBean = new UITable();
            HashMap mapTableInfo = uiTableBean.getTable(context, sName);
            // System.out.println("mapTableInfo : " + mapTableInfo);
            /*

            * ################################################################################################

# Modifed : 2011. 11. 10

# Admin Type : Table

# Name : LCMyPartsList_backup

################################################################################################*/

            sb.append("################################################################################################").append(RECORDSEP);
            sb.append("# Modified : ").append(new SimpleDateFormat("yyyy. MM. dd").format(new Date())).append(RECORDSEP);
            sb.append("# Admin Type : Table").append(RECORDSEP);
            sb.append("# Name : ").append(sName).append(RECORDSEP);
            sb.append("################################################################################################").append(RECORDSEP).append(RECORDSEP);
            sb.append("#copy table ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SPACE).append(DOUBLE_QUOTE).append(sName).append("_backup").append(DOUBLE_QUOTE).append(" fromuser system touser system").append(SEMI_COLON).append(RECORDSEP);
            sb.append("#del table ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SPACE).append(SYSTEM).append(SEMI_COLON).append(RECORDSEP);
            sb.append("add table ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SPACE).append(SYSTEM).append(RECORDSEP);
 

            MapList columnList = (MapList)mapTableInfo.get("columns");
            Iterator columnItr = columnList.iterator();
            while (columnItr.hasNext()) {

                HashMap columnMap = (HashMap) columnItr.next();
                StringList roles = (StringList) columnMap.get("roles");
                String name = (String) columnMap.get("name");
                System.out.println("columnMap : " + columnMap);
                System.out.println("roles : " + roles);
                System.out.println("name : " + name);
                String sColumnName = uiTableBean.getName(columnMap);
                String sColumnLabel = uiTableBean.getLabel(columnMap);
 

 

                boolean hasHref = columnMap.containsKey(HREF);
                boolean hasSortType = columnMap.containsKey(SORTTYPE);
                //boolean isBusExpr =

 

                sb.append(TAB).append(COLUMN).append(RECORDSEP);
                sb.append(TAB).append(TAB).append(NAME).append(SPACE).append(DOUBLE_QUOTE).append(sColumnName).append(DOUBLE_QUOTE).append(RECORDSEP);//name

                sb.append(TAB).append(TAB).append(LABEL).append(SPACE).append(DOUBLE_QUOTE).append(sColumnLabel).append(DOUBLE_QUOTE).append(RECORDSEP);//label

 

 

                String expr = MqlUtil.mqlCommand(context, PRINT_TABLE+SINGLE_QUOTE+sName+SINGLE_QUOTE+SPACE+SYSTEM+SPACE+SELECT+SPACE+COLUMN+START_SQUARE_BRACKET+sColumnName+END_SQUARE_BRACKET+DOT+EXPRESSION+SPACE+DUMP);
                String exprType = MqlUtil.mqlCommand(context, PRINT_TABLE+SINGLE_QUOTE+sName+SINGLE_QUOTE+SPACE+SYSTEM+SPACE+SELECT+SPACE+COLUMN+START_SQUARE_BRACKET+sColumnName+END_SQUARE_BRACKET+DOT+EXPRESSIONTYPE+SPACE+DUMP);
                if( expr != null && !"".equals(expr) && !"null".equals(expr) ){

                    sb.append(TAB).append(TAB).append(exprType).append(SPACE).append(DOUBLE_QUOTE).append(expr).append(DOUBLE_QUOTE).append(RECORDSEP);
                }

 

                String alt = MqlUtil.mqlCommand(context, PRINT_TABLE+SINGLE_QUOTE+sName+SINGLE_QUOTE+SPACE+SYSTEM+SPACE+SELECT+SPACE+COLUMN+START_SQUARE_BRACKET+sColumnName+END_SQUARE_BRACKET+DOT+ALT+SPACE+DUMP);
                sb.append(TAB).append(TAB).append(ALT).append(SPACE).append(DOUBLE_QUOTE).append(alt).append(DOUBLE_QUOTE).append(RECORDSEP);
 

                String range = MqlUtil.mqlCommand(context, PRINT_TABLE+SINGLE_QUOTE+sName+SINGLE_QUOTE+SPACE+SYSTEM+SPACE+SELECT+SPACE+COLUMN+START_SQUARE_BRACKET+sColumnName+END_SQUARE_BRACKET+DOT+RANGE+SPACE+DUMP);
                sb.append(TAB).append(TAB).append(RANGE).append(SPACE).append(DOUBLE_QUOTE).append(range).append(DOUBLE_QUOTE).append(RECORDSEP);
 

                String update = MqlUtil.mqlCommand(context, PRINT_TABLE+SINGLE_QUOTE+sName+SINGLE_QUOTE+SPACE+SYSTEM+SPACE+SELECT+SPACE+COLUMN+START_SQUARE_BRACKET+sColumnName+END_SQUARE_BRACKET+DOT+UPDATE+SPACE+DUMP);
                sb.append(TAB).append(TAB).append(UPDATE).append(SPACE).append(DOUBLE_QUOTE).append(update).append(DOUBLE_QUOTE).append(RECORDSEP);
 

 

                if(hasHref)

                {

                    String href = uiTableBean.getControlMapStringElement(columnMap, HREF);
                    sb.append(TAB).append(TAB).append(HREF).append(SPACE).append(DOUBLE_QUOTE).append(href).append(DOUBLE_QUOTE).append(RECORDSEP);//HREF

                }

 

                if(hasSortType)

                {

                    String sortType = uiTableBean.getControlMapStringElement(columnMap, SORTTYPE);
                    sb.append(TAB).append(TAB).append(SORTTYPE).append(SPACE).append(DOUBLE_QUOTE).append(sortType).append(DOUBLE_QUOTE).append(RECORDSEP);//label

                }

 

                HashMap settings = (HashMap)columnMap.get(SETTINGS);
                Iterator settingItr = settings.keySet().iterator();
                while(settingItr.hasNext())

                {

                    String settingName = (String)settingItr.next();
                    String settingValue = (String)settings.get(settingName);
                    sb.append(TAB).append(TAB).append(SETTING).append(SPACE).append(DOUBLE_QUOTE).append(settingName).append(DOUBLE_QUOTE).append(SPACE).append(DOUBLE_QUOTE).append(settingValue).append(DOUBLE_QUOTE).append(RECORDSEP);//label

                }

 

                if( roles != null && roles.size() > 0 )

                {

                    for (Iterator roleItr = roles.iterator(); roleItr.hasNext();) {

                        String sRole = (String) roleItr.next();
                        sb.append(TAB).append(TAB).append("user \"").append(sRole).append("\"").append(RECORDSEP);
                    }

                }

            }

 

            HashMap propertiesMap = (HashMap)mapTableInfo.get(PROPERTIES);
            if( propertiesMap != null){

                Iterator propertyItr = propertiesMap.keySet().iterator();
                while(propertyItr.hasNext())

                {

                    String propertyName = (String)propertyItr.next();
                    String propertyValue = (String)propertiesMap.get(propertyName);
                    sb.append(PROPERTY).append(SPACE).append(DOUBLE_QUOTE).append(propertyName).append(DOUBLE_QUOTE).append(SPACE).append(VALUE).append(SPACE).append(DOUBLE_QUOTE).append(propertyValue).append(DOUBLE_QUOTE).append(RECORDSEP);//label

                }

            }

            sb.append(SEMI_COLON);
            sb.append(RECORDSEP).append(RECORDSEP);
            //mod 2014-11-11 Mskim, "system" Add
            sb.append("#add property 'table_").append(StringUtils.deleteWhitespace(sName)).append("' on program 'eServiceSchemaVariableMapping.tcl' to table '").append(sName).append("' system ").append(SEMI_COLON);
 

 

            saveFile(sName, sb);
 

            return sb.toString();
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

    public static String getTableDSP(Context context, String[] sName) throws Exception{

        for (int i = 0; i < sName.length; i++) {

            getTableDSP(context, sName[i]);
        }

        return "";
    }

    public static String getTableDSP(Context context, String sName) throws Exception{

        System.out.println("emxSchemaUtil_mxJPO.getTableMQL()");
        try {

            StringBuffer sb = new StringBuffer();
            UITable uiTableBean = new UITable();
            HashMap mapTableInfo = uiTableBean.getTable(context, sName);
            sb.append("# Add table ").append(sName).append(RECORDSEP);
            sb.append("#del table ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SPACE).append(SYSTEM).append(SEMI_COLON).append(RECORDSEP);
            sb.append("add table ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SPACE).append(SYSTEM).append(RECORDSEP);
 

            MapList columnList = (MapList)mapTableInfo.get("columns");
            Iterator columnItr = columnList.iterator();
            while (columnItr.hasNext()) {

                HashMap columnMap = (HashMap) columnItr.next();
                String sColumnName = uiTableBean.getName(columnMap);
                String sColumnLabel = uiTableBean.getLabel(columnMap);
 

 

                boolean hasHref = columnMap.containsKey(HREF);
                boolean hasSortType = columnMap.containsKey(SORTTYPE);
                //boolean isBusExpr =

 

                        sb.append(RECORDSEP);
                sb.append(sColumnName).append(TAB).append(sColumnLabel);//name

 

 

                String expr = MqlUtil.mqlCommand(context, PRINT_TABLE+SINGLE_QUOTE+sName+SINGLE_QUOTE+SPACE+SYSTEM+SPACE+SELECT+SPACE+COLUMN+START_SQUARE_BRACKET+sColumnName+END_SQUARE_BRACKET+DOT+EXPRESSION+SPACE+DUMP);
                String exprType = MqlUtil.mqlCommand(context, PRINT_TABLE+SINGLE_QUOTE+sName+SINGLE_QUOTE+SPACE+SYSTEM+SPACE+SELECT+SPACE+COLUMN+START_SQUARE_BRACKET+sColumnName+END_SQUARE_BRACKET+DOT+EXPRESSIONTYPE+SPACE+DUMP);
                if( expr != null && !"".equals(expr) && !"null".equals(expr) ){

                    sb.append(TAB).append(exprType).append(TAB).append(expr);
                }

 

 

                HashMap settings = (HashMap)columnMap.get(SETTINGS);
                Iterator settingItr = settings.keySet().iterator();
                while(settingItr.hasNext())

                {

                    sb.append("\n");
                    String settingName = (String)settingItr.next();
 

                    String settingValue = (String)settings.get(settingName);
                    sb.append(settingName).append(TAB).append(settingValue);//label

                }

                sb.append(RECORDSEP);
            }

 

            saveFile(".." + File.separator + sName, sb, ".txt");
 

            return sb.toString();
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

    public static String getFormMQL(Context context, String sName) throws Exception{

        System.out.println("emxSchemaUtil_mxJPO.getTableMQL()" + sName);
        try {

            if( StringUtils.contains(sName, ".mql") )

            {

                sName = StringUtils.remove(sName, ".mql");
            }

            System.out.println("sName : " + sName);
            StringBuffer sb = new StringBuffer();
            UIForm uiFormBean = new UIForm();
            HashMap mapFormInfo = uiFormBean.getForm(context, sName);
            sb.append("################################################################################################").append(RECORDSEP);
            sb.append("# Modified : ").append(new SimpleDateFormat("yyyy. MM. dd").format(new Date())).append(RECORDSEP);
            sb.append("# Admin Type : webForm").append(RECORDSEP);
            sb.append("# Name : ").append(sName).append(RECORDSEP);
            sb.append("################################################################################################").append(RECORDSEP).append(RECORDSEP);
            
            sb.append("#del form ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SEMI_COLON).append(RECORDSEP);
            sb.append("add form ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SPACE).append("web").append(RECORDSEP);
 

            MapList columnList = (MapList)mapFormInfo.get("fields");
            Iterator columnItr = columnList.iterator();
            while (columnItr.hasNext()) {

                HashMap fieldMap = (HashMap) columnItr.next();
                System.out.println("fieldMap="+fieldMap);
                String sFieldName = uiFormBean.getName(fieldMap);
                String sFieldLabel = uiFormBean.getLabel(fieldMap);
 

 

                boolean hasHref = fieldMap.containsKey(HREF);
                //boolean isBusExpr =

 

                sb.append(TAB).append(FIELD).append(RECORDSEP);
                sb.append(TAB).append(TAB).append(NAME).append(SPACE).append(DOUBLE_QUOTE).append(sFieldName).append(DOUBLE_QUOTE).append(RECORDSEP);//name

                sb.append(TAB).append(TAB).append(LABEL).append(SPACE).append(DOUBLE_QUOTE).append(sFieldLabel).append(DOUBLE_QUOTE).append(RECORDSEP);//label

 

 

                String expr = MqlUtil.mqlCommand(context, PRINT_FORM+sName+SPACE+SELECT+SPACE+FIELD+START_SQUARE_BRACKET+sFieldName+END_SQUARE_BRACKET+DOT+EXPRESSION+SPACE+DUMP);
                String exprType = MqlUtil.mqlCommand(context, PRINT_FORM+sName+SPACE+SELECT+SPACE+FIELD+START_SQUARE_BRACKET+sFieldName+END_SQUARE_BRACKET+DOT+EXPRESSIONTYPE+SPACE+DUMP);
                if( expr != null && !"".equals(expr) && !"null".equals(expr) ){

                    sb.append(TAB).append(TAB).append(exprType).append(SPACE).append(DOUBLE_QUOTE).append(expr).append(DOUBLE_QUOTE).append(RECORDSEP);
                }

 

                String alt = MqlUtil.mqlCommand(context, PRINT_FORM+sName+SPACE+SELECT+SPACE+FIELD+START_SQUARE_BRACKET+sFieldName+END_SQUARE_BRACKET+DOT+ALT+SPACE+DUMP);
                sb.append(TAB).append(TAB).append(ALT).append(SPACE).append(DOUBLE_QUOTE).append(alt).append(DOUBLE_QUOTE).append(RECORDSEP);
 

                String range = MqlUtil.mqlCommand(context, PRINT_FORM+sName+SPACE+SELECT+SPACE+FIELD+START_SQUARE_BRACKET+sFieldName+END_SQUARE_BRACKET+DOT+RANGE+SPACE+DUMP);
                sb.append(TAB).append(TAB).append(RANGE).append(SPACE).append(DOUBLE_QUOTE).append(range).append(DOUBLE_QUOTE).append(RECORDSEP);
 

                String update = MqlUtil.mqlCommand(context, PRINT_FORM+sName+SPACE+SELECT+SPACE+FIELD+START_SQUARE_BRACKET+sFieldName+END_SQUARE_BRACKET+DOT+UPDATE+SPACE+DUMP);
                sb.append(TAB).append(TAB).append(UPDATE).append(SPACE).append(DOUBLE_QUOTE).append(update).append(DOUBLE_QUOTE).append(RECORDSEP);
 

 

                if(hasHref)

                {

                    String href = uiFormBean.getHRef(fieldMap);
                    sb.append(TAB).append(TAB).append(HREF).append(SPACE).append(DOUBLE_QUOTE).append(href).append(DOUBLE_QUOTE).append(RECORDSEP);//HREF

                }

 

                HashMap settings = (HashMap)fieldMap.get(SETTINGS);
                if(settings == null){

                    System.out.println( "Field SETTING NULL ("+sName+")");
                }

                if( settings != null ){

                    Iterator settingItr = settings.keySet().iterator();
                    while(settingItr.hasNext())

                    {

                        String settingName = (String)settingItr.next();
                        String settingValue = (String)settings.get(settingName);
                        sb.append(TAB).append(TAB).append(SETTING).append(SPACE).append(DOUBLE_QUOTE).append(settingName).append(DOUBLE_QUOTE).append(SPACE).append(DOUBLE_QUOTE).append(settingValue).append(DOUBLE_QUOTE).append(RECORDSEP);//label

                    }

                }

            }

 

            HashMap propertiesMap = (HashMap)mapFormInfo.get(PROPERTIES);
            if( propertiesMap != null){

                Iterator propertyItr = propertiesMap.keySet().iterator();
                while(propertyItr.hasNext())

                {

                    String propertyName = (String)propertyItr.next();
                    String propertyValue = (String)propertiesMap.get(propertyName);
                    sb.append(PROPERTY).append(SPACE).append(DOUBLE_QUOTE).append(propertyName).append(DOUBLE_QUOTE).append(SPACE).append(VALUE).append(SPACE).append(DOUBLE_QUOTE).append(propertyValue).append(DOUBLE_QUOTE).append(RECORDSEP);//label

                }

            }

            sb.append(SEMI_COLON);
            saveFile(sName, sb);
 

            return sb.toString();
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

    public static String getCommandMQL(Context context, String[] sNames) throws Exception{

        for (int i = 0; i < sNames.length; i++) {

            cdmSchemaUtil_mxJPO.getCommandMQL(context, sNames[i]);
        }

        return "";
    }

 

    public static String getCommandMQL(Context context, String sName) throws Exception{

        System.out.println("emxSchemaUtil_mxJPO.getCommandMQL() : " + sName);
        String sExtension = StringUtils.substring(sName, sName.lastIndexOf(".")+1);
        if( StringUtils.equalsIgnoreCase(sExtension, "mql") )

        {

            sName = StringUtils.substring(sName, 0, sName.lastIndexOf("."));
        }

        System.out.println(sName);
        try {

            StringBuffer sb = new StringBuffer();
            UIMenu uiMenuBean = new UIMenu();
            HashMap mapMenuInfo = uiMenuBean.getCommand(context, sName);
            System.out.println ("mapMenuInfo="+mapMenuInfo);
            sb.append("# Add command ").append(sName).append(RECORDSEP);
            sb.append("#copy command ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SPACE).append(DOUBLE_QUOTE).append(sName).append("_backup").append(DOUBLE_QUOTE).append(SEMI_COLON).append(RECORDSEP);
            sb.append("#del command ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SEMI_COLON).append(RECORDSEP);
            sb.append("add command ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(RECORDSEP);
 

            String strLabel = (String)mapMenuInfo.get(LABEL);
            String strDescription = (String)mapMenuInfo.get(DomainObject.SELECT_DESCRIPTION);
            String strHref = (String)mapMenuInfo.get(HREF);
            String strAlt = (String)mapMenuInfo.get(ALT);
            String strCode = (String)mapMenuInfo.get(CODE);
            HashMap settingMap = (HashMap)mapMenuInfo.get(SETTINGS);
            HashMap propertiesMap = (HashMap)mapMenuInfo.get(PROPERTIES);
            StringList slRoles = (StringList)mapMenuInfo.get("roles");
           
            String strUser = MqlUtil.mqlCommand(context, "print command "+sName+" select user dump |");
            slRoles = FrameworkUtil.split(strUser, "|");
 

            sb.append(TAB).append(DomainObject.SELECT_DESCRIPTION).append(SPACE).append(DOUBLE_QUOTE).append(strDescription).append(DOUBLE_QUOTE).append(RECORDSEP);
            sb.append(TAB).append(LABEL).append(SPACE).append(DOUBLE_QUOTE).append(strLabel).append(DOUBLE_QUOTE).append(RECORDSEP);
            sb.append(TAB).append(HREF).append(SPACE).append(DOUBLE_QUOTE).append(strHref).append(DOUBLE_QUOTE).append(RECORDSEP);
            sb.append(TAB).append(ALT).append(SPACE).append(DOUBLE_QUOTE).append(strAlt).append(DOUBLE_QUOTE).append(RECORDSEP);
            sb.append(TAB).append(CODE).append(SPACE).append(DOUBLE_QUOTE).append(strCode).append(DOUBLE_QUOTE).append(RECORDSEP);
 

            Iterator settingItr = settingMap.keySet().iterator();
            while(settingItr.hasNext())

            {

                String settingName = (String)settingItr.next();
                String settingValue = (String)settingMap.get(settingName);
                sb.append(TAB).append(SETTING).append(SPACE).append(DOUBLE_QUOTE).append(settingName).append(DOUBLE_QUOTE).append(SPACE).append(DOUBLE_QUOTE).append(settingValue).append(DOUBLE_QUOTE).append(RECORDSEP);//label

            }

 

            StringItr roleItr = new StringItr(slRoles);
            while(roleItr.next()){

                String userName = roleItr.obj();
                sb.append(TAB).append("user").append(SPACE).append(DOUBLE_QUOTE).append(userName).append(DOUBLE_QUOTE).append(RECORDSEP);;
            }

 

 

            if(propertiesMap!=null){

                Iterator propertyItr = propertiesMap.keySet().iterator();
                while(propertyItr.hasNext())

                {

                    String propertyName = (String)propertyItr.next();
                    String propertyValue = (String)propertiesMap.get(propertyName);
                    sb.append(PROPERTY).append(SPACE).append(DOUBLE_QUOTE).append(propertyName).append(DOUBLE_QUOTE).append(SPACE).append(VALUE).append(SPACE).append(DOUBLE_QUOTE).append(propertyValue).append(DOUBLE_QUOTE).append(RECORDSEP);//label

                }

            }

            sb.append(SEMI_COLON);
 

            StringBuffer sb2 = new StringBuffer();
            sb2.append(RECORDSEP);
            sb2.append("#*************************************************************").append(RECORDSEP);
            sb2.append("#!!!!!!!!!!!!!!!!!!!!!!!!!! Warning !!!!!!!!!!!!!!!!!!!!!!!!!!").append(RECORDSEP);
            sb2.append("#Parent Menu").append(RECORDSEP);
            String strParent = MqlUtil.mqlCommand(context, "print command "+sName+" select parent dump");
            System.out.println("strParent="+strParent);
 

            StringList list = FrameworkUtil.split(strParent, ",");
            StringItr listItr = new StringItr(list);
            while(listItr.next()){

                String parentName = listItr.obj();
                String type = "";
                try{

                    MqlUtil.mqlCommand(context, "print menu '"+parentName+"' select name dump |");
                    type = "menu";
                }catch(Exception ex){

                    type = "channel";
                }

                int iRet = 0;
                StringList slRet = new StringList();
                if("menu".equals(type)){

                    String ret = MqlUtil.mqlCommand(context, "print "+type+" '"+parentName+"' select child dump |");
                    slRet = FrameworkUtil.split(ret, "|");
                    iRet = slRet.indexOf(sName);
                }else if( "channel".equals(type)){

                    String ret = MqlUtil.mqlCommand(context, "print "+type+" '"+parentName+"' select command dump |");
                    slRet = FrameworkUtil.split(ret, "|");
                    iRet = slRet.indexOf(sName);
                }

 

 

                if("menu".equals(type)){

                    sb2.append("#mod "+type).append(SPACE).append(DOUBLE_QUOTE).append(parentName).append(DOUBLE_QUOTE).append(SPACE).append("add command").append(SPACE).append(sName).append(SEMI_COLON).append(RECORDSEP);
                    sb2.append("#mod "+type).append(SPACE).append(DOUBLE_QUOTE).append(parentName).append(DOUBLE_QUOTE).append(SPACE).append("order command").append(SPACE).append(sName).append(SPACE).append(iRet+1).append(SEMI_COLON).append(RECORDSEP);
                }else if( "channel".equals(type)){

                    String after = "";
                    if(iRet > 0 ){

                        after = (String)slRet.get(iRet-1);
                    }

                    sb2.append("#mod "+type).append(SPACE).append(DOUBLE_QUOTE).append(parentName).append(DOUBLE_QUOTE).append(SPACE).append("place").append(SPACE).append(sName).append(SPACE).append("after").append(SPACE).append(DOUBLE_QUOTE).append(after).append(DOUBLE_QUOTE).append(SEMI_COLON).append(RECORDSEP);
                }

            }

 

            sb2.append("#*************************************************************").append(RECORDSEP);
            System.out.println("sb2="+sb2);
            sb.append(sb2);
            saveFile(sName, sb);
 

            return sb.toString();
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

 

    public static String getMenuMQL(Context context, String sName) throws Exception{

        System.out.println("emxSchemaUtil_mxJPO.getMenuMQL()");
        try {

            if( StringUtils.contains(sName, ".mql") )

                sName = StringUtils.remove(sName, ".mql");
 

            StringBuffer sb = new StringBuffer();
            UIMenu uiMenuBean = new UIMenu();
            HashMap mapMenuInfo = uiMenuBean.getMenu(context, sName);
            
            sb.append("# Add menu ").append(sName).append(RECORDSEP);
            sb.append("#copy menu ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SPACE).append(DOUBLE_QUOTE).append(sName).append("_backup").append(DOUBLE_QUOTE).append(SEMI_COLON).append(RECORDSEP);
            sb.append("#del menu ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(SEMI_COLON).append(RECORDSEP);
            sb.append("add menu ").append(DOUBLE_QUOTE).append(sName).append(DOUBLE_QUOTE).append(RECORDSEP);
 

            String strLabel = (String)mapMenuInfo.get(LABEL);
            String strDescription = (String)mapMenuInfo.get(DomainObject.SELECT_DESCRIPTION);
            String strHref = (String)mapMenuInfo.get(HREF);
            String strAlt = (String)mapMenuInfo.get(ALT);
            if( strHref == null || "".equals(strHref) || "null".equals(strHref) ){

                strHref = "";
            }

            if( strAlt == null || "".equals(strAlt) || "null".equals(strAlt) ){

                strAlt = "";
            }

            HashMap settingMap = (HashMap)mapMenuInfo.get(SETTINGS);
            HashMap propertiesMap = (HashMap)mapMenuInfo.get(PROPERTIES);
            MapList childrenList = (MapList)mapMenuInfo.get("children");
 

 

            sb.append(TAB).append(DomainObject.SELECT_DESCRIPTION).append(SPACE).append(DOUBLE_QUOTE).append(strDescription).append(DOUBLE_QUOTE).append(RECORDSEP);
            sb.append(TAB).append(LABEL).append(SPACE).append(DOUBLE_QUOTE).append(strLabel).append(DOUBLE_QUOTE).append(RECORDSEP);
            sb.append(TAB).append(HREF).append(SPACE).append(DOUBLE_QUOTE).append(strHref).append(DOUBLE_QUOTE).append(RECORDSEP);
            sb.append(TAB).append(ALT).append(SPACE).append(DOUBLE_QUOTE).append(strAlt).append(DOUBLE_QUOTE).append(RECORDSEP);
            if( settingMap != null ){

                Iterator settingItr = settingMap.keySet().iterator();
                while(settingItr.hasNext())

                {

                    String settingName = (String)settingItr.next();
                    String settingValue = (String)settingMap.get(settingName);
                    sb.append(TAB).append(SETTING).append(SPACE).append(DOUBLE_QUOTE).append(settingName).append(DOUBLE_QUOTE).append(SPACE).append(DOUBLE_QUOTE).append(settingValue).append(DOUBLE_QUOTE).append(RECORDSEP);//label

                }

            }

 
            if( childrenList != null )
            {
            	Iterator childrenItr = childrenList.iterator();
            	while(childrenItr.hasNext())
            		
            	{
            		
            		Map childMap = (Map)childrenItr.next();
            		String name = (String)childMap.get("name");
            		String type = (String)childMap.get("type");
            		sb.append(TAB).append(type).append(SPACE).append(DOUBLE_QUOTE).append(name).append(DOUBLE_QUOTE).append(RECORDSEP);
            	}
            }


            if(propertiesMap!=null){

                Iterator propertyItr = propertiesMap.keySet().iterator();
                while(propertyItr.hasNext())

                {

                    String propertyName = (String)propertyItr.next();
                    String propertyValue = (String)propertiesMap.get(propertyName);
                    sb.append(PROPERTY).append(SPACE).append(DOUBLE_QUOTE).append(propertyName).append(DOUBLE_QUOTE).append(SPACE).append(VALUE).append(SPACE).append(DOUBLE_QUOTE).append(propertyValue).append(DOUBLE_QUOTE).append(RECORDSEP);//label

                }

            }

            sb.append(SEMI_COLON);
 

            StringBuffer sb2 = new StringBuffer();
            sb2.append(RECORDSEP);
            sb2.append("#*************************************************************").append(RECORDSEP);
            sb2.append("#!!!!!!!!!!!!!!!!!!!!!!!!!! Warning !!!!!!!!!!!!!!!!!!!!!!!!!!").append(RECORDSEP);
            sb2.append("#Parent Menu").append(RECORDSEP);
            
            System.out.println("sb2="+sb2);
            System.out.println("print menu \""+sName+"\" select parent dump");
            
            String strParent = MqlUtil.mqlCommand(context, "print menu \""+sName+"\" select parent dump");
            System.out.println("strParent="+strParent);
 

            StringList list = FrameworkUtil.split(strParent, ",");
            StringItr listItr = new StringItr(list);
            while(listItr.next()){

                String parentName = listItr.obj();
                String type = "";
                try{

                    MqlUtil.mqlCommand(context, "print menu '"+parentName+"' select name dump |");
                    type = "menu";
                }catch(Exception ex){

                    type = "command";
                }

                System.out.println("type="+type);
                int iRet = 0;
                StringList slRet = new StringList();
                if("menu".equals(type)){

                    String ret = MqlUtil.mqlCommand(context, "print "+type+" '"+parentName+"' select child dump |");
                    slRet = FrameworkUtil.split(ret, "|");
                    iRet = slRet.indexOf(sName);
                }else if( "command".equals(type)){

                    String ret = MqlUtil.mqlCommand(context, "print "+type+" '"+parentName+"' select child dump |");
                    slRet = FrameworkUtil.split(ret, "|");
                    iRet = slRet.indexOf(sName);
                }

                System.out.println("type="+type);
 

                if("menu".equals(type)){

                    sb2.append("#mod "+type).append(SPACE).append(DOUBLE_QUOTE).append(parentName).append(DOUBLE_QUOTE).append(SPACE).append("add menu").append(SPACE).append(sName).append(SEMI_COLON).append(RECORDSEP);
                    sb2.append("#mod "+type).append(SPACE).append(DOUBLE_QUOTE).append(parentName).append(DOUBLE_QUOTE).append(SPACE).append("order menu").append(SPACE).append(sName).append(SPACE).append(iRet+1).append(SEMI_COLON).append(RECORDSEP);
                }else if( "command".equals(type)){

                    sb2.append("#mod "+type).append(SPACE).append(DOUBLE_QUOTE).append(parentName).append(DOUBLE_QUOTE).append(SPACE).append("add command").append(SPACE).append(sName).append(SEMI_COLON).append(RECORDSEP);
                    sb2.append("#mod "+type).append(SPACE).append(DOUBLE_QUOTE).append(parentName).append(DOUBLE_QUOTE).append(SPACE).append("order command").append(SPACE).append(sName).append(SPACE).append(iRet+1).append(SEMI_COLON).append(RECORDSEP);
                }

            }

            sb2.append("#*************************************************************").append(RECORDSEP);
            System.out.println("sb2="+sb2);
            sb.append(sb2);

            saveFile(sName, sb);
            
            return sb.toString();
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

    public static String getChannelMQL(Context context, String name) throws Exception {

        StringBuffer sbResult = new StringBuffer();
        try {
            if( StringUtils.contains(name, ".mql") )
                name = StringUtils.remove(name, ".mql");
 
            HashMap mChannel  = UICache.getChannel(context, name);System.out.println(mChannel);
            MapList mCommands = (MapList) mChannel.get("commands");
            HashMap mSettings = (HashMap) mChannel.get("settings");
            HashMap mProperties = (HashMap) mChannel.get("properties");
 
            String sHeight = (String) MqlUtil.mqlCommand(context, "print channel '"+name+"' select height dump |");
            String sParents = (String) MqlUtil.mqlCommand(context, "print channel '"+name+"' select parent dump |");
 
            sbResult.append("#add channel '").append(name).append("';").append(RECORDSEP);
            sbResult.append("#copy channel '").append(name).append("' '").append(name).append("_backup';").append(RECORDSEP);
            sbResult.append("#delete channel '").append(name).append("';").append(RECORDSEP);
            sbResult.append(RECORDSEP);
            sbResult.append("add channel '").append(name).append("'").append(RECORDSEP);
            sbResult.append(SPACE).append(SPACE).append(SPACE).append("description").append(TAB).append("'").append(mChannel.get("description")).append("'").append(RECORDSEP);
            sbResult.append(SPACE).append(SPACE).append(SPACE).append("height").append(TAB).append("'").append(sHeight).append("'").append(RECORDSEP);
 
            for(Iterator cmdItr = mCommands.iterator(); cmdItr.hasNext();){
                Map mCmd = (Map) cmdItr.next();
                String sCmdType = (String) mCmd.get("type");
                String sCmdName = (String) mCmd.get("name");
 
                sbResult.append(SPACE).append(SPACE).append(SPACE).append(sCmdType).append(TAB).append("'").append(sCmdName).append("'").append(RECORDSEP);
            }

            for(Iterator propKeyItr = mSettings.keySet().iterator(); propKeyItr.hasNext();){
                String sPropKey = (String) propKeyItr.next();
                String sPropVal = (String) mSettings.get(sPropKey);
 
                sbResult.append(SPACE).append(SPACE).append(SPACE).append("setting").append(TAB).append("'").append(sPropKey).append("' '").append(sPropVal).append("'").append(RECORDSEP);
            }

            for(Iterator propKeyItr = mProperties.keySet().iterator(); propKeyItr.hasNext();){
                String sPropKey = (String) propKeyItr.next();
                String sPropVal = (String) mProperties.get(sPropKey);
 
                sbResult.append(SPACE).append(SPACE).append("property").append(TAB).append("'").append(sPropKey).append("' value '").append(sPropVal).append("'").append(RECORDSEP);
            }

            sbResult.append(";");
 
            if( StringUtils.isNotEmpty(sParents) ){

                String[] parents = StringUtils.split(sParents, "|");
                if( parents != null && parents.length > 0 ){
                    sbResult.append(RECORDSEP);
                    sbResult.append(RECORDSEP);
                    sbResult.append("#*************************************************************").append(RECORDSEP);
                    sbResult.append("#!!!!!!!!!!!!!!!!!!!!!!!!!! Warning !!!!!!!!!!!!!!!!!!!!!!!!!!").append(RECORDSEP);
                    for(String sP : parents){
                        sbResult.append("#Parent Portal : '").append(sP).append("' ").append(RECORDSEP);
                    }
                }
            }

            saveFile(name, sbResult);
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

        return sbResult.toString();
    }

 

    public static String getRelationshipMQL(Context context, String name, boolean detail) throws Exception {
    	StringBuffer sbResult = new StringBuffer();
    	boolean typeDetail = detail;
    	int newLineInterval = 4;
    	try {
    		if( StringUtils.contains(name, ".mql") ){
    			name = StringUtils.remove(name, ".mql");
    		}
            	
            sbResult.append("################################################################################################").append(RECORDSEP);
            sbResult.append("# Modified : ").append(new SimpleDateFormat("yyyy. MM. dd").format(new Date())).append(RECORDSEP);
            sbResult.append("# Admin Type : relationship").append(RECORDSEP);
            sbResult.append("# Name : ").append(name).append(RECORDSEP);
            sbResult.append("################################################################################################").append(RECORDSEP).append(RECORDSEP);

        	sbResult.append("#copy relationship '").append(name).append("' '").append(name).append("_backup';").append(RECORDSEP);
        	sbResult.append("#del relationship '").append(name).append("';").append(RECORDSEP);
        	sbResult.append(RECORDSEP);
            sbResult.append("add relationship '").append(name).append("'").append(RECORDSEP);
                
            String options = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select description abstract dynamic compositional preventduplicates hidden dump |;", 
    				true);  //runAsSuperUser
            String[] strOptions = options.split("\\|");
            
            sbResult.append(TAB).append("description '").append(strOptions[0]).append("'").append(RECORDSEP);
                       
            String attributes = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select attribute dump |;", 
    				true);  //runAsSuperUser
            StringTokenizer attrToken = new StringTokenizer(attributes, "|");
            int attrCount = attrToken.countTokens();
            if(attrCount > 0){
            	sbResult.append(TAB).append("attribute").append(SPACE);
            	
            	for(int i = 0; i < attrCount; i++){
            		if(i != 0 && (i % newLineInterval) == 0){
            			sbResult.append(RECORDSEP).append(TAB).append(TAB);
            		}
            		
            		sbResult.append("'").append(attrToken.nextToken()).append("'");
	            	
	            	if(i != attrCount - 1){
	            		sbResult.append(", ");
	            	}
            	}
	           
	            sbResult.append(RECORDSEP);
            }
            
            String derived = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select derived dump;", 
    				true);  //runAsSuperUser
            if(!"".equals(derived)){
            	sbResult.append(TAB).append("derived '").append(derived).append("'").append(RECORDSEP);
            }
            
            sbResult.append(TAB).append("abstract '").append(strOptions[1]).append("'").append(RECORDSEP);
            sbResult.append(TAB).append("dynamic '").append(strOptions[2]).append("'").append(RECORDSEP);

            if("TRUE".equals(strOptions[3])){
            	sbResult.append(TAB).append("compositional").append(RECORDSEP);
            }
 
            
            sbResult.append(TAB).append("from").append(RECORDSEP);
            
            String fromType = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select fromtype dump |;", 
    				true);  //runAsSuperUser
            
            if(!"".equals(fromType)){
            	sbResult.append(TAB).append(TAB).append("type ");
            	
            	StringTokenizer st = new StringTokenizer(fromType, "|");
            	int typeCount = 0;
            	while(st.hasMoreTokens()){
            		if(typeCount != 0 && (typeCount % newLineInterval) == 0){
            			sbResult.append(RECORDSEP).append(TAB).append(TAB).append(TAB);
            		}
            		
            		String type = st.nextToken();
            		sbResult.append("'").append(type).append("'");
            		typeCount++;
            		
            		if(st.hasMoreTokens()){
            			sbResult.append(", ");
            		}
            		
            		if(typeDetail){
            			String toDerivative = (String) MqlUtil.mqlCommand(context, 
                				true, //historyOff
                				"print type '"+type+"' select derivative dump |;", 
                				true);  //runAsSuperUser

                		StringTokenizer st1 = new StringTokenizer(toDerivative, "|");
                		if(st1.hasMoreTokens() && !st.hasMoreTokens()){
                			sbResult.append(", ");
                		}
                		
                		while(st1.hasMoreTokens()){
                			if(typeCount != 0 && (typeCount % newLineInterval) == 0){
                    			sbResult.append(RECORDSEP).append(TAB).append(TAB).append(TAB);
                    		}
                			
                    		sbResult.append("'").append(st1.nextToken()).append("'");
                    		typeCount++;
                    		
                    		if(st1.hasMoreTokens()){
                    			sbResult.append(", ");
                    		}else if(st.hasMoreTokens()){
                    			sbResult.append(", ");
                    		}
                    	}
            		}
            	}
            	
            	sbResult.append(RECORDSEP);
            }
            
            String fromRel = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select fromrel dump |;", 
    				true);  //runAsSuperUser
            
            if(!"".equals(fromRel)){
            	sbResult.append(TAB).append(TAB).append("relationship ");
            	
            	StringTokenizer st = new StringTokenizer(fromRel, "|");
            	int typeCount = 0;
            	while(st.hasMoreTokens()){
            		if(typeCount != 0 && (typeCount % newLineInterval) == 0){
            			sbResult.append(RECORDSEP).append(TAB).append(TAB).append(TAB);
            		}
            		
            		String type = st.nextToken();
            		sbResult.append("'").append(type).append("'");
            		typeCount++;
            		
            		if(st.hasMoreTokens()){
            			sbResult.append(", ");
            		}
            		
            		if(typeDetail){
            			String toDerivative = (String) MqlUtil.mqlCommand(context, 
                				true, //historyOff
                				"print type '"+type+"' select derivative dump |;", 
                				true);  //runAsSuperUser

                		StringTokenizer st1 = new StringTokenizer(toDerivative, "|");
                		if(st1.hasMoreTokens() && !st.hasMoreTokens()){
                			sbResult.append(", ");
                		}
                		
                		while(st1.hasMoreTokens()){
                			if(typeCount != 0 && (typeCount % newLineInterval) == 0){
                    			sbResult.append(RECORDSEP).append(TAB).append(TAB).append(TAB);
                    		}
                			
                    		sbResult.append("'").append(st1.nextToken()).append("'");
                    		typeCount++;
                    		
                    		if(st1.hasMoreTokens()){
                    			sbResult.append(", ");
                    		}else if(st.hasMoreTokens()){
                    			sbResult.append(", ");
                    		}
                    	}
            		}
            	}
            	
            	sbResult.append(RECORDSEP);
            }
            
            String fromString = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select frommeaning fromreviseaction fromcloneaction fromcardinality frompropagatemodify frompropagateconnection dump |;", 
    				true);  //runAsSuperUser
            String[] fromData = fromString.split("\\|");
            sbResult.append(TAB).append(TAB).append("meaning '").append(fromData[0]).append("'").append(RECORDSEP);
            sbResult.append(TAB).append(TAB).append("revision '").append(fromData[1]).append("'").append(RECORDSEP);
            sbResult.append(TAB).append(TAB).append("clone '").append(fromData[2]).append("'").append(RECORDSEP);
            sbResult.append(TAB).append(TAB).append("cardinality '").append(fromData[3]).append("'").append(RECORDSEP);
            if("TRUE".equals(fromData[4])){
            	sbResult.append(TAB).append(TAB).append("propagatemodify").append(RECORDSEP);
            }else{
            	sbResult.append(TAB).append(TAB).append("notpropagatemodify").append(RECORDSEP);
            }
            if("TRUE".equals(fromData[5])){
            	sbResult.append(TAB).append(TAB).append("propagateconnection").append(RECORDSEP);
            }else{
            	sbResult.append(TAB).append(TAB).append("notpropagateconnection").append(RECORDSEP);
            }
            
            
            sbResult.append(TAB).append("to").append(RECORDSEP);
            
            String toType = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select totype dump |;", 
    				true);  //runAsSuperUser
            
            if(!"".equals(toType)){
            	sbResult.append(TAB).append(TAB).append("type ");
            	
            	StringTokenizer st = new StringTokenizer(toType, "|");
            	int typeCount = 0;
            	while(st.hasMoreTokens()){
            		if(typeCount != 0 && (typeCount % newLineInterval) == 0){
            			sbResult.append(RECORDSEP).append(TAB).append(TAB).append(TAB);
            		}
            		
            		String type = st.nextToken();
            		sbResult.append("'").append(type).append("'");
            		typeCount++;
            		
            		if(st.hasMoreTokens()){
            			sbResult.append(", ");
            		}
            		
            		if(typeDetail){
            			String toDerivative = (String) MqlUtil.mqlCommand(context, 
                				true, //historyOff
                				"print type '"+type+"' select derivative dump |;", 
                				true);  //runAsSuperUser

                		StringTokenizer st1 = new StringTokenizer(toDerivative, "|");
                		if(st1.hasMoreTokens() && !st.hasMoreTokens()){
                			sbResult.append(", ");
                		}
                		
                		while(st1.hasMoreTokens()){
                			if(typeCount != 0 && (typeCount % newLineInterval) == 0){
                    			sbResult.append(RECORDSEP).append(TAB).append(TAB).append(TAB);
                    		}
                			
                    		sbResult.append("'").append(st1.nextToken()).append("'");
                    		typeCount++;
                    		
                    		if(st1.hasMoreTokens()){
                    			sbResult.append(", ");
                    		}else if(st.hasMoreTokens()){
                    			sbResult.append(", ");
                    		}
                    	}
            		}
            	}
            	
            	sbResult.append(RECORDSEP);
            }
            
            String toRel = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select torel dump |;", 
    				true);  //runAsSuperUser
            
            if(!"".equals(toRel)){
            	sbResult.append(TAB).append(TAB).append("relationship ");
            	
            	StringTokenizer st = new StringTokenizer(toRel, "|");
            	int typeCount = 0;
            	while(st.hasMoreTokens()){
            		if(typeCount != 0 && (typeCount % newLineInterval) == 0){
            			sbResult.append(RECORDSEP).append(TAB).append(TAB).append(TAB);
            		}
            		
            		String type = st.nextToken();
            		sbResult.append("'").append(type).append("'");
            		typeCount++;
            		
            		if(st.hasMoreTokens()){
            			sbResult.append(", ");
            		}
            		
            		if(typeDetail){
            			String toDerivative = (String) MqlUtil.mqlCommand(context, 
                				true, //historyOff
                				"print type '"+type+"' select derivative dump |;", 
                				true);  //runAsSuperUser

                		StringTokenizer st1 = new StringTokenizer(toDerivative, "|");
                		if(st1.hasMoreTokens() && !st.hasMoreTokens()){
                			sbResult.append(", ");
                		}
                		
                		while(st1.hasMoreTokens()){
                			if(typeCount != 0 && (typeCount % newLineInterval) == 0){
                    			sbResult.append(RECORDSEP).append(TAB).append(TAB).append(TAB);
                    		}
                			
                    		sbResult.append("'").append(st1.nextToken()).append("'");
                    		typeCount++;
                    		
                    		if(st1.hasMoreTokens()){
                    			sbResult.append(", ");
                    		}else if(st.hasMoreTokens()){
                    			sbResult.append(", ");
                    		}
                    	}
            		}
            	}
            	
            	sbResult.append(RECORDSEP);
            }
            
            String toString = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select tomeaning toreviseaction tocloneaction tocardinality topropagatemodify topropagateconnection dump |;", 
    				true);  //runAsSuperUser
            String[] toData = toString.split("\\|");
            sbResult.append(TAB).append(TAB).append("meaning '").append(toData[0]).append("'").append(RECORDSEP);
            sbResult.append(TAB).append(TAB).append("revision '").append(toData[1]).append("'").append(RECORDSEP);
            sbResult.append(TAB).append(TAB).append("clone '").append(toData[2]).append("'").append(RECORDSEP);
            sbResult.append(TAB).append(TAB).append("cardinality '").append(toData[3]).append("'").append(RECORDSEP);
            if("TRUE".equals(toData[4])){
            	sbResult.append(TAB).append(TAB).append("propagatemodify").append(RECORDSEP);
            }else{
            	sbResult.append(TAB).append(TAB).append("notpropagatemodify").append(RECORDSEP);
            }
            if("TRUE".equals(toData[5])){
            	sbResult.append(TAB).append(TAB).append("propagateconnection").append(RECORDSEP);
            }else{
            	sbResult.append(TAB).append(TAB).append("notpropagateconnection").append(RECORDSEP);
            }

            
            String trigger = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select trigger dump |;", 
    				true);  //runAsSuperUser
            StringTokenizer triggerToken = new StringTokenizer(trigger, "|");
            if(triggerToken.countTokens() > 0){
            	while(triggerToken.hasMoreTokens()){
            		StringTokenizer st = new StringTokenizer(triggerToken.nextToken(), ":|(|)");
            		String event = st.nextToken();
            		
            		sbResult.append(TAB).append("trigger ");
            		
            		if(event.startsWith("Create")){
            			sbResult.append("create ");
            		}else if(event.startsWith("Delete")){
            			sbResult.append("delete ");
            		}else if(event.startsWith("ModifyAttribute")){
            			sbResult.append("modifyattribute ");
            		}else if(event.startsWith("Freeze")){
            			sbResult.append("freeze ");
            		}else if(event.startsWith("Thaw")){
            			sbResult.append("thaw ");            			
            		}else if(event.startsWith("ModifyTo")){
            			sbResult.append("modifyto ");
            		}else if(event.startsWith("ModifyFrom")){
            			sbResult.append("modifyfrom ");
            		}
            		
            		if(event.endsWith("Action")){
            			sbResult.append("action ");
            		}else if(event.endsWith("Check")){
            			sbResult.append("check ");
            		}else if(event.endsWith("Override")){
            			sbResult.append("override ");
            		}
            		
            		String triggerName = st.nextToken();
            		sbResult.append(triggerName).append(" ");
            		if(st.hasMoreTokens()){
            			String argName = st.nextToken();
            			sbResult.append("input ").append(argName);
            		}
            		sbResult.append(RECORDSEP);
            	}
            }
            
            if("TRUE".equals(strOptions[4])){
            	sbResult.append(TAB).append("preventduplicates").append(RECORDSEP);
            }else{
            	sbResult.append(TAB).append("notpreventduplicates").append(RECORDSEP);
            }
            
            if("TRUE".equals(strOptions[5])){
            	sbResult.append(TAB).append("hidden").append(RECORDSEP);
            }else{
            	sbResult.append(TAB).append("nothidden").append(RECORDSEP);
            }
            
            String properties = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print relationship '"+name+"' select property dump |;", 
    				true);  //runAsSuperUser
            StringTokenizer propertyToken = new StringTokenizer(properties, "|");
            if(propertyToken.countTokens() > 0){
            	while(propertyToken.hasMoreTokens()){
            		//sbResult.append(TAB).append("property ").append(propertyToken.nextToken()).append(RECORDSEP);
            		String[] nameValue = propertyToken.nextToken().split(" value ");
            		sbResult.append(TAB).append("property ").append("'").append(nameValue[0]).append("'");
            		
            		String[] nameAdmin = nameValue[0].split(" to ");
            		if(nameAdmin.length > 1){
            			sbResult.append(" to ").append("'").append(nameAdmin[1]).append("'");
            		}
            		
            		if(nameValue.length > 1){
            			sbResult.append(" value ").append("'").append(nameValue[1]).append("'");
            		}
            		
            		sbResult.append(RECORDSEP);
            	}
            }
            
            sbResult.append(SEMI_COLON).append(RECORDSEP).append(RECORDSEP);
            
            saveFile(name, sbResult);
    	} catch (Exception e) {
    		e.printStackTrace();
    		throw e;
    	}

        return sbResult.toString();
    }

 

    public static String getAttributeMQL(Context context, String name) throws Exception {

        StringBuffer sbResult = new StringBuffer();
        try {

            if( StringUtils.contains(name, ".mql") )

                name = StringUtils.remove(name, ".mql");
 

            sbResult.append("################################################################################################").append(RECORDSEP);
            sbResult.append("# Modified : ").append(new SimpleDateFormat("yyyy. MM. dd").format(new Date())).append(RECORDSEP);
            sbResult.append("# Admin Type : Attribute").append(RECORDSEP);
            sbResult.append("# Name : ").append(name).append(RECORDSEP);
            sbResult.append("################################################################################################").append(RECORDSEP).append(RECORDSEP);
            sbResult.append("#del attribute '").append(name).append("';").append(RECORDSEP);
            sbResult.append("add attribute '").append(name).append("'").append(RECORDSEP);
 

            String sBases = MqlUtil.mqlCommand(context, "print attribute '"+name+"' select type multiline default hidden dump |");
            String ranges = MqlUtil.mqlCommand(context, "print attribute '"+name+"' select range dump |");
            String sDesc  = MqlUtil.mqlCommand(context, "print attribute '"+name+"' select description dump |");
            System.out.println("sBases " + sBases);
            StringList base    = FrameworkUtil.split(sBases, "|");
            StringList slRange = FrameworkUtil.split(ranges, "|");
 

            sbResult.append("   description '").append(sDesc).append("'").append(RECORDSEP);
            sbResult.append("   type        '").append(base.get(0)).append("'").append(RECORDSEP);
            sbResult.append("   default     '").append(base.get(2)).append("'").append(RECORDSEP);
            sbResult.append("   ").append(BooleanUtils.toBoolean((String)base.get(1))?"":"not").append("multiline").append(RECORDSEP);
            boolean bHidden = BooleanUtils.toBoolean((String)base.get(3));
            sbResult.append("   ").append(bHidden?"":"not").append("hidden").append(RECORDSEP);
 

            if( slRange != null && slRange.size() > 0 )

            {

                for (Iterator rangeItr = slRange.iterator(); rangeItr.hasNext();) {

                    String strRange = (String) rangeItr.next();
                    System.out.println("strRange : " + strRange);
                    sbResult.append("   range \"").append(strRange).append("\"").append(RECORDSEP);
                }

            }

            String propertys = MqlUtil.mqlCommand(context, "print attribute '"+name+"' select property.name dump |");
            String propertyVals = MqlUtil.mqlCommand(context, "print attribute '"+name+"' select property.value dump |");
            StringList slproperty      = FrameworkUtil.split(propertys, "|");
            StringList slpropertyValue = FrameworkUtil.split(propertyVals, "|");
 

            int i = 0;
            for (Iterator propItr = slpropertyValue.iterator(); propItr.hasNext();) {
                String prop = (String) propItr.next();
                String sPk = (String) slproperty.get(i);
                sPk = "\""+sPk+"\"";
                if( sPk.length() < 16 ) {
                    for (int j = sPk.length(); j < 16; j++) {
                        sPk += " ";
                    }
                }

                sbResult.append("  property ").append(sPk).append(" value \"").append(prop).append("\"").append(RECORDSEP);
                i++;
            }

            sbResult.append(";").append(RECORDSEP).append(RECORDSEP);
            sbResult.append("#add property attribute_").append(StringUtils.deleteWhitespace(name)).append(" on program 'eServiceSchemaVariableMapping.tcl' to attribute '").append(name).append("';").append(RECORDSEP);
 
            sbResult.append("################################################################################################").append(RECORDSEP);
            sbResult.append("#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!! Warning !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!").append(RECORDSEP);
            String types = MqlUtil.mqlCommand(context, "list type");
            StringList slType = FrameworkUtil.split(types, "\n");
            if( slType != null && slType.size() > 0 ) {
                String sAttrs = "";
                for (int j = 0; j < slType.size(); j++) {
                    String sType = (String) slType.get(j);
                    sAttrs = MqlUtil.mqlCommand(context, "print type '"+sType+"' select immediateattribute dump |");
                    StringList slAttrs = FrameworkUtil.split(sAttrs, "|");
                    if( slAttrs.contains(name) ) {
                        sbResult.append("#modify type '").append(sType).append("' add attribute '").append(name).append("';").append(RECORDSEP);
                    }
                }
            }

            sbResult.append("###############################################################################################").append(RECORDSEP);

            saveFile(name, sbResult);
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

        return sbResult.toString();
    }

 

    public static String getTypeMQL(Context context, String name) throws Exception {
        StringBuffer sbResult = new StringBuffer();
        try {
            if( StringUtils.contains(name, ".mql") )
                name = StringUtils.remove(name, ".mql");
 
            String s1 = MqlUtil.mqlCommand(context, "print type '"+name+"' select abstract description hidden dump " + SELECT_SEPERATOR);
            StringList sl1 = FrameworkUtil.split(s1, SELECT_SEPERATOR);
 
            sbResult.append("################################################################################################").append(RECORDSEP);
            sbResult.append("# Modified : ").append(new SimpleDateFormat("yyyy. MM. dd").format(new Date())).append(RECORDSEP);
            sbResult.append("# Admin Type : type").append(RECORDSEP);
            sbResult.append("# Name : ").append(name).append(RECORDSEP);
            sbResult.append("################################################################################################").append(RECORDSEP).append(RECORDSEP);

            String sDerived = MqlUtil.mqlCommand(context, "print type '"+name+"' select derived dump " + SELECT_SEPERATOR);
 
            sbResult.append("# del type '").append(name).append("';").append(RECORDSEP);
            sbResult.append("add type '").append(name).append("'").append(RECORDSEP);
 
            System.out.println("sl1 : " + sl1);
            System.out.println("sDerived : " + sDerived);
 
            sbResult.append(_TAB).append("description").append(_TAB).append("'").append(sl1.get(1)).append("'").append(RECORDSEP);
            sbResult.append(_TAB).append("derived").append(_TAB).append(_TAB).append("'").append(sDerived).append("'").append(RECORDSEP);
            sbResult.append(_TAB).append("abstract").append(_TAB).append("   '").append(sl1.get(0)).append("'").append(RECORDSEP);
            sbResult.append(_TAB).append("hidden").append(_TAB).append(_TAB).append(" '").append(sl1.get(2)).append("'").append(RECORDSEP);
 
            String s2 = MqlUtil.mqlCommand(context, "print type '"+name+"' select attribute dump " + SELECT_SEPERATOR);
            String s3 = MqlUtil.mqlCommand(context, "print type '"+name+"' select immediateattribute dump " + SELECT_SEPERATOR);
 
            StringList sl2 = FrameworkUtil.split(s2, SELECT_SEPERATOR);
            StringList sl3 = FrameworkUtil.split(s3, SELECT_SEPERATOR);
 
            sl3.sort();
            for (Iterator itr1 = sl3.iterator(); itr1.hasNext();) {
                String s4 = (String) itr1.next();
                sbResult.append(_TAB).append("attribute").append(_TAB).append(" '").append(s4).append("'").append(RECORDSEP);
                //if( !sl3.contains(s4) )
            }

 

            String sTrigger = MqlUtil.mqlCommand(context, "print type '"+name+"' select trigger dump |");
            if( sTrigger != null && !"".equals(sTrigger) ) {
                StringList slTrigger = FrameworkUtil.split(sTrigger, "|");
                for (Iterator itrTrigger = slTrigger.iterator(); itrTrigger.hasNext();) {
                    String sTr = (String) itrTrigger.next();
                    String[] strArrTrg = sTr.split(":");
 
                    String strTriggerType = strArrTrg[0];
                    String strTriggerName = StringUtils.substringBetween(strArrTrg[1], "(", ")");
                    System.out.println("strTriggerType : " + strTriggerType);
                    System.out.println("strTriggerName : " + strTriggerName);
 
                    sbResult.append(_TAB).append("trigger ");
                    if( strTriggerType.endsWith("Action") ){
                        sbResult.append(StringUtils.substringBefore(strTriggerType, "Action")).append(" action");
                    } else if( strTriggerType.endsWith("Override") ) {

                        sbResult.append(StringUtils.substringBefore(strTriggerType, "Override")).append(" override");
                    } else if( strTriggerType.endsWith("Check") ) {

                        sbResult.append(StringUtils.substringBefore(strTriggerType, "Check")).append(" check");
                    }

                    sbResult.append(" emxTriggerManager input '").append(strTriggerName).append("'").append(RECORDSEP);
                }

            }

 

            String s5 = MqlUtil.mqlCommand(context, "print type '"+name+"' select property[application].value property[version].value property[installer].value property[installed date].value property[original name].value dump " + SELECT_SEPERATOR);
            StringList sl4 = FrameworkUtil.split(s5, SELECT_SEPERATOR);
 

            sbResult.append("  ").append("property   'application'     value '").append(sl4.get(0)).append("'").append(RECORDSEP);
            sbResult.append("  ").append("property   'version'         value '").append(sl4.get(1)).append("'").append(RECORDSEP);
            sbResult.append("  ").append("property   'installer'       value '").append(sl4.get(2)).append("'").append(RECORDSEP);
            sbResult.append("  ").append("property   'installed date'  value '").append(sl4.get(3)).append("'").append(RECORDSEP);
            sbResult.append("  ").append("property   'original name'   value '").append(sl4.get(4)).append("'").append(RECORDSEP);
            sbResult.append(";").append(RECORDSEP);
 

            sbResult.append("add property type_").append(StringUtils.deleteWhitespace(name)).append(" on program eServiceSchemaVariableMapping.tcl to type '").append(name).append("';").append(RECORDSEP);
 

            System.out.println(sbResult.toString());
            saveFile(name, sbResult);
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

        return sbResult.toString();
    }

 

    public static String getPolicyMQL(Context context, String name) throws Exception {

        StringBuffer sb = new StringBuffer();
        try {

            String s1  = MqlUtil.mqlCommand(context, "print policy '"+name+"' select description revision store hidden format dump " + SELECT_SEPERATOR);
            //StringList sl1 = FrameworkUtil.split(s1, SELECT_SEPERATOR);
            String[] sl1 = s1.split("\\|");

            if(sl1.length == 4){
            	sl1 = new String[5];
            	sl1[4] = "";
            }
            
            int iDesc       = 0;
            int iRev        = 1;
            int iStore      = 2;
            int iHidden = 3;
            int iFormat = 4;

            sb.append("# copy policy '").append(name).append("' '").append(name).append("_backup'").append(RECORDSEP);
            sb.append("# delete policy '").append(name).append("'").append(RECORDSEP);
            sb.append("add policy '").append(name).append("'").append(RECORDSEP);
            sb.append(_TAB).append("description").append(_TAB).append("'").append(sl1[iDesc]).append("'").append(RECORDSEP);
            sb.append(_TAB).append("sequence").append(_TAB).append("   '").append(sl1[iRev]).append("'").append(RECORDSEP);
            sb.append(_TAB).append("store").append(_TAB).append(_TAB).append("  '").append(sl1[iStore]).append("'").append(RECORDSEP);
            sb.append(_TAB).append(BooleanUtils.toBoolean((String)sl1[iHidden])?"":"not").append("hidden").append(RECORDSEP);
 
            String s2  = MqlUtil.mqlCommand(context, "print policy '"+name+"' select type dump " + SELECT_SEPERATOR);
            StringList sl2 = FrameworkUtil.split(s2, SELECT_SEPERATOR);
            sb.append(_TAB).append("type").append(_TAB).append(_TAB).append("   ").append("'").append(StringUtils.join(sl2, "','")).append("'").append(RECORDSEP);

            sb.append(_TAB).append("format").append(_TAB).append(_TAB).append(" '").append(sl1[iFormat]).append("'").append(RECORDSEP);

            String s3  = MqlUtil.mqlCommand(context, "print policy '"+name+"' select state dump " + SELECT_SEPERATOR);
            StringList sl3 = FrameworkUtil.split(s3, SELECT_SEPERATOR);
            for (Iterator itr3 = sl3.iterator(); itr3.hasNext();) {

                String str = (String) itr3.next();
                sb.append(_TAB).append("state '").append(str).append("'").append(RECORDSEP);
                String s4 = MqlUtil.mqlCommand(context, "print policy '"+name+"' select state["+ str +"].revisionable dump " + SELECT_SEPERATOR);
                sb.append(_TAB).append(_TAB).append("revision").append(" ").append(s4).append(RECORDSEP);
                String s5 = MqlUtil.mqlCommand(context, "print policy '"+name+"' select state["+ str +"].versionable dump " + SELECT_SEPERATOR);
                sb.append(_TAB).append(_TAB).append("version").append("  ").append(s5).append(RECORDSEP);
                String s6 = MqlUtil.mqlCommand(context, "print policy '"+name+"' select state["+ str +"].autopromote dump " + SELECT_SEPERATOR);
                sb.append(_TAB).append(_TAB).append("promote").append("  ").append(s6).append(RECORDSEP);
                String s7 = MqlUtil.mqlCommand(context, "print policy '"+name+"' select state["+ str +"].checkouthistory dump " + SELECT_SEPERATOR);
                sb.append(_TAB).append(_TAB).append("checkouthistory").append("  ").append(s7).append(RECORDSEP);
                String s8 = MqlUtil.mqlCommand(context, "print policy '"+name+"' select state["+ str +"].owneraccess dump " + SELECT_SEPERATOR);
                sb.append(_TAB).append(_TAB).append("owner").append("  ").append(s8).append(RECORDSEP);
                String s9 = MqlUtil.mqlCommand(context, "print policy '"+name+"' select state["+ str +"].publicaccess dump " + SELECT_SEPERATOR);
                sb.append(_TAB).append(_TAB).append("public").append("  ").append(s9).append(RECORDSEP);

                String s10 = MqlUtil.mqlCommand(context, "print policy '"+name+"' select state["+ str +"].access");
                
                StringList sl4 = FrameworkUtil.split(s10, "\n");
                for (Iterator itr4 = sl4.iterator(); itr4.hasNext();) {
                    String str2 = StringUtils.trim((String) itr4.next());
                    if( StringUtils.isNotBlank(str2) && !"null".equals(str2) && !str2.startsWith("policy") ) {
                        String[] strArr1 = StringUtils.split(str2, "=");
                        String strUser = StringUtils.remove(strArr1[0].trim(), "state["+ str +"].access");
                        strUser = StringUtils.substringBetween(strUser, "[", "]");
//                        System.out.println("User : " + strUser);
                        sb.append(_TAB).append(_TAB).append("user").append("  '").append(strUser).append("' ").append(strArr1[1].trim()).append(RECORDSEP);
                    }
                }  
            }

            Policy policy = new Policy(name);
            StateRequirementList states = policy.getStateRequirements(context);
            for (Iterator itr = states.iterator(); itr.hasNext();) {
                StateRequirement sr = (StateRequirement) itr.next();
//                System.out.println(sr.getName());
            }
            
            String properties = (String) MqlUtil.mqlCommand(context, 
    				true, //historyOff
    				"print policy '"+name+"' select property dump |;", 
    				true);  //runAsSuperUser
            StringTokenizer propertyToken = new StringTokenizer(properties, "|");
            if(propertyToken.countTokens() > 0){
            	while(propertyToken.hasMoreTokens()){
            		String[] nameValue = propertyToken.nextToken().split(" value ");
            		sb.append(TAB).append("property ").append("'").append(nameValue[0]).append("'");
            		
            		String[] nameAdmin = nameValue[0].split(" to ");
            		if(nameAdmin.length > 1){
            			sb.append(" to ").append("'").append(nameAdmin[1]).append("'");
            		}
            		
            		if(nameValue.length > 1){
            			sb.append(" value ").append("'").append(nameValue[1]).append("'");
            		}
            		
            		sb.append(RECORDSEP);
            	}
            }
//            System.out.println(sb);
//            System.out.println(sl1[iHidden]);
            sb.append(";").append(RECORDSEP);
            saveFile(name, sb);
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }

        return sb.toString();
    }

 

    private static void saveFile(String sName, StringBuffer sb )

            throws IOException {

        saveFile(sName, sb, ".mql");
    }

 

    private static void saveFile(String sName, StringBuffer sb , String suffix)

            throws IOException {

        String documentDirectory = System.getenv("TEMP");
        System.out.println("TEMP_DIR : " + TEMP_DIR);
        if( TEMP_DIR != null)

            documentDirectory = TEMP_DIR;
        FileWriter statusLog = null;
        File oldFile = new File(documentDirectory + File.separator  + sName + suffix);
        boolean bExists = oldFile.exists();
        if( bExists ){

            boolean bDelete = oldFile.delete();
        }

        String outFilePath = documentDirectory + File.separator  + sName + suffix;
        System.out.println("Save File Path : " + outFilePath);
        statusLog   = new FileWriter(outFilePath, true);
 

        statusLog.flush();
        statusLog.write(sb.toString());
        statusLog.flush();
        statusLog.close();
    }

 

    /**

    * @param context

    * @param childOID

    * @param parentObj

    * @return

    * @throws FrameworkException

    * @throws MatrixException

    * @throws Exception

    */

    private boolean isAreadyConnectedPreviousEBOM(

            Context context,

            String childOID,

            DomainObject parentObj)

                    throws FrameworkException,

                    MatrixException,

                    Exception {

        BusinessObject previousBus = parentObj.getPreviousRevision(context);
        DomainObject previousObj = DomainObject.newInstance(context,

                previousBus);
 

        HashMap hashMap = new HashMap();
        hashMap.put("FromId", previousObj.getObjectId(context));
        hashMap.put("ToId", childOID);
        hashMap.put("RelName", DomainConstants.RELATIONSHIP_EBOM);
        boolean isAready = this.isAlreadyConnected(context,

                previousObj.getObjectId(context), childOID,

                DomainConstants.RELATIONSHIP_EBOM);
        return isAready;
    }

 

    private boolean isAlreadyConnected( Context context, String[] args) throws Exception

    {

        boolean isConnected = false;
        HashMap hmArgs = (HashMap)JPO.unpackArgs(args);
        String strFromId    = (String)hmArgs.get("FromId");
        String strToId        = (String)hmArgs.get("ToId");
        String strRelName    = (String)hmArgs.get("RelName");
 

        isConnected = isAlreadyConnected( context, strFromId, strToId, strRelName, true);
        return isConnected;
    }

    private boolean isAlreadyConnected(Context context,

            String strFromId,

            String strToId,

            String strRelName

            )

                    throws Exception

                    {

        return isAlreadyConnected( context, strFromId, strToId, strRelName, true);
                    }

    /**

    * It finds whether two objects are connected through a Particular Relationship or not.

    * @param context - The eMatrix <code>Context</code> object

    * @param strFromId -       from side Object Id

    * @param strToId -         to side Object Id

    * @param strRelName -      relationship name

    * @param bFrom - if true, expand from

    * @since ProductCentral 10-6

    * @grade 0

    **/

    private boolean isAlreadyConnected(Context context,

            String strFromId,

            String strToId,

            String strRelName,

            boolean bFrom) throws Exception {

        boolean isAlreadyConnected = false;
        try {

            String sMqlCmd = "";
            if(bFrom)

                sMqlCmd = "expand bus "+strFromId+" from rel \""+strRelName+"\" recurse to 1 select bus where \"id=="+strToId+"\" dump |";
            else

                sMqlCmd = "expand bus "+strToId+" to rel \""+strRelName+"\" recurse to 1 select bus where \"id=="+strFromId+"\" dump |";
 

            String sRetVal = MqlUtil.mqlCommand(context, sMqlCmd);
            isAlreadyConnected = sRetVal != null && !"".equals(sRetVal);
        } catch (Exception e) {

            System.out.println("Error in isAlreadyConnected : " + e.toString());
        }

        return isAlreadyConnected;
    }//end method

 

    public String baseDir = "D:" + File.separator + "LGE_prj" + File.separator

            + "V30" + File.separator + "ematrix" + File.separator;
    public String centralDir = "engineeringcentral";
    public void Customized(Context context, String[] args) throws Exception {

 

        try {

 

 

            File file = new File(baseDir + File.separator + centralDir);
            File[] emxlist = file.listFiles(new FilenameFilter() {

                public boolean accept(File dir, String name) {

                    boolean bEmx = name.startsWith("emx");
                    if (bEmx) {

 

                        File lgeFile = new File(baseDir + File.separator + centralDir, "lge" + name);
 

 

                        if (lgeFile.exists()) {

                            System.out.println("lgeFile=" + lgeFile);
                            System.out.println("lgeFile.exists()="

                                    + lgeFile.exists());
                            return true;
                        } else {

                            return false;
                        }

                    } else {

                        return false;
                    }

                }

            });
 

            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < emxlist.length; i++) {

                System.out.println("file list = " + emxlist[i].getName());
                sb.append( centralDir+File.separator+"lge"+emxlist[i].getName() );
                sb.append("\n");
 

            }

            saveFile(centralDir+"_custom", sb, ".txt");
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

    public void newfile(Context context, String[] args) throws Exception {

 

        try {

            File file = new File(baseDir + File.separator + centralDir);
            File[] emxlist = file.listFiles(new FilenameFilter() {

                public boolean accept(File dir, String name) {

                    boolean bEmx = name.startsWith("lge");
                    if (bEmx) {

                        if( name.startsWith("lgeemx")==true )

                        {

                            return false;
                        }

                        File lgeFile = new File(baseDir + File.separator + centralDir, name );
 

 

                        if (lgeFile.exists()) {

                            System.out.println("lgeFile=" + lgeFile);
                            System.out.println("lgeFile.exists()="

                                    + lgeFile.exists());
                            return true;
                        } else {

                            return false;
                        }

                    } else {

                        return false;
                    }

                }

            });
 

            StringBuffer sb = new StringBuffer();
            for (int i = 0; i < emxlist.length; i++) {

                System.out.println("file list = " + emxlist[i].getName());
                sb.append( centralDir+File.separator + emxlist[i].getName() );
                sb.append("\n");
 

            }

            saveFile(centralDir+"_new", sb, ".txt");
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

    public static StringBuffer sbCommand = new StringBuffer();
    public static StringBuffer sbMenu = new StringBuffer();
    public void getMenuChilds(Context context, String[] args) throws Exception{

        System.out.println("emxSchemaUtil_mxJPO.getMenuChilds()");
        try {

 

            for (int i = 0; i < args.length; i++) {

                sbCommand.append("["+args[i]+"]\n");
                getMenuChild(context, args[i], sbCommand, sbMenu);
            }

        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

    public void getMenuChild(Context context, String sName , StringBuffer sbCommand, StringBuffer sbMenu)  throws Exception{

 

        try {

 

            String sMql1 = "print menu '" + sName+ "' select child[].type dump";
            String sMql2 = "print menu '" + sName+ "' select child[].name dump";
            String sResult1 = MqlUtil.mqlCommand(context, sMql1);
            String sResult2 = MqlUtil.mqlCommand(context, sMql2);
            System.out.println("sResult1=" + sResult1);
            System.out.println("sResult2=" + sResult2);
            StringList sTypes = FrameworkUtil.split(sResult1, ",");
            StringList sNames = FrameworkUtil.split(sResult2, ",");
            Iterator iterator1 = sNames.iterator();
            for (Iterator iterator2 = sTypes.iterator(); iterator2.hasNext();) {

                String sType = (String) iterator2.next();
                String sChildName = (String) iterator1.next();
                System.out.println("sType=" + sType);
                System.out.println("sChildName=" + sChildName);
                if ("command".equalsIgnoreCase(sType)) {

                    sbCommand.append(sChildName);
                    sbCommand.append("\n");
                    getCommandMQL(context, sChildName);
                }

 

                if ("menu".equalsIgnoreCase(sType)) {

                    sbMenu.append(sChildName);
                    sbMenu.append("\n");
                    getMenuChilds(context, new String[] { sChildName });
                    getMenuMQL(context, sChildName);
                }

            }

            saveFile(".." + File.separator +"command", sbCommand,  ".txt");
            saveFile(".." + File.separator + "menu", sbMenu, ".txt");
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

 

    }

 

    public static void schemaMigration(Context context , String args ) throws Exception{

        System.out.println("emxSchemaUtil_mxJPO.schemaMigration()");
        File schemaFile = new File(args);
        FileInputStream fis = new FileInputStream(schemaFile);
        //

        //

        //

        POIFSFileSystem fs = new POIFSFileSystem(fis);
        StringBuffer mql = new StringBuffer();
        try {

            HSSFWorkbook workbook = new HSSFWorkbook(fs);
            int sheetNum = workbook.getNumberOfSheets();
            for (int k = 0; k < sheetNum; k++) {

 

 

                mql = new StringBuffer();
                HSSFSheet sheet = workbook.getSheetAt(k);
                String sheetName = workbook.getSheetName(k);
                System.out.println("sheetName="+sheetName);
                if(StringUtils.equals("New_Attribute", sheetName)){

                    getAttributeMql(mql, sheet, sheetName);
 

                } else if(StringUtils.equals("New_Type", sheetName)){

                    getTypeMql(mql, sheet, sheetName);
 

                } else if(StringUtils.equals("New_Relationship", sheetName)){

                    getRelationshipMql(mql, sheet, sheetName);
 

                } else if(StringUtils.equals("New_Policy", sheetName)){

                    getPolicyMql(mql, sheet, sheetName);
 

                }

                saveFile("delete_schema", REMOVE_SCHMA);
                saveFile("string_resource", STRING_RESOURCE,".txt");
                saveFile("import_schema", IMPORT_SCHMA);
                saveFile("export_schema", EXPORT_SCHMA);
 

 

            }

        } catch (Exception e) {

            System.out.println("emxSchemaUtil_mxJPO.schemaMigration()");
            System.out.println("mql="+mql);
            e.printStackTrace();
        } finally{

            fis.close();
        }

 

    }

 

    /**

    * @param mql

    * @param sheet

    * @param sheetName

    * @throws IOException

    */

    private static void getAttributeMql(StringBuffer mql, HSSFSheet sheet,

            String sheetName) throws IOException {

        int rows = sheet.getPhysicalNumberOfRows();
        HSSFRow headerRow = sheet.getRow(0);
        int headerCells = 8;
 

 

        try {

            for (int r = 1; r < rows; r++) {

                StringBuffer sbCmd = new StringBuffer();
                String symbolic = "";
 

                HSSFRow row = sheet.getRow(r);
                if (row != null) {

                    int cells = row.getPhysicalNumberOfCells();
                    String description = "";
                    for (short c = 0; c < (short) headerCells; c++) {

                        HSSFCell headerCell = headerRow.getCell(c);
                        HSSFCell cell = row.getCell(c);
 

                        String name = headerCell.getStringCellValue().trim();
                        if (cell != null) {

 

                            if ("symbolic".equals(name)) {

                                symbolic = "add property "

                                        + cell.getStringCellValue().trim()

                                        + " on program eServiceSchemaVariableMapping.tcl to attribute "

                                        + row.getCell((short) 0)

                                        .getStringCellValue().trim() + "";
                            } else if ("name".equals(name)) {

                                sbCmd.append("\n#ADD ATTRIBUTE "+cell.getStringCellValue().trim());
                                sbCmd.append("\n");
                                sbCmd.append("add attribute \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
                                REMOVE_SCHMA.append("delete attribute ");
                                REMOVE_SCHMA.append("\"");
                                REMOVE_SCHMA.append(cell.getStringCellValue().trim());
                                REMOVE_SCHMA.append("\";");
                                REMOVE_SCHMA.append("\n");
 

                                EXPORT_SCHMA.append("export attribute "+cell.getStringCellValue().trim()+" xml into file \"");
                                //D:\dev\sejong_bak\sji\MQL

                                EXPORT_SCHMA.append(EXPORT_DIR);
                                EXPORT_SCHMA.append("01.attribute");
                                EXPORT_SCHMA.append(File.separator);
                                EXPORT_SCHMA.append(cell.getStringCellValue().trim());
                                EXPORT_SCHMA.append(".xml\";");
                                EXPORT_SCHMA.append("\n");
 

 

                                IMPORT_SCHMA.append("import attribute "+cell.getStringCellValue().trim()+" from file \"");
                                //D:\dev\sejong_bak\sji\MQL

                                IMPORT_SCHMA.append(EXPORT_DIR);
                                IMPORT_SCHMA.append("01.attribute");
                                IMPORT_SCHMA.append(File.separator);
                                IMPORT_SCHMA.append(cell.getStringCellValue().trim());
                                IMPORT_SCHMA.append(".xml\";");
                                IMPORT_SCHMA.append("\n");
 

 

                            } else if ("type".equals(name)) {

                                sbCmd.append("type ");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append(" ");
                                sbCmd.append("\n");
 

                            } else if ("default".equals(name)) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(cell.getBooleanCellValue());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                            } else if ("description".equals(name)) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
                                description = cell.getStringCellValue().trim();
 

                            } else if ("multiline".equals(name)) {

                                sbCmd.append("");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append(name);
                                sbCmd.append(" ");
                                sbCmd.append("\n");
 

                            } else if ("dimension".equals(name)) {

                                sbCmd.append("dimension \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                            } else if ("hidden".equals(name)) {

                                sbCmd.append("");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append(name);
                                sbCmd.append("\n");
                            }

                        }

 

                    }

 

                    STRING_RESOURCE.append("emxFramework.Attribute.");
                    STRING_RESOURCE.append(row.getCell((short) 0).getStringCellValue().trim() );
                    STRING_RESOURCE.append("=");
                    STRING_RESOURCE.append(description);
                    STRING_RESOURCE.append("\n");
 

 

                    for (short c = (short) headerCells; c < 40; c++) {

                        HSSFCell cell = row.getCell(c);
                        if (cell != null) {

 

 

                            String value = null;
                            switch (cell.getCellType()) {

                            case HSSFCell.CELL_TYPE_FORMULA:

                                value = cell.getCellFormula();
                                break;
                            case HSSFCell.CELL_TYPE_NUMERIC:

                                value = String.valueOf(cell

                                        .getNumericCellValue());
                                break;
                            case HSSFCell.CELL_TYPE_STRING:

                                value = cell.getStringCellValue().trim();
                                break;
                            case HSSFCell.CELL_TYPE_BLANK:

                                value = null;
                                break;
                            case HSSFCell.CELL_TYPE_BOOLEAN:

                                value = String.valueOf(cell

                                        .getBooleanCellValue());
                                break;
                            case HSSFCell.CELL_TYPE_ERROR:

                                value = String

                                .valueOf(cell.getErrorCellValue());
                                break;
                            default:

                            }

 

                            //StringUtils.isn

                            if( StringUtils.isNotEmpty( value ) ){

                                sbCmd.append(" range ");
                                String rangeValue = StringUtils.substringBetween(value, "[", "]");
                                //String displayValue = StringUtils.substringAfter(value, "[");
                                //displayValue = StringUtils.substringBefore(displayValue, "]");
                                String displayValue = StringUtils.substringBefore(value, "[");
 

                                sbCmd.append(" = \"");
                                sbCmd.append(rangeValue.trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                                STRING_RESOURCE.append("emxFramework.Range.");
                                STRING_RESOURCE.append(row.getCell((short) 0).getStringCellValue().trim() );
                                STRING_RESOURCE.append(".");
                                STRING_RESOURCE.append(rangeValue);
                                STRING_RESOURCE.append("=");
                                STRING_RESOURCE.append(displayValue);
                                STRING_RESOURCE.append("\n");
                            }

                        }

                    }

 

                }

 

                mql.append(sbCmd.toString());
                mql.append(" property version value V6R2009x.SEJONG ");
                mql.append("\n");
                mql.append(" property application value SEJONG ");
                mql.append("\n");
                mql.append(" property installer value SEJONG-ADMIN ");
                mql.append("\n");
                mql.append(" property \"original name\" value \"" + row.getCell((short) 0).getStringCellValue().trim()+"\"" );
                mql.append("\n");
                Calendar calOriginated = new GregorianCalendar();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getInputDateFormat() , Locale.US);
                mql.append(" property \"installed date\" value \"" + simpleDateFormat.format(calOriginated.getTime()) +"\"" );
                mql.append("\n");
                mql.append(";");
                mql.append("\n");
                mql.append(symbolic + ";");
                mql.append("\n");
                //System.out.println("mql="+mql);
            }

            saveFile(sheetName, mql);
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

 

    /**

    * @param mql

    * @param sheet

    * @param sheetName

    * @throws IOException

    */

    private static void getTypeMql(StringBuffer mql, HSSFSheet sheet,

            String sheetName) throws IOException {

        int rows = sheet.getPhysicalNumberOfRows();
        HSSFRow headerRow = sheet.getRow(0);
        int headerCells = 6;
 

 

        try {

            for (int r = 1; r < rows; r++) {

                StringBuffer sbCmd = new StringBuffer();
                String symbolic = "";
 

                HSSFRow row = sheet.getRow(r);
                if (row != null) {

                    int cells = row.getPhysicalNumberOfCells();
                    String description = "";
                    for (short c = 0; c < (short) headerCells; c++) {

                        HSSFCell headerCell = headerRow.getCell(c);
                        HSSFCell cell = row.getCell(c);
 

                        String name = headerCell.getStringCellValue().trim();
                        name = name.trim();
 

                        if (cell != null) {

 

                            if ("symbolic".equals(name)) {

                                symbolic = "add property "

                                        + cell.getStringCellValue().trim()

                                        + " on program eServiceSchemaVariableMapping.tcl to type "

                                        + row.getCell((short) 0)

                                        .getStringCellValue().trim() + "";
                            } else if ("name".equals(name)) {

                                sbCmd.append("\n#ADD TYPE "+cell.getStringCellValue().trim());
                                sbCmd.append("\n");
                                sbCmd.append("add type \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

 

                                REMOVE_SCHMA.append("delete type ");
                                REMOVE_SCHMA.append("\"");
                                REMOVE_SCHMA.append(cell.getStringCellValue().trim());
                                REMOVE_SCHMA.append("\";");
                                REMOVE_SCHMA.append("\n");
 

 

                                EXPORT_SCHMA.append("export type "+cell.getStringCellValue().trim()+" xml into file \"");
                                //D:\dev\sejong_bak\sji\MQL

                                EXPORT_SCHMA.append(EXPORT_DIR);
                                EXPORT_SCHMA.append("02.type");
                                EXPORT_SCHMA.append(File.separator);
                                EXPORT_SCHMA.append(cell.getStringCellValue().trim());
                                EXPORT_SCHMA.append(".xml\";");
                                EXPORT_SCHMA.append("\n");
 

                                IMPORT_SCHMA.append("import type "+cell.getStringCellValue().trim()+" from file \"");
                                //D:\dev\sejong_bak\sji\MQL

                                IMPORT_SCHMA.append(EXPORT_DIR);
                                IMPORT_SCHMA.append("02.type");
                                IMPORT_SCHMA.append(File.separator);
                                IMPORT_SCHMA.append(cell.getStringCellValue().trim());
                                IMPORT_SCHMA.append(".xml\";");
                                IMPORT_SCHMA.append("\n");
 

                            } else if ("derived".equals(name)) {

                                sbCmd.append("derived ");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append(" ");
                                sbCmd.append("\n");
 

                            } else if ("abstract".equals(name)) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(cell.getBooleanCellValue());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                            } else if ("description".equals(name)) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                                description=cell.getStringCellValue().trim();
 

                            } else if ("hidden".equals(name)) {

                                sbCmd.append("");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append(name);
                                sbCmd.append(" ");
                                sbCmd.append("\n");
                            }

                        }

 

                    }

 

 

                    STRING_RESOURCE.append("emxFramework.Type.");
                    STRING_RESOURCE.append(row.getCell((short) 0).getStringCellValue().trim() );
                    STRING_RESOURCE.append("=");
                    STRING_RESOURCE.append(description);
                    STRING_RESOURCE.append("\n");
 

                    if( headerCells < cells ){

                        sbCmd.append(" attribute ");
                    }

                    for (short c = (short) headerCells; c < cells; c++) {

                        HSSFCell cell = row.getCell(c);
                        if (cell != null) {

                            String value = null;
                            switch (cell.getCellType()) {

                            case HSSFCell.CELL_TYPE_FORMULA:

                                value = cell.getCellFormula();
                                break;
                            case HSSFCell.CELL_TYPE_NUMERIC:

                                value = String.valueOf(cell

                                        .getNumericCellValue());
                                break;
                            case HSSFCell.CELL_TYPE_STRING:

                                value = cell.getStringCellValue().trim();
                                break;
                            case HSSFCell.CELL_TYPE_BLANK:

                                value = null;
                                break;
                            case HSSFCell.CELL_TYPE_BOOLEAN:

                                value = String.valueOf(cell

                                        .getBooleanCellValue());
                                break;
                            case HSSFCell.CELL_TYPE_ERROR:

                                value = String

                                .valueOf(cell.getErrorCellValue());
                                break;
                            default:

 

                            }

                            sbCmd.append(" \"");
                            sbCmd.append(value.trim());
                            sbCmd.append("\" ");
                            if( c+1 < cells ){

                                sbCmd.append(" , ");
                            }

                            sbCmd.append("\n");
                        }

                    }

 

                }

                mql.append(sbCmd.toString());
                mql.append(" property version value V6R2009x.SEJONG ");
                mql.append("\n");
                mql.append(" property application value SEJONG ");
                mql.append("\n");
                mql.append(" property installer value SEJONG-ADMIN ");
                mql.append("\n");
                mql.append(" property \"original name\" value \"" + row.getCell((short) 0).getStringCellValue().trim()+"\"" );
                mql.append("\n");
                Calendar calOriginated = new GregorianCalendar();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getInputDateFormat() , Locale.US);
                mql.append(" property \"installed date\" value \"" + simpleDateFormat.format(calOriginated.getTime()) +"\"" );
                mql.append("\n");
                mql.append(";");
                mql.append("\n");
                mql.append(symbolic + ";");
                mql.append("\n");
            }

            saveFile(sheetName, mql);
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

 

    /**

    * @param mql

    * @param sheet

    * @param sheetName

    * @throws IOException

    */

    private static void getRelationshipMql(StringBuffer mql, HSSFSheet sheet,

            String sheetName) throws IOException {

        int rows = sheet.getPhysicalNumberOfRows();
        HSSFRow headerRow = sheet.getRow(0);
        int headerCells = 4;
 

 

        try {

            for (int r = 1; r < rows; r++) {

                StringBuffer sbCmd = new StringBuffer();
                String symbolic = "";
 

                HSSFRow row = sheet.getRow(r);
                if (row != null) {

                    int cells = row.getPhysicalNumberOfCells();
                    String description = "";
                    for (short c = 0; c < (short) headerCells; c++) {

                        HSSFCell headerCell = headerRow.getCell(c);
                        HSSFCell cell = row.getCell(c);
 

                        String name = headerCell.getStringCellValue().trim();
                        name = name.trim();
 

                        if (cell != null) {

 

                            if ("symbolic".equals(name)) {

                                symbolic = "add property "

                                        + cell.getStringCellValue().trim()

                                        + " on program eServiceSchemaVariableMapping.tcl to relationship "

                                        + row.getCell((short) 0)

                                        .getStringCellValue().trim() + "";
                            } else if ("name".equals(name)) {

                                sbCmd.append("\n#ADD RELATIONSHIP "+cell.getStringCellValue().trim());
                                sbCmd.append("\n");
                                sbCmd.append("add relationship \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

 

                                REMOVE_SCHMA.append("delete relationship ");
                                REMOVE_SCHMA.append("\"");
                                REMOVE_SCHMA.append(cell.getStringCellValue().trim());
                                REMOVE_SCHMA.append("\";");
                                REMOVE_SCHMA.append("\n");
 

                                EXPORT_SCHMA.append("export relationship "+cell.getStringCellValue().trim()+" xml into file \"");
                                //D:\dev\sejong_bak\sji\MQL

                                EXPORT_SCHMA.append(EXPORT_DIR);
                                EXPORT_SCHMA.append("04.relationship");
                                EXPORT_SCHMA.append(File.separator);
                                EXPORT_SCHMA.append(cell.getStringCellValue().trim());
                                EXPORT_SCHMA.append(".xml\";");
                                EXPORT_SCHMA.append("\n");
 

                                IMPORT_SCHMA.append("import relationship "+cell.getStringCellValue().trim()+" from file \"");
                                //D:\dev\sejong_bak\sji\MQL

                                IMPORT_SCHMA.append(EXPORT_DIR);
                                IMPORT_SCHMA.append("04.relationship");
                                IMPORT_SCHMA.append(File.separator);
                                IMPORT_SCHMA.append(cell.getStringCellValue().trim());
                                IMPORT_SCHMA.append(".xml\";");
                                IMPORT_SCHMA.append("\n");
 

 

                            } else if ("description".equals(name)) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                                description=cell.getStringCellValue().trim();
 

                            } else if ("hidden".equals(name)) {

                                sbCmd.append("");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append(name);
                                sbCmd.append(" ");
                                sbCmd.append("\n");
                            }

                        }

 

                    }

 

 

                    STRING_RESOURCE.append("emxFramework.Relationship.");
                    STRING_RESOURCE.append(row.getCell((short) 0).getStringCellValue().trim() );
                    STRING_RESOURCE.append("=");
                    STRING_RESOURCE.append(description);
                    STRING_RESOURCE.append("\n");
 

 

                    for (short c = (short) headerCells; c < cells; c++) {

                        HSSFCell headerCell = headerRow.getCell(c);
                        String name = headerCell.getStringCellValue().trim();
                        name = name.trim();
 

                        HSSFCell cell = row.getCell(c);
                        if (cell != null) {

                            String value = null;
                            switch (cell.getCellType()) {

                            case HSSFCell.CELL_TYPE_FORMULA:

                                value = cell.getCellFormula();
                                break;
                            case HSSFCell.CELL_TYPE_NUMERIC:

                                value = String.valueOf(cell

                                        .getNumericCellValue());
                                break;
                            case HSSFCell.CELL_TYPE_STRING:

                                value = cell.getStringCellValue().trim();
                                break;
                            case HSSFCell.CELL_TYPE_BLANK:

                                value = null;
                                break;
                            case HSSFCell.CELL_TYPE_BOOLEAN:

                                value = String.valueOf(cell

                                        .getBooleanCellValue());
                                break;
                            case HSSFCell.CELL_TYPE_ERROR:

                                value = String

                                .valueOf(cell.getErrorCellValue());
                                break;
                            default:

 

                            }

 

                            if ("direction".equals(name)) {

                                sbCmd.append(" ");
                                sbCmd.append(value.trim());
                                sbCmd.append(" ");
                                sbCmd.append("\n");
                            } else if ("name".equals(name)) {

                                sbCmd.append(" \"");
                                sbCmd.append(value.trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
                            } else if ("meaning".equals(name) || "cardinality".equals(name) || "cardinality".equals(name) ) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(value.trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
                            } else if ("propagatemodify".equals(name) || "propagateconnection".equals(name)) {

                                sbCmd.append("");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append(name);
                                sbCmd.append(" ");
                                sbCmd.append("\n");
                            }

                        }

                    }

 

                }

 

                mql.append(sbCmd.toString());
                mql.append(" property version value V6R2009x.SEJONG ");
                mql.append("\n");
                mql.append(" property application value SEJONG ");
                mql.append("\n");
                mql.append(" property installer value SEJONG-ADMIN ");
                mql.append("\n");
                mql.append(" property \"original name\" value \"" + row.getCell((short) 0).getStringCellValue().trim()+"\"" );
                mql.append("\n");
                Calendar calOriginated = new GregorianCalendar();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getInputDateFormat() , Locale.US);
                mql.append(" property \"installed date\" value \"" + simpleDateFormat.format(calOriginated.getTime()) +"\"" );
                mql.append("\n");
                mql.append(";");
                mql.append("\n");
                mql.append(symbolic + ";");
                mql.append("\n");
            }

            saveFile(sheetName, mql);
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

 

 

    /**

    * @param mql

    * @param sheet

    * @param sheetName

    * @throws IOException

    */

    private static void getPolicyMql(StringBuffer mql, HSSFSheet sheet,

            String sheetName) throws IOException {

        int rows = sheet.getPhysicalNumberOfRows();
        HSSFRow headerRow = sheet.getRow(0);
        int headerCells = 7;
 

 

        try {

            for (int r = 1; r < rows; r++) {

                StringBuffer sbCmd = new StringBuffer();
                String symbolic = "";
 

                HSSFRow row = sheet.getRow(r);
                if (row != null) {

                    int cells = row.getPhysicalNumberOfCells();
                    String description = "";
                    for (short c = 0; c < (short) headerCells; c++) {

                        HSSFCell headerCell = headerRow.getCell(c);
                        HSSFCell cell = row.getCell(c);
 

                        String name = headerCell.getStringCellValue().trim();
                        name = name.trim();
 

                        if (cell != null) {

 

                            if ("symbolic".equals(name)) {

                                symbolic = "add property "

                                        + cell.getStringCellValue().trim()

                                        + " on program eServiceSchemaVariableMapping.tcl to policy "

                                        + row.getCell((short) 0)

                                        .getStringCellValue().trim() + "";
                            } else if ("name".equals(name)) {

                                sbCmd.append("\n#ADD POLICY "+cell.getStringCellValue().trim());
                                sbCmd.append("\n");
                                sbCmd.append("add policy \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                                REMOVE_SCHMA.append("delete policy ");
                                REMOVE_SCHMA.append("\"");
                                REMOVE_SCHMA.append(cell.getStringCellValue().trim());
                                REMOVE_SCHMA.append("\";");
                                REMOVE_SCHMA.append("\n");
 

                                EXPORT_SCHMA.append("export policy "+cell.getStringCellValue().trim()+" xml into file \"");
                                //D:\dev\sejong_bak\sji\MQL

                                EXPORT_SCHMA.append(EXPORT_DIR);
                                EXPORT_SCHMA.append("05.policy");
                                EXPORT_SCHMA.append(File.separator);
                                EXPORT_SCHMA.append(cell.getStringCellValue().trim());
                                EXPORT_SCHMA.append(".xml\";");
                                EXPORT_SCHMA.append("\n");
 

 

                                IMPORT_SCHMA.append("import policy "+cell.getStringCellValue().trim()+" from file \"");
                                //D:\dev\sejong_bak\sji\MQL

                                IMPORT_SCHMA.append(EXPORT_DIR);
                                IMPORT_SCHMA.append("05.policy");
                                IMPORT_SCHMA.append(File.separator);
                                IMPORT_SCHMA.append(cell.getStringCellValue().trim());
                                IMPORT_SCHMA.append(".xml\";");
                                IMPORT_SCHMA.append("\n");
 

 

 

                            } else if ("description".equals(name)) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                                description = cell.getStringCellValue().trim();
 

                            } else if ("format".equals(name)) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                            } else if ("sequence".equals(name)) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
 

                            } else if ("store".equals(name)) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                            } else if ("type".equals(name)) {

                                String typeName = cell.getStringCellValue().trim();
                                String[] typeNames = StringUtils.split(typeName, ",");
                                sbCmd.append(name);
                                for( int idx = 0 ; idx < typeNames.length ; idx++ ){

                                    sbCmd.append(" \"");
                                    sbCmd.append(typeNames[idx].trim());
                                    sbCmd.append("\" ");
                                    if( (idx+1) < typeNames.length ){

                                        sbCmd.append(", ");
                                    }

                                }

                                sbCmd.append("\n");
                            } else if ("defaultformat".equals(name)) {

                                sbCmd.append(name);
                                sbCmd.append(" \"");
                                sbCmd.append(cell.getStringCellValue().trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
                            }

                        }

 

                    }

 

 

 

                    STRING_RESOURCE.append("emxFramework.Relationship.");
                    STRING_RESOURCE.append(row.getCell((short) 0).getStringCellValue().trim() );
                    STRING_RESOURCE.append("=");
                    STRING_RESOURCE.append(description);
                    STRING_RESOURCE.append("\n");
 

 

 

                    StringBuffer stateSymbolic = new StringBuffer();
                    String stateName = "";
                    for (short c = (short) headerCells; c < cells; c++) {

                        HSSFCell headerCell = headerRow.getCell(c);
                        String name = headerCell.getStringCellValue().trim();
                        name = name.trim();
 

                        HSSFCell cell = row.getCell(c);
                        if (cell != null) {

                            String value = null;
                            switch (cell.getCellType()) {

                            case HSSFCell.CELL_TYPE_FORMULA:

                                value = cell.getCellFormula();
                                break;
                            case HSSFCell.CELL_TYPE_NUMERIC:

                                value = String.valueOf(cell

                                        .getNumericCellValue());
                                break;
                            case HSSFCell.CELL_TYPE_STRING:

                                value = cell.getStringCellValue().trim();
                                break;
                            case HSSFCell.CELL_TYPE_BLANK:

                                value = null;
                                break;
                            case HSSFCell.CELL_TYPE_BOOLEAN:

                                value = String.valueOf(cell

                                        .getBooleanCellValue());
                                break;
                            case HSSFCell.CELL_TYPE_ERROR:

                                value = String

                                .valueOf(cell.getErrorCellValue());
                                break;
                            default:

 

                            }

 

                            if ("state".equals(name)) {

                                sbCmd.append(" state ");
                                sbCmd.append(" ");
                                sbCmd.append(value.trim());
                                sbCmd.append(" ");
                                stateName = value.trim();
                                sbCmd.append("\n");
 

                            } else if ("version".equals(name)) {

                                sbCmd.append(" version \"");
                                sbCmd.append(value.trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                            } else if ("revision".equals(name)) {

                                sbCmd.append(" revision \"");
                                sbCmd.append(value.trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                            } else if ("promote".equals(name)) {

                                sbCmd.append(" promote \"");
                                sbCmd.append(value.trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                            } else if ("checkouthistory".equals(name)) {

                                sbCmd.append(" checkouthistory \"");
                                sbCmd.append(value.trim());
                                sbCmd.append("\" ");
                                sbCmd.append("\n");
 

                            } else if ("symbolic".equals(name)) {

                                stateSymbolic.append("property \"");
                                stateSymbolic.append(value.trim());
                                stateSymbolic.append("\" value \"");
                                stateSymbolic.append(stateName);
                                stateSymbolic.append("\" ");
                            }

                        }

                    }

                    sbCmd.append(stateSymbolic.toString());
                }

                mql.append(sbCmd.toString());
                mql.append(" property version value V6R2009x.SEJONG ");
                mql.append("\n");
                mql.append(" property application value SEJONG ");
                mql.append("\n");
                mql.append(" property installer value SEJONG-ADMIN ");
                mql.append("\n");
                mql.append(" property \"original name\" value \"" + row.getCell((short) 0).getStringCellValue().trim()+"\"" );
                mql.append("\n");
                Calendar calOriginated = new GregorianCalendar();
                SimpleDateFormat simpleDateFormat = new SimpleDateFormat(eMatrixDateFormat.getInputDateFormat() , Locale.US);
                mql.append(" property \"installed date\" value \"" + simpleDateFormat.format(calOriginated.getTime()) +"\"" );
                mql.append("\n");
                mql.append(";");
                mql.append("\n");
 

 

                mql.append(symbolic + ";");
                mql.append("\n");
            }

            saveFile(sheetName, mql);
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

 

 

 

    public static void isFormExists(Context context , String[] args) throws Exception{

        String ret = MqlUtil.mqlCommand(context, "print type '"+args[0]+"' select derivative dump |" );
        StringList retList = FrameworkUtil.split(ret, "|");
        StringItr retItr = new StringItr(retList);
        while(retItr.next()){

            String type = retItr.obj();
            String typeSymbol = FrameworkUtil.getAliasForAdmin(context, "type", type, false);
            try{

                String isChild = MqlUtil.mqlCommand(context, "print type "+type+" select derivative dump;" );
                if( StringUtils.isEmpty(isChild) ){

                    String isExists = MqlUtil.mqlCommand(context, "print form "+typeSymbol+" select web dump;" );
                    //System.out.println(typeSymbol+"="+isExists);
                }

            }catch(Exception ex){

                System.out.println(typeSymbol+"=FALSE");
            }

        }

 

    }

    //D:\Dev\shi\XML

    //public static String exportBaseDir = "F:"+File.separator+"Export"+ File.separator;
    public static String exportBaseDir = "C:"+File.separator+"enoviaV6R2016x"+File.separator+"Export"+ File.separator;
    //public static String dtdDir = "F:"+File.separator+"Export"+ File.separator;
    public static String dtdDir = "C:"+File.separator+"enoviaV6R2016x"+File.separator+"Export"+ File.separator;
 

 

    private static void copy(File fOrg, File fTarget) throws IOException {

        FileInputStream io = new FileInputStream(fOrg);
 

 

        fTarget.createNewFile();
 

        FileOutputStream out = new FileOutputStream(fTarget);
 

        byte[] bBuffer = new byte[1024 * 8];
 

        int nRead;
        while ((nRead = io.read(bBuffer)) != -1) {

            out.write(bBuffer, 0, nRead);
        }

 

        io.close();
        out.close();
    }

 

 

    //quote on;verbos on;set context person creator;insert program 'D:\Dev\shi\JPO\${CLASSNAME}.java';execute program emxSchemaUtil -method exportAllSchemaXML;quit;
    //quote on;verbos on;set context person creator;execute program emxSchemaUtil -method exportSchemaXML;quit;
    public static void exportSchemaXML(Context context , String[] args) throws Exception{

        //exportAdmineXML(context , "group" , "23.group" , false);
        //exportBusXML(context , "Person" , "22.Person" , true);
        exportBusXML(context , "eService Trigger Program Parameters" , "12.eService Trigger Program Parameters" , true);
    }

    public static void exportAllSchemaXML(Context context , String[] args) throws Exception{

        System.out.println("emxSchemaUtil_mxJPO.exportAllSchemaXML(Start)");
        long lStartTime = System.currentTimeMillis();
        long lTime1 = lStartTime;
        Date todayDate = new Date();
        SimpleDateFormat mxDateFrmt = new SimpleDateFormat("yyyy-MM-dd",Locale.KOREA);
        String dateStr = mxDateFrmt.format(todayDate);
 

        exportBaseDir = exportBaseDir + dateStr + File.separator;
        File export = new File(exportBaseDir);
        export.mkdir();
 

        //exportAdmineXML(context , "dimension", "00.dimension" , true);
 

        long lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(attribute) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

        exportAdmineXML(context , "attribute", "01.attribute" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(attribute) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

        exportAdmineXML(context , "type", "02.type" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(type) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

        exportAdmineXML(context , "interface", "03.interface" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(interface) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

        exportAdmineXML(context , "relationship", "04.relationship" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(interface) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

        exportAdmineXML(context , "policy", "05.policy" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(policy) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

        exportAdmineXML(context , "command", "06.command" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(command) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

        exportAdmineXML(context , "menu", "07.menu" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(menu) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

 

 

        exportAdmineXML(context , "form", "08.webform" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(webform) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

 

        exportAdmineXML(context , "table", "09.table" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(table) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

        exportAdmineXML(context , "inquiry", "10.inquiry" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(inquiry) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

 

        exportAdmineXML(context , "channel", "11.channel" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(channel) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

        exportBusXML(context , "eService Trigger Program Parameters" , "12.eService Trigger Program Parameters" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(eService Trigger Program Parameters) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

        exportBusXML(context , "eService Object Generator" , "13.eService Object Generator" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(eService Object Generator) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

        exportBusXML(context , "eService Number Generator" , "13.eService Object Generator" , false);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(eService Number Generator) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

        System.out.println("tcl skip");
 

 

 

        exportAdmineXML(context , "portal", "16.portal" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(portal) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

 

        exportBusXML(context , "Notification" , "18.Notification" , false);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(Notification) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

        exportAdmineXML(context , "role" , "20.role" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(role) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

        exportAdmineXML(context , "association" , "21.association" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(associationr) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

        //        exportBusXML(context , "sjiNVHEngineCode" , "15.etc" , false);
        //

        //        lTime2 = System.currentTimeMillis();
        //        System.out.println("exportAdmineXML(eService Number Generator) Time ==> "+(lTime2-lTime1));
        //        lTime1 = lTime2;
 

        exportAdmineXML(context , "role" , "20.role" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(role) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

        exportAdmineXML(context , "person" , "22.Person_Schema" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(person) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

        exportBusXML(context , "Person" , "22.Person" , true);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(person) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

        exportAdmineXML(context , "group" , "23.group" , false);
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(group) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

        export = new File(exportBaseDir,"24.tcl");
        if( export.exists()){

            delete(context, export );
        }

        export.mkdir();
        File dtd = new File(dtdDir+"ematrixml.dtd");
        copy(dtd,new File(export,"ematrixml.dtd"));
 

        String mql = "export program 'eServiceSchemaVariableMapping.tcl' xml into file '"+export.getPath()+File.separator + "eServiceSchemaVariableMapping.tcl.xml' exception '"+exportBaseDir+"exception.log'";
        String expRet = MqlUtil.mqlCommand(context, mql );
 

        lTime2 = System.currentTimeMillis();
        System.out.println("exportAdmineXML(tcl) Time ==> "+(lTime2-lTime1));
        lTime1 = lTime2;
 

 

        System.out.println("exportAllSchemaXML Time ==> "+(lTime2-lStartTime));
    }

 

 

 

 

 

    public static void exportAdmineXML(Context context , String args , String args2, boolean isClear) throws Exception{

        File export = new File(exportBaseDir,args2);
        if( export.exists() && isClear){

            delete(context, export );
        }

        export.mkdir();
 

        File dtd = new File(dtdDir+"ematrixml.dtd");
        copy(dtd,new File(export,"ematrixml.dtd"));
 

        String system = "";
        if( StringUtils.equals("table", args)){

            system = " system ";
        }

        StringList retList = new StringList();
        if( StringUtils.equals("association",args ) ){

            String ret = MqlUtil.mqlCommand(context, "list "+args+system+"" );
            retList = FrameworkUtil.split(ret, "\n");
        }else{

            //System.out.println("quote on;list "+args+system+" * select name dump recordsep ~");
            String ret = MqlUtil.mqlCommand(context, "quote on;list "+args+system+" * select name dump" );
            retList = FrameworkUtil.split(ret, "\n");
        }

        StringItr retItr = new StringItr(retList);
        SAXBuilder sax = new SAXBuilder();
        XMLOutputter outputer = new XMLOutputter(Format.getPrettyFormat());
        while(retItr.next()){

            String obj = retItr.obj();
 

            String mql = "";
            if( StringUtils.equals("association",args ) ){

                mql = "export "+args+" "+obj+" xml into file '"+export.getPath()+File.separator+FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(obj, ":", "~"), "/", ""), "'", "")+ ".xml' exception '"+exportBaseDir+"exception.log'";
 

            }else{

                mql = "export "+args+" '"+obj+"' xml into file '"+export.getPath()+File.separator+FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(obj, ":", "~"), "/", ""), "'", "")+ ".xml' exception '"+exportBaseDir+"exception.log'";
            }

            try{

                String expRet = MqlUtil.mqlCommand(context, mql );
 

                Document doc = sax.build(export.getPath()+File.separator+FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(obj, ":", "~"), "/", ""), "'", "")+ ".xml");
                FileOutputStream out = new FileOutputStream(new File(export.getPath()+File.separator+FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(obj, ":", "~"), "/", ""), "'", "")+ ".xml"));
                if( isDateRemove ){

                    doc.getRootElement().removeChild("creationProperties");
                    Element element = (Element)XPath.selectSingleNode(doc.getRootElement(),"/ematrix//adminProperties");
                    element.removeChild("creationInfo");
                    element.removeChild("modificationInfo");
                }

                outputer.output(doc, out);
 

            }catch(Exception ex){

                System.out.println("mql="+mql +":");
                ex.printStackTrace();
            }

        }

    }

 

    public static void delete(Context context , File file) throws Exception{

        File[] subDir = file.listFiles();
        for( int idx = 0 ; idx < subDir.length ; idx++ ){

 

            if( subDir[idx].isDirectory() ){

                delete(context , subDir[idx]);
            }else{

                subDir[idx].delete();
            }

        }

    }

 

    public static void exportBusXML(Context context , String args , String args2, boolean isClear) throws Exception{

        File export = new File(exportBaseDir,args2);
        if( export.exists() && isClear){

            delete(context, export );
        }

        export.mkdir();
 

        File dtd = new File(dtdDir+"ematrixml.dtd");
        copy(dtd,new File(export,"ematrixml.dtd"));
 

        //System.out.println("quote on;temp query bus '"+args+"' * * select type name revision dump |" );
        String ret = MqlUtil.mqlCommand(context, "quote on;temp query bus '"+args+"' * * select type name revision dump |" );
        StringList retList = FrameworkUtil.split(ret, "\n");
        StringItr retItr = new StringItr(retList);
        SAXBuilder sax = new SAXBuilder();
        XMLOutputter outputer = new XMLOutputter(Format.getPrettyFormat());
        while(retItr.next()){

            String obj = retItr.obj();
            StringList objList = FrameworkUtil.split(obj, "|");
            String mql = "export bus '"+objList.get(3)+"' '"+objList.get(4)+"' '"+objList.get(5)+"' xml into file '"+export.getPath()+File.separator+FrameworkUtil.findAndReplace((String)objList.get(3), "/", "")+"~"+FrameworkUtil.findAndReplace((String)objList.get(4), "/", "")+"~"+FrameworkUtil.findAndReplace((String)objList.get(5), "/", "")+".xml' exception '"+exportBaseDir+"exception.log'";
            try{

                String expRet = MqlUtil.mqlCommand(context, mql );
                Document doc = sax.build(export.getPath()+File.separator+FrameworkUtil.findAndReplace((String)objList.get(3), "/", "")+"~"+FrameworkUtil.findAndReplace((String)objList.get(4), "/", "")+"~"+FrameworkUtil.findAndReplace((String)objList.get(5), "/", "")+".xml");
                FileOutputStream out = new FileOutputStream(new File(export.getPath()+File.separator+FrameworkUtil.findAndReplace((String)objList.get(3), "/", "")+"~"+FrameworkUtil.findAndReplace((String)objList.get(4), "/", "")+"~"+FrameworkUtil.findAndReplace((String)objList.get(5), "/", "")+".xml"));
                if( isDateRemove ){

                    doc.getRootElement().removeChild("creationProperties");
                    Element element = (Element)XPath.selectSingleNode(doc.getRootElement(),"/ematrix//businessObject");
                    element.removeChild("creationInfo");
                    element.removeChild("modificationInfo");
                }

                outputer.output(doc, out);
            }catch(Exception ex){

                System.out.println("mql="+mql +":");
                ex.printStackTrace();
            }

        }

    }

 

    //set context person creator;insert program 'D:\Dev\shi\JPO\${CLASSNAME}.java';start trans; exec program emxSchemaUtil -method importSchemaEach;abort trans;quit;
    public static void importSchemaEach(Context context , String[] args) throws Exception {

        Date todayDate = new Date();
        todayDate.setMonth( 6 );
        todayDate.setDate( 30 );
        SimpleDateFormat mxDateFrmt = new SimpleDateFormat("yyyy-MM-dd",Locale.KOREA);
        String dateStr = mxDateFrmt.format(todayDate);
        exportBaseDir = exportBaseDir + dateStr + File.separator;
        File export = new File(exportBaseDir,"22.Person_Schema");
        FilenameFilter fileNameFilter = new FilenameFilter() {

            public boolean accept(File dir, String name) {

                return name.endsWith(".xml")

                        &&!name.startsWith( "SAP" )

                        &&!name.startsWith( "VPM" )

                        &&!name.startsWith( "VPLM" )

                        &&!name.startsWith( "Configured Part" )

                        &&!name.startsWith( "creator" )

                        &&!name.startsWith( "guest" )

                        &&( name.indexOf( "_backup" ) == -1 );
            }

        };
        Calendar toDaycal = new GregorianCalendar();
        toDaycal.clear();
        toDaycal.set( 2011 , Calendar.MARCH , 15 , 00 , 00 , 00 );
 

        System.out.println("######################################################################");
        System.out.println("#                          START CHANNEL                             #");
        System.out.println("######################################################################");
        export = new File(exportBaseDir,"11.channel");
        removeSchema(context , export ,fileNameFilter , "channel");
        importSchema(context , export ,fileNameFilter);
        System.out.println("######################################################################");
        System.out.println("#                          START PORTAL                              #");
        System.out.println("######################################################################");
        export = new File(exportBaseDir,"16.portal");
        removeSchema(context , export ,fileNameFilter , "portal");
        importSchema(context , export , fileNameFilter);
    }

    //set context person creator;insert program 'D:\Dev\shi\JPO\${CLASSNAME}.java';start trans; exec program emxSchemaUtil -method importSchemaAll;abort trans;quit;
    //set context person creator;insert program 'D:\Dev\shi\JPO\${CLASSNAME}.java';exec program emxSchemaUtil -method importSchemaAll 1;quit;
    //set context person creator;insert program 'D:\Dev\shi\JPO\${CLASSNAME}.java';exec program emxSchemaUtil -method importSchemaAll 2;quit;
    //

    public static void importSchemaAll(Context context , String[] args) throws Exception {

        try

        {

            ContextUtil.startTransaction( context , true );
 

            File export = new File(exportBaseDir);
            Calendar toDaycal = new GregorianCalendar();
            toDaycal.clear();
            toDaycal.set( 2011 , Calendar.JULY , 28 , 00 , 00 , 00 ); //

                    System.out.println(DatatypeConverter.printDateTime( toDaycal ) );
 

                    Date todayDate = new Date();
                    todayDate.setMonth( 6 );//

                    todayDate.setDate( 30 );//

                    SimpleDateFormat mxDateFrmt = new SimpleDateFormat("yyyy-MM-dd",Locale.KOREA);
                    String dateStr = mxDateFrmt.format(todayDate);
                    System.out.println("dateStr="+dateStr);
                    exportBaseDir = exportBaseDir + dateStr + File.separator;
                    FilenameFilter fileNameFilter = new FilenameFilter() {

                        public boolean accept(File dir, String name) {

                            return name.endsWith(".xml")

                                    &&!name.startsWith( "SAP" )

                                    &&!name.startsWith( "VPM" )

                                    &&!name.startsWith( "VPLM" )

                                    &&!name.startsWith( "Configured Part" )

                                    &&( name.indexOf( "_backup" ) == -1 );
                        }

                    };
                    if( StringUtils.equals(args[0] , "1") ){

                        System.out.println("######################################################################");
                        System.out.println("#                         START DIMENSION                            #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir+"00.dimension");
                        importSchemaAdd(context , export , fileNameFilter , toDaycal , "dimension" );
                        importSchemaModify(context , export , fileNameFilter , toDaycal , "dimension" );
 

                        System.out.println("######################################################################");
                        System.out.println("#                         START ATTRIBUTE                            #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir+"01.attribute");
                        importSchemaAdd(context , export , fileNameFilter , toDaycal , "attribute" );
                        importSchemaModify(context , export , fileNameFilter , toDaycal , "attribute" );
 

                        System.out.println("######################################################################");
                        System.out.println("#                         START TYPE                                 #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir+"02.type");
                        importSchemaAdd(context , export , fileNameFilter , toDaycal , "type" );
                        importSchemaModify(context , export , fileNameFilter , toDaycal , "type" );
 

                        System.out.println("######################################################################");
                        System.out.println("#                         START INTERFACE                            #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir+"03.interface");
                        importSchemaAdd(context , export , fileNameFilter , toDaycal , "interface" );
                        importSchemaModify(context , export , fileNameFilter , toDaycal , "interface" );
 

                        System.out.println("######################################################################");
                        System.out.println("#                         START RELATIONSHIP                         #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir+"04.relationship");
                        importSchemaAdd(context , export , fileNameFilter , toDaycal , "relationship" );
                        importSchemaModify(context , export , fileNameFilter , toDaycal , "relationship" );
                    }

                    /*********************************************************************************************************

                    *

                    *             

                    *             Role / Person Schema / Person Bus / Role

            System.out.println("######################################################################");
            System.out.println("#                         START GROUP                                #");
            System.out.println("######################################################################");
 

            export = new File(exportBaseDir,"23.group");
            importSchema(context , export , new FilenameFilter() {

                public boolean accept(File dir, String name) {

                    return name.endsWith(".xml");
                }

            });
 

            System.out.println("######################################################################");
            System.out.println("#                         START PERSON                                 #");
            System.out.println("######################################################################");
 

 

            export = new File(exportBaseDir,"22.Person_Schema");
            importSchemaAdd(context , export , fileNameFilter = new FilenameFilter() {

                public boolean accept(File dir, String name) {

                    return name.endsWith(".xml")

                    &&!name.startsWith( "SAP" )

                    &&!name.startsWith( "VPM" )

                    &&!name.startsWith( "VPLM" )

                    &&!name.startsWith( "Configured Part" )

                    &&!name.startsWith( "creator" )

                    &&!name.startsWith( "guest" )

                    &&( name.indexOf( "_backup" ) == -1 );
                }

            } , toDaycal , "person" );
            importSchemaModify(context , export , fileNameFilter = new FilenameFilter() {

                public boolean accept(File dir, String name) {

                    return name.endsWith(".xml")

                    &&!name.startsWith( "SAP" )

                    &&!name.startsWith( "VPM" )

                    &&!name.startsWith( "VPLM" )

                    &&!name.startsWith( "Configured Part" )

                    &&!name.startsWith( "creator" )

                    &&!name.startsWith( "guest" )

                    &&( name.indexOf( "_backup" ) == -1 );
                }

            } , toDaycal , "person" );
 

            export = new File(exportBaseDir,"22.Person");
            importBusSchema(context , export , new FilenameFilter() {

                public boolean accept(File dir, String name) {

                    return name.endsWith(".xml");
                }

            });
 

 

            System.out.println("######################################################################");
            System.out.println("#                         START ROLE                                 #");
            System.out.println("######################################################################");
 

            export = new File(exportBaseDir,"20.role");
            importSchemaAdd(context , export , fileNameFilter , toDaycal , "role" );
            importSchemaModify(context , export , fileNameFilter , toDaycal , "role" );
 

                    ***********************************************************************************************************/

 

                    if( StringUtils.equals(args[0] , "2") ){

 

                        System.out.println("######################################################################");
                        System.out.println("#                          START POLICY                              #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir+"05.policy");
                        importSchemaAdd(context , export , fileNameFilter , toDaycal , "policy" );
                        importSchemaModify(context , export , fileNameFilter , toDaycal , "policy" );
 

 

 

                        System.out.println("######################################################################");
                        System.out.println("#                          START COMMAND                             #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"06.command");
                        importSchema(context , export , new FilenameFilter() {

                            public boolean accept(File dir, String name) {

                                return name.endsWith(".xml");
                            }

                        });
 

                        toDaycal.clear();
                        toDaycal.set( 2011 , Calendar.JANUARY , 1 , 00 , 00 , 00 );
 

                        System.out.println("######################################################################");
                        System.out.println("#                          START MENU                                #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"07.menu");
 

                        FilenameFilter menuFilter = new FilenameFilter() {

                            public boolean accept(File dir, String name) {

                                return name.endsWith(".xml")

                                        &&!name.startsWith( "VPM" )

                                        &&!name.startsWith( "VPLM" )

                                        &&!name.equals("Tree.xml")

                                        &&( name.indexOf( "_backup" ) == -1 );
                            }

                        };
                        importMenuAdd(context , export , menuFilter , toDaycal , "menu" );
 

                        menuFilter = new FilenameFilter() {

                            public boolean accept(File dir, String name) {

                                return name.endsWith(".xml")

                                        &&!name.startsWith( "VPM" )

                                        &&!name.startsWith( "VPLM" )

                                        &&name.equals("Tree.xml")

                                        &&( name.indexOf( "_backup" ) == -1 );
                            }

                        };
                        importMenuAdd(context , export , menuFilter , toDaycal , "menu" );
                        importSchema(context , export , fileNameFilter);
 

 

                        System.out.println("######################################################################");
                        System.out.println("#                          START WEBFORM                             #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"08.webform");
                        importSchema(context , export , fileNameFilter);
 

                        System.out.println("######################################################################");
                        System.out.println("#                          START TABLE                               #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"09.table");
                        importSchema(context , export , fileNameFilter);
 

                        System.out.println("######################################################################");
                        System.out.println("#                          START INQUIRY                             #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"10.inquiry");
                        importSchema(context , export , fileNameFilter);
                        System.out.println("######################################################################");
                        System.out.println("#                          START CHANNEL                             #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"11.channel");
                        removeSchema(context , export ,fileNameFilter , "channel");
                        importSchema(context , export ,fileNameFilter);
                        System.out.println("######################################################################");
                        System.out.println("#                          START PORTAL                              #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"16.portal");
                        importSchema(context , export , fileNameFilter);
 

 

 

                        System.out.println("######################################################################");
                        System.out.println("#                          START association                         #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"21.association");
                        importSchema(context , export , fileNameFilter);
                        System.out.println("######################################################################");
                        System.out.println("#         START eService Trigger Program Parameters                  #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"12.eService Trigger Program Parameters");
                        importBusSchema(context , export , fileNameFilter);
 

                        System.out.println("######################################################################");
                        System.out.println("#              START eService Object Generator                       #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"13.eService Object Generator");
                        importBusSchema(context , export , fileNameFilter);
 

 

                        System.out.println("######################################################################");
                        System.out.println("#                     START Notification                             #");
                        System.out.println("######################################################################");
                        export = new File(exportBaseDir,"18.Notification");
                        importBusSchema(context , export , fileNameFilter);
 

                        fileNameFilter = new FilenameFilter() {

                            public boolean accept(File dir, String name) {

                                return !name.equals( ".svn" ) && name.endsWith( ".java" ) ;
                            }

                        };
                        export = new File("D:"+File.separator+"Dev"+File.separator+"shi"+ File.separator+"JPO"+ File.separator);
                        importJPOSchema(context , export ,  fileNameFilter);
 

 

                        fileNameFilter = new FilenameFilter() {

                            public boolean accept(File dir, String name) {

                                return !name.equals( ".svn" ) ;
                            }

                        };
                        export = new File("D:"+File.separator+"Dev"+File.separator+"shi"+ File.separator+"MQL"+ File.separator+"14.tcl"+ File.separator);
                        importTCLSchema(context , export , fileNameFilter);
 

 

                        export = new File(exportBaseDir,"24.tcl");
                        String mql = "import program 'eServiceSchemaVariableMapping.tcl' overwrite from file '"+export.getPath()+File.separator + "eServiceSchemaVariableMapping.tcl.xml'";
                        String expRet = MqlUtil.mqlCommand(context, mql );
 

 

                        export = new File("D:"+File.separator+"Dev"+File.separator+"shi"+ File.separator+"WebContent"+ File.separator + "config.xml");
                        mql = "set system searchindex file '"+export.getPath()+"'";
                        expRet = MqlUtil.mqlCommand(context, mql );
 

 

                    }

 

                    System.out.println( "emxSchemaUtil_mxJPO.importSchemaAll(OK)" );
        }catch (Exception ex){

            ex.printStackTrace();
            ContextUtil.abortTransaction( context );
            throw ex;
        }finally{

            ContextUtil.commitTransaction( context );
        }

 

    }

    public static void importJPOSchema(Context context , String[] args) throws Exception{

        File file = new File("D:"+File.separator+"Dev"+File.separator+"shi"+ File.separator+"JPO"+ File.separator);
        FilenameFilter fileNameFilter = new FilenameFilter() {

            public boolean accept(File dir, String name) {

                return !name.equals( ".svn" ) && name.endsWith( ".java" ) ;
            }

        };
        importJPOSchema(context , file , fileNameFilter);
    }

    public static void importTCLSchema(Context context , String[] args) throws Exception{

        File file = new File("D:"+File.separator+"Dev"+File.separator+"shi"+ File.separator+"MQL"+ File.separator+"14.tcl"+ File.separator);
        FilenameFilter fileNameFilter = new FilenameFilter() {

            public boolean accept(File dir, String name) {

                return !name.equals( ".svn" ) ;
            }

        };
        importTCLSchema(context , file , fileNameFilter);
    }

 

    public static void importJPOSchema(Context context , File file , FilenameFilter filter) throws Exception{

        File[] files = file.listFiles(filter);
        for(int idx = 0 ; idx < files.length ; idx++) {

            MqlUtil.mqlCommand( context , "insert program '"+files[idx].getPath()+"'" );
            System.out.println("insert program '"+files[idx].getPath()+"'");
        }

    }

 

    public static void importTCLSchema(Context context , File file , FilenameFilter filter) throws Exception{

        File[] files = file.listFiles(filter);
        for(int idx = 0 ; idx < files.length ; idx++) {

            String ret = MqlUtil.mqlCommand( context , "list program '"+files[idx].getName()+"'" );
            System.out.println("ret="+ret);
            if( StringUtils.equals( ret , files[idx].getName() ) == false ){

                System.out.println("add program '"+files[idx].getName()+"' file '"+files[idx].getPath()+"'");
                MqlUtil.mqlCommand( context , "add program '"+files[idx].getName()+"' file '"+files[idx].getPath()+"'" );
            }else{

                System.out.println("mod program '"+files[idx].getName()+"' file '"+files[idx].getPath()+"'");
                MqlUtil.mqlCommand( context , "mod program '"+files[idx].getName()+"' file '"+files[idx].getPath()+"'" );
            }

        }

    }

 

 

    public static void importBusSchema(Context context , File file , FilenameFilter filter) throws Exception {

        System.out.println("file="+file);
        File[] files = file.listFiles(filter);
        System.out.println("files.length="+files.length);
        SAXBuilder sax = new SAXBuilder();
        XMLOutputter outputer = new XMLOutputter();
        for(int idx = 0 ; idx < files.length ; idx++) {

            if( idx > 0 && (idx%10)==0){

                System.out.println(idx+" Processing!");
            }

            Document doc = sax.build(files[idx].getPath());
            Element typeElement = (Element)XPath.selectSingleNode(doc.getRootElement(),"/ematrix//businessObject/objectType");
            Element nameElement = (Element)XPath.selectSingleNode(doc.getRootElement(),"/ematrix//businessObject/objectName");
            Element revisionElement = (Element)XPath.selectSingleNode(doc.getRootElement(),"/ematrix//businessObject/objectRevision");
            System.out.println("files[idx].getPath()="+files[idx].getPath());
            //if( StringUtils.equals( typeElement.getTextTrim() , "Person" )){

            String ret = MqlUtil.mqlCommand( context , "eval expr 'count TRUE' on temp query bus '"+typeElement.getTextTrim()+"' '"+nameElement.getTextTrim()+"' '"+revisionElement.getTextTrim()+"' dump;" );
            if( StringUtils.equals( ret , "0" ) ){

                System.out.println("files[idx].getPath()="+files[idx].getPath());
                MqlUtil.mqlCommand(context, "import bus * * * overwrite from file '"+files[idx].getPath()+"';");
                //break;
            }else{

                String retId = MqlUtil.mqlCommand(context, "print bus '"+typeElement.getTextTrim()+"' '"+nameElement.getTextTrim()+"' '"+revisionElement.getTextTrim()+"' select physicalid logicalid dump;");
                StringList retIds = FrameworkUtil.split( retId , "," );
                Element physicalid = (Element)XPath.selectSingleNode(doc.getRootElement(),"/ematrix//businessObject/physicalid");
                Element logicalid = (Element)XPath.selectSingleNode(doc.getRootElement(),"/ematrix//businessObject/logicalid");
                System.out.println("retIds="+retIds);
                physicalid.setText( (String)retIds.get(0) );
                logicalid.setText( (String)retIds.get(1) );
                FileOutputStream out = new FileOutputStream(new File(files[idx].getPath()));
                outputer.output(doc, out);
                out.close();
                MqlUtil.mqlCommand(context, "import bus '"+typeElement.getTextTrim()+"' '"+nameElement.getTextTrim()+"' '"+revisionElement.getTextTrim()+"' overwrite from file '"+files[idx].getPath()+"';");
            }

            //}else{

            //    MqlUtil.mqlCommand(context, "import bus * * * overwrite from file '"+files[idx].getPath()+"';");
            //}

 

        }

    }

 

    public static void removeSchema(Context context , File file , FilenameFilter filter , String admin) throws Exception {

        try{

            System.out.println("file="+file);
            File[] files = file.listFiles(filter);
            System.out.println("files.length="+files.length);
            SAXBuilder sax = new SAXBuilder();
            for(int idx = 0 ; idx < files.length ; idx++) {

                if( idx > 0 && (idx%100)==0){

                    System.out.println(idx+" Processing!");
                }

                Document doc = sax.build(files[idx].getPath());
                String name = ((Element)XPath.selectSingleNode( doc.getRootElement() , "/ematrix//adminProperties/name" )).getTextTrim();
 

 

                System.out.println("delete "+admin+" '"+name+"';");
                MqlUtil.mqlCommand(context, "delete "+admin+" '"+name+"';");
            }

        }catch(Exception ex){

            ex.printStackTrace();
            throw ex;
        }

    }

    public static void importSchema(Context context , File file , FilenameFilter filter) throws Exception {

        try{

            System.out.println("file="+file);
            File[] files = file.listFiles(filter);
            System.out.println("files.length="+files.length);
            for(int idx = 0 ; idx < files.length ; idx++) {

                if( idx > 0 && (idx%100)==0){

                    System.out.println(idx+" Processing!");
                }

                System.out.println("import admin * overwrite from file '"+files[idx].getPath()+"';");
                MqlUtil.mqlCommand(context, "import admin * overwrite from file '"+files[idx].getPath()+"';");
            }

        }catch(Exception ex){

            ex.printStackTrace();
            throw ex;
        }

    }

 

    public static void modifyWebForm(Context context , String[] argsa) throws Exception{

        try{

            File export = new File(exportBaseDir,"99.Part");
            if( export.exists() ){

                delete(context, export );
            }

            export.mkdir();
 

            File dtd = new File(dtdDir+"ematrixml.dtd");
            copy(dtd,new File(export,"ematrixml.dtd"));
 

            SAXBuilder sax = new SAXBuilder();
            XMLOutputter outputer = new XMLOutputter(Format.getPrettyFormat());
 

            String sMqlRet = MqlUtil.mqlCommand(context, "print type Part  select derivative dump ~;");
            StringList sMqlRetList = FrameworkUtil.split(sMqlRet, "~");
            StringItr sMqlRetItr = new StringItr(sMqlRetList);
            while(sMqlRetItr.next()){

                String type = sMqlRetItr.obj();
                System.out.println("type="+type);
                BusinessType busType = new BusinessType(type, context.getVault());
                busType.open(context,false);
                AttributeTypeList partAttrList = busType.getAttributeTypes(context) ;
                busType.close(context);
 

                //get attribute info

                Map attrMap = FrameworkUtil.toMap( context,partAttrList);
                //System.out.println("attrMap="+attrMap);
 

                type = "type_"+type;
 

                String ret = MqlUtil.mqlCommand(context, "quote on;list form "+type+" select name dump" );
                if( StringUtils.isEmpty(ret)){

                    //System.out.println("not exists!!");
                    continue;
                }

 

 

                String mql = "export form "+type+" xml into file '"+export.getPath()+File.separator+type+ ".xml' ";
                MqlUtil.mqlCommand(context, mql);
 

                Document doc = sax.build(export.getPath()+File.separator+type+ ".xml");
                FileOutputStream out = new FileOutputStream(new File(export.getPath()+File.separator+type+ ".xml"));
                if( isDateRemove ){

                    doc.getRootElement().removeChild("creationProperties");
                    Element element = (Element)XPath.selectSingleNode(doc.getRootElement(),"/ematrix//adminProperties");
                    element.removeChild("creationInfo");
                    element.removeChild("modificationInfo");
                }

                Element fieldListElement = (Element)XPath.selectSingleNode(doc.getRootElement(),"/ematrix//fieldList");
                String count = fieldListElement.getAttributeValue("count");
                int iCount = Integer.parseInt(count, 10);
 

                List fields = fieldListElement.getChildren("field");
                Iterator fieldItr = fields.iterator();
                while(fieldItr.hasNext()){

                    Element ele = (Element)fieldItr.next();
                    String name = ele.getChildText("name");
                    if( attrMap.containsKey(name) == false ){

                        fieldListElement.removeContent(ele);
                        --iCount;
                        fieldItr = fields.iterator();
 

                    } else {

                        Element settingList = ele.getChild("fieldSettingList");
 

                        int iSettingCount = Integer.parseInt(settingList.getAttributeValue("count"), 10);
                        Element fieldSetting1 = (Element)XPath.selectSingleNode(settingList,"fieldSetting[child::fieldSettingName[text()='Label Class'] and child::fieldSettingValue[text()='label']]");
                        Element fieldSetting2 = (Element)XPath.selectSingleNode(settingList,"fieldSetting[child::fieldSettingName[text()='Valid Function'] and child::fieldSettingValue[text()='required']]");
                        Element fieldSetting3 = (Element)XPath.selectSingleNode(settingList,"fieldSetting[child::fieldSettingName[text()='Valid Message']]");
                        Element fieldSetting4 = (Element)XPath.selectSingleNode(settingList,"fieldSetting[child::fieldSettingName[text()='JSValidation']]");
                        if( fieldSetting1 != null && fieldSetting2 != null){

                            settingList.removeContent(fieldSetting2);
                            settingList.removeContent(fieldSetting3);
                            --iSettingCount;
                            --iSettingCount;
 

                            fieldSetting4.getChild("fieldSettingValue").setText("false");
                            settingList.setAttribute("count", iSettingCount+"");
                        }

 

                        settingList = ele.getChild("fieldSettingList");
                        Element fieldSetting5 = (Element)XPath.selectSingleNode(settingList,"fieldSetting[child::fieldSettingName[text()='Label Class'] and child::fieldSettingValue[text()='label']]");
                        Element fieldSetting6 = (Element)XPath.selectSingleNode(settingList,"fieldSetting[child::fieldSettingName[text()='Valid Function'] and child::fieldSettingValue[starts-with(text(),'required|')]]");
                        Element fieldSetting7 = (Element)XPath.selectSingleNode(settingList,"fieldSetting[child::fieldSettingName[text()='JSValidation']]");
                        Element fieldSetting8 = (Element)XPath.selectSingleNode(settingList,"fieldSetting[child::fieldSettingName[text()='Valid Message']]");
                        if( fieldSetting5 != null && fieldSetting6 != null){

                            String validation = fieldSetting6.getChild("fieldSettingValue").getText();
                            String message = fieldSetting8.getChild("fieldSettingValue").getText();
                            StringList validations = FrameworkUtil.split(validation, "|");
                            StringList messages = FrameworkUtil.split(message, "|");
 

                            int idx = validations.indexOf("required");
                            validations.remove(idx);
                            messages.remove(idx);
 

                            fieldSetting6.getChild("fieldSettingValue").setText(FrameworkUtil.join(validations, "|"));
                            fieldSetting8.getChild("fieldSettingValue").setText(FrameworkUtil.join(messages, "|"));
 

                            fieldSetting7.getChild("fieldSettingValue").setText("true");
                        }

 

 

 

                    }

                }

                fieldListElement.setAttribute("count", iCount+"");
                outputer.output(doc, out);
 

                out.close();
 

            }

            /*

                export = new File(exportBaseDir,"99.Part");
                importSchema(context , export , new FilenameFilter() {

                    public boolean accept(File dir, String name) {

                        return name.endsWith(".xml");
                    }

                });*/

        }catch(Exception ex){

            ex.printStackTrace();
            throw ex;
        }

    }

 

 

 

    public static void exportPartTypeXML(Context context , String[] args ) throws Exception{

        File export = new File(exportBaseDir,"Part");
        if( export.exists() && true){

            delete(context, export );
        }

        export.mkdir();
 

        File dtd = new File(dtdDir+"ematrixml.dtd");
        copy(dtd,new File(export,"ematrixml.dtd"));
 

        String system = "";
 

        StringList retList = new StringList();
 

        String ret = MqlUtil.mqlCommand(context, "quote on;print type Part select derivative dump |" );
        retList = FrameworkUtil.split(ret, "|");
        StringItr retItr = new StringItr(retList);
        SAXBuilder sax = new SAXBuilder();
        XMLOutputter outputer = new XMLOutputter(Format.getPrettyFormat());
        while(retItr.next()){

            String obj = retItr.obj();
 

            String mql = "export type '"+obj+"' xml into file '"+export.getPath()+File.separator+FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(obj, ":", "~"), "/", ""), "'", "")+ ".xml' exception '"+exportBaseDir+"exception.log'";
            try{

                String expRet = MqlUtil.mqlCommand(context, mql );
 

                Document doc = sax.build(export.getPath()+File.separator+FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(obj, ":", "~"), "/", ""), "'", "")+ ".xml");
                FileOutputStream out = new FileOutputStream(new File(export.getPath()+File.separator+FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(FrameworkUtil.findAndReplace(obj, ":", "~"), "/", ""), "'", "")+ ".xml"));
                if( isDateRemove ){

                    doc.getRootElement().removeChild("creationProperties");
                    Element element = (Element)XPath.selectSingleNode(doc.getRootElement(),"/ematrix//adminProperties");
                    element.removeChild("creationInfo");
                    element.removeChild("modificationInfo");
                }

                outputer.output(doc, out);
 

            }catch(Exception ex){

                System.out.println("mql="+mql +":");
                ex.printStackTrace();
            }

        }

    }

 

 

    public static void addRoleForAllCommand(Context context , String[] args) throws Exception{

        ContextUtil.startTransaction(context, true);
        try{

            StringBuffer sb = new StringBuffer();
            sb.append("list").append(SPACE).append("command").append(SPACE).append("*").append(SPACE).append(SELECT).append(SPACE).append(NAME).append(SPACE).append("user").append(SPACE).append(DUMP).append(SEMI_COLON);
            String mqlRet = MqlUtil.mqlCommand(context, sb.toString());
            StringList commandList = FrameworkUtil.split(mqlRet, RECORDSEP);
 

            StringItr adminItr = new StringItr(commandList);
            while(adminItr.next()){

                String adminHref = adminItr.obj();
                System.out.println("adminHref="+adminHref);
                if( StringUtils.contains(adminHref, "Backup") ){

                    continue;
                }

                if( StringUtils.contains(adminHref, "backup") ){

                    continue;
                }

                //System.out.println("mod command '"+adminHref+"' add user 'Administration Manager';");
                //MqlUtil.mqlCommand(context, "mod command '"+adminHref+"' add user 'Administration Manager';");
            }

            ContextUtil.commitTransaction(context);
        }catch( Exception ex ){

            ContextUtil.abortTransaction(context);
            ex.printStackTrace();
            throw ex;
        }

    }

 

    /**

    * ECO 

    * 

    * sjiemxCreateProcess.jsp.

    * @param context

    * @param args

    * @return

    * @throws Exception

    */

    public static void autoNameObjectCheck(Context context , String[] args) throws Exception{

        ContextUtil.startTransaction(context, true);
        try{

            /*HashMap programMap = (HashMap)JPO.unpackArgs(args);
            String aliasType = (String)programMap.get("type");
            String txtCarOID = (String)programMap.get("txtCarOID");
            if(StringUtils.isEmpty(txtCarOID)){

                txtCarOID = (String)programMap.get("txtCar");
            }*/

            String aliasType = args[0];
            String txtCarOID = args[1];
            System.out.println("aliasType="+aliasType);
            System.out.println("txtCarOID="+txtCarOID);
 

            DomainObject carBean = DomainObject.newInstance(context, txtCarOID);
            //print bus A A A select exists

            String numberType = PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_type_eServiceNumberGenerator);
            String objectType = PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_type_eServiceObjectGenerator);
            String objectRelationship = PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_relationship_eServiceNumberGenerator);
            String name = aliasType;
            String revision = carBean.getInfo(context, DomainObject.SELECT_DESCRIPTION);
            //AutoNameSeries

            System.out.println("revision="+revision);
 

            String vault = PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_vault_eServiceAdministration);
            MapList list = DomainObject.findObjects(context, numberType, name, StringUtils.trim(revision), "*", vault, null , false, new StringList(DomainObject.SELECT_ID) );
 

            if( list == null || list.size() == 0 ){

 

                MapList policList = mxType.getPolicies(context, numberType, false);
                String policy = (String)( (Map)policList.get(0) ).get("name");
 

                ContextUtil.pushContext(context);
 

                //eService Next Number

                BusinessObject numberBus = mxBus.create(context, numberType , name , revision , policy , vault );
                DomainObject numberObj = DomainObject.newInstance(context , numberBus);
                HashMap numberAttrMap = new HashMap();
 

                String max = MqlUtil.mqlCommand(context, "eval expr 'count TRUE' on temp query bus ECO E"+revision+"* * dump");
 

                if( Integer.parseInt(max,10) > 0 ){

                    String ret1 = MqlUtil.mqlCommand(context, "temp query bus ECO E"+revision+"* * orderby name select name dump;");
                    StringList ret3 = FrameworkUtil.split(ret1, "\n");
                    String last = (String)ret3.get(ret3.size()-1);
                    StringList ret4 = FrameworkUtil.split(last, ",");
                    String ret5 = (String)ret4.get(ret4.size()-1);
                    String max2 = StringUtils.substring(ret5, 3);
                    System.out.println("==========================>max="+max);
                    System.out.println("==========================>max2="+Integer.parseInt(max2,10));
                    if( Integer.parseInt(max2,10) >= Integer.parseInt(max, 10)){

                        max = max2;
                    }

                }

                System.out.println("==========================>Last max2="+Integer.parseInt(max,10));
                NumberFormat nf = NumberFormat.getNumberInstance();
                nf.setMinimumIntegerDigits(4);
                nf.setParseIntegerOnly(true);
                max = nf.format(Long.parseLong(max,10)+1);
                max = FrameworkUtil.findAndReplace(max, ",", "");
 

                numberAttrMap.put( PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_attribute_eServiceNextNumber) , max );
                mxBus.setAttributeValues(context, numberObj, numberAttrMap);
                numberObj.setOwner(context, "creator");
 

 

 

                HashMap objectAttrMap = new HashMap();
                objectAttrMap.put( PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_attribute_eServiceNamePrefix ) , "E"+revision );
                objectAttrMap.put( PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_attribute_eServiceProcessingTimeLimit ) , "60" );
                objectAttrMap.put( PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_attribute_eServiceRetryCount ) , "5" );
                objectAttrMap.put( PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_attribute_eServiceRetryDelay ) , "60" );
                objectAttrMap.put( PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_attribute_eServiceSafetyPolicy ) , "policy_ECO" );
                objectAttrMap.put( PropertyUtil.getSchemaProperty(DomainSymbolicConstants.SYMBOLIC_attribute_eServiceSafetyVault ) , "vault_eServiceAdministration" );
                BusinessObject objectBus = mxBus.create(context, objectType , name , revision , policy , vault );
                DomainObject objectObj = DomainObject.newInstance(context , objectBus);
                mxBus.setAttributeValues(context, objectObj, objectAttrMap);
                objectObj.setOwner(context, "creator");
                DomainRelationship.connect(context, objectObj.getObjectId(context), objectRelationship, numberObj.getObjectId(context), false);
 

                ContextUtil.popContext(context);
            }

            //programMap.put("TypeActual", "type_ECO");
 

            ContextUtil.commitTransaction(context);
        }catch(Exception ex){

 

            ContextUtil.abortTransaction(context);
            ex.printStackTrace();
            throw ex;
        }

    }

    public static void updateECOAutoName(Context context , String[] args) throws Exception{

        ContextUtil.startTransaction(context, true);
        try{

            String retVal = MqlUtil.mqlCommand(context, "temp query bus 'eService Number Generator' type_ECO * select id dump;");
            StringList list1 = FrameworkUtil.split(retVal, "\n");
            StringItr itr1 = new StringItr(list1);
            String[] oid = new String[list1.size()];
            int i = 0;
            while(itr1.next()){

                String val1 = itr1.obj();
                StringList list2 = FrameworkUtil.split(val1, ",");
                System.out.println("1===>> list2.get(2)="+list2.get(2));
                oid[i]=(String)list2.get(list2.size()-1);
                i++;
            }

 

            DomainObject.deleteObjects(context, oid );
 

            retVal = MqlUtil.mqlCommand(context, "temp query bus 'eService Object Generator' type_ECO * select id dump;");
            list1 = FrameworkUtil.split(retVal, "\n");
            itr1 = new StringItr(list1);
            oid = new String[list1.size()];
            i = 0;
            while(itr1.next()){

                String val1 = itr1.obj();
                StringList list2 = FrameworkUtil.split(val1, ",");
                System.out.println("1===>> list2.get(2)="+list2.get(2));
                oid[i]=(String)list2.get(list2.size()-1);
                i++;
            }

 

            DomainObject.deleteObjects(context, oid );
 

 

            String ecoAlias = "type_ECO";
            retVal = MqlUtil.mqlCommand(context, "temp query bus sjiCar * * select id dump;");
            StringList retValList = FrameworkUtil.split(retVal, "\n");
            StringItr retItr = new StringItr(retValList);
            while( retItr.next() ){

                String codeId = retItr.obj();
                StringList codeIds = FrameworkUtil.split(codeId, ",");
                autoNameObjectCheck(context, new String[]{ecoAlias,(String)codeIds.get(codeIds.size()-1)} );
            }

 

 

 

            ContextUtil.commitTransaction(context);
        }catch(Exception ex){

            ex.printStackTrace();
            ContextUtil.abortTransaction(context);
 

        }

 

    }

 

    /**

    * 

    * @author jeong myeon, Ahn

    * @since 2011.05.10

    * @param context

    * @param args <pre>args[0] : from or to (string)<p/>args[1] : objectId<p/>args[2] : relationship name<p/>args[3] : target ObjectId</pre>

    * @throws Exception

    */

    public static void connectObject(Context context, String[] args) throws Exception {

        try {

            System.out.println("==================================================");
            System.out.println("connectObject start");
            if( args.length < 4 )

                throw new Exception("Checked arguments");
 

            if( !"from".equals(args[0]) && !"to".equals(args[0]) )

                throw new Exception("Selected connect type : ex] from or to");
 

            DomainObject domainObject = DomainObject.newInstance(context);
            domainObject.setId(args[1]);
 

            if( "from".equals(args[0]) ){

                domainObject.addFromObject(context, new RelationshipType(args[2]), args[3]);
            } else {

                domainObject.addToObject(context, new RelationshipType(args[2]), args[3]);
            }

            System.out.println("connectObject end");
            System.out.println("==================================================");
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

 

    public static void disconnectObject(Context context, String[] args) {

        try {

            String fromObjectId = args[0];
            String toObjectId   = args[1];
            String relationshipName = args[2];
 

            BusinessObject fromObj = new BusinessObject( fromObjectId );
            BusinessObject toObj = new BusinessObject( toObjectId );
 

            if( isAlreadyConnected( context, fromObj, toObj, relationshipName ) ) {

                RelationshipType relationshipType = new RelationshipType( relationshipName );
 

                toObj.open( context );
                fromObj.open( context );
                try {

                    fromObj.disconnect( context, relationshipType, true, toObj );
                    fromObj.update( context );
                } catch( Exception e ) {

                    e.printStackTrace();
                    throw e;
                } finally {

                    fromObj.unlock( context );
                    fromObj.close( context );
                    toObj.close( context );
                }

            }

            // DomainRelationship.disconnect(context, args[0]);
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

 

    public static boolean isAlreadyConnected( Context context, BusinessObject source,

            BusinessObject target, String relationshipTypeName ) throws Exception {

 

        target.open( context );
        RelationshipList targetRelationList = target.getToRelationship( context );
        target.close( context );
 

        RelationshipItr targetRelationItr = new RelationshipItr( targetRelationList );
        while( targetRelationItr.next() ) {

            Relationship relation = targetRelationItr.obj();
            String typeName = relation.getTypeName();
            if( !typeName.equals( relationshipTypeName ) ) {

                continue;
            }

            BusinessObject otherSideObj = relation.getFrom();
            source.open( context );
            if( source.equals( otherSideObj ) ) {

                return true;
            }

            source.close( context );
        }

        return false;
    }

 

    public static void loadTable(Context pContext, String pString) {

 

        try {

            System.out.println("pString : " + pString);
            if( StringUtils.contains(pString, ".mql") )

                pString = StringUtils.remove(pString, ".mql");
 

            String sPrintTableCommand = new StringBuilder("print table \"").append(pString).append("\" system").toString();
            System.out.println("sPrintTableCommand : " + sPrintTableCommand);
            MQLCommand localMQLCommand = new MQLCommand();
 

            localMQLCommand.executeCommand(pContext, sPrintTableCommand);
            String str1 = localMQLCommand.getResult();
 

            System.out.println(str1);
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

 

    String getMapData(Map map, String key) {

        Object object = map.get(key);
        if( object instanceof String )

            return (String) object;
        else if ( object instanceof String[] ) {

            return ((String[])object)[0];
        } else {

            return null;
        }

    }

 

    public void SearchDialogMethod(Context context, String[] args) throws Exception

    {

        HashMap parameterMap = (HashMap) JPO.unpackArgs(args);
 

        ContextUtil.startTransaction(context, true);
        try {

            String username = getMapData(parameterMap, "username");
            String password = getMapData(parameterMap, "password");
 

            if( StringUtils.isNotEmpty(username) )

            {

                ContextUtil.pushContext(context, username, password, "");
            } else {

                ContextUtil.pushContext(context, PropertyUtil.getSchemaProperty(context, "person_UserAgent"), DomainConstants.EMPTY_STRING, DomainConstants.EMPTY_STRING);
                //ContextUtil.pushContext(context);
            }

 

            String promote_btn = getMapData(parameterMap, "promote_btn");
 

            if( StringUtils.isNotEmpty(promote_btn) )

            {

                String sPromoteObjectId = getMapData((Map)parameterMap, "PromoteObjectId");
 

                if( StringUtils.isNotEmpty(sPromoteObjectId) )

                {

                    DomainObject domainObject = DomainObject.newInstance(context);
                    domainObject.setId(sPromoteObjectId);
 

                    domainObject.promote(context);
                }

            }

 

            String search_btn = getMapData(parameterMap, "search_btn");
 

            if( StringUtils.isNotEmpty(search_btn) )

            {

                String sType  = getMapData(parameterMap, "object_type");
                String sName  = getMapData(parameterMap, "object_name");
                String sRev   = getMapData(parameterMap, "object_revision");
                String sOwner = getMapData(parameterMap, "object_owner");
                String sWhere = getMapData(parameterMap, "object_where");
                String sOriginatedFrom = getMapData(parameterMap, "originated_from");
                String sOriginatedTo = getMapData(parameterMap, "originated_to");
 

                if( StringUtils.isNotEmpty(sType) ||

                        StringUtils.isNotEmpty(sName) ||

                        StringUtils.isNotEmpty(sRev)

                        )

                {

                    StringList busSelect = new StringList();
                    busSelect.add(DomainObject.SELECT_ID);
                    busSelect.add(DomainObject.SELECT_TYPE);
                    busSelect.add(DomainObject.SELECT_NAME);
                    busSelect.add(DomainObject.SELECT_REVISION);
                    busSelect.add(DomainObject.SELECT_CURRENT);
                    busSelect.add(DomainObject.SELECT_OWNER);
 

                    StringBuffer sbWhere = new StringBuffer();
 

                    StringList slWhere = new StringList();
 

                    if( !"*".equals(sName) && StringUtils.isNotEmpty(sName) )

                    {

                        slWhere.add("name==\""+sName+"\"");
                        //                                                      sbWhere.append("name=='").append(sName).append("'");
                    }

 

                    if( !"*".equals(sRev) && StringUtils.isNotEmpty(sRev) )

                    {

                        slWhere.add("revision==\""+sRev+"\"");
                    }

                    StringBuffer sbWhereExp = new StringBuffer();
 
// yunsik.seo modify
//                    MatrixSearchUtil.setBusWhereClause(context, sbWhereExp, "name", sName, true);
//                    MatrixSearchUtil.setBusWhereClause(context, sbWhereExp, "revision", sRev, true);
 

                    //MatrixSearchUtil.setDateWhereClause(context, sbWhereExp, "Originated", sOriginatedFrom, sOriginatedTo, context.getSession().getTimezone());
 

 

                    System.out.println("sbWhereExp : " + sbWhereExp);
 

                    if( slWhere.size() > 0 )

                    {

                        sbWhere.append("( ").append(StringUtils.join(slWhere," && ")).append(")");
                    }

 

                    MapList objList = DomainObject.findObjects(context,

                            sType,                                 // type

                            DomainObject.QUERY_WILDCARD,                     // name

                            DomainObject.QUERY_WILDCARD,                     // rev

                            sOwner,                               // owner

                            DomainObject.QUERY_WILDCARD,           // vault

                            sbWhereExp.toString(), // where

                            false,                                   // expand

                            busSelect);                            // selectbus

 

                }

            }

 

            String delete_btn = getMapData(parameterMap, "delete_btn");
 

            if( StringUtils.isNotEmpty(delete_btn) )

            {

                String deleteVPLMObjectId = getMapData(parameterMap, "delete_vplm");
 

                if( StringUtils.isNotEmpty(deleteVPLMObjectId) )

                {

                    //deleteVPLMObject(context, new String[]{deleteVPLMObjectId});
                }

            }

 

            String runmql_btn = getMapData(parameterMap, "mql_btn");
 

            if( StringUtils.isNotEmpty(runmql_btn) )

            {

                String sMql = getMapData(parameterMap, "run_mql");
 

                if( StringUtils.isNotEmpty(sMql) )

                {

                    String sMqlResult = MqlUtil.mqlCommand(context, sMql);
 

                    System.out.println("sMqlResult : " + sMqlResult);
 

                    String sFileSave = getMapData(parameterMap, "mql_file_save");
 

                    if( StringUtils.isNotEmpty(sFileSave) )

                    {

                        String sSaveFilePath = getMapData(parameterMap, "save_file_path");
                        String paramFileName = sSaveFilePath;
                        if( StringUtils.isNotEmpty(sSaveFilePath) )

                        {

                            sSaveFilePath = StringUtils.replace(sSaveFilePath, "\\", "/");
                            sSaveFilePath += ".txt";
                            sSaveFilePath = "d:/"+sSaveFilePath;
                            File file = new File(sSaveFilePath);
                            if( !file.exists() )

                            {

                                file.createNewFile();
                            }

                            else

                            {

                                String backupFileName = "d:/"+paramFileName+"_"+ new SimpleDateFormat("yyyyMMdd_hhmmss").format(new Date())+".txt";
                                FileInputStream inputStream = null;
                                FileOutputStream outputStream = null;
                                FileChannel fcin = null;
                                FileChannel fcout = null;
                                try {

                                    inputStream = new FileInputStream(file);
                                    outputStream = new FileOutputStream(backupFileName);
 

                                    fcin = inputStream.getChannel();
                                    fcout = outputStream.getChannel();
 

                                    long size = fcin.size();
                                    fcin.transferTo(0, size, fcout);
                                } catch (Exception e) {

                                    throw e;
                                } finally {

                                    fcout.close();
                                    fcin.close();
                                    outputStream.close();
                                    inputStream.close();
                                }

                                System.out.println("file: " + file.getName());
                            }

 

                            BufferedWriter out = new BufferedWriter(new FileWriter(file, false));
 

                            String[] strs = StringUtils.split(sMqlResult, "\n");
                            for(String st : strs)

                            {

                                out.write(st);
                                out.newLine();
                            }

                            out.close();
                        }

                    }

                }

            }

 

            String search_command = getMapData(parameterMap, "search_command");
            if( StringUtils.isNotEmpty(search_command) )

            {

                String command_href = getMapData(parameterMap, "search_command_href");
 

                String listCommandMql = "list command select name href dump |";
 

                String rslistCommandMql = MqlUtil.mqlCommand(context, listCommandMql);
 

                StringList cmdList = FrameworkUtil.split(rslistCommandMql, "\n");
 

                System.out.println(command_href);
                for (Iterator cmdItr = cmdList.iterator(); cmdItr.hasNext();) {

                    String sCmd = (String) cmdItr.next();
                    String[] cmdD = StringUtils.split(sCmd, "|");
                    String sCmdName = cmdD[0];
                    if( cmdD.length > 1 )

                    {

                        String sCmdHref = cmdD[1];
 

                        if( StringUtils.contains(sCmdHref, command_href) )

                        {

                            System.out.println(sCmdName);
                        }

                    }

                }

            }

 

            String search_symbolic = getMapData(parameterMap, "search_symbolic");
            if( StringUtils.isNotEmpty(search_symbolic) )

            {

                String symbolic_type = getMapData(parameterMap, "search_symbolic_type");
                String symbolic_name = getMapData(parameterMap, "search_symbolic_name");
 

                String sMql = "list property on program eServiceSchemaVariableMapping.tcl to "+symbolic_type+" "+symbolic_name;
 

                String rsMql = MqlUtil.mqlCommand(context, sMql);
 

                System.out.println(rsMql);
            }

 

            ContextUtil.commitTransaction(context);
        } catch (Exception e) {

            ContextUtil.abortTransaction(context);
        } finally {

            ContextUtil.popContext(context);
        }

    }

 

    public static void autoName(Context context, String[] pString) {

 System.out.println("emxSchemaUtil_mxJPO.autoName()");

        try {

            //            String newObjectId = FrameworkUtil.autoName( context , "type_Part" , "WPE5" , "EC Part" ,"eService Production",null,false,false );
            String newObjectId = FrameworkUtil.autoName( context , "type_ECO" , "" , "policy_ECO" ,"eService Production",null);
            System.out.println("newObjectId="+newObjectId);
        } catch (Exception e) {

            e.printStackTrace();
        }

    }

 

 

    //set context person creator;start trans; exec program emxSchemaUtil -method importSchema;abort trans;quit;
    //set context person creator; exec program emxSchemaUtil -method importSchema;quit;
    public static void importSchema(Context context , String[] args) throws Exception {

        try

        {

            ContextUtil.startTransaction( context , true );
            Date todayDate = new Date();
            todayDate.setMonth( 5 );
            todayDate.setDate( 27 );
 

            SimpleDateFormat mxDateFrmt = new SimpleDateFormat("yyyy-MM-dd",Locale.KOREA);
            String dateStr = mxDateFrmt.format(todayDate);
 

            File export = new File(exportBaseDir,dateStr+File.separator+"01.attribute");
            System.out.println("export.getPath()="+export.getPath());
            Calendar toDaycal = new GregorianCalendar();
            toDaycal.clear();
            toDaycal.set( 2011 , Calendar.MARCH , 15 , 00 , 00 , 00 );
            System.out.println(DatatypeConverter.printDateTime( toDaycal ) );
 

            FilenameFilter fileNameFilter = new FilenameFilter() {

                public boolean accept(File dir, String name) {

                    //                return name.endsWith(".xml")&&name.startsWith( "shi" );
                    return name.endsWith(".xml")&&!name.startsWith( "SAP" )&&!name.startsWith( "VPLM" );
                }

            };
 

            importSchemaAdd(context , export , fileNameFilter , toDaycal , "attribute" );
            importSchemaModify(context , export , fileNameFilter , toDaycal , "attribute" );
        }catch (Exception ex){

            ex.printStackTrace();
            ContextUtil.abortTransaction( context );
            throw ex;
        }finally{

            //ContextUtil.commitTransaction( context );
            ContextUtil.abortTransaction( context );
        }

    }

 

    public static void importMenuAdd(Context context , File file , FilenameFilter filter, Calendar toDaycal , String admin) throws Exception {

        try{

 

            File[] files = file.listFiles(filter);
            SAXBuilder sax = new SAXBuilder();
            XMLOutputter outputer = new XMLOutputter(Format.getPrettyFormat());
            for(int idx = 0 ; idx < files.length ; idx++) {

                if( idx > 0 && (idx%100)==0){

                    System.out.println(idx+" Processing!");
                }

 

                //MqlUtil.mqlCommand(context, "import admin * overwrite from file '"+files[idx].getPath()+"';");
                Document doc = sax.build(files[idx].getPath());
                String name = ((Element)XPath.selectSingleNode( doc.getRootElement() , "/ematrix//adminProperties/name" )).getTextTrim();
                String menuName = MqlUtil.mqlCommand( context , "list menu '" + name +"'" );
                if( StringUtils.isEmpty( menuName ) ){

                    MqlUtil.mqlCommand( context , "add menu '" + name +"'");
                }

            }

        }catch(Exception ex){

            ex.printStackTrace();
            throw ex;
        }

    }

 

    public static void importSchemaAdd(Context context , File file , FilenameFilter filter, Calendar toDaycal , String admin) throws Exception {

        try{

 

            File[] files = file.listFiles(filter);
            SAXBuilder sax = new SAXBuilder();
            XMLOutputter outputer = new XMLOutputter(Format.getPrettyFormat());
            for(int idx = 0 ; idx < files.length ; idx++) {

                if( idx > 0 && (idx%100)==0){

                    System.out.println(idx+" Processing!");
                }

 

                //MqlUtil.mqlCommand(context, "import admin * overwrite from file '"+files[idx].getPath()+"';");
                Document doc = sax.build(files[idx].getPath());
                System.out.println("files[idx].getPath()="+files[idx].getPath());
                String name = ((Element)XPath.selectSingleNode( doc.getRootElement() , "/ematrix//adminProperties/name" )).getTextTrim();
                System.out.println("name="+name);
                if( StringUtils.equals( admin , "person" ) && !StringUtils.equals( name , "swjeon" )){

                    MqlUtil.mqlCommand( context , "import person '"+name+"' overwrite from file '"+files[idx].getPath()+"'" );
                    continue;
                }

                boolean isModify = false;
                boolean isError = false;
                ArrayList<Element> historyList = (ArrayList<Element>)XPath.selectNodes(doc.getRootElement(),"/ematrix//historyList/history");
                for( int jdx = 0 ; jdx < historyList.size() ; jdx++ ){

                    Element element = historyList.get( jdx );
                    Calendar cal = new GregorianCalendar();
                    Element dateTimeElement = (Element)XPath.selectSingleNode( element , "datetime" );
                    Element orderEl = (Element)XPath.selectSingleNode( element , "order" );
                    Element mqlEl = (Element)XPath.selectSingleNode( element , "string" );
                    Element eventEl = (Element)XPath.selectSingleNode( element , "event" );
                    Element agentEl = (Element)XPath.selectSingleNode( element , "agent" );
 

                    if( StringUtils.equals( eventEl.getTextTrim() , "create" ) ){

                        cal.setTime(DatatypeConverter.parseDate( dateTimeElement.getTextTrim() ).getTime());
 

                        //                    System.out.print(DatatypeConverter.printDateTime( cal ) );
                        //                    System.out.print(" ");
                        //                    System.out.print(DatatypeConverter.printDateTime( toDaycal ) );
                        //                    System.out.print(" ");
                        //                    System.out.println("after==>"+cal.after( toDaycal ));
 

                        if( cal.after( toDaycal ) ){

 

                            if( StringUtils.equals( admin , "policy" )){

                                String ret = MqlUtil.mqlCommand( context , "eval expr 'count TRUE' on temp query bus * * * vault '"+name+"' dump;" );
                                if( StringUtils.equals( ret , "0" ) ){

                                    MqlUtil.mqlCommand( context , "import policy '"+name+"' overwrite from file '"+files[idx].getPath()+"'" );
                                    break;
                                }

                            }

 

                            String mql = mqlEl.getTextTrim();
                            mql = FrameworkUtil.findAndReplace( mql , "add range != ;" , "add range != '' ;" );
                            mql = FrameworkUtil.findAndReplace( mql , "add range = ;" , "add range = '' ;" );
                            mql = FrameworkUtil.findAndReplace( mql , "add range != remove" , "add range != '' remove" );
                            mql = FrameworkUtil.findAndReplace( mql , "remove range != ;" , "remove range != '' ;" );
                            mql = FrameworkUtil.findAndReplace( mql , "remove range = ;" , "remove range = '' ;" );
                            mql = FrameworkUtil.findAndReplace( mql , "remove range = remove " , "remove range = '' remove " );
                            mql = FrameworkUtil.findAndReplace( mql , "Working Create version" , "Working version" );
                            mql = FrameworkUtil.findAndReplace( mql , " \"Stand by CRB\" Create version" , " \"Stand by CRB\" version" );
                            mql = FrameworkUtil.findAndReplace( mql , "\"CRB Reviewing\" Create version" , "\"CRB Reviewing\" version" );
                            mql = FrameworkUtil.findAndReplace( mql , "\"Document Family\"" , "\"Document Library\"" );
                            mql = FrameworkUtil.findAndReplace( mql , "Confirmed Create version" , "Confirmed version" );
                            mql = FrameworkUtil.findAndReplace( mql , "\"Line Manager Approving\" Create version" , "\"Line Manager Approving\" version" );
                            mql = FrameworkUtil.findAndReplace( mql , "\"Part Manager Approving\" Create version" , "\"Part Manager Approving\" version" );
                            mql = FrameworkUtil.findAndReplace( mql , "\"Team Manager Approving\" Create version" , "\"Team Manager Approving\" version" );
                            StringList mqls = FrameworkUtil.split( mql , ";" );
                            for( int kdx = 0 ; kdx < mqls.size() ; kdx++ ){

                                try{

                                    if( StringUtils.isNotEmpty( (String)mqls.get(kdx) )){

                                        System.out.println("(String)mqls.get(kdx="+(String)mqls.get(kdx));
                                        MqlUtil.mqlCommand( context , (String)mqls.get(kdx) );
                                    }

                                }catch(Exception ex){

                                    ex.printStackTrace();
                                    isError = true;
                                    break;
                                }

                            }

                            isModify = true;
                        }else{

                            //                        System.out.println("\n\nBEFORE");
                            //                        System.out.println("orderEl.getTextTrim()="+orderEl.getTextTrim());
                            //                        System.out.println("mqlEl.getTextTrim()="+mqlEl.getTextTrim());
                            //                        System.out.println("eventEl.getTextTrim()="+eventEl.getTextTrim());
                        }

                    }

                    if( isError == true){

                        MqlUtil.mqlCommand( context , "import admin '"+name+"' overwrite from file '"+files[idx].getPath()+"'" );
                        break;
                    }

                }

            }

        }catch(Exception ex){

            ex.printStackTrace();
            throw ex;
        }

    }

 

 

 

    public static void importSchemaModify(Context context , File file , FilenameFilter filter, Calendar toDaycal , String admin) throws Exception {

        try{

 

            File[] files = file.listFiles(filter);
            SAXBuilder sax = new SAXBuilder();
            XMLOutputter outputer = new XMLOutputter(Format.getPrettyFormat());
            for(int idx = 0 ; idx < files.length ; idx++) {

                if( idx > 0 && (idx%100)==0){

                    System.out.println(idx+" Processing!");
                }

 

                //MqlUtil.mqlCommand(context, "import admin * overwrite from file '"+files[idx].getPath()+"';");
                Document doc = sax.build(files[idx].getPath());
                String name = ((Element)XPath.selectSingleNode( doc.getRootElement() , "/ematrix//adminProperties/name" )).getTextTrim();
                if ( StringUtils.equals( name , "shiDocument" ) || StringUtils.equals( name , "Drawing Print" ) || StringUtils.equals( name , "shiPartSpecification" ) ){

                    MqlUtil.mqlCommand( context , "import "+admin+" '"+name+"' overwrite from file '"+files[idx].getPath()+"'" );
                    continue;
                }

                if( StringUtils.equals( admin , "person" ) && !StringUtils.equals( name , "swjeon" )){

                    MqlUtil.mqlCommand( context , "import person '"+name+"' overwrite from file '"+files[idx].getPath()+"'" );
                    continue;
                }

                boolean isModify = false;
                boolean isError = false;
                ArrayList<Element> historyList = (ArrayList<Element>)XPath.selectNodes(doc.getRootElement(),"/ematrix//historyList/history");
                for( int jdx = 0 ; jdx < historyList.size() ; jdx++ ){

                    Element element = historyList.get( jdx );
                    Calendar cal = new GregorianCalendar();
                    Element dateTimeElement = (Element)XPath.selectSingleNode( element , "datetime" );
                    Element orderEl = (Element)XPath.selectSingleNode( element , "order" );
                    Element mqlEl = (Element)XPath.selectSingleNode( element , "string" );
                    Element eventEl = (Element)XPath.selectSingleNode( element , "event" );
                    Element agentEl = (Element)XPath.selectSingleNode( element , "agent" );
 

                    if( StringUtils.equals( eventEl.getTextTrim() , "create" ) == false ){

                        cal.setTime(DatatypeConverter.parseDate( dateTimeElement.getTextTrim() ).getTime());
 

                        //                    System.out.print(DatatypeConverter.printDateTime( cal ) );
                        //                    System.out.print(" ");
                        //                    System.out.print(DatatypeConverter.printDateTime( toDaycal ) );
                        //                    System.out.print(" ");
                        //                    System.out.println("after==>"+cal.after( toDaycal ));
 

                        if( cal.after( toDaycal ) ){

                            if( StringUtils.equals( admin , "policy" )){

                                String ret = MqlUtil.mqlCommand( context , "eval expr 'count TRUE' on temp query bus '"+name+"' * * dump;" );
                                if( StringUtils.equals( ret , "0" ) ){

                                    MqlUtil.mqlCommand( context , "import policy '"+name+"' overwrite from file '"+files[idx].getPath()+"'" );
                                    break;
                                }

                            }

 

                            String mql = mqlEl.getTextTrim();
                            mql = FrameworkUtil.findAndReplace( mql , "add range != ;" , "add range != '' ;" );
                            mql = FrameworkUtil.findAndReplace( mql , "add range = ;" , "add range = '' ;" );
                            mql = FrameworkUtil.findAndReplace( mql , "add range != remove" , "add range != '' remove" );
                            mql = FrameworkUtil.findAndReplace( mql , "remove range != ;" , "remove range != '' ;" );
                            mql = FrameworkUtil.findAndReplace( mql , "remove range = ;" , "remove range = '' ;" );
                            mql = FrameworkUtil.findAndReplace( mql , "remove range = remove " , "remove range = '' remove " );
                            mql = FrameworkUtil.findAndReplace( mql , "Working Create version" , "Working version" );
                            mql = FrameworkUtil.findAndReplace( mql , " \"Stand by CRB\" Create version" , " \"Stand by CRB\" version" );
                            mql = FrameworkUtil.findAndReplace( mql , "\"CRB Reviewing\" Create version" , "\"CRB Reviewing\" version" );
                            mql = FrameworkUtil.findAndReplace( mql , "\"Document Family\"" , "\"Document Library\"" );
                            mql = FrameworkUtil.findAndReplace( mql , "Confirmed Create version" , "Confirmed version" );
                            mql = FrameworkUtil.findAndReplace( mql , "\"Line Manager Approving\" Create version" , "\"Line Manager Approving\" version" );
                            mql = FrameworkUtil.findAndReplace( mql , "\"Part Manager Approving\" Create version" , "\"Part Manager Approving\" version" );
                            mql = FrameworkUtil.findAndReplace( mql , "\"Team Manager Approving\" Create version" , "\"Team Manager Approving\" version" );
                            mql = FrameworkUtil.findAndReplace( mql , "notpasswordneverexpires" , "notneverexpires" );
                            mql = FrameworkUtil.findAndReplace( mql , "ctx::Local Administrator.Supplier1.Engineerin" , "ctx::Local Administrator.Supplier1.Engineering" );
                            mql = FrameworkUtil.findAndReplace( mql , "ctx::Local Administrator.Supplier1.Engineeringg" , "ctx::Local Administrator.Supplier1.Engineering" );
                            StringList mqls = FrameworkUtil.split( mql , ";" );
                            for( int kdx = 0 ; kdx < mqls.size() ; kdx++ ){

                                System.out.println("(String)mqls.get(kdx="+(String)mqls.get(kdx));
                                if( StringUtils.equals( (String)mqls.get(kdx) , "modify person \"swjeon\" property \"preference_CaseSensitive\" value \"true\"" )){

                                    continue;
                                }

                                try{

                                    if( StringUtils.isNotEmpty( (String)mqls.get(kdx) )){

                                        System.out.println("(String)mqls.get(kdx="+(String)mqls.get(kdx));
                                        MqlUtil.mqlCommand( context , (String)mqls.get(kdx) );
                                    }

                                }catch(Exception ex){

                                    ex.printStackTrace();
                                    isError = true;
                                    break;
                                }

                            }

                            isModify = true;
                        }else{

                            //                        System.out.println("\n\nBEFORE");
                            //                        System.out.println("orderEl.getTextTrim()="+orderEl.getTextTrim());
                            //                        System.out.println("mqlEl.getTextTrim()="+mqlEl.getTextTrim());
                            //                        System.out.println("eventEl.getTextTrim()="+eventEl.getTextTrim());
                        }

                    }

                    if( isError == true){

                        System.out.println("import admin '"+name+"' overwrite from file '"+files[idx].getPath()+"'");
                        MqlUtil.mqlCommand( context , "import admin '"+name+"' overwrite from file '"+files[idx].getPath()+"'" );
                        break;
                    }

                }

            }

        }catch(Exception ex){

            ex.printStackTrace();
            throw ex;
        }

    }

 

 

    public static void updateObjectData(Context context , String[] args) throws Exception{

        ContextUtil.startTransaction(context, true);
        try{

            String retVal = MqlUtil.mqlCommand(context, "temp query bus 'Part' * * where owner==ihseo||owner==swjeon select id dump;");
            StringList list1 = FrameworkUtil.split(retVal, "\n");
            StringItr itr1 = new StringItr(list1);
            int i = 0;
            MqlUtil.mqlCommand(context, "trigger off");
            while(itr1.next()){

                String val1 = itr1.obj();
                StringList list2 = FrameworkUtil.split(val1, ",");
 

                MqlUtil.mqlCommand(context, "mod bus '"+list2.get(3)+"' owner 273208");
                i++;
            }

            MqlUtil.mqlCommand(context, "trigger on");
            ContextUtil.commitTransaction(context);
        }catch(Exception ex){

            ex.printStackTrace();
            ContextUtil.abortTransaction(context);
 

        }

    }

 

    //verbos on;set context person creator;insert program 'D:\Dev\shi\JPO\${CLASSNAME}.java';execute program emxSchemaUtil -method compareSchemaAll;quit;
    public static void compareSchemaAll(Context context , String[] args ) throws Exception{

        try

        {

            FilenameFilter fileNameFilter = new FilenameFilter() {

                public boolean accept(File dir, String name) {

                    return name.endsWith(".xml");
                }

            };
 

            Date todayDate = new Date();
            todayDate.setMonth( 6 );
            todayDate.setDate( 28 );
 

            SimpleDateFormat mxDateFrmt = new SimpleDateFormat("yyyy-MM-dd",Locale.KOREA);
            String dateStr = mxDateFrmt.format(todayDate);
 

 

 

            File export = new File(exportBaseDir,dateStr+File.separator+"01.attribute");
            compareSchema(context , export , fileNameFilter , "attribute" );
 

            export = new File(exportBaseDir,dateStr+File.separator+"02.type");
            compareSchema(context , export , fileNameFilter , "type" );
 

            export = new File(exportBaseDir,dateStr+File.separator+"03.interface");
            compareSchema(context , export , fileNameFilter , "interface" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"04.relationship");
            compareSchema(context , export , fileNameFilter , "relationship" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"05.policy");
            compareSchema(context , export , fileNameFilter , "policy" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"06.command");
            compareSchema(context , export , fileNameFilter , "command" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"07.menu");
            compareSchema(context , export , fileNameFilter , "menu" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"08.webform");
            compareSchema(context , export , fileNameFilter , "form" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"09.table");
            compareSchema(context , export , fileNameFilter , "table" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"10.inquiry");
            compareSchema(context , export , fileNameFilter , "inquiry" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"11.channel");
            compareSchema(context , export , fileNameFilter , "channel" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"16.portal");
            compareSchema(context , export , fileNameFilter , "portal" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"20.role");
            compareSchema(context , export , fileNameFilter , "role" );
 

 

            export = new File(exportBaseDir,dateStr+File.separator+"21.association");
            compareSchema(context , export , fileNameFilter , "association" );
 

 

 

        }

        catch( Exception e )

        {

            e.printStackTrace();
            throw e;
        }

    }

 

 

 

    public static void compareSchema(Context context , File file , FilenameFilter filter, String admin) throws Exception {

        try

        {

            File[] files = file.listFiles(filter);
            SAXBuilder sax = new SAXBuilder();
            XMLOutputter outputer = new XMLOutputter(Format.getPrettyFormat());
            for(int idx = 0 ; idx < files.length ; idx++) {

                if( idx > 0 && (idx%100)==0){

                    System.out.println(idx+" Processing!");
                }

 

                //MqlUtil.mqlCommand(context, "import admin * overwrite from file '"+files[idx].getPath()+"';");
 

                Document doc = sax.build(files[idx].getPath());
                String name = ((Element)XPath.selectSingleNode( doc.getRootElement() , "/ematrix//adminProperties/name" )).getTextTrim();
 

                String ret = MqlUtil.mqlCommand( context , "compare "+admin+" '"+name+"' from file '"+files[idx].getPath()+"' use log '"+file.getParent()+File.separator+"log"+File.separator+name+".log'" );
                //System.out.println("=============================================================================================");
                //System.out.println("compare "+admin+" '"+name+"' from file '"+files[idx].getPath()+"' use log '"+file.getParent()+File.separator+"log"+File.separator+name+".log'");
                //System.out.println("ret="+ret);
 

                File logFile = new File(file.getParent()+File.separator+"log"+File.separator+name+".log");
                RandomAccessFile raf = new RandomAccessFile(logFile,"rw");
                String line = null;
                StringBuffer sbLine = new StringBuffer();
                boolean isFind = false;
                while((line = raf.readLine()) != null){

 

 

                    if(  StringUtils.equals( line , "=====================================================" ) ) {

                        if( isFind == false ){

                            isFind = true;
                        }else{

                            isFind = false;
                        }

                    }

 

                    if( isFind ){

                        sbLine.append( line ).append( "\n" );
                    }

                }

 

                logFile = new File(file.getParent()+File.separator+"log"+File.separator+"total.log");
                input(logFile,sbLine.toString(),"else");
                // new = , old = , else = 

 

                //System.out.println();
                //System.out.println();
            }

        }

        catch( Exception e )

        {

            e.printStackTrace();
            throw e;
        }

    }

 

    static void input(File file,String str,String mode) {

 

        int fileLen = fileLength(file);
        String fileOut = output(file);
        try

        {

            BufferedWriter buffWrite = new BufferedWriter(new FileWriter(file));
            if (mode.equals("new"))

            {

                buffWrite.write(str,0,str.length());
                buffWrite.flush();
            }else if(mode.equals("old")) {

                str = fileOut + str;
                buffWrite.write(str,0,str.length());
                buffWrite.flush();
            }else if(mode.equals("else")) {

                str = fileOut + "\n" + str;
                buffWrite.write(str,0,str.length());
                buffWrite.flush();
            }else {

                buffWrite.write(fileOut,0,fileLen);
                if (fileLen != 0) {

                    buffWrite.newLine();
                }

                buffWrite.write(str,0,str.length());
                buffWrite.flush();
            }           buffWrite.close();
        }

        catch (Exception e)

        {

            System.out.println(e);
        }

    }

    static int fileLength(File file) {

        int b,count = 0;
        try

        {

            BufferedReader buffRead = new BufferedReader(new FileReader(file));
            while ((b = buffRead.read()) != -1) {

                count++;
            }           buffRead.close();
        }

        catch (Exception e)

        {

            System.out.println(e);
        }

        return count;
    }

    static String output(File file) {

        int b;
        String fileContent = "";
        try

        {

            BufferedReader buffRead = new BufferedReader(new FileReader(file));
 

            while ((b = buffRead.read()) != -1) {

                fileContent += (char)b;
            }               buffRead.close();
        }

        catch (Exception e)

        {

            System.out.println(e);
        }

        return fileContent;
    }

 

    public static void numberGeneratorInit(Context context , String[] args) throws Exception{

        try

        {

            String ret1 = MqlUtil.mqlCommand( context , "temp query bus 'eService Number Generator' type_ECO *  select id attribute.value dump;" );
            StringList ret1s = FrameworkUtil.split( ret1 , "\n" );
            for( int idx = 0 ; idx < ret1s.size() ; idx++ ){

                String ret2 = (String)ret1s.get( idx );
                StringList ret2s = FrameworkUtil.split( ret2 , "," );
                //System.out.println("ret2s[3]="+ret2s.get(3));
                String next = (String)ret2s.get(4);
                String newNext = "0";
                for( int jdx=2 ; jdx < next.length() ; jdx++ ){

                    newNext = newNext + "0";
                }

                MqlUtil.mqlCommand( context , "mod bus '"+ret2s.get(0)+"' '"+ret2s.get(1)+"' '"+ret2s.get(2)+"' 'eService Next Number' "+newNext+"1 ;");
                System.out.println("mod bus '"+ret2s.get(0)+"' '"+ret2s.get(1)+"' '"+ret2s.get(2)+"' 'eService Next Number' "+newNext+"1 ;");
            }

        }

        catch( Exception e )

        {

            e.printStackTrace();
            throw e;
        }

    }

 

 

    public static void getRel(Context context , String[] args) throws Exception{

        try

        {

            MapList retList = new MapList();
 

            String objectId = args[0];
            DomainObject crb = DomainObject.newInstance( context , objectId );
            StringList objectSelects = new StringList(2);
            objectSelects.addElement(DomainConstants.SELECT_ID);
            objectSelects.addElement(DomainConstants.SELECT_NAME);
            objectSelects.addElement(DomainConstants.SELECT_CURRENT);
            StringList relSelectsList = new StringList(DomainConstants.SELECT_RELATIONSHIP_ID);
 

            String RELATIONSHIP_CRB_ATTENDEES = PropertyUtil.getSchemaProperty(context,"relationship_shiCRBAttendees");
            //Calling getRelatedObjects to get the relationship ids

            retList = crb.getRelatedObjects(context,

                    RELATIONSHIP_CRB_ATTENDEES,

                    DomainObject.TYPE_PERSON,

                    objectSelects,

                    relSelectsList,

                    false,

                    true,

                    (short)1,

                    DomainConstants.EMPTY_STRING,

                    DomainConstants.EMPTY_STRING);
            System.out.println("retList11="+retList);
 

 

            retList = crb.getRelatedObjects(context,

                    RELATIONSHIP_CRB_ATTENDEES,

                    DomainObject.TYPE_PERSON,

                    objectSelects,

                    relSelectsList,

                    false,

                    true,

                    (short)1,

                    "",

                    "");
 

            System.out.println("retList12="+retList);
            retList = crb.getRelatedObjects(context,

                    RELATIONSHIP_CRB_ATTENDEES,

                    DomainObject.TYPE_PERSON,

                    objectSelects,

                    relSelectsList,

                    false,

                    true,

                    (short)1,

                    null,

                    null);
 

            System.out.println("retList13="+retList);
 

 

            retList = crb.getRelatedObjects(context,

                    RELATIONSHIP_CRB_ATTENDEES,

                    "*",

                    objectSelects,

                    relSelectsList,

                    false,

                    true,

                    (short)1,

                    DomainConstants.EMPTY_STRING,

                    DomainConstants.EMPTY_STRING);
 

            System.out.println("retList14="+retList);
 

 

            retList = crb.getRelatedObjects(context,

                    "*",

                    DomainObject.TYPE_PERSON,

                    objectSelects,

                    relSelectsList,

                    false,

                    true,

                    (short)1,

                    null,

                    null);
            System.out.println("retList15="+retList);
            retList = crb.getRelatedObjects(context,

                    "*",

                    "*",

                    objectSelects,

                    relSelectsList,

                    false,

                    true,

                    (short)1,

                    DomainConstants.EMPTY_STRING,

                    DomainConstants.EMPTY_STRING);
            System.out.println("retList16="+retList);
 

            String mqlRet = MqlUtil.mqlCommand( context , "expand bus "+objectId+"" );
 

            System.out.println("mqlRet="+mqlRet);
 

        }

        catch( Exception e )

        {

            e.printStackTrace();
            throw e;
        }

    }
    
    
    
/*******************************************************************************************************************************************
 *     
*******************************************************************************************************************************************/    
    private static String _fileName = "C:"+File.separator+"workbook.xls";
    private static String _fileName2 = "C:"+File.separator+"workbook2.xls";
    private static Workbook _wb = null;
    private static boolean appendDuplicate = false;
    private static boolean _clear = false;
    
    private static boolean findRow(Sheet sheet, String cellContent) {
    	if( appendDuplicate  ) {
    		return false;
    	}else{    		
    		for (Row row : sheet) {
	        	Cell cell = row.getCell(0);
	        	System.out.println("cell="+cell);
	                if (cell.getCellType() == Cell.CELL_TYPE_STRING) {
	                    if (cell.getRichStringCellValue().getString().trim().equals(cellContent)) {
	                        return true;  
	                }
	            }
	        }    
	        return false;
    	}
    }
    
    public static void setWorkbook(Context context, String[] args) throws Exception {
    	 
    	if( args.length == 2 ){
    		_fileName = args[1];
    	}
		
    	try {
        	File file = new File(_fileName);
        	_wb = new HSSFWorkbook();
        	if( file.exists() ){
        		POIFSFileSystem poiFs = new POIFSFileSystem(new FileInputStream(file));
        		_wb = new HSSFWorkbook(poiFs);
        	}else{
        		FileOutputStream fileOut = new FileOutputStream(_fileName);        		
        		_wb.write(fileOut);
        		fileOut.close();
        	}
        } catch (Exception e) {        	
            e.printStackTrace();
            throw e;
        }
    	
    	
    }
    
    /**
     * 모든 Sheet를 삭제한다.
     * @param context
     * @param args
     * @return
     * @throws Exception
     */
    public static Workbook clearSheet(Context context , String[] args) throws Exception{
    	FileUtils.copyFile(new File(_fileName2), new File(_fileName));
    	System.out.println("clearSheet");
        setWorkbook(context, args);
        int iSheet = _wb.getNumberOfSheets();
        for( int idx = iSheet-1 ; idx >= 0 ; idx--){
        	_wb.removeSheetAt(idx);
        }

        FileOutputStream fileOut = new FileOutputStream(_fileName);
        _wb.write(fileOut);
        fileOut.close();
        return _wb;
    }
    public static void getSchemaExcel(Context context , String[] args) throws Exception{
    	long lTime = System.currentTimeMillis();
    	
    	if( _clear ){
    		clearSheet(context , args);
    	}
    	
    	getBasicSchema(context , args);
    	
    	setWorkbook(context, args);
    	String totalCommand = "";
        String ret1 = MqlUtil.mqlCommand( context , "list portal '"+args[0]+"' select name dump recordseparator ," );
        String[] paramArgs = StringUtils.split( ret1 , "," );
 
        System.out.println("===================================================");
        System.out.println("PORTAL ==>"+paramArgs.length);
        System.out.println("===================================================");
        if( paramArgs.length > 0 ){
        	totalCommand = getPortalNChannelLExcel(context , paramArgs);
        }
        

        paramArgs = StringUtils.split( totalCommand , "," );
        System.out.println("===================================================");
        System.out.println("COMMAND ==>"+paramArgs.length);
        System.out.println("===================================================");
        if( paramArgs.length > 0 ){
        	getCommandExcel( context , paramArgs , "portal");
        }
 
 

        ret1 = MqlUtil.mqlCommand( context , "list menu '"+args[0]+"' select name dump recordseparator ," );
        paramArgs = StringUtils.split( ret1 , "," );
        System.out.println("===================================================");
        System.out.println("MENU ==>"+paramArgs.length);
        System.out.println("===================================================");
        if( paramArgs.length > 0 ){
        	totalCommand = getMenuExcel(context , paramArgs);
        }
 
        

        paramArgs = StringUtils.split( totalCommand , "," );
        System.out.println("===================================================");
        System.out.println("COMMAND ==>"+paramArgs.length);
        System.out.println("===================================================");
        if( paramArgs.length > 0 ){
        	getCommandExcel( context , paramArgs , "menu" );
        }
 

        ret1 = MqlUtil.mqlCommand( context , "list table system '"+args[0]+"' select name dump recordseparator ," );
        paramArgs = StringUtils.split( ret1 , "," );
        System.out.println("===================================================");
        System.out.println("TABLE ==>"+paramArgs.length);
        System.out.println("===================================================");
        if( paramArgs.length > 0 ){
        	getTableExcel(context , paramArgs);
        }
 
        ret1 = MqlUtil.mqlCommand( context , "list form '"+args[0]+"' select name dump recordseparator ," );
        paramArgs = StringUtils.split( ret1 , "," );
        System.out.println("===================================================");
        System.out.println("FORM ==>"+paramArgs.length);
        System.out.println("===================================================");
        if( paramArgs.length > 0 ){
        	getFormExcel(context , paramArgs);
        }
        

        ret1 = MqlUtil.mqlCommand( context , "list dimension '"+args[0]+"' select name dump recordseparator ," );
        paramArgs = StringUtils.split( ret1 , "," );
        System.out.println("===================================================");
        System.out.println("DIMENSION ==>"+paramArgs.length);
        System.out.println("===================================================");
        if( paramArgs.length > 0 ){
        	getDimensionExcel(context , paramArgs);
        }
        
        
        ret1 = MqlUtil.mqlCommand( context , "list format '"+args[0]+"' select name dump recordseparator ," );
        paramArgs = StringUtils.split( ret1 , "," );
        System.out.println("===================================================");
        System.out.println("FORMAT ==>"+paramArgs.length);
        System.out.println("===================================================");
        if( paramArgs.length > 0 ){
        	getFormatExcel(context , paramArgs);
        }
        
        
        ret1 = MqlUtil.mqlCommand( context , "list inquiry '"+args[0]+"' select name dump recordseparator ," );
        paramArgs = StringUtils.split( ret1 , "," );
        System.out.println("===================================================");
        System.out.println("Inquiry ==>"+paramArgs.length);
        System.out.println("===================================================");
        if( paramArgs.length > 0 ){
        	getInquiryExcel(context , paramArgs);
        }
        
        long lTime2 = System.currentTimeMillis();
        System.out.println("total time : " +(lTime2-lTime));
    }

    public static void getInquiryExcel(Context context , String[] sNames) throws Exception{
    	
        try {
            Sheet sheet = _wb.getSheet("Inquiry");
            if( sheet == null ){
                sheet = _wb.createSheet("Inquiry");
            }

            
            int iInit = sheet.getLastRowNum()+1;    

            Row row = sheet.createRow(0);
            
            
            row.createCell(0).setCellValue("Name");
            row.createCell(1).setCellValue("Registry Name");
            row.createCell(2).setCellValue("Description");
            row.createCell(3).setCellValue("Pattern");
            row.createCell(4).setCellValue("Format");
            row.createCell(5).setCellValue("Argument Name (use \"|\" delim)");
            row.createCell(6).setCellValue("Argument Value (use \"|\" delim)");
            row.createCell(7).setCellValue("Code (use \"<ESC>\" & \"<NEWLINE>\")");
            row.createCell(8).setCellValue("Hidden (boolean)");
            
            int iMergeStart = iInit;
            int iMergeEnd = iInit;

            for (int idx = 0; idx < sNames.length; idx++) {
            	System.out.println("sNames[idx]="+sNames[idx]);
            	if( findRow(sheet,sNames[idx]) ){
            		continue;
            	}
            	
            	String result = MqlUtil.mqlCommand( context , "print inquiry '"+sNames[idx]+"' select name description pattern format code hidden dump ^" );
                StringList resultList = FrameworkUtil.split( result , "^" );
                int iCretaeCell = 0;
                //iMergeStart = iMergeStart +idx;

                System.out.println();
                System.out.println();
                System.out.println("idx="+idx);
                System.out.println("Main create row"+(iMergeEnd));
                row = sheet.createRow(iMergeEnd);
                ++iMergeEnd;
                //Format Name	
                Cell cell = row.createCell( iCretaeCell );
                cell.setCellValue( (String)resultList.get(0) );
                
                //Registry Name
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(0) );
                					
                //Description	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(1) );
                //Pattern	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(2) );
                //Format	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(3) );

                ++iCretaeCell;
                ++iCretaeCell;
                
                //Code (use "<ESC>" & "<NEWLINE>")
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(4) );
                //Hidden (boolean)	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(5) );
                
                
                result = MqlUtil.mqlCommand( context , "print inquiry '"+sNames[idx]+"' select argument.name argument.value dump ^" );
                resultList = FrameworkUtil.split(result, "^");
                int iSize = resultList.size();
                System.out.println("result="+result);
                System.out.println("iSize="+iSize);
                System.out.println("iMergeEnd="+iMergeEnd);
                for( int jdx = 0 ; jdx < iSize/2 ;jdx++ ){
                	
                	if( jdx > 0 ){
                		row = sheet.createRow(iMergeEnd);
                		System.out.println("jdx="+jdx);
                		System.out.println("Sub create row"+(iMergeEnd));
                		++iMergeEnd;
                		
                	}
                	iCretaeCell = 5;
	                //Argument Name (use "|" delim)
	                cell = row.createCell( iCretaeCell );
	                cell.setCellValue( (String)resultList.get(jdx) );
	                //Argument Value (use "|" delim)
	                cell = row.createCell( ++iCretaeCell );
	                cell.setCellValue( (String)resultList.get(jdx+(iSize/2)) );
                }
                

                if( iSize > 0){
                	
                	
	                sheet.addMergedRegion(new CellRangeAddress(
	
	                		iMergeStart, //first row (0-based)
	
	                		iMergeEnd-1, //last row  (0-based)
	
	                        0, //first column (0-based)
	
	                        0  //last column  (0-based)
	
	                        ));
                }
                iMergeStart = iMergeEnd;

                
            }

            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
 

        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }
    

    public static void getFormatExcel(Context context , String[] sNames) throws Exception{
    	
        try {

            Sheet sheet = _wb.getSheet("Foramt");
            if( sheet == null ){
                sheet = _wb.createSheet("Foramt");
            }

            int iInit = sheet.getLastRowNum()+1;
            

            Row row = sheet.createRow(0);
            
            
            row.createCell(0).setCellValue("Format Name");
            row.createCell(1).setCellValue("Registry Name");
            row.createCell(2).setCellValue("Description");
            row.createCell(3).setCellValue("Version");
            row.createCell(4).setCellValue("File Suffix");
            row.createCell(5).setCellValue("View Command");
            row.createCell(6).setCellValue("Edit Command");
            row.createCell(7).setCellValue("Print Command");
            row.createCell(8).setCellValue("Hidden (boolean)");

            for (int idx = 0; idx < sNames.length; idx++) {
            	
            	if( findRow(sheet,sNames[idx]) ){
            		continue;
            	}
            	
            	String result = MqlUtil.mqlCommand( context , "print format '"+sNames[idx]+"' select name description version filesuffix view edit print mime hidden dump |" );
                StringList resultList = FrameworkUtil.split( result , "|" );
                int iCretaeCell = 0;
                row = sheet.createRow(idx+iInit);
                //Format Name	
                Cell cell = row.createCell( iCretaeCell );
                cell.setCellValue( (String)resultList.get(0) );
                
                //Registry Name
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(0) );
                
                //Description	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(1) );
                //Version	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(2) );
                //File Suffix	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(3) );
                //View Command	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(4) );
                //Edit Command	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(5) );
                //Print Command	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(6) );
                //Mime	
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(7) );
                //Hidden (boolean)
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(8) );

                
            }

            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
 

        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }
    
    
    public static String getDimensionExcel(Context context , String[] sNames) throws Exception{
    	
        try {

            Sheet sheet = _wb.getSheet("Dimension");
            if( sheet == null ){
                sheet = _wb.createSheet("Dimension");
            }
            int iInit = sheet.getLastRowNum()+1;

            Row row = sheet.createRow(0);
            
            row.createCell(0).setCellValue("Name");
            row.createCell(1).setCellValue("Registry Name");
            row.createCell(2).setCellValue("Description");
            row.createCell(3).setCellValue("Unit Names (in order-use \"|\" delim)");
            row.createCell(4).setCellValue("Hidden (boolean)");
            row.createCell(3).setCellValue("Attributes (use \"|\" delim)");


            String totalCommand = "";

            Sheet unitSheet = _wb.getSheet("DimensionUnit");
            if( unitSheet == null ){
            	unitSheet = _wb.createSheet("DimensionUnit");
            }
            
          //Dimension Name	Unit Name	Unit Label	Unit Description	Multiplier (real)	Offset (real)
            row = unitSheet.createRow(0);
            
            
            row.createCell(0).setCellValue("Dimension Name");
            row.createCell(1).setCellValue("Unit Name");
            row.createCell(2).setCellValue("Unit Label");
            row.createCell(3).setCellValue("Unit Description");
            row.createCell(4).setCellValue("Multiplier (real)");
            row.createCell(5).setCellValue("Offset (real)");
            
            
            
            
            int iMergeStart = iInit;
            int iMergeEnd = iInit;
            for (int idx = 0; idx < sNames.length; idx++) {
            	
            	if( findRow(sheet,sNames[idx]) ){
            		continue;
            	}
            	
            	String result = MqlUtil.mqlCommand( context , "print dimension '"+sNames[idx]+"' select name description hidden dump |" );
                StringList resultList = FrameworkUtil.split( result , "|" );
                int iCretaeCell = 0;
                row = sheet.createRow(idx+iInit);
                //name
                Cell cell = row.createCell( iCretaeCell );
                cell.setCellValue( (String)resultList.get(0) );
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(0) );
                
                //desc
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(1) );

                result = MqlUtil.mqlCommand( context , "print dimension '"+sNames[idx]+"' select unit dump |" );
                //unit names
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( result );

                //hidden
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( (String)resultList.get(2) );
                
                String attrResult = MqlUtil.mqlCommand( context , "print dimension '"+sNames[idx]+"' select attribute dump |" );

                //Attributes (use \"|\" delim)
                cell = row.createCell( ++iCretaeCell );
                cell.setCellValue( attrResult );
                
                
                resultList = FrameworkUtil.split( result , "|" );
	                for( int jdx = 0 ; jdx < resultList.size() ; jdx++){
	                	String unitResult = MqlUtil.mqlCommand( context , "print dimension '"+sNames[idx]+"' select unit["+(String)resultList.get(jdx)+"].label unit["+(String)resultList.get(jdx)+"].description unit["+(String)resultList.get(jdx)+"].multiplier unit["+(String)resultList.get(jdx)+"].offset dump |;" );
	                	StringList unitResultList = FrameworkUtil.split(unitResult, "|");
	                	
		                //Dimension Name	Unit Name	Unit Label	Unit Description	Multiplier (real)	Offset (real)
		                Row unitRow = unitSheet.createRow(iMergeEnd);
		                ++iMergeEnd;
		                //Dimension Name
		                cell = unitRow.createCell( 0 );
		                cell.setCellValue( sNames[idx] );
		                
		                //Unit Name
		                cell = unitRow.createCell( 1 );
		                cell.setCellValue( (String)resultList.get(jdx) );
		                
		                //Unit Label
		                cell = unitRow.createCell( 2 );
		                cell.setCellValue( (String)unitResultList.get(0) );
		                
		                //Unit Description
		                cell = unitRow.createCell( 3 );
		                cell.setCellValue( (String)unitResultList.get(1) );
		                
		                //Multiplier (real)
		                cell = unitRow.createCell( 4 );
		                cell.setCellValue( (String)unitResultList.get(2) );
		                
		                //Offset (real)
		                cell = unitRow.createCell( 5 );
		                cell.setCellValue( (String)unitResultList.get(3) );
	                }

	                System.out.println("iMergeStart="+iMergeStart);
	                System.out.println("iMergeEnd="+iMergeEnd);
	                
	                unitSheet.addMergedRegion(new CellRangeAddress(

	                		iMergeStart, //first row (0-based)

	                		iMergeEnd-1, //last row  (0-based)

	                        0, //first column (0-based)

	                        0  //last column  (0-based)

	                        ));
	                iMergeStart= iMergeEnd;
                
            }

            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
 

            return totalCommand;
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 
    public static String getPortalNChannelLExcel(Context context, String[] sNames) throws Exception{

 

        try {
            Sheet sheet = _wb.getSheet("Portal&Channel");
            if( sheet == null ){

                sheet = _wb.createSheet("Portal&Channel");
            }

            int iInit = sheet.getLastRowNum()+1;
            
            String totalCommand = "";
            
            HSSFCellStyle cellStyle = (HSSFCellStyle)_wb.createCellStyle();
        	cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
            
            

            Row row = sheet.createRow(0);
            row.createCell(0).setCellValue("Portal Name");
            row.createCell(1).setCellValue("Channel Name");
            row.createCell(2).setCellValue("Channel Description");
            row.createCell(3).setCellValue("Height");
            
            row.createCell(4).setCellValue("Setting Nmae");
            row.createCell(5).setCellValue("Setting Value");
            
            row.createCell(6).setCellValue("Setting Nmae");
            row.createCell(7).setCellValue("Setting Value");
            
            row.createCell(8).setCellValue("Setting Nmae");
            row.createCell(9).setCellValue("Setting Value");
            
            row.createCell(10).setCellValue("Setting Nmae");
            row.createCell(11).setCellValue("Setting Value");
            
            row.createCell(12).setCellValue("Setting Nmae");
            row.createCell(13).setCellValue("Setting Value");
            
            row.createCell(14).setCellValue("Command Name(use \"|\" delim)");
 

            for (int i = 0; i < sNames.length; i++) {
 
            	if( findRow(sheet,sNames[i]) ){
            		continue;
            	}

                String result = MqlUtil.mqlCommand( context , "print portal '" + sNames[i] + "' select channel.name dump" );
                StringList channelList = FrameworkUtil.split( result , "," );
                for( int idx = 0 ; idx < channelList.size() ; idx++){

                    String channelName = (String)channelList.get(idx);
 

                    String description = MqlUtil.mqlCommand( context , "print channel '" + channelName + "' select description dump" );
                    String height = MqlUtil.mqlCommand( context , "print channel '" + channelName + "' select height dump" );
 
                    int iCreate = 0;
 

                    row = sheet.createRow(idx+iInit);

                    Cell cell = row.createCell( iCreate );
                    cell.setCellValue( sNames[i] );
                    cell.setCellStyle(cellStyle);

                    cell = row.createCell( ++iCreate );
                    cell.setCellValue( channelName );
 

                    cell = row.createCell( ++iCreate );
                    cell.setCellValue( description );
 

                    cell = row.createCell( ++iCreate );
                    cell.setCellValue( height );
 

                    String settingName = MqlUtil.mqlCommand( context , "print channel '" + channelName + "' select setting.name dump" );
                    String settingValue = MqlUtil.mqlCommand( context , "print channel '" + channelName + "' select setting.value dump" );
 

 

                    StringList settingNameList = FrameworkUtil.split( settingName , "," );
                    StringList settingValueList = FrameworkUtil.split( settingValue , "," );
 
                    for( int jdx = 0 ; jdx < settingNameList.size() ; jdx++ ){

                        Cell channelSettingNameCell = row.createCell( iCreate+1+(jdx*2) );
                        Cell channelSettingValueCell = row.createCell( iCreate+2+(jdx*2) );
                        channelSettingNameCell.setCellValue( (String)settingNameList.get(jdx) );
                        channelSettingValueCell.setCellValue( (String)settingValueList.get(jdx) );
                    }

 

                    if( settingNameList.size() > 20 ){

                        System.out.println("===================================================");
                        System.out.println("CHANNEL : "+channelName);
                        System.out.println("CHANNEL Warning : Setting Size = "+ settingNameList.size());
                        System.out.println("===================================================");
                    }
 
                    String command = MqlUtil.mqlCommand( context , "print channel '" + channelName + "' select command dump |" );
                    
                    Cell commandNameCell = row.createCell( 14 );
                    commandNameCell.setCellValue( command );
                    
                    StringList commandList = FrameworkUtil.split( command , "|" );
                    for( int jdx = 0 ; jdx < commandList.size() ; jdx++ ){
                        totalCommand = channelName+"|"+(String)commandList.get(jdx) + ","+totalCommand;
                    }

                }

 

                sheet.addMergedRegion(new CellRangeAddress(

                        iInit, //first row (0-based)

                        channelList.size()+(iInit-1), //last row  (0-based)

                        0, //first column (0-based)

                        0  //last column  (0-based)

                        ));
 

//                sheet.addMergedRegion(new CellRangeAddress(
//
//                        iInit, //first row (0-based)
//
//                        channelList.size()+(iInit-1), //last row  (0-based)
//
//                        1, //first column (0-based)
//
//                        1  //last column  (0-based)
//
//                        ));
 

                iInit = iInit + channelList.size();
                if( i > 0 && i%100==0 ){

                    System.out.println(i+" Items!!!");
                }

            }

            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
 

            return totalCommand;
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }

 

 

    public static String getMenuExcel(Context context, String[] sNames) throws Exception{

 

        try {

            Sheet sheet = _wb.getSheet( "Menu" );
            Sheet sheet2 = _wb.getSheet("Menu(Href)");
            if( sheet == null ){

                sheet = _wb.createSheet("Menu");
                sheet2 = _wb.createSheet("Menu(Href)");
            }
            
            HSSFCellStyle cellStyle = (HSSFCellStyle)_wb.createCellStyle();
            cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

            int iInit = sheet.getLastRowNum()+1;
            int iInitHref = sheet2.getLastRowNum()+1;

            String totalCommand = "";
            
            Row row = sheet.createRow(0);            
            Cell cell = row.createCell(0);
            cell.setCellValue("Menu Name");
            cell = row.createCell(1);
            cell.setCellValue("Menu Description");
            cell = row.createCell(2);
            cell.setCellValue("Menu Label");
            cell = row.createCell(3);
            cell.setCellValue("Hidden (boolean)");
            cell = row.createCell(4);
            cell.setCellValue("Alt");
            for( int idx = 0 ; idx < 30 ; ){
	            cell = row.createCell(5+idx);	            
	            cell.setCellValue("Setting Name");
	            ++idx;
	            cell = row.createCell(5+idx);
	            cell.setCellValue("Setting Value");
	            ++idx;
            }
            
            row = sheet2.createRow(0);
            cell = row.createCell(0);
            cell.setCellValue("Menu Name");
            cell = row.createCell(1);
            cell.setCellValue("Href");
 

            for (int i = 0; i < sNames.length; i++) {

            	if( findRow(sheet,sNames[i]) ){
            		continue;
            	}
                
                int iCellCreate = 0;

                String result = MqlUtil.mqlCommand( context , "print menu '" + sNames[i] + "' select name description label hidden alt href dump" );
                StringList resultList = FrameworkUtil.split( result , "," );

                row = sheet.createRow(iInit);
                ++iInit;
                Cell menuNameCell = row.createCell( iCellCreate );
                menuNameCell.setCellValue( (String)resultList.get(0) );
                menuNameCell.setCellStyle(cellStyle);

                Cell descriptionCell = row.createCell( ++iCellCreate );
                descriptionCell.setCellValue( (String)resultList.get(1) );
                
                if( StringUtils.isNotEmpty((String)resultList.get(5)) ){
	                Row row2 = sheet2.createRow(iInitHref);
	                Cell menuNameCell2 = row2.createCell( 0 );
	                menuNameCell2.setCellValue( (String)resultList.get(0) );
	                Cell hrefCell = row2.createCell( 1 );
	                hrefCell.setCellValue( (String)resultList.get(5) );
	                ++iInitHref;
                }

                Cell labelCell = row.createCell( ++iCellCreate );
                labelCell.setCellValue( (String)resultList.get(2) );
 

                Cell hiddenCell = row.createCell( ++iCellCreate );
                hiddenCell.setCellValue( (String)resultList.get(3) );
 

                Cell altCell = row.createCell( ++iCellCreate );
                altCell.setCellValue( (String)resultList.get(4) );
 

                String settingName = MqlUtil.mqlCommand( context , "print menu '" + sNames[i] + "' select setting.name dump" );
                String settingValue = MqlUtil.mqlCommand( context , "print menu '" + sNames[i] + "' select setting.value dump" );
 

                StringList settingNameList = FrameworkUtil.split( settingName , "," );
                StringList settingValueList = FrameworkUtil.split( settingValue , "," );
 

                for( int jdx = 0 ; jdx < settingNameList.size() ; jdx++ ){

                    Cell channelSettingNameCell = row.createCell( iCellCreate+1+(jdx*2) );
                    Cell channelSettingValueCell = row.createCell( iCellCreate+2+(jdx*2) );
                    channelSettingNameCell.setCellValue( (String)settingNameList.get(jdx) );
                    channelSettingValueCell.setCellValue( (String)settingValueList.get(jdx) );
                }

 

                if( settingNameList.size() > 20 ){

                    System.out.println("===================================================");
                    System.out.println("MENU : "+sNames[i]);
                    System.out.println("MENU Warning : Setting Size = "+ settingNameList.size());
                    System.out.println("===================================================");
                }

 

                String command = MqlUtil.mqlCommand( context , "print menu '" + sNames[i] + "' select command dump" );
                //47

                StringList commandList = FrameworkUtil.split( command , "," );
                for( int jdx = 0 ; jdx < commandList.size() ; jdx++ ){

                    Cell commandNameCell = row.createCell( 46+jdx );
                    commandNameCell.setCellValue( (String)commandList.get(jdx) );
                    totalCommand = sNames[i]+"|"+commandList.get(jdx) + ","+totalCommand;
                }

 

                if( i > 0 && i%100==0 ){

                    System.out.println(i+" Items!!!");
                }

            }

 

            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
 

            return totalCommand;
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }

    }


    public static String getBasicSchema(Context context , String[] args) throws Exception{
    	
    	try {
    		setWorkbook(context, args);
    		
			String ret1 = MqlUtil.mqlCommand(context, "list type '" + args[0]+ "' select name dump recordseparator ,");			
			String[] paramArgs = StringUtils.split(ret1, ",");
			
			System.out.println("===================================================");
	        System.out.println("Type-Attribute ==>"+paramArgs.length);
	        System.out.println("===================================================");
	        if( paramArgs.length > 0 ){
	        	getTypeNAttributeExcel(context, paramArgs);
	        }
			
			ret1 = MqlUtil.mqlCommand(context, "list relationship '" + args[0]+ "' select name dump recordseparator ,");
			paramArgs = StringUtils.split(ret1, ",");
			System.out.println("===================================================");
	        System.out.println("Relationship-Attribute ==>"+paramArgs.length);
	        System.out.println("===================================================");
	        if( paramArgs.length > 0 ){
	        	getRelationshipNAttributeExcel(context, paramArgs);
	        }
			
			ret1 = MqlUtil.mqlCommand(context, "list policy '" + args[0] + "' select name dump recordseparator ,");
			paramArgs = StringUtils.split(ret1, ",");
			System.out.println("===================================================");
	        System.out.println("Policy ==>"+paramArgs.length);
	        System.out.println("===================================================");
	        if( paramArgs.length > 0 ){
	        	getPolicyExcel(context,paramArgs);
	        }
			
			
			return "";
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    	
    }
    

    public static String getTypeNAttributeExcel(Context context , String[] sNames) throws Exception{
    	
        try {
            
            Sheet typeSheet = _wb.getSheet("Type");
            if( typeSheet == null  ){
            	typeSheet = _wb.createSheet("Type");
            }
            
            


            Row row = typeSheet.createRow(0);
            row.createCell(0).setCellValue("Name");
            row.createCell(1).setCellValue("Registry Name");
            row.createCell(2).setCellValue("Parent Type");
            row.createCell(3).setCellValue("Abstract (boolean)");
            row.createCell(4).setCellValue("Description");
            row.createCell(5).setCellValue("Attributes (use \"|\" delim)");
            row.createCell(6).setCellValue("Hidden (boolean)");

            
            int iInit = typeSheet.getLastRowNum()+1;
            
            HSSFCellStyle cellStyle = (HSSFCellStyle)_wb.createCellStyle();
        	cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
            
            
            String totalCommand = "";
            HashMap<String,String[]> attrNameMap = new HashMap<String,String[]>();
            
            for (int idx = 0; idx < sNames.length; idx++) {
            	if( findRow(typeSheet,sNames[idx]) ){
            		continue;
            	}
            	String result = MqlUtil.mqlCommand( context , "print type '" + sNames[idx] + "' select name abstract description hidden dump |" );
            	
            	StringList resultList = FrameworkUtil.split( result , "|" );
            	
            	row = typeSheet.createRow(idx+iInit);
            	
            	//Name

                Cell nameCell = row.createCell( 0 );
                nameCell.setCellValue( (String)resultList.get(0) );
                nameCell.setCellStyle(cellStyle);
                //	Registry Name	
                Cell registryNameCell = row.createCell( 1 );
                registryNameCell.setCellValue( (String)resultList.get(0) );
                
                result = MqlUtil.mqlCommand( context , "print type '" + sNames[idx] + "' select derived dump |" );
                //Parent Type	
                  Cell parentCell = row.createCell( 2 );
                  parentCell.setCellValue( result );
                                
                //Abstract (boolean)	
                Cell abstractCell = row.createCell( 3 );
                abstractCell.setCellValue( (String)resultList.get(1) );
                
                //Description	
                Cell descriptionCell = row.createCell( 4 );
                descriptionCell.setCellValue( (String)resultList.get(2) );
                
              //Hidden (boolean)
                Cell hiddenCell = row.createCell( 6 );
                hiddenCell.setCellValue( (String)resultList.get(3) );

                
                //Attributes (use "|" delim)
                result = MqlUtil.mqlCommand( context , "print type '" + sNames[idx] + "' select attribute dump |" );
                Cell attributeCell = row.createCell( 5 );
                attributeCell.setCellValue( result );
                
                attrNameMap.put(sNames[idx],StringUtils.split( result , "|" ));
                
                //getAttributeExcel(context,sNames[idx]+"(TYPE)" ,StringUtils.split( result , "|" ) );
                //attrName.addAll(FrameworkUtil.split( result , "|" ));

                if( idx > 0 && idx%100==0 ){
                    System.out.println("type : "+idx+" Items!!!");
                }
                
            }
            
            
            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();

            for(String key : attrNameMap.keySet()){
            	getAttributeExcel(context,key ,attrNameMap.get(key) , "type" ); 
            }

            return totalCommand;
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }
    }
    
    
    
    public static String getRelationshipNAttributeExcel(Context context , String[] sNames) throws Exception{
    	
        try {
            
            Sheet relationshipSheet = _wb.getSheet("Relationship");
            if( relationshipSheet == null  ){
            	relationshipSheet = _wb.createSheet("Relationship");
            }
            
            Row row = relationshipSheet.createRow(0);
            row.createCell(0).setCellValue("Name");
            row.createCell(1).setCellValue("Registry Name");
            row.createCell(2).setCellValue("Description");
            row.createCell(3).setCellValue("Attributes (use \"|\" delim)");//
            row.createCell(4).setCellValue("Hidden (boolean)");
            row.createCell(5).setCellValue("PreventDuplicates (boolean)");
            row.createCell(6).setCellValue("From Types (use \"|\" delim)");//
            row.createCell(7).setCellValue("From Meaning");
            row.createCell(8).setCellValue("From Revision (none / float / replicate)");
            row.createCell(9).setCellValue("From Clone (none / float / replicate)");
            row.createCell(10).setCellValue("From Cardinality (one / many)");
            row.createCell(11).setCellValue("From Propagate Modify (boolean)");
            row.createCell(12).setCellValue("From Propagate Connect (boolean)");
            
            row.createCell(13).setCellValue("To Types (use \"|\" delim)");//
            row.createCell(14).setCellValue("To Meaning");
            row.createCell(15).setCellValue("To Revision (none / float / replicate)");
            row.createCell(16).setCellValue("To Clone (none / float / replicate)");
            row.createCell(17).setCellValue("To Cardinality (one / many)");
            row.createCell(18).setCellValue("To Propagate Modify (boolean)");
            row.createCell(19).setCellValue("To Propagate Connect (boolean)");
            

            HSSFCellStyle cellStyle = (HSSFCellStyle)_wb.createCellStyle();
        	cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
            
            
            int iInit = relationshipSheet.getLastRowNum()+1;
            
            String totalCommand = "";
            HashMap<String,String[]> attrNameMap = new HashMap<String,String[]>();
            
            for (int idx = 0; idx < sNames.length; idx++) {
            	
            	if( findRow(relationshipSheet,sNames[idx]) ){
            		continue;
            	}
            	
            	String fromselect = "frommeaning  fromreviseaction fromcloneaction fromcardinality frompropagatemodify frompropagateconnection ";
            	String toselect = "tomeaning  toreviseaction tocloneaction tocardinality topropagatemodify topropagateconnection ";
            	String result = MqlUtil.mqlCommand( context , "print relationship '" + sNames[idx] + "' select name description hidden preventduplicates "+fromselect +" "+toselect+" dump |" );
            	
            	StringList resultList = FrameworkUtil.split( result , "|" );
            	
            	
            	row = relationshipSheet.createRow(idx+iInit);
            	
            	//Name	
                Cell cell = row.createCell( 0 );
                cell.setCellValue( (String)resultList.get(0) );
                cell.setCellStyle(cellStyle);
                
                //Registry Name
                cell = row.createCell( 1 );
                cell.setCellValue( (String)resultList.get(0) );
                //Description
                cell = row.createCell( 2 );
                cell.setCellValue( (String)resultList.get(1) );
                
                //Attributes (use "|" delim)
                result = MqlUtil.mqlCommand( context , "print relationship '" + sNames[idx] + "' select attribute dump |" );
                Cell attributeCell = row.createCell( 3 );
                attributeCell.setCellValue( result );
                //getAttributeExcel(context, sNames[idx]+"(RELATIONSHIP)" , StringUtils.split(result, "|"));
                
                attrNameMap.put(sNames[idx],StringUtils.split( result , "|" ));
                
                //Hidden (boolean)	PreventDuplicates (boolean)
                cell = row.createCell( 4 );
                cell.setCellValue( (String)resultList.get(2) );                
                
                //PreventDuplicates (boolean)
                cell = row.createCell( 5 );
                cell.setCellValue( (String)resultList.get(3) );
                
                //From Types (use "|" delim)	
                result = MqlUtil.mqlCommand( context , "print relationship '" + sNames[idx] + "' select fromtype dump |" );
                cell = row.createCell( 6 );
                cell.setCellValue( result );

                
                //From Meaning	
                cell = row.createCell( 7 );
                cell.setCellValue( (String)resultList.get(4) );
                
                //From Revision (none or ""/ float / replicate)	
                cell = row.createCell( 8 );
                cell.setCellValue( (String)resultList.get(5) );
                
                //From Clone (none or "" / float / replicate)
                cell = row.createCell( 9 );
                cell.setCellValue( (String)resultList.get(6) );
                
                //From Cardinality (one / many or "")
                cell = row.createCell( 10 );
                cell.setCellValue( (String)resultList.get(7) );
                
                //From Propagate Modify (boolean)
                cell = row.createCell( 11 );
                cell.setCellValue( (String)resultList.get(8) );
                
                

                //To Types (use "|" delim)	
                result = MqlUtil.mqlCommand( context , "print relationship '" + sNames[idx] + "' select totype dump |" );
                cell = row.createCell( 12 );
                cell.setCellValue( result );
                
                //To Meaning	
                cell = row.createCell( 13 );
                cell.setCellValue( (String)resultList.get(9) );
                
                //To Revision (none or ""/ float / replicate)	
                cell = row.createCell( 14 );
                cell.setCellValue( (String)resultList.get(10) );
                
                //To Clone (none or "" / float / replicate)
                cell = row.createCell( 15 );
                cell.setCellValue( (String)resultList.get(11) );
                
                //To Cardinality (one / many or "")
                cell = row.createCell( 16 );
                cell.setCellValue( (String)resultList.get(12) );
                
                //To Propagate Modify (boolean)
                cell = row.createCell( 17 );
                cell.setCellValue( (String)resultList.get(13) );
                
                
                if( idx > 0 && idx%100==0 ){
                    System.out.println("type : "+idx+" Items!!!");
                }
                
            }
            
            
            
            
            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
            
            for(String key : attrNameMap.keySet()){
            	getAttributeExcel(context,key ,attrNameMap.get(key) , "relationship" );
            }
 

            return totalCommand;
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }
    }
    
    
    
    public static void getAttributeExcel(Context context, String sName, String[] sNames , String adminType) throws Exception{
    	try {
            
            Sheet attributeSheet = _wb.getSheet("Attribute("+adminType+")");
            if( attributeSheet == null  ){
            	attributeSheet = _wb.createSheet("Attribute("+adminType+")");
            }
            Row row = attributeSheet.createRow( 0);
            
            
            row.createCell(0).setCellValue("Attribute Name");
            row.createCell(1).setCellValue("Registry Name");
            row.createCell(2).setCellValue("Type");
            row.createCell(3).setCellValue("Description");
            row.createCell(4).setCellValue("Default");
            row.createCell(5).setCellValue("Ranges (use \"|\" delim)");
            row.createCell(6).setCellValue("Multiline (boolean)");
            row.createCell(7).setCellValue("Hidden (boolean)");

            
            int iInit = attributeSheet.getLastRowNum()+1;
            
            
            
            String totalCommand = "";
            
            HSSFCellStyle cellStyle = (HSSFCellStyle)_wb.createCellStyle();
            cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
            
            
            for (int idx = 0; idx < sNames.length; idx++) {
            	
            	String result = MqlUtil.mqlCommand( context , "print attribute '" + sNames[idx] + "' select name type description default multiline hidden dump |" );
            	
            	StringList resultList = FrameworkUtil.split( result , "|" );
            	
            	row = attributeSheet.createRow( idx+iInit);
            	
            	Cell cell = row.createCell( 0 );
            	cell.setCellValue( sName );
            	cell.setCellStyle(cellStyle);
            	
            	//Attribute Name	
                Cell nameCell = row.createCell( 1 );
                nameCell.setCellValue( (String)resultList.get(0) );
                //Registry Name		
                Cell registryNameCell = row.createCell( 2 );
                registryNameCell.setCellValue( (String)resultList.get(0) );
                                
                //Type		
                Cell typeCell = row.createCell( 3 );
                typeCell.setCellValue( (String)resultList.get(1) );
                
                //Description		
                Cell descriptionCell = row.createCell( 4 );
                descriptionCell.setCellValue( (String)resultList.get(2) );
                
              //Default	
                Cell defaultCell = row.createCell( 5 );
                defaultCell.setCellValue( (String)resultList.get(3) );

              //	Ranges (use "|" delim)
                Cell rangeCell = row.createCell( 6 );
                StringList choices = mxAttr.getChoices(context, sNames[idx]);
                String ranges = "";
                if( choices != null && choices.size() > 0){
                	ranges = FrameworkUtil.join( choices ,"|");
                }
                rangeCell.setCellValue( ranges );
                
              //Multiline (boolean)		
                Cell multiLineCell = row.createCell( 7 );
                multiLineCell.setCellValue( (String)resultList.get(4) );
                
                
                //Hidden (boolean)
                Cell HiddenCell = row.createCell( 8 );
                HiddenCell.setCellValue( (String)resultList.get(5) );
                

                if( idx > 0 && idx%100==0 ){
                    System.out.println("attr : "+idx+" Items!!!");
                }
                
            }
            /*System.out.println("sNames.length="+sNames.length);
            System.out.println("iInit="+iInit);
            System.out.println("sNames.length+(iInit-1)="+(sNames.length+(iInit-1)));*/
            if( sNames.length > 0 ){
	            attributeSheet.addMergedRegion(new CellRangeAddress(iInit, //first row (0-based)
	                    sNames.length+(iInit-1), //last row  (0-based)
	                    0, //first column (0-based)
	                    0  //last column  (0-based)
	                    ));
            }
            
            /*
            */
            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
            e.printStackTrace();
            throw e;
        }
    }
    
    
    
    
    
    public static void getPolicyExcel(Context context , String[] sNames) throws Exception{
    	
        try {
            Sheet policySheet = _wb.getSheet("Policy");
            if( policySheet == null  ){
            	policySheet = _wb.createSheet("Policy");
            }
            

            Row row = policySheet.createRow( 0);
            row.createCell(0).setCellValue("Name");
            row.createCell(1).setCellValue("Registry Name");
            row.createCell(2).setCellValue("Description");
            row.createCell(3).setCellValue("Rev Sequence (use 'continue' for '...')");
            row.createCell(4).setCellValue("Store");
            row.createCell(5).setCellValue("Hidden (boolean)");
            row.createCell(6).setCellValue("Types (use \"|\" delim)");//
            row.createCell(7).setCellValue("Formats (use \"|\" delim)");//            
            row.createCell(8).setCellValue("Default Format");
            row.createCell(9).setCellValue("Locking (boolean)");
            row.createCell(10).setCellValue("State Names (in order-use \"|\" delim)");
            row.createCell(11).setCellValue("State Registry Names (in order-use \"|\" delim)");

            HSSFCellStyle cellStyle = (HSSFCellStyle)_wb.createCellStyle();
            cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
            
            int iInit = policySheet.getLastRowNum()+1;
            
            
            String totalCommand = "";
            HashMap<String,StringList> stateNameMap = new HashMap<String,StringList>();
            
            for (int idx = 0; idx < sNames.length; idx++) {
            	if( findRow(policySheet,sNames[idx]) ){
            		continue;
            	}
            	
            	String result  = MqlUtil.mqlCommand(context, "print policy '"+sNames[idx]+"' select name description revision hidden islockingenforced dump " + SELECT_SEPERATOR);
            	StringList resultList = FrameworkUtil.split( result , SELECT_SEPERATOR );
            	
            	row = policySheet.createRow( idx+iInit);
            	//Name
                Cell cell = row.createCell( 0 );
                cell.setCellValue( (String)resultList.get(0) );
                cell.setCellStyle(cellStyle);
                //	Registry Name	
                cell = row.createCell( 1 );
                cell.setCellValue( (String)resultList.get(0) );
                //Description
                cell = row.createCell( 2 );
                cell.setCellValue( (String)resultList.get(1) );
                
                //Rev Sequence (use 'continue' for '...')
                cell = row.createCell( 3 );
                cell.setCellValue( (String)resultList.get(2) );
                
                result  = MqlUtil.mqlCommand(context, "print policy '"+sNames[idx]+"' select store dump " + SELECT_SEPERATOR);
                //store
                cell = row.createCell( 4 );
                cell.setCellValue( result );
                //hidden
                cell = row.createCell( 5 );
                cell.setCellValue( (String)resultList.get(3) );
                //Types (use "|" delim)	
                result  = MqlUtil.mqlCommand(context, "print policy '"+sNames[idx]+"' select type dump " + SELECT_SEPERATOR);
                cell = row.createCell( 6 );
                cell.setCellValue( result );
                
                //Formats (use "|" delim)	
                //State Names (in order-use "|" delim)
                result  = MqlUtil.mqlCommand(context, "print policy '"+sNames[idx]+"' select format dump " + SELECT_SEPERATOR);
                cell = row.createCell( 7 );
                cell.setCellValue( result );
                
                result  = MqlUtil.mqlCommand(context, "print policy '"+sNames[idx]+"' select defaultformat dump " + SELECT_SEPERATOR);
                //defaultformat
                cell = row.createCell( 8 );
                cell.setCellValue( result );
                
                //islockingenforced
                cell = row.createCell( 9 );
                cell.setCellValue( (String)resultList.get(4) );
                
                result  = MqlUtil.mqlCommand(context, "print policy '"+sNames[idx]+"' select state dump " + SELECT_SEPERATOR);
                
                //State Names (in order-use "|" delim)	
                cell = row.createCell( 10 );
                cell.setCellValue( result );
                
                //State Registry Names (in order-use "|" delim)
                cell = row.createCell( 11 );
                cell.setCellValue( result );
                
                resultList = FrameworkUtil.split(result, SELECT_SEPERATOR);
                stateNameMap.put(sNames[idx] , resultList);
                
                if( idx > 0 && idx%100==0 ){
                    System.out.println("type : "+idx+" Items!!!");
                }
                
            }
            
            
            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
            
            
            
            for(String key : stateNameMap.keySet()){
            	getPolicyStateExcel(context , key , stateNameMap.get(key));
            }
            

        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }
    }
    
    public static void getPolicyStateExcel(Context context, String sPolicyName ,  StringList resultList) throws Exception{
    	try {
            Sheet stateSheet = _wb.getSheet("Policy-States");
            if( stateSheet == null  ){
            	stateSheet = _wb.createSheet("Policy-States");
            }
            
            //Name	Registry Name	Parent Type	Abstract (boolean)	Description	Attributes (use "|" delim)	Hidden (boolean)
            //Attribute Name	Registry Name	Type	Description	Default	Ranges (use "|" delim)	Multiline (boolean)	Hidden (boolean)	Icon File
            
            HSSFCellStyle cellStyle = (HSSFCellStyle)_wb.createCellStyle();
            cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
            
            
            Row stateRow = stateSheet.createRow( 0);
            stateRow.createCell(0).setCellValue("Policy Name");
            stateRow.createCell(1).setCellValue("State Name");
            stateRow.createCell(2).setCellValue("Revision (boolean)");
            stateRow.createCell(3).setCellValue("Version (boolean)");
            stateRow.createCell(4).setCellValue("Promote (boolean)");
            stateRow.createCell(5).setCellValue("Checkout History (boolean)");
            stateRow.createCell(6).setCellValue("Users for Access");//
            stateRow.createCell(7).setCellValue("Access (use \"|\" delim)");//
            stateRow.createCell(8).setCellValue("Signatures (use \"|\" delim)");

            
            int iInit = stateSheet.getLastRowNum()+1;
            int userListSize = 0;
            for (int idx=0; idx < resultList.size(); idx++ )
            {
                String str = (String) resultList.get(idx);
                
                String s4 = MqlUtil.mqlCommand(context, "print policy '"+sPolicyName+"' select state["+ str +"].revisionable dump " + SELECT_SEPERATOR);
                String s5 = MqlUtil.mqlCommand(context, "print policy '"+sPolicyName+"' select state["+ str +"].versionable dump " + SELECT_SEPERATOR);
                String s6 = MqlUtil.mqlCommand(context, "print policy '"+sPolicyName+"' select state["+ str +"].autopromote dump " + SELECT_SEPERATOR);
                String s7 = MqlUtil.mqlCommand(context, "print policy '"+sPolicyName+"' select state["+ str +"].checkouthistory dump " + SELECT_SEPERATOR);
                
                
                String s8 = MqlUtil.mqlCommand(context, "print policy '"+sPolicyName+"' select state["+ str +"].owneraccess dump " + SELECT_SEPERATOR);                    
                String s9 = MqlUtil.mqlCommand(context, "print policy '"+sPolicyName+"' select state["+ str +"].publicaccess dump " + SELECT_SEPERATOR);                    
                String s10 = MqlUtil.mqlCommand(context, "print policy '"+sPolicyName+"' select state["+ str +"].user dump " + SELECT_SEPERATOR);
                String s11 = MqlUtil.mqlCommand(context, "print policy '"+sPolicyName+"' select state["+ str +"].signature dump " + SELECT_SEPERATOR);
                
                int iCurrentRow = iInit+idx;
                
                stateRow = stateSheet.createRow(iCurrentRow+userListSize);
                //Policy Name
                Cell cell = stateRow.createCell( 0 );
                cell.setCellValue( sPolicyName );
                cell.setCellStyle(cellStyle);
                
                //State Name
                cell = stateRow.createCell( 1 );
                cell.setCellValue( str );
                
                //Revision (boolean)
                cell = stateRow.createCell( 2 );
                cell.setCellValue( s4 );
                
                //Version (boolean)
                cell = stateRow.createCell( 3 );
                cell.setCellValue( s5 );
                
                //Promote (boolean)
                cell = stateRow.createCell( 4 );
                cell.setCellValue( s6 );
                                
                //Checkout History (boolean)
                cell = stateRow.createCell( 5 );
                cell.setCellValue( s7 );
                
                //Signatures (use "|" delim)
                cell = stateRow.createCell( 8 );
                cell.setCellValue( s11 );
                
              //Users for Access (use "|" delim)
                cell = stateRow.createCell( 6 );
                cell.setCellValue( "owneraccess" );
              //Signatures (use "|" delim)
                cell = stateRow.createCell( 7 );
                cell.setCellValue( s8 );
                
                stateRow = stateSheet.createRow(iCurrentRow+(userListSize+1));
                cell = stateRow.createCell( 6 );
                cell.setCellValue( "publicaccess" );
              //Signatures (use "|" delim)
                cell = stateRow.createCell( 7 );
                cell.setCellValue( s9 );
                
                StringList userList = FrameworkUtil.split( s10 , SELECT_SEPERATOR );
                
                for( int jdx = 0 ; jdx < userList.size() ; jdx++ ){
                	stateRow = stateSheet.createRow(iCurrentRow+(userListSize+2+jdx));
                    cell = stateRow.createCell( 6 );
                    cell.setCellValue( (String)userList.get(jdx) );
                  //Signatures (use "|" delim)
                    String userAccess = MqlUtil.mqlCommand(context, "print policy '"+sPolicyName+"' select state["+ str +"].access["+(String)userList.get(jdx)+"] dump " + SELECT_SEPERATOR);
                    cell = stateRow.createCell( 7 );
                    cell.setCellValue( userAccess );
                }
                
                stateSheet.addMergedRegion(new CellRangeAddress(iCurrentRow+userListSize,iCurrentRow+userListSize +1+userList.size(),1,1));
                stateSheet.addMergedRegion(new CellRangeAddress(iCurrentRow+userListSize,iCurrentRow+userListSize +1+userList.size(),2,2));
                stateSheet.addMergedRegion(new CellRangeAddress(iCurrentRow+userListSize,iCurrentRow+userListSize +1+userList.size(),3,3));
                stateSheet.addMergedRegion(new CellRangeAddress(iCurrentRow+userListSize,iCurrentRow+userListSize +1+userList.size(),4,4));
                stateSheet.addMergedRegion(new CellRangeAddress(iCurrentRow+userListSize,iCurrentRow+userListSize +1+userList.size(),5,5));
                userListSize =  userListSize +1+userList.size();
                
            }
            /*System.out.println("iInit="+iInit);
            System.out.println("userListSize="+userListSize);
            System.out.println("resultList.size()="+resultList.size());
            System.out.println("resultList.size()+(iInit-1)+userListSize="+(resultList.size()+(iInit-1)+userListSize));*/
            if( resultList.size() > 0 ){
	            stateSheet.addMergedRegion(new CellRangeAddress(
	                    iInit, //first row (0-based)
	                    resultList.size()+(iInit-1)+userListSize, //last row  (0-based)
	                    0, //first column (0-based)
	                    0  //last column  (0-based)
	                    ));
            }
            
            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        }
    }
    

    public static void getCommandExcel(Context context, String[] sNames , String type) throws Exception{
    	String sName = "";
    	String result = "";
        try {
            Sheet sheet = _wb.getSheet( "Command("+type+")" );
            Sheet sheet2 = _wb.getSheet("Command(Href)");
            if( sheet == null ){

                sheet = _wb.createSheet("Command("+type+")");
            }
            if( sheet2 == null ){
                sheet2 = _wb.createSheet("Command(Href)");
            }
            
            HSSFCellStyle cellStyle = (HSSFCellStyle)_wb.createCellStyle();
            cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

            int iInit =sheet.getLastRowNum()+1;
            int iInitHref =sheet2.getLastRowNum()+1;
            
            Row row = sheet.createRow(0);            
            Cell cell = row.createCell(0);
            cell.setCellValue(type+" Name");
            cell = row.createCell(1);
            cell.setCellValue("Command Name");
            cell = row.createCell(2);
            cell.setCellValue("Command Description");
            cell = row.createCell(3);
            cell.setCellValue("Command Label");
            cell = row.createCell(4);
            cell.setCellValue("Hidden (boolean)");
            cell = row.createCell(5);
            cell.setCellValue("Alt");
            

            for( int idx = 0 ; idx < 30 ; ){
	            cell = row.createCell(6+idx);
	            cell.setCellValue("Setting Name");
	            ++idx;
	            cell = row.createCell(6+idx);
	            cell.setCellValue("Setting Value");
	            ++idx;
            }
            cell = row.createCell(37);
            cell.setCellValue("User (use \"|\" delim)");
            
            row = sheet2.createRow(0);
            cell = row.createCell(0);
            cell.setCellValue("Command Name");
            cell = row.createCell(1);
            cell.setCellValue("Href");

            int iMergeStart = iInit;
            int iMergeEnd = iInit;
            String menuName = "";
            for (int i = 0; i < sNames.length; i++) {

                StringList sNamesList = FrameworkUtil.split( sNames[i] , "|" );
                sName = (String)sNamesList.get( 1 );
                result = MqlUtil.mqlCommand( context , "print command '" + (String)sNamesList.get( 1 ) + "' select name description label hidden alt href dump |" );
                StringList resultList = FrameworkUtil.split( result , "|" );
 

                int iCellNo = 0;
 
				if( StringUtils.isNotEmpty((String)resultList.get(5)) ){
	                Row row2 = sheet2.createRow(iInitHref);
	
	                Cell menuNameCell2 = row2.createCell( iCellNo );
	                menuNameCell2.setCellValue( (String)resultList.get(0) );
	 
	                Cell hrefCell = row2.createCell( ++iCellNo );
	                hrefCell.setCellValue( (String)resultList.get(5) );
	                ++iInitHref;
				}

                iCellNo = 0;
                row = sheet.createRow(iInit);
                Cell menuNameCell = row.createCell( iCellNo );//1
                menuNameCell.setCellValue( (String)sNamesList.get( 0 ) );
                menuNameCell.setCellStyle(cellStyle);
 

                Cell commandNameCell = row.createCell( ++iCellNo );//2

                commandNameCell.setCellValue( (String)resultList.get(0) );

                Cell descriptionCell = row.createCell( ++iCellNo );//3

                descriptionCell.setCellValue( (String)resultList.get(1) );
 

                Cell labelCell = row.createCell( ++iCellNo );//4

                labelCell.setCellValue( (String)resultList.get(2) );

                Cell hiddenCell = row.createCell( ++iCellNo );//6

                hiddenCell.setCellValue( (String)resultList.get(3) );
 

                Cell altCell = row.createCell( ++iCellNo );//7

                altCell.setCellValue( (String)resultList.get(4) );

                String settingName = MqlUtil.mqlCommand( context , "print command '" +(String)sNamesList.get( 1 ) + "' select setting.name dump" );
                String settingValue = MqlUtil.mqlCommand( context , "print command '" +(String)sNamesList.get( 1 ) + "' select setting.value dump" );
 

                StringList settingNameList = FrameworkUtil.split( settingName , "," );
                StringList settingValueList = FrameworkUtil.split( settingValue , "," );
 

                for( int jdx = 0 ; jdx < settingNameList.size() ; jdx++ ){

                    iCellNo = 6+(jdx*2);
                    Cell channelSettingNameCell = row.createCell( iCellNo );
                    iCellNo = 7+(jdx*2);
                    Cell channelSettingValueCell = row.createCell( iCellNo );
                    channelSettingNameCell.setCellValue( (String)settingNameList.get(jdx) );
                    channelSettingValueCell.setCellValue( (String)settingValueList.get(jdx) );
                }

 

                if( settingNameList.size() > 20 ){

                    System.out.println("===================================================");
                    System.out.println("COMMAND : "+(String)sNamesList.get( 1 ));
                    System.out.println("COMMAND Warning : Setting Size = "+ settingNameList.size());
                    System.out.println("===================================================");
                }

                String users = MqlUtil.mqlCommand( context , "print command '" +(String)sNamesList.get( 1 ) + "' select user dump |" );
                Cell userNameCell = row.createCell( 37 );
                userNameCell.setCellValue( users );

                if( i > 0 ){
                    iMergeEnd = iInit;
                    if( StringUtils.equals(menuName, (String)sNamesList.get( 0 ) ) == false ){
                        sheet.addMergedRegion(new CellRangeAddress(
                                iMergeStart, //first row (0-based)
                                iMergeEnd, //last row  (0-based)
                                1, //first column (0-based)
                                1  //last column  (0-based)
                                ));
                        iMergeStart = iMergeEnd+1;
                        menuName = (String)sNamesList.get( 0 );
                    }
                }else{
                    menuName = (String)sNamesList.get( 0 );
                }
                ++iInit;
                if( i > 0 && i%100==0 ){
                    System.out.println(i+" Items!!!");
                }
            }
            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
        } catch (Exception e) {
        	System.out.println("Error ==> sName="+sName);
        	System.out.println("Error ==> result="+result);
        	FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
            
            e.printStackTrace();
            throw e;
        }

    }

 

 

 

    public static void getTableExcel(Context context, String[] sNames) throws Exception{
        try {

            

            Sheet sheet = _wb.getSheet( "Table" );
            if( sheet == null ){
                sheet = _wb.createSheet("Table");
            }
            
            HSSFCellStyle cellStyle = (HSSFCellStyle)_wb.createCellStyle();
            cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);
            
            
            Row row = sheet.createRow(0);
            row.createCell(0).setCellValue("Table Name");
            row.createCell(1).setCellValue("Column Name");
            row.createCell(2).setCellValue("Column Description");
            row.createCell(3).setCellValue("Column Label");
            row.createCell(4).setCellValue("Column Expression Type");
            row.createCell(5).setCellValue("Column Expression");
            row.createCell(6).setCellValue("Column href");
            row.createCell(7).setCellValue("Column alt");
            row.createCell(8).setCellValue("Column range");
            row.createCell(9).setCellValue("Column update");
            
            
            

            for( int idx = 0 ; idx <= 40 ;){
	            row.createCell(10+idx).setCellValue("Setting Name");
	            ++idx;
	            row.createCell(10+idx).setCellValue("Setting Value");
	            ++idx;
            }
            
            row.createCell(51).setCellValue("roles");
            
            int iInit = sheet.getLastRowNum()+1;
            int iFirst = sheet.getLastRowNum()+1;

            UITable uiTableBean = new UITable();
            for (int i = 0; i < sNames.length; i++) {
            	
            	if( findRow(sheet,sNames[i]) ){
            		continue;
            	}
            	
                HashMap mapTableInfo = uiTableBean.getTable(context, sNames[i]);

                MapList columnList = (MapList)mapTableInfo.get("columns");
                Iterator columnItr = columnList.iterator();
                while (columnItr.hasNext()) {

                	int iCell = 0 ;
                    row = sheet.createRow(iInit);

                    Cell tNameCell = row.createCell( iCell );
                    tNameCell.setCellValue( sNames[i] );
                    tNameCell.setCellStyle(cellStyle);

                    HashMap columnMap = (HashMap) columnItr.next();

                    //StringList roles = (StringList) columnMap.get("roles");
                    String name = (String) columnMap.get("name");
                    Cell cNameCell = row.createCell( ++iCell );
                    cNameCell.setCellValue( name );

                    String sColumnDesc = uiTableBean.getDescription( columnMap );
                    Cell cDescCell = row.createCell( ++iCell );
                    cDescCell.setCellValue( sColumnDesc );

                    Cell cHeadCell = row.createCell( ++iCell );
                    cHeadCell.setCellValue( (String) columnMap.get("label") );

                    String expr = MqlUtil.mqlCommand(context, PRINT_TABLE+SINGLE_QUOTE+sNames[i]+SINGLE_QUOTE+SPACE+SYSTEM+SPACE+SELECT+SPACE+COLUMN+START_SQUARE_BRACKET+name+END_SQUARE_BRACKET+DOT+EXPRESSION+SPACE+DUMP);
                    String exprType = MqlUtil.mqlCommand(context, PRINT_TABLE+SINGLE_QUOTE+sNames[i]+SINGLE_QUOTE+SPACE+SYSTEM+SPACE+SELECT+SPACE+COLUMN+START_SQUARE_BRACKET+name+END_SQUARE_BRACKET+DOT+EXPRESSIONTYPE+SPACE+DUMP);

                    Cell cExprTypeCell = row.createCell( ++iCell );
                    cExprTypeCell.setCellValue( exprType );

                    Cell cExprCell = row.createCell( ++iCell );
                    cExprCell.setCellValue( expr );

                    Cell cHrefCell = row.createCell( ++iCell );
                    cHrefCell.setCellValue( (String) columnMap.get("href") );

                    Cell cAltCell = row.createCell( ++iCell );
                    cAltCell.setCellValue( (String) columnMap.get("alt") );

                    Cell cRangeCell = row.createCell( ++iCell );
                    cRangeCell.setCellValue( (String) columnMap.get("range") );

                    String update = MqlUtil.mqlCommand(context, PRINT_TABLE+SINGLE_QUOTE+sNames[i]+SINGLE_QUOTE+SPACE+SYSTEM+SPACE+SELECT+SPACE+COLUMN+START_SQUARE_BRACKET+name+END_SQUARE_BRACKET+DOT+UPDATE+SPACE+DUMP);

                    Cell cUpdateCell = row.createCell( ++iCell );
                    cUpdateCell.setCellValue( update );
 
                    HashMap settings = (HashMap)columnMap.get(SETTINGS);
                    if( settings != null && settings.size() > 0) {

                        Iterator settingItr = settings.keySet().iterator();
                        int k = 0;
                        while(settingItr.hasNext())

                        {

                            String settingName = (String)settingItr.next();
                            String settingValue = (String)settings.get(settingName);
                            //12
                            Cell cSettingNameCell = row.createCell( iCell+1+(k*2) );
                            cSettingNameCell.setCellValue( settingName );
                            Cell cSettingValueCell = row.createCell( iCell+2+(k*2) );
                            cSettingValueCell.setCellValue( settingValue );
                            ++k;

                        }

                        if( settings.size() > 20 ){
                            System.out.println("===================================================");
                            System.out.println("TABLE : "+sNames[i]);
                            System.out.println("TABLE Warning : Setting Size = "+ settings.size());
                            System.out.println("===================================================");
                        }

                    }

 

                    StringList roles = (StringList) columnMap.get("roles");
                    if( roles != null && roles.size() > 0 )

                    {
                        int jdx = 0;
                        for (Iterator roleItr = roles.iterator(); roleItr.hasNext();jdx++) {

                            String sRole = (String) roleItr.next();
                            Cell userNameCell = row.createCell( 51+jdx );
                            userNameCell.setCellValue( sRole );
                            if( jdx > 200 ){

                                userNameCell = row.createCell( 51+jdx+1 );
                                userNameCell.setCellValue( "..." );
                                break;
                            }
                        }

                    }

                    ++iInit;
                }
                sheet.addMergedRegion(new CellRangeAddress(
                        iFirst, //first row (0-based)
                        columnList.size()+(iFirst-1), //last row  (0-based)
                        0, //first column (0-based)
                        0  //last column  (0-based)
                        ));
 

/*
                sheet.addMergedRegion(new CellRangeAddress(
                        iFirst, //first row (0-based)
                        columnList.size()+(iFirst-1), //last row  (0-based)
                        1, //first column (0-based)
                        1  //last column  (0-based)
                        ));
*/
                iFirst = iFirst + columnList.size();
                if( i > 0 && i%100==0 ){
                    System.out.println(i+" Items!!!");
                }

            }

        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        } finally {

            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
        }

    }

 

 

    public static void getFormExcel(Context context, String[] sNames) throws Exception{

 

        try {

            Sheet sheet = _wb.getSheet( "Form" );
            if( sheet == null ){
                sheet = _wb.createSheet("Form");
            }

            
            HSSFCellStyle cellStyle = (HSSFCellStyle)_wb.createCellStyle();
            cellStyle.setVerticalAlignment(CellStyle.VERTICAL_CENTER);

            Row row = sheet.createRow(0);
            row.createCell(0).setCellValue("Form Name");
            row.createCell(1).setCellValue("Field Name");
            row.createCell(2).setCellValue("Field Description");
            row.createCell(3).setCellValue("Field Label");
            row.createCell(4).setCellValue("Field Expression Type");
            row.createCell(5).setCellValue("Field Expression");
            row.createCell(6).setCellValue("Field href");
            row.createCell(7).setCellValue("Field alt");
            row.createCell(8).setCellValue("Field range");
            row.createCell(9).setCellValue("Field update");
            


            for( int idx = 0 ; idx <= 40 ;){
	            row.createCell(10+idx).setCellValue("Setting Name");
	            ++idx;
	            row.createCell(10+idx).setCellValue("Setting Value");
	            ++idx;
            }
            
            row.createCell(51).setCellValue("roles");
            

            int iInit = sheet.getLastRowNum()+1;
            int iFirst = sheet.getLastRowNum()+1;

            UIForm uiFormBean = new UIForm();
            for (int i = 0; i < sNames.length; i++) {
            	
            	if( findRow(sheet,sNames[i]) ){
            		continue;
            	}
            	
                HashMap mapTableInfo = uiFormBean.getForm(context, sNames[i]);

                MapList columnList = (MapList)mapTableInfo.get("fields");
                Iterator columnItr = columnList.iterator();
                while (columnItr.hasNext()) {

                	int iCell = 0;
                    row = sheet.createRow(iInit);

                    Cell tNameCell = row.createCell( iCell );
                    tNameCell.setCellValue( sNames[i] );
                    tNameCell.setCellStyle(cellStyle);
 

                    HashMap columnMap = (HashMap) columnItr.next();
 

                    //StringList roles = (StringList) columnMap.get("roles");
                    String name = (String) columnMap.get("name");
                    Cell cNameCell = row.createCell( ++iCell );
                    cNameCell.setCellValue( name );
 

                    String sColumnDesc = uiFormBean.getDescription( columnMap );
                    Cell cDescCell = row.createCell( ++iCell );
                    cDescCell.setCellValue( sColumnDesc );
 

 

                    Cell cHeadCell = row.createCell( ++iCell );
                    cHeadCell.setCellValue( (String) columnMap.get("label") );
 

                    String expr = MqlUtil.mqlCommand(context, PRINT_FORM+SINGLE_QUOTE+sNames[i]+SINGLE_QUOTE+SPACE+SELECT+SPACE+FIELD+START_SQUARE_BRACKET+name+END_SQUARE_BRACKET+DOT+EXPRESSION+SPACE+DUMP);
                    String exprType = MqlUtil.mqlCommand(context, PRINT_FORM+SINGLE_QUOTE+sNames[i]+SINGLE_QUOTE+SPACE+SELECT+SPACE+FIELD+START_SQUARE_BRACKET+name+END_SQUARE_BRACKET+DOT+EXPRESSIONTYPE+SPACE+DUMP);
 

                    Cell cExprTypeCell = row.createCell( ++iCell );
                    cExprTypeCell.setCellValue( exprType );
 

                    Cell cExprCell = row.createCell( ++iCell );
                    cExprCell.setCellValue( expr );
 

                    Cell cHrefCell = row.createCell( ++iCell );
                    cHrefCell.setCellValue( (String) columnMap.get("href") );
 

                    Cell cAltCell = row.createCell( ++iCell );
                    cAltCell.setCellValue( (String) columnMap.get("alt") );
 

                    Cell cRangeCell = row.createCell( ++iCell );
                    cRangeCell.setCellValue( (String) columnMap.get("range") );
 

                    String update = MqlUtil.mqlCommand(context, PRINT_FORM+SINGLE_QUOTE+sNames[i]+SINGLE_QUOTE+SPACE+SELECT+SPACE+FIELD+START_SQUARE_BRACKET+name+END_SQUARE_BRACKET+DOT+UPDATE+SPACE+DUMP);
 

                    Cell cUpdateCell = row.createCell( ++iCell );
                    cUpdateCell.setCellValue( update );
 

                    HashMap settings = (HashMap)columnMap.get(SETTINGS);
                    if( settings != null && settings.size() > 0) {

                        Iterator settingItr = settings.keySet().iterator();
                        int k = 0;
                        while(settingItr.hasNext())
                        {
                            String settingName = (String)settingItr.next();
                            String settingValue = (String)settings.get(settingName);
                            //12

                            Cell cSettingNameCell = row.createCell( iCell+1+(k*2) );
                            cSettingNameCell.setCellValue( settingName );
                            Cell cSettingValueCell = row.createCell( iCell+2+(k*2) );
                            cSettingValueCell.setCellValue( settingValue );
                            ++k;
                        }

                        if( settings.size() > 20 ){
                            System.out.println("===================================================");
                            System.out.println("TABLE : "+sNames[i]);
                            System.out.println("TABLE Warning : Setting Size = "+ settings.size());
                            System.out.println("===================================================");
                        }
                    }

                    StringList roles = (StringList) columnMap.get("roles");
                    if( roles != null && roles.size() > 0 )
                    {
                        int jdx = 0;
                        for (Iterator roleItr = roles.iterator(); roleItr.hasNext();jdx++) {

                            String sRole = (String) roleItr.next();
                            Cell userNameCell = row.createCell( 51+jdx );
                            userNameCell.setCellValue( sRole );
                            if( jdx > 200 ){

                                userNameCell = row.createCell( 51+jdx+1 );
                                userNameCell.setCellValue( "..." );
                                break;
                            }
                        }
                    }
                    ++iInit;
                }

 

                sheet.addMergedRegion(new CellRangeAddress(
                        iFirst, //first row (0-based)
                        columnList.size()+(iFirst-1), //last row  (0-based)
                        0, //first column (0-based)
                        0  //last column  (0-based)
                        ));

                iFirst = iFirst + columnList.size();

                if( i > 0 && i%100==0 ){
                    System.out.println(i+" Items!!!");
                }

            }

        } catch (Exception e) {

            e.printStackTrace();
            throw e;
        } finally {

            FileOutputStream fileOut = new FileOutputStream(_fileName);
            _wb.write(fileOut);
            fileOut.close();
        }

    }



	private Document xmlDocumentParse(Context context , String filePath)
			throws FileNotFoundException, UnsupportedEncodingException,
			JDOMException, IOException, Exception {
		try{
			Document doc;
			SAXBuilder sax 			= new SAXBuilder();
			System.out.println("filePath="+filePath);
			File file = new File(filePath);
			InputStream inputStream= new FileInputStream(file);
			Reader reader = new InputStreamReader(inputStream,"UTF-8");
	
			InputSource is = new InputSource(reader);
			is.setEncoding("UTF-8");
			doc					= sax.build( is );
			return doc;
		}catch(Exception ex){
			try {
			} catch (Exception e) {
				e.printStackTrace();
			}
			ex.printStackTrace();
			throw ex;
		}
	}

 

    public String sortTest(Context context , String[] args ) throws Exception{
    	try{
    		XMLOutputter outputer = new XMLOutputter();
    		Document doc			= xmlDocumentParse(context,"D:\\Noname3.xml");
    		List<Element> pathList = (List<Element>)XPath.selectNodes(doc.getRootElement(),"/log/logentry/paths/path");
    		for( Element element : pathList){
    			
    			if( StringUtils.equalsIgnoreCase( element.getAttributeValue("action") ,"D" ) ){
    				outputer.output(element, System.out);
    				System.out.println("");
    			}
    		}
    	}catch(Exception ex){
    		ex.printStackTrace();
    	}
    	return "TEST";
    	
    }
    
    
    
    
    public static void userColumnModify(Context context , String[] args) throws Exception{
		try {
			
			//print table APPNonVersionableFileSummary system select column[].setting[format].value dump;
	        String ret1 = MqlUtil.mqlCommand( context , "list table system '*' select name dump recordseparator ," );
	        String[] paramArgs = StringUtils.split( ret1 , "," );
	        for( int idx = 0 ; idx < paramArgs.length ; idx++ ){	        	
	        	String ret2 = MqlUtil.mqlCommand( context , "print table '"+paramArgs[idx]+"' system select column[].setting[format].value" );	        	
	        	if( StringUtils.isNotEmpty(ret2) && StringUtils.contains(ret2, "user")){
	        		
	        		TEMP_DIR = "D:\\Export";
        			getTableMQL(context, paramArgs[idx]);
	        		
	        		StringList paramArgs2 = FrameworkUtil.split( ret2 , "\n" );
	        		paramArgs2.remove(0);
	        		for(int jdx=0 ; jdx < paramArgs2.size() ; jdx++ ){
	        			String columnName = (String)paramArgs2.get(jdx);
	        			columnName = StringUtils.trim(columnName);
	        			
	        			if( ((String)FrameworkUtil.split(columnName, "=").get(1)).trim().equalsIgnoreCase("user")  &&
	        				 ((String)FrameworkUtil.split(columnName, "=").get(0)).trim().contains("setting[format]") ){
	        				System.out.println("columnName="+columnName);
	        				columnName = (String)FrameworkUtil.split(columnName, "=").get(0);
	        				columnName = StringUtils.trim(columnName);
		        			columnName = FrameworkUtil.findAndReplace(columnName, "column[", "");
		        			columnName = FrameworkUtil.findAndReplace(columnName, "].setting[format].value", "");
		        			
		        			String mql = "modify table '"+paramArgs[idx]+"' system column modify name '"+columnName+"' sorttype other add setting 'Sort Program' 'emxSortPersonFullName' remove setting format add setting format user";
		        			System.out.println("mql="+mql);
		        			MqlUtil.mqlCommand( context , mql);
	        			}
	        		}
	        		
	        		TEMP_DIR = "C:\\Projects\\CJ2\\cjpin\\src\\mql\\08.table";
        			getTableMQL(context, paramArgs[idx]);
	        	}
	        }
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
    private final static HashMap<String,Integer> typeMap = new HashMap<String,Integer>();
    static{
    	typeMap.put("menu",1);
    	typeMap.put("command",2); 
    }
    
    /**
     * 모듈별 메뉴관리를 위한 상위 Menu 정보를 가져옴 (posTopMenuMap하위 1레벨)
     * @param context
     * @param args
     * @return
     * @throws Exception
     */
    public MapList getRootMenuMap(Context context , String[] args ) throws Exception {
    	try {
    		
    		String topMenu = "AEFGlobalToolbar";
    		
    		HashMap menu = UIMenu.getMenu(context, topMenu);
        	MapList menuMapList = (MapList)menu.get("children");
        	MapList retList = new MapList();
        	for(Object child : menuMapList){
	    		String type = (String)((Map)child).get("type");
	    		String name = (String)((Map)child).get("name");	 
	    		
	    		
	    		switch (typeMap.get(type)) {
				case 1:
					
					HashMap childMenu = UICache.getMenu(context, name);
					HashMap childMenuSettings = (HashMap)childMenu.get("settings");
					childMenu.put("id", (String)childMenu.get("name"));
					childMenu.put("Name", (String)childMenu.get("name"));
					childMenu.put("id[connection]", type+":"+name+"~1");						
					childMenu.put("level", "1");
					
					childMenu.put("Description", FrameworkUtil.findAndReplace((String)childMenu.get("description"), "<br/>", "\n") );
					if( childMenu.containsKey("children")){
						MapList mapList = (MapList)childMenu.get("children");
						childMenu.remove("children");
						childMenu.put("hasChildren", "true");
					}else{
						childMenu.put("hasChildren", "false");
					}
					childMenu.put("Note", (String)childMenuSettings.get("Note") );
					childMenu.put("pageNo", (String)childMenuSettings.get("pageNo") );
					retList.add(childMenu);
					
					HashMap paramMap = new HashMap();
					paramMap.put("objectId",(String)childMenu.get("name"));
					paramMap.put("relId",type+":"+topMenu+":"+(String)childMenu.get("name") + "~"+"1");
					paramMap.put("expandLevel","99");					
					
					retList.addAll( getMenuMapBase(context , JPO.packArgs(paramMap) ) );
					
					break;
				case 2:
					HashMap command = UICache.getCommand(context, name);					
					HashMap commandSettings = (HashMap)command.get("settings");
					
					command.put("id", (String)command.get("name") );
					command.put("id[connection]", type+":"+name+"~1");
					command.put("Name", (String)command.get("name") );
					
					command.put("Description", FrameworkUtil.findAndReplace((String)command.get("description"), "<br/>", "\n") );
					
					
					if( command.containsKey("children")){
						MapList mapList = (MapList)command.get("children");
						command.remove("children");
						command.put("hasChildren", "true");
					}else{
						command.put("hasChildren", "false");
					}
					
					command.put("Note", (String)commandSettings.get("Note") );
					command.put("pageNo", (String)commandSettings.get("pageNo") );
					
					command.put("level", "1");
					retList.add(command);
					break;
				default:
					break;
				}
	    		
        	}
        	for(int idx = 0 ; idx < retList.size(); idx++){
        		System.out.println(((Map)retList.get(idx)).get("id")+":"+((Map)retList.get(idx)).get("id[connection]"));
        	}
			return retList;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    }
    
    

    /**
     * 각 모듈별 Tree Menu를 가져오는 함수
     * expandLevel적용하여 가져옴
     * @param context
     * @param args
     * @return
     * @throws Exception
     */
    public MapList getMenuMapBase(Context context , String[] args ) throws Exception {
    	try {
    		
    		HashMap programMap = (HashMap)JPO.unpackArgs(args);
    		String expandLevel = (String)programMap.get("expandLevel");
    		if( StringUtils.equalsIgnoreCase(expandLevel, "All") ){
    			expandLevel = "99";
    		}
    		String menuName = (String)programMap.get("objectId");
    		String relId = (String)programMap.get("relId");    		
    		String level = (String) FrameworkUtil.split(relId, "~").get(1);
    		String nextLevel = String.valueOf( NumberUtils.createInteger(level)+1 );
    		String nextExpandLevel = String.valueOf( NumberUtils.createInteger(expandLevel)-1 );
    		
    		String baseLevel = (String)programMap.get("baseLevel");
    		if( StringUtils.isEmpty(baseLevel)){
    			baseLevel = level;
    		}
    		
    		HashMap menu = UICache.getMenu(context, menuName);
    		if( menu == null) { 
    			menu = UICache.getCommand(context, menuName);
    		}
	    	MapList menuChild = (MapList)menu.get("children");
	    	
	    	
	    	MapList retList = new MapList();
	    	if( menuChild != null){
		    	for(Object child : menuChild){
		    		String type = (String)((Map)child).get("type");
		    		String name = (String)((Map)child).get("name");
		    		
		    		switch (typeMap.get(type)) {
					case 1:
						
						HashMap childMenu = UICache.getMenu(context, name);
						HashMap childMenuSettings = (HashMap)childMenu.get("settings");
						
						
						childMenu.put("id", (String)childMenu.get("name"));
						childMenu.put("id[connection]", type+":"+menuName+":"+name + "~"+nextLevel );						
						childMenu.put("Name", (String)childMenu.get("name"));
						childMenu.put("Note", (String)childMenuSettings.get("Note") );
						childMenu.put("pageNo", (String)childMenuSettings.get("pageNo") );
						if( StringUtils.isEmpty((String)programMap.get("baseLevel")) ){
							childMenu.put("level","1");
			    		}else{
			    			childMenu.put("level",level);
			    		}
						childMenu.put("Description", FrameworkUtil.findAndReplace((String)childMenu.get("description"), "<br/>", "\n") );
						if( childMenu.containsKey("children")){
							MapList mapList = (MapList)childMenu.get("children");
							childMenu.remove("children");
							childMenu.put("hasChildren", "true");
						}else{
							childMenu.put("hasChildren", "false");
						}
						
						String accessMask = StringUtils.defaultIfEmpty( (String)childMenuSettings.get("Access Mask") , "" );
						String accessExpression = StringUtils.defaultIfEmpty( (String)childMenuSettings.get("Access Expression") , "" );
						String accessProgram = StringUtils.defaultIfEmpty( (String)childMenuSettings.get("Access Program") , "" );
						String accessFunction = StringUtils.defaultIfEmpty( (String)childMenuSettings.get("Access Function") , "" );
						
						childMenu.put("AccessMask", accessMask);
						childMenu.put("AccessExpression", accessExpression);
						if( StringUtils.isNotEmpty(accessProgram) ){
							childMenu.put("AccessProgram", accessProgram+":"+accessFunction);
						}
						
						retList.add(childMenu);
						
						
						
						if( NumberUtils.createInteger(nextLevel)-NumberUtils.createInteger(baseLevel) < NumberUtils.createInteger(expandLevel) ){
							HashMap paramMap = new HashMap();
							paramMap.put("objectId",(String)childMenu.get("name"));
							paramMap.put("relId",type+":"+menuName+":"+name + "~"+nextLevel);
							paramMap.put("expandLevel",nextExpandLevel);
							paramMap.put("baseLevel",baseLevel);
							
							retList.addAll( getMenuMapBase(context , JPO.packArgs(paramMap) ) );
						}
						
						
						//Issue와 Punch List가 동일한 Tree Menu를 사용하기 때문에 프로그램로직으로 Punch List를 추가한다.
						if( StringUtils.equalsIgnoreCase(name, "type_Issue")){
							HashMap tmpChildMenu = new HashMap();
							tmpChildMenu.putAll(childMenu);
							tmpChildMenu.put("Name", "");
							tmpChildMenu.put("id[connection]", type+":"+menuName+":"+"Punch" + "~"+nextLevel );
							tmpChildMenu.put("label", "emxProgramCentral.Common.Punch");
							
							accessMask = StringUtils.defaultIfEmpty( (String)childMenuSettings.get("Access Mask") , "" );
							accessExpression = StringUtils.defaultIfEmpty( (String)childMenuSettings.get("Access Expression") , "" );
							accessProgram = StringUtils.defaultIfEmpty( (String)childMenuSettings.get("Access Program") , "" );
							accessFunction = StringUtils.defaultIfEmpty( (String)childMenuSettings.get("Access Function") , "" );
							
							childMenu.put("AccessMask", accessMask);
							childMenu.put("AccessExpression", accessExpression);
							if( StringUtils.isNotEmpty(accessProgram) ){
								tmpChildMenu.put("AccessProgram", accessProgram+":"+accessFunction);
							}
							
							retList.add(tmpChildMenu);
							
							if( NumberUtils.createInteger(nextLevel)-NumberUtils.createInteger(baseLevel) < NumberUtils.createInteger(expandLevel) ){
								HashMap paramMap = new HashMap();
								paramMap.put("objectId",(String)childMenu.get("name"));
								paramMap.put("relId",type+":"+menuName+":"+name + "~"+nextLevel);
								paramMap.put("expandLevel",nextExpandLevel);
								paramMap.put("baseLevel",baseLevel);
								
								retList.addAll( getMenuMapBase(context , JPO.packArgs(paramMap) ) );
							}
			    			
				    	}
						
						break;
					case 2:
						HashMap command = UICache.getCommand(context, name);
						HashMap commandSettings = (HashMap)command.get("settings");
						
				    	
						
						//Issue와 Punch List가 동일한 Tree Menu를 사용하기 때문에 프로그램으로 Command를 구분해야한다.
				    	if( StringUtils.equalsIgnoreCase(menuName, "type_Issue") ){
				    		
				    		StringList relList = FrameworkUtil.split(relId, ":");
				    		String parenName = (String)FrameworkUtil.split( (String)relList.get(relList.size()-1) , "~").get(0);

				    		if( StringUtils.equalsIgnoreCase(parenName, "Punch")){

				    			if( commandSettings.containsValue("attribute[posIssueType] != 'Punch'") == false ){
				    				continue;
					    		}
					    		
				    		} else if( StringUtils.equalsIgnoreCase(parenName, "type_Issue")){
				    			if( commandSettings.containsValue("type == Issue && attribute[posIssueType] == 'Punch'")==false ){
					    			continue;
					    		}
				    		}
				    	}
				    	
				    	accessMask = StringUtils.defaultIfEmpty( (String)commandSettings.get("Access Mask") , "" );
						accessExpression = StringUtils.defaultIfEmpty( (String)commandSettings.get("Access Expression") , "" );
						accessProgram = StringUtils.defaultIfEmpty( (String)commandSettings.get("Access Program") , "" );
						accessFunction = StringUtils.defaultIfEmpty( (String)commandSettings.get("Access Function") , "" );
						
						command.put("AccessMask", accessMask);
						command.put("AccessExpression", accessExpression);
						if( StringUtils.isNotEmpty(accessProgram) ){
							command.put("AccessProgram", accessProgram+":"+accessFunction);
						}

						
						command.put("id", (String)command.get("name") );
						command.put("id[connection]", type+":"+menuName+":"+name  + "~"+nextLevel);
						command.put("Name", (String)command.get("name") );
						command.put("Note", (String)commandSettings.get("Note") );
						command.put("pageNo", (String)commandSettings.get("pageNo") );
						command.put("Description", FrameworkUtil.findAndReplace((String)command.get("description"), "<br/>", "\n") );
						if( command.containsKey("children")){
							MapList mapList = (MapList)command.get("children");
							command.remove("children");
							command.put("hasChildren", "true");
						}else{
							command.put("hasChildren", "false");
						}
						
						String ret = MqlUtil.mqlCommand(context, "print "+type + " '" + name + "' select user dump ,");
						command.put("User", ret);

						if( StringUtils.isEmpty((String)programMap.get("baseLevel")) ){
							command.put("level","1");
			    		}else{
			    			command.put("level",level);
			    		}
						
						
						
						
						HashMap settings = (HashMap)command.get("settings");
						String registeredSuite = (String)settings.get("Registered Suite");
						String resource = UINavigatorUtil.getStringResourceFileId(registeredSuite);
						String displyaLabel = i18nNow.getI18nString((String)command.get("label"), resource,  context.getSession().getLanguage());
						
						if( StringUtils.equalsIgnoreCase(displyaLabel, "History")||StringUtils.equalsIgnoreCase(displyaLabel, "Lifecycle") ){
							continue;
						}
							
						
						retList.add(command);
						break;
					default:
						break;
					}
		    	}
	    	}
	        	
			return retList;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
    }
    
    
    
    public static void policyModify(Context context , String[] args) throws Exception{
		try {
			
			//print table APPNonVersionableFileSummary system select column[].setting[format].value dump;
	        String ret1 = MqlUtil.mqlCommand( context , "list policy '*' select name store dump | " );
	        String[] paramArgs = StringUtils.split( ret1 , "\n" );
	        for( int idx = 0 ; idx < paramArgs.length ; idx++ ){
	        	if( FrameworkUtil.split(paramArgs[idx], "|").size() < 2 ){
	        		String name = (String)FrameworkUtil.split(paramArgs[idx], "|").get(0);
	        		String mql = "modify policy '"+name+"' store STORE";
        			System.out.println("mql="+mql);
        			MqlUtil.mqlCommand( context , mql);        			
	        	}
	        }
	        
	        ret1 = MqlUtil.mqlCommand( context , "list policy '*' select name format dump | " );
	        paramArgs = StringUtils.split( ret1 , "\n" );	        	
	        for( int idx = 0 ; idx < paramArgs.length ; idx++ ){
	        	if( FrameworkUtil.split(paramArgs[idx], "|").size() < 2 ){
	        		String name = (String)FrameworkUtil.split(paramArgs[idx], "|").get(0);
	        		String mql = "modify policy '"+name+"' add format generic";
        			System.out.println("mql="+mql);
        			MqlUtil.mqlCommand( context , mql);
	        		
	        	}if( FrameworkUtil.split(paramArgs[idx], "|").size() >= 2 ){
	        		if( FrameworkUtil.split(paramArgs[idx], "|").contains("generic") == false ){
	        			String name = (String)FrameworkUtil.split(paramArgs[idx], "|").get(0);
	        			String mql = "modify policy '"+name+"' add format generic";
	        			System.out.println("mql="+mql);
	        			MqlUtil.mqlCommand( context , mql);	        			
	        		}
	        	}
	        }
	        			
	        
	        
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
    
}