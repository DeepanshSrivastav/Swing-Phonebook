/*
 ** ${CLASS:MarketingFeature}
 **
 ** Copyright (c) 1993-2015 Dassault Systemes. All Rights Reserved.
 ** This program contains proprietary and trade secret information of
 ** Dassault Systemes.
 ** Copyright notice is precautionary only and does not evidence any actual
 ** or intended publication of such program
 */

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.StringTokenizer;

import com.mando.util.cdmConstantsUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkProperties;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.engineering.EngineeringUtil;

import matrix.db.Access;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.StringList;

/**
 * The <code>emxENCActionLinkAcess</code> class contains code for the "Action Link".
 *
 * @version EC 10.5 - Copyright (c) 2002, MatrixOne, Inc.
 */
public class emxENCActionLinkAccess_mxJPO extends emxENCActionLinkAccessBase_mxJPO
{
    /**
     * Constructor.
     *
     * @param context the eMatrix <code>Context</code> object.
     * @param args holds no arguments.
     * @throws Exception if the operation fails.
     * @since EC 10.5
     */
    public emxENCActionLinkAccess_mxJPO (Context context, String[] args)
        throws Exception
    {
        super(context, args);
    }
    
    /**
     * To Show Apply link in EBOM emxTable/Indented  Table
     * based on the state of the Parent assembly Part
     * @param context the eMatrix <code>Context</code> object.
     * @param args holds objectId.
     * @return Boolean.
     * @throws Exception If the operation fails.
     * @since X+3.
     * @author jh.Lee
     */
    
    @SuppressWarnings({ "deprecation" })
	public Boolean isApplyAllowed (Context context, String[] args) throws Exception {
        boolean allowApply = false;
        try {
            HashMap paramMap = (HashMap)JPO.unpackArgs(args);
            String parentId      = (String) paramMap.get("objectId");
            
            //modified as per changes for bug 311050
            //check the parent obj state
            StringList strList  = new StringList(4);
            strList.add(SELECT_CURRENT);
            strList.add(SELECT_POLICY);
            strList.add(SELECT_REVISION);
            strList.add("last.revision");

            DomainObject domObj = new DomainObject(parentId);
            Map map = domObj.getInfo(context,strList);

            String objState    = (String)map.get(SELECT_CURRENT);
            String objPolicy   = (String)map.get(SELECT_POLICY);
            String objRev      = (String)map.get(SELECT_REVISION);
            String objLastRev  = (String)map.get("last.revision");

            String propAllowLevel = null;

            matrix.db.Access mAccess = domObj.getAccessMask(context);
           
            //371781 - modified the if else condition to check for PolicyClassification instead of Policy
            String policyClassification = EngineeringUtil.getPolicyClassification(context, objPolicy);
            Locale strLocale = new Locale(context.getSession().getLanguage());
            
            if (mAccess.has(Access.cModify)) {
            	if (cdmConstantsUtil.TEXT_PRODUCTION.equalsIgnoreCase(policyClassification)) {
            		propAllowLevel = (String)FrameworkProperties.getProperty(context, "emxEngineeringCentral.ECPart.AllowApply");
            	}else if ("Development".equalsIgnoreCase(policyClassification)) {
            		propAllowLevel = (String)FrameworkProperties.getProperty(context, "emxEngineeringCentral.DevelopmentPart.AllowApply");
            	}else if ("Unresolved".equalsIgnoreCase(policyClassification)) {
            		propAllowLevel = (String)FrameworkProperties.getProperty(context, "emxUnresolvedEBOM.ConfiguredPart.AllowApply");
            	}

            	StringList propAllowLevelList = new StringList();
            	if (propAllowLevel != null && !"null".equals(propAllowLevel) && propAllowLevel.length() > 0) {
            		StringTokenizer stateTok = new StringTokenizer(propAllowLevel, ",");
            		while (stateTok.hasMoreTokens()) {
            			String tok = (String)stateTok.nextToken();
            			propAllowLevelList.add(FrameworkUtil.lookupStateName(context, objPolicy, tok));
            		}
            	}
            	
            	allowApply = propAllowLevelList.contains(objState);

            	//371781 - Modified to check for PolicyClassification instead of Policy
            	if (allowApply && cdmConstantsUtil.TEXT_PRODUCTION.equalsIgnoreCase(policyClassification)) {
            		String strIsVersion = domObj.getInfo(context, "attribute[" + PropertyUtil.getSchemaProperty(context,"attribute_IsVersionObject") + "]");

            		if((! objRev.equals(objLastRev) || "True".equals(strIsVersion)) && (! DomainConstants.STATE_PART_PRELIMINARY.equals(objState))) {
            			allowApply = false;
            		}
            	}
 		   	}
            
            //end of changes
        } catch (Exception e) {
        	throw new Exception(e.toString());
        }
        return Boolean.valueOf(allowApply);
    }
    
    
    
    /**
     * Checking if modification is allowed for this object.
     *
     * @param context the eMatrix <code>Context</code> object.
     * @param args holds objectId.
     * @return Boolean.
     * @throws Exception If the operation fails.
     * @since EC10-5.
     *
     */
    public Boolean isModificationAllowed(Context context, String[] args) throws Exception {
    	//Added below code for the bug 288183
    	boolean allowChanges = true;
    	String strPartFamilyRef= PropertyUtil.getSchemaProperty(context,"relationship_PartFamilyReference");
    	try{
    		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
             
            String parentId  = DomainConstants.EMPTY_STRING;
             
            // Specific check for RMB button
            String rmbTableRowId = (String) paramMap.get("rmbTableRowId");
             
            // The If condition is added specifically for a Right Mouse Button Usecase 
            if (rmbTableRowId != null && !"".equals(rmbTableRowId)) {
                StringList slList = FrameworkUtil.split(rmbTableRowId, "|");
       	      
                // This check is for cases where its not a structure browser
                // and the rmbTableRowId is in different format      
                if (slList.size() == 3) {
             	    parentId = (String) slList.get(0);
                } else if (slList.size() == 4) {
                	parentId = (String) slList.get(1);
                } else if (slList.size() == 2) {
                	parentId = (String) slList.get(1);
                } else {
                	parentId = rmbTableRowId;
                }
               
            } else {
             	parentId = (String) paramMap.get("objectId");	
            }
             
            String obsoleteState = PropertyUtil.getSchemaProperty(context, "policy",DomainConstants.POLICY_EC_PART, "state_Obsolete");
            String approvedState  = PropertyUtil.getSchemaProperty(context, "policy",DomainConstants.POLICY_EC_PART, "state_Approved");
            String PendingObsoleteState  = PropertyUtil.getSchemaProperty(context, "policy",DomainConstants.POLICY_MANUFACTURER_EQUIVALENT, "state_PendingObsolete");

            //check the parent obj state
            StringList strList  = new StringList(2);
            strList.add(SELECT_TYPE);
            strList.add(SELECT_CURRENT);
            strList.add("policy");
            strList.add(SELECT_OWNER); //Added code for the bug 346336

            DomainObject domObj = new DomainObject(parentId);

            String sMEPPolicy = PropertyUtil.getSchemaProperty(context,"policy_ManufacturerEquivalent");//Added code for the bug 346336

            Map map = domObj.getInfo(context,strList);

            String objType = (String)map.get(SELECT_TYPE);
            String objState = (String)map.get(SELECT_CURRENT);
            String objPolicy = (String)map.get("policy");
            String objOwner = (String)map.get(SELECT_OWNER);//Added code for the bug 346336
            String policyClass = EngineeringUtil.getPolicyClassification(context,objPolicy);
            String propAllowLevel = (String)FrameworkProperties.getProperty(context, "emxEngineeringCentral.Part.RestrictPartEdit");
            StringList propAllowLevelList = new StringList();

            if(propAllowLevel != null && !"null".equals(propAllowLevel) && propAllowLevel.length() > 0) {
            	StringTokenizer stateTok = new StringTokenizer(propAllowLevel, ",");
            	while (stateTok.hasMoreTokens()) {
            		String tok = (String)stateTok.nextToken();
            		propAllowLevelList.add(FrameworkUtil.lookupStateName(context, objPolicy, tok));
            	}
            }
            	
            if("Production".equals(policyClass)){
            	if(DomainConstants.TYPE_PART.equals(objType)){
            		allowChanges = (DomainConstants.STATE_PART_PRELIMINARY.equals(objState));
            	}else{
            		allowChanges = (! propAllowLevelList.contains(objState));	
            		if(! DomainConstants.STATE_PART_PRELIMINARY.equals(objState)){
                    	allowChanges = false;
                    }
            	}
            }else if(EngineeringUtil.isMBOMInstalled(context) && EngineeringUtil.isManuPartPolicy(context,objPolicy)) {
            	allowChanges = (!objState.equals(DomainObject.STATE_PART_REVIEW) && !objState.equals(approvedState) && !objState.equals(DomainObject.STATE_PART_RELEASE) && !objState.equals(obsoleteState));
            }

            String propAllowLevelDevPart = (String)FrameworkProperties.getProperty(context, "emxEngineeringCentral.Part.RestrictDevelopmentPartEdit");
            StringList propAllowLevelListDevPart = new StringList();

            if(propAllowLevelDevPart != null && !"null".equals(propAllowLevelDevPart) && propAllowLevelDevPart.length() > 0) {
            	StringTokenizer stateToken = new StringTokenizer(propAllowLevelDevPart, ",");
            	while (stateToken.hasMoreTokens()) {
            		String token = (String)stateToken.nextToken();
            		propAllowLevelListDevPart.add(FrameworkUtil.lookupStateName(context, objPolicy, token));
            	}
            }
         
            if("Development".equals(policyClass)){
            	allowChanges = (!propAllowLevelListDevPart.contains(objState));
            }
            //Ended code for the bug 288183
            //Added Code for Bug No 329545 Dated 4/13/2007 Begin
             
            Access access = new Access();
            BusinessObject boPart = new BusinessObject(parentId);
            access = boPart.getAccessMask(context);
            if(!access.hasModifyAccess()) {
            	allowChanges=false;
            }
             
            //Added Code for Bug No 329545 Dated 4/13/2007 Ends
            /**
            * MBOM-LG Structure Edit Configure Action commands to appear based on Mode and View Selector
            * the following code ristricts not to show the Add Existing command in Common View
            */
            String sBOMViewFilter = DomainConstants.EMPTY_STRING;
            if(EngineeringUtil.isMBOMInstalled(context)){
            	sBOMViewFilter    = (String) paramMap.get("ENCBillOfMaterialsViewCustomFilter");
            	if(sBOMViewFilter != null && !"engineering".equalsIgnoreCase(sBOMViewFilter)){
            		allowChanges=false;
            	}
            }
            /**Added for MBOM - Ends Here */
            // Added Code For Part Series Functionality Starts
         
            String resClassifiedItemId = DomainConstants.EMPTY_STRING;
            String toolBar = (String) paramMap.get("toolbar");
            
            if ("ENCpartSpecificationSummaryToolBar".equals(toolBar)) { // Added for IR-106890V6R2012x
            	String strattr = domObj.getInfo(context,"attribute["+ATTRIBUTE_REFERENCE_TYPE+"]");
            	String PartSeriesEnabled = (String)FrameworkProperties.getProperty(context, "emxEngineeringCentral.PartSeries.PartSeriesActive");
            		
            	if(("true".equalsIgnoreCase(PartSeriesEnabled)) && (strattr.equalsIgnoreCase(SYMB_R))) {
            		String command = "print bus $1 select $2 dump $3";
            		String strres = MqlUtil.mqlCommand(context, command, parentId, "relationship["+RELATIONSHIP_CLASSIFIED_ITEM+"].id", "|");
            		String command1 = "query connection type $1 where $2 select $3 dump";
            		StringTokenizer stCIRecords = new StringTokenizer(strres, "|");

            		while (stCIRecords.hasMoreTokens()) {
            			resClassifiedItemId = stCIRecords.nextToken();
            			String strres1 = MqlUtil.mqlCommand(context, command1, strPartFamilyRef, "fromrel.id ==" + resClassifiedItemId, "torel.to.id");
            			StringList strlIds = FrameworkUtil.split(strres1, ",");
 					
            			if (strlIds.size() == 2) {
            				String strres2 = (String) strlIds.get(1);
            				DomainObject partId = new DomainObject(strres2);
            				String strattrValue = partId.getInfo(context,"attribute["+ATTRIBUTE_REFERENCE_TYPE+"]");
            				if (strattrValue.equalsIgnoreCase(SYMB_M))  {
            					allowChanges = false;
            				}
            			}
            		}
            	}
            }
            // Added Code For Part Series Functionality Ends
            //Added below code for the bug 346336
            if(sMEPPolicy.equals(objPolicy)){
            	if(!(context.getUser().equals(objOwner)) || objState.equals(DomainObject.STATE_PART_RELEASE) || objState.equals(DomainObject.STATE_PART_OBSOLETE) || objState.equals(PendingObsoleteState))
            		allowChanges = false;
            }
            //Added above code for the bug 346336
            
        }catch (Exception e) {
        	throw new Exception(e.toString());
        }
        return  Boolean.valueOf(allowChanges);
    }
    
    
    
    /**
     * To Show Edit ALL link in EBOM SB Indented Table.
     *
     * @param context the eMatrix <code>Context</code> object.
     * @param args holds objectId.
     * @return Boolean.
     * @throws Exception If the operation fails.
     * @since EC10-6.
     *
     */
    public Boolean showEBOMIndentedTableEditAll(Context context, String []args) throws Exception {
    	boolean showCommand = false;
     	//modified for bug 308466 to call isEBOMModificationAllowed instead of isModificationAllowed
     	if(isEBOMIndentedTable(context, args).booleanValue()) {
     		
     		boolean isEBOMModificationAllowed = (isEBOMModificationAllowed(context,args).booleanValue());
     		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
     		String selectedProgram = (String)paramMap.get("selectedProgram");
     		String strMode			= (String)paramMap.get("BOMMode");
     		String showSubstituteEditIcon = (String)paramMap.get("showSubstituteEditIcon");
     		String objectId = (String)paramMap.get("objectId");
     		
     		if (null == strMode) {
     			strMode = "";
     		}
     		
     		if(isEBOMModificationAllowed &&("emxPart:getStoredEBOM".equals(selectedProgram) || "ENG".equals(strMode))) {
     			showCommand = true;
     		}
     		
     		if("true".equalsIgnoreCase(showSubstituteEditIcon)) {
     			showCommand = true;
     		}
     		
//     		String strOwner  = new DomainObject(objectId).getInfo(context, DomainConstants.SELECT_OWNER);
//   		    String strUser = context.getUser();
//   		    
//   		    if(! strOwner.equals(strUser)){
//   		    	showCommand = false;
//   		    }
     		
     	}

     	return Boolean.valueOf(showCommand);
    }
     
     
    
}
