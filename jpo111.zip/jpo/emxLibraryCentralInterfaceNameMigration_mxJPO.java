import matrix.db.Context;


public class emxLibraryCentralInterfaceNameMigration_mxJPO extends emxLibraryCentralInterfaceNameMigrationBase_mxJPO
{
	public emxLibraryCentralInterfaceNameMigration_mxJPO(Context context, String[] args) throws Exception
	{
		super(context, args);
	}
}

