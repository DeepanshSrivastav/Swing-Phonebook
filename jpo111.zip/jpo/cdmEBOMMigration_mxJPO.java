import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

import com.mando.util.cdmCommonExcel;
import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.document.util.MxDebug;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.engineering.EngineeringConstants;
import com.matrixone.apps.framework.ui.UIUtil;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.Person;
import matrix.db.Relationship;
import matrix.db.RelationshipItr;
import matrix.db.RelationshipList;
import matrix.db.RelationshipType;
import matrix.util.StringList;




public class cdmEBOMMigration_mxJPO {
	public BufferedWriter consoleWriter = null;
	public BufferedWriter logWriter  = null;
	
	public BufferedWriter successObjectidWriter  = null;
	public BufferedWriter failedObjectidWriter  = null;
	public BufferedWriter noExistFailedWriter  = null;
	public BufferedWriter errorLogFile         = null;
	public BufferedWriter debugLogFile         = null;
	public BufferedReader bufferReader  = null;
	
	public String inputDirectory 			= "";
	public String outputDirectory 			= "";
	public String fileName 		        	= "";
	
	public String failedIdsLogsDirectory 	= "";
	public PrintStream errorStream		    = null;
	public File successLogFile 				= null;
	public File failedLogFile 				= null;
	public File noExistFailedFile 				= null;
	public Integer sequenceInt ;
	public String pageObjectName 			= "";
	
	public static final String fileSeparator 							= "\\";
	public static final String stMechanicalPart        			    	= "cdmMechanicalPart"; 
	public static final String stPhantomPart           				  	= "cdmPhantomPart"; 
	public static final String sEBOM        					        = cdmConstantsUtil.RELATIONSHIP_EBOM;
	public static final String sPartEBOMRelationAttributeUOM          	= cdmConstantsUtil.TEXT_CDMPARTEBOMRELATIONATTRIBUTEUOM;
	public static final String sPartEBOMRelationAttributeECONumberM   	= cdmConstantsUtil.TEXT_CDMPARTEBOMRELATIONATTRIBUTEECONUMBERM;
	public static final String sQuantity 						     	= cdmConstantsUtil.TEXT_QUANTITY;
	public static final String sPartSpecification                     	= cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
	public static final String sFindNumber                           	= cdmConstantsUtil.TEXT_FINDNUMBER;
	public static final String sOutput_Directory						= "MIGRATION_LOGS";

	
	public void test(Context context, String args[])throws Exception{
		System.out.println("--------------------------");
		DomainObject dObj = new DomainObject();
		
	}
	
	/**
	 * args[0] :inputDirectory 파일 위치 정보 (파일명 포함되지않음) 
	 * args[1] : file name
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void executeEBOMMigration(Context context, String args[])throws Exception{
		long startTime = System.currentTimeMillis();
		System.out.println("cdmEBOMMigration_mxJPO :executeEBOMMigration start ."+cdmCommonExcel.getTimeStamp2());
		
		String sFileLocationAndFileName = args[0];
		
		String bomFileLocation 		= "";
		String bomfile 			= "";
		
		bomFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		bomfile 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		String logFileName = "ebomM";

		String[] argTest = {bomFileLocation,bomfile};
		initializeM(context,argTest,2,logFileName);
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole(" EBOM DATA MIGRATION "+ getTimeStamp()+" \n");
		writeMessageToConsole("	Reading input log file from : "+inputDirectory+bomfile);
		writeMessageToConsole("	Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		int lineNumber = 0;
		StringList stListHeader = new StringList();
		
		int successCount = 0;
		int failCount = 0;
		int notExistCount = 0;
		int totalCount  = 0;
		
		String recordRowNum     = "";
        
		try{
			MqlUtil.mqlCommand(context, "history off");
	        MqlUtil.mqlCommand(context, "trigger off");
			String stReadData = "";
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory+fileName),"euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null){
				StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
				StringBuffer sbErrorMessage = new StringBuffer("");
				if(lineNumber == 0){
					stListHeader = stListReadData ;
					writeFailToFile("errorDate"+"\t"+stReadData);
					lineNumber++;
					continue;
				}
				
				
				lineNumber++;
				
				int size_Data 	= stListReadData.size();
				int size_Header = stListHeader.size();
				if(size_Data != size_Header){
					String errorMessage = "NOT MATCH DATA FIELD";
					throw new Exception(errorMessage);
				}
				
			
				LinkedHashMap<String, Object> linkedPartHM = new LinkedHashMap<String,Object>();
//				boolean bPuchCheck = false;
				for(int stListNum = 0; stListNum<stListReadData.size() ;stListNum++){
					String stTempPartInfos = ((String)stListReadData.get(stListNum)).trim();
					
					String stTempPartHeader = ((String)stListHeader.get(stListNum)).trim();
					
					linkedPartHM.put(stTempPartHeader, stTempPartInfos);
					//linkedPartHM.put("Item_Num", String.valueOf(lineNumber));
					
				}
				
				
				String stItem_Num         = (String)linkedPartHM.get("#");             // 1
				String stPartName         = (String)linkedPartHM.get("PAR_ID");        // 2
				String stPartRev    	  = (String)linkedPartHM.get("PAR_REV");       // 3
				String stPartDec          = (String)linkedPartHM.get("PAR_DESC");      // 4
				String stIsPhantom        = (String)linkedPartHM.get("ISPHANTOM");     // 5
				String stChildPartName    = (String)linkedPartHM.get("CHLD_ID");       // 6
				String stChildPartRev     = (String)linkedPartHM.get("CHLD_REV");      // 7
				String stChildPartDec     = (String)linkedPartHM.get("CHLD_DESC");     // 8
				String stCRT_USERS  	  = (String)linkedPartHM.get("CRT_USERS");     // 10
				String stFindNumber       = (String)linkedPartHM.get("TDM_OPERATION_SEQUENCE");     // 11
				
				String stEBOMRelUOM       = (String)linkedPartHM.get("BOM_UOM");       // 12 attribute[cdmPartEBOMRelationAttributeUOM]
				String stCN_ECO_NUMBER    = (String)linkedPartHM.get("CN_ECO_NUMBER"); // 13 attribute[cdmPartEBOMRelationAttributeECONumberM]
				String stCN_QUANTITY      = (String)linkedPartHM.get("CN_QUANTITY");   // 14 attribute[Quantity]
				
				recordRowNum    	=  stItem_Num; 
				
//				if(cdmStringUtil.isNotEmpty(stPartName) && cdmStringUtil.isNotEmpty(stChildPartName)){
//					String stPartType 		= "";
//					String stParentPartId 	= "";
//					String stChildPartId 	= "";
//					String strUOM           = "";
					
					boolean bParentExist = false;
					
					/*stIsPhantom 정보는 mechanical 에서 phantom에서 변경된 데이타도 있으므로 사용하지 않는다.*/
					BusinessObject parentPartBus = new BusinessObject(stMechanicalPart , stPartName, stPartRev,"eService Production");
					bParentExist = parentPartBus.exists(context);
					if(!bParentExist){
						parentPartBus = new BusinessObject(stPhantomPart , stPartName, stPartRev,"eService Production");
						bParentExist = parentPartBus.exists(context);
						
//						if(!bParentExist){
//							failCount++;
//							notExistCount++;
//							
//							writeNoExistFailToFile(stReadData);
//							writeErrorToFile("LineNum(#):"+recordRowNum+" | parentObject  not exist.");
//							continue;
//						}
					}
					
					boolean bChildPartExist = false;
					/*bom 정보는 cdmphantomPart은 존재하지 않는다.*/
					BusinessObject childPartBus = new BusinessObject(stMechanicalPart , stChildPartName, stChildPartRev,"eService Production");
					bChildPartExist = childPartBus.exists(context);
					
					
					if(!bParentExist || !bChildPartExist ){
						failCount++;
						notExistCount++;
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+stReadData);//writeNoExistFailToFile();
						if(!bParentExist &&bChildPartExist ){
							writeNoExistFailToFile(recordRowNum +"\t"+stPartName+"\t"+stPartRev+"\t"+stIsPhantom+"\t"+"\t"+"\t");
						}else if(bParentExist && !bChildPartExist ){
							writeNoExistFailToFile(recordRowNum +"\t"+"\t"+"\t"+"\t"+stChildPartName+"\t"+stChildPartRev+"\t");
						}else if(!bParentExist && !bChildPartExist ){
							writeNoExistFailToFile(recordRowNum +"\t"+stPartName+"\t"+stPartRev+"\t"+stIsPhantom+"\t"+stChildPartName+"\t"+stChildPartRev+"\t");
						}
						
						writeErrorToFile("LineNum(#): \t not exist object \t"+recordRowNum+"\t"+stPartName+"\t"+stPartRev+"\t"+stIsPhantom+"\t"+stChildPartName+"\t"+stChildPartRev+"\t" );
						continue;
					}
//					if(!bChildPartExist){
//						failCount++;
//						writeNoExistFailToFile(stReadData);
//						writeErrorToFile("LineNum(#):"+recordRowNum+" | childObject not exist.");
//						continue;
//					}
					
					
					
//					String stChildPartMql = "temp query bus '"+stPartType+"'  '"+ stChildPartName+"' '"+stChildPartRev+ "' select id dump |" ;
//					String stChildPartMql = "temp query bus '"+stChildPartType+"'  '"+ stChildPartName+"' '"+stChildPartRev+ "' select id dump |" ;
//					String stChildPartMqlResult = MqlUtil.mqlCommand(context, stChildPartMql);
//					StringList stListChildPartMqlResult = FrameworkUtil.split(stChildPartMqlResult, "|");
//					if(stListChildPartMqlResult.size() >2){
//						stChildPartId = (String)stListChildPartMqlResult.get(3);
//					}else{
//						//writeFailToFile("Line Number: "+recordRowNum +" |EXCETPION: childObject not exist. "  );
//						failCount++;
//						writeNoExistFailToFile(stReadData);
//						writeErrorToFile("LineNum(#):"+recordRowNum+" | childObject not exist.");
//						continue;
//					}
					
					
					//
//					String vpmControlState =	"";
//					boolean isENGSMBInstalled = EngineeringUtil.isENGSMBInstalled(context, false); //Commented for IR-213006
//
//			        if (isENGSMBInstalled) { //Commented for IR-213006
//			        	String mqlQuery = new StringBuffer(100).append("print bus $1 select $2 dump").toString();
//			        	vpmControlState = MqlUtil.mqlCommand(context, mqlQuery,stParentPartId,"from["+sPartSpecification+"|to.type.kindof["+EngineeringConstants.TYPE_VPLM_CORE_REF+"]].to.attribute["+EngineeringConstants.ATTRIBUTE_VPM_CONTROLLED+"]");
//					}
//			        EBOMAutoSync.backupContextUserInfo(context);
//			        ContextUtil.pushContext(context);
//					bPuchCheck = true;
					//bom 의 데이타 가 중복이 될수 있어 체크 
					String sParentId = parentPartBus.getObjectId(context);
					String sChildId = childPartBus.getObjectId(context);
					
					RelationshipList relParentPart = new RelationshipList();
					relParentPart = parentPartBus.getFromRelationship(context);
					RelationshipItr iterRelParnet = new RelationshipItr ( relParentPart );
					try {
						while( iterRelParnet.next() ) {
							Relationship rel = iterRelParnet.obj();
							String relType = rel.getTypeName ();
							
							if ( rel.getTypeName ().equals ("EBOM")){
								String sToObj = rel.getTo().getObjectId(context);
						        if(sToObj.equals(sChildId)){
						        	writeMessageToConsole("LineNum(#): \t duplicate object row \t"+recordRowNum+"\t"+stPartName+"\t"+stPartRev+"\t"+stIsPhantom+"\t"+stChildPartName+"\t"+stChildPartRev+"\t" );
						        	throw new Exception("duplicate object row");
						        }
							}
						}
//						
						ContextUtil.startTransaction(context, true);
		 
		        
					
						matrix.db.Relationship relationObject1 = null;
						matrix.db.RelationshipType relType1 = new RelationshipType(sEBOM);
						
						DomainObject dObjParentPart = new DomainObject(parentPartBus.getObjectId(context));
						DomainObject childPart = new DomainObject(childPartBus.getObjectId(context));
						
						relationObject1 = dObjParentPart.connect(context, relType1, true, childPart);
						
						
						//connect trigger action
//						 Hashtable localHashtable = new Hashtable();
//						 if ((UIUtil.isNotNullAndNotEmpty(stParentPartId)) && (checkSyncPrerequisitesForParentPart(context, stParentPartId)) &&
//						 (!(isPartSynchronizedAndConnectedToLatestProduct(context, stChildPartId)))) {
//							 localHashtable = (Hashtable)syncPartAnditsEBOMToVPM(context, stChildPartId, "1");
//						 }
						
						// . 로 존재하는 수량정보의 경우 1로 치환하여 데이타를 입력한다 
						if(".".equals(stCN_QUANTITY)){
							stCN_QUANTITY = "1";
						}
						
						//attribute value input
						AttributeList attrList = new AttributeList();
						if (cdmStringUtil.isNotEmpty(stEBOMRelUOM)) {
							AttributeType attrTypeEBOMRelUOM = new AttributeType(sPartEBOMRelationAttributeUOM);
							Attribute attrEBOMRelUOM = new Attribute(attrTypeEBOMRelUOM, stEBOMRelUOM);
							attrList.addElement(attrEBOMRelUOM);
						}
						if (cdmStringUtil.isNotEmpty(stCN_ECO_NUMBER)) {
							AttributeType attrTypeECONumber = new AttributeType(sPartEBOMRelationAttributeECONumberM);
							Attribute attrECONumber = new Attribute(attrTypeECONumber, stCN_ECO_NUMBER);
							attrList.addElement(attrECONumber);
						}
						if (cdmStringUtil.isNotEmpty(stCN_QUANTITY)) {
							AttributeType attrTypeQuantity = new AttributeType(sQuantity);
							Attribute attrQuantity = new Attribute(attrTypeQuantity, stCN_QUANTITY);
							attrList.addElement(attrQuantity);
						}
						
						AttributeType attrTypeFindNumber = new AttributeType(sFindNumber);
						Attribute attrFindNumber = new Attribute(attrTypeFindNumber, stFindNumber);
						attrList.addElement(attrFindNumber);
						
				
//						
//						boolean checkOwner = false;
//						boolean checkOrg = false;
//						boolean checkProject = false;
//						String sOwner = "";
//						String sOrg = "";
//						String sProject = "";
//						String findPerson = "temp query bus Person "+stCRT_USERS+" * select id dump |";
//						String findPersonMql = MqlUtil.mqlCommand(context, findPerson);
//						if(cdmStringUtil.isNotEmpty(findPersonMql)){
//							 checkOwner = true;
//						}
						
//						StringList sListParent = new StringList();
//						sListParent.add("project");
//						sListParent.add("organization");
//						
//						Map requestMap = new HashMap();
//						requestMap = dObjParentPart.getInfo(context, sListParent);
//						sProject = (String)requestMap.get("project");
//						sOrg = (String)requestMap.get("organization");
						
//						 String findOrg = "list role $1 select $2 dump;";
//						if (cdmStringUtil.isNotEmpty(sOrg) && cdmStringUtil.isNotEmpty(sProject)) {
//							String str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sOrg, "isanorg" });
//							if ("TRUE".equalsIgnoreCase(str2)) {
//
//								findOrg = "list role $1 select $2 dump;";
//								str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sProject, "isaproject" });
//								if ("TRUE".equalsIgnoreCase(str2)) {
//									checkOrg = true;
//									checkProject = true;
//								}
//							}
//						}
//						if(checkOrg && checkProject){
//							relationObject1.setOwnership(context,checkOwner , checkOrg, checkProject, stCRT_USERS, sOrg, sProject);
							
//						}else{
//							sbErrorMessage.append(stCRT_USERS).append(sOrg).append(",").append(sProject).append("\t");
//						}
						relationObject1.setAttributes(context, attrList);
						ContextUtil.commitTransaction(context);
						successCount++;
						writeSuccessToFile( cdmCommonExcel.getTimeStamp2()+"\t"+recordRowNum +"\t"+stPartName+"\t"+ stPartRev+"\t"+ stChildPartName+"\t"+stChildPartRev + "\t"+ sbErrorMessage.toString());
						
					} catch (Exception exception) {
						ContextUtil.abortTransaction(context);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+stReadData);
						failCount++;
						writeErrorToFile("LineNum(#): \t"+recordRowNum +"\t"+cdmCommonExcel.getTimeStamp2());
						exception.printStackTrace(errorStream);
						
					}finally{
						
						
					}
					
				
				
			}
			

		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("File EBOM Migration COMPLETED                    ...\n");
		writeMessageToConsole("====================================================================================");
	
		
		}catch(Exception exception)
		{
			writeMessageToConsole(" Exception: "+exception.getMessage());
			writeErrorToFile(exception.getMessage());
			exception.printStackTrace(errorStream);
		}
		finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("EBOM Migration END TIME:"+cdmCommonExcel.getTimeStamp2());
			writeMessageToConsole("Lead Time:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms " +"  Succees Count("+successCount+") FailCount ("+failCount+") no Exist:("+notExistCount+")" );
			writeMessageToConsole("====================================================================================");
			closeLogStream();
			MqlUtil.mqlCommand(context, "trigger on");
			MqlUtil.mqlCommand(context, "history on");
			System.out.println("cdmEBOMMigration_mxJPO :executeEBOMMigration end ."+cdmCommonExcel.getTimeStamp2());
		}
	}
	
    private boolean isValidData(String data) {
		return ((data == null || "null".equals(data)) ? 0 : data.trim().length()) > 0;
	}
    
	private void closeLogStream() throws IOException
	{
		try 
		{
			if(null != consoleWriter)
				consoleWriter.close();

			if(null != logWriter)
				logWriter.close();

			if(null != errorStream)
				errorStream.close();

			if(null != successObjectidWriter)
				successObjectidWriter.close();

			if(null != failedObjectidWriter)
				failedObjectidWriter.close();
			
			if(null != noExistFailedWriter)
				noExistFailedWriter.close();
			
			if(null != errorLogFile)
				errorLogFile.close();
			
			if(null != debugLogFile)
				errorLogFile.close();
			
			if(null != bufferReader)
				bufferReader.close();
				
		} 
		catch (IOException e) 
		{
			System.out.println("Exception while closing log stream "+e.getMessage());
		}
	}
	
	
	private void writeErrorToFile(String message)throws Exception{
		errorStream.write(message.getBytes("UTF-8"));
		errorStream.write("\n".getBytes("UTF-8"));
	}
	
	private void writeMessageToConsole(String message) throws Exception
	{
//		consoleWriter.write(message + "\n");
//		consoleWriter.flush();
		writeMessageToLogFile(message);
	}

	private void writeMessageToLogFile(String message) throws Exception
	{
		logWriter.write( message + "\n");
		logWriter.flush();
	}
	
	private String getTimeStamp(){
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date)+"T"+ new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}
	
	public void writeFailToFile(String message) throws Exception{
		failedObjectidWriter.write( message + "\n");
		failedObjectidWriter.flush();
	}
	
	public void writeNoExistFailToFile(String message) throws Exception{
		noExistFailedWriter.write( message + "\n");
		noExistFailedWriter.flush();
	}
	public void writeSuccessToFile(String message)throws Exception{
		successObjectidWriter.write(message + "\n");
		successObjectidWriter.flush();
	}
	
	/**
	 * args{inputDirectory, 
	 * 
	 * @param context
	 * @param args
	 * @param requestAgsNum
	 * @param logFileName
	 */
	private void initializeM(Context context,String args[],int requestAgsNum , String logFileName)throws Exception{

//		consoleWriter 		= new BufferedWriter(new MatrixWriter(context));
//		sequenceInt			= 1;

		if (args.length != requestAgsNum )
		{
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}


		inputDirectory = args[0];

		// documentDirectory does not ends with "/" add it
		if(inputDirectory != null && !inputDirectory.endsWith(fileSeparator))
		{
			inputDirectory = inputDirectory + fileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + fileSeparator + sOutput_Directory + fileSeparator + logFileName  +"_"+   fileSeparator;
        File fileOutputDirectory = new File(outputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        fileName = args[1];
//        logFileName+=fileName+"_"+getTimeStamp();
        logFileName +="_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+getTimeStamp();
        
		logWriter 			 	= new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

//		// Create Results directory inside output directory to log failed object ids.
//		failedIdsLogsDirectory 	= outputDirectory + "Results" + fileSeparator;
//		File fileFailedIdsLogsDirectory = new File(failedIdsLogsDirectory);
//	    if(!fileFailedIdsLogsDirectory.isDirectory()){
//	       	fileFailedIdsLogsDirectory.mkdirs();
//	    }
		failedLogFile  			= new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		noExistFailedFile       = new File(outputDirectory + logFileName + "_noExistFailedLog" + ".txt");
		noExistFailedWriter = new BufferedWriter(new FileWriter(noExistFailedFile,true));
		// input file name
		
		

	
	}
	
	
	//
	private boolean checkSyncPrerequisitesForParentPart(Context paramContext, String paramString) throws Exception{
		if (UIUtil.isNotNullAndNotEmpty(paramString)) {
			String str = MqlUtil.mqlCommand(paramContext, "print bus $1 select $2 $3 dump", new String[] { paramString, "attribute[" + EngineeringConstants.ATTRIBUTE_VPM_VISIBLE + "]", "from[" + EngineeringConstants.RELATIONSHIP_PART_SPECIFICATION + "|to.type.kindof[" + EngineeringConstants.TYPE_VPLM_REF + "]].to.attribute[" + EngineeringConstants.ATTRIBUTE_VPM_CONTROLLED + "]" });
			StringList localStringList = FrameworkUtil.splitString(str, ",");
			if ((!(localStringList.isEmpty())) && ("True".equalsIgnoreCase((String) localStringList.get(0))) && (localStringList.size() > 1) && ("False".equalsIgnoreCase((String) localStringList.get(1)))) {
				return true;
			}
			
		}
		 return false;
	}
	//
	
	public boolean isPartSynchronizedAndConnectedToLatestProduct(Context paramContext, String paramString) throws Exception{
	
		if (UIUtil.isNullOrEmpty(paramString)) {
			throw new FrameworkException("Part Id is empty or null and hence synchronization cannot be verified");
		}
		
		String str = MqlUtil.mqlCommand(paramContext, "print bus $1 select $2 $3 dump", new String[] { paramString, "from[" + EngineeringConstants.RELATIONSHIP_PART_SPECIFICATION + "|to.type.kindof[" + EngineeringConstants.TYPE_VPLM_REF + "]].to.id", "previous.from[" + EngineeringConstants.RELATIONSHIP_PART_SPECIFICATION + "|to.type.kindof[" + EngineeringConstants.TYPE_VPLM_REF + "]].to.id" });
		StringList localStringList = FrameworkUtil.splitString(str, ",");
		
		return ((localStringList.size() >= 1) && (((localStringList.size() <= 1) || (!(((String) localStringList.get(0)).equalsIgnoreCase((String) localStringList.get(1)))))));
	}
	
//	public Map syncPartAnditsEBOMToVPM(Context paramContext, String paramString1, String paramString2) throws Exception {
//
//		Hashtable localHashtable1 = new Hashtable();
//		String str1 = paramContext.getCustomData("BOM_SYNC_FROM_ODT");
//
//		if ((!("True".equalsIgnoreCase(str1))) && (isAutoSyncDisabled(paramContext).booleanValue()))
//			return localHashtable1;
//
//		int i = 0;
//		int j = 0;
//		String str2 = "";
//
//		String str3 = "";
//		int k = 0;
//		try {
//			if (UIUtil.isNotNullAndNotEmpty(paramString1)) {
//				if (!(ContextUtil.isTransactionActive(paramContext))) {
//					ContextUtil.startTransaction(paramContext, true);
//					j = 1;
//				}
//				Object localObject1;
//				if ((UIUtil.isNullOrEmpty(str1)) && ("User Agent".equalsIgnoreCase(paramContext.getUser()))) {
//					localObject1 = getContextUserMap(paramContext);
//					if (((Map) localObject1).size() > 0) {
//						i = 1;
//						ContextUtil.pushContext(paramContext, (String) ((Map) localObject1).get("userName"), (String) ((Map) localObject1).get("password"), (String) ((Map) localObject1).get("vault"));
//					}
//				}
//
//				if (("True".equalsIgnoreCase(str1)) || ((!("User Agent".equalsIgnoreCase(paramContext.getUser()))) && (hasSyncAccess(paramContext, paramContext.getUser())))) {
//					localObject1 = new Hashtable();
//					((Hashtable) localObject1).put("ROOTID", paramString1);
//					((Hashtable) localObject1).put("SYNC_DEPTH", (UIUtil.isNotNullAndNotEmpty(paramString2)) ? paramString2 : "ALL");
//					String[] arrayOfString = JPO.packArgs(localObject1);
//					str2 = MqlUtil.mqlCommand(paramContext, "print bus $1 select $2 dump", new String[] { paramString1, "from[" + EngineeringConstants.RELATIONSHIP_PART_SPECIFICATION + "|to.type.kindof[" + EngineeringConstants.TYPE_VPLM_REF + "]].to.current" });
//					str3 = DomainObject.newInstance(paramContext, paramString1).getInfo(paramContext, "current");
//
//					if ((!(DomainConstants.STATE_PART_PRELIMINARY.equalsIgnoreCase(str3))) && ("RELEASED".equalsIgnoreCase(str2))) {
//						ContextUtil.pushContext(paramContext);
//						paramContext.setCustomData("EBOM_AUTO_SYNC", "TRUE");
//						k = 1;
//					}
//					localHashtable1 = (Hashtable) JPO.invoke(paramContext, "VPLMIntegBOMVPLMSynchronize", null, "synchronizeFromMatrixToVPM", arrayOfString, Hashtable.class);
//					if (k != 0) {
//						paramContext.removeFromCustomData("EBOM_AUTO_SYNC");
//						ContextUtil.popContext(paramContext);
//					}
//					Hashtable localHashtable2 = localHashtable1;
//					return localHashtable2;
//				}
//			}
//		} catch (Exception localException) {
//			throw new FrameworkException(localException.getMessage());
//		} finally {
//			if (i != 0) {
//				ContextUtil.popContext(paramContext);
//			}
//			if (j != 0) {
//				ContextUtil.commitTransaction(paramContext);
//			}
//		}
//		return ((Map) localHashtable1);
//
//	}
	
	public static Boolean isAutoSyncDisabled(Context paramContext) throws FrameworkException{
	
		return (("FALSE".equalsIgnoreCase(EnoviaResourceBundle.getProperty(paramContext, "emxEngineeringCentral.EBOMAutoSync.Enabled"))) ? Boolean.TRUE : Boolean.FALSE);
	}
	
	private Map getContextUserMap(Context paramContext) {
		String LOGGEDIN_USER = "LOGGEDIN USER";
		HashMap localHashMap = new HashMap();
		if ((paramContext != null) && (paramContext.getCustomData(LOGGEDIN_USER) != null)) {
			String str = paramContext.getCustomData(LOGGEDIN_USER);
			localHashMap.put("userName", str.substring(0, str.indexOf(":")));
			localHashMap.put("password", str.substring(str.indexOf(":") + 1, str.lastIndexOf(":")));
			localHashMap.put("vault", str.substring(str.lastIndexOf(":") + 1, str.length()));
		}
		return localHashMap;
	}
	
	
	//
	public boolean hasSyncAccess(Context paramContext, String paramString) throws Exception {
		int i = 0;
		Person localPerson = new Person(paramString);
		boolean bool1 = localPerson.isAssigned(paramContext, PropertyUtil.getSchemaProperty(paramContext, "role_VPLMCreator"));
		boolean bool2 = localPerson.isAssigned(paramContext, PropertyUtil.getSchemaProperty(paramContext, "role_VPLMProjectLeader"));
		if ((bool1) || (bool2)) {
			i = 1;
		}
		return (i != 0);
		// return boolean i;
	}
	
	
}


