import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.Relationship;
import matrix.util.SelectList;

/**
 * 
 * @author jshyun
 * @date 2016. 7. 27.
 * Type cdmCommonCode's JPO
 */
public class cdmCommonCode_mxJPO {
	
	/**
	 * 
	 * @param context
	 * @param args
	 * @return
	 * Table cdmCommonCodeTable view data
	 */
	@SuppressWarnings("rawtypes")
	public MapList getData(Context context, String[] args) {
		try {
			Map paramMap = JPO.unpackArgs(args);
			String objectId = (String)paramMap.get("objectId");
			
			return getList(context, objectId);
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 * 
	 * @param context
	 * @param args
	 * @return
	 * menu type_cdmCommonCode tree data
	 */
	@SuppressWarnings("rawtypes")
	public MapList getStructure(Context context, String[] args) {
		try {
			Map unpackMap = JPO.unpackArgs(args);
			Map paramMap = (Map)unpackMap.get("paramMap");
			String objectId = (String)paramMap.get("objectId");
			
			MapList retList = getList(context, objectId);
			return retList; 
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
	/**
	 *  method getData, method getStructure Common Logic
	 */
	private MapList getList(Context context, String objId) throws Exception {
		String objectId = objId;
		
		//if objectId is SPACE, emxTable is null and emxIndentedTable id ""(SPACE) 
		if(objectId == null || "".equals(objectId)){
			BusinessObject rootObj = new BusinessObject("cdmCommonCode", "CommonCodeRoot", "-", "eService Production");
			objectId = rootObj.getObjectId(context);
		}
		DomainObject domObj = new DomainObject(objectId);
		
		SelectList objSelect = new SelectList(); //extends StringList
		objSelect.addId();
		//objSelect.addName();
		SelectList relSelect = new SelectList(); //extends StringList
		relSelect.addAttribute("cdmCommonCodeTreeSeq");
		
		MapList retList = domObj.getRelatedObjects(context, 
				"cdmCommonCodeRelationship", //relationshipPattern
				"cdmCommonCode", //typePattern
				objSelect, //objectSelect
				relSelect, //relationshipSelect
				false, //getTo
				true, //getFrom
				(short)1, //recurseToLevel
				null, //objectWhere
				null, //relationshipWhere
				(short)0); //limit
		
		retList.sort("attribute[cdmCommonCodeTreeSeq]", "ascending", "integer");
		
		return retList;
	}
	
	/**
	 * 
	 * @param context
	 * @param args
	 * @return
	 * cdmCommonCodeWhereUsedTable data
	 * Type cdmCommonCode's relationship without cdmCommonCodeRelationship
	 */
	@SuppressWarnings("rawtypes")
	public MapList getWhereUsed(Context context, String[] args) {
		try {
			Map paramMap = JPO.unpackArgs(args);
			String objectId = (String)paramMap.get("objectId");
			
			DomainObject domObj = new DomainObject(objectId);
			
			SelectList objSelect = new SelectList(); //extends StringList
			objSelect.addId();
			
			MapList retList = domObj.getRelatedObjects(context, 
					"*", //relationshipPattern
					"*", //typePattern
					objSelect, //objectSelect
					null, //relationshipSelect
					true, //getTo
					true, //getFrom
					(short)1, //recurseToLevel
					"relationship != cdmCommonCodeRelationship", //objectWhere
					null, //relationshipWhere
					(short)0); //limit
			
			return retList;
		} catch (Exception e) {
			e.printStackTrace();
			return new MapList(0);
		}
	}
	
	/**
	 * 
	 * @param context
	 * @param args
	 * @return
	 * emxTree label getting
	 */
	@SuppressWarnings("rawtypes")
	public String getLabel(Context context, String[] args) {
		try {
			Map unpackMap = JPO.unpackArgs(args);
			Map paramMap = (Map)unpackMap.get("paramMap");
			
			String lang = (String)paramMap.get("languageStr");
			
			String objectId = (String)paramMap.get("objectId");
			DomainObject domObj = new DomainObject(objectId);
			
			if(lang == null){
				return null;
			}else if(lang.startsWith("ko")){
				return domObj.getAttributeValue(context, "cdmCommonCodeNameKo");
			}else if(lang.startsWith("en")){
				return domObj.getAttributeValue(context, "cdmCommonCodeNameEn");
			}else if(lang.startsWith("zh")){
				return domObj.getAttributeValue(context, "cdmCommonCodeNameCn");
			}else{
				return domObj.getAttributeValue(context, "cdmCommonCodeNameEn");
			}
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		} 
	}
	
	/**
	 * 
	 * @param context
	 * @param args
	 * @return
	 * Command cdmCommonCodeCreateAction, Form cdmCreateCommonCodeSlidein create cdmCommonCode
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Map createObject(Context context, String[] args) {
		try {
			Map paramMap = JPO.unpackArgs(args);
			System.out.println(paramMap);
			/*9/5/16 modify mj.kim start */
			String checkMigration = (String)paramMap.get("checkMigration");
			/*9/5/16 modify mj.kim end */
			String objectId = (String)paramMap.get("objectId");
			String code = (String)paramMap.get("Name");
			String codeKo = (String)paramMap.get("codeKo");
			String codeEn = (String)paramMap.get("codeEn");
			String codeCn = (String)paramMap.get("codeCn");
			//add js.hyun 2016.08.23 start
			String temp1 = (String)paramMap.get("temp1") == null ? "" : (String)paramMap.get("temp1");
			String temp2 = (String)paramMap.get("temp2") == null ? "" : (String)paramMap.get("temp2");
			String temp3 = (String)paramMap.get("temp3") == null ? "" : (String)paramMap.get("temp3");
			//add js.hyun 2016.08.23 end
			String description = (String)paramMap.get("description");

			//add js.hyun 2016.08.23 start
			String ngType = "eService Number Generator";
			String ngName = "cdmCommonCodeNumberGenerator";
			String ngRev = "cdmCommonCode";
			String ngVault = "eService Administration";
			BusinessObject numGenerator = new BusinessObject(ngType, ngName, ngRev, ngVault);
			int name = Integer.parseInt(numGenerator.getAttributeValues(context, "eService Next Number").getValue());
			//add js.hyun 2016.08.23 end
			
			DomainObject domObj = new DomainObject();
			domObj.createObject(context, 
								"cdmCommonCode",
								String.format("CC-%010d", name), 
								"-", 
								"cdmCommonCodePolicy", 
								"eService Production");
			
			//add js.hyun 2016.08.23 start
			numGenerator.setAttributeValue(context, "eService Next Number", String.valueOf(name+1));
			//add js.hyun 2016.08.23 end
			
			Map attrMap = new HashMap();
			//add js.hyun 2016.08.23 start
			attrMap.put("cdmCommonCode", code);
			attrMap.put("cdmCommonTemp1", temp1);
			attrMap.put("cdmCommonTemp2", temp2);
			attrMap.put("cdmCommonTemp3", temp3);
			//add js.hyun 2016.08.23 end
			attrMap.put("cdmCommonCodeNameKo", codeKo);
			attrMap.put("cdmCommonCodeNameEn", codeEn);
			attrMap.put("cdmCommonCodeNameCn", codeCn);
			/*  9/5/16 modify mj.kim start  */
			if(cdmStringUtil.isNotEmpty(checkMigration) && "Y".equals(checkMigration)){
				attrMap.put("cdmCheckMigration", checkMigration);
			}
			/*  9/5/16 modify mj.kim end  */
			domObj.setAttributeValues(context, attrMap);
			domObj.setDescription(context, description);
			
			//if objectId is SPACE, emxTable is null and emxIndentedTable id ""(SPACE) 
			if(objectId == null || "".equals(objectId)){
				BusinessObject rootObj = new BusinessObject("cdmCommonCode", "CommonCodeRoot", "-", "eService Production");
				objectId = rootObj.getObjectId(context);
			}
			
			domObj.setRelatedObject(context, 
									"cdmCommonCodeRelationship", 
									false, 
									objectId);
			
			Map createdIdMap = new HashMap();
			createdIdMap.put("id", domObj.getId(context));
			
			return createdIdMap;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}
	
//	private String getRandomRevision(String name){
//		String saltedStr = name + System.nanoTime();
//		
//		MessageDigest mDigest;
//		try {
//			mDigest = MessageDigest.getInstance("MD5");
//			
//			mDigest.update(saltedStr.getBytes());
//			 
//			byte[] msgStr = mDigest.digest() ;
//			
//			Encoder encoder = Base64.getEncoder();
//			
//			byte[] encodedBytes = encoder.encode(msgStr);
//			
//			return new String(encodedBytes, 0, 10);
//		} catch (Exception e) {
//			return saltedStr.substring(0, 10);
//		}
//	}
	
	/**
	 * 
	 * @param context
	 * @param args
	 * @return
	 * cdmCommonCode delete, 
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public MapList deleteCommonCodeObjects(Context context, String[] args) {
		//use emxTree
		
		try {
			MapList mldeleteCommonCodeObjList = new MapList();
			Map paramMap = JPO.unpackArgs(args);
			String[] emxTableRowIds = (String[])paramMap.get("emxTableRowIds");
			
			int idSize = emxTableRowIds.length;
			for(int i = 0; i < idSize; i++){
				StringTokenizer st = new StringTokenizer(emxTableRowIds[i], "|");
				String objId = st.nextToken();
				
				boolean f = deleteObject(context, objId);
				Map map = new HashMap();
				if(f){
					map.put(DomainObject.SELECT_ID, objId);
					mldeleteCommonCodeObjList.add(map);
				}
			}// for end

			return mldeleteCommonCodeObjList;
		} catch (Exception e) {
			e.printStackTrace();
			return new MapList();
		}
	}
	
	private boolean deleteObject(Context context, String objId) throws Exception{
		DomainObject domObj = new DomainObject(objId);
		SelectList objSelect = new SelectList();
		objSelect.addId();
		
		if("Inactive".equals(domObj.getInfo(context, "current")) ){
			//if other BusinessObject used, do not delete
			MapList otherList = domObj.getRelatedObjects(context, 
					"*", //relationshipPattern
					"*", //typePattern
					objSelect, //objectSelect
					null, //relationshipSelect
					true, //getTo
					true, //getFrom
					(short)1, //recurseToLevel
					"relationship != cdmCommonCodeRelationship", //objectWhere
					null, //relationshipWhere
					(short)0); //limit
			System.out.println(otherList);
			if(otherList == null || otherList.size() != 0){
				return false;
			}
			
			//if there is sub Common Code, do not delete
			MapList subList = domObj.getRelatedObjects(context, 
					"*", //relationshipPattern
					"*", //typePattern
					objSelect, //objectSelect
					null, //relationshipSelect
					false, //getTo
					true, //getFrom
					(short)1, //recurseToLevel
					"relationship == cdmCommonCodeRelationship", //objectWhere
					null, //relationshipWhere
					(short)0); //limit
			//System.out.println(subList);
			if(subList == null || subList.size() != 0){
				return false;
			}
			
			domObj.deleteObject(context);
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 
	 * @param context
	 * @param args
	 * cdmCommonCodeTable, cdmCommonCodeTreeTable -> cdmCommonCodeSeq update
	 */
	@SuppressWarnings({ "rawtypes" })
	public void updateAttributeSequence(Context context, String[] args){
		try {
			Map unpackMap = JPO.unpackArgs(args);
			Map paramMap = (Map)unpackMap.get("paramMap");

//			System.out.println(unpackMap);
			
			SelectList objSelect = new SelectList();
			objSelect.addId();
			
			DomainObject domObj = new DomainObject((String)paramMap.get("objectId"));
			MapList domMap = domObj.getRelatedObjects(context, 
					"cdmCommonCodeRelationship", //relationshipPattern
					"cdmCommonCode", //typePattern
					null, //objectSelect
					objSelect, //relationshipSelect
					true, //getTo
					false, //getFrom
					(short)1, //recurseToLevel
					null, //objectWhere
					null, //relationshipWhere
					(short)0); //limit
			
			Relationship rel = new Relationship((String)((Map)domMap.get(0)).get("id"));
			
			AttributeType attrType = new AttributeType("cdmCommonCodeTreeSeq");
			Attribute attr = new Attribute(attrType, (String)paramMap.get("New Value"));
			AttributeList attrList = new AttributeList();
			attrList.addElement(attr);
			
			rel.setAttributes(context, attrList);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
	String rootName = "PROJECT";
	String rootType = "General Library";
	
	@SuppressWarnings({ "unchecked", "deprecation", "unused", "rawtypes" })
	public MapList getGeneralLibraryFirstNode(Context context, String[] args) throws Exception {
		
		MapList nodeList = new MapList();
		HashMap paramMap = (HashMap) JPO.unpackArgs(args);
		
		String master = (String)paramMap.get("searchMode");
		String refName = (String)paramMap.get("refName");
		String displayKey = (String)paramMap.get("displayKey");
		if(displayKey==null || "".equalsIgnoreCase(displayKey)) displayKey = "name";
		
		String type = "General Class";
		String relation = "Subclass";
		SelectList selectList = new SelectList(6);
		selectList.addId();
		selectList.addName();
		selectList.addType();
		selectList.add("attribute[Title]");
		selectList.add(displayKey);
		selectList.add("from[" + relation + "].to.name");
		selectList.add("from[" + relation + "].to.id");
		
		boolean isLeaf = true, hasChild=false;
        String strLeaf = null, strChild = null;
        MapList mapList = new MapList();
		try {
			MapList rootList = DomainObject.findObjects(context, 
					rootType, 
					rootName, 
					"*", 
					"*", 
					"eService Production", 
					"",
					"",
					true, 
					selectList, 
					(short)0);
			
			if(rootList==null || rootList.size()==0) return new MapList();
			Map rootMap = (Map)rootList.get(0);
			String rootId = (String)rootMap.get("id");
			DomainObject nodeObj = DomainObject.newInstance(context);
			nodeObj.setId(rootId);
			mapList = nodeObj.getRelatedObjects(context, relation, type, selectList, null, false, true, (short)1, "", null);
			mapList.sort("name", "ascending", "string");
			
			if(mapList != null && mapList.size() > 0) {
				for (int i = 0; i < mapList.size(); i++) {
					Map map = (Map) mapList.get(i);
					String name = (String)map.get("name");
					String display = (String)map.get(displayKey);
					if(map.get("from[" + relation + "].to.id") == null) {
						hasChild = false;
						isLeaf = true;
					} else {
						hasChild = true;
						isLeaf = true;
					}
					strLeaf = (isLeaf?"TRUE":"FALSE");
					strChild = (hasChild?"TRUE":"FALSE");
					map.put("name", name);
					map.put(displayKey, display);
					map.put("IS_LEAF", strLeaf);
					map.put("hasChild", strChild);
					nodeList.add(map);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return nodeList;
    }
	
	@SuppressWarnings({ "deprecation", "rawtypes", "unused", "unchecked" })
	public MapList expandGeneralLibraryNode(Context context, String[]args) throws Exception {
    	MapList expandList = new MapList();
    	try {
    		HashMap paramMap = (HashMap) JPO.unpackArgs(args);
    		String type = "General Class";
    		String relation = "Subclass";
    		
    		SelectList selectList = new SelectList(6);
        	selectList.addId();
    		selectList.addName();
    		selectList.addType();
    		selectList.add("attribute[Title]");
    		selectList.add("level");
    		selectList.add("from[" + relation + "].to.name");
    		selectList.add("from[" + relation + "].to.id");
			
			String objectId = (String)paramMap.get("objectId");
			String filterType = (String)paramMap.get("filterType");
			String orgId = (String)paramMap.get("orgId");
			
			boolean isLeaf = true, hasChild=false;
	        String strLeaf = null, strChild = null;
			
			MapList mapList = new MapList();
			if(objectId == null){
				if(orgId == null){
					objectId = MqlUtil.mqlCommand(context, "print bus 'General Library' PROJECT - select id dump");
					DomainObject nodeObj = new DomainObject(objectId);
					mapList = nodeObj.getRelatedObjects(context, relation, type, selectList, null, false, true, (short)0, "", null);
					mapList.sort("name", "ascending", "string");
					if(mapList != null && mapList.size() > 0) {
						for (int i = 0; i < mapList.size(); i++) {
							Map map = (Map) mapList.get(i);
							String name  = (String)map.get("name");
							String level = (String)map.get("level");
							if(map.get("from[" + relation + "].to.id") != null){
								hasChild = true;
								isLeaf = true;
							} else {
								hasChild = false;
								isLeaf = true;
							}
							strLeaf = (isLeaf?"TRUE":"FALSE");
							strChild = (hasChild?"TRUE":"FALSE");
							map.put("IS_LEAF", strLeaf);
							map.put("hasChild", strChild);
							expandList.add(map);	
						}
					}
				}else{
					DomainObject nodeObj = new DomainObject(orgId);
					mapList = nodeObj.getRelatedObjects(context, relation, type, selectList, null, false, true, (short)1, "", null);
					mapList.sort("name", "ascending", "string");
					if(mapList != null && mapList.size() > 0) {
						for (int i = 0; i < mapList.size(); i++) {
							Map map = (Map) mapList.get(i);
							String name  = (String)map.get("name");
							String level = (String)map.get("level");
							if(map.get("from[" + relation + "].to.id") == null) {
								hasChild = false;
								isLeaf = true;
							} else {
								hasChild = true;
								isLeaf = true;
							}
							strLeaf = (isLeaf?"TRUE":"FALSE");
							strChild = (hasChild?"TRUE":"FALSE");
							map.put("IS_LEAF", strLeaf);
							map.put("hasChild", strChild);
							expandList.add(map);	
						}
					}
				}
			}else{
				DomainObject nodeObj = new DomainObject(objectId);
				mapList = nodeObj.getRelatedObjects(context, relation, type, selectList, null, false, true, (short)1, "", null);
				mapList.sort("name", "ascending", "string");
				if(mapList != null && mapList.size() > 0) {
					for (int i = 0; i < mapList.size(); i++) {
						Map map = (Map) mapList.get(i);
						String name  = (String)map.get("name");
						String level = (String)map.get("level");
						if(map.get("from[" + relation + "].to.id") == null) {
							hasChild = false;
							isLeaf = true;
						} else {
							hasChild = true;
							isLeaf = true;
						}
						strLeaf = (isLeaf?"TRUE":"FALSE");
						strChild = (hasChild?"TRUE":"FALSE");
						map.put("IS_LEAF", strLeaf);
						map.put("hasChild", strChild);
						expandList.add(map);	
					}
				}
			}
	        
    	} catch(Exception e) {
    		e.printStackTrace();
    		throw e;
    	}
    	return expandList;
    }
}
