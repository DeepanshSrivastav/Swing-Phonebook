import matrix.db.Context;

// ${CLASSNAME}.java
//
// Created on jan 02, 2008
//
// Copyright (c) 2005-2015 Dassault Systems Limited.
// All Rights Reserved
// This program contains proprietary and trade secret information of
// Dassault Systems, Inc.  Copyright notice is precautionary only and does
// not evidence any actual or intended publication of such program.
//

/**
 * @author Lanka
 *
 * The <code>${CLASSNAME}</code> class/interface contains .
 *
 * @version AEF 10.7.3 - Copyright (c) 2005-2015, Dassault Systems, Inc.
 */
public class emxAEFFullSearch_mxJPO extends emxAEFFullSearchBase_mxJPO {

     /**
     * @param context
     * @param args
     * @throws Exception
     */
    public emxAEFFullSearch_mxJPO(Context context, String[] args)throws Exception
    {
        super(context, args);
        // TODO Auto-generated constructor stub
    }

    /**
     * @param args
     */
    public static void main(String[] args) {
        // TODO Auto-generated method stub
    }

}
