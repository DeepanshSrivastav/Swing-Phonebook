import matrix.db.Context;


public class emxCurrencyConversion_mxJPO extends emxCurrencyConversionBase_mxJPO{
	 /**
    *
    * @param context the eMatrix <code>Context</code> object
    * @param args holds no arguments
    * @throws Exception if the operation fails  
    */
   public emxCurrencyConversion_mxJPO (Context context, String[] args)
       throws Exception
   {
     super(context, args);
   }
	
}
