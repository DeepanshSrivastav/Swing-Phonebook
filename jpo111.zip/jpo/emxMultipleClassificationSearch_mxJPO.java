//
// $Id: ${CLASSNAME}.java.rca 1.6 Wed Oct 22 16:54:24 2008 przemek Experimental przemek $ 
//
/*
**  emxMultipleClassificationSearch
**
**  Copyright (c) 1992-2015 Dassault Systemes.
**  All Rights Reserved.
**  This program contains proprietary and trade secret information of MatrixOne,
**  Inc.  Copyright notice is precautionary only
**  and does not evidence any actual or intended publication of such program
**
**   
*/
import matrix.db.*;

public class emxMultipleClassificationSearch_mxJPO extends emxMultipleClassificationSearchBase_mxJPO
{

    public emxMultipleClassificationSearch_mxJPO (Context context, String[] args) throws Exception {
        super(context, args);
    }

}
