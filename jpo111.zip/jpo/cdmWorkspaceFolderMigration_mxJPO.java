import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.Buffer;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.beans.IEFIntegAccessUtil;
import com.matrixone.MCADIntegration.server.beans.MCADConfigObjectLoader;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.beans.MCADServerGeneralUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADGlobalConfigObject;
import com.matrixone.MCADIntegration.utils.MCADUtil;
import com.matrixone.apps.classification.AttributeGroup;
import com.matrixone.apps.classification.Classification;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.common.SubscriptionManager;
import com.matrixone.apps.common.Workspace;
import com.matrixone.apps.common.WorkspaceVault;
import com.matrixone.apps.common.util.JSPUtil;
import com.matrixone.apps.domain.DomainAccess;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainSymbolicConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkProperties;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MailUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.domain.util.mxBus;
import com.matrixone.apps.engineering.EBOMAutoSync;
import com.matrixone.apps.engineering.EBOMMarkup;
import com.matrixone.apps.engineering.EngineeringConstants;
import com.matrixone.apps.engineering.EngineeringUtil;
import com.matrixone.apps.engineering.PartFamily;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralConstants;
import com.matrixone.apps.library.PartLibrary;
import com.matrixone.apps.manufacturerequivalentpart.Part;
import com.matrixone.apps.team.TeamUtil;
import com.matrixone.jdom.Element;
import com.matrixone.search.index.Config.formatIndexedType;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.BusinessObjectAttributes;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.MatrixWriter;
import matrix.db.Policy;
import matrix.db.RelationshipType;
import matrix.db.StateRequirement;
import matrix.db.StateRequirementList;
import matrix.util.DateFormatUtil;
import matrix.util.List;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;

import com.dassault_systemes.WebServiceHandler.Domain;
import com.dassault_systemes.i3dx.appsmodel.matrix.mql.factory.BusinessObjectName;
import com.mando.util.cdmCommonExcel;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

/**
 * 
 * @author mj
 */
public class cdmWorkspaceFolderMigration_mxJPO {

	public static final String sfileSeparator = "\\";
	public static final String Output_Directory = "MIGRATION_LOGS";

	public int mxMain(Context context, String args[]) throws Exception {
		return 0;
	}

	/**
	 * argTest 이라는 string[] 에 직접 입력하여 initializeM 호출
	 * 
	 * args[0] :inputDirectory 파일 경로 정보 (파일명 포함되지않음) args[1] : file name
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void executeFolderMigration(Context context, String args[]) throws Exception {
		long startTime = System.currentTimeMillis();
		System.out.println("[${CLASS:cdmWorkSpaceMigration} : executeFolderMigration] start ." + cdmCommonExcel.getTimeStamp2());

		BufferedWriter logWriter = null;
		BufferedWriter successObjectidWriter = null;
		BufferedWriter failedObjectidWriter = null;
		BufferedReader bufferReader = null;

		String inputDirectory = "";
		String outputDirectory = "";
		String fileName = "";

		int totalCount = 0;
		int failCount = 0;
		int successCount = 0;
		// String failedIdsLogsDirectory = "";
		PrintStream errorStream = null;
		File successLogFile = null;
		File failedLogFile = null;
		
//		String sFileLocationAndFileName = "";
//		sFileLocationAndFileName = (String)paramMap.get("File");
		
		String logFileName = "FolderToFolder";
		String sFileLocationAndFileName = args[0];

		String sFileLocation = "";
		String sFileName = "";

		sFileLocation = sFileLocationAndFileName.substring(0, sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName = sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\") + 1);
		String[] argTest = { sFileLocation, sFileName }; // 읽을 파일경로 ,읽을 파일명
//
//		if (argTest.length != 2) {
//			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//		}

		inputDirectory = argTest[0];

		// input file name
		fileName = argTest[1];

		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + Output_Directory + sfileSeparator + logFileName +   sfileSeparator;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
		//
		logFileName +="_" + fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
		
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));

		// initializeMap = initializeM(context,argTest,2,logFileName,logWriter);
		// //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.

		writeMessageToConsole(logWriter, "====================================================================================");
		writeMessageToConsole(logWriter, "     WorkSpace DATA MIGRATION " + getTimeStamp() + " \n");
		writeMessageToConsole(logWriter, "		Reading input log file from : " + inputDirectory + fileName);
		writeMessageToConsole(logWriter, "		Writing Log files to: " + outputDirectory);
		writeMessageToConsole(logWriter, "====================================================================================\n");
		int lineNumber = 0;
		StringList stListHeader = new StringList();
		String recordRowNum = "";

		try {
			MqlUtil.mqlCommand(context, "history off");
			MqlUtil.mqlCommand(context, "Trigger Off");
			final HttpSession HttpServletRequest = null;

			// folder 검색
			String folderWhere = "attribute[cdmCheckMigration]=='Y' && attribute[cdmTDMXID]!=''  ";

			SelectList selectListFolder = new SelectList();
			selectListFolder.add("attribute[cdmTDMXID]");
			selectListFolder.add("to[Data Vaults].from.id");
			selectListFolder.addId();

			MapList mListFolder = new MapList();
			mListFolder = DomainObject.findObjects(context,
					"Workspace Vault",//type
					"*", // name
					"*", // rev
					"*", // owner
					"*", // vault
					folderWhere, // where
					false, // expand
					selectListFolder); // selectb
			
			HashMap<String, String> folderWorkSpaceHMap = new HashMap<String, String>();
			HashMap<String, String> folderHMap = new HashMap<String, String>();
			for (Iterator iterFolder = mListFolder.iterator(); iterFolder.hasNext();) {
				Map foldersMap = (Map) iterFolder.next();
				String folderCode = (String) foldersMap.get("attribute[cdmTDMXID]");
				String folderId = (String) foldersMap.get("id");
				String relWorkspaceId = (String) foldersMap.get("to[Data Vaults].from.id");
				relWorkspaceId = isVaildNullData(relWorkspaceId);

				folderHMap.put(folderCode, folderId);
				folderWorkSpaceHMap.put(folderCode, relWorkspaceId);

			}
			int headerSize = 0 ;
			
			String strPolicyWorkspaceVault = PropertyUtil.getSchemaProperty(context, "policy_ProjectVault"); // Workspace Vaults
			String strRelProjectVaults = PropertyUtil.getSchemaProperty(context, "relationship_ProjectVaults"); // Data Vaults
			String strTypefolder = PropertyUtil.getSchemaProperty(context, "type_ProjectVault"); // Workspace Vault

			String strRelSubProjectValues = "Sub Vaults";
			String strSubType = "Workspace Vault";
			String strSubPolicy = "Workspace Vaults";

			String stReadData = "";
			
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null) {
				try {
					StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
	
					if (lineNumber == 0) {
						stListHeader = stListReadData;
						headerSize =stListReadData.size();
						writeFailToFile(failedObjectidWriter, stReadData);
						lineNumber++;
	
						continue;
					}
	
					lineNumber++;
					totalCount = lineNumber;
					LinkedHashMap<String, Object> linkedWorkspaceFolderHM = new LinkedHashMap<String, Object>();

					int readDatSize = stListReadData.size();
//					System.out.println(readDatSize+" readDatSize"); 
					
					if(readDatSize != headerSize){
						throw new Exception("not match data size.");
					}
					/*
					 * 0: # :RowNummer 
					 * 1:CLASS_ID1
					 * 2:OBJECT_ID1
					 * 3:CLASS_ID2
					 * 4:OBJECT_ID2 
					 * 5:TDMX_ID : PARENT .
					 * 6:TDM_DESCRIPTION : PARENT DESCRIPTION . 
					 * 7:TDMX_ID : CHILD . 
					 * 8:TDM_DESCRIPTION : CHILD DESCRIPTION .
					 */
	
					for (int cnt = 0; cnt < stListReadData.size(); cnt++) {
						String sLocation = String.valueOf(cnt);
						String tempData = (String) stListReadData.get(cnt);
	
						linkedWorkspaceFolderHM.put(sLocation, tempData);
					}

				

					/* parent 와 child 연결 */

					String sRowNum = (String) linkedWorkspaceFolderHM.get("0");
					String sParentFolderName = (String) linkedWorkspaceFolderHM.get("5");
					String sParentFolderDescription = (String) linkedWorkspaceFolderHM.get("6");
					String sChildFolderName = (String) linkedWorkspaceFolderHM.get("7");
					String sChildFolderDescription = (String) linkedWorkspaceFolderHM.get("8");

					recordRowNum = sRowNum;


					boolean bParentExists = false;
					boolean bChildExists = false;
					String pFolderId = "";
					String accessType = "";

					// #################################################################################################################################
					// cdmProjectRelationshipWorkspace
					// #################################################################################################################################
					// workspace id
//					String strWorkspaceId = folderWorkSpaceHMap.get(sProejctTDMXId);
					String strFolderParent = folderHMap.get(sParentFolderName);
					String strFolderChild = folderHMap.get(sChildFolderName);
					
//					WorkspaceVault wVaultParent = new WorkspaceVault();
//					WorkspaceVault wVaultChild = new WorkspaceVault();
					
					//
//					DomainObject dObjWorkspace = new DomainObject(strWorkspaceId);
//					String strPhysicalId = (String) dObjWorkspace.getInfo(context, "physicalid");
//
//					WorkspaceVault wVaultParent = new WorkspaceVault();
//					WorkspaceVault wVaultChild = new WorkspaceVault();
//
//					BusinessObject boParentWorkspaceValut = null;
//
//					// String strTempWV = MqlUtil.mqlCommand(context, "temp
//					// query bus $1 $2 $3 select $4 $5 dump $6",
//					// strTypefolder,sParentFolderDescription,strWorkspaceRevision,
//					// "physicalid", "id", "|");
//					boParentWorkspaceValut = new BusinessObject(strTypefolder, sParentFolderDescription, strPhysicalId, strPolicyWorkspaceVault);
//
					ContextUtil.startTransaction(context, true);

					if(UIUtil.isNotNullAndNotEmpty(strFolderParent) && UIUtil.isNotNullAndNotEmpty(strFolderChild)){
						WorkspaceVault parentWVault = new WorkspaceVault();
//						WorkspaceVault childWVault = new WorkspaceVault();
						parentWVault.setId(strFolderParent);
						parentWVault.connectTo(context, parentWVault.RELATIONSHIP_SUB_VAULTS, new DomainObject(strFolderChild));

					}else{
						
						if(UIUtil.isNullOrEmpty(strFolderParent) && UIUtil.isNullOrEmpty(strFolderChild)){
							throw new Exception("not exist both \t"+sParentFolderName+"\t"+sChildFolderName);
						}else if(UIUtil.isNotNullAndNotEmpty(strFolderParent) || UIUtil.isNullOrEmpty(strFolderChild)){
							throw new Exception("not exist child \t"+"\t"+sChildFolderName);
						}else if(UIUtil.isNullOrEmpty(strFolderParent) && UIUtil.isNotNullAndNotEmpty(strFolderChild)){
							throw new Exception("not exist parent \t"+sParentFolderName+"\t");
						}
					}
					ContextUtil.commitTransaction(context);
					writeSuccessToFile(successObjectidWriter, recordRowNum+"\t"+sParentFolderName+"\t"+sParentFolderDescription+"\t"+sChildFolderName+"\t"+sChildFolderDescription);
					successCount++;
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failCount++;
					
					writeFailToFile(failedObjectidWriter, stReadData);
					String message = exception.getMessage();
					if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not exist both")){
						writeMessageToConsole(logWriter, "LINE NUMBER: \t" +recordRowNum+"\t"+cdmCommonExcel.getTimeStamp()+ "\t"+"1" + "\t" + message);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not exist child")){
						writeMessageToConsole(logWriter, "LINE NUMBER: \t" +recordRowNum+"\t"+cdmCommonExcel.getTimeStamp()+ "\t"+"2" + "\t" + message);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not exist parent")){
						writeMessageToConsole(logWriter, "LINE NUMBER: \t" +recordRowNum+"\t"+cdmCommonExcel.getTimeStamp()+ "\t"+"3" + "\t" + message);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not match data size.")){
						writeMessageToConsole(logWriter, "LINE NUMBER: \t" +recordRowNum+"\t"+cdmCommonExcel.getTimeStamp()+ "\t"+"4" + "\t" + message);
					}else{
						writeMessageToConsole(logWriter, "LINE NUMBER: \t" +recordRowNum+"\t"+cdmCommonExcel.getTimeStamp()+ "\t"+"5" + "\t" + message);
					}
					writeErrorToFile(errorStream, "LINE NUMBER: \t" + recordRowNum+"\t"+message);
					
					exception.printStackTrace(errorStream);

				}
			}

			writeMessageToConsole(logWriter, "====================================================================================");
			writeMessageToConsole(logWriter, "        File WorkSpace Migration COMPLETED.                    ");
			writeMessageToConsole(logWriter, "====================================================================================\n");

		} catch (Exception exception) {
			writeMessageToConsole(logWriter, "LINE NUMBER: \t" + recordRowNum + "\t" + exception.getMessage());
			writeErrorToFile(errorStream, "LINE NUMBER: \t" + recordRowNum + "\t " + exception.getMessage());
			exception.printStackTrace(errorStream);
		} finally {
			writeMessageToConsole(logWriter, "====================================================================================");
			writeMessageToConsole(logWriter, "CLOSE TIME:" + getTimeStamp() + "                                    ");
			writeMessageToConsole(logWriter, "LEAD TIME:" + (System.currentTimeMillis() - startTime) / 1000 / 60 + "ms        \n");
			writeMessageToConsole(logWriter, "FailCount: (" + failCount + ") SuccessCount: (" + successCount + ") totalCount:(" + (totalCount - 1) + ")");

			writeMessageToConsole(logWriter, "==================================================================================== \n");
			System.out.println("[${CLASS:cdmWorkSpaccdmWorkspaceFolderMigration} : executeFolderMigration] end .");
			// closeLogStream();
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();

				if (null != bufferReader)
					bufferReader.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			MqlUtil.mqlCommand(context, "history on");
			MqlUtil.mqlCommand(context, "Trigger On");
		}

		//

	}

	/**
	 * workspace 생성 
	 * workspace 
	 * @param context
	 * @param args
	 */
	public void workspaceCreateProcess(Context context ,String[] args)throws Exception{
//			#	CLS_NAME	TDMX_ID	REVISION	CRT_USERS	MOD_USERS	TDM_DESCRIPTION	TDM_ORG_USER_ID	PROD_DIV	CN_PROJECT	CN_PROJECT_CUST	CN_PRODUCT_GROUP	CN_CUSTOMER	CN_VEHICLE	CN_PROJECT_ID	PROD_GROUP	CN_CUST_VEHICLE
		long startTime = System.currentTimeMillis();
		System.out.println("[${CLASS:cdmWorkSpaceMigration} : workspaceCreateProcess] start ."+cdmCommonExcel.getTimeStamp2());
		
		BufferedWriter logWriter 			 = null;
		BufferedWriter successObjectidWriter  = null;
		BufferedWriter failedObjectidWriter   = null;
		BufferedReader bufferReader           = null;
		
		String inputDirectory 			= "";
		String outputDirectory 			= "";
		String fileName 		        	= "";
		 
		int totalCount = 0;
		int failCount = 0;
		int successCount = 0;
		PrintStream errorStream		    = null;
		File successLogFile 				= null;
		File failedLogFile 				= null;

		String sFileLocationAndFileName = args[0];
		String sFileLocation = "";
		String sFileName = "";

		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf(File.separator));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf(File.separator)+1);
		
//		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
//		String sFileLocationAndFileName = (String)paramMap.get("fileData");
//		
//		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
//		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		String logFileName = "FolderCreateM";
		
		String[] argTest = {sFileLocation,sFileName}; //읽을 파일경로 ,읽을 파일명
		
		if (argTest.length != 2 ){
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}
		
		inputDirectory = argTest[0];
		fileName = argTest[1];
		
		// documentDirectory does not ends with "/" add it
		if(inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)){
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator +  Output_Directory + sfileSeparator + logFileName  +  sfileSeparator;
        File fileOutputDirectory = new File(outputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }

		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
        logFileName+="_"+sFileName.substring(0, sFileName.lastIndexOf("."))+"_"+formatTime;
        
		logWriter 			 	= new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
//		initializeMap = initializeM(context,argTest,2,logFileName,logWriter);      //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		
		writeMessageToConsole(logWriter,"====================================================================================");
		writeMessageToConsole(logWriter,"WorkSpace Create MIGRATION "+ getTimeStamp()+" \n");
		writeMessageToConsole(logWriter,"Reading input log file from : "+inputDirectory+fileName);
		writeMessageToConsole(logWriter,"Writing Log files to: " + outputDirectory );
		writeMessageToConsole(logWriter,"====================================================================================\n");
		int lineNumber = 0;
		StringList stListHeader = new StringList();
		String recordRowNum     = "";
		boolean checkTriggerOff = false;
		try{
			MqlUtil.mqlCommand(context, "history off");
			MqlUtil.mqlCommand(context, "Trigger Off");
			checkTriggerOff = true;
			final HttpSession HttpServletRequest = null;
			
			//project 검색
			String projectWhere = "attribute[cdmCheckMigration] == 'Y' && attribute[cdmProjectObjectIdM] != '' && from[cdmProjectRelationshipWorkspace] == 'True'  ";
			
			SelectList selectListProject = new SelectList();
			selectListProject.add("attribute[cdmProjectCode]");
			selectListProject.add("attribute[cdmProjectObjectIdM]");
			selectListProject.add("from[cdmProjectRelationshipWorkspace].to.id");
			
			selectListProject.addId();
		
			MapList mListProject = new MapList();
			mListProject = DomainObject.findObjects(context,
							"cdmProjectGroupObject",
							 "*", // name
							 "*", // rev
							 "*", // owner
							 "*", // vault
							 projectWhere, // where
							false, // expand
							selectListProject); // select 
			HashMap<String,String> projectHMap = new HashMap<String,String>();
			for (Iterator iterProject = mListProject.iterator(); iterProject.hasNext();) {
				Map projectMap = (Map) iterProject.next();
				String projectCode = (String)projectMap.get("attribute[cdmProjectObjectIdM]");
				String projectId = (String)projectMap.get("id");
				String relWorkspaceId = (String)projectMap.get("from[cdmProjectRelationshipWorkspace].to.id");
				relWorkspaceId = isVaildNullData(relWorkspaceId);
				
				String chekcValue = projectHMap.get(projectCode);
				if(UIUtil.isNullOrEmpty(chekcValue)){
					projectHMap.put(projectCode, relWorkspaceId);
				}
				
			}
			
			//test 0210 start 운영에서는 사용하지않는다. 
//			HashMap alreadyExistFolderMap = new HashMap();
//			String wvWhere = "attribute[cdmCheckMigration]==Y";
//			StringList selectListWV = new StringList();
//			selectListWV.add("id");
//			selectListWV.add("attribute[cdmTDMXID]");
//			
//			MapList mListWV = new MapList();
//			mListWV = DomainObject.findObjects(context,
//							"Workspace Vault",
//							 "*", // name
//							 "*", // rev
//							 "*", // owner
//							 "*", // vault
//							 wvWhere, // where
//							false, // expand
//							selectListWV); // select 
//			
//			for (Iterator iterWV = mListWV.iterator(); iterWV.hasNext();) {
//				Map mapWV = (Map) iterWV.next();
//				String sWVTdmxId = (String)mapWV.get("attribute[cdmTDMXID]");
//				String sWVId = (String)mapWV.get("id");
//				
//				alreadyExistFolderMap.put(sWVTdmxId,sWVId);
//				
//			}
			//test 0210 end 운영에서는 사용하지않는다 
			
			String languageStr = (String) context.getLocale().getLanguage();
			String strPolicyWorkspaceVault = PropertyUtil.getSchemaProperty(context, "policy_ProjectVault"); // Workspace Vaults
			String strRelProjectVaults = PropertyUtil.getSchemaProperty(context, "relationship_ProjectVaults"); // Data Vaults
			String strTypefolder = PropertyUtil.getSchemaProperty(context, "type_ProjectVault"); // Workspace Vault
			
			String strRelSubProjectValues = "Sub Vaults";
			String strSubType = "Workspace Vault";
			String strSubPolicy = "Workspace Vaults";
			
			String stReadData = "";
			
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory+fileName),"euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null){
				StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
				
				if(lineNumber == 0){
					writeFailToFile(failedObjectidWriter, "errorData \t errorNum \t"+stReadData);
					stListHeader = stListReadData ;
					lineNumber++;
					
					continue;
				}
				
				lineNumber++;
				totalCount = lineNumber;
				LinkedHashMap<String, Object> linkedWorkspaceFolderHM = new LinkedHashMap<String,Object>();
				
				
				/*
				 * #                    :RowNummer
				 * CLS_NAME             :
				 * TDMX_ID              :attribute[TDMXID]
				 * REVISION             :
				 * CRT_USERS            :owner
				 * MOD_USERS            :
				 * TDM_DESCRIPTION      :name
				 * TDM_ORG_USER_ID      :
				 * PROD_DIV             :
				 * CN_PROJECT           :
				 * CN_PROJECT_CUST      :
				 * CN_PRODUCT_GROUP     :
				 * CN_CUSTOMER          :
				 * CN_VEHICLE           :
				 * CN_PROJECT_ID        :CN_PROJECT_ID
				 * PROD_GROUP           :project
				 * CN_CUST_VEHICLE      :org
				 * ISTOP 				:top level check (true:1 false:0)
				*/
				
				int headerSize = stListHeader.size();
				int readDataSize = stListReadData.size();
				
				if(headerSize != readDataSize){
					throw new Exception("not match line info");
				}
				
				for (int cnt = 0; cnt < stListHeader.size(); cnt++) {
					String hedaerInfo = (String)stListHeader.get(cnt);
					String tempData = (String)stListReadData.get(cnt);
					
					tempData = isVaildNullData(tempData);
					linkedWorkspaceFolderHM.put(hedaerInfo, tempData);
				}
				WorkspaceVault wVaultCommon = new WorkspaceVault();
				try {
					
					/* parent 와 child 둘다 생성하며 fail시 둘다 생성되지않고 오류 로그 남긴다. */
					
					String sRowNum				= (String) linkedWorkspaceFolderHM.get("#");
					String sTDMXID		 		= (String) linkedWorkspaceFolderHM.get("TDMX_ID");
					String sUser		 		= (String) linkedWorkspaceFolderHM.get("CRT_USERS");
					String sFolderName 			= (String) linkedWorkspaceFolderHM.get("TDM_DESCRIPTION");
					String sProjectId  			= (String) linkedWorkspaceFolderHM.get("CN_PROJECT_ID");
//					String sChildFolderDescription  = (String) linkedWorkspaceFolderHM.get("CN_PROJECT_ID");
					String sProjectGroup  				= (String) linkedWorkspaceFolderHM.get("PROD_GROUP");
					String sCustVehicle  					= (String) linkedWorkspaceFolderHM.get("CN_CUST_VEHICLE");
					String sIsTOP  					= (String) linkedWorkspaceFolderHM.get("ISTOP");
					
					recordRowNum = sRowNum;

					boolean bProjectExist = false;
					String pFolderId   = "";
					String accessType  = "";
					
					/* ********************************************************************************************
					 * 0210 start 
					 *  수정한 top 체크  테스트만을 위한 데이타이며 운영에서는 사용하지않는다.
					 ******************************************************************************************** */
//					String sExistFolderId = "";
//					sExistFolderId = (String)alreadyExistFolderMap.get(sTDMXID);
//					if(UIUtil.isNotNullAndNotEmpty(sExistFolderId) && "0".equals(sIsTOP)){
//						DomainObject dObjExistF = new DomainObject(sExistFolderId);
//						String sRelDataVaultId = "";
//						sRelDataVaultId = dObjExistF.getInfo(context, "to[Data Vaults].id");
//						
//						if(UIUtil.isNotNullAndNotEmpty(sRelDataVaultId)){
//							DomainRelationship relDataVault = new DomainRelationship();
//							relDataVault.disconnect(context, sRelDataVaultId);
//						}
//					}else if(UIUtil.isNotNullAndNotEmpty(sExistFolderId) && "1".equals(sIsTOP)){
//						DomainObject dObjExistF = new DomainObject(sExistFolderId);
//						String sToDataVaultId = "";
//						sToDataVaultId = dObjExistF.getInfo(context, "to[Data Vaults].from.id");
//						
//						if(UIUtil.isNotNullAndNotEmpty(sToDataVaultId)){
//							DomainObject dObjWorkSpace = new DomainObject(sToDataVaultId);
//							String currentSate =dObjWorkSpace.getCurrentState(context).getName();
//							if(!"Active".equals(currentSate)){
//								dObjWorkSpace.setState(context, "Active");
//							}
//						}
//					}
//					
//					if(UIUtil.isNotNullAndNotEmpty(sExistFolderId)) {
//						//에러가 아니므로 failWriter에는 기록하지 않는다. 9 라고 기록한다.
//						writeMessageToConsole(logWriter,recordRowNum+" \t 9 \t"+ sTDMXID+"\t"+sFolderName+"\t"+sProjectId+"\t"+sProjectGroup+"\t"+sCustVehicle+"\t"+sIsTOP);
//						failCount++;
//						
//						continue;
//					}
					/* ******************************************************************************************* 
					 *   0210 end  
					 *   수정한 top 체크  테스트만을 위한 데이타이며 운영에서는 사용하지않는다.
					  *******************************************************************************************  */
					String personIdMql = "temp query bus Person '" + sUser + "' - select id dump |";
					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
					String stPerson = "";
					boolean boolPerson = false;
					if (stListPersonIdMql.size() > 2) {
						stPerson = (String) stListPersonIdMql.get(3);
						boolPerson = true;
					}
					
					/*
					 * project id 
					 */
					String strWorkspaceId = ""; 
					if(UIUtil.isNotNullAndNotEmpty(sProjectId)){
						bProjectExist = true;
						strWorkspaceId = (String)projectHMap.get(sProjectId);
					}
					
//					if(UIUtil.isNullOrEmpty(strWorkspaceId) && cdmStringUtil.isNotEmpty(sProjectId) ){
//						throw new Exception("workspace info exist but enovia object not exist.");
//					}
					// #################################################################################################################################
					// cdmProjectRelationshipWorkspace
					// #################################################################################################################################
					//workspace id
					
					
					ContextUtil.startTransaction(context, true);
					if (bProjectExist && UIUtil.isNotNullAndNotEmpty(strWorkspaceId)) {
						DomainObject dObjWorkspace = new DomainObject(strWorkspaceId);
//						String strPhysicalId = (String) dObjWorkspace.getInfo(context, "physicalid");
						String strProjectVault = (String) dObjWorkspace.getVault();
						Workspace workspace        = (Workspace) DomainObject.newInstance(context,DomainConstants.TYPE_WORKSPACE,DomainConstants.TEAM);
						workspace.setId(strWorkspaceId);
						/*folder 정보는 revision 정보를   physicalid 값을 사용하지 않는다. */
							
						long revision = System.currentTimeMillis();
						WorkspaceVault wVault = new WorkspaceVault();
//						System.out.println(sFolderName);
						
						wVault.createObject(context, strTypefolder, sFolderName,String.valueOf(revision) , strPolicyWorkspaceVault, strProjectVault);
						
						HashMap<String, String> attrMap = new HashMap<String, String>();
						if(boolPerson){
							wVault.setOwner(context, sUser);
							attrMap.put("Originator", sUser);
						}
						attrMap.put("cdmCheckMigration", "Y");
						attrMap.put("cdmTDMXID", sTDMXID);
						wVault.setAttributeValues(context, attrMap);
						
						if("1".equals(sIsTOP)){
							wVault.connect(context, strRelProjectVaults, (DomainObject)workspace, true);
						}
						wVaultCommon = wVault;	
						
					}else{
						// project 없는 데이타도 존재함 뿐만 아니라 중복으로 인한 workspace가 존재하지 않는 경우도 존재 
						
							long revisionNotProject = System.currentTimeMillis();
							WorkspaceVault wVaultNotProject = new WorkspaceVault();
							wVaultNotProject.createObject(context, strTypefolder, sFolderName,String.valueOf(revisionNotProject) , strPolicyWorkspaceVault, context.getVault().getName());
							HashMap<String, String> attrMap = new HashMap<String, String>();
							attrMap.put("cdmCheckMigration", "Y");
							attrMap.put("cdmTDMXID", sTDMXID);
							
							if(boolPerson){
								wVaultNotProject.setOwner(context, sUser);
//								wVaultNotProject.setAttributeValue(context, "Originator", sUser);
								attrMap.put("Originator", sUser);
							}
							wVaultNotProject.setAttributeValues(context, attrMap);
							wVaultCommon = wVaultNotProject;
//						failCount++;
					}
					ContextUtil.commitTransaction(context);
					
					successCount++;	
					StringBuffer sbErrorMessage = new StringBuffer();
					boolean notSecurityConetxt = false;
					try {
						
						if(StringUtils.isNotEmpty(sProjectGroup) && StringUtils.isNotEmpty(sCustVehicle) && !" - ".equals(sCustVehicle) ) {
//							MqlUtil.mqlCommand(context, "Trigger Off");
							MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3",wVaultCommon.getObjectId(context) , sProjectGroup, sCustVehicle);
//							MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", wVaultCommon.getObjectId(context), sProjectGroup, sCustVehicle);
//							MqlUtil.mqlCommand(context, "Trigger On");
							notSecurityConetxt = true;
						}
						
					} catch (Exception e) {
						sbErrorMessage.append(sProjectGroup).append("\t").append(sCustVehicle).append("\t");
					}
					writeSuccessToFile(successObjectidWriter, recordRowNum+"\t"+sTDMXID+"\t"+sFolderName+"\t"+sProjectId+"\t"+sIsTOP+"\t"+notSecurityConetxt+"\t"+sbErrorMessage.toString());
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failCount++;
					String message = exception.getMessage();
					if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not exist project.")){
						writeFailToFile(failedObjectidWriter,cdmCommonExcel.getTimeStamp2()+"\t"+"1 \t "+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("workspace info exist but enovia object not exist.")){
						writeFailToFile(failedObjectidWriter,cdmCommonExcel.getTimeStamp2()+"\t"+"2 \t "+stReadData);
					}else if( UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not match line info")){
						writeFailToFile(failedObjectidWriter,cdmCommonExcel.getTimeStamp2()+"\t"+"3 \t "+stReadData);
					}else{
						writeFailToFile(failedObjectidWriter,cdmCommonExcel.getTimeStamp2()+"\t"+"0 \t "+stReadData);
					}
					writeMessageToConsole(logWriter,recordRowNum+"\t"+ exception.getMessage());
					writeErrorToFile(errorStream,"LINE NUMBER: \t" + recordRowNum );
					
					exception.printStackTrace(errorStream);

				}finally{
					
					
					
				}
			}
			

		writeMessageToConsole(logWriter,"====================================================================================");
		writeMessageToConsole(logWriter,"        File WorkSpace Migration COMPLETED.                    ");
		writeMessageToConsole(logWriter,"====================================================================================\n");
	
		
		}catch(Exception exception){
	
			writeMessageToConsole(logWriter, "LINE NUMBER: \t" + recordRowNum + "\t" + exception.getMessage());
			writeErrorToFile(errorStream, "LINE NUMBER: \t" + recordRowNum + "\t " + exception.getMessage());
			exception.printStackTrace(errorStream);
		}finally{
	
		writeMessageToConsole(logWriter, "====================================================================================");
		writeMessageToConsole(logWriter, "CLOSE TIME:" + getTimeStamp() + "                                    ");
		writeMessageToConsole(logWriter, "LEAD TIME:" + (System.currentTimeMillis() - startTime) / 1000 / 60 + "ms        \n");
		writeMessageToConsole(logWriter, "FailCount: (" + failCount + ") SuccessCount: (" + successCount + ") totalCount:(" + (totalCount - 1) + ")");

		writeMessageToConsole(logWriter, "==================================================================================== \n");
		System.out.println("[${CLASS:cdmWorkSpaccdmWorkspaceFolderMigration} : executeFolderMigration] end ." + cdmCommonExcel.getTimeStamp2());
		// closeLogStream();
		
		if(checkTriggerOff){
			MqlUtil.mqlCommand(context, "Trigger On");
		}
		MqlUtil.mqlCommand(context, "history off");
		try {
			if (null != logWriter)
				logWriter.close();

			if (null != errorStream)
				errorStream.close();

			if (null != successObjectidWriter)
				successObjectidWriter.close();

			if (null != failedObjectidWriter)
				failedObjectidWriter.close();

			if (null != bufferReader)
				bufferReader.close();
			
		} catch (IOException e) {
			System.out.println("Exception while closing log stream " + e.getMessage());
		}

	}
	}

	
	
	
	/**
	 * workspace 연결 없으면 에러 (workspace가 존재하지 않아 에러난것을 예외 처리 ) 그런경우 에러는 따로 보관
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void connectWorkspaceValut(Context context, String args[]) throws Exception {
		long startTime = System.currentTimeMillis();
		System.out.println("[${CLASS:cdmWorkSpaceMigration} : executeFolderMigration] start ." + cdmCommonExcel.getTimeStamp2());

		BufferedWriter logWriter = null;
		BufferedWriter successObjectidWriter = null;
		BufferedWriter failedObjectidWriter = null;
		BufferedWriter noExistWriter = null;
		BufferedReader bufferReader = null;

		PrintStream errorStream = null;
		File successLogFile = null;
		File failedLogFile = null;
		File noExistFile = null;

		String inputDirectory = "";
		String outputDirectory = "";
		String fileName = "";

		int totalCount = 0;
		int failCount = 0;
		int successCount = 0;
		String logFileName = "FolderConnectM";

		String sFileLocationAndFileName = args[0];

		String sFileLocation = "";
		String sFileName = "";

		sFileLocation = sFileLocationAndFileName.substring(0, sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName = sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\") + 1);
		logFileName += "_" + sFileName;
		String[] argTest = { sFileLocation, sFileName }; // 읽을 파일경로 ,읽을 파일명

		if (argTest.length != 2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}

		inputDirectory = argTest[0];
		fileName = argTest[1];

		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + Output_Directory + sfileSeparator + logFileName + "_" +  sfileSeparator;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));

		noExistFile = new File(outputDirectory + logFileName + "_noExistLog" + ".txt");
		noExistWriter = new BufferedWriter(new FileWriter(noExistFile, true));

		// initializeMap = initializeM(context,argTest,2,logFileName,logWriter);
		// //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.

		writeMessageToConsole(logWriter, "====================================================================================");
		writeMessageToConsole(logWriter, "     WorkSpace DATA MIGRATION " + getTimeStamp() + " \n");
		writeMessageToConsole(logWriter, "		Reading input log file from : " + inputDirectory + fileName);
		writeMessageToConsole(logWriter, "		Writing Log files to: " + outputDirectory);
		writeMessageToConsole(logWriter, "====================================================================================\n");
		int lineNumber = 0;
		StringList stListHeader = new StringList();
		String recordRowNum = "";

		try {
			final HttpSession HttpServletRequest = null;

			// project 검색
			String wvWhere = "attribute[cdmCheckMigration] == 'Y' && attribute[cdmTDMXID] !='' ";

			SelectList selectListProject = new SelectList();
			selectListProject.add("attribute[cdmTDMXID]");
			selectListProject.add("id");

			selectListProject.addId();

			MapList mListWV = new MapList();
			mListWV = DomainObject.findObjects(context, "Workspace Vault",
					"*", // name
					"*", // rev
					"*", // owner
					"*", // vault
					wvWhere, // where
					false, // expand
					selectListProject); // selectb
			
			HashMap<String, String> wVHMap = new HashMap<String, String>();
			for (Iterator iterWV = mListWV.iterator(); iterWV.hasNext();) {
				Map mapWV = (Map) iterWV.next();
				String wvAttrTdmxId = (String) mapWV.get("attribute[cdmTDMXID]");
				String wvId = (String) mapWV.get("id");
				wvAttrTdmxId = isVaildNullData(wvAttrTdmxId);

				wVHMap.put(wvAttrTdmxId, wvId);
			}


			String strPolicyWorkspaceVault = PropertyUtil.getSchemaProperty(context, "policy_ProjectVault"); // Workspace
																												// Vaults
			String strRelProjectVaults = PropertyUtil.getSchemaProperty(context, "relationship_ProjectVaults"); // Data
																												// Vaults
			String strTypefolder = PropertyUtil.getSchemaProperty(context, "type_ProjectVault"); // Workspace
																									// Vault

			String strRelSubProjectValues = "Sub Vaults";
			String strSubType = "Workspace Vault";
			String strSubPolicy = "Workspace Vaults";

			String stReadData = "";
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null) {
				StringList stListReadData = FrameworkUtil.split(stReadData, "\t");

				if (lineNumber == 0) {
					writeFailToFile(failedObjectidWriter, stReadData);
					stListHeader = stListReadData;
					lineNumber++;
					
					continue;
				}

				lineNumber++;
				totalCount = lineNumber;
				LinkedHashMap<String, Object> linkedWorkspaceFolderHM = new LinkedHashMap<String, Object>();

				/*
				 * 0: #
				 * 1: CLASS_ID1
				 * 2: OBJECT_ID1
				 * 3: CLASS_ID2
				 * 4: OBJECT_ID2
				 * 5: TDMX_ID <parent Folder>
				 * 6: TDM_DESCRIPTION
				 * 7: TDMX_ID <childe Folder>
				 * 8 TDM_DESCRIPTION
				 */

				for (int cnt = 0; cnt < stListReadData.size(); cnt++) {
					String sLocation = String.valueOf(cnt);
					String tempData = (String) stListReadData.get(cnt);
					linkedWorkspaceFolderHM.put(sLocation, tempData);
				}

				try {

					/* parent 와 child 둘다 생성하며 fail시 둘다 생성되지않고 오류 로그 남긴다. */

					String sRowNum = (String) linkedWorkspaceFolderHM.get("0");
					String sParentFolderAttrTDMXID = (String) linkedWorkspaceFolderHM.get("5");
					String sChildFolderAttrTDMXID = (String) linkedWorkspaceFolderHM.get("7");

					recordRowNum = sRowNum;

					String languageStr = (String) context.getLocale().getLanguage();
					
					boolean bParentExists = false;
					boolean bChildExists = false;
					String pFolderId = "";
					String accessType = "";

					String stTDMXIdParent = ""; 
					String stTDMXIdChild = ""; 
					stTDMXIdParent = wVHMap.get(sParentFolderAttrTDMXID);
					stTDMXIdChild = wVHMap.get(sChildFolderAttrTDMXID);
					
					if(UIUtil.isNullOrEmpty(stTDMXIdChild) || UIUtil.isNullOrEmpty(stTDMXIdParent) ){
						if(UIUtil.isNullOrEmpty(stTDMXIdChild) && UIUtil.isNotNullAndNotEmpty(stTDMXIdParent)){
							writeNoExistToFile(noExistWriter, recordRowNum+"\t"+"\t"+stTDMXIdChild);
						}else if(UIUtil.isNotNullAndNotEmpty(stTDMXIdChild) && UIUtil.isNullOrEmpty(stTDMXIdParent)){
							writeNoExistToFile(noExistWriter, recordRowNum+"\t"+stTDMXIdParent+"\t");
						}else if(UIUtil.isNotNullAndNotEmpty(stTDMXIdChild) && UIUtil.isNullOrEmpty(stTDMXIdParent)){
							writeNoExistToFile(noExistWriter, recordRowNum+"\t"+stTDMXIdParent+"\t"+stTDMXIdChild);
						}
						throw new Exception("not exist object ");
					}

					WorkspaceVault wVaultParent = new WorkspaceVault(stTDMXIdParent);
					WorkspaceVault wVaultChild = new WorkspaceVault(stTDMXIdChild);

					BusinessObject boParentWorkspaceValut = null;


					ContextUtil.startTransaction(context, true);
					DomainRelationship.connect(context, new DomainObject(wVaultParent.getObjectId()), WorkspaceVault.RELATIONSHIP_SUB_VAULTS, new DomainObject(wVaultChild.getObjectId(context))); 
//					wVaultChild.connectTo(context,	WorkspaceVault.RELATIONSHIP_SUB_VAULTS, new DomainObject(wVaultParent.getObjectId()));
					
//					ContextUtil.abortTransaction(context);
					ContextUtil.commitTransaction(context);
					writeSuccessToFile(successObjectidWriter, recordRowNum+"\t"+sParentFolderAttrTDMXID+"\t"+sChildFolderAttrTDMXID);
					successCount++;
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					writeFailToFile(failedObjectidWriter, stReadData);
					writeMessageToConsole(logWriter, recordRowNum + "\t" + exception.getMessage());
					writeErrorToFile(errorStream, "LINE NUMBER: \t" + recordRowNum);
					failCount++;
					exception.printStackTrace(errorStream);

				}
			}

			writeMessageToConsole(logWriter, "====================================================================================");
			writeMessageToConsole(logWriter, "        File WorkSpace Migration COMPLETED.                    ");
			writeMessageToConsole(logWriter, "====================================================================================\n");

		} catch (Exception exception) {
			writeMessageToConsole(logWriter, "LINE NUMBER: \t" + recordRowNum + "\t" + exception.getMessage());
			writeErrorToFile(errorStream, "LINE NUMBER: \t" + recordRowNum + "\t " + exception.getMessage());
			exception.printStackTrace(errorStream);
		} finally {
			writeMessageToConsole(logWriter, "====================================================================================");
			writeMessageToConsole(logWriter, "CLOSE TIME:" + getTimeStamp() + "                                    ");
			writeMessageToConsole(logWriter, "LEAD TIME:" + (System.currentTimeMillis() - startTime) / 1000 / 60 + "ms        \n");
			writeMessageToConsole(logWriter, "FailCount: (" + failCount + ") SuccessCount: (" + successCount + ") totalCount:(" + (totalCount - 1) + ")");

			writeMessageToConsole(logWriter, "==================================================================================== \n");
			System.out.println("[${CLASS:cdmWorkSpaccdmWorkspaceFolderMigration} : executeFolderMigration] end .");
			// closeLogStream();
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();

				if (null != bufferReader)
					bufferReader.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

		}

	}

	
	
	
	/**
	 * null 발생시 "" 로 체크
	 * 
	 * @param data
	 * @return
	 */
	public String isVaildNullData(String data) {
		return ((data == null || "null".equals(data)) ? "" : data.trim());
	}

	private boolean isValidData(String data) {
		return ((data == null || "null".equals(data)) ? 0 : data.trim().length()) > 0;
	}

	private void writeErrorToFile(PrintStream errorStream, String message) throws Exception {
		errorStream.write(message.getBytes("UTF-8"));
		errorStream.write("\n".getBytes("UTF-8"));
	}

	private void writeMessageToConsole(BufferedWriter logWriter, String message) throws Exception {
		writeMessageToLogFile(logWriter, message);
	}

	private void writeMessageToLogFile(BufferedWriter logWriter, String message) throws Exception {
		logWriter.write(message + "\n");
		logWriter.flush();
	}

	private String getTimeStamp() {
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date) + "T" + new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}

	public void writeFailToFile(BufferedWriter failedObjectidWriter, String message) throws Exception {
		failedObjectidWriter.write(message + "\n");
		failedObjectidWriter.flush();
	}

	public void writeSuccessToFile(BufferedWriter successObjectidWriter, String message) throws Exception {
		successObjectidWriter.write(message + "\n");
		successObjectidWriter.flush();
	}
	
	public void writeNoExistToFile(BufferedWriter noExist , String message) throws Exception {
		noExist.write(message + "\n");
		noExist.flush();
	}

	/**
	 * args{inputDirectory,
	 * 
	 * @param context
	 * @param args
	 * @param requestAgsNum
	 * @param logFileName
	 */
	// private void initializeM(Context context,String args[],int requestAgsNum
	// , String logFileName)throws Exception{
	//
	// if (args.length != requestAgsNum )
	// {
	// throw new IllegalArgumentException("Wrong number of arguments or
	// arguments with wrong values!");
	// }
	//
	//
	// inputDirectory = args[0];
	//
	// // input file name
	// fileName = args[1];
	//
	// // documentDirectory does not ends with "/" add it
	// if(inputDirectory != null && !inputDirectory.endsWith(sfileSeparator))
	// {
	// inputDirectory = inputDirectory + sfileSeparator;
	// }
	//
	// // create a directory to add debug and error logs
	// outputDirectory = new File(inputDirectory).getParentFile().getParent() +
	// sfileSeparator + "confirm_File" + sfileSeparator + logFileName +"_"+
	// getTimeStamp() + sfileSeparator;
	// File fileOutputDirectory = new File(outputDirectory);
	// if(!fileOutputDirectory.isDirectory()){
	// fileOutputDirectory.mkdirs();
	// }
	// logWriter = new BufferedWriter(new FileWriter(outputDirectory +
	// logFileName + "_DebugLog.txt",true));
	// errorStream = new PrintStream(new FileOutputStream(new
	// File(outputDirectory + logFileName + "_ErrorLog.txt")));
	//
	// successLogFile = new File(outputDirectory + logFileName +
	// "_SuccessObjectids.log");
	// successObjectidWriter = new BufferedWriter(new
	// FileWriter(successLogFile,true));
	//
	// failedLogFile = new File(outputDirectory + logFileName +
	// "_FailedObjectids" + ".txt");
	// failedObjectidWriter = new BufferedWriter(new
	// FileWriter(failedLogFile,true));
	//
	//
	// }

	/**
	 * folder 하위에 cad 연결
	 * 
	 * args :file 경로 포함한 file name 
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void executeFolderCADMigration(Context context, String args[]) throws Exception {
		long startTime = System.currentTimeMillis();
		System.out.println("[${CLASS:cdmWorkSpaceMigration} : executeFolderCADMigration] start ." + cdmCommonExcel.getTimeStamp2());

		BufferedWriter logWriter = null;
		BufferedWriter successObjectidWriter = null;
		BufferedWriter failedObjectidWriter = null;
//		BufferedWriter errorLogFile = null;
		BufferedWriter noExistWriter = null;
		BufferedReader bufferReader = null;

		String inputDirectory = "";
		String outputDirectory = "";
		String fileName = "";

		String failedIdsLogsDirectory = "";
		PrintStream errorStream = null;
		File successLogFile = null;
		File failedLogFile = null;
		File noExistFile = null;

		String logFileName = "FolderCAD";

		String sFileLocationAndFileName = args[0];
//테스트 
//		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
//		String sFileLocationAndFileName = (String)paramMap.get("fileData");
		
		String sFileLocation = "";
		String sFileName = "";

		sFileLocation = sFileLocationAndFileName.substring(0, sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName = sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\") + 1);

		
		// 읽을 파일경로 ,읽을 파일명
		String[] argTest = { sFileLocation, sFileName };

		if (argTest.length != 2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}

		inputDirectory = argTest[0];
		// input file name
		fileName = argTest[1];

		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + Output_Directory + sfileSeparator + logFileName + sfileSeparator;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
		logFileName += "_" + sFileName.substring(0, sFileName.lastIndexOf("."))+"_"+formatTime;
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));

		noExistFile = new File(outputDirectory + logFileName + "_noExistLog" + ".txt");
		noExistWriter = new BufferedWriter(new FileWriter(noExistFile, true));
				
		int totalCount = 0;
		int successCount = 0;
		int failedCount = 0;
		int noExistCount = 0;
		
		// initializeMap = initializeM(context,argTest,2,logFileName,logWriter);
		// //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		writeErrorToFile(errorStream, inputDirectory+fileName);
		writeMessageToConsole(logWriter, "====================================================================================");
		writeMessageToConsole(logWriter, "FOLDER RELATION CAD DATA MIGRATION " + getTimeStamp() + " \n");
		writeMessageToConsole(logWriter, "Reading input log file from : " + inputDirectory + fileName);
		writeMessageToConsole(logWriter, "Writing Log files to: " + outputDirectory);

		writeMessageToConsole(logWriter, "====================================================================================\n");
		int lineNumber = 0;
		StringList stListHeader = new StringList();
		String recordRowNum = "";

		try {

			MqlUtil.mqlCommand(context, "history off");
//			MqlUtil.mqlCommand(context, "Trigger Off");
			
			// folder 검색
			StringList selectList = new StringList();
			selectList.add("id");
			selectList.add("attribute[cdmTDMXID]");
			String sFolderWhere = "attribute[cdmCheckMigration] == 'Y' && attribute[cdmTDMXID] != '' ";
			MapList mListFolder = new MapList();
			mListFolder = DomainObject.findObjects(context, 
					cdmConstantsUtil.TYPE_WORKSPACE_VAULT,    
					"*",                                      
					"*",                                      
					"*",                                      
					"*",                   					
					sFolderWhere,                             
					true,                                     
					selectList);

			HashMap<String, String> folderHMap = new HashMap<String, String>();
//			for (Iterator iterFoler = mListFolder.iterator(); iterFoler.hasNext();) {
			for (int folderNum = 0; folderNum < mListFolder.size(); folderNum++) {
				
				Map folderMap = (Map) mListFolder.get(folderNum);
				String folderId = (String) folderMap.get("id");
				String folderUniqTDMXId = (String) folderMap.get("attribute[cdmTDMXID]");

				folderHMap.put(folderUniqTDMXId, folderId);

			}

			// cad 검색
			SelectList cadSelectList = new SelectList();
			cadSelectList.addId();
			cadSelectList.add("attribute[cdmRevisionCheckInM]");
			cadSelectList.add("attribute[cdmTDMXID]");
			cadSelectList.add("revision");
			String sCadWhere = "attribute[cdmCheckMigration] == 'Y' && attribute[cdmTDMXID] !='' && attribute[cdmRevisionCheckInM] !='' && ( policy == '"+cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION+"' || policy == 'Document Release' ) ";
			MapList mListCad = new MapList();
			mListCad = DomainObject.findObjects(context,
					"*",                           
					"*",                                        
					"*",                                        
					"*",                                        
					"*",        				
					sCadWhere,                                          
					true,                          
					cadSelectList);

			HashMap<String, String> cadHMap = new HashMap<String, String>();

			for (Iterator iterCad = mListCad.iterator(); iterCad.hasNext();) {
				Map cadMap = (Map) iterCad.next();
				String cadId = (String) cadMap.get("id");
				String cadTDMXId = (String) cadMap.get("attribute[cdmTDMXID]");
//				String cadCheckRevision = (String) cadMap.get("attribute[cdmRevisionCheckInM]");
				String cadCheckRevision = (String) cadMap.get("revision");

				cadHMap.put(cadTDMXId+cadCheckRevision, cadId);
			}
			int headerSize = 0;
			final HttpSession HttpServletRequest = null;
			String stReadData = "";
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null) {
				StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
				try {
				if (lineNumber == 0) {
					stListHeader = stListReadData;
					headerSize = stListReadData.size();
					lineNumber++;
					continue;
				}
				lineNumber++;
				totalCount = lineNumber;
				
				int readDateSize = stListReadData.size();
				if(readDateSize != headerSize){
					throw new Exception("not match data information.");
				}
				LinkedHashMap<String, Object> linkedWorkspaceFolderHM = new LinkedHashMap<String, Object>();
				
				/*
				 * *************************************************************
				 *  텍스트 필드 정보 
				 * 0 :# : Row Number 
				 * 1 :CLASS_ID1 
				 * 2 :OBJECT_ID1 
				 * 3 :CLASS_ID2 
				 * 4 :OBJECT_ID2
				 * 5 :TDMX_ID_F : FOLDER NAME 
				 * 6 :TDM_DESCRIPTION_F : FOLDER DESCRIPTION 
				 * 7 :TDMX_ID : CAD NAME 
				 * 8 :REVISION : CAD REV( 최신만 받아오는 아닐경우 대비 ) 
				 * 9 :TDM_DESCRIPTION : CAD DESCRIPTION
				 * 10:TDMX_RELATED_ITEM_ID : PART NAME 
				 * 11:CN_RELATED_ITEM_NAME : PART attribute[cdmDescription]
				 * *************************************************************
				 * 

				 */

				for (int cnt = 0; cnt < stListReadData.size(); cnt++) {
//					String sLocation = String.valueOf(cnt);
					String tempHeaderData = (String) stListHeader.get(cnt);
					String tempData = (String) stListReadData.get(cnt);
					tempHeaderData = isVaildNullData(tempHeaderData);
					tempData = isVaildNullData(tempData);
					linkedWorkspaceFolderHM.put(tempHeaderData, tempData);

				}

				

					/*
					 * *********************************************************
					 * folder 정보 없을시 에러 처리 cad
					 * 1 정보 없을시 에러 처리
					 * 2 part정보는 처리하지않는다 (cad에 Part 가 이미 달려있다고 가정)
					 * 3 folder와 cad 정보 연결 cad 정보는 중복되지 않는다. 추후 cad 정보가 존재하지 않는 경우
					 *  확인후 cad 생성하려 part 연결하도록진행 할듯 .....
					 * *********************************************************
					 * 
					 */

					String sRowNumber = (String) linkedWorkspaceFolderHM.get("NO");
					String sFolderUniqAttr = (String) linkedWorkspaceFolderHM.get("TDMX_ID_F");
					String sFolderDescription = (String) linkedWorkspaceFolderHM.get("TDM_DESCRIPTION_F");
					String sCADName = (String) linkedWorkspaceFolderHM.get("TDMX_ID");
					String sCADRev = (String) linkedWorkspaceFolderHM.get("REVISION");
					String sCADDescription = (String) linkedWorkspaceFolderHM.get("TDM_DESCRIPTION");
					String sMajorOrMinor = (String) linkedWorkspaceFolderHM.get("MAJOR");
					recordRowNum = sRowNumber;

					String sCADId = "";
					String sFolderId = "";
					boolean bMajor = false;
					boolean bCADMajorExist = false;
					boolean bFolderExist = false;
					
					
					if(UIUtil.isNotNullAndNotEmpty(sMajorOrMinor) && "MAJOR".equalsIgnoreCase(sMajorOrMinor)){
						bMajor = true;
					}else {
						writeMessageToConsole(logWriter, recordRowNum + "\t" +cdmCommonExcel.getTimeStamp2()+"\t"+"7" +"\t"+ "not Major");
						writeFailToFile(failedObjectidWriter, stReadData);
						failedCount++;
						continue;
					}
					
					sFolderId = (String) folderHMap.get(sFolderUniqAttr);
					if (UIUtil.isNotNullAndNotEmpty(sFolderId)) {
						bFolderExist = true;
					}
					String sMajorRevsion = sCADRev.replaceAll("\\..+", "");
					
					String cadFindMajorKey = sCADName+sMajorRevsion;
					sCADId = (String) cadHMap.get(cadFindMajorKey);
					
					if (UIUtil.isNotNullAndNotEmpty(sCADId)) {
						bCADMajorExist = true;
					}
					
					
					// ex . sRowNumber sFolderUniqAttr  sCADName 
					if (!bCADMajorExist || !bFolderExist) {
						noExistCount++;
						if (!bCADMajorExist && bFolderExist) {
							writeNoExistToFile(noExistWriter, sRowNumber+"\t"+"\t"+sCADName+"\t"+sCADRev);
							throw new Exception("not exist CAD Object.");

						} else if (bCADMajorExist && !bFolderExist) {
							writeNoExistToFile(noExistWriter, sRowNumber+"\t"+sFolderUniqAttr+"\t"+sCADRev);
							throw new Exception("not exist folder Object.");

						} else if (!bCADMajorExist && !bFolderExist) {
							writeNoExistToFile(noExistWriter, sRowNumber+"\t"+sFolderUniqAttr+"\t"+sCADName+"\t"+sCADRev);
							throw new Exception("not exist CAD and folder Object.");
						}
						
					}
					
//					DomainObject dMajorCad = DomainObject.newInstance(context, sCADId);
//					boolean bCadMinorVersionCheck = false;
//					boolean bDocMinorVersionCheck = false;
//					if(!bMajor){
//						String cadType = (String)dMajorCad.getInfo(context, "type");
//						
//						StringList sListSplitRevision = FrameworkUtil.split(sCADRev, "\\..+");
//						String splitMinorRevision = "";
//						if(sListSplitRevision.size()>2){
//							
//							String sRevisionSequnceSplit = (String)sListSplitRevision.get(2);
//							Integer intergerRevisionSequence = Integer.parseInt(sRevisionSequnceSplit);
//							intergerRevisionSequence = intergerRevisionSequence-1;
//						
//							String minorLatestId = (String)dMajorCad.getInfo(context, "from[Active Version].to.id");
//							DomainObject minorLatestDObj = new DomainObject(minorLatestId);
//							 StringList busSelects = new StringList(2);
//						     busSelects.add("id");
//						     
//							if("CATPart".equals(cadType) || "CATDrawing".equals(cadType) || "CATProduct".equals(cadType)){
//								splitMinorRevision = String.format("%01d", intergerRevisionSequence);
//								splitMinorRevision = sMajorRevsion+"."+splitMinorRevision;
//								
//							    busSelects.add("revision");
//								MapList mListMinorVersion = minorLatestDObj.getRevisionsInfo(context, busSelects, new StringList());
//							 	
//								for (int minorVersionCNT = 0; minorVersionCNT < mListMinorVersion.size(); minorVersionCNT++) {
//							 		 Map mMinorVersion = (Map)mListMinorVersion.get(minorVersionCNT);
//							 		 String sMinorCadRev = (String)mMinorVersion.get("revision");
//							 	
//							 		 if(splitMinorRevision.equals(sMinorCadRev)){
//							 			 String sMinorCadId = (String)mMinorVersion.get("id");
//							 			 dMajorCad.setId(sMinorCadId);
//							 			 bCadMinorVersionCheck = true;
//							 		
//							 			 break;
//							 		 }
//									
//								}
//								
//								
//							} else {
//
//								MapList mListMinorVersion = minorLatestDObj.getRevisionsInfo(context, busSelects, new StringList());
//								
//								for (int minorVersionCNT = 0; minorVersionCNT < mListMinorVersion.size(); minorVersionCNT++) {
//
//									Map mMinorVersion = (Map) mListMinorVersion.get(minorVersionCNT);
//								
//									if (intergerRevisionSequence == minorVersionCNT) {
//										String sMinorDocObj = (String) mMinorVersion.get("id");
//										dMajorCad.setId(sMinorDocObj);
//										bDocMinorVersionCheck = true;
//									
//										break;
//									}
//
//								}
//
//							}
//							
//							
//						}
//					}
					
					
					DomainObject dObjFolder = DomainObject.newInstance(context, sFolderId);
					ContextUtil.startTransaction(context, true);
					boolean bConnectFolder = false;
					String sRelationship = "";
//					if (dObjFolder.getType(context).equals(dObjFolder.TYPE_WORKSPACE_VAULT)) {
					if (dObjFolder.isKindOf(context,dObjFolder.TYPE_WORKSPACE_VAULT)) {
						sRelationship = cdmConstantsUtil.RELATIONSHIP_VAULTED_DOCUMENTS;
						dObjFolder.connect(context, sRelationship, new DomainObject(sCADId), false);
						bConnectFolder = true;
					}
					
					// trigger start  ownership add start 
//					final String SELECT_IS_KINDOF_PROJECT_SPACE = "type.kindof[" + DomainConstants.TYPE_PROJECT_SPACE + "]";
//					final String SELECT_COLLABORATIVE_SPACE = "project";
//
//					StringList slBusSelect = new StringList();
//					slBusSelect.add(SELECT_IS_KINDOF_PROJECT_SPACE);
//					slBusSelect.add(SELECT_COLLABORATIVE_SPACE);
//					slBusSelect.add(DomainConstants.SELECT_ORGANIZATION);
//
//					DomainObject toObj = DomainObject.newInstance(context, sCADId);
//					Map taskInfo = toObj.getInfo(context, slBusSelect);
//					String isProjectSpace = (String)taskInfo.get(SELECT_IS_KINDOF_PROJECT_SPACE);
//
//					//if the to-side object is a Project Space don't inherit access.
//					if("false".equalsIgnoreCase(isProjectSpace)){
//		              DomainAccess.createObjectOwnership(context, sCADId, sFolderId, DomainAccess.COMMENT_MULTIPLE_OWNERSHIP);
//
//						//Get from-side object details.
//						DomainObject fromObj = DomainObject.newInstance(context, sFolderId);
//						Map parentInfo = fromObj.getInfo(context, slBusSelect);
//						String parentCS = (String) parentInfo.get(SELECT_COLLABORATIVE_SPACE);
//						String parentOrg = (String) parentInfo.get(DomainConstants.SELECT_ORGANIZATION);
//
//						//Get to-side object details.
//						String childCS = (String) taskInfo.get(SELECT_COLLABORATIVE_SPACE);
//						String childOrg = (String) taskInfo.get(DomainConstants.SELECT_ORGANIZATION);
//
//						//if parent't POV is different from child's POV.
//						if(!parentCS.equals(childCS) || !parentOrg.equals(childOrg) ){
//							//if parent's POV is empty, remove child's POV too.
//							if("".equals(parentCS) || "".equals(parentOrg)){
//								toObj.removePrimaryOwnership(context);
//							}
//							else{ toObj.setPrimaryOwnership(context, parentCS, parentOrg); }
//						}
//		           }
					// trigger start  ownership add end
					//
					ContextUtil.commitTransaction(context);
					if(bConnectFolder){
						writeMessageToConsole(successObjectidWriter, recordRowNum + "\t" + sFolderUniqAttr + "\t" + sCADName+"\t"+sCADRev);
						successCount++;
					}else{
//						writeMessageToConsole(logWriter, recordRowNum + "\t" + sFolderUniqAttr + "\t" + sCADName+"\t"+sCADRev);
						writeMessageToConsole(logWriter, recordRowNum + "\t" +cdmCommonExcel.getTimeStamp2()+"\t"+"5"+"\t"+ "not type");
						writeFailToFile(failedObjectidWriter, stReadData);
						failedCount++;
					}

				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failedCount++;
					String message= exception.getMessage();
					if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not exist CAD Object.")){
						writeMessageToConsole(logWriter, recordRowNum + "\t" +cdmCommonExcel.getTimeStamp2()+"\t"+"1" +"\t"+ exception.getMessage());
						
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not exist folder Object.")){
						writeMessageToConsole(logWriter, recordRowNum + "\t" +cdmCommonExcel.getTimeStamp2()+"\t"+"2"+"\t"+ exception.getMessage());
						
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not exist CAD and folder Object.")){
						writeMessageToConsole(logWriter, recordRowNum + "\t" +cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+ exception.getMessage());
						
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not match data information.")){
						writeMessageToConsole(logWriter, recordRowNum + "\t" +cdmCommonExcel.getTimeStamp2()+"\t"+"4"+"\t"+ exception.getMessage());
					}
					else{
						writeMessageToConsole(logWriter, recordRowNum + "\t" +cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t"+ exception.getMessage());
					}
					writeErrorToFile(errorStream, "LINE NUMBER: \t" + recordRowNum + "\t" + cdmCommonExcel.getTimeStamp2());
					exception.printStackTrace(errorStream);

					writeFailToFile(failedObjectidWriter, stReadData);
				}
			}

			writeMessageToConsole(logWriter, "====================================================================================");
			writeMessageToConsole(logWriter, "File WorkSpace Migration COMPLETED.                    ");
			writeMessageToConsole(logWriter, "====================================================================================\n");

		} catch (Exception exception) {
			writeMessageToConsole(logWriter, "LINE NUMBER: " + recordRowNum + "\t Exception: " + exception.getMessage());
			writeErrorToFile(errorStream, "LINE NUMBER: " + recordRowNum + "\t" + exception.getMessage());
			exception.printStackTrace(errorStream);

		} finally {
			writeMessageToConsole(logWriter, "====================================================================================");
			writeMessageToConsole(logWriter, "CLOSE TIME:" + getTimeStamp() + "                                      ");
			writeMessageToConsole(logWriter, "LEAD TIME:" + (System.currentTimeMillis() - startTime) / 1000 / 60 + "ms        \n");
			writeMessageToConsole(logWriter, "failedCount :(" + failedCount + ") successCount: (" + successCount + ") noExistCount:("+noExistCount+")  totalCount: (" + (totalCount-1) + ")");
			writeMessageToConsole(logWriter, "==================================================================================== \n");
			System.out.println("[cdmWorkspaceFolderMigration : executeFolderCADMigration] end ." + cdmCommonExcel.getTimeStamp2());
			
			MqlUtil.mqlCommand(context, "history on");
//			MqlUtil.mqlCommand(context, "Trigger On");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				if(null != noExistWriter)
					noExistWriter.close();
				
				if(null != bufferReader)
					bufferReader.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

		}

	}

	/**
	 * 텍스트 파일 에 있는 데이타 삭제 테스트 필요 . 하위의 subfolder 존재시 삭제 folder 삭제
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void executeDeleateFolder(Context context, String[] args) throws Exception {
		long startTime = System.currentTimeMillis();
		System.out.println("[${CLASS:cdmWorkSpaceMigration} : executeDeleateFolder] start ." + startTime + "ms");

		BufferedWriter logWriter = null;
		BufferedWriter successObjectidWriter = null;
		BufferedWriter failedObjectidWriter = null;
		BufferedReader bufferReader = null;

		String inputDirectory = "";
		String outputDirectory = "";
		String fileName = "";

		PrintStream errorStream = null;
		File successLogFile = null;
		File failedLogFile = null;

		String logFileName = "FolderDeleteMigration";
		String[] argTest = { "C:\\temp\\Import_File\\WORKSPACEFOLDER", "Folder2Folder_00.txt" }; // 읽을
																									// 파일경로,읽을파일명

		if (argTest.length != 2) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}

		inputDirectory = argTest[0];
		// input file name
		fileName = argTest[1];

		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile().getParent() + sfileSeparator + "confirm_File" + sfileSeparator + logFileName + "_" + getTimeStamp() + sfileSeparator;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.log");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));

		writeMessageToConsole(logWriter, "====================================================================================");
		writeMessageToConsole(logWriter, "       FOLDER DELETE DATA MIGRATION " + getTimeStamp() + " \n");
		writeMessageToConsole(logWriter, "		Reading input log file from : " + inputDirectory);
		writeMessageToConsole(logWriter, "		Writing Log files to: " + outputDirectory);

		writeMessageToConsole(logWriter, "====================================================================================\n");
		int lineNumber = 0;
		StringList stListHeader = new StringList();
		String recordRowNum = "";
		try {
			final HttpSession HttpServletRequest = null;
			String stReadData = "";
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null) {
				StringList stListReadData = FrameworkUtil.split(stReadData, "\t");

				if (lineNumber == 0) {
					stListHeader = stListReadData;
					lineNumber++;
					continue;
				}
				// test
				if (lineNumber > 3) {
					break;
				}

				LinkedHashMap<String, Object> linkedWorkspaceFolderHM = new LinkedHashMap<String, Object>();
				for (int cnt = 0; cnt < stListReadData.size(); cnt++) {
					String sLocation = String.valueOf(cnt);
					String tempData = (String) stListReadData.get(cnt);
					linkedWorkspaceFolderHM.put(sLocation, tempData);

				}
				lineNumber++;

				try {

					String sRowNum = (String) linkedWorkspaceFolderHM.get("0");
					String sParentFolderName = (String) linkedWorkspaceFolderHM.get("5");
					String sParentFolderDescription = (String) linkedWorkspaceFolderHM.get("6");
					String sChildFolderName = (String) linkedWorkspaceFolderHM.get("7");
					String sChildFolderDescription = (String) linkedWorkspaceFolderHM.get("8");

					boolean subfold = false;
					String objectId = "";// parent Folder
					Workspace workspace = new Workspace();
					WorkspaceVault workspaceVault = new WorkspaceVault();
					BusinessObject boProject = null;

					String relSubVaultsStr = cdmConstantsUtil.RELATIONSHIP_SUBVAULTS;
					String relVaultedDocumentsStr = cdmConstantsUtil.RELATIONSHIP_VAULTED_DOCUMENTS;
					String typeProjectVault = cdmConstantsUtil.TYPE_PROJECT_VAULT;

					ContextUtil.startTransaction(context, true);
					// test
					SubscriptionManager subscriptionMgr = workspace.getSubscriptionManager();

					workspaceVault.setId(objectId);
					SubscriptionManager subscriptionWkVaultMgr = workspaceVault.getSubscriptionManager();

					StringList SelectList = new StringList();
					SelectList.add(workspaceVault.SELECT_ID);

					String sProjectId = "";

					boProject = new BusinessObject(sProjectId);
					boProject.open(context);

					Pattern relPattern = null;
					Pattern typePattern = null;
					workspaceVault.setId(sProjectId);
					MapList mapList = workspaceVault.getRelatedObjects(context, relSubVaultsStr, typeProjectVault, SelectList, // objectSelects,
							new SelectList(), // relationshipSelects,
							false, // getTo,
							true, // getFrom,
							(short) 0, // recurseToLevel,
							null, // objectWhere,
							""); // relationshipWhere)

					for (int i = 0; i < mapList.size(); i++) {
						Map tempmap = (Map) mapList.get(i);
						String SubFolderId = (String) tempmap.get(workspaceVault.SELECT_ID);
						BusinessObject boFolder = new BusinessObject(SubFolderId);
						boFolder.open(context);
						boFolder.remove(context);
						boFolder.close(context);
					}

					boProject.remove(context);
					boProject.close(context);
					// }

					subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_DELETED, "");
					if (subfold == true) {
						workspaceVault.setId(objectId);
						subscriptionWkVaultMgr.publishEvent(context, workspaceVault.EVENT_FOLDER_DELETED, "");
					}

					// test

					ContextUtil.commitTransaction(context);

				} catch (Exception e) {
					ContextUtil.abortTransaction(context);

					writeMessageToConsole(logWriter, " Exception occured : " + e.getMessage() + " LINE NUMBER: " + recordRowNum);
					writeErrorToFile(errorStream, "[cdmWorkspaceFolderMigration_mxJPO : executeDeleateFolder]  LINE NUMBER: " + recordRowNum + " Exception occured : " + e.getMessage());
					e.printStackTrace(errorStream);

					writeFailToFile(failedObjectidWriter, "[cdmWorkspaceFolderMigration_mxJPO : executeDeleateFolder] fail occured. LINE NUMBER: " + recordRowNum);
				}
			}
			writeMessageToConsole(logWriter, "====================================================================================");
			writeMessageToConsole(logWriter, "        File WorkSpace Migration COMPLETED.                    ");
			writeMessageToConsole(logWriter, "====================================================================================\n");

		} catch (Exception exception) {

			writeFailToFile(failedObjectidWriter, "[cdmWorkspaceFolderMigration_mxJPO : executeDeleateFolder] fail occured.  LINE NUMBER: " + recordRowNum);
			writeMessageToConsole(logWriter, " Exception occured : " + exception.getMessage() + "  LINE NUMBER: " + recordRowNum);
			writeErrorToFile(errorStream, "[cdmWorkspaceFolderMigration_mxJPO : executeDeleateFolder] Exception occured.  LINE NUMBER: " + recordRowNum + "  " + exception.getMessage());
			exception.printStackTrace(errorStream);

		} finally {
			writeMessageToConsole(logWriter, "====================================================================================");
			writeMessageToConsole(logWriter, "		CLOSE TIME:" + getTimeStamp() + "                                      ");
			writeMessageToConsole(logWriter, "		LEAD TIME:" + (System.currentTimeMillis() - startTime) + "ms        \n");
			writeMessageToConsole(logWriter, "==================================================================================== \n");
			System.out.println("[${CLASS:cdmWorkSpaccdmWorkspaceFolderMigration} : executeDeleateFolder] end .");
			try {
				if (null != logWriter)
					logWriter.close();

				if (null != errorStream)
					errorStream.close();

				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}

		}
	}

}// class end
