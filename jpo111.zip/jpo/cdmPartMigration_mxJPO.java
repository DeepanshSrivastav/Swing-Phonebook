import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.apps.classification.AttributeGroup;
import com.matrixone.apps.classification.Classification;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainAccess;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainSymbolicConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.eMatrixDateFormat;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.engineering.EBOMAutoSync;
import com.matrixone.apps.engineering.EBOMMarkup;
import com.matrixone.apps.engineering.EngineeringConstants;
import com.matrixone.apps.engineering.EngineeringUtil;
import com.matrixone.apps.engineering.PartFamily;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralConstants;
import com.matrixone.apps.library.PartLibrary;
import com.matrixone.apps.manufacturerequivalentpart.Part;
import com.matrixone.jdom.Element;

import ch.qos.logback.core.net.SyslogOutputStream;
import matrix.db.Attribute;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.BusinessObjectList;
import matrix.db.BusinessType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.Policy;
import matrix.db.RelationshipType;
import matrix.util.DateFormatUtil;
import matrix.util.List;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;

import com.dassault_systemes.WebServiceHandler.Domain;
import com.mando.util.cdmCommonExcel;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;


public class cdmPartMigration_mxJPO {
	public String doubleSlash = "\\";
//	public static final String TYPE_PHANTOMPART =  cdmConstantsUtil.TYPE_CDMPHANTOMPART;
//	public static final String TYPE_CDMMECHANICALPART = cdmConstantsUtil.TYPE_CDMMECHANICALPART;
	public static final String TYPE_PHANTOMPART =  "cdmPhantomPart";
	public static final String TYPE_CDMMECHANICALPART = "cdmMechanicalPart";
	public static final String S_ATTRIBUTE_CDMPARTTYPE = "cdmPartType";
	public static final String S_ATTRIBUTE_PHASE_PROTO = "Proto";
	public static final String S_ATTRIBUTE_PHASE_PRODUCTION = "Production";
	public static final String S_OUTPUT_DIRECTORY = "MIGRATION_LOGS";
	public static final String SELECT_ACTIVE_VERSION_ID = "relationship[Active Version].to.id";
	
	public BufferedWriter logWriter 			 = null;
	public BufferedWriter successObjectidWriter  = null;
	public BufferedWriter failedObjectidWriter   = null;
	public BufferedWriter shortErrorWriter  	 = null;
	public BufferedWriter errorLogFile        	 = null;
	public BufferedWriter debugLogFile           = null;
	       
	public String inputDirectory 			     = "";
	public String outputDirectory 			     = "";
	public String fileName 		        	     = "";
	                                             
	public String failedIdsLogsDirectory 	     = "";
	public PrintStream errorStream		         = null;
	public File successLogFile 				     = null;
	public File failedLogFile 				     = null;
	public File shortErrorLogFile 				     = null;
	
	public static final String sfileSeparator 	   	= "\\";
	
	
	public static void main(String[] args) throws Exception {
		Context context = null;
		try {
//			if(args.length !=2){
//				throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//			}
			
			context = new Context("");
//			context = getContext();
//			context.setUser("admin_platform");
//			context.setPassword("");
//			context.connect();
//			
			HashMap paramMap = new HashMap();
//			
//			String sFileLocationAndFileName 	= "C:\\temp\\Import_File\\Part\\_Retrieve_Items_BD_20161129_00.txt.00";
//			String sFileLocationAndFileName 	= "E:\\Import_File_Operation_Before\\Part\\Retrieve_Items_SSD_20161226_00_07_TESTSAMPLE.txt";
//			String sFileLocation 		= "";
//			String sFileName 			= "";
//			sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
//			sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
//			if(sFileName.contains("Items")){
//				paramMap.put("File_Location", sFileLocation);
//				paramMap.put("File", sFileName);
//			
//				JPO.invoke(context, "cdmPartMigration", null, "createPartM", JPO.packArgs(paramMap));//
//				JPO.invoke(context, "cdmPartMigration", null, "executeCreatePartMigration", JPO.packArgs(paramMap));//
//				
//			}
		
		} catch (MatrixException e) {
			e.printStackTrace();
		}finally{
			
		}
	}
	
	/**
	 * Part 을 생성 
	 * 47546 줄까지 
	 * Description : 
	 * Part 을 생성할때 기본적인 Part 의 타입은 "cdmMechanicalPart" 
	 * 
	 * 부품 정보 전체에서 코멘트 부분은 제거한 내용 의 텍스트를 가지고 진행함 
	 * 코멘트는 따로 migration을 진행할 예정 11/1/16
	 * 
	 * CADWeight 정보 값이 아직 엑셀 혹은 다른 텍스트 파일로 전달받지 못한상태이며 이부분은 
	 * 맨끝단에 있다는 가정하에 진행한다.엑셀 맨마지막 부분에 추가 을 임의로 하였으나 요구해야할 사항중 하나 !!! (9/29/16)  
	 * 
	 * sbECONumberId,sbDrawingNoId 에 관련 데이타는 구체적인 데이타는 아직 미정이라 관련 연결은 추후 (9/28/16)
	 * 유효한 데이타 정보는  47546 까지 9/29/16 
	 * 
	 * @param context
	 * @param arg
	 * @throws Exception
	 */
//	@SuppressWarnings({ "unchecked", "rawtypes" })
//	public void createPartM(Context context,String arg[])throws Exception{
//		long startTime = System.currentTimeMillis();
//		System.out.println("cdmPartMigration : createPartM -StartTime:"+cdmCommonExcel.getTimeStamp2());
//		String logFileName = "PartM";
//		
//		MqlUtil.mqlCommand(context, "history off");
//		if(arg.length!=1){
//			throw new Exception("The excel path does not exist.");
//		}
//		
//		String sFileLocationAndFileName = arg[0];
//		
//		String sFileLocation 		= "";
//		String sFileName 			= "";
//		
//		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
//		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
//		
//		logFileName +="_"+sFileName;
////		String[] argTest = {sFileLocation,sFileName}; // 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명  
////		initializeM(context,argTest,2,logFileName);      //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
//		
//		String sPartInputDirectory = sFileLocation;
//		if(sPartInputDirectory != null && !sPartInputDirectory.endsWith(sfileSeparator))
//		{
//			sPartInputDirectory = sPartInputDirectory + sfileSeparator;
//		}
//		String sPartOutputDirectory = "";
//		// create a directory to add debug and error logs
//		sPartOutputDirectory = new File(sPartInputDirectory).getParentFile() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+  cdmCommonExcel.getTimeStamp() + sfileSeparator;
//        File fileOutputDirectory = new File(sPartOutputDirectory);
//        if(!fileOutputDirectory.isDirectory()){
//        	fileOutputDirectory.mkdirs();
//        }
//		logWriter 			 	= new BufferedWriter(new FileWriter(sPartOutputDirectory + logFileName + "_DebugLog.txt",true));
//		errorStream 			= new PrintStream(new FileOutputStream(new File(sPartOutputDirectory + logFileName + "_ErrorLog.txt")));
//
//		successLogFile  		= new File(sPartOutputDirectory + logFileName + "_SuccessLogs.txt");
//		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));
//
//		failedLogFile  			= new File(sPartOutputDirectory + logFileName + "_FailedLogs" + ".txt");
//		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
//		
//		shortErrorLogFile        = new File(sPartOutputDirectory + logFileName + "ShortErrorLogs" + ".txt");
//		shortErrorWriter         = new BufferedWriter(new FileWriter(shortErrorLogFile,true));
//		// input file name
//		String fileName = sFileName;
//		//test end 
//		
//		
//		
//		String tempStRowNum   = ""; //순번
//		String tempStPartNo   = ""; //엑셀의 PartNo
//		String tempStPartRevision   = ""; //엑셀의 PartNo
//		int lineNumber = 0;
//		int successCount = 0;
//		int failCount = 0;
//		boolean checkTriggerOff = false;
//		BufferedReader bufferReader = null;
////		writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());
//		writeSuccessToFile("LineNume(#) \t  PartNo. \t Revision \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t No OPTION1 exists. \t No OPTION2 exists. \t No OPTION3 exists. \t  No OPTION4 exists. \t No OPTION5 exists \t  No OPTION6 exists \t EC information does not exist. \t No Part Family exist. ");
//		
//		writeErrorToFile(sPartInputDirectory);
////		writeFailToFile("[cdmPartMigration : createPartM]");
//		
//		writeMessageToConsole("====================================================================================");
//		writeMessageToConsole(" PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
//		writeMessageToConsole("	Reading input log file from : "+sPartInputDirectory+fileName);
//		writeMessageToConsole("	Writing Log files to: " + sPartInputDirectory );
//		writeMessageToConsole("====================================================================================\n");
//		boolean checkAddPart = false;
//		
//		try {
//
//			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(sPartInputDirectory+fileName),"euc-kr"));
//			String data = "";  							// 텍스트 파일 라인정보담을 변수 
//			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
//			
//			/* cdmCommonCode lev2 object 검색 start  */
//			
//			// 12/2 start 
//			Map option1Map = getOptionCode(context,"Option1");
//			Map option2Map = getOptionCode(context,"Option2");
//			Map option3Map = getOptionCode(context,"Option3");
//			Map option4Map = getOptionCode(context,"Option4");
//			Map option5Map = getOptionCode(context,"Option5");
//			Map option6Map = getOptionCode(context,"Option6");
//			
//			Map vehicleCommonCodeMap = getVehicleCode(context,"Vehicle");
//			Map productGroupMap = getProductGroupCode(context,"Product Group Name");
//			Map productDivMap = getProductDivCode(context,"Product Div");
//			Map projectMap = getProjectCode(context,"cdmProjectGroupObject");
//			Map partFamilyMap = getPartFamilyId(context);
//			
//			/*cdmCommonCode lev2 object 검색 end */ 
//			
//			String strLanguage = context.getLocale().getLanguage();
//			
//			AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
//			attrPartGlobal.open(context);
//			StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
//			attrPartGlobal.close(context);
//			StringList attrPartGlobalKOList = new StringList();
//			attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
//			
//			
//			AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
//			attrPartItemType.open(context);
//			StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
//			attrPartItemType.close(context);
//			StringList attrPartItemTypeKOList = new StringList();
//			attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
//			
//			
//			AttributeType attrPartERPInterface = new AttributeType("cdmPartERPInterface");
//			attrPartERPInterface.open(context);
//			StringList attrPartERPInterfaceList = attrPartERPInterface.getChoices(context);
//			attrPartERPInterface.close(context);
//			StringList attrPartERPInterfaceKOList = new StringList();
//			attrPartERPInterfaceKOList = i18nNow.getAttrRangeI18NStringList("cdmPartERPInterface", attrPartERPInterfaceList, strLanguage);
//			
//			AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
//			attrPartType.open(context);
//			StringList attrPartTypeList = attrPartType.getChoices(context);
//			attrPartType.close(context);
//			StringList attrPartTypeKOList = new StringList();
//			attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
//			
//			
//			HashMap tempUOMHMap = new HashMap();
//			tempUOMHMap.put("EA"  , "Each");
//			tempUOMHMap.put("BAG" , "bag");
//			tempUOMHMap.put("BTL" , "bottle");
//			tempUOMHMap.put("BOX" , "box");
//			tempUOMHMap.put("CC"  , "cc");
//			tempUOMHMap.put("CMM" , "mm³");
//			tempUOMHMap.put("CMT" , "m³");
//			tempUOMHMap.put("CN"  , "can");
//			tempUOMHMap.put("CT"  , "carton");
//			tempUOMHMap.put("DL"  , "dl");
//			tempUOMHMap.put("DZ"  , "dozen");
//			tempUOMHMap.put("FT"  , "ft");
//			tempUOMHMap.put("GLL" , "gallon");
//			tempUOMHMap.put("G"   , "g");
//			tempUOMHMap.put("IN"  , "inch");
//			tempUOMHMap.put("KG"  , "kg");
//			tempUOMHMap.put("KMT" , "km");
//			tempUOMHMap.put("L"   , "L");
//			tempUOMHMap.put("LBR" , "lb");
//			tempUOMHMap.put("M"   , "m");
//			tempUOMHMap.put("MGR" , "mg");
//			tempUOMHMap.put("ML"  , "ml");
//			tempUOMHMap.put("MMT" , "mm");
//			tempUOMHMap.put("MT"  , "ton");
//			tempUOMHMap.put("N"   , "N");
//			tempUOMHMap.put("PC"  , "Piece");
//			tempUOMHMap.put("PL"  , "Pl");
//			tempUOMHMap.put("ROL" , "Roll");
//			tempUOMHMap.put("SET" , "Set");
//			tempUOMHMap.put("SH"  , "Sheet");
//			tempUOMHMap.put("SM"  , "m²");
//			tempUOMHMap.put("UN"  , "unit");
//			tempUOMHMap.put("DRM" , "drum");
//			
//			lineNumber = 1;      
//			int subPartCount = 0;
//			
//			String strPreviousPartNo = null;
//			String strPreviousPartRevision = null;
//			String strPreviousPartType = null;
//			
//			
//			while ((data = bufferReader.readLine()) != null) {
//				
//			
//				StringBuffer sbErrorMessage = new StringBuffer("");
//				MqlUtil.mqlCommand(context, "trigger off");
//				checkTriggerOff = true;
//				checkAddPart = false;
//				StringList stListData = FrameworkUtil.split(data, "\t");
//				try {
//					
//					
//					if (lineNumber == 1) {
//						stListHeader = stListData;
//						writeFailToFile("errorRecord \t"+data);
//						lineNumber++;
//						continue;
//					}
//					lineNumber++;
//					
//					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
//					int size_Data = stListData.size();
//					int size_Header = stListHeader.size();
//					if (size_Data != size_Header) {
//						String errorMessage = " NOT MATCH DATA FIELD";
//						throw new Exception(errorMessage);
//					}
//
//					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {
//
//						String sPartInfos = cdmCommonExcel.isVaildNullData((String)stListData.get(stListNum));
//						String sPartHeader = ((String) stListHeader.get(stListNum)).trim();
//						partHM.put(sPartHeader, sPartInfos);
//						
//					}
//					
//					
//					String stPartType                   = TYPE_CDMMECHANICALPART;  
//					String stPartCount                  = ((String)partHM.get("#"            		        )).trim(); // 1 순번 
//					String stCLS_NAME                   = ((String)partHM.get("CLS_NAME"                    )).trim(); // 2 
//					String stOBJECT_ID                  = ((String)partHM.get("OBJECT_ID"                   )).trim(); // 3 //받은 자료에 unique 값 migration대상아님 
//	
//					String stCN_ID                      = ((String)partHM.get("CN_ID"  	                    )).trim(); // 5 Name
//					String stREVISION                   = ((String)partHM.get("REVISION"                    )).trim(); // 6 Revision
//					String stSTATE                      = ((String)partHM.get("STATE"                       )).trim(); // 7 State
//					String stCREATION_DATE              = ((String)partHM.get("CREATION_DATE"               )).trim(); // 8  attribute[cdmPartCreationDateM]
//					String stUSER_OBJECT_ID             = ((String)partHM.get("USER_OBJECT_ID"              )).trim(); // 9  attribute[cdmPartCreationUserIdM]
//					String stUSER_ID_MOD                = ((String)partHM.get("USER_ID_MOD"                 )).trim(); // 10 attribute[cdmPartModUserIdM]
//					String stMODIFICATION_DATE          = ((String)partHM.get("MODIFICATION_DATE"           )).trim(); // 11 attribute[cdmPartModificationDateM] 
//					String stTDM_DESCRIPTION            = ((String)partHM.get("TDM_DESCRIPTION"             )).trim(); // 12 attribute[cdmPartName]
//					String stTDM_UOM                    = ((String)partHM.get("TDM_UOM"  			        )).trim(); // 13 attribute[cdmPartUOM]
//					String stPhaseM                     = ((String)partHM.get("PHASE"                       )).trim(); // 14 
//					String stPAR_REVISION               = ((String)partHM.get("PAR_REVISION"                )).trim(); // 15 Previous Revision
//	//				String stAPPROVAL_DATE              = ((String)partHM.get("APPROVAL_DATE"               )).trim(); // 16 
//	//				String stREVISION_STG               = ((String)partHM.get("REVISION_STG"                )).trim(); // 17 
//					String stTDM_ORG_USER_ID            = ((String)partHM.get("TDM_ORG_USER_ID"             )).trim(); // 18 First Revision creator
//	//				String stTDM_ORG_CREATEDATE         = ((String)partHM.get("TDM_ORG_CREATEDATE"          )).trim(); // 19 
//	//				String stTDM_APPROVED_BY            = ((String)partHM.get("TDM_APPROVED_BY"             )).trim(); // 20 
//	//				String stTDM_ORIGIN_ID              = ((String)partHM.get("TDM_ORIGIN_ID"               )).trim(); // 21 
//					String stCN_PROJECT                 = ((String)partHM.get("CN_PROJECT"                  )).trim(); // 22 PROJECT
//					String stCN_PROJECT_CUST            = ((String)partHM.get("CN_PROJECT_CUST"             )).trim(); // 23 PROJECT_CUST
//	//				String stCN_PRODUCT_NAME            = ((String)partHM.get("CN_PRODUCT_NAME"             )).trim(); // 24 
//	//				String stCN_PART_GROUP              = ((String)partHM.get("CN_PART_GROUP"               )).trim(); // 25 
//	//				String stCN_PART_NAME               = ((String)partHM.get("CN_PART_NAME"                )).trim(); // 26
//	//				String stCN_WEIGHT                  = ((String)partHM.get("CN_WEIGHT"                   )).trim(); // 27
//					String stCN_ESTIMATED_WEIGHT        = ((String)partHM.get("CN_ESTIMATED_WEIGHT"         )).trim(); // 28 attribute[cdmPartEstimatedWeight] 
//					String stCN_WEIGHT_UNIT             = ((String)partHM.get("CN_WEIGHT_UNIT"              )).trim(); // 29
//					String stCN_TOP_ITEM                = ((String)partHM.get("CN_TOP_ITEM"                 )).trim(); // 30
//					String stCN_PHANTOM_ITEM            = ((String)partHM.get("CN_PHANTOM_ITEM"             )).trim(); // 31
//					String stCN_ITEM_TYPE               = ((String)partHM.get("CN_ITEM_TYPE"                )).trim(); // 32
//					String stCN_SERVICE_ITEM            = ((String)partHM.get("CN_SERVICE_ITEM"             )).trim(); // 33
//					String stCN_ITEM_MATERIAL           = ((String)partHM.get("CN_ITEM_MATERIAL"            )).trim(); // 34
//					String stCN_ITEM_UPDATE_FROM_ERP    = ((String)partHM.get("CN_ITEM_UPDATE_FROM_ERP"     )).trim(); // 35
//					String stCN_COST                    = ((String)partHM.get("CN_COST"                     )).trim(); // 36
//					String stCN_CURRENCY                = ((String)partHM.get("CN_CURRENCY"                 )).trim(); // 37
//					//String stCN_COMMENTS              = ((String)partHM.get("CN_COMMENTS"                 )).trim(); // 38
//					String stCN_OEM_PART_NUMBER         = ((String)partHM.get("CN_OEM_PART_NUMBER"          )).trim(); // 39
//					String stEC_NAME                    = ((String)partHM.get("EC_NAME"                     )).trim(); // 40
//					String stCN_ECO_NUMBER              = ((String)partHM.get("CN_ECO_NUMBER"               )).trim(); // 41
//					String stCN_PRODUCT_GROUP           = ((String)partHM.get("CN_PRODUCT_GROUP"            )).trim(); // 42
//					String stCN_SERIES_ITEM             = ((String)partHM.get("CN_SERIES_ITEM"              )).trim(); // 43
//					String stCN_VEHICLE                 = ((String)partHM.get("CN_VEHICLE"                  )).trim(); // 44
//					String stCN_CUSTOMER                = ((String)partHM.get("CN_CUSTOMER"                 )).trim(); // 45
//					String stCN_SIZE                    = ((String)partHM.get("CN_SIZE"                     )).trim(); // 46
//					String stCN_SURFACE_TREATMENT       = ((String)partHM.get("CN_SURFACE_TREATMENT"        )).trim(); // 47
//					String stCN_SURFACE_AREA            = ((String)partHM.get("CN_SURFACE_AREA"             )).trim(); // 48
//					String stCN_ITEM_TYPE1              = ((String)partHM.get("CN_ITEM_TYPE1"               )).trim(); // 49
//					String stCN_MATERIAL               = ((String)partHM.get("CN_MATERIAL"                  )).trim(); // 50
//					String stCN_ORG1                   = ((String)partHM.get("CN_ORG1"                      )).trim(); // 51  migration 대상 제외  
//	//				String stCN_ORG2                   = ((String)partHM.get("CN_ORG2"                      )).trim(); // 52  migration 대상 제외 
//	//				String stCN_ORG3                   = ((String)partHM.get("CN_ORG3"                      )).trim(); // 53  migration 대상 제외 
//					String stCN_ORG                    = ((String)partHM.get("CN_ORG"                       )).trim(); // 54  MCA Org
//					String stCN_MCA_INOUT              = ((String)partHM.get("CN_MCA_INOUT"                 )).trim(); // 55  MCA BOM Management
//					String stCN_MCA_PART_TYPE_REF      = ((String)partHM.get("CN_MCA_PART_TYPE_REF"         )).trim(); // 56  MCA Part Type
//					String stCN_OPTION1                = ((String)partHM.get("CN_OPTION1"                   )).trim(); // 57
//					String stCN_OPTION2                = ((String)partHM.get("CN_OPTION2"                   )).trim(); // 58
//					String stCN_OPTION3                = ((String)partHM.get("CN_OPTION3"                   )).trim(); // 59
//					String stCN_OPTION4                = ((String)partHM.get("CN_OPTION4"                   )).trim(); // 60
//					String stCN_OPTION5                = ((String)partHM.get("CN_OPTION5"                   )).trim(); // 61
//					String stCN_OPTION6                = ((String)partHM.get("CN_OPTION6"                   )).trim(); // 62
//					String stCN_OPTION7                = ((String)partHM.get("CN_OPTION7"                   )).trim(); // 63
//					String stCN_OPTION_ETC             = ((String)partHM.get("CN_OPTION_ETC"                )).trim(); // 64
//					String stCN_IS_CASTING             = ((String)partHM.get("CN_IS_CASTING"                )).trim(); // 65
//					String stCN_OPTION_DESC            = ((String)partHM.get("CN_OPTION_DESC"               )).trim(); // 66
//					String stCN_FOR_MAC                = ((String)partHM.get("CN_FOR_MAC"                   )).trim(); // 67
//					String stCN_FOR_MIL                = ((String)partHM.get("CN_FOR_MIL"                   )).trim(); // 68
//					String stCN_FOR_MIS                = ((String)partHM.get("CN_FOR_MIS"                   )).trim(); // 69
//					String stCN_FOR_MMT                = ((String)partHM.get("CN_FOR_MMT"                   )).trim(); // 70
//					String stCN_REAL_WEIGHT            = ((String)partHM.get("CN_REAL_WEIGHT"               )).trim(); // 71
//					String stCN_COUNTRY                = ((String)partHM.get("CN_COUNTRY"                   )).trim(); // 72
//					String stCN_PRODUCT_DIV            = ((String)partHM.get("CN_PRODUCT_DIV"               )).trim(); // 73
//					String stCN_GLOBAL_LOCAL           = ((String)partHM.get("CN_GLOBAL_LOCAL"              )).trim(); // 74
//					String stCN_PROJECT_CODE           = ((String)partHM.get("CN_PROJECT_CODE"              )).trim(); // 75
//					String stCN_OPTION_DRAWING         = ((String)partHM.get("CN_OPTION_DRAWING"            )).trim(); // 76
//					String stCN_FOR_DRAWING_FINISH     = ((String)partHM.get("CN_FOR_DRAWING_FINISH"        )).trim(); // 77
//					String stCN_FOR_DRAWING_SIZE       = ((String)partHM.get("CN_FOR_DRAWING_SIZE"          )).trim(); // 78
//					String stCN_FOR_DRAWING_REMARK     = ((String)partHM.get("CN_FOR_DRAWING_REMARK"        )).trim(); // 79
//					String stCN_ITEM_TYPE2              = ((String)partHM.get("CN_ITEM_TYPE2"               )).trim(); // 80
//					String stCN_APPLY_PARTLIST          = ((String)partHM.get("CN_APPLY_PARTLIST"           )).trim(); // 81
////					String stCN_PREVIOUS_PART           = ((String)partHM.get("CN_PREVIOUS_PART"            )).trim(); // 82
//					String stCN_COMPLEX_BODY            = ((String)partHM.get("CN_COMPLEX_BODY"             )).trim(); // 83
//					String stCN_MAIN_PART_NUMBER        = ((String)partHM.get("CN_MAIN_PART_NUMBER"         )).trim(); // 84
//					String stCN_VEHICLE_DESC            = ((String)partHM.get("CN_VEHICLE_DESC"             )).trim(); // 85 VEHICLE 
//					String stCN_VEHICLE_CODE            = ((String)partHM.get("CN_VEHICLE_CODE"             )).trim(); // 86
//					String stVehicle_Cust               = ((String)partHM.get("VEHICLE_CUST"                )).trim(); // 87
//					String stCN_DRAWING_NO              = ((String)partHM.get("CN_DRAWING_NO"               )).trim(); // 88 DRAWING_NO
//					String stCN_SUB_ID         		    = ((String)partHM.get("CN_SUB_ID"                   )).trim(); // 89
//	//				//String stCN_CHANGE_REASON 	        = ((String)partHM.get("CN_CHANGE_REASON"            )).trim(); // 90 다른 데이타 파일로 진행 예정 
//					String stCN_SURFACE_TREATMENT_KEYIN = ((String)partHM.get("CN_SURFACE_TREATMENT_KEYIN"  )).trim(); // 91
//					String stCN_OVERSEAS_ORG6           = ((String)partHM.get("CN_OVERSEAS_ORG6"            )).trim(); // 92
//					String stCN_OVERSEAS_ORG6_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG6_PART_TYPE"  )).trim(); // 93
//					String stCN_OVERSEAS_ORG6_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG6_INOUT"      )).trim(); // 94
////					String stCN_OVERSEAS_ORG7           = ((String)partHM.get("CN_OVERSEAS_ORG7"            )).trim(); // 95
////					String stCN_OVERSEAS_ORG7_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG7_PART_TYPE"  )).trim(); // 96
////					String stCN_OVERSEAS_ORG7_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG7_INOUT"      )).trim(); // 97
//
//					String stCN_Project_Id			    = ((String)partHM.get("CN_PROJECT_ID"  )).trim(); // 98
//					String stAccessProductGroup		    = ((String)partHM.get("PROD_GROUP"  )).trim(); // 98
//					String stAceesOrg				    = ((String)partHM.get("CN_CUST_VEHICLE"  )).trim(); // 98
//					if("-".equals(stAceesOrg)){
//						stAceesOrg = "";
//					}
//					String stCADWeight					= ""; 
//					
//					String stGLOBAL_LOCAL = "";
//					String stITEM_TYPE2 = "";
//					String stFOR_DRAWING_REMARK = "";
//					String stOPTION_ETC = "";
//					String stOPTION_DESC = "";
//					String stPartInvestor =   "";
//					String stESTIMATED_WEIGHT = "";
//					String stITEM_TYPE1 = "";
//					String stITEM_TYPE = "";
//					String stSERIES_ITEM = "";
//					String stPhase = "";
//					
//					String stPartCADWeight = ""; /*아직 데이타가 없음 속성 정보 재요청 필요 */
//					subPartCount = Integer.parseInt(stPartCount);
//					tempStRowNum = stPartCount;
//					tempStPartNo = stCN_ID;
//					tempStPartRevision = stREVISION;
//					String personIdMql = "temp query bus Person '" + stTDM_ORG_USER_ID + "' - select id dump |";
//					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
//					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
//					String stPerson = "";
//					boolean boolPerson = false;
//					if (stListPersonIdMql.size() > 2) {
//						stPerson = (String) stListPersonIdMql.get(3);
//						boolPerson = true;
//					}
//					
//					/* ***************************************************************************************
//					 * stCN_VEHICLE_DESC 은 다중으로 존재가능하며 구분은 , 로 한다. 
//					 * ************************************************************************************** */
//					String sTempUOM = "";
//					sTempUOM= (String)tempUOMHMap.get(stTDM_UOM);
//					sTempUOM = cdmCommonExcel.isVaildNullData(sTempUOM);
//					
//					/*  **************************************************************************************
//					 *   stCLS_NAME 정보가 "Option Item" 이라면 CN_SUB_ID 정보를 CN_ID에 합쳐야한다. 
//					 *  ************************************************************************************ */
//					if("Option Item".equalsIgnoreCase(stCLS_NAME)){
//						if(cdmStringUtil.isNotEmpty(stCN_SUB_ID)){
//							stCN_ID +=stCN_SUB_ID;
//						}
//					}
//					
//					/* **************************************************************************************
//					 * cdmPartGlobal 의 정보는 global,local 값이 없으면 ""  처리 
//					 * ************************************************************************************* */
////					AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
////					attrPartGlobal.open(context);
////					StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
////					attrPartGlobal.close(context);
////					StringList attrPartGlobalKOList = new StringList();
////					attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
//					for (int i = 0; i < attrPartGlobalKOList.size(); i++) {
//	
//						if (stCN_GLOBAL_LOCAL.equalsIgnoreCase((String) attrPartGlobalKOList.get(i))) {
//							stGLOBAL_LOCAL = (String) attrPartGlobalList.get(i);
//							break;
//						}
//					}
//					if(cdmStringUtil.isEmpty(stGLOBAL_LOCAL)){
//						stGLOBAL_LOCAL = "";
//					}
//					
//					/*  **************************************************************************************
//					 *   stCN_ITEM_TYPE2 의 정보는 
//					 *   attribute[cdmPartItemType]관련 정보
//					 *   
//					 *   attribute[cdmPartItemType]의 display name과 일치하지않다면 에러 처리  
//					 *  ************************************************************************************** */
////					AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
////					attrPartItemType.open(context);
////					StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
////	
////					StringList attrPartItemTypeKOList = new StringList();
////					attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
//					boolean bITEM_TYPE2 = false;
//					for (int i = 0; i < attrPartItemTypeKOList.size(); i++) {
//	
//						if (stCN_ITEM_TYPE2.equals((String) attrPartItemTypeKOList.get(i))) {
//							stITEM_TYPE2 = (String) attrPartItemTypeList.get(i);
//							bITEM_TYPE2 = true;
//							break;
//						}
//						
//					}
//					
//					/* *****************************************************************************************
//					 * stCN_FOR_DRAWING_REMARK 의 정보는 Part 의 한글 속성과 일치하다고 가정하여 진행 
//					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
//					 * *****************************************************************************************/
//					if(cdmStringUtil.isNotEmpty(stCN_FOR_DRAWING_REMARK) ){
//						//
//						for (int i = 0; i < attrPartERPInterfaceKOList.size(); i++) {
//	
//							if (stCN_FOR_DRAWING_REMARK.equals((String) attrPartERPInterfaceKOList.get(i))) {
//								stFOR_DRAWING_REMARK = (String) attrPartERPInterfaceList.get(i);
//								break;
//							}
//						}
//					}
//					
//	
//					/* ******************************************************************************************************************
//					 * stPartInvestor 의경우 
//					 * stCN_FOR_MAC ,stCN_FOR_MIL,stCN_FOR_MMT 의 정보가 checked 되어 있는지여부를 확인하여 하나의 String 값으로 만듬 
//					 * 
//					 * ****************************************************************************************************************   */
//					if("Checked".equals(stCN_FOR_MAC)){
//						stPartInvestor = "MAC";
//					}
//					if("Checked".equals(stCN_FOR_MIL)){
//						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
//							stPartInvestor +=",";
//						}
//						stPartInvestor += "MIL";
//					}
//					if("Checked".equals(stCN_FOR_MMT)){
//						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
//							stPartInvestor +=",";
//						}
//						stPartInvestor += "MMT";
//					}
//	
//					
//					/* ******************************************************************************************************************
//					 * attribute[Estimated Weight]의 중량단위  
//					 * g 이며 plm의 경우 kg 이므로 변환 
//					 * ****************************************************************************************************************** */
//					
//					if("".equals(stCN_WEIGHT_UNIT)){
//						stCN_WEIGHT_UNIT = "g";
//						//kg 으로 단위 변환 필요 !!
//						if(cdmStringUtil.isNotEmpty(stCN_ESTIMATED_WEIGHT)){
//							Integer inESTIMATED_WEIGHT = Integer.parseInt(stCN_ESTIMATED_WEIGHT);
//							
//							if(inESTIMATED_WEIGHT > 0 || inESTIMATED_WEIGHT < 0 ){
//								stESTIMATED_WEIGHT = String.valueOf(inESTIMATED_WEIGHT/1000);
//							}
//							
//						}
//					}else if(!"kg".equalsIgnoreCase(stCN_WEIGHT_UNIT) && !"".equals(stCN_ESTIMATED_WEIGHT)){
//						//중량단위를 kg로 변환 !!
//						Double doubleESTIMATED_WEIGHT = Double.parseDouble(stCN_ESTIMATED_WEIGHT);
//						if("g".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
//							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
//								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT/1000);
//							}
//						}else if("lb".equals(stCN_WEIGHT_UNIT)){
//							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
//								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(2204.62));
//							}
//						}else if("mg".equals(stCN_WEIGHT_UNIT)){
//							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
//								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(1000000));
//							}
//						}else if("ton".equals(stCN_WEIGHT_UNIT)){
//							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
//								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(1000));
//							}
//						}else if("N".equals(stCN_WEIGHT_UNIT)){
//							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
//								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(0.102));  //힘의 단위로 변환한것임 문의할것 
//							}
//						}
//					}
//					/* *************************************************************************************
//					 *   stCN_PHANTOM_ITEM 가 체크되어있으면 파트 타입으로 "Phantom Part"변경
//					 *   stPhase 여부와 상관없이 반드시 Proto 로 변경된다. 
//					 * *********************************************************************************** */
//					if("PROTO".equalsIgnoreCase(stCN_ORG1)){
//						stPhase = S_ATTRIBUTE_PHASE_PROTO;
//					}else{
//						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
//					}
//					
//					if( "Checked".equalsIgnoreCase(stCN_PHANTOM_ITEM) &&  "PROTO".equalsIgnoreCase(stCN_ORG1)){
//						stPartType = "cdmPhantomPart";
//						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
//					}
//					
//					
//					
//					  /* **********************************************************************************************************************
//			         * type은 pre revision 정보가 있으며 그정보 의 object 가 phantom part 타입이면 생성할 object 타입도 phantom part 타입으로
//			         * 변경  
//			         *    
//			         * ******************************************************************************************************************** */
////					if(cdmStringUtil.isNotEmpty(stPAR_REVISION)) {
////						 String stPreRevisionPhantomMql = "temp query bus '"+ TYPE_PHANTOMPART +"' '" +stCN_ID +"' '"+stPAR_REVISION+"'  select id  dump |";
////						 String stPreRevisionPhantomMqlResult =  MqlUtil.mqlCommand(context, stPreRevisionPhantomMql);
////						 StringList stListPreRevisionPhantomMqlResult = FrameworkUtil.split(stPreRevisionPhantomMqlResult, "|");
////						 
////						 if(stListPreRevisionPhantomMqlResult.size() > 2){
////							 stPartType = TYPE_PHANTOMPART;
////						 }
////					}
//					
//					
//					
//					/* ***************************************************************************************
//				     *	데이타 중복확인 
//					 * *************************************************************************************** */
////					String duplicationPart = MqlUtil.mqlCommand(context, "temp query bus \""+stPartType+"\" \""+ stCN_ID+"\"  \""+ stREVISION +"\"  dump ");
////					if(cdmStringUtil.isNotEmpty(duplicationPart)){
////						String errorMessage = "ALREADY PART OBJECT ";
////						throw new Exception(errorMessage);
////					}
//					
//					/* *************************************************************************************
//					 * stITEM_TYPE1 은  cdmPartApprovalType 속성 정보와 일치 여부 확인 후
//					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
//					 * *********************************************************************************** */
//					
//						
//					if("자작".equals(stITEM_TYPE1)){
//						stITEM_TYPE1 = "inSourcing";
//					}else if("외주".equals(stITEM_TYPE1)){
//						stITEM_TYPE1 = "outSourcing";
//					}else{
//						stITEM_TYPE1 = "";
//					}
//					
//					
//					
//					/* *************************************************************************************
//					 * stITEM_TYPE 은  cdmPartType 속성 정보와 일치 여부 확인 후
//					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
//					 * *********************************************************************************** */
//					stITEM_TYPE = "";
//					for (int attrPartTypeNum = 0; attrPartTypeNum < attrPartTypeKOList.size(); attrPartTypeNum++) {
//						String temPattrPartTypeKO = (String) attrPartTypeKOList.get(attrPartTypeNum);
//						if (stCN_ITEM_TYPE.equals(temPattrPartTypeKO)) {
//							stITEM_TYPE = (String) attrPartTypeList.get(attrPartTypeNum);
//							break;
//						}
//					}
////					if(stCN_ITEM_TYPE == null || "".equals(stCN_ITEM_TYPE) ){
////						stITEM_TYPE = "";
////					} else {
//	
////						AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
////						attrPartType.open(context);
////						StringList attrPartTypeList = attrPartType.getChoices(context);
////	
////						StringList attrPartTypeKOList = new StringList();
////						attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
//	
//						
////					}
//	
//					
//					/* *************************************************************************************
//					 * SERIES_ITEM 값이 Checked 이면 true unChecked 이면 false 
//					 * *********************************************************************************** */
//					if("Checked".equalsIgnoreCase(stCN_SERIES_ITEM)){
//						stSERIES_ITEM = "true"; 
//					}else{
//						stSERIES_ITEM = "false";
//					}
//					
//					/*stCN_SURFACE_TREATMENT 은 사용되지않아 "" 처리한다. */
//					String stSURFACE_TREATMENT = ""; 
//					
//					/*stCN_IS_CASTING*/
//					String stIS_CASTING = "";
//					if(!"0".equals(stCN_IS_CASTING)){
//						stIS_CASTING = "yes";
//					}else{
//						stIS_CASTING = "no";
//					}
//					
//					
//					/*stCN_FOR_DRAWING_FINISH*/
//					String stCFOR_DRAWING_FINISH = "";
//					if("0".equals(stCN_FOR_DRAWING_FINISH)){
//						stCFOR_DRAWING_FINISH = "unChecked";
//					}else{
//						stCFOR_DRAWING_FINISH = "Checked";
//					}
//					
//					/*stCN_FOR_DRAWING_SIZE*/
//					String stDRAWING_SIZE = "";
//					if("0".equals(stCN_FOR_DRAWING_SIZE)){
//						stDRAWING_SIZE = "unChecked";
//					}else{
//						stDRAWING_SIZE = "Checked";
//					}
//					
//					
//					//cdmPartVehicle,cdmPartProject,cdmPartProjectType,cdmPartProductType
//					HashMap attributes = new HashMap();
//					attributes.put("cdmPartPhaseM", 		 	  stPhaseM		                   );
//			        attributes.put("cdmPartNo",          	      stCN_ID 			               );
////			        attributes.put("cdmPartVehicle", 	 	      stCN_VEHICLE_DESC		           );
//			        attributes.put("cdmPartName", 		 	      stTDM_DESCRIPTION	               );
////			        attributes.put("cdmPartProject", 	 	      stCN_PROJECT		               );
//			        attributes.put("cdmPartApprovalType", 	      stITEM_TYPE1	                   );
//			        attributes.put("cdmPartType", 		          stITEM_TYPE	                   );
//			        attributes.put("cdmPartGlobal", 			  stGLOBAL_LOCAL                   );
//			        attributes.put("cdmPartDrawingNo", 			  stCN_DRAWING_NO                  );
////			        attributes.put("cdmPartUOM",     		      stTDM_UOM                        );
//			        attributes.put("cdmPartUOM",     		      sTempUOM                        );
//			        attributes.put("cdmPartECONumber", 			  stCN_ECO_NUMBER                  );
//			        attributes.put("cdmPartItemType", 			  stCN_ITEM_TYPE2                  );
//			        attributes.put("cdmPartOEMItemNumber", 		  stCN_OEM_PART_NUMBER             );
////			        attributes.put("cdmPartProductType", 		  stCN_PRODUCT_DIV                 );
//			        attributes.put("cdmPartERPInterface", 		  stFOR_DRAWING_REMARK             );
//			        attributes.put("cdmPartSurface", 			  stCN_SURFACE_AREA                );
//			        attributes.put("cdmPartEstimatedWeight", 	  stESTIMATED_WEIGHT               );
//			        attributes.put("cdmPartMaterial", 			  stCN_ITEM_MATERIAL               );
//			        attributes.put("cdmPartRealWeight", 		  stCN_REAL_WEIGHT                 );
//			        attributes.put("cdmPartSize", 				  stCN_SIZE                        );
//			        attributes.put("cdmPartCADWeight", 			  stPartCADWeight                  );
//			        attributes.put("cdmPartSurfaceTreatment", 	  stSURFACE_TREATMENT              );
//			        attributes.put("cdmPartIsCasting", 			  stIS_CASTING                     );
////			        attributes.put("cdmPartOption1", 			  stCN_OPTION1                     );
////			        attributes.put("cdmPartOption2", 			  stCN_OPTION2                     );
////			        attributes.put("cdmPartOption3", 			  stCN_OPTION3                     );
////			        attributes.put("cdmPartOption4", 			  stCN_OPTION4                     );
////			        attributes.put("cdmPartOption5", 			  stCN_OPTION5                     );
////			        attributes.put("cdmPartOption6", 		   	  stCN_OPTION6                     );
//			        attributes.put("cdmPartOptionETC",         	  stOPTION_ETC               	   );
//			        attributes.put("cdmPartOptionDescription", 	  stOPTION_DESC            		   );
//			        attributes.put("cdmPartPublishingTarget",     stCN_COST                        );
//			        attributes.put("cdmPartInvestor",          	  stPartInvestor                   );
////			        attributes.put("cdmPartProjectType",          stCN_PRODUCT_GROUP               ); // 
////			        attributes.put("cdmPartProductDivision",      stCN_PRODUCT_GROUP               ); //?? 확인 작업이 필요 
//					
//			        /*migration을 작업을 위해 attribute 추가 start */
//			        attributes.put("cdmPartItemOtionItemM",        stCLS_NAME                      );
//			        attributes.put("cdmPartPreviousRevisionM",     stPAR_REVISION                  );
//			        attributes.put("cdmPartCheckPhantomPartM",     stCN_PHANTOM_ITEM   	           );
//			        attributes.put("cdmPartECNameM",               stEC_NAME    	               );
//			        attributes.put("cdmPartSeriesItemM",           stSERIES_ITEM                   );
//			        attributes.put("cdmPartMCAOrgM",               stCN_ORG      	               );
//			        attributes.put("cdmPartMCABOMManagementM",     stCN_MCA_INOUT        	       );
//			        attributes.put("cdmPartMCAPartTypeM",          stCN_MCA_PART_TYPE_REF          );
//			        attributes.put("cdmPartOption7",          	   stCN_OPTION7                    );
//			        attributes.put("cdmPartCountryM",          	   stCN_COUNTRY                    );
//			        attributes.put("cdmPartDrawingFinishM",        stCFOR_DRAWING_FINISH           );
//			        attributes.put("cdmPartDrawingSizeM",          stDRAWING_SIZE                  );
//			        attributes.put("cdmPartApplyPartListM",        stCN_APPLY_PARTLIST             );
//			        attributes.put("cdmPartSubIdM",                stCN_SUB_ID                     );
//			        attributes.put("cdmPartMCPOrgM",          	   stCN_OVERSEAS_ORG6              );
//			        attributes.put("cdmPartMCPPartTypeM",          stCN_OVERSEAS_ORG6_PART_TYPE    );
//			        attributes.put("cdmPartMCPBOMManagementM",     stCN_OVERSEAS_ORG6_INOUT 	   );  
//			        attributes.put("cdmPartCreationDateM",        stCREATION_DATE     	           );  
//			        attributes.put("cdmPartCreationUserIdM",      stUSER_OBJECT_ID  	           );  
//			        attributes.put("cdmPartModUserIdM",           stUSER_ID_MOD  	               );  
//			        attributes.put("cdmPartModificationDateM",    stMODIFICATION_DATE  	           );  
//			        attributes.put("cdmPartComplexBodyForRealWeightM",  stCN_COMPLEX_BODY          );
//			        attributes.put("cdmCheckMigration",           "Y"					  	       );
//			        attributes.put("cdmPartPhase",           	   stPhase			  	       	   );
//			        //add attribute 11/17/2016 start 
//			        attributes.put("cdmPartApplyPartList",           "true"				  	       );
//			        attributes.put("cdmPartApplySizeList",           "false"			  	       );
//			        attributes.put("cdmPartApplySurfaceTreatmentList", "false"	  				   );
//			        //add attribute 11/17/2016 end 
//			        
//			        /*migration을 작업을 위해 attribute 추가 end  */
//			        
//			      
//			        /* **********************************************************************************************************************
//			         * part 데이타 생성 및 데이타 
//			         * 트리거 오프한 상태로 진행되며 트리거에서 제공되는 attribute[originator]속성 및 interface 추가 설정 필터 정보 와 
//			         * rev 정보 part master 생성 및 연결 및 속성(attribute[Originator]속성 추가 
//			         * 에러 발생시 정지 및 데이타 정보 검색 
//			         * ******************************************************************************************************************* */
//			        DomainObject partObj = new DomainObject();
//	
////					partObj.createObject(context, stPartType, stCN_ID, stREVISION, cdmConstantsUtil.POLICY_CDM_PART_POLICY, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//			        ContextUtil.startTransaction(context, true);
//			        
//			        boolean bNewPartCheck = false;
//			        boolean reviseCheck = false;
//			        
//			        
//			        if(  stCN_ID.equals(strPreviousPartNo)   && UIUtil.isNotNullAndNotEmpty(stPAR_REVISION) && stPAR_REVISION.equals(strPreviousPartRevision )) {
////			        	BusinessObject previousPart  = new BusinessObject(stPartType,stCN_ID,strPreviousPartRevision,"eService Production");
//			        	BusinessObject previousPart  = new BusinessObject(strPreviousPartType,stCN_ID,strPreviousPartRevision,"eService Production");
////			        	BusinessObject previousPart  = new BusinessObject(stPartType,stCN_ID,strPreviousPartRevision,"eService Production");
////			        	boolean checkPrevious = previousPart.exists(context);
////			        	if(!checkPrevious){
////			        		if("cdmPhantomPart".equals(stPartType)){
////			        			previousPart  = new BusinessObject(TYPE_CDMMECHANICALPART,stCN_ID,strPreviousPartRevision,"eService Production");
////			        			
////			        		}else{
////			        			previousPart  = new BusinessObject("cdmPhantomPart",stCN_ID,strPreviousPartRevision,"eService Production");
////			        			
////			        		}
////			        	}
//			        	BusinessObject currentPart = previousPart.revise(context, stREVISION, "eService Production");
//			        	
//			        	partObj.setId(currentPart.getObjectId(context));
//
//			        	
//			        	
//			        	StringBuffer sbRelType = new StringBuffer();
//			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT).append(",");
//			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE).append(",");
//			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE).append(",");
//			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE).append(",");
//			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION);
//			        	
//			        	StringList relList = new StringList();
//			        	relList.add("id[connection]");
//			        	
//			        	MapList mlCodes = partObj.getRelatedObjects(context,
//			        			sbRelType.toString(), // relationship pattern
//			                    "*", // object pattern
//			                    null, // object selects
//			                    relList, // relationship selects
//			                    true, // to direction
//			                    false, // from direction
//			                    (short) 1, // recursion level
//			                    "", // object where clause
//			                    null); // relationship where clause
//			        	
//			        	for (int jj = 0; jj < mlCodes.size(); jj++) {
//							Map mapCode = (Map)mlCodes.get(jj);
//							String relid = (String)mapCode.get("id[connection]");
//							
//							MqlUtil.mqlCommand(context, "del connection "+relid);
//							
//						}
//			        } else {
//			        	partObj.createObject(context, stPartType, stCN_ID, stREVISION, "cdmPartPolicy", cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//			        	bNewPartCheck = true;
//			        }
//			        strPreviousPartNo = stCN_ID;
//					strPreviousPartRevision = stREVISION;
//					strPreviousPartType = stPartType;
//
//					
//					
//					if ("In Approval".equals(stSTATE)) {
//						stSTATE = "Review";
//						
//					} else if ("Inactive".equals(stSTATE)) {
//						stSTATE = "Obsolete";
//						
//					}else if ("Released".equals(stSTATE)) {
//						stSTATE = "Release";
//							
//						
//					}else if ("In Work".equals(stSTATE)) {
//						stSTATE = "Preliminary";
//					}
//					
//					partObj.setState(context, stSTATE);
//					try{
//					partObj.setAttributeValues(context, attributes);
//					}catch(Exception e3){
//						sbErrorMessage.append("not input attribute value.");
//					}
//						
//					String partObjectId = partObj.getId(context);
//
//					if(boolPerson){
//						partObj.setOwner(context, stTDM_ORG_USER_ID); 
//					}
//					
//					
//					
//					
////					StringList tempProjectArray = FrameworkUtil.split(stCN_PROJECT,"-");
////					String sAccessCustomer = stCN_PROJECT_CUST.trim();
////					
////					boolean checkOwner = false;
//					boolean checkOrg = false;
//					boolean checkProject = false;
//					String sOwner = "";
//					String findOrg = "list role $1 select $2 dump;";
//					if (cdmStringUtil.isNotEmpty(stAceesOrg) && cdmStringUtil.isNotEmpty(stAccessProductGroup)) {
//						String str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { stAceesOrg, "isanorg" });
//						if ("TRUE".equalsIgnoreCase(str2)) {
//							findOrg = "list role $1 select $2 dump;";
//							str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { stAccessProductGroup, "isaproject" });
//							if ("TRUE".equalsIgnoreCase(str2)) {
//								checkOrg = true;
//								checkProject = true;
//							}
//						}
//					}
//					
//					if(UIUtil.isNotNullAndNotEmpty(stAceesOrg) && UIUtil.isNotNullAndNotEmpty(stAccessProductGroup) && checkOrg && checkProject ){
//						MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", partObjectId, stAccessProductGroup, stAceesOrg);
//					}
//					
////					partObj.setOwnership(context, checkOwner, checkOrg, checkProject, sOwner, stAceesOrg, stAccessProductGroup);
//				
//					
////					 String str1 = "print role $1 select $2 dump;";                                                                                                 
////					 String str2 = MqlUtil.mqlCommand(paramContext, str1, true, new String[] { paramString2, "isanorg" });                                          
////					 if ("TRUE".equalsIgnoreCase(str2))                                                                                                             
////					 {                                                                                                                                              
////					   str1 = "print role $1 select $2 dump;";                                                                                                      
////					   str2 = MqlUtil.mqlCommand(paramContext, str1, true, new String[] { paramString1, "isaproject" });                                            
////					   if ("TRUE".equalsIgnoreCase(str2))                                                                                                           
////					   {                                                                                                                                            
////					     str1 = "mod bus $1 project $2 organization $3";                                                                                            
////					     MqlUtil.mqlCommand(paramContext, str1, true, new String[] { getObjectId(paramContext), paramString1, paramString2 }); break label142:      
////					   }                                                                                                                                            
//					
//					//test 11/18/16 end
//					
//					
//					/*
//					 * *********************************************************
//					 *  create 시 발생하는 trigger에서 발생하는 interface 생성 start
//					 * *********************************************************
//					 */
//					boolean isMEP = false;
////	
//					if (partObjectId != null && !"".equals(partObjectId)) {
//						String sExternalPartData = PropertyUtil.getSchemaProperty(context, DomainSymbolicConstants.SYMBOLIC_interface_ExternalPartData);
//						Part part = new Part(partObjectId);
//						String sPolicyClassification = part.getInfo(context, "policy.property[PolicyClassification].value");
//
//						// enable MEP by default
//						if (sPolicyClassification != null && "Equivalent".equals(sPolicyClassification)) {
//							isMEP = true;
//						}
//						if (isMEP) {
//							MqlUtil.mqlCommand(context, "modify bus $1 add interface $2;", partObjectId, sExternalPartData);
//						}
//					}
//		
//						/*
//					 * *********************************************************
//					 * attribute[attribute_Originator]
//					 * 의 정보를stTDM_ORG_USER_ID 정보를 입력.
//					 * *********************************************************
//					 * 
//					 */
//					partObj.setAttributeValue(context, DomainConstants.ATTRIBUTE_ORIGINATOR, stTDM_ORG_USER_ID);
//						
//					//2012/05/15 02:53:29 ,날짜 기록
//					if (UIUtil.isNotNullAndNotEmpty(stCREATION_DATE) ) {
//						Date createdate = new Date(stCREATION_DATE);
////						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss aa", new Locale("en", "US"));
//						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa", new Locale("en", "US"));
//						String tempCreatedDate = "";
//						tempCreatedDate = sdf.format(createdate);
//						//12/6/2016 10:40:16 AM
//						MqlUtil.mqlCommand(context, "mod bus $1 originated $2", partObjectId, tempCreatedDate);
//					}
//						/* part Master 생성 start */
//						createPartMaster(context, partObjectId, stTDM_ORG_USER_ID,boolPerson);
//						/* part Master 생성 end */
//		
//						/* create 시 발생하는 trigger에서 사용된 정보 interface 생성 end */
//		
//						/*
//						 * *********************************************************
//						 * 
//						 *  EBOM 정보로 연결된 Part 을 생성할시 relationship 연결을 제외된다.
//						 * 또한 relationship 연결의 경우 공통코드 데이타가 PLM에 스마트팀 정보가 다 있다고 가정하여
//						 * 진행 공통코드를 검색하여 데이타가 없을시 오류 처리 . 오류가 발생하면 Exception 발생.
//						 * *********************************************************
//						 */
//		
//						StringBuffer sbVehicleId = new StringBuffer("");
//						StringBuffer sbProjectId = new StringBuffer("");
//						StringBuffer sbProjectTypeId = new StringBuffer("");
//						StringBuffer sbProductTypeId = new StringBuffer("");
//		
//						StringBuffer sbOrg1Id = new StringBuffer();
//						StringBuffer sbOrg2Id = new StringBuffer();
//						StringBuffer sbOrg3Id = new StringBuffer();
//		
//						StringBuffer sbOption1Id = new StringBuffer("");
//						StringBuffer sbOption2Id = new StringBuffer("");
//						StringBuffer sbOption3Id = new StringBuffer("");
//						StringBuffer sbOption4Id = new StringBuffer("");
//						StringBuffer sbOption5Id = new StringBuffer("");
//						StringBuffer sbOption6Id = new StringBuffer("");
//		
//						StringBuffer sbECONumberId = new StringBuffer("");
//						StringBuffer sbDrawingNoId = new StringBuffer("");
//						StringList sListPFs = new StringList();
//						/* ************************************************
//						 * stCN_VEHICLE_DESC 정보는 두개 이상 있을수 있으며 구분자 , 
//						 * stVehicle_Cust 정보의 경우 두개이상 데이타 존재 있을수 있다 구분자 ;
//						 * ************************************************
//						 * */
//						StringList stListCN_VEHICLE_DESC = new StringList();
//						StringList stListVehicle_Cust = new StringList();
//	
//						stListCN_VEHICLE_DESC = FrameworkUtil.split(stCN_VEHICLE_DESC, ",");
//	
//						boolean checkErrorVehicleCust = false;
//						if (stVehicle_Cust.startsWith("ORA-01422") || "-2147483647".equals(stVehicle_Cust)) {
//							checkErrorVehicleCust = true;
//						} else {
//							stListVehicle_Cust = FrameworkUtil.split(stVehicle_Cust, ";");
//						}
//	
//						if (cdmStringUtil.isNotEmpty(stCN_VEHICLE_DESC) &&  !checkErrorVehicleCust) {
//	
//							for (int stListVehicleNum = 0; stListVehicleNum < stListCN_VEHICLE_DESC.size(); stListVehicleNum++) {
//	
//								String stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);
//	
//								String stTempVehicleCust = (String) stListVehicle_Cust.get(stListVehicleNum);
//								
//								String searchVehicle = stTempVehicle+"_"+stTempVehicle+"_"+stTempVehicleCust;
//								
//								String tempVehicleId = (String)vehicleCommonCodeMap.get(searchVehicle);
//								tempVehicleId = (tempVehicleId == null || "null".equals(tempVehicleId)) ? "" : tempVehicleId.trim();
//								if(StringUtils.isNotEmpty(tempVehicleId)) {
//									sbVehicleId.append(tempVehicleId);
//									sbVehicleId.append(",");
//								}
//	
//							}
//						}
//						
//						if(cdmStringUtil.isNotEmpty(stCN_VEHICLE_DESC) && cdmStringUtil.isEmpty(sbVehicleId.toString()) && !checkErrorVehicleCust){
//							sbErrorMessage.append("O").append("\t");
//						}else{
//							sbErrorMessage.append("X").append("\t");
//						}
//						
//						/* Project */
//						if (cdmStringUtil.isNotEmpty(stCN_Project_Id)) {
//							
//							String stTempProjectId = "";
//							stTempProjectId = (String)projectMap.get(stCN_Project_Id);
//							stTempProjectId = (stTempProjectId == null || "null".equals(stTempProjectId)) ? "" : stTempProjectId.trim();
//							sbProjectId.append(stTempProjectId);
//							
//						}
//						
//						if(cdmStringUtil.isEmpty(sbProjectId.toString())){
////							sbErrorMessage.append("No Project information exists in the database.");
//							sbErrorMessage.append("O").append("\t");
//						}else{
//							sbErrorMessage.append("X").append("\t");
//						}
//						
//						// Product Group
//						if (cdmStringUtil.isNotEmpty(stCN_PRODUCT_GROUP)) {
//							String stTempProductGroupId = (String)productGroupMap.get(stCN_PRODUCT_GROUP+"_"+stCN_PRODUCT_DIV);
//							stTempProductGroupId = (stTempProductGroupId == null || "null".equals(stTempProductGroupId)) ? "" : stTempProductGroupId.trim();
//							sbProjectTypeId.append(stTempProductGroupId);
//	
//						}
//	
//						if(cdmStringUtil.isNotEmpty(stCN_PRODUCT_GROUP) && cdmStringUtil.isEmpty(sbProjectTypeId.toString())){
////							sbErrorMessage.append("No Product Group information exists in the database.");
//							sbErrorMessage.append("O").append("\t");
//						}else{
//							sbErrorMessage.append("X").append("\t");
//						}
//						
//						/* Product Div */
//						if ( cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
//							String stTempProductDivId = (String)productDivMap.get(stCN_PRODUCT_DIV);
//							stTempProductDivId = (stTempProductDivId == null || "null".equals(stTempProductDivId)) ? "" : stTempProductDivId.trim();
//							sbProductTypeId.append(stTempProductDivId);
//	
//						}
//						
//						if(cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV) && cdmStringUtil.isEmpty(sbProductTypeId.toString())){
////							sbErrorMessage.append("No Product Div information exists in the database.");
//							sbErrorMessage.append("O").append("\t");
//						}else{
//							sbErrorMessage.append("X").append("\t");
//						}
//	
//						/* Option1 */
//						if (cdmStringUtil.isNotEmpty(stCN_OPTION1)) {
//							
//							String stTempOption1 = "";
//							stTempOption1 = (String)option1Map.get(stCN_OPTION1+"_"+stCN_PRODUCT_DIV);
//							stTempOption1 = (stTempOption1 == null || "null".equals(stTempOption1)) ? "" : stTempOption1.trim();
//							sbOption1Id.append(stTempOption1);
//						}
//						
//						if(cdmStringUtil.isNotEmpty(stCN_OPTION1) && cdmStringUtil.isEmpty(sbOption1Id.toString())){
//							sbErrorMessage.append("O").append("\t");
//						}else{
//							sbErrorMessage.append("X").append("\t");
//						}
//						
//						/* Option2 */
////						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeOption2Id) && cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
//						if (cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
//							String stTempOption2 = "";
//							stTempOption2 = (String)option2Map.get(stCN_OPTION2+"_"+stCN_PRODUCT_DIV);
//							stTempOption2 = (stTempOption2 == null || "null".equals(stTempOption2)) ? "" : stTempOption2.trim();
//							sbOption2Id.append(stTempOption2);
//						}
//						
//						if(cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isEmpty(sbOption2Id.toString())){
////							
//							sbErrorMessage.append("O").append("\t");
//						}else{
//							sbErrorMessage.append("X").append("\t");
//						}
//	
//						/* Option3 */
//						if (cdmStringUtil.isNotEmpty(stCN_OPTION3) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
//							String stTempOption3 = "";
//							stTempOption3 = (String)option3Map.get(stCN_OPTION3+"_"+stCN_PRODUCT_DIV);
//							stTempOption3 = (stTempOption3 == null || "null".equals(stTempOption3)) ? "" : stTempOption3.trim();
//							sbOption3Id.append(stTempOption3);
//						}
//						if(cdmStringUtil.isNotEmpty(stCN_OPTION3) && cdmStringUtil.isEmpty(sbOption3Id.toString())){
////							sbErrorMessage.append("No OPTION3 information exists in the database.");
//							sbErrorMessage.append("O").append("\t");
//						}else{
//							sbErrorMessage.append("X").append("\t");
//						}
//						/* Option4 */
//						if ( cdmStringUtil.isNotEmpty(stCN_OPTION4) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
//							String stTempOption4 = "";
//							stTempOption4 = (String)option4Map.get(stCN_OPTION4+"_"+stCN_PRODUCT_DIV);
//							stTempOption4 = (stTempOption4 == null || "null".equals(stTempOption4)) ? "" : stTempOption4.trim();
//							sbOption4Id.append(stTempOption4);
//						}
//						if(cdmStringUtil.isNotEmpty(stCN_OPTION4) && cdmStringUtil.isEmpty(sbOption4Id.toString())){
////							sbErrorMessage.append("No OPTION4 information exists in the database.");
//							sbErrorMessage.append("O").append("\t");
//						}else{
//							sbErrorMessage.append("X").append("\t");
//						}
//						/* Option5 */
//						if (cdmStringUtil.isNotEmpty(stCN_OPTION5) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
//							
//							String stTempOption5 = "";
//							stTempOption5 = (String)option5Map.get(stCN_OPTION5+"_"+stCN_PRODUCT_DIV);
//							stTempOption5 = (stTempOption5 == null || "null".equals(stTempOption5)) ? "" : stTempOption5.trim();
//							sbOption5Id.append(stTempOption5);
//	
//						}
//						if(cdmStringUtil.isNotEmpty(stCN_OPTION5) && cdmStringUtil.isEmpty(sbOption5Id.toString())){
////							sbErrorMessage.append("No OPTION5 information exists in the database.");
//							sbErrorMessage.append("O").append("\t");
//						}else{
//							sbErrorMessage.append("X").append("\t");
//						}
//						/* Option6 */
//						if (cdmStringUtil.isNotEmpty(stCN_OPTION6) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
//							String stTempOption6 = "";
//							stTempOption6 = (String)option6Map.get(stCN_OPTION6+"_"+stCN_PRODUCT_DIV);
//							stTempOption6 = (stTempOption6 == null || "null".equals(stTempOption6)) ? "" : stTempOption6.trim();
//							sbOption6Id.append(stTempOption6);
//						}
//						if(cdmStringUtil.isNotEmpty(stCN_OPTION6) && cdmStringUtil.isEmpty(sbOption6Id.toString())){
////							sbErrorMessage.append("No OPTION6 information exists in the database.");
//							sbErrorMessage.append("O").append("\t");
//						}else{
//							sbErrorMessage.append("X").append("\t");
//						}
//						/* sbECONumberId */
//					if (cdmStringUtil.isNotEmpty(stCN_ECO_NUMBER)) {
//						StringBuffer sbfECType = new StringBuffer();
//						sbfECType.append("cdmECO");
//						sbfECType.append(",");
//						sbfECType.append("cdmEAR");
//						sbfECType.append(",");
//						sbfECType.append("cdmDCR");
//						sbfECType.append(",");
//						sbfECType.append("cdmPEO");
////						sbfECType.append(",");
////						sbfECType.append("cdmTEO");
//						
//						
//						String stTempECExist = "temp query bus \"" + sbfECType.toString() + "\" \""+stCN_ECO_NUMBER +"\"  *  select id dump |";
//						String stTempECExistMql = MqlUtil.mqlCommand(context, stTempECExist);
//						StringList sListTempECExistMql = FrameworkUtil.split(stTempECExistMql, "|");
//						// test start start
//						if (sListTempECExistMql.size() > 2) {
//							sbECONumberId.append(sListTempECExistMql.get(3));
//							sbErrorMessage.append("X").append("\t");
//						} else {
//							sbErrorMessage.append("O").append("\t");
//						}
//					}
//					
//					//Part Family 1:1 관계 되도록 
//					if (stCN_ID.length() > 6) {
//
//						String pfCodeName = stCN_ID.substring(0, 5);
//						String partFamilys = (String)partFamilyMap.get(pfCodeName);
//						partFamilys = (partFamilys == null || "null".equals(partFamilys)) ? "" : partFamilys.trim();
//						sListPFs = FrameworkUtil.split(partFamilys, ",");
//						if(cdmStringUtil.isEmpty(partFamilys) ){
//							if(bNewPartCheck){
//								sbErrorMessage.append("○").append("\t");
//							}else{
//								sbErrorMessage.append("X").append("\t");
//							}
//						}else{
//							if(bNewPartCheck){
//								sbErrorMessage.append("X").append("\t");
//							}else{
//								sbErrorMessage.append("○").append("\t");
//							}
//						}
//					}else{
//						sbErrorMessage.append("○").append("\t");
//					}
//					
////						stCN_ECO_NUMBER
//						/* sbDrawingNoId */
//	
//						HashMap paramHM = new HashMap();
//						paramHM.put("partObjectId", partObjectId);
//						paramHM.put("VehicleObjectId", sbVehicleId.toString());
//						paramHM.put("ProjectObjectId", sbProjectId.toString());
//						paramHM.put("ProjectTypeObjectId", sbProjectTypeId.toString());
//						paramHM.put("ProductTypeObjectId", sbProductTypeId.toString());
//						
//						String[] objectIdArray = sbVehicleId.toString().split(",");
//						for(int i=0; i<objectIdArray.length; i++){
//	    					String strVehicleId = objectIdArray[i];
//	    					
//	    					if(StringUtils.isEmpty(strVehicleId))
//	    						continue;
//	    					
//	    					DomainRelationship.connect(context, new DomainObject(strVehicleId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
//	    				}
//
////						paramHM.put("Org1ObjectId", sbOrg1Id.toString());
////						paramHM.put("Org2ObjectId", sbOrg2Id.toString());
////						paramHM.put("Org3ObjectId", sbOrg3Id.toString());
////						paramHM.put("Option1ObjectId", sbOption1Id.toString());
////						paramHM.put("Option2ObjectId", sbOption2Id.toString());
////						paramHM.put("Option3ObjectId", sbOption3Id.toString());
////						paramHM.put("Option4ObjectId", sbOption4Id.toString());
////						paramHM.put("Option5ObjectId", sbOption5Id.toString());
////						paramHM.put("Option6ObjectId", sbOption6Id.toString());
////						
//						
//						if(UIUtil.isNotNullAndNotEmpty(sbProjectId.toString())){
//			    			DomainRelationship.connect(context, new DomainObject(sbProjectId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT, partObj);
//			    		}
//						
//						if(UIUtil.isNotNullAndNotEmpty(sbProjectTypeId.toString())){
//							DomainRelationship.connect(context, new DomainObject(sbProjectTypeId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE, partObj);
//			        	}
//						
//						
//						if(UIUtil.isNotNullAndNotEmpty(sbProductTypeId.toString())){
//			    			DomainRelationship.connect(context, new DomainObject(sbProductTypeId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE, partObj);
//			        	}
//						
//						if(UIUtil.isNotNullAndNotEmpty(sbOption1Id.toString())){
//							DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption1Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
//							x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option1");
//			        	}
//			        	if(UIUtil.isNotNullAndNotEmpty(sbOption2Id.toString())){
//			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption2Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
//			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option2");
//			        	}
//			        	if(UIUtil.isNotNullAndNotEmpty(sbOption3Id.toString())){
//			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption3Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
//			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option3");
//			        	}
//			        	if(UIUtil.isNotNullAndNotEmpty(sbOption4Id.toString())){
//			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption4Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
//			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option4");
//			        	}
//			        	if(UIUtil.isNotNullAndNotEmpty(sbOption5Id.toString())){
//			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption5Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
//			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option5");
//			        	}
//			        	if(UIUtil.isNotNullAndNotEmpty(sbOption6Id.toString())){
//			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption6Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
//			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option6");
//			        	}
//			        	
//						paramHM.put("ECONumberOid", sbECONumberId.toString());
//						if(UIUtil.isNotNullAndNotEmpty(sbECONumberId.toString())){
//		        			DomainRelationship.connect(context, new DomainObject(sbECONumberId.toString()), DomainConstants.RELATIONSHIP_AFFECTED_ITEM, partObj);
//			        		
//			        	}
//						
//					if (bNewPartCheck) {
//						int sListPartFamilyIdsSize = sListPFs.size();
//						boolean bCheckPartNamePF = false;
//						/*PF 와는 1:1 관계 Part name 5자리와 일치하는 여러개의 Part family 존재가능이때 part Family의 name: 으로 확인 */
//						for (Iterator iterPF = sListPFs.iterator(); iterPF.hasNext();) {
//							
//							String sPF = (String) iterPF.next();
//							HashMap connectPFHMap = new HashMap();
//							
//							if(sListPartFamilyIdsSize>1){
//								String pfCodeName = stCN_ID.substring(0, 5);
//								String checkPartFamilyName = pfCodeName+":"+stTDM_DESCRIPTION;
//								sPF = (String)partFamilyMap.get(checkPartFamilyName);
//								bCheckPartNamePF = true;
//							}
//							
//							if ( (UIUtil.isNotNullAndNotEmpty(sPF) && bCheckPartNamePF) || sListPartFamilyIdsSize == 1) {
//								connectPFHMap.put("sPF", sPF);
//								connectPFHMap.put("partObjectId", partObjectId);
//								
//								String connectResult = JPO.invoke(context, "cdmPartMigration", null, "connectPartFamily", JPO.packArgs(connectPFHMap), String.class);
//
//								if (connectResult.startsWith("false|")) {
//									int startIndex = connectResult.indexOf("false|");
//									connectResult.substring(startIndex);
//									sbErrorMessage.append(connectResult).append("\t");
//								} else {
//									sbErrorMessage.append("O").append("\t");
//
//								}
//								break;
//							}
//						}
//						checkAddPart = true;
//					}else{
//						checkAddPart = true;
//					}
//						
//						//
//					
//						/*
//						 * *********************************************************
//						 * promote 및 revise "In Approval" 상태를
//						 * 가진 part 정보일경우 enovia에서는 In Review 상태로 ... "Inactive" 상태를
//						 * 가진 part 정보일경우 enovia에서는 Obsolete 상태로 변경. 과거 revision을 가진
//						 * object 은 무조건 Released 상태를 가진다. 현재 eo 데이타는 존재하지않아 연결정보를
//						 * 사용할 수 없다. 현재 상태로는 eo 데이타가 없고 drawing 데이타가 연결이 되지않아 추후 연결
//						 * 필요
//						 * 
//						 * 도면 있을 때 에는 revise 될때 같이 처리해야한다. 참조 cdmPartLibray
//						 * revise... 소스는 빼논 상태
//						 * *********************************************************
//						 * 
//						 */
//						
//					
//					ContextUtil.commitTransaction(context);
//					MqlUtil.mqlCommand(context, "trigger on");
//					checkTriggerOff = false;	
//						
//					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
////						writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());	
//						writeSuccessToFile(subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+sbErrorMessage.toString());	
//					}else{
//						writeSuccessToFile(subPartCount +"\t"+tempStPartNo+"\t"+stREVISION);
//							
//					}
//						
//						successCount++;
//						
//				} catch (Exception e) {
//					ContextUtil.abortTransaction(context);
//
//					if(checkTriggerOff){
//						MqlUtil.mqlCommand(context, "trigger on");
//						checkTriggerOff = false;			
//					}
//					failCount++;
//					writeErrorToFile("LineNum(#)"+tempStRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " +e.getMessage().replaceAll("\r|\n", "")); 
//					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t" +  data ) ;
//					
//					e.printStackTrace(errorStream);
//					writeShotErrorToFile(e.toString());
//				}finally{
//					
//				}
//				
//			} // end of while 
//			
//			
//			writeMessageToConsole("====================================================================================");
//			writeMessageToConsole("        Migration COMPLETED.                    ");
//			writeMessageToConsole("====================================================================================");
//			//
//		} catch (Exception e1) {
//			writeFailToFile(" LineNum(#):"+tempStRowNum);
//			writeErrorToFile("LineNum(#):"+tempStRowNum + "  "+e1.getMessage());
//			e1.printStackTrace(errorStream);
//			
//		}finally {
//			if(lineNumber>2){
//				lineNumber= lineNumber -2;
//			}else{
//				lineNumber =0;
//			}
//			writeMessageToConsole("====================================================================================");
//			writeMessageToConsole("	CREATE PART OBJECT CLOSE TIME:  "+cdmCommonExcel.getTimeStamp2()+"          "  );
//			writeMessageToConsole("	CREATE PART OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
//			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+")  TOTAL COUNT:("+(lineNumber)+"  ");
//			writeMessageToConsole("==================================================================================== \n");
//			MqlUtil.mqlCommand(context, "history on");
//			if(checkTriggerOff){
//				MqlUtil.mqlCommand(context, "trigger on");
//			}
//			try {
//				if (null != errorStream )
//					errorStream .close();
//
//				if (null != logWriter)
//					logWriter.close();
//
//				if (null != failedObjectidWriter)
//					failedObjectidWriter.close();
//				
//				if (null != successObjectidWriter)
//					successObjectidWriter.close();
//
//				if(null != bufferReader)
//					bufferReader.close();
//				
//				if(null != errorLogFile)
//					errorLogFile.close();
//				
//				if(null != debugLogFile)
//					debugLogFile.close();
//
//				if(null != errorLogFile)
//					errorLogFile.close();
//			} catch (IOException e) {
//				System.out.println("Exception while closing log stream " + e.getMessage());
//			}
//			
//			
//			bufferReader.close();
//			long endTime = System.currentTimeMillis();
//			long leadTime = (endTime-startTime)/1000;
//			System.out.println("cdmPartMigration : createPartM End.   endTime:"+cdmCommonExcel.getTimeStamp2()  + "leadTime :"+leadTime/60);
//			
//		}
//	}
	
	
	/**
	 * part Master 생성
	 * @param context
	 * @param objectId
	 * @throws Exception
	 */
	public void createPartMaster(Context context, String objectId, String stOriginator, boolean boolPerson) throws Exception {
		String strPartMasterId = "";

		DomainObject doPart = DomainObject.newInstance(context);
		doPart.setId(objectId);

		try {
			doPart.open(context);

			// Par Master creation and connection should happen only for
			// Production, Development and Unresolved Parts.

			String strPartName = doPart.getInfo(context, DomainObject.SELECT_NAME);

			DomainObject doPartMaster = null;
			BusinessObject boPartMaster = null;

			String typePartMaster = "Part Master";
			String policyPartMaster = "Part Master";
			String relationshipPartRevision = "Part Revision";

			boPartMaster = new BusinessObject(typePartMaster, strPartName, doPart.getInfo(context, DomainObject.SELECT_TYPE), doPart.getVault());
			if (!boPartMaster.exists(context)) {
				boPartMaster.create(context, policyPartMaster);
			}
			boPartMaster.open(context);
			strPartMasterId = boPartMaster.getObjectId();
			boPartMaster.close(context);

			doPartMaster = DomainObject.newInstance(context);
			doPartMaster.setId(strPartMasterId);

			DomainRelationship.connect(context, doPartMaster, relationshipPartRevision, doPart);

			/*
			 * *********************************************************** mod
			 * by 9/26/16 start. description : attribute[Originator] 의 설정
			 ************************************************************/
			// doPartMaster.setAttributeValue(context,
			// DomainConstants.ATTRIBUTE_ORIGINATOR, context.getUser());
			if (boolPerson) {
				doPartMaster.setAttributeValue(context, DomainConstants.ATTRIBUTE_ORIGINATOR, stOriginator);
				doPartMaster.setOwner(context, stOriginator);
				
			}
			/* mod by 9/26/16 end. */

		} catch (Exception e) {
			throw e;
		} finally {
			doPart.close(context);
		}
	}

	/**
	 * 11/18
	 * Add part attributes (comment, reason)
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void addPartAttributes(Context context,String args[])throws Exception{

		long startTime = System.currentTimeMillis();
		System.out.println("${CLASS:cdmBomMigration} : createPartM -StartTime:"+startTime);
		String logFileName = "PartMigration";
		if(args.length!=1){
			String errorMessage = "NOT FIND PATH ";
			throw new Exception(errorMessage);
		}
		
		String partPath = args[0];
		
		String sFileLocation = "";
		String sFileName = "";
		sFileLocation 	= partPath.substring(0,partPath.lastIndexOf("\\"));
		sFileName 		= partPath.substring(partPath.lastIndexOf("\\")+1);
		
		
//		String[] argTest = {"C:\\temp\\Import_File\\Part","Retrieve_Items_BD-With_Comment_01.txt"}; // 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명  
		String[] argTest = {sFileLocation,sFileName}; // 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명  
		initializeM(context,argTest,2,logFileName);      //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		
		//Total line total except null
		int 	tempStRowNum   = 0; 
		int successCount = 0;
		int failCount = 0;
		
		
		BufferedReader bufferReader = null;	
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
		writeMessageToConsole("Reading input log file from : "+inputDirectory);
		writeMessageToConsole("	Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		try {
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory+fileName),"euc-kr"));
			String data = "";  							// 텍스트 파일 라인정보담을 변수 
			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
			
			int lineNumber = 1;      
			int subLineNumber = 0;
			
			MqlUtil.mqlCommand(context, "trigger off");
			
			while ((data = bufferReader.readLine()) != null) {

				StringList stListData = FrameworkUtil.split(data, "\t");
				try {
					if (lineNumber == 1) {
						stListHeader = stListData;
						lineNumber++;
						continue;
					}

					lineNumber++;
					tempStRowNum = lineNumber;
					
					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
					int size_Data = stListData.size();
					int size_Header = stListHeader.size();
					if (size_Data != size_Header) {
						String errorMessage = " NOT MATCH DATA FIELD";
						throw new Exception(errorMessage);
					}

					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {
						// String sPartInfos =
						// ((String)stListData.get(stListNum)).trim();
						// String sPartHeader =
						// ((String)stListHeader.get(stListNum)).trim();

						String sPartInfos = cdmCommonExcel.isVaildNullData((String) stListData.get(stListNum));
						String sPartHeader = (String) stListHeader.get(stListNum);
						partHM.put(sPartHeader, sPartInfos);
					}
					ContextUtil.startTransaction(context, true);
					
					String sPartLineNumber = (String) partHM.get("#");
					String sPartName = (String) partHM.get("CN_ID");
					String sPartRevision = (String) partHM.get("REVISION");
					String sPartComment = (String) partHM.get("CN_COMMENTS");
					String sPartChangeReason = (String) partHM.get("CN_CHANGE_REASON");

					if (cdmStringUtil.isEmpty(sPartLineNumber)) {
						String errorMessage = "The information in the #(line number) column does not exist.";
						throw new Exception(errorMessage);
					}
					if (cdmStringUtil.isEmpty(sPartName)) {
						String errorMessage = "The information in the CN_ID column does not exist.";
						throw new Exception(errorMessage);
					}

					if (cdmStringUtil.isEmpty(sPartRevision)) {
						String errorMessage = "The information in the REVISION column does not exist.";
						throw new Exception(errorMessage);
					}
					subLineNumber = Integer.parseInt(sPartLineNumber);
					
					String findPartInfo = "temp query bus \"cdmMechanicalPart,cdmPhantomPart\"  \""+sPartName +"\" \""+sPartRevision +"\"  select id dump |"; 
					String findPartInfoMql = MqlUtil.mqlCommand(context, findPartInfo);
					
					StringList sListFindPartInfo = new StringList();
					sListFindPartInfo = FrameworkUtil.split(findPartInfoMql, "|");
					
					String partId = "";
					if(sListFindPartInfo.size()>2){
						partId = (String)sListFindPartInfo.get(3);
					}else{
						String errorMessage = "The part you searched for in the database does not exist.";
						throw new Exception(errorMessage);
					}
					
					DomainObject dObj = new DomainObject(partId);
					HashMap paramHm = new HashMap();
					if(cdmStringUtil.isNotEmpty(sPartComment)){
						paramHm.put("cdmDescription", sPartComment);
					}
					if(cdmStringUtil.isNotEmpty(sPartChangeReason)){
						paramHm.put("cdmPartChangeReason", sPartChangeReason);
					}
					
					dObj.setAttributeValues(context, paramHm);
					
					writeMessageToConsole("LINE NUMBER: " + tempStRowNum +" | sub LineNumber"+subLineNumber+"");
					ContextUtil.commitTransaction(context);
					successCount ++ ;
				} catch (Exception e) {
					ContextUtil.abortTransaction(context);
					failCount++;
					writeErrorToFile("LINE NUMBER: " + tempStRowNum + " EXCEPTION: " + e.getMessage());
					writeFailToFile("LINE NUMBER: " + tempStRowNum + " EXCEPTION: " + e.getMessage());
					e.printStackTrace(errorStream);
				}
			}
			MqlUtil.mqlCommand(context, "trigger on");
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        File  Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================");
			//
		} catch (Exception e1) {
			writeFailToFile("LINE NUMBER: "+tempStRowNum+"|EXCEPTION:"+e1.getMessage());
			writeErrorToFile("LINE NUMBER: "+tempStRowNum + " |EXCEPTION:"+e1.getMessage());
			e1.printStackTrace(errorStream);
			failCount++;
			
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("	ADD PART ATTROBITES CLOSE TIME:  "+cdmCommonExcel.getTimeStamp()+"          "  );
			writeMessageToConsole("	ADD PART ATTROBITES OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000 + " second                  "  );
			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+")"  );
			writeMessageToConsole("==================================================================================== \n");
			
			
			try {
				if (null != errorStream )
					errorStream .close();

				if (null != logWriter)
					logWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if(null != bufferReader)
					bufferReader.close();
				
				if(null != errorLogFile)
					errorLogFile.close();
				
				if(null != debugLogFile)
					debugLogFile.close();

				if(null != errorLogFile)
					errorLogFile.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			
			bufferReader.close();
			long endTime = System.currentTimeMillis();
			long leadTime = (endTime-startTime)/1000;
			System.out.println("cdmPartMigration : createPartM end : -endTime:"+endTime  + "leadTime :"+leadTime);
			
		}
	
	}
	

	/**
	 * 
	 * @param context
	 * @param arg
	 * @throws Exception
	 */
	public void modifyPartCreate(Context context,String arg[])throws Exception{

		long startTime = System.currentTimeMillis();
		System.out.println("cdmPartMigration : modifyPartCreate -StartTime:"+startTime);
		String logFileName = "ModifyPartMigration";
		
	
		if(arg.length!=1){
			throw new Exception("The excel path does not exist.");
		}
		String sFileLocationAndFileName = arg[0];
		
		String sFileLocation 		= "";
		String sFileName 			= "";
		
		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
//		
//		HashMap paramMap = (HashMap)JPO.unpackArgs(arg);
//		sFileLocation = (String)paramMap.get("File_Location");
//		sFileName = (String)paramMap.get("File");
//		
		
		logFileName +="_"+sFileName;
		String[] argTest = {sFileLocation,sFileName}; // 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명  
		  
//		initializeM(context,argTest,2,logFileName);      //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		String sPartInputDirectory = sFileLocation;

		// documentDirectory does not ends with "/" add it
		if(sPartInputDirectory != null && !sPartInputDirectory.endsWith(sfileSeparator))
		{
			sPartInputDirectory = sPartInputDirectory + sfileSeparator;
		}
		String sPartOutputDirectory = "";
		// create a directory to add debug and error logs
		sPartOutputDirectory = new File(sPartInputDirectory).getParentFile().getParent() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+  cdmCommonExcel.getTimeStamp() + sfileSeparator;
        File fileOutputDirectory = new File(sPartOutputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
		logWriter 			 	= new BufferedWriter(new FileWriter(sPartOutputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(sPartOutputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(sPartOutputDirectory + logFileName + "_SuccessLogs.log");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(sPartOutputDirectory + logFileName + "_FailedLogs" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		shortErrorLogFile        = new File(sPartOutputDirectory + logFileName + "ShortErrorLogs" + ".txt");
		shortErrorWriter         = new BufferedWriter(new FileWriter(shortErrorLogFile,true));
		// input file name
		String fileName = sFileName;
		//test end 
		
		
		
		String tempStRowNum   = ""; //순번
		String tempStPartNo   = ""; //엑셀의 PartNo
		String tempStPartRevision   = ""; //엑셀의 PartNo
		
		int successCount = 0;
		int failCount = 0;
		boolean checkTriggerOff = false;
		BufferedReader bufferReader = null;
//		writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());
//		writeSuccessToFile("subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());
		writeSuccessToFile("LineNume(#) \t  PartNo. \t Revision \t error Org Project \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t No OPTION1 exists. \t No OPTION2 exists. \t No OPTION3 exists. \t  No OPTION4 exists. \t No OPTION5 exists \t  No OPTION6 exists \t EC information does not exist. \t No Part Family exist. \t attribute value ");
		writeErrorToFile("[cdmPartMigration : createPartM]");
		writeErrorToFile("LineNum(#) \t ErrorTime");
//		writeFailToFile("[cdmPartMigration : createPartM]");
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole(" PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
		writeMessageToConsole("	Reading input log file from : "+sPartInputDirectory+fileName);
		writeMessageToConsole("	Writing Log files to: " + sPartInputDirectory );
		writeMessageToConsole("====================================================================================\n");
		boolean checkAddPart = false;
		MqlUtil.mqlCommand(context, "history off");
		try {
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(sPartInputDirectory+fileName),"euc-kr"));
			String data = "";  							// 텍스트 파일 라인정보담을 변수 
			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
			
			/* cdmCommonCode lev2 object 검색 start  */
			
			// 12/2 start 
			Map option1Map = getOptionCode(context,"Option1");
			Map option2Map = getOptionCode(context,"Option2");
			Map option3Map = getOptionCode(context,"Option3");
			Map option4Map = getOptionCode(context,"Option4");
			Map option5Map = getOptionCode(context,"Option5");
			Map option6Map = getOptionCode(context,"Option6");
			
			Map vehicleCommonCodeMap = getVehicleCode(context,"Vehicle");
			Map productGroupMap = getProductGroupCode(context,"Product Group Name");
			Map productDivMap = getProductDivCode(context,"Product Div");
			Map projectMap = getProjectCode(context,"cdmProjectGroupObject");
			Map partFamilyMap = getPartFamilyId(context);
			
			/*cdmCommonCode lev2 object 검색 end */ 
			
			String strLanguage = context.getLocale().getLanguage();
			
			AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
			attrPartGlobal.open(context);
			StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
			attrPartGlobal.close(context);
			StringList attrPartGlobalKOList = new StringList();
			attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
			
			
			AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
			attrPartItemType.open(context);
			StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
			attrPartItemType.close(context);
			StringList attrPartItemTypeKOList = new StringList();
			attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
			
			
			AttributeType attrPartERPInterface = new AttributeType("cdmPartERPInterface");
			attrPartERPInterface.open(context);
			StringList attrPartERPInterfaceList = attrPartERPInterface.getChoices(context);
			attrPartERPInterface.close(context);
			StringList attrPartERPInterfaceKOList = new StringList();
			attrPartERPInterfaceKOList = i18nNow.getAttrRangeI18NStringList("cdmPartERPInterface", attrPartERPInterfaceList, strLanguage);
			
			AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
			attrPartType.open(context);
			StringList attrPartTypeList = attrPartType.getChoices(context);
			attrPartType.close(context);
			StringList attrPartTypeKOList = new StringList();
			attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
			
			HashMap tempUOMHMap = new HashMap();
			tempUOMHMap.put("EA"  , "Each");
			tempUOMHMap.put("BAG" , "bag");
			tempUOMHMap.put("BTL" , "bottle");
			tempUOMHMap.put("BOX" , "box");
			tempUOMHMap.put("CC"  , "cc");
			tempUOMHMap.put("CMM" , "mm³");
			tempUOMHMap.put("CMT" , "m³");
			tempUOMHMap.put("CN"  , "can");
			tempUOMHMap.put("CT"  , "carton");
			tempUOMHMap.put("DL"  , "dl");
			tempUOMHMap.put("DZ"  , "dozen");
			tempUOMHMap.put("FT"  , "ft");
			tempUOMHMap.put("GLL" , "gallon");
			tempUOMHMap.put("G"   , "g");
			tempUOMHMap.put("IN"  , "inch");
			tempUOMHMap.put("KG"  , "kg");
			tempUOMHMap.put("KMT" , "km");
			tempUOMHMap.put("L"   , "L");
			tempUOMHMap.put("LBR" , "lb");
			tempUOMHMap.put("M"   , "m");
			tempUOMHMap.put("MGR" , "mg");
			tempUOMHMap.put("ML"  , "ml");
			tempUOMHMap.put("MMT" , "mm");
			tempUOMHMap.put("MT"  , "ton");
			tempUOMHMap.put("N"   , "N");
			tempUOMHMap.put("PC"  , "Piece");
			tempUOMHMap.put("PL"  , "Pl");
			tempUOMHMap.put("ROL" , "Roll");
			tempUOMHMap.put("SET" , "Set");
			tempUOMHMap.put("SH"  , "Sheet");
			tempUOMHMap.put("SM"  , "m²");
			tempUOMHMap.put("UN"  , "unit");
			tempUOMHMap.put("DRM" , "drum");
			
			int lineNumber = 1;      
//			String sRecordRowNum = "";
			int subPartCount = 0;
			
			String strPreviousPartNo = null;
			String strPreviousPartRevision = null;
			String strPreviousPartType = null;
			
			
			while ((data = bufferReader.readLine()) != null) {
				
				StringBuffer sbErrorMessage = new StringBuffer("");
				MqlUtil.mqlCommand(context, "trigger off");
				checkTriggerOff = true;
				checkAddPart = false;
				StringList stListData = FrameworkUtil.split(data, "\t");
				try {
					
					if (lineNumber == 1) {
						stListHeader = stListData;
						writeFailToFile("errorRecord \t"+data);
						lineNumber++;
						continue;
					}
					lineNumber++;
					
					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
					int size_Data = stListData.size();
					int size_Header = stListHeader.size();
					if (size_Data != size_Header) {
						String errorMessage = " NOT MATCH DATA FIELD";
						throw new Exception(errorMessage);
					}

					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {

						String sPartInfos = cdmCommonExcel.isVaildNullData((String)stListData.get(stListNum));
						String sPartHeader = ((String) stListHeader.get(stListNum)).trim();
						partHM.put(sPartHeader, sPartInfos);
						
					}
					
					String stPartType                   = TYPE_CDMMECHANICALPART;  
					String stPartCount                  = ((String)partHM.get("#"            		        )).trim(); // 1 순번 
					String stCLS_NAME                   = ((String)partHM.get("CLS_NAME"                    )).trim(); // 2 
					String stOBJECT_ID                  = ((String)partHM.get("OBJECT_ID"                   )).trim(); // 3 //받은 자료에 unique 값 migration대상아님 
	
					String stCN_ID                      = ((String)partHM.get("CN_ID"  	                    )).trim(); // 5 Name
					String stREVISION                   = ((String)partHM.get("REVISION"                    )).trim(); // 6 Revision
					String stSTATE                      = ((String)partHM.get("STATE"                       )).trim(); // 7 State
					String stCREATION_DATE              = ((String)partHM.get("CREATION_DATE"               )).trim(); // 8  attribute[cdmPartCreationDateM]
					String stUSER_OBJECT_ID             = ((String)partHM.get("USER_OBJECT_ID"              )).trim(); // 9  attribute[cdmPartCreationUserIdM]
					String stUSER_ID_MOD                = ((String)partHM.get("USER_ID_MOD"                 )).trim(); // 10 attribute[cdmPartModUserIdM]
					String stMODIFICATION_DATE          = ((String)partHM.get("MODIFICATION_DATE"           )).trim(); // 11 attribute[cdmPartModificationDateM] 
					String stTDM_DESCRIPTION            = ((String)partHM.get("TDM_DESCRIPTION"             )).trim(); // 12 attribute[cdmPartName]
					String stTDM_UOM                    = ((String)partHM.get("TDM_UOM"  			        )).trim(); // 13 attribute[cdmPartUOM]
					String stPhaseM                     = ((String)partHM.get("PHASE"                       )).trim(); // 14 
					String stPAR_REVISION               = ((String)partHM.get("PAR_REVISION"                )).trim(); // 15 Previous Revision
	//				String stAPPROVAL_DATE              = ((String)partHM.get("APPROVAL_DATE"               )).trim(); // 16 
	//				String stREVISION_STG               = ((String)partHM.get("REVISION_STG"                )).trim(); // 17 
					String stTDM_ORG_USER_ID            = ((String)partHM.get("TDM_ORG_USER_ID"             )).trim(); // 18 First Revision creator
	//				String stTDM_ORG_CREATEDATE         = ((String)partHM.get("TDM_ORG_CREATEDATE"          )).trim(); // 19 
	//				String stTDM_APPROVED_BY            = ((String)partHM.get("TDM_APPROVED_BY"             )).trim(); // 20 
	//				String stTDM_ORIGIN_ID              = ((String)partHM.get("TDM_ORIGIN_ID"               )).trim(); // 21 
					String stCN_PROJECT                 = ((String)partHM.get("CN_PROJECT"                  )).trim(); // 22 PROJECT
					String stCN_PROJECT_CUST            = ((String)partHM.get("CN_PROJECT_CUST"             )).trim(); // 23 PROJECT_CUST
	//				String stCN_PRODUCT_NAME            = ((String)partHM.get("CN_PRODUCT_NAME"             )).trim(); // 24 
	//				String stCN_PART_GROUP              = ((String)partHM.get("CN_PART_GROUP"               )).trim(); // 25 
	//				String stCN_PART_NAME               = ((String)partHM.get("CN_PART_NAME"                )).trim(); // 26
	//				String stCN_WEIGHT                  = ((String)partHM.get("CN_WEIGHT"                   )).trim(); // 27
					String stCN_ESTIMATED_WEIGHT        = ((String)partHM.get("CN_ESTIMATED_WEIGHT"         )).trim(); // 28 attribute[cdmPartEstimatedWeight] 
					String stCN_WEIGHT_UNIT             = ((String)partHM.get("CN_WEIGHT_UNIT"              )).trim(); // 29
					String stCN_TOP_ITEM                = ((String)partHM.get("CN_TOP_ITEM"                 )).trim(); // 30
					String stCN_PHANTOM_ITEM            = ((String)partHM.get("CN_PHANTOM_ITEM"             )).trim(); // 31
					String stCN_ITEM_TYPE               = ((String)partHM.get("CN_ITEM_TYPE"                )).trim(); // 32
					String stCN_SERVICE_ITEM            = ((String)partHM.get("CN_SERVICE_ITEM"             )).trim(); // 33
					String stCN_ITEM_MATERIAL           = ((String)partHM.get("CN_ITEM_MATERIAL"            )).trim(); // 34
					String stCN_ITEM_UPDATE_FROM_ERP    = ((String)partHM.get("CN_ITEM_UPDATE_FROM_ERP"     )).trim(); // 35
					String stCN_COST                    = ((String)partHM.get("CN_COST"                     )).trim(); // 36
					String stCN_CURRENCY                = ((String)partHM.get("CN_CURRENCY"                 )).trim(); // 37
					//String stCN_COMMENTS              = ((String)partHM.get("CN_COMMENTS"                 )).trim(); // 38
					String stCN_OEM_PART_NUMBER         = ((String)partHM.get("CN_OEM_PART_NUMBER"          )).trim(); // 39
					String stEC_NAME                    = ((String)partHM.get("EC_NAME"                     )).trim(); // 40
					String stCN_ECO_NUMBER              = ((String)partHM.get("CN_ECO_NUMBER"               )).trim(); // 41
					String stCN_PRODUCT_GROUP           = ((String)partHM.get("CN_PRODUCT_GROUP"            )).trim(); // 42
					String stCN_SERIES_ITEM             = ((String)partHM.get("CN_SERIES_ITEM"              )).trim(); // 43
					String stCN_VEHICLE                 = ((String)partHM.get("CN_VEHICLE"                  )).trim(); // 44
					String stCN_CUSTOMER                = ((String)partHM.get("CN_CUSTOMER"                 )).trim(); // 45
					String stCN_SIZE                    = ((String)partHM.get("CN_SIZE"                     )).trim(); // 46
					String stCN_SURFACE_TREATMENT       = ((String)partHM.get("CN_SURFACE_TREATMENT"        )).trim(); // 47
					String stCN_SURFACE_AREA            = ((String)partHM.get("CN_SURFACE_AREA"             )).trim(); // 48
					String stCN_ITEM_TYPE1              = ((String)partHM.get("CN_ITEM_TYPE1"               )).trim(); // 49
					String stCN_MATERIAL               = ((String)partHM.get("CN_MATERIAL"                  )).trim(); // 50
					String stCN_ORG1                   = ((String)partHM.get("CN_ORG1"                      )).trim(); // 51  migration 대상 제외  
	//				String stCN_ORG2                   = ((String)partHM.get("CN_ORG2"                      )).trim(); // 52  migration 대상 제외 
	//				String stCN_ORG3                   = ((String)partHM.get("CN_ORG3"                      )).trim(); // 53  migration 대상 제외 
					String stCN_ORG                    = ((String)partHM.get("CN_ORG"                       )).trim(); // 54  MCA Org
					String stCN_MCA_INOUT              = ((String)partHM.get("CN_MCA_INOUT"                 )).trim(); // 55  MCA BOM Management
					String stCN_MCA_PART_TYPE_REF      = ((String)partHM.get("CN_MCA_PART_TYPE_REF"         )).trim(); // 56  MCA Part Type
					String stCN_OPTION1                = ((String)partHM.get("CN_OPTION1"                   )).trim(); // 57
					String stCN_OPTION2                = ((String)partHM.get("CN_OPTION2"                   )).trim(); // 58
					String stCN_OPTION3                = ((String)partHM.get("CN_OPTION3"                   )).trim(); // 59
					String stCN_OPTION4                = ((String)partHM.get("CN_OPTION4"                   )).trim(); // 60
					String stCN_OPTION5                = ((String)partHM.get("CN_OPTION5"                   )).trim(); // 61
					String stCN_OPTION6                = ((String)partHM.get("CN_OPTION6"                   )).trim(); // 62
					String stCN_OPTION7                = ((String)partHM.get("CN_OPTION7"                   )).trim(); // 63
					String stCN_OPTION_ETC             = ((String)partHM.get("CN_OPTION_ETC"                )).trim(); // 64
					String stCN_IS_CASTING             = ((String)partHM.get("CN_IS_CASTING"                )).trim(); // 65
					String stCN_OPTION_DESC            = ((String)partHM.get("CN_OPTION_DESC"               )).trim(); // 66
					String stCN_FOR_MAC                = ((String)partHM.get("CN_FOR_MAC"                   )).trim(); // 67
					String stCN_FOR_MIL                = ((String)partHM.get("CN_FOR_MIL"                   )).trim(); // 68
					String stCN_FOR_MIS                = ((String)partHM.get("CN_FOR_MIS"                   )).trim(); // 69
					String stCN_FOR_MMT                = ((String)partHM.get("CN_FOR_MMT"                   )).trim(); // 70
					String stCN_REAL_WEIGHT            = ((String)partHM.get("CN_REAL_WEIGHT"               )).trim(); // 71
					String stCN_COUNTRY                = ((String)partHM.get("CN_COUNTRY"                   )).trim(); // 72
					String stCN_PRODUCT_DIV            = ((String)partHM.get("CN_PRODUCT_DIV"               )).trim(); // 73
					String stCN_GLOBAL_LOCAL           = ((String)partHM.get("CN_GLOBAL_LOCAL"              )).trim(); // 74
					String stCN_PROJECT_CODE           = ((String)partHM.get("CN_PROJECT_CODE"              )).trim(); // 75
					String stCN_OPTION_DRAWING         = ((String)partHM.get("CN_OPTION_DRAWING"            )).trim(); // 76
					String stCN_FOR_DRAWING_FINISH     = ((String)partHM.get("CN_FOR_DRAWING_FINISH"        )).trim(); // 77
					String stCN_FOR_DRAWING_SIZE       = ((String)partHM.get("CN_FOR_DRAWING_SIZE"          )).trim(); // 78
					String stCN_FOR_DRAWING_REMARK     = ((String)partHM.get("CN_FOR_DRAWING_REMARK"        )).trim(); // 79
					String stCN_ITEM_TYPE2              = ((String)partHM.get("CN_ITEM_TYPE2"               )).trim(); // 80
					String stCN_APPLY_PARTLIST          = ((String)partHM.get("CN_APPLY_PARTLIST"           )).trim(); // 81
//					String stCN_PREVIOUS_PART           = ((String)partHM.get("CN_PREVIOUS_PART"            )).trim(); // 82
					String stCN_COMPLEX_BODY            = ((String)partHM.get("CN_COMPLEX_BODY"             )).trim(); // 83
					String stCN_MAIN_PART_NUMBER        = ((String)partHM.get("CN_MAIN_PART_NUMBER"         )).trim(); // 84
					String stCN_VEHICLE_DESC            = ((String)partHM.get("CN_VEHICLE_DESC"             )).trim(); // 85 VEHICLE 
					String stCN_VEHICLE_CODE            = ((String)partHM.get("CN_VEHICLE_CODE"             )).trim(); // 86
					String stVehicle_Cust               = ((String)partHM.get("VEHICLE_CUST"                )).trim(); // 87
					String stCN_DRAWING_NO              = ((String)partHM.get("CN_DRAWING_NO"               )).trim(); // 88 DRAWING_NO
					String stCN_SUB_ID         		    = ((String)partHM.get("CN_SUB_ID"                   )).trim(); // 89
	//				//String stCN_CHANGE_REASON 	        = ((String)partHM.get("CN_CHANGE_REASON"            )).trim(); // 90 다른 데이타 파일로 진행 예정 
					String stCN_SURFACE_TREATMENT_KEYIN = ((String)partHM.get("CN_SURFACE_TREATMENT_KEYIN"  )).trim(); // 91
					String stCN_OVERSEAS_ORG6           = ((String)partHM.get("CN_OVERSEAS_ORG6"            )).trim(); // 92
					String stCN_OVERSEAS_ORG6_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG6_PART_TYPE"  )).trim(); // 93
					String stCN_OVERSEAS_ORG6_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG6_INOUT"      )).trim(); // 94
//					String stCN_OVERSEAS_ORG7           = ((String)partHM.get("CN_OVERSEAS_ORG7"            )).trim(); // 95
//					String stCN_OVERSEAS_ORG7_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG7_PART_TYPE"  )).trim(); // 96
//					String stCN_OVERSEAS_ORG7_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG7_INOUT"      )).trim(); // 97

					String stCN_Project_Id			    = ((String)partHM.get("CN_PROJECT_ID"  )).trim(); // 98
					String stAccessProductGroup		    = ((String)partHM.get("PROD_GROUP"  )).trim(); // 98
					String stAceesOrg				    = ((String)partHM.get("CN_CUST_VEHICLE"  )).trim(); // 98
					if("-".equals(stAceesOrg)){
						stAceesOrg = "";
					}
					String stCADWeight					= ""; 
					
					String stGLOBAL_LOCAL = "";
					String stITEM_TYPE2 = "";
					String stFOR_DRAWING_REMARK = "";
					String stOPTION_ETC = "";
					String stOPTION_DESC = "";
					String stPartInvestor =   "";
					String stESTIMATED_WEIGHT = "";
					String stITEM_TYPE1 = "";
					String stITEM_TYPE = "";
					String stSERIES_ITEM = "";
					String stPhase = "";
					
					String stPartCADWeight = ""; /*아직 데이타가 없음 속성 정보 재요청 필요 */
					subPartCount = Integer.parseInt(stPartCount);
					tempStRowNum = stPartCount;
					tempStPartNo = stCN_ID;
					tempStPartRevision = stREVISION;
					String personIdMql = "temp query bus Person '" + stTDM_ORG_USER_ID + "' - select id dump |";
					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
					String stPerson = "";
					boolean boolPerson = false;
					if (stListPersonIdMql.size() > 2) {
						stPerson = (String) stListPersonIdMql.get(3);
						boolPerson = true;
					}
					
					/* ***************************************************************************************
					 * stCN_VEHICLE_DESC 은 다중으로 존재가능하며 구분은 , 로 한다. 
					 * ************************************************************************************** */
					
					
					/*  **************************************************************************************
					 *   stCLS_NAME 정보가 "Option Item" 이라면 CN_SUB_ID 정보를 CN_ID에 합쳐야한다. 
					 *  ************************************************************************************ */
					if("Option Item".equalsIgnoreCase(stCLS_NAME)){
						if(cdmStringUtil.isNotEmpty(stCN_SUB_ID)){
							stCN_ID +=stCN_SUB_ID;
						}
					}
					
					/* **************************************************************************************
					 * cdmPartGlobal 의 정보는 global,local 값이 없으면 ""  처리 
					 * ************************************************************************************* */
//					AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
//					attrPartGlobal.open(context);
//					StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
//					attrPartGlobal.close(context);
//					StringList attrPartGlobalKOList = new StringList();
//					attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
					for (int i = 0; i < attrPartGlobalKOList.size(); i++) {
	
						if (stCN_GLOBAL_LOCAL.equalsIgnoreCase((String) attrPartGlobalKOList.get(i))) {
							stGLOBAL_LOCAL = (String) attrPartGlobalList.get(i);
							break;
						}
					}
					if(cdmStringUtil.isEmpty(stGLOBAL_LOCAL)){
						stGLOBAL_LOCAL = "";
					}
					
					/*  **************************************************************************************
					 *   stCN_ITEM_TYPE2 의 정보는 
					 *   attribute[cdmPartItemType]관련 정보
					 *   
					 *   attribute[cdmPartItemType]의 display name과 일치하지않다면 에러 처리  
					 *  ************************************************************************************** */
//					AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
//					attrPartItemType.open(context);
//					StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
//	
//					StringList attrPartItemTypeKOList = new StringList();
//					attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
					boolean bITEM_TYPE2 = false;
					for (int i = 0; i < attrPartItemTypeKOList.size(); i++) {
	
						if (stCN_ITEM_TYPE2.equals((String) attrPartItemTypeKOList.get(i))) {
							stITEM_TYPE2 = (String) attrPartItemTypeList.get(i);
							bITEM_TYPE2 = true;
							break;
						}
						
					}
					
					/* *****************************************************************************************
					 * stCN_FOR_DRAWING_REMARK 의 정보는 Part 의 한글 속성과 일치하다고 가정하여 진행 
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					if(cdmStringUtil.isNotEmpty(stCN_FOR_DRAWING_REMARK) ){
						//
						for (int i = 0; i < attrPartERPInterfaceKOList.size(); i++) {
	
							if (stCN_FOR_DRAWING_REMARK.equals((String) attrPartERPInterfaceKOList.get(i))) {
								stFOR_DRAWING_REMARK = (String) attrPartERPInterfaceList.get(i);
								break;
							}
						}
					}
					
					/* ******************************************************************************************************************************* 
					 * 
					 * stCN_OPTION_ETC
					 * 엑셀에서 텍스트로 저장될경우 맨 앞 혹은 뒤에 특수 기호가 존재할경우 큰따음표로 감싸주는 형태로 텍스트파일에 저장이 된다.
					 * 큰따음표를 제거해주는 부분이며 이는 추후 데이타의 가져올때 재확인하여 제거 해야할지 확인해야할 필요가 있다.
					 * 연속된 구분기호를 하나로 처리해주는 부분이 처리되는 경우가 있어 (텍스트 한정자 ",') 중복시 제거한다. 
					 * 
					 * ******************************************************************************************************************************* */
	//				if (cdmStringUtil.isNotEmpty(stCN_OPTION_ETC)) {
	//					String optionEtcFirstSubString = stCN_OPTION_ETC.substring(0, 1);
	//					int optionEtcLength = stCN_OPTION_ETC.length();
	//					String optionEtcLastSubString = stCN_OPTION_ETC.substring(optionEtcLength - 1);
	//
	//					if ("\"".equals(optionEtcFirstSubString) && "\"".equals(optionEtcLastSubString)) {
	//						stOPTION_ETC = stCN_OPTION_ETC.substring(1, optionEtcLength - 1);
	//						Pattern pattern = Pattern.compile("\"\"");
	//						Matcher matcher = pattern.matcher(stOPTION_ETC);
	//						if (matcher.find()) {
	//							stOPTION_ETC = stOPTION_ETC.replaceAll("\"\"", "\"");
	//						}
	//						Pattern pattern2 = Pattern.compile("\'\'");
	//						Matcher matcher2 = pattern2.matcher(stOPTION_ETC);
	//						if (matcher2.find()) {
	//							stOPTION_ETC = stOPTION_ETC.replaceAll("\'\'", "\'");
	//						}
	//
	//					} else {
	//						stOPTION_ETC = stCN_OPTION_ETC;
	//					}
	//				}
					
					/* ******************************************************************************************************************************* 
					 * stCN_OPTION_DESC
					 * 엑셀에서 텍스트로 저장될경우 맨 앞 혹은 뒤에 특수 기호가 존재할경우 큰따음표로 감싸주는 형태로 텍스트파일에 저장이 된다.
					 * 큰따음표를 제거해주는 부분이며 이는 추후 데이타의 가져올때 재확인하여 제거 해야할지 확인해야할 필요가 있다.
					 * 
					 * ******************************************************************************************************************************* */
	//				if (cdmStringUtil.isNotEmpty(stCN_OPTION_DESC)) {
	//					String optionDescFirstSubString = stCN_OPTION_DESC.substring(0, 1);
	//					int optionDescLength = stCN_OPTION_DESC.length();
	//					String optionDescLastSubString = stCN_OPTION_DESC.substring(optionDescLength - 1);
	//
	//					if ("\"".equals(optionDescFirstSubString) && "\"".equals(optionDescLastSubString)) {
	//						stOPTION_DESC = stCN_OPTION_DESC.substring(1, optionDescLength - 1);
	//					} else {
	//						stOPTION_DESC = stCN_OPTION_DESC;
	//					}
	//				}
					
					
					
					/* ******************************************************************************************************************************* 
					 * stCN_OPTION4
					 * 엑셀에서 텍스트로 저장될경우 맨 앞 혹은 뒤에 특수 기호가 존재할경우 큰따음표로 감싸주는 형태로 텍스트파일에 저장이 된다.
					 * 큰따음표를 제거해주는 부분이며 이는 추후 데이타의 가져올때 재확인하여 제거 해야할지 확인해야할 필요가 있다.
					 * 
					 * ******************************************************************************************************************************* */
	//				if (cdmStringUtil.isNotEmpty(stCN_OPTION4)) {
	//					String stoption4FirstSubString = stCN_OPTION4.substring(0, 1);
	//					int stoption4Length = stCN_OPTION4.length();
	//					String stoption4LastSubString = stCN_OPTION4.substring(stoption4Length - 1);
	//
	//					if ("\"".equals(stoption4FirstSubString) && "\"".equals(stoption4LastSubString)) {
	//						stCN_OPTION4 = stCN_OPTION4.substring(1, stoption4Length - 1);
	//					} else {
	//						stCN_OPTION4 = stCN_OPTION4;
	//					}
	//				}
					
					String sTempUOM = "";
					sTempUOM= (String)tempUOMHMap.get(stTDM_UOM);
					sTempUOM = cdmCommonExcel.isVaildNullData(sTempUOM);
					
					/* ******************************************************************************************************************
					 * stPartInvestor 의경우 
					 * stCN_FOR_MAC ,stCN_FOR_MIL,stCN_FOR_MMT 의 정보가 checked 되어 있는지여부를 확인하여 하나의 String 값으로 만듬 
					 * 
					 * ****************************************************************************************************************   */
					if("Checked".equals(stCN_FOR_MAC)){
						stPartInvestor = "MAC";
					}
					if("Checked".equals(stCN_FOR_MIL)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MIL";
					}
					if("Checked".equals(stCN_FOR_MMT)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MMT";
					}
	
					
					/* ******************************************************************************************************************
					 * attribute[Estimated Weight]의 중량단위  
					 * g 이며 plm의 경우 kg 이므로 변환 
					 * ****************************************************************************************************************** */
					
					if("".equals(stCN_WEIGHT_UNIT)){
						stCN_WEIGHT_UNIT = "g";
						//kg 으로 단위 변환 필요 !!
						if(cdmStringUtil.isNotEmpty(stCN_ESTIMATED_WEIGHT)){
							Integer inESTIMATED_WEIGHT = Integer.parseInt(stCN_ESTIMATED_WEIGHT);
							
							if(inESTIMATED_WEIGHT > 0 || inESTIMATED_WEIGHT < 0 ){
								stESTIMATED_WEIGHT = String.valueOf(inESTIMATED_WEIGHT/1000);
							}
							
						}
					}else if(!"kg".equalsIgnoreCase(stCN_WEIGHT_UNIT) && !"".equals(stCN_ESTIMATED_WEIGHT)){
						//중량단위를 kg로 변환 !!
						Double doubleESTIMATED_WEIGHT = Double.parseDouble(stCN_ESTIMATED_WEIGHT);
						if("g".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT/1000);
							}
						}else if("lb".equals(stCN_WEIGHT_UNIT)){
							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(2204.62));
							}
						}else if("mg".equals(stCN_WEIGHT_UNIT)){
							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(1000000));
							}
						}else if("ton".equals(stCN_WEIGHT_UNIT)){
							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(1000));
							}
						}else if("N".equals(stCN_WEIGHT_UNIT)){
							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(0.102));  //힘의 단위로 변환한것임 문의할것 
							}
						}
					}
					/* *************************************************************************************
					 *   stCN_PHANTOM_ITEM 가 체크되어있으면 파트 타입으로 "Phantom Part"변경
					 *   stPhase 여부와 상관없이 반드시 Proto 로 변경된다. 
					 * *********************************************************************************** */
					if("PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPhase = S_ATTRIBUTE_PHASE_PROTO;
					}else{
						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
					}
					
					if( "Checked".equalsIgnoreCase(stCN_PHANTOM_ITEM) &&  "PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPartType = "cdmPhantomPart";
						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
					}
					
					
					
					  /* **********************************************************************************************************************
			         * type은 pre revision 정보가 있으며 그정보 의 object 가 phantom part 타입이면 생성할 object 타입도 phantom part 타입으로
			         * 변경  
			         *    
			         * ******************************************************************************************************************** */
//					if(cdmStringUtil.isNotEmpty(stPAR_REVISION)) {
//						 String stPreRevisionPhantomMql = "temp query bus '"+ TYPE_PHANTOMPART +"' '" +stCN_ID +"' '"+stPAR_REVISION+"'  select id  dump |";
//						 String stPreRevisionPhantomMqlResult =  MqlUtil.mqlCommand(context, stPreRevisionPhantomMql);
//						 StringList stListPreRevisionPhantomMqlResult = FrameworkUtil.split(stPreRevisionPhantomMqlResult, "|");
//						 
//						 if(stListPreRevisionPhantomMqlResult.size() > 2){
//							 stPartType = TYPE_PHANTOMPART;
//						 }
//					}
					
					
					
					/* ***************************************************************************************
				     *	데이타 중복확인 
					 * *************************************************************************************** */
					String duplicationPart = MqlUtil.mqlCommand(context, "temp query bus \""+stPartType+"\" \""+ stCN_ID+"\"  \""+ stREVISION +"\"  dump ");
					if(cdmStringUtil.isNotEmpty(duplicationPart)){
						String errorMessage = "ALREADY PART OBJECT ";
						throw new Exception(errorMessage);
					}
					
					/* *************************************************************************************
					 * stITEM_TYPE1 은  cdmPartApprovalType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					
						
					if("자작".equals(stITEM_TYPE1)){
						stITEM_TYPE1 = "inSourcing";
					}else if("외주".equals(stITEM_TYPE1)){
						stITEM_TYPE1 = "outSourcing";
					}else{
						stITEM_TYPE1 = "";
					}
					
					
					
					/* *************************************************************************************
					 * stITEM_TYPE 은  cdmPartType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					stITEM_TYPE = "";
					for (int attrPartTypeNum = 0; attrPartTypeNum < attrPartTypeKOList.size(); attrPartTypeNum++) {
						String temPattrPartTypeKO = (String) attrPartTypeKOList.get(attrPartTypeNum);
						if (stCN_ITEM_TYPE.equals(temPattrPartTypeKO)) {
							stITEM_TYPE = (String) attrPartTypeList.get(attrPartTypeNum);
							break;
						}
					}
//					if(stCN_ITEM_TYPE == null || "".equals(stCN_ITEM_TYPE) ){
//						stITEM_TYPE = "";
//					} else {
	
//						AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
//						attrPartType.open(context);
//						StringList attrPartTypeList = attrPartType.getChoices(context);
//	
//						StringList attrPartTypeKOList = new StringList();
//						attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
	
						
//					}
	
					
					/* *************************************************************************************
					 * SERIES_ITEM 값이 Checked 이면 true unChecked 이면 false 
					 * *********************************************************************************** */
					if("Checked".equalsIgnoreCase(stCN_SERIES_ITEM)){
						stSERIES_ITEM = "true"; 
					}else{
						stSERIES_ITEM = "false";
					}
					
					/*stCN_SURFACE_TREATMENT 은 사용되지않아 "" 처리한다. */
					String stSURFACE_TREATMENT = ""; 
					
					/*stCN_IS_CASTING*/
					String stIS_CASTING = "";
					if(!"0".equals(stCN_IS_CASTING)){
						stIS_CASTING = "yes";
					}else{
						stIS_CASTING = "no";
					}
					
					
					/*stCN_FOR_DRAWING_FINISH*/
					String stCFOR_DRAWING_FINISH = "";
					if("0".equals(stCN_FOR_DRAWING_FINISH)){
						stCFOR_DRAWING_FINISH = "unChecked";
					}else{
						stCFOR_DRAWING_FINISH = "Checked";
					}
					
					/*stCN_FOR_DRAWING_SIZE*/
					String stDRAWING_SIZE = "";
					if("0".equals(stCN_FOR_DRAWING_SIZE)){
						stDRAWING_SIZE = "unChecked";
					}else{
						stDRAWING_SIZE = "Checked";
					}
					
//					stTDM_UOM = new String(stTDM_UOM.getBytes("utf-8"), "euc-kr");
//					stPhaseM = new String(stPhaseM.getBytes("euc-kr"), "utf-8");
					HashMap attributes = new HashMap();
					if(UIUtil.isNotNullAndNotEmpty(stPhaseM)){
						attributes.put("cdmPartPhaseM", 		 	  stPhaseM		                   );
					}
//					System.out.println("cdmPartUOM :" +stTDM_UOM);
			        attributes.put("cdmPartNo",          	      stCN_ID 			               );
			        attributes.put("cdmPartVehicle", 	 	      stCN_VEHICLE_DESC		           );
			        attributes.put("cdmPartName", 		 	      stTDM_DESCRIPTION	               );
			        attributes.put("cdmPartProject", 	 	      stCN_PROJECT		               );
			        attributes.put("cdmPartApprovalType", 	      stITEM_TYPE1	                   );
			        attributes.put("cdmPartType", 		          stITEM_TYPE	                   );
			        attributes.put("cdmPartGlobal", 			  stGLOBAL_LOCAL                   );
			        attributes.put("cdmPartDrawingNo", 			  stCN_DRAWING_NO                  );
//			        attributes.put("cdmPartUOM",     		      stTDM_UOM                        );
			        attributes.put("cdmPartUOM",     		      sTempUOM                        );
//			        데이타가 깨진것이 있어 추후 cdmPartUOM 값을 변경해야함 12/06/16 12:19:00 이후 마이그레이션 대상으로
//			        attributes.put("cdmPartUOM_TempM",     		      stTDM_UOM                        );
			        attributes.put("cdmPartECONumber", 			  stCN_ECO_NUMBER                  );
			        attributes.put("cdmPartItemType", 			  stCN_ITEM_TYPE2                  );
			        attributes.put("cdmPartOEMItemNumber", 		  stCN_OEM_PART_NUMBER             );
			        attributes.put("cdmPartProductType", 		  stCN_PRODUCT_DIV                 );
			        attributes.put("cdmPartERPInterface", 		  stFOR_DRAWING_REMARK             );
			        attributes.put("cdmPartSurface", 			  stCN_SURFACE_AREA                );
			        attributes.put("cdmPartEstimatedWeight", 	  stESTIMATED_WEIGHT               );
			        attributes.put("cdmPartMaterial", 			  stCN_ITEM_MATERIAL               );
			        attributes.put("cdmPartRealWeight", 		  stCN_REAL_WEIGHT                 );
			        attributes.put("cdmPartSize", 				  stCN_SIZE                        );
			        attributes.put("cdmPartCADWeight", 			  stPartCADWeight                  );
			        attributes.put("cdmPartSurfaceTreatment", 	  stSURFACE_TREATMENT              );
			        attributes.put("cdmPartIsCasting", 			  stIS_CASTING                     );
			        attributes.put("cdmPartOption1", 			  stCN_OPTION1                     );
			        attributes.put("cdmPartOption2", 			  stCN_OPTION2                     );
			        attributes.put("cdmPartOption3", 			  stCN_OPTION3                     );
			        attributes.put("cdmPartOption4", 			  stCN_OPTION4                     );
			        attributes.put("cdmPartOption5", 			  stCN_OPTION5                     );
			        attributes.put("cdmPartOption6", 		   	  stCN_OPTION6                     );
			        attributes.put("cdmPartOptionETC",         	  stOPTION_ETC               	   );
			        attributes.put("cdmPartOptionDescription", 	  stOPTION_DESC            		   );
			        attributes.put("cdmPartPublishingTarget",     stCN_COST                        );
			        attributes.put("cdmPartInvestor",          	  stPartInvestor                   );
			        attributes.put("cdmPartProjectType",          stCN_PRODUCT_GROUP               ); // 
//			        attributes.put("cdmPartProductDivision",      stCN_PRODUCT_GROUP               ); //?? 확인 작업이 필요 
					
			        /*migration을 작업을 위해 attribute 추가 start */
			        attributes.put("cdmPartItemOtionItemM",        stCLS_NAME                      );
			        attributes.put("cdmPartPreviousRevisionM",     stPAR_REVISION                  );
			        attributes.put("cdmPartCheckPhantomPartM",     stCN_PHANTOM_ITEM   	           );
			        attributes.put("cdmPartECNameM",               stEC_NAME    	               );
			        attributes.put("cdmPartSeriesItemM",           stSERIES_ITEM                   );
			        attributes.put("cdmPartMCAOrgM",               stCN_ORG      	               );
			        attributes.put("cdmPartMCABOMManagementM",     stCN_MCA_INOUT        	       );
			        attributes.put("cdmPartMCAPartTypeM",          stCN_MCA_PART_TYPE_REF          );
			        attributes.put("cdmPartOption7",          	   stCN_OPTION7                    );
			        attributes.put("cdmPartCountryM",          	   stCN_COUNTRY                    );
			        attributes.put("cdmPartDrawingFinishM",        stCFOR_DRAWING_FINISH           );
			        attributes.put("cdmPartDrawingSizeM",          stDRAWING_SIZE                  );
			        attributes.put("cdmPartApplyPartListM",        stCN_APPLY_PARTLIST             );
			        attributes.put("cdmPartSubIdM",                stCN_SUB_ID                     );
			        attributes.put("cdmPartMCPOrgM",          	   stCN_OVERSEAS_ORG6              );
			        attributes.put("cdmPartMCPPartTypeM",          stCN_OVERSEAS_ORG6_PART_TYPE    );
			        attributes.put("cdmPartMCPBOMManagementM",     stCN_OVERSEAS_ORG6_INOUT 	   );  
			        attributes.put("cdmPartCreationDateM",        stCREATION_DATE     	           );  
			        attributes.put("cdmPartCreationUserIdM",      stUSER_OBJECT_ID  	           );  
			        attributes.put("cdmPartModUserIdM",           stUSER_ID_MOD  	               );  
			        attributes.put("cdmPartModificationDateM",    stMODIFICATION_DATE  	           );  
			        attributes.put("cdmPartComplexBodyForRealWeightM",  stCN_COMPLEX_BODY          );
			        attributes.put("cdmCheckMigration",           "Y"					  	       );
			        attributes.put("cdmPartPhase",           	   stPhase			  	       	   );
			        //add attribute 11/17/2016 start 
			        attributes.put("cdmPartApplyPartList",           "true"				  	       );
			        attributes.put("cdmPartApplySizeList",           "false"			  	       );
			        attributes.put("cdmPartApplySurfaceTreatmentList", "false"	  				   );
			        //add attribute 11/17/2016 end 
			        
			        /*migration을 작업을 위해 attribute 추가 end  */
			        
			      
			        /* **********************************************************************************************************************
			         * part 데이타 생성 및 데이타 
			         * 트리거 오프한 상태로 진행되며 트리거에서 제공되는 attribute[originator]속성 및 interface 추가 설정 필터 정보 와 
			         * rev 정보 part master 생성 및 연결 및 속성(attribute[Originator]속성 추가 
			         * 에러 발생시 정지 및 데이타 정보 검색 
			         * ******************************************************************************************************************* */
			        
			        DomainObject partObj = new DomainObject();
			        boolean bCommit = false;
//					partObj.createObject(context, stPartType, stCN_ID, stREVISION, cdmConstantsUtil.POLICY_CDM_PART_POLICY, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        ContextUtil.startTransaction(context, true);
			        bCommit = true;
			        boolean bNewPartCheck = false;
			        boolean reviseCheck = false;
			        BusinessObject previousPart  = null;
			        
			        previousPart  = new BusinessObject(TYPE_CDMMECHANICALPART,stCN_ID,stPAR_REVISION,"eService Production");
			        if(!previousPart.exists(context)){
			        	previousPart  = new BusinessObject("cdmPhantomPart",stCN_ID,stPAR_REVISION,"eService Production");
			        }
//			        if("cdmPhantomPart".equals(stPartType)){
//	        			previousPart  = new BusinessObject(TYPE_CDMMECHANICALPART,stCN_ID,stPAR_REVISION,"eService Production");
//	        			
//	        		}else{
//	        			previousPart  = new BusinessObject("cdmPhantomPart",stCN_ID,stPAR_REVISION,"eService Production");
//	        			
//	        		}
			        boolean checkPartPrevious = false;
			        boolean existPreviousPart = previousPart.exists(context);
			        
			        if(  stCN_ID.equals(strPreviousPartNo) || existPreviousPart) {
			        	if(stCN_ID.equals(strPreviousPartNo) && !existPreviousPart){
			        		previousPart  = new BusinessObject(strPreviousPartType,stCN_ID,strPreviousPartRevision,"eService Production");
			        	}
			        	if(previousPart.exists(context)){
			        		checkPartPrevious = true;
			        	}
			        }
			        
//			        if(  stCN_ID.equals(strPreviousPartNo) || existPreviousPart) {
//			        	if(stCN_ID.equals(strPreviousPartNo) && !existPreviousPart){
//			        		previousPart  = new BusinessObject(strPreviousPartType,stCN_ID,strPreviousPartRevision,"eService Production");
//			        	}
			        if(checkPartPrevious){
//			        	BusinessObject previousPart  = new BusinessObject(stPartType,stCN_ID,strPreviousPartRevision,"eService Production");
//			        	BusinessObject previousPart  = new BusinessObject(strPreviousPartType,stCN_ID,strPreviousPartRevision,"eService Production");
//			        	BusinessObject previousPart  = new BusinessObject(stPartType,stCN_ID,strPreviousPartRevision,"eService Production");
//			        	boolean checkPrevious = previousPart.exists(context);
//			        	if(!checkPrevious){
//			        		if("cdmPhantomPart".equals(stPartType)){
//			        			previousPart  = new BusinessObject(TYPE_CDMMECHANICALPART,stCN_ID,strPreviousPartRevision,"eService Production");
//			        			
//			        		}else{
//			        			previousPart  = new BusinessObject("cdmPhantomPart",stCN_ID,strPreviousPartRevision,"eService Production");
//			        			
//			        		}
//			        	}
			        	BusinessObject currentPart = previousPart.revise(context, stREVISION, "eService Production");
			        	
			        	partObj.setId(currentPart.getObjectId(context));

			        	
			        	
			        	StringBuffer sbRelType = new StringBuffer();
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION);
			        	 
			        	StringList relList = new StringList();
			        	relList.add("id[connection]");
			        	
			        	MapList mlCodes = partObj.getRelatedObjects(context,
			        			sbRelType.toString(), // relationship pattern
			                    "*", // object pattern
			                    null, // object selects
			                    relList, // relationship selects
			                    true, // to direction
			                    false, // from direction
			                    (short) 1, // recursion level
			                    "", // object where clause
			                    null); // relationship where clause
			        	
			        	for (int jj = 0; jj < mlCodes.size(); jj++) {
							Map mapCode = (Map)mlCodes.get(jj);
							String relid = (String)mapCode.get("id[connection]");
							
							MqlUtil.mqlCommand(context, "del connection "+relid);
							
						}
			        } else {
			        	partObj.createObject(context, stPartType, stCN_ID, stREVISION, "cdmPartPolicy", cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        	bNewPartCheck = true;
			        }
			        strPreviousPartNo = stCN_ID;
					strPreviousPartRevision = stREVISION;
					strPreviousPartType = stPartType;

					
					
					if ("In Approval".equals(stSTATE)) {
						stSTATE = "Review";
						
					} else if ("Inactive".equals(stSTATE)) {
						stSTATE = "Obsolete";
						
					}else if ("Released".equals(stSTATE)) {
						stSTATE = "Release";
							
						
					}else if ("In Work".equals(stSTATE)) {
						stSTATE = "Preliminary";
					}
					
					partObj.setState(context, stSTATE);
					
//					partObj.setAttributeValues(context, attributes);
					
//					System.out.println("stTDM_UOM 0"+new String(stTDM_UOM));
//					System.out.println("stTDM_UOM 1"+new String(stTDM_UOM.getBytes("utf-8"), "euc-kr"));
////					System.out.println("stTDM_UOM "+new String(stTDM_UOM.getBytes("euc-kr"), "utf-8"));
//					partObj.setAttributeValue(context, "cdmPartUOM", new String(stTDM_UOM.getBytes("euc-kr"), "utf-8"));
						
					String partObjectId = partObj.getId(context);

					if(boolPerson){
						partObj.setOwner(context, stTDM_ORG_USER_ID); 
					}
					
					
					
					
//					StringList tempProjectArray = FrameworkUtil.split(stCN_PROJECT,"-");
//					String sAccessCustomer = stCN_PROJECT_CUST.trim();
//					
//					boolean checkOwner = false;
//					boolean checkOrg = false;
//					boolean checkProject = false;
//					String sOwner = "";
//					String findOrg = "list role $1 select $2 dump;";
//					if (cdmStringUtil.isNotEmpty(stAceesOrg) && cdmStringUtil.isNotEmpty(stAccessProductGroup)) {
//						String str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { stAceesOrg, "isanorg" });
//						if ("TRUE".equalsIgnoreCase(str2)) {
//							findOrg = "list role $1 select $2 dump;";
//							str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { stAccessProductGroup, "isaproject" });
//							if ("TRUE".equalsIgnoreCase(str2)) {
//								checkOrg = true;
//								checkProject = true;
//							}
//						}
//					}
					
					
					
//					if(checkOrg && checkProject){
//						MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", partObjectId, stAccessProductGroup, stAceesOrg);
//						sbErrorMessage.append("○").append("\t");
//					
//					}else{
//						sbErrorMessage.append(stAceesOrg).append(",").append(stAccessProductGroup).append("\t");
//					}
//					partObj.setOwnership(context, checkOwner, checkOrg, checkProject, sOwner, stAceesOrg, stAccessProductGroup);
//					 
					
//					 String str1 = "print role $1 select $2 dump;";                                                                                                 
//					 String str2 = MqlUtil.mqlCommand(paramContext, str1, true, new String[] { paramString2, "isanorg" });                                          
//					 if ("TRUE".equalsIgnoreCase(str2))                                                                                                             
//					 {                                                                                                                                              
//					   str1 = "print role $1 select $2 dump;";                                                                                                      
//					   str2 = MqlUtil.mqlCommand(paramContext, str1, true, new String[] { paramString1, "isaproject" });                                            
//					   if ("TRUE".equalsIgnoreCase(str2))                                                                                                           
//					   {                                                                                                                                            
//					     str1 = "mod bus $1 project $2 organization $3";                                                                                            
//					     MqlUtil.mqlCommand(paramContext, str1, true, new String[] { getObjectId(paramContext), paramString1, paramString2 }); break label142:      
//					   }                                                                                                                                            
					
					//test 11/18/16 end
					
					
					/*
					 * *********************************************************
					 *  create 시 발생하는 trigger에서 발생하는 interface 생성 start
					 * *********************************************************
					 */
//					boolean isMEP = false;
//	
//					if (partObjectId != null && !"".equals(partObjectId)) {
//						String sExternalPartData = PropertyUtil.getSchemaProperty(context, DomainSymbolicConstants.SYMBOLIC_interface_ExternalPartData);
//						Part part = new Part(partObjectId);
//						String sPolicyClassification = part.getInfo(context, "policy.property[PolicyClassification].value");
//
//						// enable MEP by default
//						if (sPolicyClassification != null && "Equivalent".equals(sPolicyClassification)) {
//							isMEP = true;
//						}
//						if (isMEP) {
//							MqlUtil.mqlCommand(context, "modify bus $1 add interface $2;", partObjectId, sExternalPartData);
//						}
//					}
		
						/*
						 * *********************************************************
						 * attribute[attribute_Originator]
						 * 의 정보를stTDM_ORG_USER_ID 정보를 입력.
						 * *********************************************************
						 * 
						 */
						partObj.setAttributeValue(context, DomainConstants.ATTRIBUTE_ORIGINATOR, stTDM_ORG_USER_ID);
		
						/* part Master 생성 start */
						createPartMaster(context, partObjectId, stTDM_ORG_USER_ID,boolPerson);
						/* part Master 생성 end */
		
						/* create 시 발생하는 trigger에서 사용된 정보 interface 생성 end */
		
						/*
						 * *********************************************************
						 * 
						 *  EBOM 정보로 연결된 Part 을 생성할시 relationship 연결을 제외된다.
						 * 또한 relationship 연결의 경우 공통코드 데이타가 PLM에 스마트팀 정보가 다 있다고 가정하여
						 * 진행 공통코드를 검색하여 데이타가 없을시 오류 처리 . 오류가 발생하면 Exception 발생.
						 * *********************************************************
						 */
		
						StringBuffer sbVehicleId = new StringBuffer("");
						StringBuffer sbProjectId = new StringBuffer("");
						StringBuffer sbProjectTypeId = new StringBuffer("");
						StringBuffer sbProductTypeId = new StringBuffer("");
		
						StringBuffer sbOrg1Id = new StringBuffer();
						StringBuffer sbOrg2Id = new StringBuffer();
						StringBuffer sbOrg3Id = new StringBuffer();
		
						StringBuffer sbOption1Id = new StringBuffer("");
						StringBuffer sbOption2Id = new StringBuffer("");
						StringBuffer sbOption3Id = new StringBuffer("");
						StringBuffer sbOption4Id = new StringBuffer("");
						StringBuffer sbOption5Id = new StringBuffer("");
						StringBuffer sbOption6Id = new StringBuffer("");
		
						StringBuffer sbECONumberId = new StringBuffer("");
						StringBuffer sbDrawingNoId = new StringBuffer("");
						StringList sListPFs = new StringList();
						/* ************************************************
						 * stCN_VEHICLE_DESC 정보는 두개 이상 있을수 있으며 구분자 , 
						 * stVehicle_Cust 정보의 경우 두개이상 데이타 존재 있을수 있다 구분자 ;
						 * ************************************************
						 * */
						StringList stListCN_VEHICLE_DESC = new StringList();
						StringList stListVehicle_Cust = new StringList();
	
						stListCN_VEHICLE_DESC = FrameworkUtil.split(stCN_VEHICLE_DESC, ",");
	
						boolean checkErrorVehicleCust = false;
						if (stVehicle_Cust.startsWith("ORA-01422") || "-2147483647".equals(stVehicle_Cust)) {
							checkErrorVehicleCust = true;
						} else {
							stListVehicle_Cust = FrameworkUtil.split(stVehicle_Cust, ";");
						}
						int vehicleCustInt = 0;
						int vehicleDesInt = 0;
						vehicleCustInt = stListVehicle_Cust.size();
						vehicleDesInt = stListCN_VEHICLE_DESC.size();
						if (cdmStringUtil.isNotEmpty(stCN_VEHICLE_DESC) &&  !checkErrorVehicleCust) {
							StringList sListVehicleIds = new StringList();
						if (vehicleCustInt == vehicleDesInt) {
							for (int stListVehicleNum = 0; stListVehicleNum < stListCN_VEHICLE_DESC.size(); stListVehicleNum++) {

								String stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);

								String stTempVehicleCust = (String) stListVehicle_Cust.get(stListVehicleNum);

								String searchVehicle = stTempVehicle + "_" + stTempVehicle + "_" + stTempVehicleCust;

								String tempVehicleId = (String) vehicleCommonCodeMap.get(searchVehicle);
								tempVehicleId = (tempVehicleId == null || "null".equals(tempVehicleId)) ? "" : tempVehicleId.trim();
								if (StringUtils.isNotEmpty(tempVehicleId) && !sListVehicleIds.contains(tempVehicleId)) {
									sListVehicleIds.add(tempVehicleId);
									sbVehicleId.append(tempVehicleId);
									sbVehicleId.append(",");
								}

							}
						}
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_VEHICLE_DESC) && cdmStringUtil.isEmpty(sbVehicleId.toString()) && !checkErrorVehicleCust){
//							sbErrorMessage.append("No Vehicle information exists in the database.");
							sbErrorMessage.append("○").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Project */
						if (cdmStringUtil.isNotEmpty(stCN_Project_Id)) {
							
//							String projectIdMql = " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectCode] =='" + stCN_PROJECT + "' &&  attribute[cdmProjectGroupCustomerAttribute] =='" + stCN_PROJECT_CUST + "' && attribute[cdmProjectGroupProductTypeAttribute] == '" + stCN_PRODUCT_DIV + "' \" select id dump |";
//							String projectIdMql = " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectObjectIdM] =='" + stCN_Project_Id +"' select id dump |";
//							String projectIdMqlResult = MqlUtil.mqlCommand(context, projectIdMql);
//							StringList stListProjectMqlResult = FrameworkUtil.split(projectIdMqlResult, "|");
							String stTempProjectId = "";
							stTempProjectId = (String)projectMap.get(stCN_Project_Id);
							stTempProjectId = (stTempProjectId == null || "null".equals(stTempProjectId)) ? "" : stTempProjectId.trim();
							sbProjectId.append(stTempProjectId);
							
						}
						
						if(cdmStringUtil.isEmpty(sbProjectId.toString())){
//							sbErrorMessage.append("No Project information exists in the database.");
							sbErrorMessage.append("○").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						// Product Group
						if (cdmStringUtil.isNotEmpty(stCN_PRODUCT_GROUP)) {
							String stTempProductGroupId = (String)productGroupMap.get(stCN_PRODUCT_GROUP+"_"+stCN_PRODUCT_DIV);
							stTempProductGroupId = (stTempProductGroupId == null || "null".equals(stTempProductGroupId)) ? "" : stTempProductGroupId.trim();
							sbProjectTypeId.append(stTempProductGroupId);
	
						}
	
						if(cdmStringUtil.isNotEmpty(stCN_PRODUCT_GROUP) && cdmStringUtil.isEmpty(sbProjectTypeId.toString())){
//							sbErrorMessage.append("No Product Group information exists in the database.");
							sbErrorMessage.append("○").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Product Div */
						if ( cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempProductDivId = (String)productDivMap.get(stCN_PRODUCT_DIV);
							stTempProductDivId = (stTempProductDivId == null || "null".equals(stTempProductDivId)) ? "" : stTempProductDivId.trim();
							sbProductTypeId.append(stTempProductDivId);
	
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV) && cdmStringUtil.isEmpty(sbProductTypeId.toString())){
//							sbErrorMessage.append("No Product Div information exists in the database.");
							sbErrorMessage.append("○").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
	
						/* Option1 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION1)) {
							
							String stTempOption1 = "";
							stTempOption1 = (String)option1Map.get(stCN_OPTION1+"_"+stCN_PRODUCT_DIV);
							stTempOption1 = (stTempOption1 == null || "null".equals(stTempOption1)) ? "" : stTempOption1.trim();
							sbOption1Id.append(stTempOption1);
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_OPTION1) && cdmStringUtil.isEmpty(sbOption1Id.toString())){
//							sbErrorMessage.append("No OPTION1 information exists in the database.");
							sbErrorMessage.append("○").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Option2 */
//						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeOption2Id) && cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
						if (cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption2 = "";
							stTempOption2 = (String)option2Map.get(stCN_OPTION2+"_"+stCN_PRODUCT_DIV);
							stTempOption2 = (stTempOption2 == null || "null".equals(stTempOption2)) ? "" : stTempOption2.trim();
							sbOption2Id.append(stTempOption2);
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isEmpty(sbOption2Id.toString())){
//							sbErrorMessage.append("No OPTION2 information exists in the database.");
							sbErrorMessage.append("○").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
	
						/* Option3 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION3) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption3 = "";
							stTempOption3 = (String)option3Map.get(stCN_OPTION3+"_"+stCN_PRODUCT_DIV);
							stTempOption3 = (stTempOption3 == null || "null".equals(stTempOption3)) ? "" : stTempOption3.trim();
							sbOption3Id.append(stTempOption3);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION3) && cdmStringUtil.isEmpty(sbOption3Id.toString())){
//							sbErrorMessage.append("No OPTION3 information exists in the database.");
							sbErrorMessage.append("○").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option4 */
						if ( cdmStringUtil.isNotEmpty(stCN_OPTION4) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption4 = "";
							stTempOption4 = (String)option4Map.get(stCN_OPTION4+"_"+stCN_PRODUCT_DIV);
							stTempOption4 = (stTempOption4 == null || "null".equals(stTempOption4)) ? "" : stTempOption4.trim();
							sbOption4Id.append(stTempOption4);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION4) && cdmStringUtil.isEmpty(sbOption4Id.toString())){
//							sbErrorMessage.append("No OPTION4 information exists in the database.");
							sbErrorMessage.append("○").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option5 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION5) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							
							String stTempOption5 = "";
							stTempOption5 = (String)option5Map.get(stCN_OPTION5+"_"+stCN_PRODUCT_DIV);
							stTempOption5 = (stTempOption5 == null || "null".equals(stTempOption5)) ? "" : stTempOption5.trim();
							sbOption5Id.append(stTempOption5);
	
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION5) && cdmStringUtil.isEmpty(sbOption5Id.toString())){
//							sbErrorMessage.append("No OPTION5 information exists in the database.");
							sbErrorMessage.append("○").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option6 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION6) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption6 = "";
							stTempOption6 = (String)option6Map.get(stCN_OPTION6+"_"+stCN_PRODUCT_DIV);
							stTempOption6 = (stTempOption6 == null || "null".equals(stTempOption6)) ? "" : stTempOption6.trim();
							sbOption6Id.append(stTempOption6);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION6) && cdmStringUtil.isEmpty(sbOption6Id.toString())){
//							sbErrorMessage.append("No OPTION6 information exists in the database.");
							sbErrorMessage.append("○").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* sbECONumberId */
					if (cdmStringUtil.isNotEmpty(stCN_ECO_NUMBER)) {
						StringBuffer sbfECType = new StringBuffer();
						sbfECType.append("cdmECO");
						sbfECType.append(",");
						sbfECType.append("cdmEAR");
						sbfECType.append(",");
						sbfECType.append("cdmDCR");
						sbfECType.append(",");
						sbfECType.append("cdmPEO");
//						sbfECType.append(",");
//						sbfECType.append("cdmTEO");
						
						
						String stTempECExist = "temp query bus \"" + sbfECType.toString() + "\" \""+stCN_ECO_NUMBER +"\"  *  select id dump |";
						String stTempECExistMql = MqlUtil.mqlCommand(context, stTempECExist);
						StringList sListTempECExistMql = FrameworkUtil.split(stTempECExistMql, "|");
						// test start start
						if (sListTempECExistMql.size() > 2) {
							sbECONumberId.append(sListTempECExistMql.get(3));
							sbErrorMessage.append("X").append("\t");
						} else {
//							sbErrorMessage.append( "EC information does not exist.");
							sbErrorMessage.append("○").append("\t");
						}
					}
					
					//Part Family
					if (stCN_ID.length() > 6) {

						String pfCodeName = stCN_ID.substring(0, 5);
						String partFamilys = (String)partFamilyMap.get(pfCodeName);
						partFamilys = (partFamilys == null || "null".equals(partFamilys)) ? "" : partFamilys.trim();
						sListPFs = FrameworkUtil.split(partFamilys, ",");
						if(cdmStringUtil.isEmpty(partFamilys) ){
							if(bNewPartCheck){
								sbErrorMessage.append("○").append("\t");
							}else{
								sbErrorMessage.append("X").append("\t");
							}
						}else{
							if(bNewPartCheck){
								sbErrorMessage.append("X").append("\t");
							}else{
								sbErrorMessage.append("○").append("\t");
							}
						}
					}else{
						sbErrorMessage.append("○").append("\t");
					}
					
//						stCN_ECO_NUMBER
						/* sbDrawingNoId */
					
					HashMap paramHM = new HashMap();
					paramHM.put("partObjectId", partObjectId);
					paramHM.put("VehicleObjectId", sbVehicleId.toString());
					paramHM.put("ProjectObjectId", sbProjectId.toString());
					paramHM.put("ProjectTypeObjectId", sbProjectTypeId.toString());
					paramHM.put("ProductTypeObjectId", sbProductTypeId.toString());
						
					String[] objectIdArray = sbVehicleId.toString().split(",");
					for(int i=0; i<objectIdArray.length; i++){
	    				String strVehicleId = objectIdArray[i];
	    				
	    				if(StringUtils.isEmpty(strVehicleId.trim()))
	    					continue;
	    					
	    					DomainRelationship.connect(context, new DomainObject(strVehicleId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
	    				}

//						paramHM.put("Org1ObjectId", sbOrg1Id.toString());
//						paramHM.put("Org2ObjectId", sbOrg2Id.toString());
//						paramHM.put("Org3ObjectId", sbOrg3Id.toString());
//						paramHM.put("Option1ObjectId", sbOption1Id.toString());
//						paramHM.put("Option2ObjectId", sbOption2Id.toString());
//						paramHM.put("Option3ObjectId", sbOption3Id.toString());
//						paramHM.put("Option4ObjectId", sbOption4Id.toString());
//						paramHM.put("Option5ObjectId", sbOption5Id.toString());
//						paramHM.put("Option6ObjectId", sbOption6Id.toString());
//						
						
						if(UIUtil.isNotNullAndNotEmpty(sbProjectId.toString())){
			    			DomainRelationship.connect(context, new DomainObject(sbProjectId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT, partObj);
			    		}
						
						if(UIUtil.isNotNullAndNotEmpty(sbProjectTypeId.toString())){
							DomainRelationship.connect(context, new DomainObject(sbProjectTypeId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE, partObj);
			        	}
						
						
						if(UIUtil.isNotNullAndNotEmpty(sbProductTypeId.toString())){
			    			DomainRelationship.connect(context, new DomainObject(sbProductTypeId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE, partObj);
			        	}
						
						if(UIUtil.isNotNullAndNotEmpty(sbOption1Id.toString())){
							DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption1Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
							x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option1");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption2Id.toString())){
			    		     
			    		    DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption2Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option2");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption3Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption3Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option3");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption4Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption4Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option4");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption5Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption5Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option5");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption6Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption6Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option6");
			        	}
			        	
						paramHM.put("ECONumberOid", sbECONumberId.toString());
						if(UIUtil.isNotNullAndNotEmpty(sbECONumberId.toString())){
		        			DomainRelationship.connect(context, new DomainObject(sbECONumberId.toString()), DomainConstants.RELATIONSHIP_AFFECTED_ITEM, partObj);
			        		
			        	}
						
					if (bNewPartCheck) {
						for (Iterator iterPF = sListPFs.iterator(); iterPF.hasNext();) {
							String sPF = (String) iterPF.next();
							PartFamily partFamily = (PartFamily) DomainObject.newInstance(context, DomainConstants.TYPE_PART_FAMILY, DomainConstants.ENGINEERING);
							partFamily.setId(sPF);

							MQLCommand mqlCommand = new MQLCommand();
							mqlCommand.open(context);
							mqlCommand.executeCommand(context, "set transaction savepoint $1", "PartFamily");
							partFamily.addPart(context, partObjectId);
							
							//trigger 필요
							DomainObject doFromObject = new DomainObject(sPF);
				            DomainObject doToObject = new DomainObject(partObjectId);

				            String sFromObjectType = doFromObject.getInfo(context, DomainConstants.SELECT_TYPE);
				            // Get Created Part ObjectId from Environment Variables
				            String partFamilyReference =  PropertyUtil.getSchemaProperty(context,"interface_PartFamilyReference");

		                    if(sFromObjectType.equals(DomainConstants.TYPE_PART_FAMILY) && doToObject.isKindOf(context, DomainConstants.TYPE_PART)) {
								if(!(MqlUtil.mqlCommand(context,"print bus $1 select $2 dump;",partObjectId,"interface["+partFamilyReference+"]")).equals("TRUE")){
			                     MqlUtil.mqlCommand(context, "modify bus $1 add interface $2;",true,partObjectId,partFamilyReference);
								}
		                    }
							//
						}
						checkAddPart = true;
					}else{
						checkAddPart = true;
					}
//						paramHM.put("DrawingNo_Oid", sbDrawingNoId.toString());
//						Boolean ErrorCheck = (Boolean) JPO.invoke(context, "cdmPartLibrary", null, "checkPartObjectRelationShip", JPO.packArgs(paramHM), Boolean.class);
						//(Context context, String partObjectId, String vehicleObjectId,
//			    		String projectObjectId, String projectTypeObjectId, String productTypeObjectId, String org1ObjectId, 
//						String org2ObjectId, String org3ObjectId, String option1ObjectId, String option2ObjectId,
//						String option3ObjectId, String option4ObjectId, String option5ObjectId, String option6ObjectId, String ecId, String drawingId) 
						
//						partObjectRelationShip(context, partObjectId, VehicleObjectId, ProjectObjectId, ProjectTypeObjectId, ProductTypeObjectId, Org1ObjectId, Org2ObjectId, Org3ObjectId, Option1ObjectId, Option2ObjectId, Option3ObjectId, Option4ObjectId, Option5ObjectId, Option6ObjectId, ECONumberOid, DrawingNo_Oid);
//			    		DomainObject partObj = new DomainObject(partObjectId);
//			    		if(UIUtil.isNotNullAndNotEmpty(vehicleObjectId)){
//			    			StringList relVehicleIdList = partObj.getInfoList(context, "to["+cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE+"].id");
//			    			if(relVehicleIdList.size() > 0 && ! "".equals(relVehicleIdList)){
//			    				for(int k=0; k<relVehicleIdList.size(); k++){
//			    					DomainRelationship.disconnect(context, relVehicleIdList.get(k).toString());
//			    				}
//			    			}
//			    		    if(vehicleObjectId.contains(",")){
//			    				String[] objectIdArray = vehicleObjectId.split(",");
//			    				StringBuffer strBuffer = new StringBuffer();
//			    				for(int i=0; i<objectIdArray.length; i++){
//			    					String strVehicleId = objectIdArray[i];
//			    					DomainRelationship.connect(context, new DomainObject(strVehicleId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
//			    				}
//			    		    }else{
//			    			    if(!"".equals(vehicleObjectId)){
//			    					DomainRelationship.connect(context, new DomainObject(vehicleObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
//			    				}
//			    		    }
//			    		}
			    		
			    	
						
						//
					
						/*
						 * *********************************************************
						 * promote 및 revise "In Approval" 상태를
						 * 가진 part 정보일경우 enovia에서는 In Review 상태로 ... "Inactive" 상태를
						 * 가진 part 정보일경우 enovia에서는 Obsolete 상태로 변경. 과거 revision을 가진
						 * object 은 무조건 Released 상태를 가진다. 현재 eo 데이타는 존재하지않아 연결정보를
						 * 사용할 수 없다. 현재 상태로는 eo 데이타가 없고 drawing 데이타가 연결이 되지않아 추후 연결
						 * 필요
						 * 
						 * 도면 있을 때 에는 revise 될때 같이 처리해야한다. 참조 cdmPartLibray
						 * revise... 소스는 빼논 상태
						 * *********************************************************
						 * 
						 */
					bCommit = true;
					ContextUtil.commitTransaction(context);	
					
					try {
						MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", partObjectId, stAccessProductGroup, stAceesOrg);
						sbErrorMessage.append("X").append("\t").append("X").append("\t");
					} catch (Exception e) {
						sbErrorMessage.append(stAccessProductGroup).append("\t").append(stAceesOrg).append("\t");
					}
					
					
					if(bCommit){
						try{
						partObj.setAttributeValues(context, attributes);
						sbErrorMessage.append("X").append("\t");
						}catch(Exception e4){
							sbErrorMessage.append("○").append("\t");
						}
					}
					
					MqlUtil.mqlCommand(context, "trigger on");
					checkTriggerOff = false;	
						
					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
//						writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());	
						writeSuccessToFile(subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+sbErrorMessage.toString());	
					}else{
//							writeSuccessToFile("LineNum(#): "+subPartCount +" \t PartNo: \t "+tempStPartNo+" \t ");
						writeSuccessToFile(subPartCount +"\t"+tempStPartNo+"\t"+stREVISION);
							
					}
						
						successCount++;
						
				} catch (Exception e) {
					ContextUtil.abortTransaction(context);

					if(!checkAddPart){
						MQLCommand mqlCommand = new MQLCommand();
						mqlCommand.open(context);
						mqlCommand.executeCommand(context, "abort transaction $1","PartFamily");
					}
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "trigger on");
						checkTriggerOff = false;			
					}
					failCount++;
					writeErrorToFile("LineNum(#)"+tempStRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " +e.getMessage().replaceAll("\r|\n", "")); 
					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t" +  data ) ;
					
					e.printStackTrace(errorStream);
					writeShotErrorToFile(e.toString().replaceAll("\r|\n", ""));
				}finally{
					
				}
				
			} // end of while 
			
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================");
			//
		} catch (Exception e1) {
			writeFailToFile(" LineNum(#):"+tempStRowNum);
			writeErrorToFile("LineNum(#):"+tempStRowNum + "  "+e1.getMessage());
			e1.printStackTrace(errorStream);
			
//			e1.printStackTrace();
//			String date= DateFormatUtils.formatUTC(System.currentTimeMillis(), "MMddyy");
//			String recordDirectory = directory+doubleSlash+"ErrorPart"+"_"+date+".txt"; //errorfile
//			
//			errorBufferWriter = new BufferedWriter(new FileWriter(recordDirectory, true));
//			StringBuilder stBuilder = new StringBuilder();
//			stBuilder.append("rowNumber: ").append(tempStRowNum).append("|").append("beforeSystemObjId: ").append(tempStObjectId).append("|").append("PartNo: ").append(tempStPartNo).append("|").append("SubId  :").append(tempStSubId).append("|").append("- error!");
//			errorBufferWriter.write(stBuilder.toString() );
//			errorBufferWriter.newLine();
//			
//			StackTraceElement[] elem = e1.getStackTrace();
//			String strTrace = "\n";
//			for (int i = 0; i < elem.length; i++) {
//				strTrace = elem[i].toString()+"\n";
//			}
//			errorBufferWriter.write(strTrace);
//			error2bufferWriter.flush();
//			errorBufferWriter.close();
			
			
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("	CREATE PART OBJECT CLOSE TIME:  "+cdmCommonExcel.getTimeStamp2()+"          "  );
			writeMessageToConsole("	CREATE PART OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+")"  );
			writeMessageToConsole("==================================================================================== \n");
			MqlUtil.mqlCommand(context, "history on");
			if(checkTriggerOff){
				MqlUtil.mqlCommand(context, "trigger on");
			}
			try {
				if (null != errorStream )
					errorStream .close();

				if (null != logWriter)
					logWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if(null != bufferReader)
					bufferReader.close();
				
				if(null != errorLogFile)
					errorLogFile.close();
				
				if(null != debugLogFile)
					debugLogFile.close();

				if(null != errorLogFile)
					errorLogFile.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			
			long endTime = System.currentTimeMillis();
			long leadTime = (endTime-startTime)/1000/60;
			System.out.println("cdmPartMigration : modifyPartCreate End.   endTime:"+endTime  + "leadTime :"+leadTime);
			
		}
	
	}
	
//	/**
//	 * 
//	 * @param context
//	 * @param lev2CommonCode
//	 * @param commonCodeValue
//	 * @param SingleAndMulti
//	 * @return
//	 * @throws Exception
//	 */
//	public String expandCommonCodeMql(Context context,String lev2CommonCode,String commonCodeWhere, String SingleAndMulti)throws Exception{
//		StringBuffer result = new StringBuffer();
//		try{
//			String stCommonCodeMql = "expand  bus "+ lev2CommonCode  +" "+commonCodeWhere ;
//    	 	String stCommonCodeMqResult = MqlUtil.mqlCommand(context, stCommonCodeMql);
//    	 	
//    	 	StringList stListCommonCodeMqResult =  FrameworkUtil.split(stCommonCodeMqResult, "\n");
//    	 	int number = 1;
//    	 	
//    	 	for (Iterator stListCommonCodeIerator = stListCommonCodeMqResult.iterator(); stListCommonCodeIerator.hasNext();) {
//    	 		String stTempCommonCode = (String) stListCommonCodeIerator.next();
//			
//				StringList stListTempCommonCode =  FrameworkUtil.split(stTempCommonCode, "|");
//				String stCommonCode= (String)stListTempCommonCode.get(6); //ex : 1|cdmCommonCodeRelationship|to|cdmCommonCode|CC-0000006643|-|8820.41398.39528.10777
//				
//				if("M".equals(SingleAndMulti) && stListCommonCodeMqResult.size() > number && stListCommonCodeMqResult.size() >1 ){
//					result.append(",");
//	    	 	}
//				result.append(stCommonCode);
//				number ++;
//				if("S".equals(SingleAndMulti)){
//					break;
//				}
//    	 	}
//
//		}catch(Exception e){
//			e.printStackTrace();
//		}
//		return result.toString();
//	}
	
	
	public Map getVehicleCode(Context context, String strCommonCode)throws Exception{
		Map resultMap = new HashMap();
		try{
			
			
			String sWhereExp = "attribute[cdmCommonCode] == '" +strCommonCode+ "'";
			
			MapList ml1LvlCommonCode = DomainObject.findObjects(context,
                    "cdmCommonCode", "*", sWhereExp , new StringList("id"));
					
			
			String str1LvlCodeId = null;
			if(ml1LvlCommonCode.size() == 1) {
				
				str1LvlCodeId =(String) ((Map) ml1LvlCommonCode.get(0)).get("id");
				
			} else {
				throw new Exception("NOT EXIST COMMNONCODE OPTION LEV1 OBJECT");
			}
			
			DomainObject codeObj = new DomainObject(str1LvlCodeId);
			
			StringList busSelect = new StringList();
			busSelect.add("id");
			busSelect.add("attribute[cdmCommonCode]");
			busSelect.add("attribute[cdmCommonCodeNameEn]");
			busSelect.add("to[cdmCommonCodeRelationship].from.attribute[cdmCommonCode]");
			
			MapList mlCodes = codeObj.getRelatedObjects(context,
				                    "cdmCommonCodeRelationship", // relationship pattern
				                    "cdmCommonCode", // object pattern
				                    busSelect, // object selects
				                    null, // relationship selects
				                    false, // to direction
				                    true, // from direction
				                    (short) 2, // recursion level
				                    "", // object where clause
				                    null); // relationship where clause

			
			for (int i = 0; i < mlCodes.size(); i++) {
				
				Map objMap = (Map) mlCodes.get(i);
				String sLevel = (String) objMap.get("level");
				if(!"2".equals(sLevel)){
					continue;
				}
				String sOid = (String) objMap.get("id");
				String sCode = (String) objMap.get("attribute[cdmCommonCode]");
				String sCodeName = (String) objMap.get("attribute[cdmCommonCodeNameEn]");
				String sCustomerCode = (String) objMap.get("to[cdmCommonCodeRelationship].from.attribute[cdmCommonCode]");
				
				sCode = cdmCommonExcel.isVaildNullData(sCode);
				sCodeName = cdmCommonExcel.isVaildNullData(sCodeName);
				sCustomerCode = cdmCommonExcel.isVaildNullData(sCustomerCode);
				
				resultMap.put(sCode+"_"+sCodeName+"_"+sCustomerCode, sOid);
			
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return resultMap;
	}
	
	
	public Map getProductGroupCode(Context context, String strCommonCodeProductGroup)throws Exception{
		Map resultMap = new HashMap();
		try{
			
//			String productGroupIddWhere = " from relationship cdmCommonCodeRelationship type cdmCommonCode recurse to end select bus id  where \"  attribute[cdmCommonCodeNameEn]=='" + stCN_PRODUCT_GROUP + "' && attribute[cdmCommonTemp2]=='" + stCN_PRODUCT_DIV + "' \" dump |";
			
			//String stTempECExist = "temp query bus \"" + sbfECType.toString() + "\" * * where \"attribute[cdmECCode]=='" + stCN_ECO_NUMBER + "' \" select id dump |";
			
			String sWhereExp = "attribute[cdmCommonCode] == '" +strCommonCodeProductGroup+ "' && to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot'";
			
			MapList ml1LvlCommonCode = DomainObject.findObjects(context,
                    "cdmCommonCode", "*", sWhereExp , new StringList("id"));

			
			String str1LvlCodeId = null;
			if(ml1LvlCommonCode.size() == 1) {
				str1LvlCodeId =(String) ((Map) ml1LvlCommonCode.get(0)).get("id");
			} else {
				throw new Exception("NOT EXIST COMMNONCODE "+strCommonCodeProductGroup+" LEV1 OBJECT");
			}
			
			DomainObject codeObj = new DomainObject(str1LvlCodeId);
			
			StringList busSelect = new StringList();
			busSelect.add("id");
			busSelect.add("attribute[cdmCommonCodeNameEn]");
//			busSelect.add("attribute[cdmCommonTemp1]");
			busSelect.add("attribute[cdmCommonTemp2]");
			
			
			MapList mlCodes = codeObj.getRelatedObjects(context,
									"cdmCommonCodeRelationship", // relationship pattern
				                    "cdmCommonCode", // object pattern
				                    busSelect, // object selects
				                    null, // relationship selects
				                    false, // to direction
				                    true, // from direction
				                    (short) 1, // recursion level
				                    null, // object where clause
				                    null); // relationship where clause

			
			for (int i = 0; i < mlCodes.size(); i++) {
				Map objMap = (Map) mlCodes.get(i);
				String sOid = (String) objMap.get("id");
				String sCodeName = (String) objMap.get("attribute[cdmCommonCodeNameEn]");
//				String sTemp1 = (String) objMap.get("attribute[cdmCommonTemp1]");
				String sTemp2 = (String) objMap.get("attribute[cdmCommonTemp2]");
				
				
				resultMap.put(sCodeName+"_"+sTemp2, sOid);
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return resultMap;
	}
	
	
	public Map getProductDivCode(Context context, String strCommonCodeProductDiv)throws Exception{
		Map resultMap = new HashMap();
		try{
			
			
			String sWhereExp = "attribute[cdmCommonCode] == '" +strCommonCodeProductDiv+ "' && to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot'";
			
			MapList ml1LvlCommonCode = DomainObject.findObjects(context,
                    "cdmCommonCode", "*", sWhereExp , new StringList("id"));

			
			String str1LvlCodeId = null;
			if(ml1LvlCommonCode.size() == 1) {
				str1LvlCodeId =(String) ((Map) ml1LvlCommonCode.get(0)).get("id");
			} else {
				throw new Exception("NOT EXIST COMMNONCODE "+strCommonCodeProductDiv+" LEV1 OBJECT");
			}
			
			DomainObject codeObj = new DomainObject(str1LvlCodeId);
			
			StringList busSelect = new StringList();
			busSelect.add("id");
			busSelect.add("attribute[cdmCommonCodeNameEn]");
			
			
			MapList mlCodes = codeObj.getRelatedObjects(context,
									"cdmCommonCodeRelationship", // relationship pattern
				                    "cdmCommonCode", // object pattern
				                    busSelect, // object selects
				                    null, // relationship selects
				                    false, // to direction
				                    true, // from direction
				                    (short) 1, // recursion level
				                    null, // object where clause
				                    null); // relationship where clause

			
			for (int i = 0; i < mlCodes.size(); i++) {
				Map objMap = (Map) mlCodes.get(i);
				String sOid = (String) objMap.get("id");
				String sCodeName = (String) objMap.get("attribute[cdmCommonCodeNameEn]");
				
				resultMap.put(sCodeName, sOid);
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return resultMap;
	}
	
	public Map getOptionCode(Context context, String strCommonCodeOption)throws Exception{
		Map resultMap = new HashMap();
		try{
			
			
			//String stTempECExist = "temp query bus \"" + sbfECType.toString() + "\" * * where \"attribute[cdmECCode]=='" + stCN_ECO_NUMBER + "' \" select id dump |";
			
			String sWhereExp = "attribute[cdmCommonCode] == '" +strCommonCodeOption+ "' && to[cdmCommonCodeRelationship].from.name == 'CommonCodeRoot'";
			
			MapList ml1LvlCommonCode = DomainObject.findObjects(context,
                    "cdmCommonCode", "*", sWhereExp , new StringList("id"));

			
			String str1LvlCodeId = null;
			if(ml1LvlCommonCode.size() == 1) {
				str1LvlCodeId =(String) ((Map) ml1LvlCommonCode.get(0)).get("id");
			} else {
				throw new Exception("NOT EXIST COMMNONCODE "+strCommonCodeOption+" LEV1 OBJECT");
			}
			
			DomainObject codeObj = new DomainObject(str1LvlCodeId);
			
			StringList busSelect = new StringList();
			busSelect.add("id");
			busSelect.add("attribute[cdmCommonCode]");
			busSelect.add("attribute[cdmCommonTemp1]");
			
			
			MapList mlCodes = codeObj.getRelatedObjects(context,
									"cdmCommonCodeRelationship", // relationship pattern
				                    "cdmCommonCode", // object pattern
				                    busSelect, // object selects
				                    null, // relationship selects
				                    false, // to direction
				                    true, // from direction
				                    (short) 1, // recursion level
				                    null, // object where clause
				                    null); // relationship where clause

			
			for (int i = 0; i < mlCodes.size(); i++) {
				Map objMap = (Map) mlCodes.get(i);
				String sOid = (String) objMap.get("id");
				String sCode = (String) objMap.get("attribute[cdmCommonCode]");
				String sTemp1 = (String) objMap.get("attribute[cdmCommonTemp1]");
				
				resultMap.put(sCode+"_"+sTemp1, sOid);
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return resultMap;
	}
	
	
	public Map getProjectCode(Context context, String strProject)throws Exception{
		Map resultMap = new HashMap();
		try{
			
			
			//String stTempECExist = "temp query bus \"" + sbfECType.toString() + "\" * * where \"attribute[cdmECCode]=='" + stCN_ECO_NUMBER + "' \" select id dump |";
			
			String sWhereExp = "attribute[cdmProjectObjectIdM] != '' &&  attribute[cdmCheckMigration] == 'Y'";
			
			StringList sList = new StringList();
			sList.add("id");
			sList.add("attribute[cdmProjectObjectIdM]");
			MapList mProject = DomainObject.findObjects(context,
                    "cdmProjectGroupObject", "*", sWhereExp , sList);

			
			for (int i = 0; i < mProject.size(); i++) {
				Map mProjectMap = (Map) mProject.get(i);
				String sOid = (String) mProjectMap.get("id");
				String sProjectObjectIdM = (String) mProjectMap.get("attribute[cdmProjectObjectIdM]");
				
				resultMap.put(sProjectObjectIdM.trim(), sOid);
				
			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return resultMap;
	}
	
	public Map getPartFamilyId(Context context)throws Exception{
		Map resultMap = new HashMap();
		try{
			
			String sWhereExp = "name=='Electronic_Parts' || name == 'Block_Code' ";
			
			StringList sList = new StringList();
			sList.add("id");
			sList.add("name");
			
			MapList mPartLibrary = DomainObject.findObjects(context,
                    "Part Library", "*", sWhereExp , sList);

			
 
			String sPFWhere = "attribute[cdmPartFamilyBlockCodeName] !='' && attribute[cdmPartFamilyBlockCodeName] ~='*:*'"; 
//			String sPFWhere = "attribute[cdmCheckMigration]==\"Y\""; 
			StringList busSelect = new StringList();
			busSelect.add("id");
			busSelect.add("name");
			busSelect.add("level");
			busSelect.add("attribute[cdmPartFamilyBlockCodeName]");
			for (int i = 0; i < mPartLibrary.size(); i++) {
				Map mPartLibraryMap = (Map) mPartLibrary.get(i);
				String sOid = (String) mPartLibraryMap.get("id");
				String sName = (String) mPartLibraryMap.get("name");

				DomainObject pfObj = new DomainObject();

				pfObj.setId(sOid);
				MapList mListPF = pfObj.getRelatedObjects(context, "Subclass", // relationship pattern
						"Part Family", // object pattern
						busSelect, // object selects
						null, // relationship selects
						false, // to direction
						true, // from direction
						(short) 3, // recursion level
						sPFWhere, // object where clause
						null); // relationship where clause

				for (int blockCodePFCount = 0; blockCodePFCount < mListPF.size(); blockCodePFCount++) {
					Map objMap = (Map) mListPF.get(blockCodePFCount);
					
					String sLevel = (String) objMap.get("level");
					if(!"3".equals(sLevel)){
						continue;
					}
					String sBlockCodeOid = (String) objMap.get("id");
					String sTempBlockCode = (String) objMap.get("attribute[cdmPartFamilyBlockCodeName]");
					String sBlockCode = sTempBlockCode.substring(0, 5);

					String duplicateBlockCode = (String) resultMap.get(sBlockCode) == null || (String) resultMap.get(sBlockCode) == "null" ? "" : (String) resultMap.get(sBlockCode);
					if (UIUtil.isNotNullAndNotEmpty(duplicateBlockCode)) {
						duplicateBlockCode += ",";
						duplicateBlockCode += sBlockCodeOid;
						resultMap.put(sBlockCode, duplicateBlockCode);
					} else {
						resultMap.put(sBlockCode, sBlockCodeOid);

					}
					resultMap.put(sTempBlockCode, sBlockCodeOid);

				}


			}
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return resultMap;
	}
	
	public Map getPartFamilyId2(Context context,String arg){
		Map resultMap = new HashMap();
		try {
//			arg = "Global R&D:Global R&D";
			MapList findPartFamily = new MapList();
			String findType = "Part Family";
			// String sBusWhere = "attribute[cdmPartFamilyBlockCodeName]!= '' && attribute[cdmPartFamilyBlockCodeName]~='*:*' ";
			// String sBusWhere = "attribute[cdmPartFamilyBlockCodeName]!= '' && attribute[cdmPartFamilyBlockCodeName]=='Global R&D:Global R&D' ";
			String sBusWhere = "attribute[cdmPartFamilyBlockCodeName]!= '' && attribute[cdmPartFamilyBlockCodeName]=='" + arg + "' ";
			StringList slBusSelect = new StringList();
			slBusSelect.add("id");
			slBusSelect.add("attribute[cdmPartFamilyBlockCodeName]");

			findPartFamily = DomainObject.findObjects(context, findType, // type
					cdmConstantsUtil.QUERY_WILDCARD, // name
					cdmConstantsUtil.QUERY_WILDCARD, // rev
					cdmConstantsUtil.QUERY_WILDCARD, // owner
					cdmConstantsUtil.QUERY_WILDCARD, // vault
					sBusWhere, // where
					false, // expand
					slBusSelect); // selectbus

			String partFamilyTopId = "";
			for (Iterator findPFIter = findPartFamily.iterator(); findPFIter.hasNext();) {
				Map finsPFMap = (Map) findPFIter.next();
				partFamilyTopId = (String) finsPFMap.get("id");

			}

			String sRelType = "Subclass";
			StringList seList = new StringList();
			seList.add("id");
			seList.add("attribute[cdmPartFamilyBlockCodeName]");

			String findPFMql = "expand bus $1 from relationship $2 recurse to end   select bus $3 $4 dump $5";
			String mqlResult = MqlUtil.mqlCommand(context, findPFMql, partFamilyTopId, "Subclass", "id", "attribute[cdmPartFamilyBlockCodeName]", "|");

			StringList sListMqlPF = new StringList();
			sListMqlPF = FrameworkUtil.split(mqlResult, "\n");

//			HashMap resultMap = new HashMap();
			for (int blockCodePFCount = 0; blockCodePFCount < sListMqlPF.size(); blockCodePFCount++) {
				String sPFInfo = (String) sListMqlPF.get(blockCodePFCount);
				StringList sListPFInfo = new StringList();

				sListPFInfo = FrameworkUtil.split(sPFInfo, "|");
				String sBlockCodeOid = (String) sListPFInfo.get(6);
				String sTempBlockCode = (String) sListPFInfo.get(7);
				String sBlockCode = sTempBlockCode.substring(0, 5);

				String duplicateBlockCode = (String) resultMap.get(sBlockCode) == null || (String) resultMap.get(sBlockCode) == "null" ? "" : (String) resultMap.get(sBlockCode);
				if (UIUtil.isNotNullAndNotEmpty(duplicateBlockCode)) {
					duplicateBlockCode += ",";
					duplicateBlockCode += sBlockCodeOid;
					resultMap.put(sBlockCode, duplicateBlockCode);
				} else {
					resultMap.put(sBlockCode, sBlockCodeOid);
				}
				resultMap.put(sTempBlockCode, sBlockCodeOid);

			}
		}catch(Exception e2){
			e2.printStackTrace();
		}finally{
			return resultMap;
		}
	}
	/**
	 * strPhase 기준 정보 필요 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
//	@SuppressWarnings("finally")
//	public boolean revisePartM(Context context, String args[]) throws Exception {
//		boolean checkCreate = false;
//		String revisePartObjectId = "";
//		try {
//			HashMap paramMap = JPO.unpackArgs(args);
//			
//			String strPartId = (String) paramMap.get("partObjectId");
//			String strCustomRevision = (String) paramMap.get("stReviseState");
//			
//			String strPartNo = (String) paramMap.get("cdmPartNo"); //PartNo
//			String strPartName = (String) paramMap.get("cdmPartName"); //PartName
//			
//			String strPhase = ""; 
//			String strECobjectId = "";
//			// modify by mskim 0930 start 
//			strPhase = (String) paramMap.get("cdmPartPhase"); //Phase
////			strECobjectId = (String) paramMap.get("EC_Oid"); //EC_Oid
//			//modify by mskim 0930 end  
//			Part part = new Part(strPartId);
//			String strPartphase = part.getAttributeValue(context, "cdmPartPhase");
//			String strType = part.getTypeName();
//			
//			//리비전 정보가 존재하는 경우 제외
//			DomainObject revisePartObj = new DomainObject();
//			if (!strPhase.equals(strPartphase) && "Production".equals(strPhase)) {
//				BusinessObject buCloneObject = part.cloneObject(context, strPartNo, strCustomRevision, "eService Production");
//				revisePartObjectId = buCloneObject.getObjectId();
//				revisePartObj = DomainObject.newInstance(context, revisePartObjectId);
//				revisePartObj.setPolicy(context, "cdmPartProductionPolicy");
//				revisePartObj.setAttributeValue(context, "cdmPartPhase", strPhase);
//			} else {
//				// modify mskim -migration의 현재 rev 정보 입력 
////				BusinessObject lastRev = part.getLastRevision(context);
////				BusinessObject newbo = lastRev.revise(context, lastRev.getNextSequence(context), lastRev.getVault());
//				BusinessObject newbo = part.revise(context, strCustomRevision, "eService Production");
//				revisePartObjectId = newbo.getObjectId();
//				revisePartObj = new DomainObject(revisePartObjectId);
//			}
//
//			part.setAttributeValue(context, "Is Version Object", "True");
//			if (!"".equals(strECobjectId)) {
//				DomainRelationship.connect(context, new DomainObject(strECobjectId), "Affected Item", revisePartObj);
//			}
//
//			if ("cdmPhantomPart".equals(strType)) {
//				String strDrawingId = MqlUtil.mqlCommand(context, "print bus " + strPartId + " select from[Part Specification||type=='CATDrawing'].id dump");
//				System.out.println("DrawingId     :     " + strDrawingId);
//
//				if (!"".equals(strDrawingId)) {
//
//					String relation = "Part Specification";
//					String type = "type_Part";
//
//					SelectList selectList = new SelectList(3);
//					selectList.addId();
//					selectList.addName();
//					selectList.addType();
//
//					DomainObject domObj = DomainObject.newInstance(context);
//					domObj.setId(strDrawingId);
//					MapList mlSeriesPartList = domObj.getRelatedObjects(context, relation, type, selectList, null, false, true, (short) 1, "", null);
//					int seriesPartSize = mlSeriesPartList.size();
//
//					for (int i = 0; i < seriesPartSize; i++) {
//						Map map = (Map) mlSeriesPartList.get(i);
//						String id = (String) map.get(DomainConstants.SELECT_ID);
//						Part seriesPart = new Part(id);
//						String strSeriesPhase = seriesPart.getAttributeValue(context, "cdmPartPhase");
//
//						if (!strPhase.equals(strSeriesPhase) && "Production".equals(strPhase)) {
//							BusinessObject buSeriesCloneObject = seriesPart.cloneObject(context, strPartNo, strCustomRevision, "eService Production");
//							String reviseSeriesPartObjectId = buSeriesCloneObject.getObjectId();
//							DomainObject reviseSeriesPartObj = DomainObject.newInstance(context, reviseSeriesPartObjectId);
//							reviseSeriesPartObj.setPolicy(context, "cdmPartProductionPolicy");
//							reviseSeriesPartObj.setAttributeValue(context, "cdmPartPhase", strPhase);
//						} else {
//							BusinessObject seriesPartlastRev = seriesPart.getLastRevision(context);
//							seriesPartlastRev.revise(context, seriesPartlastRev.getNextSequence(context), seriesPartlastRev.getVault());
//						}
//					}
//				}
//			}
//			
//		} catch (Exception e) {
//			e.printStackTrace();
//			checkCreate = false;
//		}finally{
//			return checkCreate ;
//		}
//	}
	 public String connectPartFamily(Context context,String args[])throws Exception{
		 String result = "";
		 boolean checkAddPart = false;
//		 MQLCommand mqlCommand = new MQLCommand();
		 try 
		 {
//			 trigger on 의 주석을 제거하려면 implementInterfaceOnClassifiedItem 호출하는 부분을 주석처리해야함
//			 MqlUtil.mqlCommand(context, "trigger on"); // 
			HashMap paramHMap = JPO.unpackArgs(args);
			
			String sPF = (String)paramHMap.get("sPF");
			String partObjectId = (String)paramHMap.get("partObjectId");
			
			PartFamily partFamily = (PartFamily) DomainObject.newInstance(context, DomainConstants.TYPE_PART_FAMILY, DomainConstants.ENGINEERING);
			partFamily.setId(sPF);

			
//			mqlCommand.open(context);
//			mqlCommand.executeCommand(context, "set transaction savepoint $1", "PartFamily");
//			partFamily.addPart(context, partObjectId);
			
//			Object localObject1 = RELATIONSHIP_CLASSIFIED_ITEM;
//			String relClassifiedItem = cdmConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM;
//			partFamily.connectTo(context, relClassifiedItem, new DomainObject(partObjectId));
			DomainRelationship.connect(context, partFamily, DomainConstants.RELATIONSHIP_CLASSIFIED_ITEM, new DomainObject(partObjectId));
			
			
		} catch (Exception e) {
			checkAddPart = false;
			if(!checkAddPart){
//				MQLCommand mqlCommand = new MQLCommand();
//				mqlCommand.open(context);
//				mqlCommand.executeCommand(context, "abort transaction $1","PartFamily");
			}
			result = "false|"+e.toString();
		}finally{
//			mqlCommand.close(context);
//			MqlUtil.mqlCommand(context, "trigger off"); 
			return result;
		}
	 }
	 
//	 /**
//	  * 임시적으로 사용 12/19만 
//	  * part 및 Part Family 데이타 들어가지 않았음 처리 필요 
//	  * @param context
//	  * @param arg
//	  * @return
//	  * @throws Exception
//	  */
//	public void interfacePartPf(Context context ,String args[])throws Exception{
//		try {
//			String type = cdmConstantsUtil.TYPE_CDMMECHANICALPART+","+cdmConstantsUtil.TYPE_CDMPHANTOMPART;
//			String sBusWhere = "attribute[cdmCheckMigration] == 'Y' && to[Classified Item] == 'True' && to[Classified Item].from.type == 'Part Family'";
//			
//			SelectList slBusSelect = new SelectList();
//			slBusSelect.addId();
//			slBusSelect.add("to[Classified Item].from.id");
//			
//			MapList findMList = new MapList();
//			findMList = DomainObject.findObjects(context, 
//					type,       // type
//					cdmConstantsUtil.QUERY_WILDCARD,            // name
//					cdmConstantsUtil.QUERY_WILDCARD,            // rev
//					cdmConstantsUtil.QUERY_WILDCARD,            // owner
//					cdmConstantsUtil.QUERY_WILDCARD,           	// vault
//					sBusWhere, 									// where
//					false,                                   	// expand
//					slBusSelect);                            	// selectbus
//					
//			for (Iterator iterPart = findMList.iterator(); iterPart.hasNext();) {
//
//				Map partMap = (Map) iterPart.next();
//				String tempPartId = (String)partMap.get("id");
//				String tempPartFamilyId = (String)partMap.get("to[Classified Item].from.id");
//				tempPartId = cdmCommonExcel.isVaildNullData(tempPartId);
//				tempPartFamilyId = cdmCommonExcel.isVaildNullData(tempPartFamilyId);
//				//trigger from 
//				if (UIUtil.isNotNullAndNotEmpty(tempPartId) && UIUtil.isNotNullAndNotEmpty(tempPartFamilyId)) {
//					DomainObject doFromObject = new DomainObject(tempPartFamilyId);
//					String sFromObjectType = doFromObject.getInfo(context, DomainConstants.SELECT_TYPE);
//					DomainObject doToObject = new DomainObject(tempPartId);
//					String partFamilyReference = PropertyUtil.getSchemaProperty(context, "interface_PartFamilyReference");
//
//
//					DomainObject doObj = new DomainObject(tempPartFamilyId);
//					String strInterface = doObj.getAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//
//					String strPartMQL = "print bus $1 select interface dump";
//					String strResult = MqlUtil.mqlCommand(context, strPartMQL, tempPartId);
//					ContextUtil.pushContext(context);
//
//					if (strResult != null && strResult.indexOf(strInterface) == -1) {
//						String strMQL = "modify bus $1 add interface $2";
//						strResult = MqlUtil.mqlCommand(context, strMQL, tempPartId, strInterface);
//					}
//
//					ContextUtil.popContext(context);
//
//					
//				}
//			}
//			
//		} catch (Exception e) {
//			// TODO: handle exception
//			e.printStackTrace();
//		}
//	}
	public boolean beforeRevision(Context context,String arg[])throws Exception{
		boolean checkCreate = false;
		String revisePartObjectId = "";
		try {
			HashMap paramMap = JPO.unpackArgs(arg);
			
			String strPartId = (String) paramMap.get("partObjectId"); //기준 object
			String stBeforeRevision = (String) paramMap.get("stBeforeRevision");
			String existPreRev = (String) paramMap.get("existPreRev"); // object 생성 여부 확인 
			String existPreRevisionObjectId = (String) paramMap.get("existPreRevisionObjectId");
			String strPartNo = (String) paramMap.get("cdmPartNo");   //PartNo
			String strPartName = (String) paramMap.get("cdmPartName"); //PartName
			
			String strPhase = ""; 
			String strECobjectId = "";
			strPhase = (String) paramMap.get("cdmPartPhase"); //Phase
			
			Part part = new Part(strPartId);
			String strPartphase = part.getAttributeValue(context, "cdmPartPhase");
			String strType = part.getTypeName();
			DomainObject dObjinsertRevisionBefore = DomainObject.newInstance(context);
			if (!Boolean.parseBoolean(existPreRev)) {
				BusinessObject insertRevisionBeforeObject = part.cloneObject(context, strPartNo, stBeforeRevision, "eService Production");
				part.insertRevisionBefore(context, insertRevisionBeforeObject, true);

				dObjinsertRevisionBefore.setId(insertRevisionBeforeObject.getObjectId());

				dObjinsertRevisionBefore.setPolicy(context, "cdmPartProductionPolicy");
				dObjinsertRevisionBefore.setAttributeValue(context, "cdmPartPhase", strPhase);
				dObjinsertRevisionBefore.setState(context, cdmConstantsUtil.STATE_CDM_PART_PRODUCTION_POLICY_RELEASED);
			
				
//				if (!"".equals(strECobjectId)) {
//					DomainRelationship.connect(context, new DomainObject(strECobjectId), "Affected Item", dObjinsertRevisionBefore);
//				}
			}else{
				BusinessObject insertRevisionBeforeExistObject  = new BusinessObject(existPreRevisionObjectId);
				part.insertRevisionBefore(context, insertRevisionBeforeExistObject, true);
			}
			part.setAttributeValue(context, "Is Version Object", "True");

			if ("cdmPhantomPart".equals(strType)) {
				String strDrawingId = MqlUtil.mqlCommand(context, "print bus " + strPartId + " select from[Part Specification||type=='CATDrawing'].id dump");
				System.out.println("DrawingId     :     " + strDrawingId);

				if (!"".equals(strDrawingId)) {

					String relation = "Part Specification";
					String type = "type_Part";

					SelectList selectList = new SelectList(3);
					selectList.addId();
					selectList.addName();
					selectList.addType();

					DomainObject domObj = DomainObject.newInstance(context);
					domObj.setId(strDrawingId);
					MapList mlSeriesPartList = domObj.getRelatedObjects(context, relation, type, selectList, null, false, true, (short) 1, "", null);
					int seriesPartSize = mlSeriesPartList.size();

					for (int i = 0; i < seriesPartSize; i++) {
						Map map = (Map) mlSeriesPartList.get(i);
						String id = (String) map.get(DomainConstants.SELECT_ID);
						Part seriesPart = new Part(id);
						String strSeriesPhase = seriesPart.getAttributeValue(context, "cdmPartPhase");

						if (!strPhase.equals(strSeriesPhase) && "Production".equals(strPhase)) {
							BusinessObject buSeriesCloneObject = seriesPart.cloneObject(context, strPartNo, stBeforeRevision, "eService Production");
							String reviseSeriesPartObjectId = buSeriesCloneObject.getObjectId();
							DomainObject reviseSeriesPartObj = DomainObject.newInstance(context, reviseSeriesPartObjectId);
							reviseSeriesPartObj.setPolicy(context, "cdmPartProductionPolicy");
							reviseSeriesPartObj.setAttributeValue(context, "cdmPartPhase", strPhase);
						} else {
							BusinessObject seriesPartlastRev = seriesPart.getLastRevision(context);
							seriesPartlastRev.revise(context, seriesPartlastRev.getNextSequence(context), seriesPartlastRev.getVault());
						}
					}
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
			checkCreate = false;
		}finally{
			return checkCreate ;
		}
	}
	
	/**
	 * part 삭제 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void deletePartM(Context context,String[] args)throws Exception{
		boolean suceess = false;
		try{
			Map paramMap = (Map)JPO.unpackArgs(args);
			String id = (String)paramMap.get("objectId");
			
			String stArrayDeleteId[]  =  {id};
			StringList objectSelects = new StringList(2);
	        objectSelects.addElement(DomainObject.SELECT_ID);
	        objectSelects.addElement(cdmConstantsUtil.TEXT_KINDOFDOCUMENT);
	        
	        MapList deleteAccessList = DomainObject.getInfo(context, stArrayDeleteId, objectSelects);
	        Iterator deleteAccessItr = deleteAccessList.iterator();
	        while(deleteAccessItr.hasNext()) {
	            Map accessMap = (Map)deleteAccessItr.next();
	        
	            String domObjectId = (String)accessMap.get(DomainObject.SELECT_ID);
	            String isDocumentType = (String)accessMap.get(cdmConstantsUtil.TEXT_KINDOFDOCUMENT);
	
//	            DomainObject.deleteObject(context, domObjectId);
	            
//	            DomainObject.deleteObjects(context, stArrayDeleteId);
	        
	        }
			suceess = true;
			
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			System.out.println("suceess ->>>>>"+suceess);
		}
	}
	

	/**
	 *  
	 * 
	 * @param context
	 * @param args
	 * @param requestAgsNum
	 * @param logFileName
	 */
	public void initializeM(Context context,String args[],int requestAgsNum , String logFileName)throws Exception{

		if (args.length != requestAgsNum )
		{
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}


		inputDirectory = args[0];

		// documentDirectory does not ends with "/" add it
		if(inputDirectory != null && !inputDirectory.endsWith(sfileSeparator))
		{
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+  sfileSeparator;
        File fileOutputDirectory = new File(outputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        // input file name
     	fileName = args[1];
     	logFileName += fileName.substring(0, fileName.lastIndexOf("."))+cdmCommonExcel.getTimeStamp();
		logWriter 			 	= new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(outputDirectory + logFileName + "_SuccessLogs.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(outputDirectory + logFileName + "_FailedLogs" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		
	
	}
	
	
	public void writeShotErrorToFile(String message)throws Exception{
		shortErrorWriter.write( message + "\n");
		shortErrorWriter.flush();
	}
	public void writeErrorToFile(String message)throws Exception{
		errorStream.write(message.getBytes("UTF-8"));
		errorStream.write("\n".getBytes("UTF-8"));
	}
	
	public void writeMessageToConsole(String message) throws Exception
	{
		writeMessageToLogFile(message);
	}

	public void writeMessageToLogFile(String message) throws Exception
	{
		logWriter.write( message + "\n");
		logWriter.flush();
	}
	public void writeFailToFile(String message) throws Exception{
		failedObjectidWriter.write( message + "\n");
		failedObjectidWriter.flush();
	}
	public void writeSuccessToFile(String message)throws Exception{
		successObjectidWriter.write(message + "\n");
		successObjectidWriter.flush();
	}

    public String getFormatENOVIA(Context context, String strDate) throws Exception {
    	try {
//			int iDateFormat = eMatrixDateFormat.getEMatrixDisplayDateFormat();
			int iDateFormat = 1;
			Locale locale = context.getLocale();
			TimeZone tz = TimeZone.getTimeZone(context.getSession().getTimezone());
			double dbMilisecondsOffset = (double) (-1) * tz.getRawOffset();
			double clientTZOffset = (new Double(dbMilisecondsOffset / (1000 * 60 * 60))).doubleValue();
			strDate = eMatrixDateFormat.getFormattedDisplayDateTime(strDate, false, iDateFormat, clientTZOffset , locale);
    	} catch(Exception e) {
    		e.printStackTrace();
    	}
    	return strDate;
    }
    
    /**
     * 12/28
     * @param context
     * @param args
     * @throws Exception
     */
    public void modifyPartAttribute(Context context, String args[]) throws Exception {
    		
    		//part Master 연결
    		StringList slBusSelect = new StringList();
    		slBusSelect.add("id");
    		slBusSelect.add("name");
    		slBusSelect.add("revision");
    		
    		String type = "cdmMechanicalPart,cdmPhantomPart";
    		// Prt Revision 연결  part family 
//    		eo , , 속성 추가 ,commoncode 해제 및 추가 
//    		String sBusWhere = "attribute[cdmCheckMigration]!='Y' || relationship[Part Revision]=='False'  || last.id != id";
//    		String sBusWhere = "relationship["+LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM+"]== 'False' || relationship[Part Revision]=='False'";
    		String sBusWhere = "attribute[cdmCheckMigration]!='Y'";
    		MapList mListNotConnectPart = DomainObject.findObjects(context,
    				type,       // type
					cdmConstantsUtil.QUERY_WILDCARD,            // name
					cdmConstantsUtil.QUERY_WILDCARD,            // rev
					cdmConstantsUtil.QUERY_WILDCARD,            // owner
					cdmConstantsUtil.QUERY_WILDCARD,           	// vault
					sBusWhere, 									// where
					false,                                   	// expand
					slBusSelect);                            	// selectbus
    		
    		HashMap hmNoAttributePart = new HashMap<>();
    		DomainObject dObj = new DomainObject();
    		for (Iterator iterNoConnectPart = mListNotConnectPart.iterator(); iterNoConnectPart.hasNext();) {
				Map noConnectPartMap = (Map) iterNoConnectPart.next();
				String objectId = (String)noConnectPartMap.get("id");
				String partName = (String)noConnectPartMap.get("name");
				String partRev = (String)noConnectPartMap.get("revision");
				hmNoAttributePart.put(partName+"|"+partRev, objectId);
			}
    		//

    		long startTime = System.currentTimeMillis();
    		System.out.println("cdmPartMigration : modifyPartCreate -StartTime:"+cdmCommonExcel.getTimeStamp2());
    		String logFileName = "ModifyPartAttribute";
    		
    	
//    		if(args.length!=1){
//    			throw new Exception("The excel path does not exist.");
//    		}
//    		
    		String sFileLocation 		= "";
    		String sFileName 			= "";
//    		String sFileLocationAndFileName = args[0];
//    		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
//    		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
    		//java application
    		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
    		String sFileLocationAndFileName = (String)paramMap.get("fileData");
    		
    		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
    		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
    		
    		logFileName +="_"+sFileName;
    		String[] argTest = {sFileLocation,sFileName}; // 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명  
    		  
    		String sPartInputDirectory = sFileLocation;

    		// documentDirectory does not ends with "/" add it
    		if(sPartInputDirectory != null && !sPartInputDirectory.endsWith(sfileSeparator))
    		{
    			sPartInputDirectory = sPartInputDirectory + sfileSeparator;
    		}
    		String sPartOutputDirectory = "";
    		// create a directory to add debug and error logs
    		sPartOutputDirectory = new File(sPartInputDirectory).getParentFile() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+  cdmCommonExcel.getTimeStamp() + sfileSeparator;
            File fileOutputDirectory = new File(sPartOutputDirectory);
            if(!fileOutputDirectory.isDirectory()){
            	fileOutputDirectory.mkdirs();
            }
    		logWriter 			 	= new BufferedWriter(new FileWriter(sPartOutputDirectory + logFileName + "_DebugLog.txt",true));
    		errorStream 			= new PrintStream(new FileOutputStream(new File(sPartOutputDirectory + logFileName + "_ErrorLog.txt")));

    		successLogFile  		= new File(sPartOutputDirectory + logFileName + "_SuccessLogs.log");
    		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

    		failedLogFile  			= new File(sPartOutputDirectory + logFileName + "_FailedLogs" + ".txt");
    		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
    		
    		shortErrorLogFile        = new File(sPartOutputDirectory + logFileName + "ShortErrorLogs" + ".txt");
    		shortErrorWriter         = new BufferedWriter(new FileWriter(shortErrorLogFile,true));
    		
    		String fileName = sFileName;
    		String tempStRowNum   = ""; //순번
    		String tempStPartNo   = ""; //엑셀의 PartNo
    		String tempStPartRevision   = ""; //엑셀의 PartNo
    		
    		int successCount = 0;
    		int failCount = 0;
    		boolean checkTriggerOff = false;
    		BufferedReader bufferReader = null;
    		writeSuccessToFile("LineNume(#) \t  PartNo. \t Revision \t error Org Project \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t No OPTION1 exists. \t No OPTION2 exists. \t No OPTION3 exists. \t  No OPTION4 exists. \t No OPTION5 exists \t  No OPTION6 exists \t EC information does not exist. \t No Part Family exist. \t attribute value ");
    		writeErrorToFile(sPartInputDirectory+fileName);
    		
    		writeMessageToConsole("====================================================================================");
    		writeMessageToConsole(" PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
    		writeMessageToConsole("	Reading input log file from : "+sPartInputDirectory+fileName);
    		writeMessageToConsole("	Writing Log files to: " + sPartInputDirectory );
    		writeMessageToConsole("====================================================================================\n");
    		boolean checkAddPart = false;
    		MqlUtil.mqlCommand(context, "history off");
    		try {
    			
    			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(sPartInputDirectory+fileName),"euc-kr"));
    			String data = "";  							// 텍스트 파일 라인정보담을 변수 
    			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
    			
    			/* cdmCommonCode lev2 object 검색 start  */
    			
    			// 12/2 start 
    			Map option1Map = getOptionCode(context,"Option1");
    			Map option2Map = getOptionCode(context,"Option2");
    			Map option3Map = getOptionCode(context,"Option3");
    			Map option4Map = getOptionCode(context,"Option4");
    			Map option5Map = getOptionCode(context,"Option5");
    			Map option6Map = getOptionCode(context,"Option6");
    			
    			Map vehicleCommonCodeMap = getVehicleCode(context,"Vehicle");
    			Map productGroupMap = getProductGroupCode(context,"Product Group Name");
    			Map productDivMap = getProductDivCode(context,"Product Div");
    			Map projectMap = getProjectCode(context,"cdmProjectGroupObject");
    			Map partFamilyMap = getPartFamilyId(context);
    			
    			/*cdmCommonCode lev2 object 검색 end */ 
    			
    			String strLanguage = context.getLocale().getLanguage();
    			
    			AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
    			attrPartGlobal.open(context);
    			StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
    			attrPartGlobal.close(context);
    			StringList attrPartGlobalKOList = new StringList();
    			attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
    			
    			
    			AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
    			attrPartItemType.open(context);
    			StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
    			attrPartItemType.close(context);
    			StringList attrPartItemTypeKOList = new StringList();
    			attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
    			
    			
    			AttributeType attrPartERPInterface = new AttributeType("cdmPartERPInterface");
    			attrPartERPInterface.open(context);
    			StringList attrPartERPInterfaceList = attrPartERPInterface.getChoices(context);
    			attrPartERPInterface.close(context);
    			StringList attrPartERPInterfaceKOList = new StringList();
    			attrPartERPInterfaceKOList = i18nNow.getAttrRangeI18NStringList("cdmPartERPInterface", attrPartERPInterfaceList, strLanguage);
    			
    			AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
    			attrPartType.open(context);
    			StringList attrPartTypeList = attrPartType.getChoices(context);
    			attrPartType.close(context);
    			StringList attrPartTypeKOList = new StringList();
    			attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
    			
    			HashMap tempUOMHMap = new HashMap();
    			tempUOMHMap.put("EA"  , "Each");
    			tempUOMHMap.put("BAG" , "bag");
    			tempUOMHMap.put("BTL" , "bottle");
    			tempUOMHMap.put("BOX" , "box");
    			tempUOMHMap.put("CC"  , "cc");
    			tempUOMHMap.put("CMM" , "mm³");
    			tempUOMHMap.put("CMT" , "m³");
    			tempUOMHMap.put("CN"  , "can");
    			tempUOMHMap.put("CT"  , "carton");
    			tempUOMHMap.put("DL"  , "dl");
    			tempUOMHMap.put("DZ"  , "dozen");
    			tempUOMHMap.put("FT"  , "ft");
    			tempUOMHMap.put("GLL" , "gallon");
    			tempUOMHMap.put("G"   , "g");
    			tempUOMHMap.put("IN"  , "inch");
    			tempUOMHMap.put("KG"  , "kg");
    			tempUOMHMap.put("KMT" , "km");
    			tempUOMHMap.put("L"   , "L");
    			tempUOMHMap.put("LBR" , "lb");
    			tempUOMHMap.put("M"   , "m");
    			tempUOMHMap.put("MGR" , "mg");
    			tempUOMHMap.put("ML"  , "ml");
    			tempUOMHMap.put("MMT" , "mm");
    			tempUOMHMap.put("MT"  , "ton");
    			tempUOMHMap.put("N"   , "N");
    			tempUOMHMap.put("PC"  , "Piece");
    			tempUOMHMap.put("PL"  , "Pl");
    			tempUOMHMap.put("ROL" , "Roll");
    			tempUOMHMap.put("SET" , "Set");
    			tempUOMHMap.put("SH"  , "Sheet");
    			tempUOMHMap.put("SM"  , "m²");
    			tempUOMHMap.put("UN"  , "unit");
    			tempUOMHMap.put("DRM" , "drum");
    			
    			int lineNumber = 1;      
    			int subPartCount = 0;
    			
    			String strPreviousPartNo = null;
    			String strPreviousPartRevision = null;
    			String strPreviousPartType = null;
    			
    			
    			while ((data = bufferReader.readLine()) != null) {
    				
    				StringBuffer sbErrorMessage = new StringBuffer("");
    				MqlUtil.mqlCommand(context, "trigger off");
    				checkTriggerOff = true;
    				checkAddPart = false;
    				StringList stListData = FrameworkUtil.split(data, "\t");
    				try {
    					
    					if (lineNumber == 1) {
    						stListHeader = stListData;
    						writeFailToFile("errorRecord \t"+data);
    						lineNumber++;
    						continue;
    					}
    					lineNumber++;
    					
    					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
    					int size_Data = stListData.size();
    					int size_Header = stListHeader.size();
    					if (size_Data != size_Header) {
    						String errorMessage = " NOT MATCH DATA FIELD";
//    						throw new Exception(errorMessage);
    						writeFailToFile("errorRecord \t 5 \t"+data);
    						continue;
    					}

    					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {

    						String sPartInfos = cdmCommonExcel.isVaildNullData((String)stListData.get(stListNum));
    						String sPartHeader = ((String) stListHeader.get(stListNum)).trim();
    						partHM.put(sPartHeader, sPartInfos);
    						
    					}
    					
    					String stPartType                   = TYPE_CDMMECHANICALPART;  
    					String stPartCount                  = ((String)partHM.get("#"            		        )).trim(); // 1 순번 
    					String stCLS_NAME                   = ((String)partHM.get("CLS_NAME"                    )).trim(); // 2 
    					String stOBJECT_ID                  = ((String)partHM.get("OBJECT_ID"                   )).trim(); // 3 //받은 자료에 unique 값 migration대상아님 
    	
    					String stCN_ID                      = ((String)partHM.get("CN_ID"  	                    )).trim(); // 5 Name
    					String stREVISION                   = ((String)partHM.get("REVISION"                    )).trim(); // 6 Revision
    					String stSTATE                      = ((String)partHM.get("STATE"                       )).trim(); // 7 State
    					String stCREATION_DATE              = ((String)partHM.get("CREATION_DATE"               )).trim(); // 8  attribute[cdmPartCreationDateM]
    					String stUSER_OBJECT_ID             = ((String)partHM.get("USER_OBJECT_ID"              )).trim(); // 9  attribute[cdmPartCreationUserIdM]
    					String stUSER_ID_MOD                = ((String)partHM.get("USER_ID_MOD"                 )).trim(); // 10 attribute[cdmPartModUserIdM]
    					String stMODIFICATION_DATE          = ((String)partHM.get("MODIFICATION_DATE"           )).trim(); // 11 attribute[cdmPartModificationDateM] 
    					String stTDM_DESCRIPTION            = ((String)partHM.get("TDM_DESCRIPTION"             )).trim(); // 12 attribute[cdmPartName]
    					String stTDM_UOM                    = ((String)partHM.get("TDM_UOM"  			        )).trim(); // 13 attribute[cdmPartUOM]
    					String stPhaseM                     = ((String)partHM.get("PHASE"                       )).trim(); // 14 
    					String stPAR_REVISION               = ((String)partHM.get("PAR_REVISION"                )).trim(); // 15 Previous Revision
    	//				String stAPPROVAL_DATE              = ((String)partHM.get("APPROVAL_DATE"               )).trim(); // 16 
    	//				String stREVISION_STG               = ((String)partHM.get("REVISION_STG"                )).trim(); // 17 
    					String stTDM_ORG_USER_ID            = ((String)partHM.get("TDM_ORG_USER_ID"             )).trim(); // 18 First Revision creator
    	//				String stTDM_ORG_CREATEDATE         = ((String)partHM.get("TDM_ORG_CREATEDATE"          )).trim(); // 19 
    	//				String stTDM_APPROVED_BY            = ((String)partHM.get("TDM_APPROVED_BY"             )).trim(); // 20 
    	//				String stTDM_ORIGIN_ID              = ((String)partHM.get("TDM_ORIGIN_ID"               )).trim(); // 21 
    					String stCN_PROJECT                 = ((String)partHM.get("CN_PROJECT"                  )).trim(); // 22 PROJECT
    					String stCN_PROJECT_CUST            = ((String)partHM.get("CN_PROJECT_CUST"             )).trim(); // 23 PROJECT_CUST
    	//				String stCN_PRODUCT_NAME            = ((String)partHM.get("CN_PRODUCT_NAME"             )).trim(); // 24 
    	//				String stCN_PART_GROUP              = ((String)partHM.get("CN_PART_GROUP"               )).trim(); // 25 
    	//				String stCN_PART_NAME               = ((String)partHM.get("CN_PART_NAME"                )).trim(); // 26
    	//				String stCN_WEIGHT                  = ((String)partHM.get("CN_WEIGHT"                   )).trim(); // 27
    					String stCN_ESTIMATED_WEIGHT        = ((String)partHM.get("CN_ESTIMATED_WEIGHT"         )).trim(); // 28 attribute[cdmPartEstimatedWeight] 
    					String stCN_WEIGHT_UNIT             = ((String)partHM.get("CN_WEIGHT_UNIT"              )).trim(); // 29
    					String stCN_TOP_ITEM                = ((String)partHM.get("CN_TOP_ITEM"                 )).trim(); // 30
    					String stCN_PHANTOM_ITEM            = ((String)partHM.get("CN_PHANTOM_ITEM"             )).trim(); // 31
    					String stCN_ITEM_TYPE               = ((String)partHM.get("CN_ITEM_TYPE"                )).trim(); // 32
    					String stCN_SERVICE_ITEM            = ((String)partHM.get("CN_SERVICE_ITEM"             )).trim(); // 33
    					String stCN_ITEM_MATERIAL           = ((String)partHM.get("CN_ITEM_MATERIAL"            )).trim(); // 34
    					String stCN_ITEM_UPDATE_FROM_ERP    = ((String)partHM.get("CN_ITEM_UPDATE_FROM_ERP"     )).trim(); // 35
    					String stCN_COST                    = ((String)partHM.get("CN_COST"                     )).trim(); // 36
    					String stCN_CURRENCY                = ((String)partHM.get("CN_CURRENCY"                 )).trim(); // 37
    					//String stCN_COMMENTS              = ((String)partHM.get("CN_COMMENTS"                 )).trim(); // 38
    					String stCN_OEM_PART_NUMBER         = ((String)partHM.get("CN_OEM_PART_NUMBER"          )).trim(); // 39
    					String stEC_NAME                    = ((String)partHM.get("EC_NAME"                     )).trim(); // 40
    					String stCN_ECO_NUMBER              = ((String)partHM.get("CN_ECO_NUMBER"               )).trim(); // 41
    					String stCN_PRODUCT_GROUP           = ((String)partHM.get("CN_PRODUCT_GROUP"            )).trim(); // 42
    					String stCN_SERIES_ITEM             = ((String)partHM.get("CN_SERIES_ITEM"              )).trim(); // 43
    					String stCN_VEHICLE                 = ((String)partHM.get("CN_VEHICLE"                  )).trim(); // 44
    					String stCN_CUSTOMER                = ((String)partHM.get("CN_CUSTOMER"                 )).trim(); // 45
    					String stCN_SIZE                    = ((String)partHM.get("CN_SIZE"                     )).trim(); // 46
    					String stCN_SURFACE_TREATMENT       = ((String)partHM.get("CN_SURFACE_TREATMENT"        )).trim(); // 47
    					String stCN_SURFACE_AREA            = ((String)partHM.get("CN_SURFACE_AREA"             )).trim(); // 48
    					String stCN_ITEM_TYPE1              = ((String)partHM.get("CN_ITEM_TYPE1"               )).trim(); // 49
    					String stCN_MATERIAL               = ((String)partHM.get("CN_MATERIAL"                  )).trim(); // 50
    					String stCN_ORG1                   = ((String)partHM.get("CN_ORG1"                      )).trim(); // 51  migration 대상 제외  
    	//				String stCN_ORG2                   = ((String)partHM.get("CN_ORG2"                      )).trim(); // 52  migration 대상 제외 
    	//				String stCN_ORG3                   = ((String)partHM.get("CN_ORG3"                      )).trim(); // 53  migration 대상 제외 
    					String stCN_ORG                    = ((String)partHM.get("CN_ORG"                       )).trim(); // 54  MCA Org
    					String stCN_MCA_INOUT              = ((String)partHM.get("CN_MCA_INOUT"                 )).trim(); // 55  MCA BOM Management
    					String stCN_MCA_PART_TYPE_REF      = ((String)partHM.get("CN_MCA_PART_TYPE_REF"         )).trim(); // 56  MCA Part Type
    					String stCN_OPTION1                = ((String)partHM.get("CN_OPTION1"                   )).trim(); // 57
    					String stCN_OPTION2                = ((String)partHM.get("CN_OPTION2"                   )).trim(); // 58
    					String stCN_OPTION3                = ((String)partHM.get("CN_OPTION3"                   )).trim(); // 59
    					String stCN_OPTION4                = ((String)partHM.get("CN_OPTION4"                   )).trim(); // 60
    					String stCN_OPTION5                = ((String)partHM.get("CN_OPTION5"                   )).trim(); // 61
    					String stCN_OPTION6                = ((String)partHM.get("CN_OPTION6"                   )).trim(); // 62
    					String stCN_OPTION7                = ((String)partHM.get("CN_OPTION7"                   )).trim(); // 63
    					String stCN_OPTION_ETC             = ((String)partHM.get("CN_OPTION_ETC"                )).trim(); // 64
    					String stCN_IS_CASTING             = ((String)partHM.get("CN_IS_CASTING"                )).trim(); // 65
    					String stCN_OPTION_DESC            = ((String)partHM.get("CN_OPTION_DESC"               )).trim(); // 66
    					String stCN_FOR_MAC                = ((String)partHM.get("CN_FOR_MAC"                   )).trim(); // 67
    					String stCN_FOR_MIL                = ((String)partHM.get("CN_FOR_MIL"                   )).trim(); // 68
    					String stCN_FOR_MIS                = ((String)partHM.get("CN_FOR_MIS"                   )).trim(); // 69
    					String stCN_FOR_MMT                = ((String)partHM.get("CN_FOR_MMT"                   )).trim(); // 70
    					String stCN_REAL_WEIGHT            = ((String)partHM.get("CN_REAL_WEIGHT"               )).trim(); // 71
    					String stCN_COUNTRY                = ((String)partHM.get("CN_COUNTRY"                   )).trim(); // 72
    					String stCN_PRODUCT_DIV            = ((String)partHM.get("CN_PRODUCT_DIV"               )).trim(); // 73
    					String stCN_GLOBAL_LOCAL           = ((String)partHM.get("CN_GLOBAL_LOCAL"              )).trim(); // 74
    					String stCN_PROJECT_CODE           = ((String)partHM.get("CN_PROJECT_CODE"              )).trim(); // 75
    					String stCN_OPTION_DRAWING         = ((String)partHM.get("CN_OPTION_DRAWING"            )).trim(); // 76
    					String stCN_FOR_DRAWING_FINISH     = ((String)partHM.get("CN_FOR_DRAWING_FINISH"        )).trim(); // 77
    					String stCN_FOR_DRAWING_SIZE       = ((String)partHM.get("CN_FOR_DRAWING_SIZE"          )).trim(); // 78
    					String stCN_FOR_DRAWING_REMARK     = ((String)partHM.get("CN_FOR_DRAWING_REMARK"        )).trim(); // 79
    					String stCN_ITEM_TYPE2              = ((String)partHM.get("CN_ITEM_TYPE2"               )).trim(); // 80
    					String stCN_APPLY_PARTLIST          = ((String)partHM.get("CN_APPLY_PARTLIST"           )).trim(); // 81
//    					String stCN_PREVIOUS_PART           = ((String)partHM.get("CN_PREVIOUS_PART"            )).trim(); // 82
    					String stCN_COMPLEX_BODY            = ((String)partHM.get("CN_COMPLEX_BODY"             )).trim(); // 83
    					String stCN_MAIN_PART_NUMBER        = ((String)partHM.get("CN_MAIN_PART_NUMBER"         )).trim(); // 84
    					String stCN_VEHICLE_DESC            = ((String)partHM.get("CN_VEHICLE_DESC"             )).trim(); // 85 VEHICLE 
    					String stCN_VEHICLE_CODE            = ((String)partHM.get("CN_VEHICLE_CODE"             )).trim(); // 86
    					String stVehicle_Cust               = ((String)partHM.get("VEHICLE_CUST"                )).trim(); // 87
    					String stCN_DRAWING_NO              = ((String)partHM.get("CN_DRAWING_NO"               )).trim(); // 88 DRAWING_NO
    					String stCN_SUB_ID         		    = ((String)partHM.get("CN_SUB_ID"                   )).trim(); // 89
    	//				//String stCN_CHANGE_REASON 	        = ((String)partHM.get("CN_CHANGE_REASON"            )).trim(); // 90 다른 데이타 파일로 진행 예정 
    					String stCN_SURFACE_TREATMENT_KEYIN = ((String)partHM.get("CN_SURFACE_TREATMENT_KEYIN"  )).trim(); // 91
    					String stCN_OVERSEAS_ORG6           = ((String)partHM.get("CN_OVERSEAS_ORG6"            )).trim(); // 92
    					String stCN_OVERSEAS_ORG6_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG6_PART_TYPE"  )).trim(); // 93
    					String stCN_OVERSEAS_ORG6_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG6_INOUT"      )).trim(); // 94
//    					String stCN_OVERSEAS_ORG7           = ((String)partHM.get("CN_OVERSEAS_ORG7"            )).trim(); // 95
//    					String stCN_OVERSEAS_ORG7_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG7_PART_TYPE"  )).trim(); // 96
//    					String stCN_OVERSEAS_ORG7_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG7_INOUT"      )).trim(); // 97

    					String stCN_Project_Id			    = ((String)partHM.get("CN_PROJECT_ID"  )).trim(); // 98
    					String stAccessProductGroup		    = ((String)partHM.get("PROD_GROUP"  )).trim(); // 98
    					String stAceesOrg				    = ((String)partHM.get("CN_CUST_VEHICLE"  )).trim(); // 98
    					if("-".equals(stAceesOrg)){
    						stAceesOrg = "";
    					}
    					//
    					String sNotExistAttInfoPart= (String)hmNoAttributePart.get(stCN_ID+"|"+stREVISION);
    					sNotExistAttInfoPart = cdmCommonExcel.isVaildNullData(sNotExistAttInfoPart);
    					if(UIUtil.isNullOrEmpty(sNotExistAttInfoPart)){
    						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+  data ) ;
    						continue;
//    						failedObjectidWriter
    						
    					}
    					
    					
    					String stCADWeight					= ""; 
    					String stGLOBAL_LOCAL = "";
    					String stITEM_TYPE2 = "";
    					String stFOR_DRAWING_REMARK = "";
    					String stOPTION_ETC = "";
    					String stOPTION_DESC = "";
    					String stPartInvestor =   "";
    					String stESTIMATED_WEIGHT = "";
    					String stITEM_TYPE1 = "";
    					String stITEM_TYPE = "";
    					String stSERIES_ITEM = "";
    					String stPhase = "";
    					
    					String stPartCADWeight = ""; /*아직 데이타가 없음 속성 정보 재요청 필요 */
    					subPartCount = Integer.parseInt(stPartCount);
    					tempStRowNum = stPartCount;
    					tempStPartNo = stCN_ID;
    					tempStPartRevision = stREVISION;
    					String personIdMql = "temp query bus Person '" + stTDM_ORG_USER_ID + "' - select id dump |";
    					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
    					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
    					String stPerson = "";
    					boolean boolPerson = false;
    					if (stListPersonIdMql.size() > 2) {
    						stPerson = (String) stListPersonIdMql.get(3);
    						boolPerson = true;
    					}
    					
    					/* ***************************************************************************************
    					 * stCN_VEHICLE_DESC 은 다중으로 존재가능하며 구분은 , 로 한다. 
    					 * ************************************************************************************** */
    					
    					
    					/*  **************************************************************************************
    					 *   stCLS_NAME 정보가 "Option Item" 이라면 CN_SUB_ID 정보를 CN_ID에 합쳐야한다. 
    					 *  ************************************************************************************ */
    					if("Option Item".equalsIgnoreCase(stCLS_NAME)){
    						if(cdmStringUtil.isNotEmpty(stCN_SUB_ID)){
    							stCN_ID +=stCN_SUB_ID;
    						}
    					}
    					
    					/* **************************************************************************************
    					 * cdmPartGlobal 의 정보는 global,local 값이 없으면 ""  처리 
    					 * ************************************************************************************* */
    					for (int i = 0; i < attrPartGlobalKOList.size(); i++) {
    	
    						if (stCN_GLOBAL_LOCAL.equalsIgnoreCase((String) attrPartGlobalKOList.get(i))) {
    							stGLOBAL_LOCAL = (String) attrPartGlobalList.get(i);
    							break;
    						}
    					}
    					if(cdmStringUtil.isEmpty(stGLOBAL_LOCAL)){
    						stGLOBAL_LOCAL = "";
    					}
    					
    					/*  **************************************************************************************
    					 *   stCN_ITEM_TYPE2 의 정보는 
    					 *   attribute[cdmPartItemType]관련 정보
    					 *   
    					 *   attribute[cdmPartItemType]의 display name과 일치하지않다면 에러 처리  
    					 *  ************************************************************************************** */
    					boolean bITEM_TYPE2 = false;
    					for (int i = 0; i < attrPartItemTypeKOList.size(); i++) {
    	
    						if (stCN_ITEM_TYPE2.equals((String) attrPartItemTypeKOList.get(i))) {
    							stITEM_TYPE2 = (String) attrPartItemTypeList.get(i);
    							bITEM_TYPE2 = true;
    							break;
    						}
    						
    					}
    					
    					/* *****************************************************************************************
    					 * stCN_FOR_DRAWING_REMARK 의 정보는 Part 의 한글 속성과 일치하다고 가정하여 진행 
    					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
    					 * *****************************************************************************************/
    					if(cdmStringUtil.isNotEmpty(stCN_FOR_DRAWING_REMARK) ){
    						//
    						for (int i = 0; i < attrPartERPInterfaceKOList.size(); i++) {
    	
    							if (stCN_FOR_DRAWING_REMARK.equals((String) attrPartERPInterfaceKOList.get(i))) {
    								stFOR_DRAWING_REMARK = (String) attrPartERPInterfaceList.get(i);
    								break;
    							}
    						}
    					}
    					
    					
    					String sTempUOM = "";
    					sTempUOM= (String)tempUOMHMap.get(stTDM_UOM);
    					sTempUOM = cdmCommonExcel.isVaildNullData(sTempUOM);
    					
    					/* ******************************************************************************************************************
    					 * stPartInvestor 의경우 
    					 * stCN_FOR_MAC ,stCN_FOR_MIL,stCN_FOR_MMT 의 정보가 checked 되어 있는지여부를 확인하여 하나의 String 값으로 만듬 
    					 * 
    					 * ****************************************************************************************************************   */
    					if("Checked".equals(stCN_FOR_MAC)){
    						stPartInvestor = "MAC";
    					}
    					if("Checked".equals(stCN_FOR_MIL)){
    						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
    							stPartInvestor +=",";
    						}
    						stPartInvestor += "MIL";
    					}
    					if("Checked".equals(stCN_FOR_MMT)){
    						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
    							stPartInvestor +=",";
    						}
    						stPartInvestor += "MMT";
    					}
    	
    					
    					/* ******************************************************************************************************************
    					 * attribute[Estimated Weight]의 중량단위  
    					 * g 이며 plm의 경우 kg 이므로 변환 
    					 * ****************************************************************************************************************** */
    					
    					if("".equals(stCN_WEIGHT_UNIT)){
    						stCN_WEIGHT_UNIT = "g";
    						//kg 으로 단위 변환 필요 !!
    						if(cdmStringUtil.isNotEmpty(stCN_ESTIMATED_WEIGHT)){
    							Integer inESTIMATED_WEIGHT = Integer.parseInt(stCN_ESTIMATED_WEIGHT);
    							
    							if(inESTIMATED_WEIGHT > 0 || inESTIMATED_WEIGHT < 0 ){
    								stESTIMATED_WEIGHT = String.valueOf(inESTIMATED_WEIGHT/1000);
    							}
    							
    						}
    					}else if(!"kg".equalsIgnoreCase(stCN_WEIGHT_UNIT) && !"".equals(stCN_ESTIMATED_WEIGHT)){
    						//중량단위를 kg로 변환 !!
    						Double doubleESTIMATED_WEIGHT = Double.parseDouble(stCN_ESTIMATED_WEIGHT);
    						if("g".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
    							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
    								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT/1000);
    							}
    						}else if("lb".equals(stCN_WEIGHT_UNIT)){
    							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
    								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(2204.62));
    							}
    						}else if("mg".equals(stCN_WEIGHT_UNIT)){
    							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
    								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(1000000));
    							}
    						}else if("ton".equals(stCN_WEIGHT_UNIT)){
    							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
    								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(1000));
    							}
    						}else if("N".equals(stCN_WEIGHT_UNIT)){
    							if(doubleESTIMATED_WEIGHT > 0 || doubleESTIMATED_WEIGHT < 0 ){
    								stESTIMATED_WEIGHT = String.valueOf(doubleESTIMATED_WEIGHT*(0.102));  //힘의 단위로 변환한것임 문의할것 
    							}
    						}
    					}
    					/* *************************************************************************************
    					 *   stCN_PHANTOM_ITEM 가 체크되어있으면 파트 타입으로 "Phantom Part"변경
    					 *   stPhase 여부와 상관없이 반드시 Proto 로 변경된다. 
    					 * *********************************************************************************** */
    					if("PROTO".equalsIgnoreCase(stCN_ORG1)){
    						stPhase = S_ATTRIBUTE_PHASE_PROTO;
    					}else{
    						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
    					}
    					
    					if( "Checked".equalsIgnoreCase(stCN_PHANTOM_ITEM) &&  "PROTO".equalsIgnoreCase(stCN_ORG1)){
    						stPartType = "cdmPhantomPart";
    						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
    					}
    					
    					
    					/* *************************************************************************************
    					 * stITEM_TYPE1 은  cdmPartApprovalType 속성 정보와 일치 여부 확인 후
    					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
    					 * *********************************************************************************** */
    					
    						
    					if("자작".equals(stITEM_TYPE1)){
    						stITEM_TYPE1 = "inSourcing";
    					}else if("외주".equals(stITEM_TYPE1)){
    						stITEM_TYPE1 = "outSourcing";
    					}else{
    						stITEM_TYPE1 = "";
    					}
    					
    					
    					
    					/* *************************************************************************************
    					 * stITEM_TYPE 은  cdmPartType 속성 정보와 일치 여부 확인 후
    					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
    					 * *********************************************************************************** */
    					stITEM_TYPE = "";
    					for (int attrPartTypeNum = 0; attrPartTypeNum < attrPartTypeKOList.size(); attrPartTypeNum++) {
    						String temPattrPartTypeKO = (String) attrPartTypeKOList.get(attrPartTypeNum);
    						if (stCN_ITEM_TYPE.equals(temPattrPartTypeKO)) {
    							stITEM_TYPE = (String) attrPartTypeList.get(attrPartTypeNum);
    							break;
    						}
    					}
    	
    					
    					/* *************************************************************************************
    					 * SERIES_ITEM 값이 Checked 이면 true unChecked 이면 false 
    					 * *********************************************************************************** */
    					if("Checked".equalsIgnoreCase(stCN_SERIES_ITEM)){
    						stSERIES_ITEM = "true"; 
    					}else{
    						stSERIES_ITEM = "false";
    					}
    					
    					/*stCN_SURFACE_TREATMENT 은 사용되지않아 "" 처리한다. */
    					String stSURFACE_TREATMENT = ""; 
    					
    					/*stCN_IS_CASTING*/
    					String stIS_CASTING = "";
    					if(!"0".equals(stCN_IS_CASTING)){
    						stIS_CASTING = "yes";
    					}else{
    						stIS_CASTING = "no";
    					}
    					
    					
    					/*stCN_FOR_DRAWING_FINISH*/
    					String stCFOR_DRAWING_FINISH = "";
    					if("0".equals(stCN_FOR_DRAWING_FINISH)){
    						stCFOR_DRAWING_FINISH = "unChecked";
    					}else{
    						stCFOR_DRAWING_FINISH = "Checked";
    					}
    					
    					/*stCN_FOR_DRAWING_SIZE*/
    					String stDRAWING_SIZE = "";
    					if("0".equals(stCN_FOR_DRAWING_SIZE)){
    						stDRAWING_SIZE = "unChecked";
    					}else{
    						stDRAWING_SIZE = "Checked";
    					}
    					
//    					stTDM_UOM = new String(stTDM_UOM.getBytes("utf-8"), "euc-kr");
//    					stPhaseM = new String(stPhaseM.getBytes("euc-kr"), "utf-8");
    					HashMap attributes = new HashMap();
    					if(UIUtil.isNotNullAndNotEmpty(stPhaseM)){
    						attributes.put("cdmPartPhaseM", 		 	  stPhaseM		                   );
    					}
//    					System.out.println("cdmPartUOM :" +stTDM_UOM);
    			        attributes.put("cdmPartNo",          	      stCN_ID 			               );
    			        attributes.put("cdmPartVehicle", 	 	      stCN_VEHICLE_DESC		           );
    			        attributes.put("cdmPartName", 		 	      stTDM_DESCRIPTION	               );
    			        attributes.put("cdmPartProject", 	 	      stCN_PROJECT		               );
    			        attributes.put("cdmPartApprovalType", 	      stITEM_TYPE1	                   );
    			        attributes.put("cdmPartType", 		          stITEM_TYPE	                   );
    			        attributes.put("cdmPartGlobal", 			  stGLOBAL_LOCAL                   );
    			        attributes.put("cdmPartDrawingNo", 			  stCN_DRAWING_NO                  );
//    			        attributes.put("cdmPartUOM",     		      stTDM_UOM                        );
    			        attributes.put("cdmPartUOM",     		      sTempUOM                        );
//    			        데이타가 깨진것이 있어 추후 cdmPartUOM 값을 변경해야함 12/06/16 12:19:00 이후 마이그레이션 대상으로
//    			        attributes.put("cdmPartUOM_TempM",     		      stTDM_UOM                        );
    			        attributes.put("cdmPartECONumber", 			  stCN_ECO_NUMBER                  );
    			        attributes.put("cdmPartItemType", 			  stCN_ITEM_TYPE2                  );
    			        attributes.put("cdmPartOEMItemNumber", 		  stCN_OEM_PART_NUMBER             );
    			        attributes.put("cdmPartProductType", 		  stCN_PRODUCT_DIV                 );
    			        attributes.put("cdmPartERPInterface", 		  stFOR_DRAWING_REMARK             );
    			        attributes.put("cdmPartSurface", 			  stCN_SURFACE_AREA                );
    			        attributes.put("cdmPartEstimatedWeight", 	  stESTIMATED_WEIGHT               );
    			        attributes.put("cdmPartMaterial", 			  stCN_ITEM_MATERIAL               );
    			        attributes.put("cdmPartRealWeight", 		  stCN_REAL_WEIGHT                 );
    			        attributes.put("cdmPartSize", 				  stCN_SIZE                        );
    			        attributes.put("cdmPartCADWeight", 			  stPartCADWeight                  );
    			        attributes.put("cdmPartSurfaceTreatment", 	  stSURFACE_TREATMENT              );
    			        attributes.put("cdmPartIsCasting", 			  stIS_CASTING                     );
    			        attributes.put("cdmPartOption1", 			  stCN_OPTION1                     );
    			        attributes.put("cdmPartOption2", 			  stCN_OPTION2                     );
    			        attributes.put("cdmPartOption3", 			  stCN_OPTION3                     );
    			        attributes.put("cdmPartOption4", 			  stCN_OPTION4                     );
    			        attributes.put("cdmPartOption5", 			  stCN_OPTION5                     );
    			        attributes.put("cdmPartOption6", 		   	  stCN_OPTION6                     );
    			        attributes.put("cdmPartOptionETC",         	  stOPTION_ETC               	   );
    			        attributes.put("cdmPartOptionDescription", 	  stOPTION_DESC            		   );
    			        attributes.put("cdmPartPublishingTarget",     stCN_COST                        );
    			        attributes.put("cdmPartInvestor",          	  stPartInvestor                   );
    			        attributes.put("cdmPartProjectType",          stCN_PRODUCT_GROUP               ); // 
//    			        attributes.put("cdmPartProductDivision",      stCN_PRODUCT_GROUP               ); //?? 확인 작업이 필요 
    					
    			        /*migration을 작업을 위해 attribute 추가 start */
    			        attributes.put("cdmPartItemOtionItemM",        stCLS_NAME                      );
    			        attributes.put("cdmPartPreviousRevisionM",     stPAR_REVISION                  );
    			        attributes.put("cdmPartCheckPhantomPartM",     stCN_PHANTOM_ITEM   	           );
    			        attributes.put("cdmPartECNameM",               stEC_NAME    	               );
    			        attributes.put("cdmPartSeriesItemM",           stSERIES_ITEM                   );
    			        attributes.put("cdmPartMCAOrgM",               stCN_ORG      	               );
    			        attributes.put("cdmPartMCABOMManagementM",     stCN_MCA_INOUT        	       );
    			        attributes.put("cdmPartMCAPartTypeM",          stCN_MCA_PART_TYPE_REF          );
    			        attributes.put("cdmPartOption7",          	   stCN_OPTION7                    );
    			        attributes.put("cdmPartCountryM",          	   stCN_COUNTRY                    );
    			        attributes.put("cdmPartDrawingFinishM",        stCFOR_DRAWING_FINISH           );
    			        attributes.put("cdmPartDrawingSizeM",          stDRAWING_SIZE                  );
    			        attributes.put("cdmPartApplyPartListM",        stCN_APPLY_PARTLIST             );
    			        attributes.put("cdmPartSubIdM",                stCN_SUB_ID                     );
    			        attributes.put("cdmPartMCPOrgM",          	   stCN_OVERSEAS_ORG6              );
    			        attributes.put("cdmPartMCPPartTypeM",          stCN_OVERSEAS_ORG6_PART_TYPE    );
    			        attributes.put("cdmPartMCPBOMManagementM",     stCN_OVERSEAS_ORG6_INOUT 	   );  
    			        attributes.put("cdmPartCreationDateM",        stCREATION_DATE     	           );  
    			        attributes.put("cdmPartCreationUserIdM",      stUSER_OBJECT_ID  	           );  
    			        attributes.put("cdmPartModUserIdM",           stUSER_ID_MOD  	               );  
    			        attributes.put("cdmPartModificationDateM",    stMODIFICATION_DATE  	           );  
    			        attributes.put("cdmPartComplexBodyForRealWeightM",  stCN_COMPLEX_BODY          );
    			        attributes.put("cdmCheckMigration",           "Y"					  	       );
    			        attributes.put("cdmPartPhase",           	   stPhase			  	       	   );
    			        //add attribute 11/17/2016 start 
    			        attributes.put("cdmPartApplyPartList",           "true"				  	       );
    			        attributes.put("cdmPartApplySizeList",           "false"			  	       );
    			        attributes.put("cdmPartApplySurfaceTreatmentList", "false"	  				   );
    			        //add attribute 11/17/2016 end 
    			        
    			        /*migration을 작업을 위해 attribute 추가 end  */
    			        
    			      
    			        /* **********************************************************************************************************************
    			         * part 데이타 생성 및 데이타 
    			         * 트리거 오프한 상태로 진행되며 트리거에서 제공되는 attribute[originator]속성 및 interface 추가 설정 필터 정보 와 
    			         * rev 정보 part master 생성 및 연결 및 속성(attribute[Originator]속성 추가 
    			         * 에러 발생시 정지 및 데이타 정보 검색 
    			         * ******************************************************************************************************************* */
    			        
//    			        DomainObject partObj = new DomainObject();
    			        boolean bCommit = false;
    			        DomainObject partObj = new DomainObject();
    			        partObj.setId(sNotExistAttInfoPart);
    			        ContextUtil.startTransaction(context, true);
    			        bCommit = true;
    			        boolean bNewPartCheck = false;
    			        boolean reviseCheck = false;
    			        
    			        
    					
    					if ("In Approval".equals(stSTATE)) {
    						stSTATE = "Review";
    						
    					} else if ("Inactive".equals(stSTATE)) {
    						stSTATE = "Obsolete";
    						
    					}else if ("Released".equals(stSTATE)) {
    						stSTATE = "Release";
    							
    						
    					}else if ("In Work".equals(stSTATE)) {
    						stSTATE = "Preliminary";
    					}
    					
    					partObj.setState(context, stSTATE);
    					
    					String partObjectId = partObj.getId(context);

    					if(boolPerson){
    						partObj.setOwner(context, stTDM_ORG_USER_ID); 
    					}
    					
    					
    		
    						/*
    						 * *********************************************************
    						 * attribute[attribute_Originator]
    						 * 의 정보를stTDM_ORG_USER_ID 정보를 입력.
    						 * *********************************************************
    						 * 
    						 */
    						partObj.setAttributeValue(context, DomainConstants.ATTRIBUTE_ORIGINATOR, stTDM_ORG_USER_ID);
    						
    						/* part Master 생성 start */
//    						createPartMaster(context, partObjectId, stTDM_ORG_USER_ID,boolPerson);
    						/* part Master 생성 end */
    		
    						/* create 시 발생하는 trigger에서 사용된 정보 interface 생성 end */
    		
    						/*
    						 * *********************************************************
    						 * 
    						 *  EBOM 정보로 연결된 Part 을 생성할시 relationship 연결을 제외된다.
    						 * 또한 relationship 연결의 경우 공통코드 데이타가 PLM에 스마트팀 정보가 다 있다고 가정하여
    						 * 진행 공통코드를 검색하여 데이타가 없을시 오류 처리 . 오류가 발생하면 Exception 발생.
    						 * *********************************************************
    						 */
    		
    					partObj.setAttributeValues(context, attributes);
    					/* sbECONumberId */
    					StringBuffer sbECONumberId = new StringBuffer("");
//    					if (cdmStringUtil.isNotEmpty(stCN_ECO_NUMBER)) {
//    						StringBuffer sbfECType = new StringBuffer();
//    						sbfECType.append("cdmECO");
//    						sbfECType.append(",");
//    						sbfECType.append("cdmEAR");
//    						sbfECType.append(",");
//    						sbfECType.append("cdmDCR");
//    						sbfECType.append(",");
//    						sbfECType.append("cdmPEO");
//    						
//    						
//    						String stTempECExist = "temp query bus \"" + sbfECType.toString() + "\" \""+stCN_ECO_NUMBER +"\"  *  select id dump |";
//    						String stTempECExistMql = MqlUtil.mqlCommand(context, stTempECExist);
//    						StringList sListTempECExistMql = FrameworkUtil.split(stTempECExistMql, "|");
//    						if (sListTempECExistMql.size() > 2) {
//    							sbECONumberId.append(sListTempECExistMql.get(3));
//    							sbErrorMessage.append("X").append("\t");
//    						} else {
//    							sbErrorMessage.append("○").append("\t");
//    						}
//    					}
//    					if(UIUtil.isNotNullAndNotEmpty(sbECONumberId.toString())){
//		        			DomainRelationship.connect(context, new DomainObject(sbECONumberId.toString()), DomainConstants.RELATIONSHIP_AFFECTED_ITEM, partObj);
//			        		
//			        	}

    					
    					//Part Family
    					StringList sListPFs =new StringList();
//    					if (stCN_ID.length() > 6) {
//
//    						String pfCodeName = stCN_ID.substring(0, 5);
//    						String partFamilys = (String)partFamilyMap.get(pfCodeName);
//    						partFamilys = (partFamilys == null || "null".equals(partFamilys)) ? "" : partFamilys.trim();
//    						sListPFs = FrameworkUtil.split(partFamilys, ",");
//    						if(cdmStringUtil.isEmpty(partFamilys) ){
//    							if(bNewPartCheck){
//    								sbErrorMessage.append("○").append("\t");
//    							}else{
//    								sbErrorMessage.append("X").append("\t");
//    							}
//    						}else{
//    							if(bNewPartCheck){
//    								sbErrorMessage.append("X").append("\t");
//    							}else{
//    								sbErrorMessage.append("○").append("\t");
//    							}
//    						}
//    					}else{
//    						sbErrorMessage.append("○").append("\t");
//    					}
    					
    					
    						/*
    						 * *********************************************************
    						 * promote 및 revise "In Approval" 상태를
    						 * 가진 part 정보일경우 enovia에서는 In Review 상태로 ... "Inactive" 상태를
    						 * 가진 part 정보일경우 enovia에서는 Obsolete 상태로 변경. 과거 revision을 가진
    						 * object 은 무조건 Released 상태를 가진다. 현재 eo 데이타는 존재하지않아 연결정보를
    						 * 사용할 수 없다. 현재 상태로는 eo 데이타가 없고 drawing 데이타가 연결이 되지않아 추후 연결
    						 * 필요
    						 * 
    						 * 도면 있을 때 에는 revise 될때 같이 처리해야한다. 참조 cdmPartLibray
    						 * revise... 소스는 빼논 상태
    						 * *********************************************************
    						 * 
    						 */
    					bCommit = true;
    					ContextUtil.commitTransaction(context);	
    					
//    					try {
//    						MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", partObjectId, stAccessProductGroup, stAceesOrg);
//    						sbErrorMessage.append("X").append("\t").append("X").append("\t");
//    					} catch (Exception e) {
//    						sbErrorMessage.append(stAccessProductGroup).append("\t").append(stAceesOrg).append("\t");
//    					}
    					
    					
    					if(bCommit){
    						try{
    						
    						sbErrorMessage.append("X").append("\t");
    						}catch(Exception e4){
    							sbErrorMessage.append("○").append("\t");
    						}
    					}
    					
    					MqlUtil.mqlCommand(context, "trigger on");
    					checkTriggerOff = false;	
    						
    					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
//    						writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());	
    						writeSuccessToFile(subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+sbErrorMessage.toString());	
    					}else{
//    							writeSuccessToFile("LineNum(#): "+subPartCount +" \t PartNo: \t "+tempStPartNo+" \t ");
    						writeSuccessToFile(subPartCount +"\t"+tempStPartNo+"\t"+stREVISION);
    							
    					}
    						
    						successCount++;
    						
    				} catch (Exception e) {
    					ContextUtil.abortTransaction(context);

    					if(!checkAddPart){
    						MQLCommand mqlCommand = new MQLCommand();
    						mqlCommand.open(context);
    						mqlCommand.executeCommand(context, "abort transaction $1","PartFamily");
    					}
    					if(checkTriggerOff){
    						MqlUtil.mqlCommand(context, "trigger on");
    						checkTriggerOff = false;			
    					}
    					failCount++;
    					writeErrorToFile("LineNum(#)"+tempStRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " +e.getMessage().replaceAll("\r|\n", "")); 
    					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t" +"1"+"\t"+  data ) ;
    					
    					e.printStackTrace(errorStream);
    					writeShotErrorToFile(e.toString().replaceAll("\r|\n", ""));
    				}finally{
    					
    				}
    				
    			} // end of while 
    			
    			
    			writeMessageToConsole("====================================================================================");
    			writeMessageToConsole("        Migration COMPLETED.                    ");
    			writeMessageToConsole("====================================================================================");
    			//
    		} catch (Exception e1) {
    			writeFailToFile(" LineNum(#):"+tempStRowNum);
    			writeErrorToFile("LineNum(#):"+tempStRowNum + "  "+e1.getMessage());
    			e1.printStackTrace(errorStream);
    			
    			
    		}finally {
    			writeMessageToConsole("====================================================================================");
    			writeMessageToConsole("	CREATE PART OBJECT CLOSE TIME:  "+cdmCommonExcel.getTimeStamp2()+"          "  );
    			writeMessageToConsole("	CREATE PART OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
    			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+")"  );
    			writeMessageToConsole("==================================================================================== \n");
    			MqlUtil.mqlCommand(context, "history on");
    			if(checkTriggerOff){
    				MqlUtil.mqlCommand(context, "trigger on");
    			}
    			try {
    				if (null != errorStream )
    					errorStream .close();

    				if (null != logWriter)
    					logWriter.close();

    				if (null != failedObjectidWriter)
    					failedObjectidWriter.close();
    				
    				if (null != successObjectidWriter)
    					successObjectidWriter.close();

    				if(null != bufferReader)
    					bufferReader.close();
    				
    				if(null != errorLogFile)
    					errorLogFile.close();
    				
    				if(null != debugLogFile)
    					debugLogFile.close();

    				if(null != errorLogFile)
    					errorLogFile.close();
    			} catch (IOException e) {
    				System.out.println("Exception while closing log stream " + e.getMessage());
    			}
    			
    			
    			long endTime = System.currentTimeMillis();
    			long leadTime = (endTime-startTime)/1000/60;
    			System.out.println("cdmPartMigration : modifyPartCreate End.   endTime:"+cdmCommonExcel.getTimeStamp2()  + "leadTime :"+leadTime);
    			
    		}
    	
    	
    	
    }
    
    
    public void modifyConnect(Context context,String args[])throws Exception{

		
		//part Master 연결
		StringList slBusSelect = new StringList();
		slBusSelect.add("id");
		slBusSelect.add("name");
		slBusSelect.add("revision");
		
		String type = "cdmMechanicalPart,cdmPhantomPart";
		// Prt Revision 연결  part family 
//		eo , , 속성 추가 ,commoncode 해제 및 추가 
//		String sBusWhere = "attribute[cdmCheckMigration]!='Y' || relationship[Part Revision]=='False'  || last.id != id";
//		String sBusWhere = "relationship["+LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM+"]== 'False' || relationship[Part Revision]=='False'";
//		String sBusWhere = "relationship[Part Revision] == 'False'";
		String sBusWhere = "relationship["+LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM+"]== 'False'";
//		String sBusWhere = "relationship["+LibraryCentralConstants.RELATIONSHIP_CLASSIFIED_ITEM+"]== 'Fals;
		MapList mListNotConnectPart = DomainObject.findObjects(context,
				type,       // type
				cdmConstantsUtil.QUERY_WILDCARD,            // name
				cdmConstantsUtil.QUERY_WILDCARD,            // rev
				cdmConstantsUtil.QUERY_WILDCARD,            // owner
				cdmConstantsUtil.QUERY_WILDCARD,           	// vault
				sBusWhere, 									// where
				false,                                   	// expand
				slBusSelect);                            	// selectbus
		
		HashMap hmNoAttributePart = new HashMap<>();
		DomainObject dObj = new DomainObject();
		for (Iterator iterNoConnectPart = mListNotConnectPart.iterator(); iterNoConnectPart.hasNext();) {
			Map noConnectPartMap = (Map) iterNoConnectPart.next();
			String objectId = (String)noConnectPartMap.get("id");
			String partName = (String)noConnectPartMap.get("name");
			String partRev = (String)noConnectPartMap.get("revision");
			hmNoAttributePart.put(partName+"|"+partRev, objectId);
		}
		//

		long startTime = System.currentTimeMillis();
		System.out.println("cdmPartMigration : modifyConnect -StartTime:"+cdmCommonExcel.getTimeStamp2());
		String logFileName = "ModifyPartAttribute";
		
	
//		if(args.length!=1){
//			throw new Exception("The excel path does not exist.");
//		}
//		
		String sFileLocation 		= "";
		String sFileName 			= "";
//		String sFileLocationAndFileName = args[0];
//		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
//		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		//java application
		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
		String sFileLocationAndFileName = (String)paramMap.get("fileData");
		
		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		
		String[] argTest = {sFileLocation,sFileName}; // 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명  
		  
		String sPartInputDirectory = sFileLocation;

		// documentDirectory does not ends with "/" add it
		if(sPartInputDirectory != null && !sPartInputDirectory.endsWith(sfileSeparator))
		{
			sPartInputDirectory = sPartInputDirectory + sfileSeparator;
		}
		String sPartOutputDirectory = "";
		// create a directory to add debug and error logs
		sPartOutputDirectory = new File(sPartInputDirectory).getParentFile() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+   sfileSeparator;
        File fileOutputDirectory = new File(sPartOutputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        logFileName +=sFileName.substring(0,sFileName.lastIndexOf("."))+cdmCommonExcel.getTimeStamp();
		logWriter 			 	= new BufferedWriter(new FileWriter(sPartOutputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(sPartOutputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(sPartOutputDirectory + logFileName + "_SuccessLogs.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(sPartOutputDirectory + logFileName + "_FailedLogs" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		shortErrorLogFile        = new File(sPartOutputDirectory + logFileName + "ShortErrorLogs" + ".txt");
		shortErrorWriter         = new BufferedWriter(new FileWriter(shortErrorLogFile,true));
		
		String fileName = sFileName;
		String tempStRowNum   = ""; //순번
		String tempStPartNo   = ""; //엑셀의 PartNo
		String tempStPartRevision   = ""; //엑셀의 PartNo
		
		int successCount = 0;
		int failCount = 0;
		boolean checkTriggerOff = false;
		BufferedReader bufferReader = null;
		writeSuccessToFile("LineNume(#) \t  PartNo. \t Revision \t error Org Project \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t No OPTION1 exists. \t No OPTION2 exists. \t No OPTION3 exists. \t  No OPTION4 exists. \t No OPTION5 exists \t  No OPTION6 exists \t EC information does not exist. \t No Part Family exist. \t attribute value ");
		writeErrorToFile(sPartInputDirectory+fileName);
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole(" PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
		writeMessageToConsole("	Reading input log file from : "+sPartInputDirectory+fileName);
		writeMessageToConsole("	Writing Log files to: " + sPartInputDirectory );
		writeMessageToConsole("====================================================================================\n");
		boolean checkAddPart = false;
		MqlUtil.mqlCommand(context, "history off");
		try {
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(sPartInputDirectory+fileName),"euc-kr"));
			String data = "";  							// 텍스트 파일 라인정보담을 변수 
			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
			
			/* cdmCommonCode lev2 object 검색 start  */
			
			// 12/2 start 
			Map option1Map = getOptionCode(context,"Option1");
			Map option2Map = getOptionCode(context,"Option2");
			Map option3Map = getOptionCode(context,"Option3");
			Map option4Map = getOptionCode(context,"Option4");
			Map option5Map = getOptionCode(context,"Option5");
			Map option6Map = getOptionCode(context,"Option6");
			
			Map vehicleCommonCodeMap = getVehicleCode(context,"Vehicle");
			Map productGroupMap = getProductGroupCode(context,"Product Group Name");
			Map productDivMap = getProductDivCode(context,"Product Div");
			Map projectMap = getProjectCode(context,"cdmProjectGroupObject");
			Map partFamilyMap = getPartFamilyId(context);
			
			/*cdmCommonCode lev2 object 검색 end */ 
			
			String strLanguage = context.getLocale().getLanguage();
			
			AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
			attrPartGlobal.open(context);
			StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
			attrPartGlobal.close(context);
			StringList attrPartGlobalKOList = new StringList();
			attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
			
			
			AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
			attrPartItemType.open(context);
			StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
			attrPartItemType.close(context);
			StringList attrPartItemTypeKOList = new StringList();
			attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
			
			
			AttributeType attrPartERPInterface = new AttributeType("cdmPartERPInterface");
			attrPartERPInterface.open(context);
			StringList attrPartERPInterfaceList = attrPartERPInterface.getChoices(context);
			attrPartERPInterface.close(context);
			StringList attrPartERPInterfaceKOList = new StringList();
			attrPartERPInterfaceKOList = i18nNow.getAttrRangeI18NStringList("cdmPartERPInterface", attrPartERPInterfaceList, strLanguage);
			
			AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
			attrPartType.open(context);
			StringList attrPartTypeList = attrPartType.getChoices(context);
			attrPartType.close(context);
			StringList attrPartTypeKOList = new StringList();
			attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
			
//			HashMap tempUOMHMap = new HashMap();
//			tempUOMHMap.put("EA"  , "Each");
//			tempUOMHMap.put("BAG" , "bag");
//			tempUOMHMap.put("BTL" , "bottle");
//			tempUOMHMap.put("BOX" , "box");
//			tempUOMHMap.put("CC"  , "cc");
//			tempUOMHMap.put("CMM" , "mm³");
//			tempUOMHMap.put("CMT" , "m³");
//			tempUOMHMap.put("CN"  , "can");
//			tempUOMHMap.put("CT"  , "carton");
//			tempUOMHMap.put("DL"  , "dl");
//			tempUOMHMap.put("DZ"  , "dozen");
//			tempUOMHMap.put("FT"  , "ft");
//			tempUOMHMap.put("GLL" , "gallon");
//			tempUOMHMap.put("G"   , "g");
//			tempUOMHMap.put("IN"  , "inch");
//			tempUOMHMap.put("KG"  , "kg");
//			tempUOMHMap.put("KMT" , "km");
//			tempUOMHMap.put("L"   , "L");
//			tempUOMHMap.put("LBR" , "lb");
//			tempUOMHMap.put("M"   , "m");
//			tempUOMHMap.put("MGR" , "mg");
//			tempUOMHMap.put("ML"  , "ml");
//			tempUOMHMap.put("MMT" , "mm");
//			tempUOMHMap.put("MT"  , "ton");
//			tempUOMHMap.put("N"   , "N");
//			tempUOMHMap.put("PC"  , "Piece");
//			tempUOMHMap.put("PL"  , "Pl");
//			tempUOMHMap.put("ROL" , "Roll");
//			tempUOMHMap.put("SET" , "Set");
//			tempUOMHMap.put("SH"  , "Sheet");
//			tempUOMHMap.put("SM"  , "m²");
//			tempUOMHMap.put("UN"  , "unit");
//			tempUOMHMap.put("DRM" , "drum");
			
			int lineNumber = 1;      
			int subPartCount = 0;
			
			String strPreviousPartNo = null;
			String strPreviousPartRevision = null;
			String strPreviousPartType = null;
			
			
			while ((data = bufferReader.readLine()) != null) {
				
				StringBuffer sbErrorMessage = new StringBuffer("");
				MqlUtil.mqlCommand(context, "trigger off");
				checkTriggerOff = true;
				checkAddPart = false;
				StringList stListData = FrameworkUtil.split(data, "\t");
				try {
					
					if (lineNumber == 1) {
						stListHeader = stListData;
						writeFailToFile("errorRecord \t"+data);
						lineNumber++;
						continue;
					}
					lineNumber++;
					
					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
					int size_Data = stListData.size();
					int size_Header = stListHeader.size();
					if (size_Data != size_Header) {
						String errorMessage = " NOT MATCH DATA FIELD";
//						throw new Exception(errorMessage);
						writeFailToFile("errorRecord \t 5 \t"+data);
						continue;
					}

					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {

						String sPartInfos = cdmCommonExcel.isVaildNullData((String)stListData.get(stListNum));
						String sPartHeader = ((String) stListHeader.get(stListNum)).trim();
						partHM.put(sPartHeader, sPartInfos);
						
					}
					
					String stPartType                   = TYPE_CDMMECHANICALPART;  
					String stPartCount                  = ((String)partHM.get("#"            		        )).trim(); // 1 순번 
					String stCLS_NAME                   = ((String)partHM.get("CLS_NAME"                    )).trim(); // 2 
					String stOBJECT_ID                  = ((String)partHM.get("OBJECT_ID"                   )).trim(); // 3 //받은 자료에 unique 값 migration대상아님 
	
					String stCN_ID                      = ((String)partHM.get("CN_ID"  	                    )).trim(); // 5 Name
					String stREVISION                   = ((String)partHM.get("REVISION"                    )).trim(); // 6 Revision
					String stSTATE                      = ((String)partHM.get("STATE"                       )).trim(); // 7 State
					String stCREATION_DATE              = ((String)partHM.get("CREATION_DATE"               )).trim(); // 8  attribute[cdmPartCreationDateM]
					String stUSER_OBJECT_ID             = ((String)partHM.get("USER_OBJECT_ID"              )).trim(); // 9  attribute[cdmPartCreationUserIdM]
					String stUSER_ID_MOD                = ((String)partHM.get("USER_ID_MOD"                 )).trim(); // 10 attribute[cdmPartModUserIdM]
					String stMODIFICATION_DATE          = ((String)partHM.get("MODIFICATION_DATE"           )).trim(); // 11 attribute[cdmPartModificationDateM] 
					String stTDM_DESCRIPTION            = ((String)partHM.get("TDM_DESCRIPTION"             )).trim(); // 12 attribute[cdmPartName]
					String stTDM_UOM                    = ((String)partHM.get("TDM_UOM"  			        )).trim(); // 13 attribute[cdmPartUOM]
					String stPhaseM                     = ((String)partHM.get("PHASE"                       )).trim(); // 14 
					String stPAR_REVISION               = ((String)partHM.get("PAR_REVISION"                )).trim(); // 15 Previous Revision
	//				String stAPPROVAL_DATE              = ((String)partHM.get("APPROVAL_DATE"               )).trim(); // 16 
	//				String stREVISION_STG               = ((String)partHM.get("REVISION_STG"                )).trim(); // 17 
					String stTDM_ORG_USER_ID            = ((String)partHM.get("TDM_ORG_USER_ID"             )).trim(); // 18 First Revision creator
	//				String stTDM_ORG_CREATEDATE         = ((String)partHM.get("TDM_ORG_CREATEDATE"          )).trim(); // 19 
	//				String stTDM_APPROVED_BY            = ((String)partHM.get("TDM_APPROVED_BY"             )).trim(); // 20 
	//				String stTDM_ORIGIN_ID              = ((String)partHM.get("TDM_ORIGIN_ID"               )).trim(); // 21 
					String stCN_PROJECT                 = ((String)partHM.get("CN_PROJECT"                  )).trim(); // 22 PROJECT
					String stCN_PROJECT_CUST            = ((String)partHM.get("CN_PROJECT_CUST"             )).trim(); // 23 PROJECT_CUST
	//				String stCN_PRODUCT_NAME            = ((String)partHM.get("CN_PRODUCT_NAME"             )).trim(); // 24 
	//				String stCN_PART_GROUP              = ((String)partHM.get("CN_PART_GROUP"               )).trim(); // 25 
	//				String stCN_PART_NAME               = ((String)partHM.get("CN_PART_NAME"                )).trim(); // 26
	//				String stCN_WEIGHT                  = ((String)partHM.get("CN_WEIGHT"                   )).trim(); // 27
					String stCN_ESTIMATED_WEIGHT        = ((String)partHM.get("CN_ESTIMATED_WEIGHT"         )).trim(); // 28 attribute[cdmPartEstimatedWeight] 
					String stCN_WEIGHT_UNIT             = ((String)partHM.get("CN_WEIGHT_UNIT"              )).trim(); // 29
					String stCN_TOP_ITEM                = ((String)partHM.get("CN_TOP_ITEM"                 )).trim(); // 30
					String stCN_PHANTOM_ITEM            = ((String)partHM.get("CN_PHANTOM_ITEM"             )).trim(); // 31
					String stCN_ITEM_TYPE               = ((String)partHM.get("CN_ITEM_TYPE"                )).trim(); // 32
					String stCN_SERVICE_ITEM            = ((String)partHM.get("CN_SERVICE_ITEM"             )).trim(); // 33
					String stCN_ITEM_MATERIAL           = ((String)partHM.get("CN_ITEM_MATERIAL"            )).trim(); // 34
					String stCN_ITEM_UPDATE_FROM_ERP    = ((String)partHM.get("CN_ITEM_UPDATE_FROM_ERP"     )).trim(); // 35
					String stCN_COST                    = ((String)partHM.get("CN_COST"                     )).trim(); // 36
					String stCN_CURRENCY                = ((String)partHM.get("CN_CURRENCY"                 )).trim(); // 37
					//String stCN_COMMENTS              = ((String)partHM.get("CN_COMMENTS"                 )).trim(); // 38
					String stCN_OEM_PART_NUMBER         = ((String)partHM.get("CN_OEM_PART_NUMBER"          )).trim(); // 39
					String stEC_NAME                    = ((String)partHM.get("EC_NAME"                     )).trim(); // 40
					String stCN_ECO_NUMBER              = ((String)partHM.get("CN_ECO_NUMBER"               )).trim(); // 41
					String stCN_PRODUCT_GROUP           = ((String)partHM.get("CN_PRODUCT_GROUP"            )).trim(); // 42
					String stCN_SERIES_ITEM             = ((String)partHM.get("CN_SERIES_ITEM"              )).trim(); // 43
					String stCN_VEHICLE                 = ((String)partHM.get("CN_VEHICLE"                  )).trim(); // 44
					String stCN_CUSTOMER                = ((String)partHM.get("CN_CUSTOMER"                 )).trim(); // 45
					String stCN_SIZE                    = ((String)partHM.get("CN_SIZE"                     )).trim(); // 46
					String stCN_SURFACE_TREATMENT       = ((String)partHM.get("CN_SURFACE_TREATMENT"        )).trim(); // 47
					String stCN_SURFACE_AREA            = ((String)partHM.get("CN_SURFACE_AREA"             )).trim(); // 48
					String stCN_ITEM_TYPE1              = ((String)partHM.get("CN_ITEM_TYPE1"               )).trim(); // 49
					String stCN_MATERIAL               = ((String)partHM.get("CN_MATERIAL"                  )).trim(); // 50
					String stCN_ORG1                   = ((String)partHM.get("CN_ORG1"                      )).trim(); // 51  migration 대상 제외  
	//				String stCN_ORG2                   = ((String)partHM.get("CN_ORG2"                      )).trim(); // 52  migration 대상 제외 
	//				String stCN_ORG3                   = ((String)partHM.get("CN_ORG3"                      )).trim(); // 53  migration 대상 제외 
					String stCN_ORG                    = ((String)partHM.get("CN_ORG"                       )).trim(); // 54  MCA Org
					String stCN_MCA_INOUT              = ((String)partHM.get("CN_MCA_INOUT"                 )).trim(); // 55  MCA BOM Management
					String stCN_MCA_PART_TYPE_REF      = ((String)partHM.get("CN_MCA_PART_TYPE_REF"         )).trim(); // 56  MCA Part Type
					String stCN_OPTION1                = ((String)partHM.get("CN_OPTION1"                   )).trim(); // 57
					String stCN_OPTION2                = ((String)partHM.get("CN_OPTION2"                   )).trim(); // 58
					String stCN_OPTION3                = ((String)partHM.get("CN_OPTION3"                   )).trim(); // 59
					String stCN_OPTION4                = ((String)partHM.get("CN_OPTION4"                   )).trim(); // 60
					String stCN_OPTION5                = ((String)partHM.get("CN_OPTION5"                   )).trim(); // 61
					String stCN_OPTION6                = ((String)partHM.get("CN_OPTION6"                   )).trim(); // 62
					String stCN_OPTION7                = ((String)partHM.get("CN_OPTION7"                   )).trim(); // 63
					String stCN_OPTION_ETC             = ((String)partHM.get("CN_OPTION_ETC"                )).trim(); // 64
					String stCN_IS_CASTING             = ((String)partHM.get("CN_IS_CASTING"                )).trim(); // 65
					String stCN_OPTION_DESC            = ((String)partHM.get("CN_OPTION_DESC"               )).trim(); // 66
					String stCN_FOR_MAC                = ((String)partHM.get("CN_FOR_MAC"                   )).trim(); // 67
					String stCN_FOR_MIL                = ((String)partHM.get("CN_FOR_MIL"                   )).trim(); // 68
					String stCN_FOR_MIS                = ((String)partHM.get("CN_FOR_MIS"                   )).trim(); // 69
					String stCN_FOR_MMT                = ((String)partHM.get("CN_FOR_MMT"                   )).trim(); // 70
					String stCN_REAL_WEIGHT            = ((String)partHM.get("CN_REAL_WEIGHT"               )).trim(); // 71
					String stCN_COUNTRY                = ((String)partHM.get("CN_COUNTRY"                   )).trim(); // 72
					String stCN_PRODUCT_DIV            = ((String)partHM.get("CN_PRODUCT_DIV"               )).trim(); // 73
					String stCN_GLOBAL_LOCAL           = ((String)partHM.get("CN_GLOBAL_LOCAL"              )).trim(); // 74
					String stCN_PROJECT_CODE           = ((String)partHM.get("CN_PROJECT_CODE"              )).trim(); // 75
					String stCN_OPTION_DRAWING         = ((String)partHM.get("CN_OPTION_DRAWING"            )).trim(); // 76
					String stCN_FOR_DRAWING_FINISH     = ((String)partHM.get("CN_FOR_DRAWING_FINISH"        )).trim(); // 77
					String stCN_FOR_DRAWING_SIZE       = ((String)partHM.get("CN_FOR_DRAWING_SIZE"          )).trim(); // 78
					String stCN_FOR_DRAWING_REMARK     = ((String)partHM.get("CN_FOR_DRAWING_REMARK"        )).trim(); // 79
					String stCN_ITEM_TYPE2              = ((String)partHM.get("CN_ITEM_TYPE2"               )).trim(); // 80
					String stCN_APPLY_PARTLIST          = ((String)partHM.get("CN_APPLY_PARTLIST"           )).trim(); // 81
//					String stCN_PREVIOUS_PART           = ((String)partHM.get("CN_PREVIOUS_PART"            )).trim(); // 82
					String stCN_COMPLEX_BODY            = ((String)partHM.get("CN_COMPLEX_BODY"             )).trim(); // 83
					String stCN_MAIN_PART_NUMBER        = ((String)partHM.get("CN_MAIN_PART_NUMBER"         )).trim(); // 84
					String stCN_VEHICLE_DESC            = ((String)partHM.get("CN_VEHICLE_DESC"             )).trim(); // 85 VEHICLE 
					String stCN_VEHICLE_CODE            = ((String)partHM.get("CN_VEHICLE_CODE"             )).trim(); // 86
					String stVehicle_Cust               = ((String)partHM.get("VEHICLE_CUST"                )).trim(); // 87
					String stCN_DRAWING_NO              = ((String)partHM.get("CN_DRAWING_NO"               )).trim(); // 88 DRAWING_NO
					String stCN_SUB_ID         		    = ((String)partHM.get("CN_SUB_ID"                   )).trim(); // 89
	//				//String stCN_CHANGE_REASON 	        = ((String)partHM.get("CN_CHANGE_REASON"            )).trim(); // 90 다른 데이타 파일로 진행 예정 
					String stCN_SURFACE_TREATMENT_KEYIN = ((String)partHM.get("CN_SURFACE_TREATMENT_KEYIN"  )).trim(); // 91
					String stCN_OVERSEAS_ORG6           = ((String)partHM.get("CN_OVERSEAS_ORG6"            )).trim(); // 92
					String stCN_OVERSEAS_ORG6_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG6_PART_TYPE"  )).trim(); // 93
					String stCN_OVERSEAS_ORG6_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG6_INOUT"      )).trim(); // 94
//					String stCN_OVERSEAS_ORG7           = ((String)partHM.get("CN_OVERSEAS_ORG7"            )).trim(); // 95
//					String stCN_OVERSEAS_ORG7_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG7_PART_TYPE"  )).trim(); // 96
//					String stCN_OVERSEAS_ORG7_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG7_INOUT"      )).trim(); // 97

					String stCN_Project_Id			    = ((String)partHM.get("CN_PROJECT_ID"  )).trim(); // 98
					String stAccessProductGroup		    = ((String)partHM.get("PROD_GROUP"  )).trim(); // 98
					String stAceesOrg				    = ((String)partHM.get("CN_CUST_VEHICLE"  )).trim(); // 98
					if("-".equals(stAceesOrg)){
						stAceesOrg = "";
					}
					//
					String sNotExistAttInfoPart= (String)hmNoAttributePart.get(stCN_ID+"|"+stREVISION);
					sNotExistAttInfoPart = cdmCommonExcel.isVaildNullData(sNotExistAttInfoPart);
					if(UIUtil.isNullOrEmpty(sNotExistAttInfoPart)){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+  data ) ;
						continue;
						
					}
					

			        /* **********************************************************************************************************************
			         * part 데이타 생성 및 데이타 
			         * 트리거 오프한 상태로 진행되며 트리거에서 제공되는 attribute[originator]속성 및 interface 추가 설정 필터 정보 와 
			         * rev 정보 part master 생성 및 연결 및 속성(attribute[Originator]속성 추가 
			         * 에러 발생시 정지 및 데이타 정보 검색 
			         * ******************************************************************************************************************* */
			        
//			        DomainObject partObj = new DomainObject();
			        boolean bCommit = false;
			        DomainObject partObj = new DomainObject();
			        partObj.setId(sNotExistAttInfoPart);
			        ContextUtil.startTransaction(context, true);
			        bCommit = true;
			        boolean bNewPartCheck = false;
			        boolean reviseCheck = false;
			      
			        String partName = partObj.getName(context);
			        
//			        paramHM.put("ECONumberOid", sbECONumberId.toString());
			        //
			        String sbECONumberId = "";
			        if (cdmStringUtil.isNotEmpty(stCN_ECO_NUMBER)) {
						StringBuffer sbfECType = new StringBuffer();
						sbfECType.append("cdmECO");
						sbfECType.append(",");
						sbfECType.append("cdmEAR");
						sbfECType.append(",");
						sbfECType.append("cdmDCR");
						sbfECType.append(",");
						sbfECType.append("cdmPEO");
//						sbfECType.append(",");
//						sbfECType.append("cdmTEO");
						
						
						String stTempECExist = "temp query bus \"" + sbfECType.toString() + "\" \""+stCN_ECO_NUMBER +"\"  *  select id dump |";
						String stTempECExistMql = MqlUtil.mqlCommand(context, stTempECExist);
						StringList sListTempECExistMql = FrameworkUtil.split(stTempECExistMql, "|");
						// test start start
						if (sListTempECExistMql.size() > 2) {
							sbECONumberId = (String)sListTempECExistMql.get(3);
							sbErrorMessage.append("X").append("\t");
						} else {
							sbErrorMessage.append("O").append("\t");
						}
					}
			        
					if(UIUtil.isNotNullAndNotEmpty(sbECONumberId)){
	        			DomainRelationship.connect(context, new DomainObject(sbECONumberId), DomainConstants.RELATIONSHIP_AFFECTED_ITEM, partObj);
		        		
		        	}
			        
			        //Part FAmily start 
//			        String sSplitPartName = partName.substring(0, 5);
//			        String partFamilys = (String)partFamilyMap.get(sSplitPartName);
//			        StringList sListPFs = FrameworkUtil.split(partFamilys, ",");
//			        //
			        boolean bCheckPF = false;
//			        boolean bCheckPartNamePF = false;
//			        int sListPartFamilyIdsSize = sListPFs.size();
//			        for (Iterator iterPF = sListPFs.iterator(); iterPF.hasNext();) {
//						
//						String sPF = (String) iterPF.next();
//						HashMap connectPFHMap = new HashMap();
//						
//						if(sListPartFamilyIdsSize>1){
//							String pfCodeName = stCN_ID.substring(0, 5);
//							String checkPartFamilyName = pfCodeName+":"+stTDM_DESCRIPTION;
//							sPF = (String)partFamilyMap.get(checkPartFamilyName);
//							bCheckPartNamePF = true;
//						}
//						
//						if ( (UIUtil.isNotNullAndNotEmpty(sPF) && bCheckPartNamePF) || sListPartFamilyIdsSize == 1) {
//							connectPFHMap.put("sPF", sPF);
//							connectPFHMap.put("partObjectId", sNotExistAttInfoPart);
//							
//							String connectResult = JPO.invoke(context, "cdmPartMigration", null, "connectPartFamily", JPO.packArgs(connectPFHMap), String.class);
//
//							if (connectResult.startsWith("false|")) {
//								int startIndex = connectResult.indexOf("false|");
//								connectResult.substring(startIndex);
//								sbErrorMessage.append(connectResult).append("\t");
//							} else {
//								sbErrorMessage.append("O").append("\t");
//
//							}
//							bCheckPF = true;
//							break;
//						}
//						
//					}
			        //part family end 
			        // part master 
//			        boolean boolPerson = false;
			        
//			        String personIdMql = "temp query bus Person '" + stTDM_ORG_USER_ID + "' - select id dump |";
//					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
//					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
//					String stPerson = "";
//					if (stListPersonIdMql.size() > 2) {
//						stPerson = (String) stListPersonIdMql.get(3);
//						boolPerson = true;
//					}
//			        createPartMaster(context, sNotExistAttInfoPart, stTDM_ORG_USER_ID,boolPerson);
			
					bCommit = true;
					ContextUtil.commitTransaction(context);	
					
					
					if(bCommit){
						try{
						
						sbErrorMessage.append("X").append("\t");
						}catch(Exception e4){
							sbErrorMessage.append("○").append("\t");
						}
					}
					
					MqlUtil.mqlCommand(context, "trigger on");
					checkTriggerOff = false;	
						
					if (bCheckPF){
						writeSuccessToFile(subPartCount +" \t "+partName+"\t"+ stREVISION+"\t "+sbErrorMessage.toString()+"\t"+sNotExistAttInfoPart);	
						successCount++;
					}
						
						
				} catch (Exception e) {
					ContextUtil.abortTransaction(context);

					if(!checkAddPart){
						MQLCommand mqlCommand = new MQLCommand();
						mqlCommand.open(context);
						mqlCommand.executeCommand(context, "abort transaction $1","PartFamily");
					}
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "trigger on");
						checkTriggerOff = false;			
					}
					failCount++;
					writeErrorToFile("LineNum(#)"+tempStRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " +e.getMessage().replaceAll("\r|\n", "")); 
					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t" +"1"+"\t"+  data ) ;
					
					e.printStackTrace(errorStream);
					writeShotErrorToFile(e.toString().replaceAll("\r|\n", ""));
				}finally{
					
				}
				
			} // end of while 
			
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================");
			//
		} catch (Exception e1) {
			writeFailToFile(" LineNum(#):"+tempStRowNum);
			writeErrorToFile("LineNum(#):"+tempStRowNum + "  "+e1.getMessage());
			e1.printStackTrace(errorStream);
			
			
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("	CREATE PART OBJECT CLOSE TIME:  "+cdmCommonExcel.getTimeStamp2()+"          "  );
			writeMessageToConsole("	CREATE PART OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+")"  );
			writeMessageToConsole("==================================================================================== \n");
			MqlUtil.mqlCommand(context, "history on");
			if(checkTriggerOff){
				MqlUtil.mqlCommand(context, "trigger on");
			}
			try {
				if (null != errorStream )
					errorStream .close();

				if (null != logWriter)
					logWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if(null != bufferReader)
					bufferReader.close();
				
				if(null != errorLogFile)
					errorLogFile.close();
				
				if(null != debugLogFile)
					debugLogFile.close();

				if(null != errorLogFile)
					errorLogFile.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			
			long endTime = System.currentTimeMillis();
			long leadTime = (endTime-startTime)/1000/60;
			System.out.println("cdmPartMigration : modifyPartCreate End.   endTime:"+cdmCommonExcel.getTimeStamp2()  + "leadTime :"+leadTime);
			
		}
	
	
	

    }
    
    
    /**
     * 수정한 part create Migration 0109 
     * update 진행 
     * @param context
     * @param args
     * @throws Exception
     */
    public void executeCreatePartMigration(Context context,String args[])throws Exception{


		long startTime = System.currentTimeMillis();
		System.out.println("cdmPartMigration : executeCreatePartMigration -StartTime:"+cdmCommonExcel.getTimeStamp());
		String logFileName = "CreatePartM";
		
	
		if(args.length!=1){
			throw new Exception("The excel path does not exist.");
		}
		String sFileLocationAndFileName = args[0];
		
		String sFileLocation 		= "";
		String sFileName 			= "";
		
		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
//		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
//		sFileLocation = (String)paramMap.get("File_Location");
//		sFileName = (String)paramMap.get("File");
		
		String sPartInputDirectory = sFileLocation;

		// documentDirectory does not ends with "/" add it
		if(sPartInputDirectory != null && !sPartInputDirectory.endsWith(sfileSeparator))
		{
			sPartInputDirectory = sPartInputDirectory + sfileSeparator;
		}
		String sPartOutputDirectory = "";
		// create a directory to add debug and error logs
		sPartOutputDirectory = new File(sPartInputDirectory).getParentFile() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+  sfileSeparator;
        File fileOutputDirectory = new File(sPartOutputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        
        String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		logFileName +="_"+sFileName.substring(0, sFileName.lastIndexOf("."))+"_"+formatTime;
		
        
		logWriter 			 	= new BufferedWriter(new FileWriter(sPartOutputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(sPartOutputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(sPartOutputDirectory + logFileName + "_SuccessLogs.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(sPartOutputDirectory + logFileName + "_FailedLogs" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		shortErrorLogFile        = new File(sPartOutputDirectory + logFileName + "ShortErrorLogs" + ".txt");
		shortErrorWriter         = new BufferedWriter(new FileWriter(shortErrorLogFile,true));
		
		String tempStRowNum   = ""; //순번
		String tempStPartNo   = ""; //엑셀의 PartNo
		String tempStPartRevision   = ""; //엑셀의 PartNo
		int totalCount = 0;
		int successCount = 0;
		int failCount = 0;
		boolean checkTriggerOff = false;
		BufferedReader bufferReader = null;
//		writeSuccessToFile("LineNume(#) \t  PartNo. \t Revision \t error Org Project \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t No OPTION1 exists. \t No OPTION2 exists. \t No OPTION3 exists. \t  No OPTION4 exists. \t No OPTION5 exists \t  No OPTION6 exists \t EC information does not exist. \t No Part Family exist. \t attribute value ");
		writeSuccessToFile("CreateTime \t LineNume(#) \t  PartNo. \t Revision \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t  OPTION1 Wrong. \t OPTION2 Wrong. \t  OPTION3 Wrong. \t   OPTION4 Wrong. \t  OPTION5 Wrong. \t   OPTION6 Wrong. \t EC information does not exist. \t No Part Family exist. \t Part Connect \t Project Group \t Org  \t attributes ");
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole(" PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
		writeMessageToConsole("	Reading input log file from : "+sPartInputDirectory+sFileName);
		writeMessageToConsole("	Writing Log files to: " + sPartInputDirectory );
		writeMessageToConsole("====================================================================================\n");
		boolean checkAddPart = false;
		MqlUtil.mqlCommand(context, "history off");
		try {
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(sPartInputDirectory+sFileName),"euc-kr"));
			String data = "";  							// 텍스트 파일 라인정보담을 변수 
			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
			
			/* cdmCommonCode lev2 object 검색 start  */
			
			// 12/2 start 
			Map option1Map = getOptionCode(context,"Option1");
			Map option2Map = getOptionCode(context,"Option2");
			Map option3Map = getOptionCode(context,"Option3");
			Map option4Map = getOptionCode(context,"Option4");
			Map option5Map = getOptionCode(context,"Option5");
			Map option6Map = getOptionCode(context,"Option6");
			
			Map vehicleCommonCodeMap = getVehicleCode(context,"Vehicle");
			Map productGroupMap      = getProductGroupCode(context,"Product Group Name");
			Map productDivMap        = getProductDivCode(context,"Product Div");
			Map projectMap           = getProjectCode(context,"cdmProjectGroupObject");
//			Map partFamilyMap        = getPartFamilyId(context);
			Map partFamilyMap        = getPartFamilyId2(context,"Global R&D:Global R&D"); //top part family[cdmPartFamilyBlockCodeName]
			
			/*cdmCommonCode lev2 object 검색 end */ 
			
			String strLanguage = context.getLocale().getLanguage();
			
			AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
			attrPartGlobal.open(context);
			StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
			attrPartGlobal.close(context);
			StringList attrPartGlobalKOList = new StringList();
			attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
			
			
			AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
			attrPartItemType.open(context);
			StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
			attrPartItemType.close(context);
			StringList attrPartItemTypeKOList = new StringList();
			attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
			
			
			AttributeType attrPartERPInterface = new AttributeType("cdmPartERPInterface");
			attrPartERPInterface.open(context);
			StringList attrPartERPInterfaceList = attrPartERPInterface.getChoices(context);
			attrPartERPInterface.close(context);
			StringList attrPartERPInterfaceKOList = new StringList();
			attrPartERPInterfaceKOList = i18nNow.getAttrRangeI18NStringList("cdmPartERPInterface", attrPartERPInterfaceList, strLanguage);
			
			AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
			attrPartType.open(context);
			StringList attrPartTypeList = attrPartType.getChoices(context);
			attrPartType.close(context);
			StringList attrPartTypeKOList = new StringList();
			attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
			
			HashMap tempUOMHMap = new HashMap();
			tempUOMHMap.put("EA"  , "Each");
			tempUOMHMap.put("BAG" , "bag");
			tempUOMHMap.put("BTL" , "bottle");
			tempUOMHMap.put("BOX" , "box");
			tempUOMHMap.put("CC"  , "cc");
			tempUOMHMap.put("CMM" , "mm³");
			tempUOMHMap.put("CMT" , "m³");
			tempUOMHMap.put("CN"  , "can");
			tempUOMHMap.put("CT"  , "carton");
			tempUOMHMap.put("DL"  , "dl");
			tempUOMHMap.put("DZ"  , "dozen");
			tempUOMHMap.put("FT"  , "ft");
			tempUOMHMap.put("GLL" , "gallon");
			tempUOMHMap.put("G"   , "g");
			tempUOMHMap.put("IN"  , "inch");
			tempUOMHMap.put("KG"  , "kg");
			tempUOMHMap.put("KMT" , "km");
			tempUOMHMap.put("L"   , "L");
			tempUOMHMap.put("LBR" , "lb");
			tempUOMHMap.put("M"   , "m");
			tempUOMHMap.put("MGR" , "mg");
			tempUOMHMap.put("ML"  , "ml");
			tempUOMHMap.put("MMT" , "mm");
			tempUOMHMap.put("MT"  , "ton");
			tempUOMHMap.put("N"   , "N");
			tempUOMHMap.put("PC"  , "Piece");
			tempUOMHMap.put("PL"  , "Pl");
			tempUOMHMap.put("ROL" , "Roll");
			tempUOMHMap.put("SET" , "Set");
			tempUOMHMap.put("SH"  , "Sheet");
			tempUOMHMap.put("SM"  , "m²");
			tempUOMHMap.put("UN"  , "unit");
			tempUOMHMap.put("DRM" , "drum");
			
			int lineNumber = 1;      
			int subPartCount = 0;
			
			String strPreviousPartNo = null;
			String strPreviousPartRevision = null;
			String strPreviousPartType = null;
			
			
			while ((data = bufferReader.readLine()) != null) {
				
				StringBuffer sbErrorMessage = new StringBuffer("");
				MqlUtil.mqlCommand(context, "trigger off");
				checkTriggerOff = true;
				checkAddPart = false;
				StringList stListData = FrameworkUtil.split(data, "\t");
				try {
					
					if (lineNumber == 1) {
						stListHeader = stListData;
						writeFailToFile("errorRecord \t"+data);
						lineNumber++;
						continue;
					}
					lineNumber++;
					totalCount++;
					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
					int size_Data = stListData.size();
					int size_Header = stListHeader.size();
					if (size_Data != size_Header) {
						String errorMessage = " NOT MATCH DATA FIELD";
						throw new Exception(errorMessage);
					}

					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {

						String sPartInfos = cdmCommonExcel.isVaildNullData((String)stListData.get(stListNum));
						String sPartHeader = ((String) stListHeader.get(stListNum)).trim();
						partHM.put(sPartHeader, sPartInfos);
						
					}
					
					String stPartType                   = TYPE_CDMMECHANICALPART;  
					String stPartCount                  = ((String)partHM.get("#"            		        )).trim(); // 1 순번 
					String stCLS_NAME                   = ((String)partHM.get("CLS_NAME"                    )).trim(); // 2 
					String stOBJECT_ID                  = ((String)partHM.get("OBJECT_ID"                   )).trim(); // 3 //받은 자료에 unique 값 migration대상아님 
	
					String stCN_ID                      = ((String)partHM.get("CN_ID"  	                    )).trim(); // 5 Name
					String stREVISION                   = ((String)partHM.get("REVISION"                    )).trim(); // 6 Revision
					String stSTATE                      = ((String)partHM.get("STATE"                       )).trim(); // 7 State
					String stCREATION_DATE              = ((String)partHM.get("CREATION_DATE"               )).trim(); // 8  attribute[cdmPartCreationDateM]
					String stUSER_OBJECT_ID             = ((String)partHM.get("USER_OBJECT_ID"              )).trim(); // 9  attribute[cdmPartCreationUserIdM]
					String stUSER_ID_MOD                = ((String)partHM.get("USER_ID_MOD"                 )).trim(); // 10 attribute[cdmPartModUserIdM]
					String stMODIFICATION_DATE          = ((String)partHM.get("MODIFICATION_DATE"           )).trim(); // 11 attribute[cdmPartModificationDateM] 
					String stTDM_DESCRIPTION            = ((String)partHM.get("TDM_DESCRIPTION"             )).trim(); // 12 attribute[cdmPartName]
					String stTDM_UOM                    = ((String)partHM.get("TDM_UOM"  			        )).trim(); // 13 attribute[cdmPartUOM]
					String stPhaseM                     = ((String)partHM.get("PHASE"                       )).trim(); // 14 
					String stPAR_REVISION               = ((String)partHM.get("PAR_REVISION"                )).trim(); // 15 Previous Revision
	//				String stAPPROVAL_DATE              = ((String)partHM.get("APPROVAL_DATE"               )).trim(); // 16 
	//				String stREVISION_STG               = ((String)partHM.get("REVISION_STG"                )).trim(); // 17 
					String stTDM_ORG_USER_ID            = ((String)partHM.get("TDM_ORG_USER_ID"             )).trim(); // 18 First Revision creator
	//				String stTDM_ORG_CREATEDATE         = ((String)partHM.get("TDM_ORG_CREATEDATE"          )).trim(); // 19 
	//				String stTDM_APPROVED_BY            = ((String)partHM.get("TDM_APPROVED_BY"             )).trim(); // 20 
	//				String stTDM_ORIGIN_ID              = ((String)partHM.get("TDM_ORIGIN_ID"               )).trim(); // 21 
					String stCN_PROJECT                 = ((String)partHM.get("CN_PROJECT"                  )).trim(); // 22 PROJECT
					String stCN_PROJECT_CUST            = ((String)partHM.get("CN_PROJECT_CUST"             )).trim(); // 23 PROJECT_CUST
	//				String stCN_PRODUCT_NAME            = ((String)partHM.get("CN_PRODUCT_NAME"             )).trim(); // 24 
	//				String stCN_PART_GROUP              = ((String)partHM.get("CN_PART_GROUP"               )).trim(); // 25 
	//				String stCN_PART_NAME               = ((String)partHM.get("CN_PART_NAME"                )).trim(); // 26
	//				String stCN_WEIGHT                  = ((String)partHM.get("CN_WEIGHT"                   )).trim(); // 27
					String stCN_ESTIMATED_WEIGHT        = ((String)partHM.get("CN_ESTIMATED_WEIGHT"         )).trim(); // 28 attribute[cdmPartEstimatedWeight] 
					String stCN_WEIGHT_UNIT             = ((String)partHM.get("CN_WEIGHT_UNIT"              )).trim(); // 29
					String stCN_TOP_ITEM                = ((String)partHM.get("CN_TOP_ITEM"                 )).trim(); // 30
					String stCN_PHANTOM_ITEM            = ((String)partHM.get("CN_PHANTOM_ITEM"             )).trim(); // 31
					String stCN_ITEM_TYPE               = ((String)partHM.get("CN_ITEM_TYPE"                )).trim(); // 32
					String stCN_SERVICE_ITEM            = ((String)partHM.get("CN_SERVICE_ITEM"             )).trim(); // 33
					String stCN_ITEM_MATERIAL           = ((String)partHM.get("CN_ITEM_MATERIAL"            )).trim(); // 34
					String stCN_ITEM_UPDATE_FROM_ERP    = ((String)partHM.get("CN_ITEM_UPDATE_FROM_ERP"     )).trim(); // 35
					String stCN_COST                    = ((String)partHM.get("CN_COST"                     )).trim(); // 36
					String stCN_CURRENCY                = ((String)partHM.get("CN_CURRENCY"                 )).trim(); // 37
					//String stCN_COMMENTS              = ((String)partHM.get("CN_COMMENTS"                 )).trim(); // 38
					String stCN_OEM_PART_NUMBER         = ((String)partHM.get("CN_OEM_PART_NUMBER"          )).trim(); // 39
					String stEC_NAME                    = ((String)partHM.get("EC_NAME"                     )).trim(); // 40
					String stCN_ECO_NUMBER              = ((String)partHM.get("CN_ECO_NUMBER"               )).trim(); // 41
					String stCN_PRODUCT_GROUP           = ((String)partHM.get("CN_PRODUCT_GROUP"            )).trim(); // 42
					String stCN_SERIES_ITEM             = ((String)partHM.get("CN_SERIES_ITEM"              )).trim(); // 43
					String stCN_VEHICLE                 = ((String)partHM.get("CN_VEHICLE"                  )).trim(); // 44
					String stCN_CUSTOMER                = ((String)partHM.get("CN_CUSTOMER"                 )).trim(); // 45
					String stCN_SIZE                    = ((String)partHM.get("CN_SIZE"                     )).trim(); // 46
					String stCN_SURFACE_TREATMENT       = ((String)partHM.get("CN_SURFACE_TREATMENT"        )).trim(); // 47
					String stCN_SURFACE_AREA            = ((String)partHM.get("CN_SURFACE_AREA"             )).trim(); // 48
					String stCN_ITEM_TYPE1              = ((String)partHM.get("CN_ITEM_TYPE1"               )).trim(); // 49
					String stCN_MATERIAL               = ((String)partHM.get("CN_MATERIAL"                  )).trim(); // 50
					String stCN_ORG1                   = ((String)partHM.get("CN_ORG1"                      )).trim(); // 51  migration 대상 제외  
	//				String stCN_ORG2                   = ((String)partHM.get("CN_ORG2"                      )).trim(); // 52  migration 대상 제외 
	//				String stCN_ORG3                   = ((String)partHM.get("CN_ORG3"                      )).trim(); // 53  migration 대상 제외 
					String stCN_ORG                    = ((String)partHM.get("CN_ORG"                       )).trim(); // 54  MCA Org
					String stCN_MCA_INOUT              = ((String)partHM.get("CN_MCA_INOUT"                 )).trim(); // 55  MCA BOM Management
					String stCN_MCA_PART_TYPE_REF      = ((String)partHM.get("CN_MCA_PART_TYPE_REF"         )).trim(); // 56  MCA Part Type
					String stCN_OPTION1                = ((String)partHM.get("CN_OPTION1"                   )).trim(); // 57
					String stCN_OPTION2                = ((String)partHM.get("CN_OPTION2"                   )).trim(); // 58
					String stCN_OPTION3                = ((String)partHM.get("CN_OPTION3"                   )).trim(); // 59
					String stCN_OPTION4                = ((String)partHM.get("CN_OPTION4"                   )).trim(); // 60
					String stCN_OPTION5                = ((String)partHM.get("CN_OPTION5"                   )).trim(); // 61
					String stCN_OPTION6                = ((String)partHM.get("CN_OPTION6"                   )).trim(); // 62
					String stCN_OPTION7                = ((String)partHM.get("CN_OPTION7"                   )).trim(); // 63
					String stCN_OPTION_ETC             = ((String)partHM.get("CN_OPTION_ETC"                )).trim(); // 64
					String stCN_IS_CASTING             = ((String)partHM.get("CN_IS_CASTING"                )).trim(); // 65
					String stCN_OPTION_DESC            = ((String)partHM.get("CN_OPTION_DESC"               )).trim(); // 66
					String stCN_FOR_MAC                = ((String)partHM.get("CN_FOR_MAC"                   )).trim(); // 67
					String stCN_FOR_MIL                = ((String)partHM.get("CN_FOR_MIL"                   )).trim(); // 68
					String stCN_FOR_MIS                = ((String)partHM.get("CN_FOR_MIS"                   )).trim(); // 69
					String stCN_FOR_MMT                = ((String)partHM.get("CN_FOR_MMT"                   )).trim(); // 70
					String stCN_REAL_WEIGHT            = ((String)partHM.get("CN_REAL_WEIGHT"               )).trim(); // 71
					String stCN_COUNTRY                = ((String)partHM.get("CN_COUNTRY"                   )).trim(); // 72
					String stCN_PRODUCT_DIV            = ((String)partHM.get("CN_PRODUCT_DIV"               )).trim(); // 73
					String stCN_GLOBAL_LOCAL           = ((String)partHM.get("CN_GLOBAL_LOCAL"              )).trim(); // 74
					String stCN_PROJECT_CODE           = ((String)partHM.get("CN_PROJECT_CODE"              )).trim(); // 75
					String stCN_OPTION_DRAWING         = ((String)partHM.get("CN_OPTION_DRAWING"            )).trim(); // 76
					String stCN_FOR_DRAWING_FINISH     = ((String)partHM.get("CN_FOR_DRAWING_FINISH"        )).trim(); // 77
					String stCN_FOR_DRAWING_SIZE       = ((String)partHM.get("CN_FOR_DRAWING_SIZE"          )).trim(); // 78
					String stCN_FOR_DRAWING_REMARK     = ((String)partHM.get("CN_FOR_DRAWING_REMARK"        )).trim(); // 79
					String stCN_ITEM_TYPE2              = ((String)partHM.get("CN_ITEM_TYPE2"               )).trim(); // 80
					String stCN_APPLY_PARTLIST          = ((String)partHM.get("CN_APPLY_PARTLIST"           )).trim(); // 81
//					String stCN_PREVIOUS_PART           = ((String)partHM.get("CN_PREVIOUS_PART"            )).trim(); // 82
					String stCN_COMPLEX_BODY            = ((String)partHM.get("CN_COMPLEX_BODY"             )).trim(); // 83
					String stCN_MAIN_PART_NUMBER        = ((String)partHM.get("CN_MAIN_PART_NUMBER"         )).trim(); // 84
					String stCN_VEHICLE_DESC            = ((String)partHM.get("CN_VEHICLE_DESC"             )).trim(); // 85 VEHICLE 
					String stCN_VEHICLE_CODE            = ((String)partHM.get("CN_VEHICLE_CODE"             )).trim(); // 86
					String stVehicle_Cust               = ((String)partHM.get("VEHICLE_CUST"                )).trim(); // 87
					String stCN_DRAWING_NO              = ((String)partHM.get("CN_DRAWING_NO"               )).trim(); // 88 DRAWING_NO
					String stCN_SUB_ID         		    = ((String)partHM.get("CN_SUB_ID"                   )).trim(); // 89
	//				//String stCN_CHANGE_REASON 	        = ((String)partHM.get("CN_CHANGE_REASON"            )).trim(); // 90 다른 데이타 파일로 진행 예정 
					String stCN_SURFACE_TREATMENT_KEYIN = ((String)partHM.get("CN_SURFACE_TREATMENT_KEYIN"  )).trim(); // 91
					String stCN_OVERSEAS_ORG6           = ((String)partHM.get("CN_OVERSEAS_ORG6"            )).trim(); // 92
					String stCN_OVERSEAS_ORG6_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG6_PART_TYPE"  )).trim(); // 93
					String stCN_OVERSEAS_ORG6_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG6_INOUT"      )).trim(); // 94
//					String stCN_OVERSEAS_ORG7           = ((String)partHM.get("CN_OVERSEAS_ORG7"            )).trim(); // 95
//					String stCN_OVERSEAS_ORG7_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG7_PART_TYPE"  )).trim(); // 96
//					String stCN_OVERSEAS_ORG7_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG7_INOUT"      )).trim(); // 97

					String stCN_Project_Id			    = ((String)partHM.get("CN_PROJECT_ID"  )).trim(); // 98
					String stAccessProductGroup		    = ((String)partHM.get("PROD_GROUP"  )).trim(); // 99
					String stAceesOrg				    = ((String)partHM.get("CN_CUST_VEHICLE"  )).trim(); // 100
					if("-".equals(stAceesOrg)){
						stAceesOrg = "";
					}
					String stCADWeight					= ""; 
					
					String stGLOBAL_LOCAL = "";
//					String stITEM_TYPE2 = "";
					String stFOR_DRAWING_REMARK = "";
					String stOPTION_ETC = stCN_OPTION_ETC;
					String stOPTION_DESC = stCN_OPTION_DESC;
					String stPartInvestor =   "";
					String stESTIMATED_WEIGHT = "";
					String stITEM_TYPE1 = "";
					String stITEM_TYPE = "";
					String stSERIES_ITEM = "";
					String stPhase = "";
					
					String stPartCADWeight = ""; /*아직 데이타가 없음 속성 정보 재요청 필요 */
					subPartCount = Integer.parseInt(stPartCount);
					tempStRowNum = stPartCount;
					tempStPartNo = stCN_ID;
					tempStPartRevision = stREVISION;
					String personIdMql = "temp query bus Person '" + stTDM_ORG_USER_ID + "' - select id dump |";
					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
					String stPerson = "";
					boolean boolPerson = false;
					if (stListPersonIdMql.size() > 2) {
						stPerson = (String) stListPersonIdMql.get(3);
						boolPerson = true;
					}
					
					
					/*  **************************************************************************************
					 *   stCLS_NAME 정보가 "Option Item" 이라면 CN_SUB_ID 정보를 CN_ID에 합쳐야한다. 
					 *  ************************************************************************************ */
					if("Option Item".equalsIgnoreCase(stCLS_NAME)){
						if(cdmStringUtil.isNotEmpty(stCN_SUB_ID)){
							stCN_ID +=stCN_SUB_ID;
						}
					}
					
					/* **************************************************************************************
					 * cdmPartGlobal 의 정보는 global,local 값이 없으면 ""  처리 
					 * ************************************************************************************* */
					for (int i = 0; i < attrPartGlobalKOList.size(); i++) {
	
						if (stCN_GLOBAL_LOCAL.equalsIgnoreCase((String) attrPartGlobalKOList.get(i))) {
							stGLOBAL_LOCAL = (String) attrPartGlobalList.get(i);
							break;
						}
					}
					if(cdmStringUtil.isEmpty(stGLOBAL_LOCAL)){
						stGLOBAL_LOCAL = "";
					}
					
					/*  **************************************************************************************
					 *   stCN_ITEM_TYPE2 의 정보는 
					 *   attribute[cdmPartItemType]관련 정보
					 *   
					 *   attribute[cdmPartItemType]의 display name과 일치하지않다면 에러 처리  
					 *  ************************************************************************************** */
//					boolean bITEM_TYPE2 = false;
//					for (int i = 0; i < attrPartItemTypeKOList.size(); i++) {
//	
//						if (stCN_ITEM_TYPE2.equals((String) attrPartItemTypeKOList.get(i))) {
//							stITEM_TYPE2 = (String) attrPartItemTypeList.get(i);
//							bITEM_TYPE2 = true;
//							break;
//						}
//						
//					}
					
					/* *****************************************************************************************
					 * stCN_FOR_DRAWING_REMARK 의 정보는 Part 의 한글 속성과 일치 
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					if(cdmStringUtil.isNotEmpty(stCN_FOR_DRAWING_REMARK) ){
						for (int i = 0; i < attrPartERPInterfaceKOList.size(); i++) {
	
							if (stCN_FOR_DRAWING_REMARK.equals((String) attrPartERPInterfaceKOList.get(i))) {
								stFOR_DRAWING_REMARK = (String) attrPartERPInterfaceList.get(i);
								break;
							}
						}
					}
					
					
					/* *****************************************************************************************
					 * CDM 의 UOM 과 전달받은 UOM 은 정보는 달라 기준정보 (MAP )로 찾아 데이타를 입력한다.
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					String sTempUOM = "";
					sTempUOM= (String)tempUOMHMap.get(stTDM_UOM);
					sTempUOM = cdmCommonExcel.isVaildNullData(sTempUOM);
					
					
					/* ******************************************************************************************************************
					 * stPartInvestor 의경우 
					 * stCN_FOR_MAC ,stCN_FOR_MIL,stCN_FOR_MMT 의 정보가 checked 되어 있는지여부를 확인하여 하나의 String 값으로 만듬 
					 * ****************************************************************************************************************   */
					if("Checked".equals(stCN_FOR_MAC)){
						stPartInvestor = "MAC";
					}
					if("Checked".equals(stCN_FOR_MIL)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MIL";
					}
					if("Checked".equals(stCN_FOR_MMT)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MMT";
					}
	
					
					/* ******************************************************************************************************************
					 *  attribute[cdmPartEstimateWeightUnit] 중량 단위 
					 *  넘어오는 데이타의 데이타가 없으면  attribute[cdmPartEstimateWeightUnit] 속성값은 G 로 입력된다 .
					 *  (넘어오는 데이타가 default 중량단위는 G )
					 * ****************************************************************************************************************** */
					String sTempWeightUnit = "";
					if("".equals(stCN_WEIGHT_UNIT)){
						sTempWeightUnit = "G";
					}else {
						//중량단위를 kg로 변환 !!
						if("g".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "G";
						}else if("lb".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "LBR";
						}else if("mg".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "MGR";
						}else if("ton".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "MT";
						}else if("N".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "N";
						}else if("kg".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "KG";
						}
						
					}
						
					
					/* *************************************************************************************
					 *   stCN_ORG1 가 PROTO 이면 stPhase 값은 proto 
					 *   stCN_PHANTOM_ITEM 가 체크되어있으면 파트 타입으로 "Phantom Part"변경
					 *   stPhase 여부와 상관없이 반드시 Proto 로 변경된다. 
					 * *********************************************************************************** */
					if("PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPhase = S_ATTRIBUTE_PHASE_PROTO;
					}else{
						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
					}
					
					if( "Checked".equalsIgnoreCase(stCN_PHANTOM_ITEM) &&  "PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPartType = "cdmPhantomPart";
						stPhase = S_ATTRIBUTE_PHASE_PROTO; //변경요청
					}
					
					
					
					  /* **********************************************************************************************************************
			         * type은 pre revision 정보가 있으며 그정보 의 object 가 phantom part 타입이면 생성할 object 타입도 phantom part 타입으로
			         * 변경  
			         *    
			         * ******************************************************************************************************************** */
//					if(cdmStringUtil.isNotEmpty(stPAR_REVISION)) {
//						 String stPreRevisionPhantomMql = "temp query bus '"+ TYPE_PHANTOMPART +"' '" +stCN_ID +"' '"+stPAR_REVISION+"'  select id  dump |";
//						 String stPreRevisionPhantomMqlResult =  MqlUtil.mqlCommand(context, stPreRevisionPhantomMql);
//						 StringList stListPreRevisionPhantomMqlResult = FrameworkUtil.split(stPreRevisionPhantomMqlResult, "|");
//						 
//						 if(stListPreRevisionPhantomMqlResult.size() > 2){
//							 stPartType = TYPE_PHANTOMPART;
//						 }
//					}
					
					
					
					/* ***************************************************************************************
				     *	데이타 중복확인 
					 * *************************************************************************************** */
					String duplicationPart = MqlUtil.mqlCommand(context, "temp query bus \""+stPartType+"\" \""+ stCN_ID+"\"  \""+ stREVISION +"\"  dump ");
					if(cdmStringUtil.isNotEmpty(duplicationPart)){
						String errorMessage = "ALREADY PART OBJECT "+stCN_ID;
						throw new Exception(errorMessage);
					}
					
					/* *************************************************************************************
					 * stITEM_TYPE1 은  cdmPartApprovalType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					
					
					if("자작".equals(stCN_ITEM_TYPE1)){
						stITEM_TYPE1 = "inSourcing";
					}else if("외주".equals(stCN_ITEM_TYPE1)){
						stITEM_TYPE1 = "outSourcing";
					}else{
						stITEM_TYPE1 = "";
					}
					
					
					
					/* *************************************************************************************
					 * stITEM_TYPE 은  cdmPartType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					stITEM_TYPE = "";
//					for (int attrPartTypeNum = 0; attrPartTypeNum < attrPartTypeKOList.size(); attrPartTypeNum++) {
//						String temPattrPartTypeKO = (String) attrPartTypeKOList.get(attrPartTypeNum);
//						if (stCN_ITEM_TYPE.equals(temPattrPartTypeKO)) {
//							stITEM_TYPE = (String) attrPartTypeList.get(attrPartTypeNum);
//							break;
//						}
//					}
					
					//
					if("단품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "singleSupply";
					}else if("완제품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "completeProduct";
					}else if("반제품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "halfFinishedProduct";
					}else if("원부자재".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "rawMaterial";
					}
					//
//					if(stCN_ITEM_TYPE == null || "".equals(stCN_ITEM_TYPE) ){
//						stITEM_TYPE = "";
//					} else {
	
//						AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
//						attrPartType.open(context);
//						StringList attrPartTypeList = attrPartType.getChoices(context);
//	
//						StringList attrPartTypeKOList = new StringList();
//						attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
	
						
//					}
	
					
					/* *************************************************************************************
					 * SERIES_ITEM 값이 Checked 이면 true unChecked 이면 false 
					 * *********************************************************************************** */
					if("Checked".equalsIgnoreCase(stCN_SERIES_ITEM)){
						stSERIES_ITEM = "true"; 
					}else{
						stSERIES_ITEM = "false";
					}
					
					/*stCN_SURFACE_TREATMENT 은 사용되지않아 "" 처리한다. */
					String stSURFACE_TREATMENT = ""; 
					
					/*stCN_IS_CASTING*/
					String stIS_CASTING = "";
					if(!"0".equals(stCN_IS_CASTING)){
						stIS_CASTING = "yes";
					}else{
						stIS_CASTING = "no";
					}
					
					
					/*stCN_FOR_DRAWING_FINISH*/
					String stCFOR_DRAWING_FINISH = "";
					if("0".equals(stCN_FOR_DRAWING_FINISH)){
						stCFOR_DRAWING_FINISH = "unChecked";
					}else{
						stCFOR_DRAWING_FINISH = "Checked";
					}
					
					/*stCN_FOR_DRAWING_SIZE*/
					String stDRAWING_SIZE = "";
					if("0".equals(stCN_FOR_DRAWING_SIZE)){
						stDRAWING_SIZE = "unChecked";
					}else{
						stDRAWING_SIZE = "Checked";
					}
					
					HashMap attributes = new HashMap();
					if(UIUtil.isNotNullAndNotEmpty(stPhaseM)){
						attributes.put("cdmPartPhaseM", 		 	  stPhaseM		                   );
					}
			        attributes.put("cdmPartNo",          	      stCN_ID 			               );
//			        attributes.put("cdmPartVehicle", 	 	      stCN_VEHICLE_DESC		           );
			        attributes.put("cdmPartName", 		 	      stTDM_DESCRIPTION	               );
//			        attributes.put("cdmPartProject", 	 	      stCN_PROJECT		               );
			        attributes.put("cdmPartApprovalType", 	      stITEM_TYPE1	                   );
			        attributes.put("cdmPartType", 		          stITEM_TYPE	                   );
			        attributes.put("cdmPartGlobal", 			  stGLOBAL_LOCAL                   );
			        attributes.put("cdmPartDrawingNo", 			  stCN_DRAWING_NO                  );
//			        attributes.put("cdmPartUOM",     		      stTDM_UOM                        );
			        attributes.put("cdmPartUOM",     		      sTempUOM                        );
//			        데이타가 깨진것이 있어 추후 cdmPartUOM 값을 변경해야함 12/06/16 12:19:00 이후 마이그레이션 대상으로
//			        attributes.put("cdmPartUOM_TempM",     		      stTDM_UOM                        );
			        attributes.put("cdmPartECONumber", 			  stCN_ECO_NUMBER                  );
			        attributes.put("cdmPartItemType", 			  stCN_ITEM_TYPE2                  );
			        attributes.put("cdmPartOEMItemNumber", 		  stCN_OEM_PART_NUMBER             );
			        attributes.put("cdmPartProductType", 		  stCN_PRODUCT_DIV                 );
			        attributes.put("cdmPartERPInterface", 		  stFOR_DRAWING_REMARK             );
			        attributes.put("cdmPartSurface", 			  stCN_SURFACE_AREA                );
//			        attributes.put("cdmPartEstimatedWeight", 	  stESTIMATED_WEIGHT               );
			        attributes.put("cdmPartEstimatedWeight", 	  stCN_ESTIMATED_WEIGHT            );
			        attributes.put("cdmPartMaterial", 			  stCN_ITEM_MATERIAL               );
			        attributes.put("cdmPartRealWeight", 		  stCN_REAL_WEIGHT                 );
			        attributes.put("cdmPartSize", 				  stCN_SIZE                        );
			        attributes.put("cdmPartCADWeight", 			  stPartCADWeight                  );
			        attributes.put("cdmPartSurfaceTreatment", 	  stSURFACE_TREATMENT              );
			        attributes.put("cdmPartIsCasting", 			  stIS_CASTING                     );
//			        attributes.put("cdmPartOption1", 			  stCN_OPTION1                     );
//			        attributes.put("cdmPartOption2", 			  stCN_OPTION2                     );
//			        attributes.put("cdmPartOption3", 			  stCN_OPTION3                     );
//			        attributes.put("cdmPartOption4", 			  stCN_OPTION4                     );
//			        attributes.put("cdmPartOption5", 			  stCN_OPTION5                     );
//			        attributes.put("cdmPartOption6", 		   	  stCN_OPTION6                     );
			        attributes.put("cdmPartOptionETC",         	  stOPTION_ETC               	   );
			        attributes.put("cdmPartOptionDescription", 	  stOPTION_DESC            		   );
			        attributes.put("cdmPartPublishingTarget",     stCN_COST                        );
			        attributes.put("cdmPartInvestor",          	  stPartInvestor                   );
//			        attributes.put("cdmPartProjectType",          stCN_PRODUCT_GROUP               ); // 
//			        attributes.put("cdmPartProductDivision",      stCN_PRODUCT_GROUP               ); //?? 확인 작업이 필요 
					
			        /*migration을 작업을 위해 attribute 추가 start */
			        attributes.put("cdmPartItemOtionItemM",        stCLS_NAME                      );
			        attributes.put("cdmPartPreviousRevisionM",     stPAR_REVISION                  );
			        attributes.put("cdmPartCheckPhantomPartM",     stCN_PHANTOM_ITEM   	           );
			        attributes.put("cdmPartECNameM",               stEC_NAME    	               );
			        attributes.put("cdmPartSeriesItemM",           stSERIES_ITEM                   );
			        attributes.put("cdmPartMCAOrgM",               stCN_ORG      	               );
			        attributes.put("cdmPartMCABOMManagementM",     stCN_MCA_INOUT        	       );
			        attributes.put("cdmPartMCAPartTypeM",          stCN_MCA_PART_TYPE_REF          );
			        attributes.put("cdmPartOption7",          	   stCN_OPTION7                    );
			        attributes.put("cdmPartCountryM",          	   stCN_COUNTRY                    );
			        attributes.put("cdmPartDrawingFinishM",        stCFOR_DRAWING_FINISH           );
			        attributes.put("cdmPartDrawingSizeM",          stDRAWING_SIZE                  );
			        attributes.put("cdmPartApplyPartListM",        stCN_APPLY_PARTLIST             );
			        attributes.put("cdmPartSubIdM",                stCN_SUB_ID                     );
			        attributes.put("cdmPartMCPOrgM",          	   stCN_OVERSEAS_ORG6              );
			        attributes.put("cdmPartMCPPartTypeM",          stCN_OVERSEAS_ORG6_PART_TYPE    );
			        attributes.put("cdmPartMCPBOMManagementM",     stCN_OVERSEAS_ORG6_INOUT 	   );  
			        attributes.put("cdmPartCreationDateM",        stCREATION_DATE     	           );  
			        attributes.put("cdmPartCreationUserIdM",      stUSER_OBJECT_ID  	           );  
			        attributes.put("cdmPartModUserIdM",           stUSER_ID_MOD  	               );  
			        attributes.put("cdmPartModificationDateM",    stMODIFICATION_DATE  	           );  
			        attributes.put("cdmPartComplexBodyForRealWeightM",  stCN_COMPLEX_BODY          );
			        attributes.put("cdmCheckMigration",           "Y"					  	       );
			        attributes.put("cdmPartPhase",           	   stPhase			  	       	   );
			        //add attribute 11/17/2016 start 
			        attributes.put("cdmPartApplyPartList",           "true"				  	       );
			        attributes.put("cdmPartApplySizeList",           "false"			  	       );
			        attributes.put("cdmPartApplySurfaceTreatmentList", "false"	  				   );
			        //add attribute 11/17/2016 end 
			        attributes.put("cdmPartEstimateWeightUnit", sTempWeightUnit			   );
			        
			        /*migration을 작업을 위해 attribute 추가 end  */
			        
			      
			        /* **********************************************************************************************************************
			         * part 데이타 생성 및 데이타 
			         * 트리거 오프한 상태로 진행되며 트리거에서 제공되는 attribute[originator]속성 및 interface 추가 설정 필터 정보 와 
			         * rev 정보 part master 생성 및 연결 및 속성(attribute[Originator]속성 추가 
			         * 에러 발생시 정지 및 데이타 정보 검색 
			         * ******************************************************************************************************************* */
			        
			        DomainObject partObj = new DomainObject();
			        boolean bCommit = false;
//					partObj.createObject(context, stPartType, stCN_ID, stREVISION, cdmConstantsUtil.POLICY_CDM_PART_POLICY, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        ContextUtil.startTransaction(context, true);
			        bCommit = true;
			        boolean bNewPartCheck = false;
			        boolean reviseCheck = false;
			        BusinessObject previousPart  = null;
			        
			        
			        boolean checkPartPrevious = false;
//			        boolean existPreviousPart = previousPart.exists(context);
			        
			        if(  stCN_ID.equals(strPreviousPartNo) ) {
			        	previousPart  = new BusinessObject(strPreviousPartType,strPreviousPartNo,strPreviousPartRevision,"eService Production");
				        if(previousPart.exists(context)){
				        	checkPartPrevious = true;
				        }
//			        if(stCN_ID.equals(strPreviousPartNo) && !existPreviousPart){
//			        	previousPart  = new BusinessObject(strPreviousPartType,stCN_ID,strPreviousPartRevision,"eService Production");
//			        }
//			        	if(previousPart.exists(context)){
//			        		checkPartPrevious = true;
//			        	}
			        }
			        
			        if(checkPartPrevious){
			        	BusinessObject currentPart = previousPart.revise(context, stREVISION, "eService Production");
			        	partObj.setId(currentPart.getObjectId(context));
			        	
			        	StringBuffer sbRelType = new StringBuffer();
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION);
			        	 
			        	StringList relList = new StringList();
			        	relList.add("id[connection]");
			        	
			        	MapList mlCodes = partObj.getRelatedObjects(context,
			        			sbRelType.toString(), // relationship pattern
			                    "*", // object pattern
			                    null, // object selects
			                    relList, // relationship selects
			                    true, // to direction
			                    false, // from direction
			                    (short) 1, // recursion level
			                    "", // object where clause
			                    null); // relationship where clause
			        	
			        	for (int jj = 0; jj < mlCodes.size(); jj++) {
							Map mapCode = (Map)mlCodes.get(jj);
							String relid = (String)mapCode.get("id[connection]");
							
							MqlUtil.mqlCommand(context, "del connection "+relid);
							
						}
			        } else {
			        	partObj.createObject(context, stPartType, stCN_ID, stREVISION, "cdmPartPolicy", cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        	bNewPartCheck = true;
			        }
			        strPreviousPartNo = stCN_ID;
					strPreviousPartRevision = stREVISION;
					strPreviousPartType = stPartType;

					
					
					if ("In Approval".equals(stSTATE)) {
						stSTATE = "Review";
						
					} else if ("Inactive".equals(stSTATE)) {
						stSTATE = "Obsolete";
						
					}else if ("Released".equals(stSTATE)) {
						stSTATE = "Release";
							
						
					}else if ("In Work".equals(stSTATE)) {
						stSTATE = "Preliminary";
					}
					
					partObj.setState(context, stSTATE);
					
					String partObjectId = partObj.getId(context);

					if(boolPerson){
						partObj.setOwner(context, stTDM_ORG_USER_ID); 
					}
					
					
					/*
					 * *********************************************************
					 *  create 시 발생하는 trigger에서 발생하는 interface 생성 start
					 * *********************************************************
					 */
//					boolean isMEP = false;
//	
//					if (partObjectId != null && !"".equals(partObjectId)) {
//						String sExternalPartData = PropertyUtil.getSchemaProperty(context, DomainSymbolicConstants.SYMBOLIC_interface_ExternalPartData);
//						Part part = new Part(partObjectId);
//						String sPolicyClassification = part.getInfo(context, "policy.property[PolicyClassification].value");
//
//						// enable MEP by default
//						if (sPolicyClassification != null && "Equivalent".equals(sPolicyClassification)) {
//							isMEP = true;
//						}
//						if (isMEP) {
//							MqlUtil.mqlCommand(context, "modify bus $1 add interface $2;", partObjectId, sExternalPartData);
//						}
//					}
		
						/*
						 * *********************************************************
						 * attribute[attribute_Originator]
						 * 의 정보를stTDM_ORG_USER_ID 정보를 입력.
						 * *********************************************************
						 * 
						 */
						partObj.setAttributeValue(context, DomainConstants.ATTRIBUTE_ORIGINATOR, stTDM_ORG_USER_ID);
		
						/* part Master 생성 start */
						createPartMaster(context, partObjectId, stTDM_ORG_USER_ID,boolPerson);
						/* part Master 생성 end */
		
						/* create 시 발생하는 trigger에서 사용된 정보 interface 생성 end */
		
						/*
						 * *********************************************************
						 * 
						 *  EBOM 정보로 연결된 Part 을 생성할시 relationship 연결을 제외된다.
						 * 또한 relationship 연결의 경우 공통코드 데이타가 PLM에 스마트팀 정보가 다 있다고 가정하여
						 * 진행 공통코드를 검색하여 데이타가 없을시 오류 처리 . 오류가 발생하면 Exception 발생.
						 * *********************************************************
						 */
		
						StringBuffer sbVehicleId = new StringBuffer("");
						StringBuffer sbProjectId = new StringBuffer("");
						StringBuffer sbProjectTypeId = new StringBuffer("");
						StringBuffer sbProductTypeId = new StringBuffer("");
		
						StringBuffer sbOrg1Id = new StringBuffer();
						StringBuffer sbOrg2Id = new StringBuffer();
						StringBuffer sbOrg3Id = new StringBuffer();
		
						StringBuffer sbOption1Id = new StringBuffer("");
						StringBuffer sbOption2Id = new StringBuffer("");
						StringBuffer sbOption3Id = new StringBuffer("");
						StringBuffer sbOption4Id = new StringBuffer("");
						StringBuffer sbOption5Id = new StringBuffer("");
						StringBuffer sbOption6Id = new StringBuffer("");
		
						StringBuffer sbECONumberId = new StringBuffer("");
						StringBuffer sbDrawingNoId = new StringBuffer("");
						StringList sListPFs = new StringList();
						/* ************************************************
						 * stCN_VEHICLE_DESC 정보는 두개 이상 있을수 있으며 구분자 , 
						 * stVehicle_Cust 정보의 경우 두개이상 데이타 존재 있을수 있다 구분자 ;
						 * ************************************************
						 * */
						StringList stListCN_VEHICLE_DESC = new StringList();
						StringList stListVehicle_Cust = new StringList();
	
						stListCN_VEHICLE_DESC = FrameworkUtil.split(stCN_VEHICLE_DESC, ",");
	
						boolean checkErrorVehicleCust = false;
						if (stVehicle_Cust.startsWith("ORA-01422") || "-2147483647".equals(stVehicle_Cust)) {
							checkErrorVehicleCust = true;
						} else {
							stListVehicle_Cust = FrameworkUtil.split(stVehicle_Cust, ";");
						}
						int vehicleCustInt = 0;
						int vehicleDesInt = 0;
						vehicleCustInt = stListVehicle_Cust.size();
						vehicleDesInt = stListCN_VEHICLE_DESC.size();
						if (cdmStringUtil.isNotEmpty(stCN_VEHICLE_DESC) &&  !checkErrorVehicleCust) {
							StringList sListVehicleIds = new StringList();
//							if (vehicleCustInt == vehicleDesInt) {
//								for (int stListVehicleNum = 0; stListVehicleNum < stListCN_VEHICLE_DESC.size(); stListVehicleNum++) {
//	
//									String stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);
//	
//									String stTempVehicleCust = (String) stListVehicle_Cust.get(stListVehicleNum);
//	
//									String searchVehicle = stTempVehicle + "_" + stTempVehicle + "_" + stTempVehicleCust;
//	
//									String tempVehicleId = (String) vehicleCommonCodeMap.get(searchVehicle);
//									tempVehicleId = (tempVehicleId == null || "null".equals(tempVehicleId)) ? "" : tempVehicleId.trim();
//									if (StringUtils.isNotEmpty(tempVehicleId) && !sListVehicleIds.contains(tempVehicleId)) {
//										sListVehicleIds.add(tempVehicleId);
//										sbVehicleId.append(tempVehicleId);
//										sbVehicleId.append(",");
//									}
//	
//								}
								
								//
							if (vehicleCustInt >0) {
								for (int stListVehicleNum = 0; stListVehicleNum < stListVehicle_Cust.size(); stListVehicleNum++) {
									
									String stTempVehicle = "";
									if(stListVehicleNum+1<=vehicleDesInt){
										stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);
									}else{
										continue;
									}
//									String stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);
	
									String stTempVehicleCust = (String) stListVehicle_Cust.get(stListVehicleNum);
									String checkVehicleCust = ""; 
									checkVehicleCust = stTempVehicleCust.trim();
									if("-".equals(checkVehicleCust)){
										continue;
									}
									String searchVehicle = stTempVehicle + "_" + stTempVehicle + "_" + stTempVehicleCust;
	
									String tempVehicleId = (String) vehicleCommonCodeMap.get(searchVehicle);
									tempVehicleId = (tempVehicleId == null || "null".equals(tempVehicleId)) ? "" : tempVehicleId.trim();
									if (StringUtils.isNotEmpty(tempVehicleId) && !sListVehicleIds.contains(tempVehicleId)) {
										sListVehicleIds.add(tempVehicleId);
										sbVehicleId.append(tempVehicleId);
										sbVehicleId.append(",");
									}
	
								}
								//
							}
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_VEHICLE_DESC) && cdmStringUtil.isEmpty(sbVehicleId.toString()) && !checkErrorVehicleCust){
//							sbErrorMessage.append("No Vehicle information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Project */
						if (cdmStringUtil.isNotEmpty(stCN_Project_Id)) {
							
//							String projectIdMql = " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectCode] =='" + stCN_PROJECT + "' &&  attribute[cdmProjectGroupCustomerAttribute] =='" + stCN_PROJECT_CUST + "' && attribute[cdmProjectGroupProductTypeAttribute] == '" + stCN_PRODUCT_DIV + "' \" select id dump |";
//							String projectIdMql = " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectObjectIdM] =='" + stCN_Project_Id +"' select id dump |";
//							String projectIdMqlResult = MqlUtil.mqlCommand(context, projectIdMql);
//							StringList stListProjectMqlResult = FrameworkUtil.split(projectIdMqlResult, "|");
							String stTempProjectId = "";
							stTempProjectId = (String)projectMap.get(stCN_Project_Id);
							stTempProjectId = (stTempProjectId == null || "null".equals(stTempProjectId)) ? "" : stTempProjectId.trim();
							sbProjectId.append(stTempProjectId);
							
						}
						
						if(cdmStringUtil.isEmpty(sbProjectId.toString())){
//							sbErrorMessage.append("No Project information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						// Product Group
						if (cdmStringUtil.isNotEmpty(stCN_PRODUCT_GROUP)) {
							String stTempProductGroupId = (String)productGroupMap.get(stCN_PRODUCT_GROUP+"_"+stCN_PRODUCT_DIV);
							stTempProductGroupId = (stTempProductGroupId == null || "null".equals(stTempProductGroupId)) ? "" : stTempProductGroupId.trim();
							sbProjectTypeId.append(stTempProductGroupId);
	
						}
	
						if(cdmStringUtil.isNotEmpty(stCN_PRODUCT_GROUP) && cdmStringUtil.isEmpty(sbProjectTypeId.toString())){
//							sbErrorMessage.append("No Product Group information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Product Div */
						if ( cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempProductDivId = (String)productDivMap.get(stCN_PRODUCT_DIV);
							stTempProductDivId = (stTempProductDivId == null || "null".equals(stTempProductDivId)) ? "" : stTempProductDivId.trim();
							sbProductTypeId.append(stTempProductDivId);
	
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV) && cdmStringUtil.isEmpty(sbProductTypeId.toString())){
//							sbErrorMessage.append("No Product Div information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
	
						/* Option1 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION1)) {
							
							String stTempOption1 = "";
							stTempOption1 = (String)option1Map.get(stCN_OPTION1+"_"+stCN_PRODUCT_DIV);
							stTempOption1 = (stTempOption1 == null || "null".equals(stTempOption1)) ? "" : stTempOption1.trim();
							sbOption1Id.append(stTempOption1);
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_OPTION1) && cdmStringUtil.isEmpty(sbOption1Id.toString())){
//							sbErrorMessage.append("No OPTION1 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Option2 */
//						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeOption2Id) && cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
						if (cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption2 = "";
							stTempOption2 = (String)option2Map.get(stCN_OPTION2+"_"+stCN_PRODUCT_DIV);
							stTempOption2 = (stTempOption2 == null || "null".equals(stTempOption2)) ? "" : stTempOption2.trim();
							sbOption2Id.append(stTempOption2);
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isEmpty(sbOption2Id.toString())){
//							sbErrorMessage.append("No OPTION2 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
	
						/* Option3 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION3) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption3 = "";
							stTempOption3 = (String)option3Map.get(stCN_OPTION3+"_"+stCN_PRODUCT_DIV);
							stTempOption3 = (stTempOption3 == null || "null".equals(stTempOption3)) ? "" : stTempOption3.trim();
							sbOption3Id.append(stTempOption3);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION3) && cdmStringUtil.isEmpty(sbOption3Id.toString())){
//							sbErrorMessage.append("No OPTION3 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option4 */
						if ( cdmStringUtil.isNotEmpty(stCN_OPTION4) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption4 = "";
							stTempOption4 = (String)option4Map.get(stCN_OPTION4+"_"+stCN_PRODUCT_DIV);
							stTempOption4 = (stTempOption4 == null || "null".equals(stTempOption4)) ? "" : stTempOption4.trim();
							sbOption4Id.append(stTempOption4);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION4) && cdmStringUtil.isEmpty(sbOption4Id.toString())){
//							sbErrorMessage.append("No OPTION4 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option5 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION5) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							
							String stTempOption5 = "";
							stTempOption5 = (String)option5Map.get(stCN_OPTION5+"_"+stCN_PRODUCT_DIV);
							stTempOption5 = (stTempOption5 == null || "null".equals(stTempOption5)) ? "" : stTempOption5.trim();
							sbOption5Id.append(stTempOption5);
	
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION5) && cdmStringUtil.isEmpty(sbOption5Id.toString())){
//							sbErrorMessage.append("No OPTION5 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option6 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION6) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption6 = "";
							stTempOption6 = (String)option6Map.get(stCN_OPTION6+"_"+stCN_PRODUCT_DIV);
							stTempOption6 = (stTempOption6 == null || "null".equals(stTempOption6)) ? "" : stTempOption6.trim();
							sbOption6Id.append(stTempOption6);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION6) && cdmStringUtil.isEmpty(sbOption6Id.toString())){
//							sbErrorMessage.append("No OPTION6 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* sbECONumberId */
					if (cdmStringUtil.isNotEmpty(stCN_ECO_NUMBER)) {
						StringBuffer sbfECType = new StringBuffer();
						sbfECType.append("cdmECO");
						sbfECType.append(",");
						sbfECType.append("cdmEAR");
						sbfECType.append(",");
						sbfECType.append("cdmDCR");
						sbfECType.append(",");
						sbfECType.append("cdmPEO");
						
						
						String stTempECExist = "temp query bus \"" + sbfECType.toString() + "\" \""+stCN_ECO_NUMBER +"\"  *  select id dump |";
						String stTempECExistMql = MqlUtil.mqlCommand(context, stTempECExist);
						StringList sListTempECExistMql = FrameworkUtil.split(stTempECExistMql, "|");
						// test start start
						if (sListTempECExistMql.size() > 2) {
							sbECONumberId.append(sListTempECExistMql.get(3));
							sbErrorMessage.append("X").append("\t");
						} else {
//							sbErrorMessage.append( "EC information does not exist.");
							sbErrorMessage.append("O").append("\t");
						}
					}
					
					//Part Family
					if (stCN_ID.length() > 6) {

						String pfCodeName = stCN_ID.substring(0, 5);
						String partFamilys = (String)partFamilyMap.get(pfCodeName);
						partFamilys = (partFamilys == null || "null".equals(partFamilys)) ? "" : partFamilys.trim();
						sListPFs = FrameworkUtil.split(partFamilys, ",");
						if(cdmStringUtil.isEmpty(partFamilys) ){
//							if(bNewPartCheck){
								sbErrorMessage.append("O").append("\t");
//							}else{
//								sbErrorMessage.append("X").append("\t");
//							}
						}else{
//							if(bNewPartCheck){
								sbErrorMessage.append("X").append("\t");
//							}else{
//								sbErrorMessage.append("O").append("\t");
//							}
						}
					}
					
//						stCN_ECO_NUMBER
						/* sbDrawingNoId */
					
					HashMap paramHM = new HashMap();
					paramHM.put("partObjectId", partObjectId);
					paramHM.put("VehicleObjectId", sbVehicleId.toString());
					paramHM.put("ProjectObjectId", sbProjectId.toString());
					paramHM.put("ProjectTypeObjectId", sbProjectTypeId.toString());
					paramHM.put("ProductTypeObjectId", sbProductTypeId.toString());
						
					String[] objectIdArray = sbVehicleId.toString().split(",");
					for(int i=0; i<objectIdArray.length; i++){
	    				String strVehicleId = objectIdArray[i];
	    				
	    				if(StringUtils.isEmpty(strVehicleId.trim()))
	    					continue;
	    				
	    				DomainRelationship.connect(context, new DomainObject(strVehicleId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
	    			}
						
						if(UIUtil.isNotNullAndNotEmpty(sbProjectId.toString())){
			    			DomainRelationship.connect(context, new DomainObject(sbProjectId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT, partObj);
			    		}
						
						if(UIUtil.isNotNullAndNotEmpty(sbProjectTypeId.toString())){
							DomainRelationship.connect(context, new DomainObject(sbProjectTypeId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE, partObj);
			        	}
						
						//product group
						if(UIUtil.isNotNullAndNotEmpty(sbProductTypeId.toString())){
			    			DomainRelationship.connect(context, new DomainObject(sbProductTypeId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE, partObj);
			        	}
						
						if(UIUtil.isNotNullAndNotEmpty(sbOption1Id.toString())){
							DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption1Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
							x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option1");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption2Id.toString())){
			    		     
			    		    DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption2Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option2");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption3Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption3Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option3");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption4Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption4Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option4");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption5Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption5Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option5");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption6Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption6Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option6");
			        	}
			        	
						paramHM.put("ECONumberOid", sbECONumberId.toString());
						if(UIUtil.isNotNullAndNotEmpty(sbECONumberId.toString())){
		        			DomainRelationship.connect(context, new DomainObject(sbECONumberId.toString()), DomainConstants.RELATIONSHIP_AFFECTED_ITEM, partObj);
			        		
			        	}
						bCommit = true;
						ContextUtil.commitTransaction(context);		
					if (bNewPartCheck) {
						int sListPartFamilyIdsSize = sListPFs.size();
						boolean bCheckPartNamePF = false;
						boolean bExceedOnePF = false;
						for (Iterator iterPF = sListPFs.iterator(); iterPF.hasNext();) {
							
							String sPF = (String) iterPF.next();
							HashMap connectPFHMap = new HashMap();
							
							if(sListPartFamilyIdsSize>1){
								String pfCodeName = stCN_ID.substring(0, 5);
								String checkPartFamilyName = pfCodeName+":"+stTDM_DESCRIPTION;
								bExceedOnePF = true;
								sPF = (String)partFamilyMap.get(checkPartFamilyName);
								if(UIUtil.isNotNullAndNotEmpty(sPF)){
									bCheckPartNamePF = true;
								}
							}
							
							if ( (UIUtil.isNotNullAndNotEmpty(sPF) && bExceedOnePF) || sListPartFamilyIdsSize == 1) {
								connectPFHMap.put("sPF", sPF);
								connectPFHMap.put("partObjectId", partObjectId);
//							
								String connectResult = JPO.invoke(context, "cdmPartMigration", null, "connectPartFamily", JPO.packArgs(connectPFHMap), String.class);
								
								if (connectResult.startsWith("false|")) {
									sbErrorMessage.append("O (PartFamily)").append(connectResult).append("\t");
									
								} else {
									sbErrorMessage.append("X (PartFamily)").append("\t");
									implementInterfaceOnClassifiedItem(context,sPF,partObjectId);
								}
								break;
							}
						}
						//2개 이상 part family 과 존재하지만  stCN_ID  자른 정보와 part family의 name 값이 일치하지않을경우 하나의 part family만 연결한다.
						if(bExceedOnePF && !bCheckPartNamePF){
							//
							for (int exceedOnePfCnt = 0 ;exceedOnePfCnt<sListPFs.size();exceedOnePfCnt++ ) {
								
								String sPF = (String) sListPFs.get(0);
								HashMap connectPFHMap = new HashMap();
								
								String pfCodeName = stCN_ID.substring(0, 5);
								String checkPartFamilyName = pfCodeName+":"+stTDM_DESCRIPTION;
								
								if ( UIUtil.isNotNullAndNotEmpty(sPF)  ) {
									connectPFHMap.put("sPF", sPF);
									connectPFHMap.put("partObjectId", partObjectId);
									
									String connectResult = JPO.invoke(context, "cdmPartMigration", null, "connectPartFamily", JPO.packArgs(connectPFHMap), String.class);
									
									if (connectResult.startsWith("false|")) {
										sbErrorMessage.append("O (PartFamily)").append("\t");
									} else {
										sbErrorMessage.append("X (PartFamily)").append("\t");
										implementInterfaceOnClassifiedItem(context,sPF,partObjectId);
									}
									break;
								}
							}
							//
						}
						checkAddPart = true;
					}else{
						checkAddPart = true;
						sbErrorMessage.append("X (Revise PartFamily)").append("\t");
					}
//						paramHM.put("DrawingNo_Oid", sbDrawingNoId.toString());
//						Boolean ErrorCheck = (Boolean) JPO.invoke(context, "cdmPartLibrary", null, "checkPartObjectRelationShip", JPO.packArgs(paramHM), Boolean.class);
						//(Context context, String partObjectId, String vehicleObjectId,
//			    		String projectObjectId, String projectTypeObjectId, String productTypeObjectId, String org1ObjectId, 
//						String org2ObjectId, String org3ObjectId, String option1ObjectId, String option2ObjectId,
//						String option3ObjectId, String option4ObjectId, String option5ObjectId, String option6ObjectId, String ecId, String drawingId) 
						
//						partObjectRelationShip(context, partObjectId, VehicleObjectId, ProjectObjectId, ProjectTypeObjectId, ProductTypeObjectId, Org1ObjectId, Org2ObjectId, Org3ObjectId, Option1ObjectId, Option2ObjectId, Option3ObjectId, Option4ObjectId, Option5ObjectId, Option6ObjectId, ECONumberOid, DrawingNo_Oid);
//			    		DomainObject partObj = new DomainObject(partObjectId);
//			    		if(UIUtil.isNotNullAndNotEmpty(vehicleObjectId)){
//			    			StringList relVehicleIdList = partObj.getInfoList(context, "to["+cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE+"].id");
//			    			if(relVehicleIdList.size() > 0 && ! "".equals(relVehicleIdList)){
//			    				for(int k=0; k<relVehicleIdList.size(); k++){
//			    					DomainRelationship.disconnect(context, relVehicleIdList.get(k).toString());
//			    				}
//			    			}
//			    		    if(vehicleObjectId.contains(",")){
//			    				String[] objectIdArray = vehicleObjectId.split(",");
//			    				StringBuffer strBuffer = new StringBuffer();
//			    				for(int i=0; i<objectIdArray.length; i++){
//			    					String strVehicleId = objectIdArray[i];
//			    					DomainRelationship.connect(context, new DomainObject(strVehicleId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
//			    				}
//			    		    }else{
//			    			    if(!"".equals(vehicleObjectId)){
//			    					DomainRelationship.connect(context, new DomainObject(vehicleObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
//			    				}
//			    		    }
//			    		}
					
						/*
						 * *********************************************************
						 * promote 및 revise "In Approval" 상태를
						 * 가진 part 정보일경우 enovia에서는 In Review 상태로 ... "Inactive" 상태를
						 * 가진 part 정보일경우 enovia에서는 Obsolete 상태로 변경. 과거 revision을 가진
						 * object 은 무조건 Released 상태를 가진다. 현재 eo 데이타는 존재하지않아 연결정보를
						 * 사용할 수 없다. 현재 상태로는 eo 데이타가 없고 drawing 데이타가 연결이 되지않아 추후 연결
						 * 필요
						 * 
						 * 도면 있을 때 에는 revise 될때 같이 처리해야한다. 참조 cdmPartLibray
						 * revise... 소스는 빼논 상태
						 * *********************************************************
						 * 
						 */
//					bCommit = true;
//					ContextUtil.commitTransaction(context);	
					

					if (UIUtil.isNotNullAndNotEmpty(stCREATION_DATE) ) {
						Date createdate = new Date(stCREATION_DATE);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa", new Locale("en", "US"));
						String tempCreatedDate = "";
						tempCreatedDate = sdf.format(createdate);
						//12/6/2016 10:40:16 AM
						MqlUtil.mqlCommand(context, "mod bus $1 originated $2", partObjectId, tempCreatedDate);
					}

					
					try {
						MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", partObjectId, stAccessProductGroup, stAceesOrg);
						
						if(UIUtil.isNullOrEmpty(stAccessProductGroup) || " - ".equals(stAceesOrg)  || UIUtil.isNullOrEmpty(stAceesOrg)){
							sbErrorMessage.append(stAccessProductGroup).append("\t").append(stAceesOrg).append("\t").append("project or Org not exist").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t").append("X").append("\t");
						}
					} catch (Exception e) {
						sbErrorMessage.append(stAccessProductGroup).append("\t").append(stAceesOrg).append("\t");
					}
					
					
					if(bCommit){
						try{
						partObj.setAttributeValues(context, attributes);
						sbErrorMessage.append("X").append("\t");
						}catch(Exception e4){
							sbErrorMessage.append("O").append("\t");
						}
					}
					
					MqlUtil.mqlCommand(context, "trigger on");
					checkTriggerOff = false;	
						
					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
//						writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());	
						writeSuccessToFile(cdmCommonExcel.getTimeStamp() +"\t"+ subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+sbErrorMessage.toString());	
					}else{
//							writeSuccessToFile("LineNum(#): "+subPartCount +" \t PartNo: \t "+tempStPartNo+" \t ");
						writeSuccessToFile(cdmCommonExcel.getTimeStamp()+"\t"+subPartCount +"\t"+tempStPartNo+"\t"+stREVISION);
							
					}
						
					successCount++;
						
				} catch (Exception e) {
					ContextUtil.abortTransaction(context);

//					if(!checkAddPart){
//						MQLCommand mqlCommand = new MQLCommand();
//						mqlCommand.open(context);
//						mqlCommand.executeCommand(context, "abort transaction $1","PartFamily");
//					}
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "trigger on");
						checkTriggerOff = false;			
					}
					failCount++;
					writeErrorToFile("LineNum(#) \t"+tempStRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t "+ tempStPartNo+"\t"+tempStPartRevision +"\t"+e.getMessage().replaceAll("\r|\n", "")); 
					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t" +  data ) ;
					e.printStackTrace(errorStream);
					
					writeShotErrorToFile("LineNum(#) \t"+tempStRowNum + " \t"+cdmCommonExcel.getTimeStamp2()+"\t "+tempStPartNo+"\t"+tempStPartRevision +"\t"+e.toString().replaceAll("\r|\n", ""));
				}finally{
					
				}
				
			} // end of while 
			
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================");
			//
		} catch (Exception e1) {
			writeFailToFile(" LineNum(#):"+tempStRowNum);
			writeErrorToFile("LineNum(#):"+tempStRowNum + "  "+e1.getMessage());
			e1.printStackTrace(errorStream);
			
			
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("	CREATE PART OBJECT CLOSE TIME:  "+cdmCommonExcel.getTimeStamp2()+"          "  );
			writeMessageToConsole("	CREATE PART OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+") TOTALCOUNT :("+totalCount+")"  );
			writeMessageToConsole("==================================================================================== \n");
			MqlUtil.mqlCommand(context, "history on");
			if(checkTriggerOff){
				MqlUtil.mqlCommand(context, "trigger on");
			}
			try {
				if (null != errorStream )
					errorStream .close();

				if (null != logWriter)
					logWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if(null != bufferReader)
					bufferReader.close();
				
				if(null != errorLogFile)
					errorLogFile.close();
				
				if(null != debugLogFile)
					debugLogFile.close();

				if(null != errorLogFile)
					errorLogFile.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			
			long endTime = System.currentTimeMillis();
			long leadTime = (endTime-startTime)/1000/60;
			System.out.println("cdmPartMigration : executeCreatePartMigration End.   endTime:"+cdmCommonExcel.getTimeStamp()  + " leadTime :"+leadTime);
			
		}
	
	
    }
    
    
    
    /** 
	 * part connect part Family  
	 * 연결되지않은 part 을 검색하여 처리 임시 메소드이며 170202 처리 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void connectPartAndPartFamily(Context context,String args[])throws Exception{



		long startTime = System.currentTimeMillis();
		System.out.println("cdmPartMigration : executeCreatePartMigration -StartTime:"+cdmCommonExcel.getTimeStamp());
		String logFileName = "connectPart_PF";
		
	
		if(args.length!=1){
			throw new Exception("The excel path does not exist.");
		}
		String sFileLocationAndFileName = args[0];
		
		String sFileLocation 		= "";
		String sFileName 			= "";
		
		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		
		
		String sPartInputDirectory = sFileLocation;

		// documentDirectory does not ends with "/" add it
		if(sPartInputDirectory != null && !sPartInputDirectory.endsWith(sfileSeparator))
		{
			sPartInputDirectory = sPartInputDirectory + sfileSeparator;
		}
		String sPartOutputDirectory = "";
		// create a directory to add debug and error logs
		sPartOutputDirectory = new File(sPartInputDirectory).getParentFile() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+  sfileSeparator;
        File fileOutputDirectory = new File(sPartOutputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        
        String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		logFileName +="_"+sFileName.substring(0, sFileName.lastIndexOf("."))+"_"+formatTime;
		
        
		logWriter 			 	= new BufferedWriter(new FileWriter(sPartOutputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(sPartOutputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(sPartOutputDirectory + logFileName + "_SuccessLogs.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(sPartOutputDirectory + logFileName + "_FailedLogs" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		shortErrorLogFile        = new File(sPartOutputDirectory + logFileName + "ShortErrorLogs" + ".txt");
		shortErrorWriter         = new BufferedWriter(new FileWriter(shortErrorLogFile,true));
		
		String tempStRowNum   = ""; //순번
		String tempStPartNo   = ""; //엑셀의 PartNo
		String tempStPartRevision   = ""; //엑셀의 PartNo
		int totalCount = 0;
		int successCount = 0;
		int failCount = 0;
		boolean checkTriggerOff = false;
		BufferedReader bufferReader = null;
//		writeSuccessToFile("LineNume(#) \t  PartNo. \t Revision \t error Org Project \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t No OPTION1 exists. \t No OPTION2 exists. \t No OPTION3 exists. \t  No OPTION4 exists. \t No OPTION5 exists \t  No OPTION6 exists \t EC information does not exist. \t No Part Family exist. \t attribute value ");
		writeSuccessToFile("LineNume(#) \t  PartNo. \t Revision \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t No OPTION1 exists. \t No OPTION2 exists. \t No OPTION3 exists. \t  No OPTION4 exists. \t No OPTION5 exists \t  No OPTION6 exists \t EC information does not exist. \t No Part Family exist. \t Project Group \t Org  \t attributes ");
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole(" PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
		writeMessageToConsole("	Reading input log file from : "+sPartInputDirectory+sFileName);
		writeMessageToConsole("	Writing Log files to: " + sPartInputDirectory );
		writeMessageToConsole("====================================================================================\n");
		boolean checkAddPart = false;
		MqlUtil.mqlCommand(context, "history off");
		try {
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(sPartInputDirectory+sFileName),"euc-kr"));
			String data = "";  							// 텍스트 파일 라인정보담을 변수 
			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
			
			/* cdmCommonCode lev2 object 검색 start  */
			
			// 12/2 start 
//			Map option1Map = getOptionCode(context,"Option1");
//			Map option2Map = getOptionCode(context,"Option2");
//			Map option3Map = getOptionCode(context,"Option3");
//			Map option4Map = getOptionCode(context,"Option4");
//			Map option5Map = getOptionCode(context,"Option5");
//			Map option6Map = getOptionCode(context,"Option6");
			
//			Map vehicleCommonCodeMap = getVehicleCode(context,"Vehicle");
//			Map productGroupMap      = getProductGroupCode(context,"Product Group Name");
//			Map productDivMap        = getProductDivCode(context,"Product Div");
//			Map projectMap           = getProjectCode(context,"cdmProjectGroupObject");
			Map partFamilyMap        = getPartFamilyId2(context,"Global R&D:Global R&D");
			
			/*cdmCommonCode lev2 object 검색 end */ 
			
			String strLanguage = context.getLocale().getLanguage();
			
			int lineNumber = 1;      
			int subPartCount = 0;
			
			String strPreviousPartNo = null;
			String strPreviousPartRevision = null;
			String strPreviousPartType = null;
			
			
			while ((data = bufferReader.readLine()) != null) {
				
				StringBuffer sbErrorMessage = new StringBuffer("");
				MqlUtil.mqlCommand(context, "trigger off");
				checkTriggerOff = true;
				checkAddPart = false;
				StringList stListData = FrameworkUtil.split(data, "\t");
				try {
					
					if (lineNumber == 1) {
						stListHeader = stListData;
						writeFailToFile("errorRecord \t"+data);
						lineNumber++;
						continue;
					}
					lineNumber++;
					totalCount++;
					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
					int size_Data = stListData.size();
					int size_Header = stListHeader.size();
					if (size_Data != size_Header) {
						String errorMessage = " NOT MATCH DATA FIELD";
						throw new Exception(errorMessage);
					}

					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {

						String sPartInfos = cdmCommonExcel.isVaildNullData((String)stListData.get(stListNum));
						String sPartHeader = ((String) stListHeader.get(stListNum)).trim();
						partHM.put(sPartHeader, sPartInfos);
						
					}
					
					String stPartType                   = TYPE_CDMMECHANICALPART;  
					String stPartCount                  = ((String)partHM.get("#"            		        )).trim(); // 1 순번 
					String stCLS_NAME                   = ((String)partHM.get("CLS_NAME"                    )).trim(); // 2 
					String stOBJECT_ID                  = ((String)partHM.get("OBJECT_ID"                   )).trim(); // 3 //받은 자료에 unique 값 migration대상아님 
	
					String stCN_ID                      = ((String)partHM.get("CN_ID"  	                    )).trim(); // 5 Name
					String stREVISION                   = ((String)partHM.get("REVISION"                    )).trim(); // 6 Revision
					String stSTATE                      = ((String)partHM.get("STATE"                       )).trim(); // 7 State
					String stCREATION_DATE              = ((String)partHM.get("CREATION_DATE"               )).trim(); // 8  attribute[cdmPartCreationDateM]
					String stUSER_OBJECT_ID             = ((String)partHM.get("USER_OBJECT_ID"              )).trim(); // 9  attribute[cdmPartCreationUserIdM]
					String stUSER_ID_MOD                = ((String)partHM.get("USER_ID_MOD"                 )).trim(); // 10 attribute[cdmPartModUserIdM]
					String stMODIFICATION_DATE          = ((String)partHM.get("MODIFICATION_DATE"           )).trim(); // 11 attribute[cdmPartModificationDateM] 
					String stTDM_DESCRIPTION            = ((String)partHM.get("TDM_DESCRIPTION"             )).trim(); // 12 attribute[cdmPartName]
					String stTDM_UOM                    = ((String)partHM.get("TDM_UOM"  			        )).trim(); // 13 attribute[cdmPartUOM]
					String stPhaseM                     = ((String)partHM.get("PHASE"                       )).trim(); // 14 
					String stPAR_REVISION               = ((String)partHM.get("PAR_REVISION"                )).trim(); // 15 Previous Revision
	//				String stAPPROVAL_DATE              = ((String)partHM.get("APPROVAL_DATE"               )).trim(); // 16 
	//				String stREVISION_STG               = ((String)partHM.get("REVISION_STG"                )).trim(); // 17 
					String stTDM_ORG_USER_ID            = ((String)partHM.get("TDM_ORG_USER_ID"             )).trim(); // 18 First Revision creator
	//				String stTDM_ORG_CREATEDATE         = ((String)partHM.get("TDM_ORG_CREATEDATE"          )).trim(); // 19 
	//				String stTDM_APPROVED_BY            = ((String)partHM.get("TDM_APPROVED_BY"             )).trim(); // 20 
	//				String stTDM_ORIGIN_ID              = ((String)partHM.get("TDM_ORIGIN_ID"               )).trim(); // 21 
					String stCN_PROJECT                 = ((String)partHM.get("CN_PROJECT"                  )).trim(); // 22 PROJECT
					String stCN_PROJECT_CUST            = ((String)partHM.get("CN_PROJECT_CUST"             )).trim(); // 23 PROJECT_CUST
	//				String stCN_PRODUCT_NAME            = ((String)partHM.get("CN_PRODUCT_NAME"             )).trim(); // 24 
	//				String stCN_PART_GROUP              = ((String)partHM.get("CN_PART_GROUP"               )).trim(); // 25 
	//				String stCN_PART_NAME               = ((String)partHM.get("CN_PART_NAME"                )).trim(); // 26
	//				String stCN_WEIGHT                  = ((String)partHM.get("CN_WEIGHT"                   )).trim(); // 27
					String stCN_ESTIMATED_WEIGHT        = ((String)partHM.get("CN_ESTIMATED_WEIGHT"         )).trim(); // 28 attribute[cdmPartEstimatedWeight] 
					String stCN_WEIGHT_UNIT             = ((String)partHM.get("CN_WEIGHT_UNIT"              )).trim(); // 29
					String stCN_TOP_ITEM                = ((String)partHM.get("CN_TOP_ITEM"                 )).trim(); // 30
					String stCN_PHANTOM_ITEM            = ((String)partHM.get("CN_PHANTOM_ITEM"             )).trim(); // 31
					String stCN_ITEM_TYPE               = ((String)partHM.get("CN_ITEM_TYPE"                )).trim(); // 32
					String stCN_SERVICE_ITEM            = ((String)partHM.get("CN_SERVICE_ITEM"             )).trim(); // 33
					String stCN_ITEM_MATERIAL           = ((String)partHM.get("CN_ITEM_MATERIAL"            )).trim(); // 34
					String stCN_ITEM_UPDATE_FROM_ERP    = ((String)partHM.get("CN_ITEM_UPDATE_FROM_ERP"     )).trim(); // 35
					String stCN_COST                    = ((String)partHM.get("CN_COST"                     )).trim(); // 36
					String stCN_CURRENCY                = ((String)partHM.get("CN_CURRENCY"                 )).trim(); // 37
					//String stCN_COMMENTS              = ((String)partHM.get("CN_COMMENTS"                 )).trim(); // 38
					String stCN_OEM_PART_NUMBER         = ((String)partHM.get("CN_OEM_PART_NUMBER"          )).trim(); // 39
					String stEC_NAME                    = ((String)partHM.get("EC_NAME"                     )).trim(); // 40
					String stCN_ECO_NUMBER              = ((String)partHM.get("CN_ECO_NUMBER"               )).trim(); // 41
					String stCN_PRODUCT_GROUP           = ((String)partHM.get("CN_PRODUCT_GROUP"            )).trim(); // 42
					String stCN_SERIES_ITEM             = ((String)partHM.get("CN_SERIES_ITEM"              )).trim(); // 43
					String stCN_VEHICLE                 = ((String)partHM.get("CN_VEHICLE"                  )).trim(); // 44
					String stCN_CUSTOMER                = ((String)partHM.get("CN_CUSTOMER"                 )).trim(); // 45
					String stCN_SIZE                    = ((String)partHM.get("CN_SIZE"                     )).trim(); // 46
					String stCN_SURFACE_TREATMENT       = ((String)partHM.get("CN_SURFACE_TREATMENT"        )).trim(); // 47
					String stCN_SURFACE_AREA            = ((String)partHM.get("CN_SURFACE_AREA"             )).trim(); // 48
					String stCN_ITEM_TYPE1              = ((String)partHM.get("CN_ITEM_TYPE1"               )).trim(); // 49
					String stCN_MATERIAL               = ((String)partHM.get("CN_MATERIAL"                  )).trim(); // 50
					String stCN_ORG1                   = ((String)partHM.get("CN_ORG1"                      )).trim(); // 51  migration 대상 제외  
	//				String stCN_ORG2                   = ((String)partHM.get("CN_ORG2"                      )).trim(); // 52  migration 대상 제외 
	//				String stCN_ORG3                   = ((String)partHM.get("CN_ORG3"                      )).trim(); // 53  migration 대상 제외 
					String stCN_ORG                    = ((String)partHM.get("CN_ORG"                       )).trim(); // 54  MCA Org
					String stCN_MCA_INOUT              = ((String)partHM.get("CN_MCA_INOUT"                 )).trim(); // 55  MCA BOM Management
					String stCN_MCA_PART_TYPE_REF      = ((String)partHM.get("CN_MCA_PART_TYPE_REF"         )).trim(); // 56  MCA Part Type
					String stCN_OPTION1                = ((String)partHM.get("CN_OPTION1"                   )).trim(); // 57
					String stCN_OPTION2                = ((String)partHM.get("CN_OPTION2"                   )).trim(); // 58
					String stCN_OPTION3                = ((String)partHM.get("CN_OPTION3"                   )).trim(); // 59
					String stCN_OPTION4                = ((String)partHM.get("CN_OPTION4"                   )).trim(); // 60
					String stCN_OPTION5                = ((String)partHM.get("CN_OPTION5"                   )).trim(); // 61
					String stCN_OPTION6                = ((String)partHM.get("CN_OPTION6"                   )).trim(); // 62
					String stCN_OPTION7                = ((String)partHM.get("CN_OPTION7"                   )).trim(); // 63
					String stCN_OPTION_ETC             = ((String)partHM.get("CN_OPTION_ETC"                )).trim(); // 64
					String stCN_IS_CASTING             = ((String)partHM.get("CN_IS_CASTING"                )).trim(); // 65
					String stCN_OPTION_DESC            = ((String)partHM.get("CN_OPTION_DESC"               )).trim(); // 66
					String stCN_FOR_MAC                = ((String)partHM.get("CN_FOR_MAC"                   )).trim(); // 67
					String stCN_FOR_MIL                = ((String)partHM.get("CN_FOR_MIL"                   )).trim(); // 68
					String stCN_FOR_MIS                = ((String)partHM.get("CN_FOR_MIS"                   )).trim(); // 69
					String stCN_FOR_MMT                = ((String)partHM.get("CN_FOR_MMT"                   )).trim(); // 70
					String stCN_REAL_WEIGHT            = ((String)partHM.get("CN_REAL_WEIGHT"               )).trim(); // 71
					String stCN_COUNTRY                = ((String)partHM.get("CN_COUNTRY"                   )).trim(); // 72
					String stCN_PRODUCT_DIV            = ((String)partHM.get("CN_PRODUCT_DIV"               )).trim(); // 73
					String stCN_GLOBAL_LOCAL           = ((String)partHM.get("CN_GLOBAL_LOCAL"              )).trim(); // 74
					String stCN_PROJECT_CODE           = ((String)partHM.get("CN_PROJECT_CODE"              )).trim(); // 75
					String stCN_OPTION_DRAWING         = ((String)partHM.get("CN_OPTION_DRAWING"            )).trim(); // 76
					String stCN_FOR_DRAWING_FINISH     = ((String)partHM.get("CN_FOR_DRAWING_FINISH"        )).trim(); // 77
					String stCN_FOR_DRAWING_SIZE       = ((String)partHM.get("CN_FOR_DRAWING_SIZE"          )).trim(); // 78
					String stCN_FOR_DRAWING_REMARK     = ((String)partHM.get("CN_FOR_DRAWING_REMARK"        )).trim(); // 79
					String stCN_ITEM_TYPE2              = ((String)partHM.get("CN_ITEM_TYPE2"               )).trim(); // 80
					String stCN_APPLY_PARTLIST          = ((String)partHM.get("CN_APPLY_PARTLIST"           )).trim(); // 81
//					String stCN_PREVIOUS_PART           = ((String)partHM.get("CN_PREVIOUS_PART"            )).trim(); // 82
					String stCN_COMPLEX_BODY            = ((String)partHM.get("CN_COMPLEX_BODY"             )).trim(); // 83
					String stCN_MAIN_PART_NUMBER        = ((String)partHM.get("CN_MAIN_PART_NUMBER"         )).trim(); // 84
					String stCN_VEHICLE_DESC            = ((String)partHM.get("CN_VEHICLE_DESC"             )).trim(); // 85 VEHICLE 
					String stCN_VEHICLE_CODE            = ((String)partHM.get("CN_VEHICLE_CODE"             )).trim(); // 86
					String stVehicle_Cust               = ((String)partHM.get("VEHICLE_CUST"                )).trim(); // 87
					String stCN_DRAWING_NO              = ((String)partHM.get("CN_DRAWING_NO"               )).trim(); // 88 DRAWING_NO
					String stCN_SUB_ID         		    = ((String)partHM.get("CN_SUB_ID"                   )).trim(); // 89
	//				//String stCN_CHANGE_REASON 	        = ((String)partHM.get("CN_CHANGE_REASON"            )).trim(); // 90 다른 데이타 파일로 진행 예정 
					String stCN_SURFACE_TREATMENT_KEYIN = ((String)partHM.get("CN_SURFACE_TREATMENT_KEYIN"  )).trim(); // 91
					String stCN_OVERSEAS_ORG6           = ((String)partHM.get("CN_OVERSEAS_ORG6"            )).trim(); // 92
					String stCN_OVERSEAS_ORG6_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG6_PART_TYPE"  )).trim(); // 93
					String stCN_OVERSEAS_ORG6_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG6_INOUT"      )).trim(); // 94
//					String stCN_OVERSEAS_ORG7           = ((String)partHM.get("CN_OVERSEAS_ORG7"            )).trim(); // 95
//					String stCN_OVERSEAS_ORG7_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG7_PART_TYPE"  )).trim(); // 96
//					String stCN_OVERSEAS_ORG7_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG7_INOUT"      )).trim(); // 97

					String stCN_Project_Id			    = ((String)partHM.get("CN_PROJECT_ID"  )).trim(); // 98
					String stAccessProductGroup		    = ((String)partHM.get("PROD_GROUP"  )).trim(); // 99
					String stAceesOrg				    = ((String)partHM.get("CN_CUST_VEHICLE"  )).trim(); // 100
					if("-".equals(stAceesOrg)){
						stAceesOrg = "";
					}
					String stCADWeight					= ""; 
					
					String stGLOBAL_LOCAL = "";
//					String stITEM_TYPE2 = "";
					String stFOR_DRAWING_REMARK = "";
					String stOPTION_ETC = "";
					String stOPTION_DESC = "";
					String stPartInvestor =   "";
					String stESTIMATED_WEIGHT = "";
					String stITEM_TYPE1 = "";
					String stITEM_TYPE = "";
					String stSERIES_ITEM = "";
					String stPhase = "";
					
					String stPartCADWeight = ""; /*아직 데이타가 없음 속성 정보 재요청 필요 */
					subPartCount = Integer.parseInt(stPartCount);
					tempStRowNum = stPartCount;
					tempStPartNo = stCN_ID;
					tempStPartRevision = stREVISION;
					String personIdMql = "temp query bus Person '" + stTDM_ORG_USER_ID + "' - select id dump |";
					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
					String stPerson = "";
					boolean boolPerson = false;
					if (stListPersonIdMql.size() > 2) {
						stPerson = (String) stListPersonIdMql.get(3);
						boolPerson = true;
					}
					
					
					/*  **************************************************************************************
					 *   stCLS_NAME 정보가 "Option Item" 이라면 CN_SUB_ID 정보를 CN_ID에 합쳐야한다. 
					 *  ************************************************************************************ */
					if("Option Item".equalsIgnoreCase(stCLS_NAME)){
						if(cdmStringUtil.isNotEmpty(stCN_SUB_ID)){
							stCN_ID +=stCN_SUB_ID;
						}
					}
					
//				
					
					
					
					/* ***************************************************************************************
				     *	데이타 중복확인 
					 * *************************************************************************************** */
//					String duplicationPart = MqlUtil.mqlCommand(context, "temp query bus \""+stPartType+"\" \""+ stCN_ID+"\"  \""+ stREVISION +"\"  dump ");
//					if(cdmStringUtil.isNotEmpty(duplicationPart)){
//						String errorMessage = "ALREADY PART OBJECT ";
//						throw new Exception(errorMessage);
//					}
					
//					ContextUtil.startTransaction(context, true);
					StringList sListPFs = new StringList();
//					
					//Part Family
					if (stCN_ID.length() > 6) {

						String pfCodeName = stCN_ID.substring(0, 5);
						String partFamilys = (String)partFamilyMap.get(pfCodeName);
						partFamilys = (partFamilys == null || "null".equals(partFamilys)) ? "" : partFamilys.trim();
						sListPFs = FrameworkUtil.split(partFamilys, ",");
						if(cdmStringUtil.isEmpty(partFamilys) ){
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
							
						}
					}else{
						sbErrorMessage.append("O").append("\t");
					}
					
					String partObjectId = "";
					BusinessObject busMechanical = new BusinessObject("cdmMechanicalPart",stCN_ID,stREVISION,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
					if(!busMechanical.exists(context)){
						BusinessObject busPhantom = new BusinessObject("cdmPhantomPart",stCN_ID,stREVISION,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						if(!busPhantom.exists(context)){
							throw new Exception("not exist part object ");
						}else{
							
							partObjectId = busPhantom.getObjectId(context);
						}
					}else{
						partObjectId = busMechanical.getObjectId(context);
					}	
					
					DomainObject dPart = new DomainObject(partObjectId);
					String currentRelClassifiedItem = "";
					currentRelClassifiedItem = dPart.getInfo(context, "to[Classified Item].id");
					
					if(UIUtil.isNotNullAndNotEmpty(currentRelClassifiedItem)){
//						System.out.println("bb disconnect");
						DomainRelationship dRel = new DomainRelationship();
						dRel.disconnect(context, currentRelClassifiedItem);
					}
					boolean checkConnect = false;
//					boolean bCheckPartNamePF = false;
					int sListPartFamilyIdsSize = sListPFs.size();
					boolean bExceedOnePF = false;
				
					if(sListPFs.size()>1){
						bExceedOnePF = true;
						
					}
					for (Iterator iterPF = sListPFs.iterator(); iterPF.hasNext();) {

						String sPF = (String) iterPF.next();
						HashMap connectPFHMap = new HashMap();

						if (sListPartFamilyIdsSize > 1) {
							String pfCodeName = stCN_ID.substring(0, 5);
							String checkPartFamilyName = pfCodeName + ":" + stTDM_DESCRIPTION;
							
							sPF = (String) partFamilyMap.get(checkPartFamilyName);
						}

						if (  (UIUtil.isNotNullAndNotEmpty(sPF)  || sListPartFamilyIdsSize == 1)) {
							connectPFHMap.put("sPF", sPF);
							connectPFHMap.put("partObjectId", partObjectId);
							
							String connectResult = JPO.invoke(context, "cdmPartMigration", null, "connectPartFamily", JPO.packArgs(connectPFHMap), String.class);

							if (connectResult.startsWith("false|")) {
								int startIndex = connectResult.indexOf("false|");
								connectResult.substring(startIndex);
								sbErrorMessage.append("O (PartFamily)").append("\t");
								
							} else {
								sbErrorMessage.append("X (PartFamily)").append("\t");
								checkConnect = true;

							}
							break;
						}
					}
						//2개 이상 part family 과 존재하지만  stCN_ID  자른 정보와 part family의 name 값이 일치하지않을경우 하나의 part family만 연결한다.
						if(bExceedOnePF && !checkConnect){
							//
							for (int exceedOnePfCnt = 0 ;exceedOnePfCnt<sListPFs.size();exceedOnePfCnt++ ) {
								
								String sPF = (String) sListPFs.get(0);
								HashMap connectPFHMap = new HashMap();
								
								String pfCodeName = stCN_ID.substring(0, 5);
								if ( UIUtil.isNotNullAndNotEmpty(sPF) &&  sPF.equals(pfCodeName) ) {
									connectPFHMap.put("sPF", sPF);
									connectPFHMap.put("partObjectId", partObjectId);
									
									String connectResult = JPO.invoke(context, "cdmPartMigration", null, "connectPartFamily", JPO.packArgs(connectPFHMap), String.class);
									
									if (connectResult.startsWith("false|")) {
										int startIndex = connectResult.indexOf("false|");
										connectResult.substring(startIndex);
										sbErrorMessage.append("O (PartFamily)").append("\t");
									} else {
										sbErrorMessage.append("X (PartFamily)").append("\t");
										checkConnect = true;
									}
									break;
								}
							}
							//
						}
//					
//					bCommit = true;
//					ContextUtil.commitTransaction(context);	
					

//					if (UIUtil.isNotNullAndNotEmpty(stCREATION_DATE) ) {
//						Date createdate = new Date(stCREATION_DATE);
//						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa", new Locale("en", "US"));
//						String tempCreatedDate = "";
//						tempCreatedDate = sdf.format(createdate);
//						//12/6/2016 10:40:16 AM
//						MqlUtil.mqlCommand(context, "mod bus $1 originated $2", partObjectId, tempCreatedDate);
//					}

					
//					try {
//						MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", partObjectId, stAccessProductGroup, stAceesOrg);
//						sbErrorMessage.append("X").append("\t").append("X").append("\t");
//					} catch (Exception e) {
//						sbErrorMessage.append(stAccessProductGroup).append("\t").append(stAceesOrg).append("\t");
//					}
					
					
//					if(bCommit){
//						try{
//						partObj.setAttributeValues(context, attributes);
//						sbErrorMessage.append("X").append("\t");
//						}catch(Exception e4){
//							sbErrorMessage.append("O").append("\t");
//						}
//					}
					
					MqlUtil.mqlCommand(context, "trigger on");
					checkTriggerOff = false;	
						
					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
//						writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());
						if(checkConnect){
							writeSuccessToFile(cdmCommonExcel.getTimeStamp() +"\t"+ subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+sbErrorMessage.toString());	
							
						}else{
							writeMessageToConsole(cdmCommonExcel.getTimeStamp() +"\t"+ subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+sbErrorMessage.toString());
						}
					
//							writeSuccessToFile("LineNum(#): "+subPartCount +" \t PartNo: \t "+tempStPartNo+" \t ");
//						writeSuccessToFile(cdmCommonExcel.getTimeStamp()+"\t"+subPartCount +"\t"+tempStPartNo+"\t"+stREVISION);
							
					}
					if(!checkConnect){
						failCount++;
					}else{
						successCount++;
					}
				} catch (Exception e) {
//					ContextUtil.abortTransaction(context);

//					if(!checkAddPart){
//						MQLCommand mqlCommand = new MQLCommand();
//						mqlCommand.open(context);
//						mqlCommand.executeCommand(context, "abort transaction $1","PartFamily");
//					}
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "trigger on");
						checkTriggerOff = false;			
					}
					failCount++;
					writeErrorToFile("LineNum(#) \t"+tempStRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t "+ tempStPartNo+"\t"+tempStPartRevision +"\t"+e.getMessage().replaceAll("\r|\n", "")); 
					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t" +  data ) ;
					e.printStackTrace(errorStream);
					
					writeShotErrorToFile("LineNum(#) \t"+tempStRowNum + " \t"+cdmCommonExcel.getTimeStamp2()+"\t "+tempStPartNo+"\t"+tempStPartRevision +"\t"+e.toString().replaceAll("\r|\n", ""));
				}finally{
					
				}
				
			} // end of while 
			
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================");
			//
		} catch (Exception e1) {
			writeFailToFile(" LineNum(#):"+tempStRowNum);
			writeErrorToFile("LineNum(#):"+tempStRowNum + "  "+e1.getMessage());
			e1.printStackTrace(errorStream);
			
			
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("	CREATE PART OBJECT CLOSE TIME:  "+cdmCommonExcel.getTimeStamp2()+"          "  );
			writeMessageToConsole("	CREATE PART OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+") TOTALCOUNT :("+totalCount+")"  );
			writeMessageToConsole("==================================================================================== \n");
			MqlUtil.mqlCommand(context, "history on");
			if(checkTriggerOff){
				MqlUtil.mqlCommand(context, "trigger on");
			}
			try {
				if (null != errorStream )
					errorStream .close();

				if (null != logWriter)
					logWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if(null != bufferReader)
					bufferReader.close();
				
				if(null != errorLogFile)
					errorLogFile.close();
				
				if(null != debugLogFile)
					debugLogFile.close();

				if(null != errorLogFile)
					errorLogFile.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			
			long endTime = System.currentTimeMillis();
			long leadTime = (endTime-startTime)/1000/60;
			System.out.println("cdmPartMigration : modifyPartCreate End.   endTime:"+cdmCommonExcel.getTimeStamp()  + "leadTime :"+leadTime);
			
		}
	}
	
	
	/**
	 * part 생성시 오류난 케이스 다시 돌리기 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void reCreatedPart(Context context,String args[])throws Exception{



		long startTime = System.currentTimeMillis();
		System.out.println("cdmPartMigration : reCreatedPart -StartTime:"+cdmCommonExcel.getTimeStamp());
		String logFileName = "reCreatePartM";
		
	
//		if(args.length!=1){
//			throw new Exception("The excel path does not exist.");
//		}
//		String sFileLocationAndFileName = args[0];
		
		String sFileLocation 		= "";
		String sFileName 			= "";
		
		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
		String sFileLocationAndFileName = (String)paramMap.get("fileData");
		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
//		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
//		sFileLocation = (String)paramMap.get("File_Location");
//		sFileName = (String)paramMap.get("File");
		
		String sPartInputDirectory = sFileLocation;

		// documentDirectory does not ends with "/" add it
		if(sPartInputDirectory != null && !sPartInputDirectory.endsWith(sfileSeparator))
		{
			sPartInputDirectory = sPartInputDirectory + sfileSeparator;
		}
		String sPartOutputDirectory = "";
		// create a directory to add debug and error logs
		sPartOutputDirectory = new File(sPartInputDirectory).getParentFile() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+  sfileSeparator;
        File fileOutputDirectory = new File(sPartOutputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        
        String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		logFileName +="_"+sFileName.substring(0, sFileName.lastIndexOf("."))+"_"+formatTime;
		
        
		logWriter 			 	= new BufferedWriter(new FileWriter(sPartOutputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(sPartOutputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(sPartOutputDirectory + logFileName + "_SuccessLogs.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(sPartOutputDirectory + logFileName + "_FailedLogs" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		shortErrorLogFile        = new File(sPartOutputDirectory + logFileName + "ShortErrorLogs" + ".txt");
		shortErrorWriter         = new BufferedWriter(new FileWriter(shortErrorLogFile,true));
		
		String tempStRowNum   = ""; //순번
		String tempStPartNo   = ""; //엑셀의 PartNo
		String tempStPartRevision   = ""; //엑셀의 PartNo
		int totalCount = 0;
		int successCount = 0;
		int failCount = 0;
		boolean checkTriggerOff = false;
		BufferedReader bufferReader = null;
//		writeSuccessToFile("LineNume(#) \t  PartNo. \t Revision \t error Org Project \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t No OPTION1 exists. \t No OPTION2 exists. \t No OPTION3 exists. \t  No OPTION4 exists. \t No OPTION5 exists \t  No OPTION6 exists \t EC information does not exist. \t No Part Family exist. \t attribute value ");
		writeSuccessToFile("CreateTime \t LineNume(#) \t  PartNo. \t Revision \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t  OPTION1 Wrong. \t OPTION2 Wrong. \t  OPTION3 Wrong. \t   OPTION4 Wrong. \t  OPTION5 Wrong. \t   OPTION6 Wrong. \t EC information does not exist. \t No Part Family exist. \t Part Connect \t Project Group \t Org  \t attributes ");
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole(" RE Create PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
		writeMessageToConsole("	Reading input log file from : "+sPartInputDirectory+sFileName);
		writeMessageToConsole("	Writing Log files to: " + sPartInputDirectory );
		writeMessageToConsole("====================================================================================\n");
		boolean checkAddPart = false;
		MqlUtil.mqlCommand(context, "history off");
		try {
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(sPartInputDirectory+sFileName),"euc-kr"));
			String data = "";  							// 텍스트 파일 라인정보담을 변수 
			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
			
			/* cdmCommonCode lev2 object 검색 start  */
			
			// 12/2 start 
			Map option1Map = getOptionCode(context,"Option1");
			Map option2Map = getOptionCode(context,"Option2");
			Map option3Map = getOptionCode(context,"Option3");
			Map option4Map = getOptionCode(context,"Option4");
			Map option5Map = getOptionCode(context,"Option5");
			Map option6Map = getOptionCode(context,"Option6");
			
			Map vehicleCommonCodeMap = getVehicleCode(context,"Vehicle");
			Map productGroupMap      = getProductGroupCode(context,"Product Group Name");
			Map productDivMap        = getProductDivCode(context,"Product Div");
			Map projectMap           = getProjectCode(context,"cdmProjectGroupObject");
//			Map partFamilyMap        = getPartFamilyId(context);
			Map partFamilyMap        = getPartFamilyId2(context,"Global R&D:Global R&D"); //top part family[cdmPartFamilyBlockCodeName]
			
			/*cdmCommonCode lev2 object 검색 end */ 
			
			String strLanguage = context.getLocale().getLanguage();
			
			AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
			attrPartGlobal.open(context);
			StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
			attrPartGlobal.close(context);
			StringList attrPartGlobalKOList = new StringList();
			attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
			
			
			AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
			attrPartItemType.open(context);
			StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
			attrPartItemType.close(context);
			StringList attrPartItemTypeKOList = new StringList();
			attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
			
			
			AttributeType attrPartERPInterface = new AttributeType("cdmPartERPInterface");
			attrPartERPInterface.open(context);
			StringList attrPartERPInterfaceList = attrPartERPInterface.getChoices(context);
			attrPartERPInterface.close(context);
			StringList attrPartERPInterfaceKOList = new StringList();
			attrPartERPInterfaceKOList = i18nNow.getAttrRangeI18NStringList("cdmPartERPInterface", attrPartERPInterfaceList, strLanguage);
			
			AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
			attrPartType.open(context);
			StringList attrPartTypeList = attrPartType.getChoices(context);
			attrPartType.close(context);
			StringList attrPartTypeKOList = new StringList();
			attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
			
			HashMap tempUOMHMap = new HashMap();
			tempUOMHMap.put("EA"  , "Each");
			tempUOMHMap.put("BAG" , "bag");
			tempUOMHMap.put("BTL" , "bottle");
			tempUOMHMap.put("BOX" , "box");
			tempUOMHMap.put("CC"  , "cc");
			tempUOMHMap.put("CMM" , "mm³");
			tempUOMHMap.put("CMT" , "m³");
			tempUOMHMap.put("CN"  , "can");
			tempUOMHMap.put("CT"  , "carton");
			tempUOMHMap.put("DL"  , "dl");
			tempUOMHMap.put("DZ"  , "dozen");
			tempUOMHMap.put("FT"  , "ft");
			tempUOMHMap.put("GLL" , "gallon");
			tempUOMHMap.put("G"   , "g");
			tempUOMHMap.put("IN"  , "inch");
			tempUOMHMap.put("KG"  , "kg");
			tempUOMHMap.put("KMT" , "km");
			tempUOMHMap.put("L"   , "L");
			tempUOMHMap.put("LBR" , "lb");
			tempUOMHMap.put("M"   , "m");
			tempUOMHMap.put("MGR" , "mg");
			tempUOMHMap.put("ML"  , "ml");
			tempUOMHMap.put("MMT" , "mm");
			tempUOMHMap.put("MT"  , "ton");
			tempUOMHMap.put("N"   , "N");
			tempUOMHMap.put("PC"  , "Piece");
			tempUOMHMap.put("PL"  , "Pl");
			tempUOMHMap.put("ROL" , "Roll");
			tempUOMHMap.put("SET" , "Set");
			tempUOMHMap.put("SH"  , "Sheet");
			tempUOMHMap.put("SM"  , "m²");
			tempUOMHMap.put("UN"  , "unit");
			tempUOMHMap.put("DRM" , "drum");
			
			int lineNumber = 1;      
			int subPartCount = 0;
			
			String strPreviousPartNo = null;
			String strPreviousPartRevision = null;
			String strPreviousPartType = null;
			
			
			while ((data = bufferReader.readLine()) != null) {
				
				StringBuffer sbErrorMessage = new StringBuffer("");
				MqlUtil.mqlCommand(context, "trigger off");
				checkTriggerOff = true;
				checkAddPart = false;
				StringList stListData = FrameworkUtil.split(data, "\t");
				try {
					
					if (lineNumber == 1) {
						stListHeader = stListData;
						writeFailToFile("errorRecord \t"+data);
						lineNumber++;
						continue;
					}
					lineNumber++;
					totalCount++;
					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
					int size_Data = stListData.size();
					int size_Header = stListHeader.size();
					if (size_Data != size_Header) {
						String errorMessage = " NOT MATCH DATA FIELD";
						throw new Exception(errorMessage);
					}

					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {

						String sPartInfos = cdmCommonExcel.isVaildNullData((String)stListData.get(stListNum));
						String sPartHeader = ((String) stListHeader.get(stListNum)).trim();
						partHM.put(sPartHeader, sPartInfos);
						
					}
					
					String stPartType                   = TYPE_CDMMECHANICALPART;  
					String stPartCount                  = ((String)partHM.get("#"            		        )).trim(); // 1 순번 
					String stCLS_NAME                   = ((String)partHM.get("CLS_NAME"                    )).trim(); // 2 
					String stOBJECT_ID                  = ((String)partHM.get("OBJECT_ID"                   )).trim(); // 3 //받은 자료에 unique 값 migration대상아님 
	
					String stCN_ID                      = ((String)partHM.get("CN_ID"  	                    )).trim(); // 5 Name
					String stREVISION                   = ((String)partHM.get("REVISION"                    )).trim(); // 6 Revision
					String stSTATE                      = ((String)partHM.get("STATE"                       )).trim(); // 7 State
					String stCREATION_DATE              = ((String)partHM.get("CREATION_DATE"               )).trim(); // 8  attribute[cdmPartCreationDateM]
					String stUSER_OBJECT_ID             = ((String)partHM.get("USER_OBJECT_ID"              )).trim(); // 9  attribute[cdmPartCreationUserIdM]
					String stUSER_ID_MOD                = ((String)partHM.get("USER_ID_MOD"                 )).trim(); // 10 attribute[cdmPartModUserIdM]
					String stMODIFICATION_DATE          = ((String)partHM.get("MODIFICATION_DATE"           )).trim(); // 11 attribute[cdmPartModificationDateM] 
					String stTDM_DESCRIPTION            = ((String)partHM.get("TDM_DESCRIPTION"             )).trim(); // 12 attribute[cdmPartName]
					String stTDM_UOM                    = ((String)partHM.get("TDM_UOM"  			        )).trim(); // 13 attribute[cdmPartUOM]
					String stPhaseM                     = ((String)partHM.get("PHASE"                       )).trim(); // 14 
					String stPAR_REVISION               = ((String)partHM.get("PAR_REVISION"                )).trim(); // 15 Previous Revision
	//				String stAPPROVAL_DATE              = ((String)partHM.get("APPROVAL_DATE"               )).trim(); // 16 
	//				String stREVISION_STG               = ((String)partHM.get("REVISION_STG"                )).trim(); // 17 
					String stTDM_ORG_USER_ID            = ((String)partHM.get("TDM_ORG_USER_ID"             )).trim(); // 18 First Revision creator
	//				String stTDM_ORG_CREATEDATE         = ((String)partHM.get("TDM_ORG_CREATEDATE"          )).trim(); // 19 
	//				String stTDM_APPROVED_BY            = ((String)partHM.get("TDM_APPROVED_BY"             )).trim(); // 20 
	//				String stTDM_ORIGIN_ID              = ((String)partHM.get("TDM_ORIGIN_ID"               )).trim(); // 21 
					String stCN_PROJECT                 = ((String)partHM.get("CN_PROJECT"                  )).trim(); // 22 PROJECT
					String stCN_PROJECT_CUST            = ((String)partHM.get("CN_PROJECT_CUST"             )).trim(); // 23 PROJECT_CUST
	//				String stCN_PRODUCT_NAME            = ((String)partHM.get("CN_PRODUCT_NAME"             )).trim(); // 24 
	//				String stCN_PART_GROUP              = ((String)partHM.get("CN_PART_GROUP"               )).trim(); // 25 
	//				String stCN_PART_NAME               = ((String)partHM.get("CN_PART_NAME"                )).trim(); // 26
	//				String stCN_WEIGHT                  = ((String)partHM.get("CN_WEIGHT"                   )).trim(); // 27
					String stCN_ESTIMATED_WEIGHT        = ((String)partHM.get("CN_ESTIMATED_WEIGHT"         )).trim(); // 28 attribute[cdmPartEstimatedWeight] 
					String stCN_WEIGHT_UNIT             = ((String)partHM.get("CN_WEIGHT_UNIT"              )).trim(); // 29
					String stCN_TOP_ITEM                = ((String)partHM.get("CN_TOP_ITEM"                 )).trim(); // 30
					String stCN_PHANTOM_ITEM            = ((String)partHM.get("CN_PHANTOM_ITEM"             )).trim(); // 31
					String stCN_ITEM_TYPE               = ((String)partHM.get("CN_ITEM_TYPE"                )).trim(); // 32
					String stCN_SERVICE_ITEM            = ((String)partHM.get("CN_SERVICE_ITEM"             )).trim(); // 33
					String stCN_ITEM_MATERIAL           = ((String)partHM.get("CN_ITEM_MATERIAL"            )).trim(); // 34
					String stCN_ITEM_UPDATE_FROM_ERP    = ((String)partHM.get("CN_ITEM_UPDATE_FROM_ERP"     )).trim(); // 35
					String stCN_COST                    = ((String)partHM.get("CN_COST"                     )).trim(); // 36
					String stCN_CURRENCY                = ((String)partHM.get("CN_CURRENCY"                 )).trim(); // 37
					//String stCN_COMMENTS              = ((String)partHM.get("CN_COMMENTS"                 )).trim(); // 38
					String stCN_OEM_PART_NUMBER         = ((String)partHM.get("CN_OEM_PART_NUMBER"          )).trim(); // 39
					String stEC_NAME                    = ((String)partHM.get("EC_NAME"                     )).trim(); // 40
					String stCN_ECO_NUMBER              = ((String)partHM.get("CN_ECO_NUMBER"               )).trim(); // 41
					String stCN_PRODUCT_GROUP           = ((String)partHM.get("CN_PRODUCT_GROUP"            )).trim(); // 42
					String stCN_SERIES_ITEM             = ((String)partHM.get("CN_SERIES_ITEM"              )).trim(); // 43
					String stCN_VEHICLE                 = ((String)partHM.get("CN_VEHICLE"                  )).trim(); // 44
					String stCN_CUSTOMER                = ((String)partHM.get("CN_CUSTOMER"                 )).trim(); // 45
					String stCN_SIZE                    = ((String)partHM.get("CN_SIZE"                     )).trim(); // 46
					String stCN_SURFACE_TREATMENT       = ((String)partHM.get("CN_SURFACE_TREATMENT"        )).trim(); // 47
					String stCN_SURFACE_AREA            = ((String)partHM.get("CN_SURFACE_AREA"             )).trim(); // 48
					String stCN_ITEM_TYPE1              = ((String)partHM.get("CN_ITEM_TYPE1"               )).trim(); // 49
					String stCN_MATERIAL               = ((String)partHM.get("CN_MATERIAL"                  )).trim(); // 50
					String stCN_ORG1                   = ((String)partHM.get("CN_ORG1"                      )).trim(); // 51  migration 대상 제외  
	//				String stCN_ORG2                   = ((String)partHM.get("CN_ORG2"                      )).trim(); // 52  migration 대상 제외 
	//				String stCN_ORG3                   = ((String)partHM.get("CN_ORG3"                      )).trim(); // 53  migration 대상 제외 
					String stCN_ORG                    = ((String)partHM.get("CN_ORG"                       )).trim(); // 54  MCA Org
					String stCN_MCA_INOUT              = ((String)partHM.get("CN_MCA_INOUT"                 )).trim(); // 55  MCA BOM Management
					String stCN_MCA_PART_TYPE_REF      = ((String)partHM.get("CN_MCA_PART_TYPE_REF"         )).trim(); // 56  MCA Part Type
					String stCN_OPTION1                = ((String)partHM.get("CN_OPTION1"                   )).trim(); // 57
					String stCN_OPTION2                = ((String)partHM.get("CN_OPTION2"                   )).trim(); // 58
					String stCN_OPTION3                = ((String)partHM.get("CN_OPTION3"                   )).trim(); // 59
					String stCN_OPTION4                = ((String)partHM.get("CN_OPTION4"                   )).trim(); // 60
					String stCN_OPTION5                = ((String)partHM.get("CN_OPTION5"                   )).trim(); // 61
					String stCN_OPTION6                = ((String)partHM.get("CN_OPTION6"                   )).trim(); // 62
					String stCN_OPTION7                = ((String)partHM.get("CN_OPTION7"                   )).trim(); // 63
					String stCN_OPTION_ETC             = ((String)partHM.get("CN_OPTION_ETC"                )).trim(); // 64
					String stCN_IS_CASTING             = ((String)partHM.get("CN_IS_CASTING"                )).trim(); // 65
					String stCN_OPTION_DESC            = ((String)partHM.get("CN_OPTION_DESC"               )).trim(); // 66
					String stCN_FOR_MAC                = ((String)partHM.get("CN_FOR_MAC"                   )).trim(); // 67
					String stCN_FOR_MIL                = ((String)partHM.get("CN_FOR_MIL"                   )).trim(); // 68
					String stCN_FOR_MIS                = ((String)partHM.get("CN_FOR_MIS"                   )).trim(); // 69
					String stCN_FOR_MMT                = ((String)partHM.get("CN_FOR_MMT"                   )).trim(); // 70
					String stCN_REAL_WEIGHT            = ((String)partHM.get("CN_REAL_WEIGHT"               )).trim(); // 71
					String stCN_COUNTRY                = ((String)partHM.get("CN_COUNTRY"                   )).trim(); // 72
					String stCN_PRODUCT_DIV            = ((String)partHM.get("CN_PRODUCT_DIV"               )).trim(); // 73
					String stCN_GLOBAL_LOCAL           = ((String)partHM.get("CN_GLOBAL_LOCAL"              )).trim(); // 74
					String stCN_PROJECT_CODE           = ((String)partHM.get("CN_PROJECT_CODE"              )).trim(); // 75
					String stCN_OPTION_DRAWING         = ((String)partHM.get("CN_OPTION_DRAWING"            )).trim(); // 76
					String stCN_FOR_DRAWING_FINISH     = ((String)partHM.get("CN_FOR_DRAWING_FINISH"        )).trim(); // 77
					String stCN_FOR_DRAWING_SIZE       = ((String)partHM.get("CN_FOR_DRAWING_SIZE"          )).trim(); // 78
					String stCN_FOR_DRAWING_REMARK     = ((String)partHM.get("CN_FOR_DRAWING_REMARK"        )).trim(); // 79
					String stCN_ITEM_TYPE2              = ((String)partHM.get("CN_ITEM_TYPE2"               )).trim(); // 80
					String stCN_APPLY_PARTLIST          = ((String)partHM.get("CN_APPLY_PARTLIST"           )).trim(); // 81
//					String stCN_PREVIOUS_PART           = ((String)partHM.get("CN_PREVIOUS_PART"            )).trim(); // 82
					String stCN_COMPLEX_BODY            = ((String)partHM.get("CN_COMPLEX_BODY"             )).trim(); // 83
					String stCN_MAIN_PART_NUMBER        = ((String)partHM.get("CN_MAIN_PART_NUMBER"         )).trim(); // 84
					String stCN_VEHICLE_DESC            = ((String)partHM.get("CN_VEHICLE_DESC"             )).trim(); // 85 VEHICLE 
					String stCN_VEHICLE_CODE            = ((String)partHM.get("CN_VEHICLE_CODE"             )).trim(); // 86
					String stVehicle_Cust               = ((String)partHM.get("VEHICLE_CUST"                )).trim(); // 87
					String stCN_DRAWING_NO              = ((String)partHM.get("CN_DRAWING_NO"               )).trim(); // 88 DRAWING_NO
					String stCN_SUB_ID         		    = ((String)partHM.get("CN_SUB_ID"                   )).trim(); // 89
	//				//String stCN_CHANGE_REASON 	        = ((String)partHM.get("CN_CHANGE_REASON"            )).trim(); // 90 다른 데이타 파일로 진행 예정 
					String stCN_SURFACE_TREATMENT_KEYIN = ((String)partHM.get("CN_SURFACE_TREATMENT_KEYIN"  )).trim(); // 91
					String stCN_OVERSEAS_ORG6           = ((String)partHM.get("CN_OVERSEAS_ORG6"            )).trim(); // 92
					String stCN_OVERSEAS_ORG6_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG6_PART_TYPE"  )).trim(); // 93
					String stCN_OVERSEAS_ORG6_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG6_INOUT"      )).trim(); // 94
//					String stCN_OVERSEAS_ORG7           = ((String)partHM.get("CN_OVERSEAS_ORG7"            )).trim(); // 95
//					String stCN_OVERSEAS_ORG7_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG7_PART_TYPE"  )).trim(); // 96
//					String stCN_OVERSEAS_ORG7_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG7_INOUT"      )).trim(); // 97

					String stCN_Project_Id			    = ((String)partHM.get("CN_PROJECT_ID"  )).trim(); // 98
					String stAccessProductGroup		    = ((String)partHM.get("PROD_GROUP"  )).trim(); // 99
					String stAceesOrg				    = ((String)partHM.get("CN_CUST_VEHICLE"  )).trim(); // 100
					if("-".equals(stAceesOrg)){
						stAceesOrg = "";
					}
					String stCADWeight					= ""; 
					
					String stGLOBAL_LOCAL = "";
//					String stITEM_TYPE2 = "";
					String stFOR_DRAWING_REMARK = "";
					String stOPTION_ETC = stCN_OPTION_ETC;
					String stOPTION_DESC = stCN_OPTION_DESC;
					String stPartInvestor =   "";
					String stESTIMATED_WEIGHT = "";
					String stITEM_TYPE1 = "";
					String stITEM_TYPE = "";
					String stSERIES_ITEM = "";
					String stPhase = "";
					
					String stPartCADWeight = ""; /*아직 데이타가 없음 속성 정보 재요청 필요 */
					subPartCount = Integer.parseInt(stPartCount);
					tempStRowNum = stPartCount;
					tempStPartNo = stCN_ID;
					tempStPartRevision = stREVISION;
					String personIdMql = "temp query bus Person '" + stTDM_ORG_USER_ID + "' - select id dump |";
					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
					String stPerson = "";
					boolean boolPerson = false;
					if (stListPersonIdMql.size() > 2) {
						stPerson = (String) stListPersonIdMql.get(3);
						boolPerson = true;
					}
					
					
					/*  **************************************************************************************
					 *   stCLS_NAME 정보가 "Option Item" 이라면 CN_SUB_ID 정보를 CN_ID에 합쳐야한다. 
					 *  ************************************************************************************ */
					if("Option Item".equalsIgnoreCase(stCLS_NAME)){
						if(cdmStringUtil.isNotEmpty(stCN_SUB_ID)){
							stCN_ID +=stCN_SUB_ID;
						}
					}
					
					/* **************************************************************************************
					 * cdmPartGlobal 의 정보는 global,local 값이 없으면 ""  처리 
					 * ************************************************************************************* */
					for (int i = 0; i < attrPartGlobalKOList.size(); i++) {
	
						if (stCN_GLOBAL_LOCAL.equalsIgnoreCase((String) attrPartGlobalKOList.get(i))) {
							stGLOBAL_LOCAL = (String) attrPartGlobalList.get(i);
							break;
						}
					}
					if(cdmStringUtil.isEmpty(stGLOBAL_LOCAL)){
						stGLOBAL_LOCAL = "";
					}
					
					/*  **************************************************************************************
					 *   stCN_ITEM_TYPE2 의 정보는 
					 *   attribute[cdmPartItemType]관련 정보
					 *   
					 *   attribute[cdmPartItemType]의 display name과 일치하지않다면 에러 처리  
					 *  ************************************************************************************** */
//					boolean bITEM_TYPE2 = false;
//					for (int i = 0; i < attrPartItemTypeKOList.size(); i++) {
//	
//						if (stCN_ITEM_TYPE2.equals((String) attrPartItemTypeKOList.get(i))) {
//							stITEM_TYPE2 = (String) attrPartItemTypeList.get(i);
//							bITEM_TYPE2 = true;
//							break;
//						}
//						
//					}
					
					/* *****************************************************************************************
					 * stCN_FOR_DRAWING_REMARK 의 정보는 Part 의 한글 속성과 일치 
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					if(cdmStringUtil.isNotEmpty(stCN_FOR_DRAWING_REMARK) ){
						for (int i = 0; i < attrPartERPInterfaceKOList.size(); i++) {
	
							if (stCN_FOR_DRAWING_REMARK.equals((String) attrPartERPInterfaceKOList.get(i))) {
								stFOR_DRAWING_REMARK = (String) attrPartERPInterfaceList.get(i);
								break;
							}
						}
					}
					
					
					/* *****************************************************************************************
					 * CDM 의 UOM 과 전달받은 UOM 은 정보는 달라 기준정보 (MAP )로 찾아 데이타를 입력한다.
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					String sTempUOM = "";
					sTempUOM= (String)tempUOMHMap.get(stTDM_UOM);
					sTempUOM = cdmCommonExcel.isVaildNullData(sTempUOM);
					
					
					/* ******************************************************************************************************************
					 * stPartInvestor 의경우 
					 * stCN_FOR_MAC ,stCN_FOR_MIL,stCN_FOR_MMT 의 정보가 checked 되어 있는지여부를 확인하여 하나의 String 값으로 만듬 
					 * ****************************************************************************************************************   */
					if("Checked".equals(stCN_FOR_MAC)){
						stPartInvestor = "MAC";
					}
					if("Checked".equals(stCN_FOR_MIL)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MIL";
					}
					if("Checked".equals(stCN_FOR_MMT)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MMT";
					}
	
					
					/* ******************************************************************************************************************
					 *  attribute[cdmPartEstimateWeightUnit] 중량 단위 
					 *  넘어오는 데이타의 데이타가 없으면  attribute[cdmPartEstimateWeightUnit] 속성값은 G 로 입력된다 .
					 *  (넘어오는 데이타가 default 중량단위는 G )
					 * ****************************************************************************************************************** */
					String sTempWeightUnit = "";
					if("".equals(stCN_WEIGHT_UNIT)){
						sTempWeightUnit = "G";
					}else {
						//중량단위를 kg로 변환 !!
						if("g".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "G";
						}else if("lb".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "LBR";
						}else if("mg".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "MGR";
						}else if("ton".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "MT";
						}else if("N".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "N";
						}else if("kg".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "KG";
						}
						
					}
						
					
					/* *************************************************************************************
					 *   stCN_ORG1 가 PROTO 이면 stPhase 값은 proto 
					 *   stCN_PHANTOM_ITEM 가 체크되어있으면 파트 타입으로 "Phantom Part"변경
					 *   stPhase 여부와 상관없이 반드시 Proto 로 변경된다. 
					 * *********************************************************************************** */
					if("PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPhase = S_ATTRIBUTE_PHASE_PROTO;
					}else{
						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
					}
					
					if( "Checked".equalsIgnoreCase(stCN_PHANTOM_ITEM) &&  "PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPartType = "cdmPhantomPart";
						stPhase = S_ATTRIBUTE_PHASE_PROTO; //변경요청
					}
					
					
					
					  /* **********************************************************************************************************************
			         * type은 pre revision 정보가 있으며 그정보 의 object 가 phantom part 타입이면 생성할 object 타입도 phantom part 타입으로
			         * 변경  
			         *    
			         * ******************************************************************************************************************** */
//					if(cdmStringUtil.isNotEmpty(stPAR_REVISION)) {
//						 String stPreRevisionPhantomMql = "temp query bus '"+ TYPE_PHANTOMPART +"' '" +stCN_ID +"' '"+stPAR_REVISION+"'  select id  dump |";
//						 String stPreRevisionPhantomMqlResult =  MqlUtil.mqlCommand(context, stPreRevisionPhantomMql);
//						 StringList stListPreRevisionPhantomMqlResult = FrameworkUtil.split(stPreRevisionPhantomMqlResult, "|");
//						 
//						 if(stListPreRevisionPhantomMqlResult.size() > 2){
//							 stPartType = TYPE_PHANTOMPART;
//						 }
//					}
					
					
					
					/* ***************************************************************************************
				     *	데이타 중복확인 
					 * *************************************************************************************** */
					String duplicationPart = MqlUtil.mqlCommand(context, "temp query bus \""+stPartType+"\" \""+ stCN_ID+"\"  \""+ stREVISION +"\"  dump ");
					if(cdmStringUtil.isNotEmpty(duplicationPart)){
						String errorMessage = "ALREADY PART OBJECT ";
						throw new Exception(errorMessage);
					}
					
					/* *************************************************************************************
					 * stITEM_TYPE1 은  cdmPartApprovalType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					
					
					if("자작".equals(stCN_ITEM_TYPE1)){
						stITEM_TYPE1 = "inSourcing";
					}else if("외주".equals(stCN_ITEM_TYPE1)){
						stITEM_TYPE1 = "outSourcing";
					}else{
						stITEM_TYPE1 = "";
					}
					
					
					
					/* *************************************************************************************
					 * stITEM_TYPE 은  cdmPartType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					stITEM_TYPE = "";
//					for (int attrPartTypeNum = 0; attrPartTypeNum < attrPartTypeKOList.size(); attrPartTypeNum++) {
//						String temPattrPartTypeKO = (String) attrPartTypeKOList.get(attrPartTypeNum);
//						if (stCN_ITEM_TYPE.equals(temPattrPartTypeKO)) {
//							stITEM_TYPE = (String) attrPartTypeList.get(attrPartTypeNum);
//							break;
//						}
//					}
					
					//
					if("단품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "singleSupply";
					}else if("완제품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "completeProduct";
					}else if("반제품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "halfFinishedProduct";
					}else if("원부자재".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "rawMaterial";
					}
					//
//					if(stCN_ITEM_TYPE == null || "".equals(stCN_ITEM_TYPE) ){
//						stITEM_TYPE = "";
//					} else {
	
//						AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
//						attrPartType.open(context);
//						StringList attrPartTypeList = attrPartType.getChoices(context);
//	
//						StringList attrPartTypeKOList = new StringList();
//						attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
	
						
//					}
	
					
					/* *************************************************************************************
					 * SERIES_ITEM 값이 Checked 이면 true unChecked 이면 false 
					 * *********************************************************************************** */
					if("Checked".equalsIgnoreCase(stCN_SERIES_ITEM)){
						stSERIES_ITEM = "true"; 
					}else{
						stSERIES_ITEM = "false";
					}
					
					/*stCN_SURFACE_TREATMENT 은 사용되지않아 "" 처리한다. */
					String stSURFACE_TREATMENT = ""; 
					
					/*stCN_IS_CASTING*/
					String stIS_CASTING = "";
					if(!"0".equals(stCN_IS_CASTING)){
						stIS_CASTING = "yes";
					}else{
						stIS_CASTING = "no";
					}
					
					
					/*stCN_FOR_DRAWING_FINISH*/
					String stCFOR_DRAWING_FINISH = "";
					if("0".equals(stCN_FOR_DRAWING_FINISH)){
						stCFOR_DRAWING_FINISH = "unChecked";
					}else{
						stCFOR_DRAWING_FINISH = "Checked";
					}
					
					/*stCN_FOR_DRAWING_SIZE*/
					String stDRAWING_SIZE = "";
					if("0".equals(stCN_FOR_DRAWING_SIZE)){
						stDRAWING_SIZE = "unChecked";
					}else{
						stDRAWING_SIZE = "Checked";
					}
					
					HashMap attributes = new HashMap();
					if(UIUtil.isNotNullAndNotEmpty(stPhaseM)){
						attributes.put("cdmPartPhaseM", 		 	  stPhaseM		                   );
					}
			        attributes.put("cdmPartNo",          	      stCN_ID 			               );
//			        attributes.put("cdmPartVehicle", 	 	      stCN_VEHICLE_DESC		           );
			        attributes.put("cdmPartName", 		 	      stTDM_DESCRIPTION	               );
//			        attributes.put("cdmPartProject", 	 	      stCN_PROJECT		               );
			        attributes.put("cdmPartApprovalType", 	      stITEM_TYPE1	                   );
			        attributes.put("cdmPartType", 		          stITEM_TYPE	                   );
			        attributes.put("cdmPartGlobal", 			  stGLOBAL_LOCAL                   );
			        attributes.put("cdmPartDrawingNo", 			  stCN_DRAWING_NO                  );
//			        attributes.put("cdmPartUOM",     		      stTDM_UOM                        );
			        attributes.put("cdmPartUOM",     		      sTempUOM                        );
//			        데이타가 깨진것이 있어 추후 cdmPartUOM 값을 변경해야함 12/06/16 12:19:00 이후 마이그레이션 대상으로
//			        attributes.put("cdmPartUOM_TempM",     		      stTDM_UOM                        );
			        attributes.put("cdmPartECONumber", 			  stCN_ECO_NUMBER                  );
			        attributes.put("cdmPartItemType", 			  stCN_ITEM_TYPE2                  );
			        attributes.put("cdmPartOEMItemNumber", 		  stCN_OEM_PART_NUMBER             );
			        attributes.put("cdmPartProductType", 		  stCN_PRODUCT_DIV                 );
			        attributes.put("cdmPartERPInterface", 		  stFOR_DRAWING_REMARK             );
			        attributes.put("cdmPartSurface", 			  stCN_SURFACE_AREA                );
//			        attributes.put("cdmPartEstimatedWeight", 	  stESTIMATED_WEIGHT               );
			        attributes.put("cdmPartEstimatedWeight", 	  stCN_ESTIMATED_WEIGHT            );
			        attributes.put("cdmPartMaterial", 			  stCN_ITEM_MATERIAL               );
			        attributes.put("cdmPartRealWeight", 		  stCN_REAL_WEIGHT                 );
			        attributes.put("cdmPartSize", 				  stCN_SIZE                        );
			        attributes.put("cdmPartCADWeight", 			  stPartCADWeight                  );
			        attributes.put("cdmPartSurfaceTreatment", 	  stSURFACE_TREATMENT              );
			        attributes.put("cdmPartIsCasting", 			  stIS_CASTING                     );
//			        attributes.put("cdmPartOption1", 			  stCN_OPTION1                     );
//			        attributes.put("cdmPartOption2", 			  stCN_OPTION2                     );
//			        attributes.put("cdmPartOption3", 			  stCN_OPTION3                     );
//			        attributes.put("cdmPartOption4", 			  stCN_OPTION4                     );
//			        attributes.put("cdmPartOption5", 			  stCN_OPTION5                     );
//			        attributes.put("cdmPartOption6", 		   	  stCN_OPTION6                     );
			        attributes.put("cdmPartOptionETC",         	  stOPTION_ETC               	   );
			        attributes.put("cdmPartOptionDescription", 	  stOPTION_DESC            		   );
			        attributes.put("cdmPartPublishingTarget",     stCN_COST                        );
			        attributes.put("cdmPartInvestor",          	  stPartInvestor                   );
//			        attributes.put("cdmPartProjectType",          stCN_PRODUCT_GROUP               ); // 
//			        attributes.put("cdmPartProductDivision",      stCN_PRODUCT_GROUP               ); //?? 확인 작업이 필요 
					
			        /*migration을 작업을 위해 attribute 추가 start */
			        attributes.put("cdmPartItemOtionItemM",        stCLS_NAME                      );
			        attributes.put("cdmPartPreviousRevisionM",     stPAR_REVISION                  );
			        attributes.put("cdmPartCheckPhantomPartM",     stCN_PHANTOM_ITEM   	           );
			        attributes.put("cdmPartECNameM",               stEC_NAME    	               );
			        attributes.put("cdmPartSeriesItemM",           stSERIES_ITEM                   );
			        attributes.put("cdmPartMCAOrgM",               stCN_ORG      	               );
			        attributes.put("cdmPartMCABOMManagementM",     stCN_MCA_INOUT        	       );
			        attributes.put("cdmPartMCAPartTypeM",          stCN_MCA_PART_TYPE_REF          );
			        attributes.put("cdmPartOption7",          	   stCN_OPTION7                    );
			        attributes.put("cdmPartCountryM",          	   stCN_COUNTRY                    );
			        attributes.put("cdmPartDrawingFinishM",        stCFOR_DRAWING_FINISH           );
			        attributes.put("cdmPartDrawingSizeM",          stDRAWING_SIZE                  );
			        attributes.put("cdmPartApplyPartListM",        stCN_APPLY_PARTLIST             );
			        attributes.put("cdmPartSubIdM",                stCN_SUB_ID                     );
			        attributes.put("cdmPartMCPOrgM",          	   stCN_OVERSEAS_ORG6              );
			        attributes.put("cdmPartMCPPartTypeM",          stCN_OVERSEAS_ORG6_PART_TYPE    );
			        attributes.put("cdmPartMCPBOMManagementM",     stCN_OVERSEAS_ORG6_INOUT 	   );  
			        attributes.put("cdmPartCreationDateM",        stCREATION_DATE     	           );  
			        attributes.put("cdmPartCreationUserIdM",      stUSER_OBJECT_ID  	           );  
			        attributes.put("cdmPartModUserIdM",           stUSER_ID_MOD  	               );  
			        attributes.put("cdmPartModificationDateM",    stMODIFICATION_DATE  	           );  
			        attributes.put("cdmPartComplexBodyForRealWeightM",  stCN_COMPLEX_BODY          );
			        attributes.put("cdmCheckMigration",           "Y"					  	       );
			        attributes.put("cdmPartPhase",           	   stPhase			  	       	   );
			        //add attribute 11/17/2016 start 
			        attributes.put("cdmPartApplyPartList",           "true"				  	       );
			        attributes.put("cdmPartApplySizeList",           "false"			  	       );
			        attributes.put("cdmPartApplySurfaceTreatmentList", "false"	  				   );
			        //add attribute 11/17/2016 end 
			        attributes.put("cdmPartEstimateWeightUnit", sTempWeightUnit			   );
			        
			        /*migration을 작업을 위해 attribute 추가 end  */
			        
			      
			        /* **********************************************************************************************************************
			         * part 데이타 생성 및 데이타 
			         * 트리거 오프한 상태로 진행되며 트리거에서 제공되는 attribute[originator]속성 및 interface 추가 설정 필터 정보 와 
			         * rev 정보 part master 생성 및 연결 및 속성(attribute[Originator]속성 추가 
			         * 에러 발생시 정지 및 데이타 정보 검색 
			         * ******************************************************************************************************************* */
			        
			        DomainObject partObj = new DomainObject();
			        boolean bCommit = false;
//					partObj.createObject(context, stPartType, stCN_ID, stREVISION, cdmConstantsUtil.POLICY_CDM_PART_POLICY, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        ContextUtil.startTransaction(context, true);
			        bCommit = true;
			        boolean bNewPartCheck = false;
			        boolean reviseCheck = false;
			        BusinessObject previousPart  = null;
			        
			        
//			        previousPart  = new BusinessObject(TYPE_CDMMECHANICALPART,stCN_ID,stPAR_REVISION,"eService Production");
//			        if(!previousPart.exists(context)){
//			        	previousPart  = new BusinessObject("cdmPhantomPart",stCN_ID,stPAR_REVISION,"eService Production");
//			        }
			        boolean checkPartPrevious = false;
			        
			        // 데이타 가 빵꾸난거 한해 이전 revise 정보을 가진 object 을 검색하며 생성기 아래와 같은 방식을 사용하지않는다. 
			        String findPreReviseMql = "temp query bus $1 $2 $3 where $4  select $5 dump $6";
			        String findMqlResult = "";
			        findMqlResult = MqlUtil.mqlCommand(context,findPreReviseMql,stPartType,stCN_ID,"*"," id==last.id","id","|");
			        System.out.println("findMqlResult"+findMqlResult);
			        StringList sListFindMqlPreRevise = new StringList();
			        sListFindMqlPreRevise = FrameworkUtil.split(findMqlResult, "|");
			        
			        if(sListFindMqlPreRevise.size()>2){
			        	String previousPartId = (String)sListFindMqlPreRevise.get(3);
			        	previousPart = new BusinessObject(previousPartId);
			        	checkPartPrevious = true;
			        }
			        
//			        if(  stCN_ID.equals(strPreviousPartNo) ) {
//			        	previousPart  = new BusinessObject(strPreviousPartType,strPreviousPartNo,strPreviousPartRevision,"eService Production");
//			        	boolean existPreviousPart = previousPart.exists(context);
//			        	if(previousPart.exists(context)){
//			        		checkPartPrevious = true;
//			        	}
//			        	if(stCN_ID.equals(strPreviousPartNo) && !existPreviousPart){
//			        		previousPart  = new BusinessObject(strPreviousPartType,stCN_ID,strPreviousPartRevision,"eService Production");
//			        	}
//			        	if(previousPart.exists(context)){
//			        		checkPartPrevious = true;
//			        	}
//			        }
			        
			        if(checkPartPrevious){
			        	BusinessObject currentPart = previousPart.revise(context, stREVISION, "eService Production");
			        	partObj.setId(currentPart.getObjectId(context));
			        	
			        	StringBuffer sbRelType = new StringBuffer();
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION);
			        	 
			        	StringList relList = new StringList();
			        	relList.add("id[connection]");
			        	
			        	MapList mlCodes = partObj.getRelatedObjects(context,
			        			sbRelType.toString(), // relationship pattern
			                    "*", // object pattern
			                    null, // object selects
			                    relList, // relationship selects
			                    true, // to direction
			                    false, // from direction
			                    (short) 1, // recursion level
			                    "", // object where clause
			                    null); // relationship where clause
			        	
			        	for (int jj = 0; jj < mlCodes.size(); jj++) {
							Map mapCode = (Map)mlCodes.get(jj);
							String relid = (String)mapCode.get("id[connection]");
							
							MqlUtil.mqlCommand(context, "del connection "+relid);
							
						}
			        } else {
			        	partObj.createObject(context, stPartType, stCN_ID, stREVISION, "cdmPartPolicy", cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        	bNewPartCheck = true;
			        }
			        strPreviousPartNo = stCN_ID;
					strPreviousPartRevision = stREVISION;
					strPreviousPartType = stPartType;

					
					
					if ("In Approval".equals(stSTATE)) {
						stSTATE = "Review";
						
					} else if ("Inactive".equals(stSTATE)) {
						stSTATE = "Obsolete";
						
					}else if ("Released".equals(stSTATE)) {
						stSTATE = "Release";
							
						
					}else if ("In Work".equals(stSTATE)) {
						stSTATE = "Preliminary";
					}
					
					partObj.setState(context, stSTATE);
					
//					partObj.setAttributeValues(context, attributes);
					
					String partObjectId = partObj.getId(context);

					if(boolPerson){
						partObj.setOwner(context, stTDM_ORG_USER_ID); 
					}
					
					
					/*
					 * *********************************************************
					 *  create 시 발생하는 trigger에서 발생하는 interface 생성 start
					 * *********************************************************
					 */
//					boolean isMEP = false;
//	
//					if (partObjectId != null && !"".equals(partObjectId)) {
//						String sExternalPartData = PropertyUtil.getSchemaProperty(context, DomainSymbolicConstants.SYMBOLIC_interface_ExternalPartData);
//						Part part = new Part(partObjectId);
//						String sPolicyClassification = part.getInfo(context, "policy.property[PolicyClassification].value");
//
//						// enable MEP by default
//						if (sPolicyClassification != null && "Equivalent".equals(sPolicyClassification)) {
//							isMEP = true;
//						}
//						if (isMEP) {
//							MqlUtil.mqlCommand(context, "modify bus $1 add interface $2;", partObjectId, sExternalPartData);
//						}
//					}
		
						/*
						 * *********************************************************
						 * attribute[attribute_Originator]
						 * 의 정보를stTDM_ORG_USER_ID 정보를 입력.
						 * *********************************************************
						 * 
						 */
						partObj.setAttributeValue(context, DomainConstants.ATTRIBUTE_ORIGINATOR, stTDM_ORG_USER_ID);
		
						/* part Master 생성 start */
						createPartMaster(context, partObjectId, stTDM_ORG_USER_ID,boolPerson);
						/* part Master 생성 end */
		
						/* create 시 발생하는 trigger에서 사용된 정보 interface 생성 end */
		
						/*
						 * *********************************************************
						 * 
						 *  EBOM 정보로 연결된 Part 을 생성할시 relationship 연결을 제외된다.
						 * 또한 relationship 연결의 경우 공통코드 데이타가 PLM에 스마트팀 정보가 다 있다고 가정하여
						 * 진행 공통코드를 검색하여 데이타가 없을시 오류 처리 . 오류가 발생하면 Exception 발생.
						 * *********************************************************
						 */
		
						StringBuffer sbVehicleId = new StringBuffer("");
						StringBuffer sbProjectId = new StringBuffer("");
						StringBuffer sbProjectTypeId = new StringBuffer("");
						StringBuffer sbProductTypeId = new StringBuffer("");
		
						StringBuffer sbOrg1Id = new StringBuffer();
						StringBuffer sbOrg2Id = new StringBuffer();
						StringBuffer sbOrg3Id = new StringBuffer();
		
						StringBuffer sbOption1Id = new StringBuffer("");
						StringBuffer sbOption2Id = new StringBuffer("");
						StringBuffer sbOption3Id = new StringBuffer("");
						StringBuffer sbOption4Id = new StringBuffer("");
						StringBuffer sbOption5Id = new StringBuffer("");
						StringBuffer sbOption6Id = new StringBuffer("");
		
						StringBuffer sbECONumberId = new StringBuffer("");
						StringBuffer sbDrawingNoId = new StringBuffer("");
						StringList sListPFs = new StringList();
						/* ************************************************
						 * stCN_VEHICLE_DESC 정보는 두개 이상 있을수 있으며 구분자 , 
						 * stVehicle_Cust 정보의 경우 두개이상 데이타 존재 있을수 있다 구분자 ;
						 * ************************************************
						 * */
						StringList stListCN_VEHICLE_DESC = new StringList();
						StringList stListVehicle_Cust = new StringList();
	
						stListCN_VEHICLE_DESC = FrameworkUtil.split(stCN_VEHICLE_DESC, ",");
	
						boolean checkErrorVehicleCust = false;
						if (stVehicle_Cust.startsWith("ORA-01422") || "-2147483647".equals(stVehicle_Cust)) {
							checkErrorVehicleCust = true;
						} else {
							stListVehicle_Cust = FrameworkUtil.split(stVehicle_Cust, ";");
						}
						int vehicleCustInt = 0;
						int vehicleDesInt = 0;
						vehicleCustInt = stListVehicle_Cust.size();
						vehicleDesInt = stListCN_VEHICLE_DESC.size();
						if (cdmStringUtil.isNotEmpty(stCN_VEHICLE_DESC) &&  !checkErrorVehicleCust) {
							StringList sListVehicleIds = new StringList();
//							if (vehicleCustInt == vehicleDesInt) {
//								for (int stListVehicleNum = 0; stListVehicleNum < stListCN_VEHICLE_DESC.size(); stListVehicleNum++) {
//	
//									String stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);
//	
//									String stTempVehicleCust = (String) stListVehicle_Cust.get(stListVehicleNum);
//	
//									String searchVehicle = stTempVehicle + "_" + stTempVehicle + "_" + stTempVehicleCust;
//	
//									String tempVehicleId = (String) vehicleCommonCodeMap.get(searchVehicle);
//									tempVehicleId = (tempVehicleId == null || "null".equals(tempVehicleId)) ? "" : tempVehicleId.trim();
//									if (StringUtils.isNotEmpty(tempVehicleId) && !sListVehicleIds.contains(tempVehicleId)) {
//										sListVehicleIds.add(tempVehicleId);
//										sbVehicleId.append(tempVehicleId);
//										sbVehicleId.append(",");
//									}
//	
//								}
								
								//
							if (vehicleCustInt >0) {
								for (int stListVehicleNum = 0; stListVehicleNum < stListVehicle_Cust.size(); stListVehicleNum++) {
	
									//
									String stTempVehicle = "";
									if(stListVehicleNum+1<=vehicleDesInt){
										stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);
									}else{
										continue;
									}
									//
//									String stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);
	
									String stTempVehicleCust = (String) stListVehicle_Cust.get(stListVehicleNum);
									String checkVehicleCust = ""; 
									checkVehicleCust = stTempVehicleCust.trim();
									if("-".equals(checkVehicleCust)){
										continue;
									}
									String searchVehicle = stTempVehicle + "_" + stTempVehicle + "_" + stTempVehicleCust;
	
									String tempVehicleId = (String) vehicleCommonCodeMap.get(searchVehicle);
									tempVehicleId = (tempVehicleId == null || "null".equals(tempVehicleId)) ? "" : tempVehicleId.trim();
									if (StringUtils.isNotEmpty(tempVehicleId) && !sListVehicleIds.contains(tempVehicleId)) {
										sListVehicleIds.add(tempVehicleId);
										sbVehicleId.append(tempVehicleId);
										sbVehicleId.append(",");
									}
	
								}
								//
							}
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_VEHICLE_DESC) && cdmStringUtil.isEmpty(sbVehicleId.toString()) && !checkErrorVehicleCust){
//							sbErrorMessage.append("No Vehicle information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Project */
						if (cdmStringUtil.isNotEmpty(stCN_Project_Id)) {
							
//							String projectIdMql = " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectCode] =='" + stCN_PROJECT + "' &&  attribute[cdmProjectGroupCustomerAttribute] =='" + stCN_PROJECT_CUST + "' && attribute[cdmProjectGroupProductTypeAttribute] == '" + stCN_PRODUCT_DIV + "' \" select id dump |";
//							String projectIdMql = " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectObjectIdM] =='" + stCN_Project_Id +"' select id dump |";
//							String projectIdMqlResult = MqlUtil.mqlCommand(context, projectIdMql);
//							StringList stListProjectMqlResult = FrameworkUtil.split(projectIdMqlResult, "|");
							String stTempProjectId = "";
							stTempProjectId = (String)projectMap.get(stCN_Project_Id);
							stTempProjectId = (stTempProjectId == null || "null".equals(stTempProjectId)) ? "" : stTempProjectId.trim();
							sbProjectId.append(stTempProjectId);
							
						}
						
						if(cdmStringUtil.isEmpty(sbProjectId.toString())){
//							sbErrorMessage.append("No Project information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						// Product Group
						if (cdmStringUtil.isNotEmpty(stCN_PRODUCT_GROUP)) {
							String stTempProductGroupId = (String)productGroupMap.get(stCN_PRODUCT_GROUP+"_"+stCN_PRODUCT_DIV);
							stTempProductGroupId = (stTempProductGroupId == null || "null".equals(stTempProductGroupId)) ? "" : stTempProductGroupId.trim();
							sbProjectTypeId.append(stTempProductGroupId);
	
						}
	
						if(cdmStringUtil.isNotEmpty(stCN_PRODUCT_GROUP) && cdmStringUtil.isEmpty(sbProjectTypeId.toString())){
//							sbErrorMessage.append("No Product Group information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Product Div */
						if ( cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempProductDivId = (String)productDivMap.get(stCN_PRODUCT_DIV);
							stTempProductDivId = (stTempProductDivId == null || "null".equals(stTempProductDivId)) ? "" : stTempProductDivId.trim();
							sbProductTypeId.append(stTempProductDivId);
	
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV) && cdmStringUtil.isEmpty(sbProductTypeId.toString())){
//							sbErrorMessage.append("No Product Div information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
	
						/* Option1 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION1)) {
							
							String stTempOption1 = "";
							stTempOption1 = (String)option1Map.get(stCN_OPTION1+"_"+stCN_PRODUCT_DIV);
							stTempOption1 = (stTempOption1 == null || "null".equals(stTempOption1)) ? "" : stTempOption1.trim();
							sbOption1Id.append(stTempOption1);
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_OPTION1) && cdmStringUtil.isEmpty(sbOption1Id.toString())){
//							sbErrorMessage.append("No OPTION1 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Option2 */
//						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeOption2Id) && cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
						if (cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption2 = "";
							stTempOption2 = (String)option2Map.get(stCN_OPTION2+"_"+stCN_PRODUCT_DIV);
							stTempOption2 = (stTempOption2 == null || "null".equals(stTempOption2)) ? "" : stTempOption2.trim();
							sbOption2Id.append(stTempOption2);
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isEmpty(sbOption2Id.toString())){
//							sbErrorMessage.append("No OPTION2 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
	
						/* Option3 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION3) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption3 = "";
							stTempOption3 = (String)option3Map.get(stCN_OPTION3+"_"+stCN_PRODUCT_DIV);
							stTempOption3 = (stTempOption3 == null || "null".equals(stTempOption3)) ? "" : stTempOption3.trim();
							sbOption3Id.append(stTempOption3);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION3) && cdmStringUtil.isEmpty(sbOption3Id.toString())){
//							sbErrorMessage.append("No OPTION3 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option4 */
						if ( cdmStringUtil.isNotEmpty(stCN_OPTION4) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption4 = "";
							stTempOption4 = (String)option4Map.get(stCN_OPTION4+"_"+stCN_PRODUCT_DIV);
							stTempOption4 = (stTempOption4 == null || "null".equals(stTempOption4)) ? "" : stTempOption4.trim();
							sbOption4Id.append(stTempOption4);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION4) && cdmStringUtil.isEmpty(sbOption4Id.toString())){
//							sbErrorMessage.append("No OPTION4 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option5 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION5) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							
							String stTempOption5 = "";
							stTempOption5 = (String)option5Map.get(stCN_OPTION5+"_"+stCN_PRODUCT_DIV);
							stTempOption5 = (stTempOption5 == null || "null".equals(stTempOption5)) ? "" : stTempOption5.trim();
							sbOption5Id.append(stTempOption5);
	
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION5) && cdmStringUtil.isEmpty(sbOption5Id.toString())){
//							sbErrorMessage.append("No OPTION5 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option6 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION6) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption6 = "";
							stTempOption6 = (String)option6Map.get(stCN_OPTION6+"_"+stCN_PRODUCT_DIV);
							stTempOption6 = (stTempOption6 == null || "null".equals(stTempOption6)) ? "" : stTempOption6.trim();
							sbOption6Id.append(stTempOption6);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION6) && cdmStringUtil.isEmpty(sbOption6Id.toString())){
//							sbErrorMessage.append("No OPTION6 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* sbECONumberId */
					if (cdmStringUtil.isNotEmpty(stCN_ECO_NUMBER)) {
						StringBuffer sbfECType = new StringBuffer();
						sbfECType.append("cdmECO");
						sbfECType.append(",");
						sbfECType.append("cdmEAR");
						sbfECType.append(",");
						sbfECType.append("cdmDCR");
						sbfECType.append(",");
						sbfECType.append("cdmPEO");
						
						
						String stTempECExist = "temp query bus \"" + sbfECType.toString() + "\" \""+stCN_ECO_NUMBER +"\"  *  select id dump |";
						String stTempECExistMql = MqlUtil.mqlCommand(context, stTempECExist);
						StringList sListTempECExistMql = FrameworkUtil.split(stTempECExistMql, "|");
						// test start start
						if (sListTempECExistMql.size() > 2) {
							sbECONumberId.append(sListTempECExistMql.get(3));
							sbErrorMessage.append("X").append("\t");
						} else {
//							sbErrorMessage.append( "EC information does not exist.");
							sbErrorMessage.append("O").append("\t");
						}
					}
					
					//Part Family
					if (stCN_ID.length() > 6) {

						String pfCodeName = stCN_ID.substring(0, 5);
						String partFamilys = (String)partFamilyMap.get(pfCodeName);
						partFamilys = (partFamilys == null || "null".equals(partFamilys)) ? "" : partFamilys.trim();
						sListPFs = FrameworkUtil.split(partFamilys, ",");
						if(cdmStringUtil.isEmpty(partFamilys) ){
//							if(bNewPartCheck){
								sbErrorMessage.append("O").append("\t");
//							}else{
//								sbErrorMessage.append("X").append("\t");
//							}
						}else{
//							if(bNewPartCheck){
								sbErrorMessage.append("X").append("\t");
//							}else{
//								sbErrorMessage.append("O").append("\t");
//							}
						}
					}
					
//						stCN_ECO_NUMBER
						/* sbDrawingNoId */
					
					HashMap paramHM = new HashMap();
					paramHM.put("partObjectId", partObjectId);
					paramHM.put("VehicleObjectId", sbVehicleId.toString());
					paramHM.put("ProjectObjectId", sbProjectId.toString());
					paramHM.put("ProjectTypeObjectId", sbProjectTypeId.toString());
					paramHM.put("ProductTypeObjectId", sbProductTypeId.toString());
						
					String[] objectIdArray = sbVehicleId.toString().split(",");
					for(int i=0; i<objectIdArray.length; i++){
	    				String strVehicleId = objectIdArray[i];
	    				
	    				if(StringUtils.isEmpty(strVehicleId.trim()))
	    					continue;
	    				
	    				DomainRelationship.connect(context, new DomainObject(strVehicleId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
	    			}
						
						if(UIUtil.isNotNullAndNotEmpty(sbProjectId.toString())){
			    			DomainRelationship.connect(context, new DomainObject(sbProjectId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT, partObj);
			    		}
						
						if(UIUtil.isNotNullAndNotEmpty(sbProjectTypeId.toString())){
							DomainRelationship.connect(context, new DomainObject(sbProjectTypeId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE, partObj);
			        	}
						
						//product group
						if(UIUtil.isNotNullAndNotEmpty(sbProductTypeId.toString())){
			    			DomainRelationship.connect(context, new DomainObject(sbProductTypeId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE, partObj);
			        	}
						
						if(UIUtil.isNotNullAndNotEmpty(sbOption1Id.toString())){
							DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption1Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
							x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option1");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption2Id.toString())){
			    		     
			    		    DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption2Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option2");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption3Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption3Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option3");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption4Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption4Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option4");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption5Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption5Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option5");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption6Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption6Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option6");
			        	}
			        	
						paramHM.put("ECONumberOid", sbECONumberId.toString());
						if(UIUtil.isNotNullAndNotEmpty(sbECONumberId.toString())){
		        			DomainRelationship.connect(context, new DomainObject(sbECONumberId.toString()), DomainConstants.RELATIONSHIP_AFFECTED_ITEM, partObj);
			        		
			        	}
						bCommit = true;
						ContextUtil.commitTransaction(context);		
					if (bNewPartCheck) {
						int sListPartFamilyIdsSize = sListPFs.size();
						boolean bCheckPartNamePF = false;
						boolean bExceedOnePF = false;
						for (Iterator iterPF = sListPFs.iterator(); iterPF.hasNext();) {
							
							String sPF = (String) iterPF.next();
							HashMap connectPFHMap = new HashMap();
							
							if(sListPartFamilyIdsSize>1){
								String pfCodeName = stCN_ID.substring(0, 5);
								String checkPartFamilyName = pfCodeName+":"+stTDM_DESCRIPTION;
								bExceedOnePF = true;
								sPF = (String)partFamilyMap.get(checkPartFamilyName);
								if(UIUtil.isNotNullAndNotEmpty(sPF)){
									bCheckPartNamePF = true;
								}
							}
							
							if ( (UIUtil.isNotNullAndNotEmpty(sPF) && bExceedOnePF) || sListPartFamilyIdsSize == 1) {
								connectPFHMap.put("sPF", sPF);
								connectPFHMap.put("partObjectId", partObjectId);
//							
								String connectResult = JPO.invoke(context, "cdmPartMigration", null, "connectPartFamily", JPO.packArgs(connectPFHMap), String.class);
								
								if (connectResult.startsWith("false|")) {
//									int startIndex = connectResult.indexOf("false|");
//									System.out.println("errorMessage ------->  "+connectResult);
//									connectResult.substring(startIndex);
									sbErrorMessage.append("O (PartFamily)").append(connectResult).append("\t");
									
								} else {
									sbErrorMessage.append("X (PartFamily)").append("\t");
									
								}
								break;
							}
						}
						//2개 이상 part family 과 존재하지만  stCN_ID  자른 정보와 part family의 name 값이 일치하지않을경우 하나의 part family만 연결한다.
						if(bExceedOnePF && !bCheckPartNamePF){
							//
							for (int exceedOnePfCnt = 0 ;exceedOnePfCnt<sListPFs.size();exceedOnePfCnt++ ) {
								
								String sPF = (String) sListPFs.get(0);
								HashMap connectPFHMap = new HashMap();
								
								String pfCodeName = stCN_ID.substring(0, 5);
								String checkPartFamilyName = pfCodeName+":"+stTDM_DESCRIPTION;
								
								if ( UIUtil.isNotNullAndNotEmpty(sPF)  ) {
									connectPFHMap.put("sPF", sPF);
									connectPFHMap.put("partObjectId", partObjectId);
									
									String connectResult = JPO.invoke(context, "cdmPartMigration", null, "connectPartFamily", JPO.packArgs(connectPFHMap), String.class);
									
									if (connectResult.startsWith("false|")) {
//										int startIndex = connectResult.indexOf("false|");
//										connectResult.substring(startIndex);
										sbErrorMessage.append("O (PartFamily)").append("\t");
									} else {
										sbErrorMessage.append("X (PartFamily)").append("\t");

									}
									break;
								}
							}
							//
						}
						checkAddPart = true;
					}else{
						checkAddPart = true;
						sbErrorMessage.append("X (Revise PartFamily)").append("\t");
					}
//						paramHM.put("DrawingNo_Oid", sbDrawingNoId.toString());
//						Boolean ErrorCheck = (Boolean) JPO.invoke(context, "cdmPartLibrary", null, "checkPartObjectRelationShip", JPO.packArgs(paramHM), Boolean.class);
						//(Context context, String partObjectId, String vehicleObjectId,
//			    		String projectObjectId, String projectTypeObjectId, String productTypeObjectId, String org1ObjectId, 
//						String org2ObjectId, String org3ObjectId, String option1ObjectId, String option2ObjectId,
//						String option3ObjectId, String option4ObjectId, String option5ObjectId, String option6ObjectId, String ecId, String drawingId) 
						
//						partObjectRelationShip(context, partObjectId, VehicleObjectId, ProjectObjectId, ProjectTypeObjectId, ProductTypeObjectId, Org1ObjectId, Org2ObjectId, Org3ObjectId, Option1ObjectId, Option2ObjectId, Option3ObjectId, Option4ObjectId, Option5ObjectId, Option6ObjectId, ECONumberOid, DrawingNo_Oid);
//			    		DomainObject partObj = new DomainObject(partObjectId);
//			    		if(UIUtil.isNotNullAndNotEmpty(vehicleObjectId)){
//			    			StringList relVehicleIdList = partObj.getInfoList(context, "to["+cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE+"].id");
//			    			if(relVehicleIdList.size() > 0 && ! "".equals(relVehicleIdList)){
//			    				for(int k=0; k<relVehicleIdList.size(); k++){
//			    					DomainRelationship.disconnect(context, relVehicleIdList.get(k).toString());
//			    				}
//			    			}
//			    		    if(vehicleObjectId.contains(",")){
//			    				String[] objectIdArray = vehicleObjectId.split(",");
//			    				StringBuffer strBuffer = new StringBuffer();
//			    				for(int i=0; i<objectIdArray.length; i++){
//			    					String strVehicleId = objectIdArray[i];
//			    					DomainRelationship.connect(context, new DomainObject(strVehicleId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
//			    				}
//			    		    }else{
//			    			    if(!"".equals(vehicleObjectId)){
//			    					DomainRelationship.connect(context, new DomainObject(vehicleObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
//			    				}
//			    		    }
//			    		}
					
						/*
						 * *********************************************************
						 * promote 및 revise "In Approval" 상태를
						 * 가진 part 정보일경우 enovia에서는 In Review 상태로 ... "Inactive" 상태를
						 * 가진 part 정보일경우 enovia에서는 Obsolete 상태로 변경. 과거 revision을 가진
						 * object 은 무조건 Released 상태를 가진다. 현재 eo 데이타는 존재하지않아 연결정보를
						 * 사용할 수 없다. 현재 상태로는 eo 데이타가 없고 drawing 데이타가 연결이 되지않아 추후 연결
						 * 필요
						 * 
						 * 도면 있을 때 에는 revise 될때 같이 처리해야한다. 참조 cdmPartLibray
						 * revise... 소스는 빼논 상태
						 * *********************************************************
						 * 
						 */
//					bCommit = true;
//					ContextUtil.commitTransaction(context);	
					

					if (UIUtil.isNotNullAndNotEmpty(stCREATION_DATE) ) {
						Date createdate = new Date(stCREATION_DATE);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa", new Locale("en", "US"));
						String tempCreatedDate = "";
						tempCreatedDate = sdf.format(createdate);
						//12/6/2016 10:40:16 AM
						MqlUtil.mqlCommand(context, "mod bus $1 originated $2", partObjectId, tempCreatedDate);
					}

					
					try {
						MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", partObjectId, stAccessProductGroup, stAceesOrg);
						
						if(UIUtil.isNullOrEmpty(stAccessProductGroup) || " - ".equals(stAceesOrg)  || UIUtil.isNullOrEmpty(stAceesOrg)){
							sbErrorMessage.append(stAccessProductGroup).append("\t").append(stAceesOrg).append("\t").append("project or Org not exist").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t").append("X").append("\t");
						}
					} catch (Exception e) {
						sbErrorMessage.append(stAccessProductGroup).append("\t").append(stAceesOrg).append("\t");
					}
					
					
					if(bCommit){
						try{
						partObj.setAttributeValues(context, attributes);
						sbErrorMessage.append("X").append("\t");
						}catch(Exception e4){
							sbErrorMessage.append("O").append("\t");
						}
					}
					
					MqlUtil.mqlCommand(context, "trigger on");
					checkTriggerOff = false;	
						
					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
//						writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());	
						writeSuccessToFile(cdmCommonExcel.getTimeStamp() +"\t"+ subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+sbErrorMessage.toString());	
					}else{
//							writeSuccessToFile("LineNum(#): "+subPartCount +" \t PartNo: \t "+tempStPartNo+" \t ");
						writeSuccessToFile(cdmCommonExcel.getTimeStamp()+"\t"+subPartCount +"\t"+tempStPartNo+"\t"+stREVISION);
							
					}
						
					successCount++;
						
				} catch (Exception e) {
					ContextUtil.abortTransaction(context);

//					if(!checkAddPart){
//						MQLCommand mqlCommand = new MQLCommand();
//						mqlCommand.open(context);
//						mqlCommand.executeCommand(context, "abort transaction $1","PartFamily");
//					}
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "trigger on");
						checkTriggerOff = false;			
					}
					failCount++;
					writeErrorToFile("LineNum(#) \t"+tempStRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t "+ tempStPartNo+"\t"+tempStPartRevision +"\t"+e.getMessage().replaceAll("\r|\n", "")); 
					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t" +  data ) ;
					e.printStackTrace(errorStream);
					
					writeShotErrorToFile("LineNum(#) \t"+tempStRowNum + " \t"+cdmCommonExcel.getTimeStamp2()+"\t "+tempStPartNo+"\t"+tempStPartRevision +"\t"+e.toString().replaceAll("\r|\n", ""));
				}finally{
					
				}
				
			} // end of while 
			
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================");
			//
		} catch (Exception e1) {
			writeFailToFile(" LineNum(#):"+tempStRowNum);
			writeErrorToFile("LineNum(#):"+tempStRowNum + "  "+e1.getMessage());
			e1.printStackTrace(errorStream);
			
			
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("	CREATE PART OBJECT CLOSE TIME:  "+cdmCommonExcel.getTimeStamp2()+"          "  );
			writeMessageToConsole("	CREATE PART OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+") TOTALCOUNT :("+totalCount+")"  );
			writeMessageToConsole("==================================================================================== \n");
			MqlUtil.mqlCommand(context, "history on");
			if(checkTriggerOff){
				MqlUtil.mqlCommand(context, "trigger on");
			}
			try {
				if (null != errorStream )
					errorStream .close();

				if (null != logWriter)
					logWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if(null != bufferReader)
					bufferReader.close();
				
				if(null != errorLogFile)
					errorLogFile.close();
				
				if(null != debugLogFile)
					debugLogFile.close();

				if(null != errorLogFile)
					errorLogFile.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			
			long endTime = System.currentTimeMillis();
			long leadTime = (endTime-startTime)/1000/60;
			System.out.println("cdmPartMigration : reCreatedPart End.   endTime:"+cdmCommonExcel.getTimeStamp()  + " leadTime :"+leadTime);
			
		}
	
	
    
	}
    
		
	/**
     * Implements interface on Classified Items
     *
     * @param context the eMatrix <code>Context</code> object
     * @param parentId parrent objectID
     * @param objectId
     * @return int 0 or 1 for Success or failure
     * @throws Exception if the operation fails
     * @throws FrameworkException if the operation fails
     */
    public static String implementInterfaceOnClassifiedItem(Context context, String parentId, String objectId) throws
        Exception,FrameworkException
    {
        String strResult = "";
        DomainObject doObj = new DomainObject(parentId);
        String strInterface = doObj.getAttributeValue(context,LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);

        try{
            String strMQL       = "print bus $1 select interface dump";
            strResult           = MqlUtil.mqlCommand(context, strMQL, objectId);
            ContextUtil.pushContext(context);

            if(strResult != null && strResult.indexOf(strInterface) == -1)
            {
                strMQL      = "modify bus $1 add interface $2";
                strResult   = MqlUtil.mqlCommand(context, strMQL, objectId,strInterface);

                if(strResult.indexOf(LibraryCentralConstants.INTERFACE_CLASSIFICATION_SEARCH_FILTER) != -1)
                {
                    strMQL      ="modify bus $1 remove interface $2";
                    strResult   = MqlUtil.mqlCommand(context, strMQL, objectId,LibraryCentralConstants.INTERFACE_CLASSIFICATION_SEARCH_FILTER);
                }

                //Changes Added for Designer Central - Integration
                DomainObject toObject = new DomainObject(objectId);
                String implementIntOnMinorObjs = EnoviaResourceBundle.getProperty(context,"emxLibraryCentral.MinorObjects.Classify");
                
                if(CommonDocument.TYPE_DOCUMENTS.equals(CommonDocument.getParentType(context, toObject.getInfo(context, DomainObject.SELECT_TYPE)))
                    && (implementIntOnMinorObjs != null && implementIntOnMinorObjs.equalsIgnoreCase("true"))){
                    //Get all version objects (minor objects)connected with Active Version relationship
                    StringList selectStmts = new StringList(2);
                    selectStmts.addElement(DomainObject.SELECT_ID);
                    selectStmts.addElement(SELECT_ACTIVE_VERSION_ID);
                    selectStmts.addElement("interface");
                    MapList result = (MapList)toObject.getRelatedObjects(context,
                                                                         CommonDocument.RELATIONSHIP_ACTIVE_VERSION,
                                                                         "*", selectStmts,
                                                                         new StringList(),
                                                                         false, true, (short)1, null, null);

                    String activeVersionId = "";
                    String implementedInterfaces = "";
                    if (result != null && result.size() > 0) {
                        for(int lCnt = 0; lCnt < result.size(); lCnt ++) {
                           Map objMap = (Map)result.get(lCnt);
                           activeVersionId = (String)objMap.get(DomainObject.SELECT_ID);

                           //check if there are more than one interfaces
                           //and act accordingly
                           Object interfaces = (Object)objMap.get("interface");

                           String interfaceStr = "";
                           StringList interfacesList = null;

                           boolean moreThanOneInterfaces = false;
                           boolean addInterface = false;

                           if(interfaces instanceof String)
                           {
                               interfaceStr = (String)interfaces;
                           }
                           else if(interfaces instanceof StringList)
                           {
                               moreThanOneInterfaces = true;
                               interfacesList = new StringList();
                               interfacesList = (StringList)interfaces;
                           }

                           if(!moreThanOneInterfaces &&
                              interfaceStr != null &&
                              interfaceStr.indexOf(strInterface) == -1)
                           {
                               addInterface = true;
                           }
                           else if(moreThanOneInterfaces &&
                                   interfacesList != null &&
                                   !interfacesList.contains(strInterface))
                           {
                               addInterface = true;
                           }

                           //The interface is new
                           if(addInterface)
                           {
                               BusinessObject activeVersionObject = new BusinessObject(activeVersionId);
                               activeVersionObject.open(context);
                               BusinessObjectList minorObjectList = activeVersionObject.getRevisions(context);
                               activeVersionObject.close(context);

                               for (int i = 0; i < minorObjectList.size(); i++)
                               {
                                   BusinessObject minorObject = (BusinessObject)minorObjectList.get(i);
                                   String versionObjectId = minorObject.getObjectId();

                                   strMQL       = "modify bus $1 add interface $2";
                                   strResult    = MqlUtil.mqlCommand(context, strMQL, versionObjectId, strInterface);
                               }
                           }
                        }
                   }
                }

                //End Changes
            }else{
                strResult = "0.0";
            }
        }catch(Exception e)
        {
            e.printStackTrace();
            strResult = "0.0";
            e.printStackTrace();
            throw e;
        }finally{
            ContextUtil.popContext(context);
        }
        return strResult;
    }
    
    
    
    /**
     * 
     * @param context
     * @param args
     * @throws Exception
     */
    public void addOptionPart(Context context,String args[])throws Exception{




		long startTime = System.currentTimeMillis();
		System.out.println("cdmPartMigration : addOptionPart -StartTime:"+cdmCommonExcel.getTimeStamp());
		String logFileName = "addOptionPartM";
		
	
		if(args.length!=1){
			throw new Exception("The excel path does not exist.");
		}
		String sFileLocationAndFileName = args[0];
		
//		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
//		String sFileLocationAndFileName = (String)paramMap.get("fileData");
		
		String sFileLocation 		= "";
		String sFileName 			= "";
		
		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf(File.separator));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf(File.separator)+1);
		
		
//		sFileName = (String)paramMap.get("File");
		
		String sPartInputDirectory = sFileLocation;

		// documentDirectory does not ends with "/" add it
		if(sPartInputDirectory != null && !sPartInputDirectory.endsWith(sfileSeparator))
		{
			sPartInputDirectory = sPartInputDirectory + sfileSeparator;
		}
		String sPartOutputDirectory = "";
		// create a directory to add debug and error logs
		sPartOutputDirectory = new File(sPartInputDirectory).getParentFile() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+  sfileSeparator;
        File fileOutputDirectory = new File(sPartOutputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        
        String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		logFileName +="_"+sFileName.substring(0, sFileName.lastIndexOf("."))+"_"+formatTime;
		
        
		logWriter 			 	= new BufferedWriter(new FileWriter(sPartOutputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(sPartOutputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(sPartOutputDirectory + logFileName + "_SuccessLogs.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(sPartOutputDirectory + logFileName + "_FailedLogs" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		shortErrorLogFile        = new File(sPartOutputDirectory + logFileName + "ShortErrorLogs" + ".txt");
		shortErrorWriter         = new BufferedWriter(new FileWriter(shortErrorLogFile,true));
		
		String tempStRowNum   = ""; //순번
		String tempStPartNo   = ""; //엑셀의 PartNo
		String tempStPartRevision   = ""; //엑셀의 PartNo
		int totalCount = 0;
		int successCount = 0;
		int failCount = 0;
		boolean checkTriggerOff = false;
		BufferedReader bufferReader = null;
		writeSuccessToFile("CreateTime \t LineNume(#) \t  PartNo. \t Revision \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t  OPTION1 Wrong. \t OPTION2 Wrong. \t  OPTION3 Wrong. \t   OPTION4 Wrong. \t  OPTION5 Wrong. \t   OPTION6 Wrong. \t EC information does not exist. \t No Part Family exist. \t Part Connect \t Project Group \t Org  \t attributes ");
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole(" RE Create PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
		writeMessageToConsole("	Reading input log file from : "+sPartInputDirectory+sFileName);
		writeMessageToConsole("	Writing Log files to: " + sPartInputDirectory );
		writeMessageToConsole("====================================================================================\n");
		boolean checkAddPart = false;
		MqlUtil.mqlCommand(context, "history off");
		try {
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(sPartInputDirectory+sFileName),"euc-kr"));
			String data = "";  							// 텍스트 파일 라인정보담을 변수 
			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
			
			/* cdmCommonCode lev2 object 검색 start  */
			
			// 12/2 start 
			Map option1Map = getOptionCode(context,"Option1");
			Map option2Map = getOptionCode(context,"Option2");
			Map option3Map = getOptionCode(context,"Option3");
			Map option4Map = getOptionCode(context,"Option4");
			Map option5Map = getOptionCode(context,"Option5");
			Map option6Map = getOptionCode(context,"Option6");
			
			Map vehicleCommonCodeMap = getVehicleCode(context,"Vehicle");
			Map productGroupMap      = getProductGroupCode(context,"Product Group Name");
			Map productDivMap        = getProductDivCode(context,"Product Div");
			Map projectMap           = getProjectCode(context,"cdmProjectGroupObject");
//			Map partFamilyMap        = getPartFamilyId(context);
			Map partFamilyMap        = getPartFamilyId2(context,"Global R&D:Global R&D"); //top part family[cdmPartFamilyBlockCodeName]
			
			/*cdmCommonCode lev2 object 검색 end */ 
			
			String strLanguage = context.getLocale().getLanguage();
			
			AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
			attrPartGlobal.open(context);
			StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
			attrPartGlobal.close(context);
			StringList attrPartGlobalKOList = new StringList();
			attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
			
			
			AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
			attrPartItemType.open(context);
			StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
			attrPartItemType.close(context);
			StringList attrPartItemTypeKOList = new StringList();
			attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
			
			
			AttributeType attrPartERPInterface = new AttributeType("cdmPartERPInterface");
			attrPartERPInterface.open(context);
			StringList attrPartERPInterfaceList = attrPartERPInterface.getChoices(context);
			attrPartERPInterface.close(context);
			StringList attrPartERPInterfaceKOList = new StringList();
			attrPartERPInterfaceKOList = i18nNow.getAttrRangeI18NStringList("cdmPartERPInterface", attrPartERPInterfaceList, strLanguage);
			
			AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
			attrPartType.open(context);
			StringList attrPartTypeList = attrPartType.getChoices(context);
			attrPartType.close(context);
			StringList attrPartTypeKOList = new StringList();
			attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
			
			HashMap tempUOMHMap = new HashMap();
			tempUOMHMap.put("EA"  , "Each");
			tempUOMHMap.put("BAG" , "bag");
			tempUOMHMap.put("BTL" , "bottle");
			tempUOMHMap.put("BOX" , "box");
			tempUOMHMap.put("CC"  , "cc");
			tempUOMHMap.put("CMM" , "mm³");
			tempUOMHMap.put("CMT" , "m³");
			tempUOMHMap.put("CN"  , "can");
			tempUOMHMap.put("CT"  , "carton");
			tempUOMHMap.put("DL"  , "dl");
			tempUOMHMap.put("DZ"  , "dozen");
			tempUOMHMap.put("FT"  , "ft");
			tempUOMHMap.put("GLL" , "gallon");
			tempUOMHMap.put("G"   , "g");
			tempUOMHMap.put("IN"  , "inch");
			tempUOMHMap.put("KG"  , "kg");
			tempUOMHMap.put("KMT" , "km");
			tempUOMHMap.put("L"   , "L");
			tempUOMHMap.put("LBR" , "lb");
			tempUOMHMap.put("M"   , "m");
			tempUOMHMap.put("MGR" , "mg");
			tempUOMHMap.put("ML"  , "ml");
			tempUOMHMap.put("MMT" , "mm");
			tempUOMHMap.put("MT"  , "ton");
			tempUOMHMap.put("N"   , "N");
			tempUOMHMap.put("PC"  , "Piece");
			tempUOMHMap.put("PL"  , "Pl");
			tempUOMHMap.put("ROL" , "Roll");
			tempUOMHMap.put("SET" , "Set");
			tempUOMHMap.put("SH"  , "Sheet");
			tempUOMHMap.put("SM"  , "m²");
			tempUOMHMap.put("UN"  , "unit");
			tempUOMHMap.put("DRM" , "drum");
			
			int lineNumber = 1;      
			int subPartCount = 0;
			
			String strPreviousPartNo = null;
			String strPreviousPartRevision = null;
			String strPreviousPartType = null;
			
			
			while ((data = bufferReader.readLine()) != null) {
				
				StringBuffer sbErrorMessage = new StringBuffer("");
				MqlUtil.mqlCommand(context, "trigger off");
				checkTriggerOff = true;
				checkAddPart = false;
				StringList stListData = FrameworkUtil.split(data, "\t");
				try {
					
					if (lineNumber == 1) {
						stListHeader = stListData;
						writeFailToFile("errorRecord \t"+data);
						lineNumber++;
						continue;
					}
					lineNumber++;
					totalCount++;
					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
					int size_Data = stListData.size();
					int size_Header = stListHeader.size();
					if (size_Data != size_Header) {
						String errorMessage = " NOT MATCH DATA FIELD";
						throw new Exception(errorMessage);
					}

					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {

						String sPartInfos = cdmCommonExcel.isVaildNullData((String)stListData.get(stListNum));
						String sPartHeader = ((String) stListHeader.get(stListNum)).trim();
						partHM.put(sPartHeader, sPartInfos);
						
					}
					
					String stPartType                   = TYPE_CDMMECHANICALPART;  
					String stPartCount                  = ((String)partHM.get("#"            		        )).trim(); // 1 순번 
					String stCLS_NAME                   = ((String)partHM.get("CLS_NAME"                    )).trim(); // 2 
					String stOBJECT_ID                  = ((String)partHM.get("OBJECT_ID"                   )).trim(); // 3 //받은 자료에 unique 값 migration대상아님 
	
					String stCN_ID                      = ((String)partHM.get("CN_ID"  	                    )).trim(); // 5 Name
					String stREVISION                   = ((String)partHM.get("REVISION"                    )).trim(); // 6 Revision
					String stSTATE                      = ((String)partHM.get("STATE"                       )).trim(); // 7 State
					String stCREATION_DATE              = ((String)partHM.get("CREATION_DATE"               )).trim(); // 8  attribute[cdmPartCreationDateM]
					String stUSER_OBJECT_ID             = ((String)partHM.get("USER_OBJECT_ID"              )).trim(); // 9  attribute[cdmPartCreationUserIdM]
					String stUSER_ID_MOD                = ((String)partHM.get("USER_ID_MOD"                 )).trim(); // 10 attribute[cdmPartModUserIdM]
					String stMODIFICATION_DATE          = ((String)partHM.get("MODIFICATION_DATE"           )).trim(); // 11 attribute[cdmPartModificationDateM] 
					String stTDM_DESCRIPTION            = ((String)partHM.get("TDM_DESCRIPTION"             )).trim(); // 12 attribute[cdmPartName]
					String stTDM_UOM                    = ((String)partHM.get("TDM_UOM"  			        )).trim(); // 13 attribute[cdmPartUOM]
					String stPhaseM                     = ((String)partHM.get("PHASE"                       )).trim(); // 14 
					String stPAR_REVISION               = ((String)partHM.get("PAR_REVISION"                )).trim(); // 15 Previous Revision
	//				String stAPPROVAL_DATE              = ((String)partHM.get("APPROVAL_DATE"               )).trim(); // 16 
	//				String stREVISION_STG               = ((String)partHM.get("REVISION_STG"                )).trim(); // 17 
					String stTDM_ORG_USER_ID            = ((String)partHM.get("TDM_ORG_USER_ID"             )).trim(); // 18 First Revision creator
	//				String stTDM_ORG_CREATEDATE         = ((String)partHM.get("TDM_ORG_CREATEDATE"          )).trim(); // 19 
	//				String stTDM_APPROVED_BY            = ((String)partHM.get("TDM_APPROVED_BY"             )).trim(); // 20 
	//				String stTDM_ORIGIN_ID              = ((String)partHM.get("TDM_ORIGIN_ID"               )).trim(); // 21 
					String stCN_PROJECT                 = ((String)partHM.get("CN_PROJECT"                  )).trim(); // 22 PROJECT
					String stCN_PROJECT_CUST            = ((String)partHM.get("CN_PROJECT_CUST"             )).trim(); // 23 PROJECT_CUST
	//				String stCN_PRODUCT_NAME            = ((String)partHM.get("CN_PRODUCT_NAME"             )).trim(); // 24 
	//				String stCN_PART_GROUP              = ((String)partHM.get("CN_PART_GROUP"               )).trim(); // 25 
	//				String stCN_PART_NAME               = ((String)partHM.get("CN_PART_NAME"                )).trim(); // 26
	//				String stCN_WEIGHT                  = ((String)partHM.get("CN_WEIGHT"                   )).trim(); // 27
					String stCN_ESTIMATED_WEIGHT        = ((String)partHM.get("CN_ESTIMATED_WEIGHT"         )).trim(); // 28 attribute[cdmPartEstimatedWeight] 
					String stCN_WEIGHT_UNIT             = ((String)partHM.get("CN_WEIGHT_UNIT"              )).trim(); // 29
					String stCN_TOP_ITEM                = ((String)partHM.get("CN_TOP_ITEM"                 )).trim(); // 30
					String stCN_PHANTOM_ITEM            = ((String)partHM.get("CN_PHANTOM_ITEM"             )).trim(); // 31
					String stCN_ITEM_TYPE               = ((String)partHM.get("CN_ITEM_TYPE"                )).trim(); // 32
					String stCN_SERVICE_ITEM            = ((String)partHM.get("CN_SERVICE_ITEM"             )).trim(); // 33
					String stCN_ITEM_MATERIAL           = ((String)partHM.get("CN_ITEM_MATERIAL"            )).trim(); // 34
					String stCN_ITEM_UPDATE_FROM_ERP    = ((String)partHM.get("CN_ITEM_UPDATE_FROM_ERP"     )).trim(); // 35
					String stCN_COST                    = ((String)partHM.get("CN_COST"                     )).trim(); // 36
					String stCN_CURRENCY                = ((String)partHM.get("CN_CURRENCY"                 )).trim(); // 37
					//String stCN_COMMENTS              = ((String)partHM.get("CN_COMMENTS"                 )).trim(); // 38
					String stCN_OEM_PART_NUMBER         = ((String)partHM.get("CN_OEM_PART_NUMBER"          )).trim(); // 39
					String stEC_NAME                    = ((String)partHM.get("EC_NAME"                     )).trim(); // 40
					String stCN_ECO_NUMBER              = ((String)partHM.get("CN_ECO_NUMBER"               )).trim(); // 41
					String stCN_PRODUCT_GROUP           = ((String)partHM.get("CN_PRODUCT_GROUP"            )).trim(); // 42
					String stCN_SERIES_ITEM             = ((String)partHM.get("CN_SERIES_ITEM"              )).trim(); // 43
					String stCN_VEHICLE                 = ((String)partHM.get("CN_VEHICLE"                  )).trim(); // 44
					String stCN_CUSTOMER                = ((String)partHM.get("CN_CUSTOMER"                 )).trim(); // 45
					String stCN_SIZE                    = ((String)partHM.get("CN_SIZE"                     )).trim(); // 46
					String stCN_SURFACE_TREATMENT       = ((String)partHM.get("CN_SURFACE_TREATMENT"        )).trim(); // 47
					String stCN_SURFACE_AREA            = ((String)partHM.get("CN_SURFACE_AREA"             )).trim(); // 48
					String stCN_ITEM_TYPE1              = ((String)partHM.get("CN_ITEM_TYPE1"               )).trim(); // 49
					String stCN_MATERIAL               = ((String)partHM.get("CN_MATERIAL"                  )).trim(); // 50
					String stCN_ORG1                   = ((String)partHM.get("CN_ORG1"                      )).trim(); // 51  migration 대상 제외  
	//				String stCN_ORG2                   = ((String)partHM.get("CN_ORG2"                      )).trim(); // 52  migration 대상 제외 
	//				String stCN_ORG3                   = ((String)partHM.get("CN_ORG3"                      )).trim(); // 53  migration 대상 제외 
					String stCN_ORG                    = ((String)partHM.get("CN_ORG"                       )).trim(); // 54  MCA Org
					String stCN_MCA_INOUT              = ((String)partHM.get("CN_MCA_INOUT"                 )).trim(); // 55  MCA BOM Management
					String stCN_MCA_PART_TYPE_REF      = ((String)partHM.get("CN_MCA_PART_TYPE_REF"         )).trim(); // 56  MCA Part Type
					String stCN_OPTION1                = ((String)partHM.get("CN_OPTION1"                   )).trim(); // 57
					String stCN_OPTION2                = ((String)partHM.get("CN_OPTION2"                   )).trim(); // 58
					String stCN_OPTION3                = ((String)partHM.get("CN_OPTION3"                   )).trim(); // 59
					String stCN_OPTION4                = ((String)partHM.get("CN_OPTION4"                   )).trim(); // 60
					String stCN_OPTION5                = ((String)partHM.get("CN_OPTION5"                   )).trim(); // 61
					String stCN_OPTION6                = ((String)partHM.get("CN_OPTION6"                   )).trim(); // 62
					String stCN_OPTION7                = ((String)partHM.get("CN_OPTION7"                   )).trim(); // 63
					String stCN_OPTION_ETC             = ((String)partHM.get("CN_OPTION_ETC"                )).trim(); // 64
					String stCN_IS_CASTING             = ((String)partHM.get("CN_IS_CASTING"                )).trim(); // 65
					String stCN_OPTION_DESC            = ((String)partHM.get("CN_OPTION_DESC"               )).trim(); // 66
					String stCN_FOR_MAC                = ((String)partHM.get("CN_FOR_MAC"                   )).trim(); // 67
					String stCN_FOR_MIL                = ((String)partHM.get("CN_FOR_MIL"                   )).trim(); // 68
					String stCN_FOR_MIS                = ((String)partHM.get("CN_FOR_MIS"                   )).trim(); // 69
					String stCN_FOR_MMT                = ((String)partHM.get("CN_FOR_MMT"                   )).trim(); // 70
					String stCN_REAL_WEIGHT            = ((String)partHM.get("CN_REAL_WEIGHT"               )).trim(); // 71
					String stCN_COUNTRY                = ((String)partHM.get("CN_COUNTRY"                   )).trim(); // 72
					String stCN_PRODUCT_DIV            = ((String)partHM.get("CN_PRODUCT_DIV"               )).trim(); // 73
					String stCN_GLOBAL_LOCAL           = ((String)partHM.get("CN_GLOBAL_LOCAL"              )).trim(); // 74
					String stCN_PROJECT_CODE           = ((String)partHM.get("CN_PROJECT_CODE"              )).trim(); // 75
					String stCN_OPTION_DRAWING         = ((String)partHM.get("CN_OPTION_DRAWING"            )).trim(); // 76
					String stCN_FOR_DRAWING_FINISH     = ((String)partHM.get("CN_FOR_DRAWING_FINISH"        )).trim(); // 77
					String stCN_FOR_DRAWING_SIZE       = ((String)partHM.get("CN_FOR_DRAWING_SIZE"          )).trim(); // 78
					String stCN_FOR_DRAWING_REMARK     = ((String)partHM.get("CN_FOR_DRAWING_REMARK"        )).trim(); // 79
					String stCN_ITEM_TYPE2              = ((String)partHM.get("CN_ITEM_TYPE2"               )).trim(); // 80
					String stCN_APPLY_PARTLIST          = ((String)partHM.get("CN_APPLY_PARTLIST"           )).trim(); // 81
//					String stCN_PREVIOUS_PART           = ((String)partHM.get("CN_PREVIOUS_PART"            )).trim(); // 82
					String stCN_COMPLEX_BODY            = ((String)partHM.get("CN_COMPLEX_BODY"             )).trim(); // 83
					String stCN_MAIN_PART_NUMBER        = ((String)partHM.get("CN_MAIN_PART_NUMBER"         )).trim(); // 84
					String stCN_VEHICLE_DESC            = ((String)partHM.get("CN_VEHICLE_DESC"             )).trim(); // 85 VEHICLE 
					String stCN_VEHICLE_CODE            = ((String)partHM.get("CN_VEHICLE_CODE"             )).trim(); // 86
					String stVehicle_Cust               = ((String)partHM.get("VEHICLE_CUST"                )).trim(); // 87
					String stCN_DRAWING_NO              = ((String)partHM.get("CN_DRAWING_NO"               )).trim(); // 88 DRAWING_NO
					String stCN_SUB_ID         		    = ((String)partHM.get("CN_SUB_ID"                   )).trim(); // 89
	//				//String stCN_CHANGE_REASON 	        = ((String)partHM.get("CN_CHANGE_REASON"            )).trim(); // 90 다른 데이타 파일로 진행 예정 
					String stCN_SURFACE_TREATMENT_KEYIN = ((String)partHM.get("CN_SURFACE_TREATMENT_KEYIN"  )).trim(); // 91
					String stCN_OVERSEAS_ORG6           = ((String)partHM.get("CN_OVERSEAS_ORG6"            )).trim(); // 92
					String stCN_OVERSEAS_ORG6_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG6_PART_TYPE"  )).trim(); // 93
					String stCN_OVERSEAS_ORG6_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG6_INOUT"      )).trim(); // 94
//					String stCN_OVERSEAS_ORG7           = ((String)partHM.get("CN_OVERSEAS_ORG7"            )).trim(); // 95
//					String stCN_OVERSEAS_ORG7_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG7_PART_TYPE"  )).trim(); // 96
//					String stCN_OVERSEAS_ORG7_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG7_INOUT"      )).trim(); // 97

					String stCN_Project_Id			    = ((String)partHM.get("CN_PROJECT_ID"  )).trim(); // 98
					String stAccessProductGroup		    = ((String)partHM.get("PROD_GROUP"  )).trim(); // 99
					String stAceesOrg				    = ((String)partHM.get("CN_CUST_VEHICLE"  )).trim(); // 100
					if("-".equals(stAceesOrg)){
						stAceesOrg = "";
					}
					String stCADWeight					= ""; 
					
					String stGLOBAL_LOCAL = "";
//					String stITEM_TYPE2 = "";
					String stFOR_DRAWING_REMARK = "";
					String stOPTION_ETC = stCN_OPTION_ETC;
					String stOPTION_DESC = stCN_OPTION_DESC;
					String stPartInvestor =   "";
					String stESTIMATED_WEIGHT = "";
					String stITEM_TYPE1 = "";
					String stITEM_TYPE = "";
					String stSERIES_ITEM = "";
					String stPhase = "";
					
					String stPartCADWeight = ""; /*아직 데이타가 없음 속성 정보 재요청 필요 */
					subPartCount = Integer.parseInt(stPartCount);
					tempStRowNum = stPartCount;
					tempStPartNo = stCN_ID;
					tempStPartRevision = stREVISION;
					String personIdMql = "temp query bus Person '" + stTDM_ORG_USER_ID + "' - select id dump |";
					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
					String stPerson = "";
					boolean boolPerson = false;
					if (stListPersonIdMql.size() > 2) {
						stPerson = (String) stListPersonIdMql.get(3);
						boolPerson = true;
					}
					
					
					/*  **************************************************************************************
					 *   stCLS_NAME 정보가 "Option Item" 이라면 CN_SUB_ID 정보를 CN_ID에 합쳐야한다. 
					 *  ************************************************************************************ */
					if("Option Item".equalsIgnoreCase(stCLS_NAME)){
						if(cdmStringUtil.isNotEmpty(stCN_SUB_ID)){
							stCN_ID +=stCN_SUB_ID;
						}
					}
					
					/* **************************************************************************************
					 * cdmPartGlobal 의 정보는 global,local 값이 없으면 ""  처리 
					 * ************************************************************************************* */
					for (int i = 0; i < attrPartGlobalKOList.size(); i++) {
	
						if (stCN_GLOBAL_LOCAL.equalsIgnoreCase((String) attrPartGlobalKOList.get(i))) {
							stGLOBAL_LOCAL = (String) attrPartGlobalList.get(i);
							break;
						}
					}
					if(cdmStringUtil.isEmpty(stGLOBAL_LOCAL)){
						stGLOBAL_LOCAL = "";
					}
					
					/*  **************************************************************************************
					 *   stCN_ITEM_TYPE2 의 정보는 
					 *   attribute[cdmPartItemType]관련 정보
					 *   
					 *   attribute[cdmPartItemType]의 display name과 일치하지않다면 에러 처리  
					 *  ************************************************************************************** */
//					boolean bITEM_TYPE2 = false;
//					for (int i = 0; i < attrPartItemTypeKOList.size(); i++) {
//	
//						if (stCN_ITEM_TYPE2.equals((String) attrPartItemTypeKOList.get(i))) {
//							stITEM_TYPE2 = (String) attrPartItemTypeList.get(i);
//							bITEM_TYPE2 = true;
//							break;
//						}
//						
//					}
					
					/* *****************************************************************************************
					 * stCN_FOR_DRAWING_REMARK 의 정보는 Part 의 한글 속성과 일치 
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					if(cdmStringUtil.isNotEmpty(stCN_FOR_DRAWING_REMARK) ){
						for (int i = 0; i < attrPartERPInterfaceKOList.size(); i++) {
	
							if (stCN_FOR_DRAWING_REMARK.equals((String) attrPartERPInterfaceKOList.get(i))) {
								stFOR_DRAWING_REMARK = (String) attrPartERPInterfaceList.get(i);
								break;
							}
						}
					}
					
					
					/* *****************************************************************************************
					 * CDM 의 UOM 과 전달받은 UOM 은 정보는 달라 기준정보 (MAP )로 찾아 데이타를 입력한다.
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					String sTempUOM = "";
					sTempUOM= (String)tempUOMHMap.get(stTDM_UOM);
					sTempUOM = cdmCommonExcel.isVaildNullData(sTempUOM);
					
					
					/* ******************************************************************************************************************
					 * stPartInvestor 의경우 
					 * stCN_FOR_MAC ,stCN_FOR_MIL,stCN_FOR_MMT 의 정보가 checked 되어 있는지여부를 확인하여 하나의 String 값으로 만듬 
					 * ****************************************************************************************************************   */
					if("Checked".equals(stCN_FOR_MAC)){
						stPartInvestor = "MAC";
					}
					if("Checked".equals(stCN_FOR_MIL)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MIL";
					}
					if("Checked".equals(stCN_FOR_MMT)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MMT";
					}
	
					
					/* ******************************************************************************************************************
					 *  attribute[cdmPartEstimateWeightUnit] 중량 단위 
					 *  넘어오는 데이타의 데이타가 없으면  attribute[cdmPartEstimateWeightUnit] 속성값은 G 로 입력된다 .
					 *  (넘어오는 데이타가 default 중량단위는 G )
					 * ****************************************************************************************************************** */
					String sTempWeightUnit = "";
					if("".equals(stCN_WEIGHT_UNIT)){
						sTempWeightUnit = "G";
					}else {
						//중량단위를 kg로 변환 !!
						if("g".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "G";
						}else if("lb".equals(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "LBR";
						}else if("mg".equals(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "MGR";
						}else if("ton".equals(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "MT";
						}else if("N".equals(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "N";
						}else if("kg".equals(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "KG";
						}
						
					}
						
					
					/* *************************************************************************************
					 *   stCN_ORG1 가 PROTO 이면 stPhase 값은 proto 
					 *   stCN_PHANTOM_ITEM 가 체크되어있으면 파트 타입으로 "Phantom Part"변경
					 *   stPhase 여부와 상관없이 반드시 Proto 로 변경된다. 
					 * *********************************************************************************** */
					if("PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPhase = S_ATTRIBUTE_PHASE_PROTO;
					}else{
						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
					}
					
					if( "Checked".equalsIgnoreCase(stCN_PHANTOM_ITEM) &&  "PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPartType = "cdmPhantomPart";
						stPhase = S_ATTRIBUTE_PHASE_PROTO; //변경요청
					}
					
					
					
					/* *************************************************************************************
					 * stITEM_TYPE1 은  cdmPartApprovalType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					if("자작".equals(stCN_ITEM_TYPE1)){
						stITEM_TYPE1 = "inSourcing";
					}else if("외주".equals(stCN_ITEM_TYPE1)){
						stITEM_TYPE1 = "outSourcing";
					}else{
						stITEM_TYPE1 = "";
					}
					
					
					
					/* *************************************************************************************
					 * stITEM_TYPE 은  cdmPartType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					stITEM_TYPE = "";
//					for (int attrPartTypeNum = 0; attrPartTypeNum < attrPartTypeKOList.size(); attrPartTypeNum++) {
//						String temPattrPartTypeKO = (String) attrPartTypeKOList.get(attrPartTypeNum);
//						if (stCN_ITEM_TYPE.equals(temPattrPartTypeKO)) {
//							stITEM_TYPE = (String) attrPartTypeList.get(attrPartTypeNum);
//							break;
//						}
//					}
					
					//
					if("단품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "singleSupply";
					}else if("완제품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "completeProduct";
					}else if("반제품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "halfFinishedProduct";
					}else if("원부자재".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "rawMaterial";
					}
					
					/* *************************************************************************************
					 * SERIES_ITEM 값이 Checked 이면 true unChecked 이면 false 
					 * *********************************************************************************** */
					if("Checked".equalsIgnoreCase(stCN_SERIES_ITEM)){
						stSERIES_ITEM = "true"; 
					}else{
						stSERIES_ITEM = "false";
					}
					
					/*stCN_SURFACE_TREATMENT 은 사용되지않아 "" 처리한다. */
					String stSURFACE_TREATMENT = ""; 
					
					/*stCN_IS_CASTING*/
					String stIS_CASTING = "";
					if(!"0".equals(stCN_IS_CASTING)){
						stIS_CASTING = "yes";
					}else{
						stIS_CASTING = "no";
					}
					
					
					/*stCN_FOR_DRAWING_FINISH*/
					String stCFOR_DRAWING_FINISH = "";
					if("0".equals(stCN_FOR_DRAWING_FINISH)){
						stCFOR_DRAWING_FINISH = "unChecked";
					}else{
						stCFOR_DRAWING_FINISH = "Checked";
					}
					
					/*stCN_FOR_DRAWING_SIZE*/
					String stDRAWING_SIZE = "";
					if("0".equals(stCN_FOR_DRAWING_SIZE)){
						stDRAWING_SIZE = "unChecked";
					}else{
						stDRAWING_SIZE = "Checked";
					}
					
					HashMap attributes = new HashMap();
//					if(UIUtil.isNotNullAndNotEmpty(stPhaseM)){
//						attributes.put("cdmPartPhaseM", 		 	  stPhaseM		                   );
//					}
//			        attributes.put("cdmPartNo",          	      stCN_ID 			               );
////			        attributes.put("cdmPartVehicle", 	 	      stCN_VEHICLE_DESC		           );
//			        attributes.put("cdmPartName", 		 	      stTDM_DESCRIPTION	               );
////			        attributes.put("cdmPartProject", 	 	      stCN_PROJECT		               );
//			        attributes.put("cdmPartApprovalType", 	      stITEM_TYPE1	                   );
//			        attributes.put("cdmPartType", 		          stITEM_TYPE	                   );
//			        attributes.put("cdmPartGlobal", 			  stGLOBAL_LOCAL                   );
//			        attributes.put("cdmPartDrawingNo", 			  stCN_DRAWING_NO                  );
////			        attributes.put("cdmPartUOM",     		      stTDM_UOM                        );
//			        attributes.put("cdmPartUOM",     		      sTempUOM                        );
////			        데이타가 깨진것이 있어 추후 cdmPartUOM 값을 변경해야함 12/06/16 12:19:00 이후 마이그레이션 대상으로
////			        attributes.put("cdmPartUOM_TempM",     		      stTDM_UOM                        );
//			        attributes.put("cdmPartECONumber", 			  stCN_ECO_NUMBER                  );
//			        attributes.put("cdmPartItemType", 			  stCN_ITEM_TYPE2                  );
//			        attributes.put("cdmPartOEMItemNumber", 		  stCN_OEM_PART_NUMBER             );
//			        attributes.put("cdmPartProductType", 		  stCN_PRODUCT_DIV                 );
//			        attributes.put("cdmPartERPInterface", 		  stFOR_DRAWING_REMARK             );
//			        attributes.put("cdmPartSurface", 			  stCN_SURFACE_AREA                );
////			        attributes.put("cdmPartEstimatedWeight", 	  stESTIMATED_WEIGHT               );
//			        attributes.put("cdmPartEstimatedWeight", 	  stCN_ESTIMATED_WEIGHT            );
//			        attributes.put("cdmPartMaterial", 			  stCN_ITEM_MATERIAL               );
//			        attributes.put("cdmPartRealWeight", 		  stCN_REAL_WEIGHT                 );
//			        attributes.put("cdmPartSize", 				  stCN_SIZE                        );
//			        attributes.put("cdmPartCADWeight", 			  stPartCADWeight                  );
//			        attributes.put("cdmPartSurfaceTreatment", 	  stSURFACE_TREATMENT              );
//			        attributes.put("cdmPartIsCasting", 			  stIS_CASTING                     );
//			        attributes.put("cdmPartOption1", 			  stCN_OPTION1                     );
//			        attributes.put("cdmPartOption2", 			  stCN_OPTION2                     );
//			        attributes.put("cdmPartOption3", 			  stCN_OPTION3                     );
//			        attributes.put("cdmPartOption4", 			  stCN_OPTION4                     );
//			        attributes.put("cdmPartOption5", 			  stCN_OPTION5                     );
//			        attributes.put("cdmPartOption6", 		   	  stCN_OPTION6                     );
//			        attributes.put("cdmPartOptionETC",         	  stOPTION_ETC               	   );
//			        attributes.put("cdmPartOptionDescription", 	  stOPTION_DESC            		   );
//			        attributes.put("cdmPartPublishingTarget",     stCN_COST                        );
//			        attributes.put("cdmPartInvestor",          	  stPartInvestor                   );
//			        attributes.put("cdmPartProjectType",          stCN_PRODUCT_GROUP               ); // 
//			        attributes.put("cdmPartProductDivision",      stCN_PRODUCT_GROUP               ); //?? 확인 작업이 필요 
					
			        /*migration을 작업을 위해 attribute 추가 start */
//			        attributes.put("cdmPartItemOtionItemM",        stCLS_NAME                      );
//			        attributes.put("cdmPartPreviousRevisionM",     stPAR_REVISION                  );
//			        attributes.put("cdmPartCheckPhantomPartM",     stCN_PHANTOM_ITEM   	           );
//			        attributes.put("cdmPartECNameM",               stEC_NAME    	               );
//			        attributes.put("cdmPartSeriesItemM",           stSERIES_ITEM                   );
//			        attributes.put("cdmPartMCAOrgM",               stCN_ORG      	               );
//			        attributes.put("cdmPartMCABOMManagementM",     stCN_MCA_INOUT        	       );
//			        attributes.put("cdmPartMCAPartTypeM",          stCN_MCA_PART_TYPE_REF          );
//			        attributes.put("cdmPartOption7",          	   stCN_OPTION7                    );
//			        attributes.put("cdmPartCountryM",          	   stCN_COUNTRY                    );
//			        attributes.put("cdmPartDrawingFinishM",        stCFOR_DRAWING_FINISH           );
//			        attributes.put("cdmPartDrawingSizeM",          stDRAWING_SIZE                  );
//			        attributes.put("cdmPartApplyPartListM",        stCN_APPLY_PARTLIST             );
//			        attributes.put("cdmPartSubIdM",                stCN_SUB_ID                     );
//			        attributes.put("cdmPartMCPOrgM",          	   stCN_OVERSEAS_ORG6              );
//			        attributes.put("cdmPartMCPPartTypeM",          stCN_OVERSEAS_ORG6_PART_TYPE    );
//			        attributes.put("cdmPartMCPBOMManagementM",     stCN_OVERSEAS_ORG6_INOUT 	   );  
//			        attributes.put("cdmPartCreationDateM",        stCREATION_DATE     	           );  
//			        attributes.put("cdmPartCreationUserIdM",      stUSER_OBJECT_ID  	           );  
//			        attributes.put("cdmPartModUserIdM",           stUSER_ID_MOD  	               );  
//			        attributes.put("cdmPartModificationDateM",    stMODIFICATION_DATE  	           );  
//			        attributes.put("cdmPartComplexBodyForRealWeightM",  stCN_COMPLEX_BODY          );
//			        attributes.put("cdmCheckMigration",           "Y"					  	       );
//			        attributes.put("cdmPartPhase",           	   stPhase			  	       	   );
//			        //add attribute 11/17/2016 start 
//			        attributes.put("cdmPartApplyPartList",           "true"				  	       );
//			        attributes.put("cdmPartApplySizeList",           "false"			  	       );
//			        attributes.put("cdmPartApplySurfaceTreatmentList", "false"	  				   );
//			        //add attribute 11/17/2016 end 
//			        attributes.put("cdmPartEstimateWeightUnit", sTempWeightUnit			   );
			        
			        /*migration을 작업을 위해 attribute 추가 end  */
			        
			      
			        /* **********************************************************************************************************************
			         * part 데이타 생성 및 데이타 
			         * 트리거 오프한 상태로 진행되며 트리거에서 제공되는 attribute[originator]속성 및 interface 추가 설정 필터 정보 와 
			         * rev 정보 part master 생성 및 연결 및 속성(attribute[Originator]속성 추가 
			         * 에러 발생시 정지 및 데이타 정보 검색 
			         * ******************************************************************************************************************* */
			        if(UIUtil.isNullOrEmpty(stCN_OPTION1) && UIUtil.isNullOrEmpty(stCN_OPTION2) && UIUtil.isNullOrEmpty(stCN_OPTION3) && UIUtil.isNullOrEmpty(stCN_OPTION3) && UIUtil.isNullOrEmpty(stCN_OPTION4) && UIUtil.isNullOrEmpty(stCN_OPTION5) && UIUtil.isNullOrEmpty(stCN_OPTION6)){
			        	continue;
			        	
			        }
			        DomainObject partObj = new DomainObject();
			        BusinessObject busPart = new BusinessObject(stPartType,stCN_ID,stREVISION,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        if(busPart.exists(context)){
			        	String partId = "";
			        	partId = busPart.getObjectId(context);
			        	partObj.setId(partId);
			        }else{
			        	throw new Exception("not exist part object .");
			        	
			        }
			        boolean bCommit = false;
//					partObj.createObject(context, stPartType, stCN_ID, stREVISION, cdmConstantsUtil.POLICY_CDM_PART_POLICY, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        ContextUtil.startTransaction(context, true);
			        bCommit = true;
					
					
			
			       	partObj.setAttributeValues(context, attributes);
					bCommit = true;
					ContextUtil.commitTransaction(context);		

					MqlUtil.mqlCommand(context, "trigger on");
					checkTriggerOff = false;	
						
					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
//						writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());	
						writeSuccessToFile(cdmCommonExcel.getTimeStamp() +"\t"+ subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+stCN_OPTION1 +"\t" +stCN_OPTION2 + "\t"+ stCN_OPTION3+"\t"+stCN_OPTION4+"\t"+stCN_OPTION5+"\t"+stCN_OPTION6+"\t"+sbErrorMessage.toString());	
					}else{
//							writeSuccessToFile("LineNum(#): "+subPartCount +" \t PartNo: \t "+tempStPartNo+" \t ");
//						writeSuccessToFile(cdmCommonExcel.getTimeStamp()+"\t"+subPartCount +"\t"+tempStPartNo+"\t"+stREVISION);
						writeSuccessToFile(cdmCommonExcel.getTimeStamp() +"\t"+ subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+stCN_OPTION1 +"\t" +stCN_OPTION2 + "\t"+ stCN_OPTION3+"\t"+stCN_OPTION4+"\t"+stCN_OPTION5+"\t"+stCN_OPTION6+"\t"+sbErrorMessage.toString());
							
					}
						
					successCount++;
						
				} catch (Exception e) {
					ContextUtil.abortTransaction(context);

//					if(!checkAddPart){
//						MQLCommand mqlCommand = new MQLCommand();
//						mqlCommand.open(context);
//						mqlCommand.executeCommand(context, "abort transaction $1","PartFamily");
//					}
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "trigger on");
						checkTriggerOff = false;			
					}
					failCount++;
					writeErrorToFile("LineNum(#) \t"+tempStRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t "+ tempStPartNo+"\t"+tempStPartRevision +"\t"+e.getMessage().replaceAll("\r|\n", "")); 
					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t" +  data ) ;
					e.printStackTrace(errorStream);
					
					writeShotErrorToFile("LineNum(#) \t"+tempStRowNum + " \t"+cdmCommonExcel.getTimeStamp2()+"\t "+tempStPartNo+"\t"+tempStPartRevision +"\t"+e.toString().replaceAll("\r|\n", ""));
				}finally{
					
				}
				
			} // end of while 
			
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================");
			//
		} catch (Exception e1) {
			writeFailToFile(" LineNum(#):"+tempStRowNum);
			writeErrorToFile("LineNum(#):"+tempStRowNum + "  "+e1.getMessage());
			e1.printStackTrace(errorStream);
			
			
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("	addOption PART OBJECT CLOSE TIME:  "+cdmCommonExcel.getTimeStamp2()+"          "  );
			writeMessageToConsole("	addOption PART OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+") TOTALCOUNT :("+totalCount+")"  );
			writeMessageToConsole("==================================================================================== \n");
			MqlUtil.mqlCommand(context, "history on");
			if(checkTriggerOff){
				MqlUtil.mqlCommand(context, "trigger on");
			}
			try {
				if (null != errorStream )
					errorStream .close();

				if (null != logWriter)
					logWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if(null != bufferReader)
					bufferReader.close();
				
				if(null != errorLogFile)
					errorLogFile.close();
				
				if(null != debugLogFile)
					debugLogFile.close();

				if(null != errorLogFile)
					errorLogFile.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			
			long endTime = System.currentTimeMillis();
			long leadTime = (endTime-startTime)/1000/60;
			System.out.println("cdmPartMigration : addOptionPart End.   endTime: "+cdmCommonExcel.getTimeStamp()  + " leadTime :"+leadTime);
			
		}
	
	
    
	
    	
    	
    	
    }
		
    
    /**
     * 
     * @param context
     * @param args
     * @throws Exception
     */
    public void secondExcutedCreatePart(Context context,String args[])throws Exception{




		long startTime = System.currentTimeMillis();
		System.out.println("cdmPartMigration : secondExcutedCreatePart -StartTime:"+cdmCommonExcel.getTimeStamp());
		String logFileName = "secondExcutedCreatePart";
		
	
		if(args.length!=1){
			throw new Exception("The excel path does not exist.");
		}
		String sFileLocationAndFileName = args[0];
		
		String sFileLocation 		= "";
		String sFileName 			= "";
		
		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
//		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
//		sFileLocation = (String)paramMap.get("File_Location");
//		sFileName = (String)paramMap.get("File");
		
		String sPartInputDirectory = sFileLocation;

		// documentDirectory does not ends with "/" add it
		if(sPartInputDirectory != null && !sPartInputDirectory.endsWith(sfileSeparator))
		{
			sPartInputDirectory = sPartInputDirectory + sfileSeparator;
		}
		String sPartOutputDirectory = "";
		// create a directory to add debug and error logs
		sPartOutputDirectory = new File(sPartInputDirectory).getParentFile() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+  sfileSeparator;
        File fileOutputDirectory = new File(sPartOutputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        
        String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		logFileName +="_"+sFileName.substring(0, sFileName.lastIndexOf("."))+"_"+formatTime;
		
        
		logWriter 			 	= new BufferedWriter(new FileWriter(sPartOutputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(sPartOutputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(sPartOutputDirectory + logFileName + "_SuccessLogs.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(sPartOutputDirectory + logFileName + "_FailedLogs" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		shortErrorLogFile        = new File(sPartOutputDirectory + logFileName + "ShortErrorLogs" + ".txt");
		shortErrorWriter         = new BufferedWriter(new FileWriter(shortErrorLogFile,true));
		
		String tempStRowNum   = ""; //순번
		String tempStPartNo   = ""; //엑셀의 PartNo
		String tempStPartRevision   = ""; //엑셀의 PartNo
		int totalCount = 0;
		int successCount = 0;
		int failCount = 0;
		boolean checkTriggerOff = false;
		BufferedReader bufferReader = null;
		writeSuccessToFile("CreateTime \t LineNume(#) \t  PartNo. \t Revision \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t  OPTION1 Wrong. \t OPTION2 Wrong. \t  OPTION3 Wrong. \t   OPTION4 Wrong. \t  OPTION5 Wrong. \t   OPTION6 Wrong. \t EC information does not exist. \t No Part Family exist. \t Part Connect \t Project Group \t Org  \t attributes ");
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole(" RE Create PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
		writeMessageToConsole("	Reading input log file from : "+sPartInputDirectory+sFileName);
		writeMessageToConsole("	Writing Log files to: " + sPartInputDirectory );
		writeMessageToConsole("====================================================================================\n");
		boolean checkAddPart = false;
		MqlUtil.mqlCommand(context, "history off");
		try {
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(sPartInputDirectory+sFileName),"euc-kr"));
			String data = "";  							// 텍스트 파일 라인정보담을 변수 
			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
			
			/* cdmCommonCode lev2 object 검색 start  */
			
			// 12/2 start 
			Map option1Map = getOptionCode(context,"Option1");
			Map option2Map = getOptionCode(context,"Option2");
			Map option3Map = getOptionCode(context,"Option3");
			Map option4Map = getOptionCode(context,"Option4");
			Map option5Map = getOptionCode(context,"Option5");
			Map option6Map = getOptionCode(context,"Option6");
			
			Map vehicleCommonCodeMap = getVehicleCode(context,"Vehicle");
			Map productGroupMap      = getProductGroupCode(context,"Product Group Name");
			Map productDivMap        = getProductDivCode(context,"Product Div");
			Map projectMap           = getProjectCode(context,"cdmProjectGroupObject");
//			Map partFamilyMap        = getPartFamilyId(context);
			Map partFamilyMap        = getPartFamilyId2(context,"Global R&D:Global R&D"); //top part family[cdmPartFamilyBlockCodeName]
			
			/*cdmCommonCode lev2 object 검색 end */ 
			
			String strLanguage = context.getLocale().getLanguage();
			
			AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
			attrPartGlobal.open(context);
			StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
			attrPartGlobal.close(context);
			StringList attrPartGlobalKOList = new StringList();
			attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
			
			
			AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
			attrPartItemType.open(context);
			StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
			attrPartItemType.close(context);
			StringList attrPartItemTypeKOList = new StringList();
			attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
			
			
			AttributeType attrPartERPInterface = new AttributeType("cdmPartERPInterface");
			attrPartERPInterface.open(context);
			StringList attrPartERPInterfaceList = attrPartERPInterface.getChoices(context);
			attrPartERPInterface.close(context);
			StringList attrPartERPInterfaceKOList = new StringList();
			attrPartERPInterfaceKOList = i18nNow.getAttrRangeI18NStringList("cdmPartERPInterface", attrPartERPInterfaceList, strLanguage);
			
			AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
			attrPartType.open(context);
			StringList attrPartTypeList = attrPartType.getChoices(context);
			attrPartType.close(context);
			StringList attrPartTypeKOList = new StringList();
			attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
			
			HashMap tempUOMHMap = new HashMap();
			tempUOMHMap.put("EA"  , "Each");
			tempUOMHMap.put("BAG" , "bag");
			tempUOMHMap.put("BTL" , "bottle");
			tempUOMHMap.put("BOX" , "box");
			tempUOMHMap.put("CC"  , "cc");
			tempUOMHMap.put("CMM" , "mm³");
			tempUOMHMap.put("CMT" , "m³");
			tempUOMHMap.put("CN"  , "can");
			tempUOMHMap.put("CT"  , "carton");
			tempUOMHMap.put("DL"  , "dl");
			tempUOMHMap.put("DZ"  , "dozen");
			tempUOMHMap.put("FT"  , "ft");
			tempUOMHMap.put("GLL" , "gallon");
			tempUOMHMap.put("G"   , "g");
			tempUOMHMap.put("IN"  , "inch");
			tempUOMHMap.put("KG"  , "kg");
			tempUOMHMap.put("KMT" , "km");
			tempUOMHMap.put("L"   , "L");
			tempUOMHMap.put("LBR" , "lb");
			tempUOMHMap.put("M"   , "m");
			tempUOMHMap.put("MGR" , "mg");
			tempUOMHMap.put("ML"  , "ml");
			tempUOMHMap.put("MMT" , "mm");
			tempUOMHMap.put("MT"  , "ton");
			tempUOMHMap.put("N"   , "N");
			tempUOMHMap.put("PC"  , "Piece");
			tempUOMHMap.put("PL"  , "Pl");
			tempUOMHMap.put("ROL" , "Roll");
			tempUOMHMap.put("SET" , "Set");
			tempUOMHMap.put("SH"  , "Sheet");
			tempUOMHMap.put("SM"  , "m²");
			tempUOMHMap.put("UN"  , "unit");
			tempUOMHMap.put("DRM" , "drum");
			
			int lineNumber = 1;      
			int subPartCount = 0;
			
			String strPreviousPartNo = null;
			String strPreviousPartRevision = null;
			String strPreviousPartType = null;
			
			
			while ((data = bufferReader.readLine()) != null) {
				
				StringBuffer sbErrorMessage = new StringBuffer("");
				MqlUtil.mqlCommand(context, "trigger off");
				checkTriggerOff = true;
				checkAddPart = false;
				StringList stListData = FrameworkUtil.split(data, "\t");
				try {
					
					if (lineNumber == 1) {
						stListHeader = stListData;
						writeFailToFile("errorRecord \t"+data);
						lineNumber++;
						continue;
					}
					lineNumber++;
					totalCount++;
					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
					int size_Data = stListData.size();
					int size_Header = stListHeader.size();
					if (size_Data != size_Header) {
						String errorMessage = " NOT MATCH DATA FIELD";
						throw new Exception(errorMessage);
					}

					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {

						String sPartInfos = cdmCommonExcel.isVaildNullData((String)stListData.get(stListNum));
						String sPartHeader = ((String) stListHeader.get(stListNum)).trim();
						partHM.put(sPartHeader, sPartInfos);
						
					}
					
					String stPartType                   = TYPE_CDMMECHANICALPART;  
					String stPartCount                  = ((String)partHM.get("#"            		        )).trim(); // 1 순번 
					String stCLS_NAME                   = ((String)partHM.get("CLS_NAME"                    )).trim(); // 2 
					String stOBJECT_ID                  = ((String)partHM.get("OBJECT_ID"                   )).trim(); // 3 //받은 자료에 unique 값 migration대상아님 
	
					String stCN_ID                      = ((String)partHM.get("CN_ID"  	                    )).trim(); // 5 Name
					String stREVISION                   = ((String)partHM.get("REVISION"                    )).trim(); // 6 Revision
					String stSTATE                      = ((String)partHM.get("STATE"                       )).trim(); // 7 State
					String stCREATION_DATE              = ((String)partHM.get("CREATION_DATE"               )).trim(); // 8  attribute[cdmPartCreationDateM]
					String stUSER_OBJECT_ID             = ((String)partHM.get("USER_OBJECT_ID"              )).trim(); // 9  attribute[cdmPartCreationUserIdM]
					String stUSER_ID_MOD                = ((String)partHM.get("USER_ID_MOD"                 )).trim(); // 10 attribute[cdmPartModUserIdM]
					String stMODIFICATION_DATE          = ((String)partHM.get("MODIFICATION_DATE"           )).trim(); // 11 attribute[cdmPartModificationDateM] 
					String stTDM_DESCRIPTION            = ((String)partHM.get("TDM_DESCRIPTION"             )).trim(); // 12 attribute[cdmPartName]
					String stTDM_UOM                    = ((String)partHM.get("TDM_UOM"  			        )).trim(); // 13 attribute[cdmPartUOM]
					String stPhaseM                     = ((String)partHM.get("PHASE"                       )).trim(); // 14 
					String stPAR_REVISION               = ((String)partHM.get("PAR_REVISION"                )).trim(); // 15 Previous Revision
	//				String stAPPROVAL_DATE              = ((String)partHM.get("APPROVAL_DATE"               )).trim(); // 16 
	//				String stREVISION_STG               = ((String)partHM.get("REVISION_STG"                )).trim(); // 17 
					String stTDM_ORG_USER_ID            = ((String)partHM.get("TDM_ORG_USER_ID"             )).trim(); // 18 First Revision creator
	//				String stTDM_ORG_CREATEDATE         = ((String)partHM.get("TDM_ORG_CREATEDATE"          )).trim(); // 19 
	//				String stTDM_APPROVED_BY            = ((String)partHM.get("TDM_APPROVED_BY"             )).trim(); // 20 
	//				String stTDM_ORIGIN_ID              = ((String)partHM.get("TDM_ORIGIN_ID"               )).trim(); // 21 
					String stCN_PROJECT                 = ((String)partHM.get("CN_PROJECT"                  )).trim(); // 22 PROJECT
					String stCN_PROJECT_CUST            = ((String)partHM.get("CN_PROJECT_CUST"             )).trim(); // 23 PROJECT_CUST
	//				String stCN_PRODUCT_NAME            = ((String)partHM.get("CN_PRODUCT_NAME"             )).trim(); // 24 
	//				String stCN_PART_GROUP              = ((String)partHM.get("CN_PART_GROUP"               )).trim(); // 25 
	//				String stCN_PART_NAME               = ((String)partHM.get("CN_PART_NAME"                )).trim(); // 26
	//				String stCN_WEIGHT                  = ((String)partHM.get("CN_WEIGHT"                   )).trim(); // 27
					String stCN_ESTIMATED_WEIGHT        = ((String)partHM.get("CN_ESTIMATED_WEIGHT"         )).trim(); // 28 attribute[cdmPartEstimatedWeight] 
					String stCN_WEIGHT_UNIT             = ((String)partHM.get("CN_WEIGHT_UNIT"              )).trim(); // 29
					String stCN_TOP_ITEM                = ((String)partHM.get("CN_TOP_ITEM"                 )).trim(); // 30
					String stCN_PHANTOM_ITEM            = ((String)partHM.get("CN_PHANTOM_ITEM"             )).trim(); // 31
					String stCN_ITEM_TYPE               = ((String)partHM.get("CN_ITEM_TYPE"                )).trim(); // 32
					String stCN_SERVICE_ITEM            = ((String)partHM.get("CN_SERVICE_ITEM"             )).trim(); // 33
					String stCN_ITEM_MATERIAL           = ((String)partHM.get("CN_ITEM_MATERIAL"            )).trim(); // 34
					String stCN_ITEM_UPDATE_FROM_ERP    = ((String)partHM.get("CN_ITEM_UPDATE_FROM_ERP"     )).trim(); // 35
					String stCN_COST                    = ((String)partHM.get("CN_COST"                     )).trim(); // 36
					String stCN_CURRENCY                = ((String)partHM.get("CN_CURRENCY"                 )).trim(); // 37
					//String stCN_COMMENTS              = ((String)partHM.get("CN_COMMENTS"                 )).trim(); // 38
					String stCN_OEM_PART_NUMBER         = ((String)partHM.get("CN_OEM_PART_NUMBER"          )).trim(); // 39
					String stEC_NAME                    = ((String)partHM.get("EC_NAME"                     )).trim(); // 40
					String stCN_ECO_NUMBER              = ((String)partHM.get("CN_ECO_NUMBER"               )).trim(); // 41
					String stCN_PRODUCT_GROUP           = ((String)partHM.get("CN_PRODUCT_GROUP"            )).trim(); // 42
					String stCN_SERIES_ITEM             = ((String)partHM.get("CN_SERIES_ITEM"              )).trim(); // 43
					String stCN_VEHICLE                 = ((String)partHM.get("CN_VEHICLE"                  )).trim(); // 44
					String stCN_CUSTOMER                = ((String)partHM.get("CN_CUSTOMER"                 )).trim(); // 45
					String stCN_SIZE                    = ((String)partHM.get("CN_SIZE"                     )).trim(); // 46
					String stCN_SURFACE_TREATMENT       = ((String)partHM.get("CN_SURFACE_TREATMENT"        )).trim(); // 47
					String stCN_SURFACE_AREA            = ((String)partHM.get("CN_SURFACE_AREA"             )).trim(); // 48
					String stCN_ITEM_TYPE1              = ((String)partHM.get("CN_ITEM_TYPE1"               )).trim(); // 49
					String stCN_MATERIAL               = ((String)partHM.get("CN_MATERIAL"                  )).trim(); // 50
					String stCN_ORG1                   = ((String)partHM.get("CN_ORG1"                      )).trim(); // 51  migration 대상 제외  
	//				String stCN_ORG2                   = ((String)partHM.get("CN_ORG2"                      )).trim(); // 52  migration 대상 제외 
	//				String stCN_ORG3                   = ((String)partHM.get("CN_ORG3"                      )).trim(); // 53  migration 대상 제외 
					String stCN_ORG                    = ((String)partHM.get("CN_ORG"                       )).trim(); // 54  MCA Org
					String stCN_MCA_INOUT              = ((String)partHM.get("CN_MCA_INOUT"                 )).trim(); // 55  MCA BOM Management
					String stCN_MCA_PART_TYPE_REF      = ((String)partHM.get("CN_MCA_PART_TYPE_REF"         )).trim(); // 56  MCA Part Type
					String stCN_OPTION1                = ((String)partHM.get("CN_OPTION1"                   )).trim(); // 57
					String stCN_OPTION2                = ((String)partHM.get("CN_OPTION2"                   )).trim(); // 58
					String stCN_OPTION3                = ((String)partHM.get("CN_OPTION3"                   )).trim(); // 59
					String stCN_OPTION4                = ((String)partHM.get("CN_OPTION4"                   )).trim(); // 60
					String stCN_OPTION5                = ((String)partHM.get("CN_OPTION5"                   )).trim(); // 61
					String stCN_OPTION6                = ((String)partHM.get("CN_OPTION6"                   )).trim(); // 62
					String stCN_OPTION7                = ((String)partHM.get("CN_OPTION7"                   )).trim(); // 63
					String stCN_OPTION_ETC             = ((String)partHM.get("CN_OPTION_ETC"                )).trim(); // 64
					String stCN_IS_CASTING             = ((String)partHM.get("CN_IS_CASTING"                )).trim(); // 65
					String stCN_OPTION_DESC            = ((String)partHM.get("CN_OPTION_DESC"               )).trim(); // 66
					String stCN_FOR_MAC                = ((String)partHM.get("CN_FOR_MAC"                   )).trim(); // 67
					String stCN_FOR_MIL                = ((String)partHM.get("CN_FOR_MIL"                   )).trim(); // 68
					String stCN_FOR_MIS                = ((String)partHM.get("CN_FOR_MIS"                   )).trim(); // 69
					String stCN_FOR_MMT                = ((String)partHM.get("CN_FOR_MMT"                   )).trim(); // 70
					String stCN_REAL_WEIGHT            = ((String)partHM.get("CN_REAL_WEIGHT"               )).trim(); // 71
					String stCN_COUNTRY                = ((String)partHM.get("CN_COUNTRY"                   )).trim(); // 72
					String stCN_PRODUCT_DIV            = ((String)partHM.get("CN_PRODUCT_DIV"               )).trim(); // 73
					String stCN_GLOBAL_LOCAL           = ((String)partHM.get("CN_GLOBAL_LOCAL"              )).trim(); // 74
					String stCN_PROJECT_CODE           = ((String)partHM.get("CN_PROJECT_CODE"              )).trim(); // 75
					String stCN_OPTION_DRAWING         = ((String)partHM.get("CN_OPTION_DRAWING"            )).trim(); // 76
					String stCN_FOR_DRAWING_FINISH     = ((String)partHM.get("CN_FOR_DRAWING_FINISH"        )).trim(); // 77
					String stCN_FOR_DRAWING_SIZE       = ((String)partHM.get("CN_FOR_DRAWING_SIZE"          )).trim(); // 78
					String stCN_FOR_DRAWING_REMARK     = ((String)partHM.get("CN_FOR_DRAWING_REMARK"        )).trim(); // 79
					String stCN_ITEM_TYPE2              = ((String)partHM.get("CN_ITEM_TYPE2"               )).trim(); // 80
					String stCN_APPLY_PARTLIST          = ((String)partHM.get("CN_APPLY_PARTLIST"           )).trim(); // 81
//					String stCN_PREVIOUS_PART           = ((String)partHM.get("CN_PREVIOUS_PART"            )).trim(); // 82
					String stCN_COMPLEX_BODY            = ((String)partHM.get("CN_COMPLEX_BODY"             )).trim(); // 83
					String stCN_MAIN_PART_NUMBER        = ((String)partHM.get("CN_MAIN_PART_NUMBER"         )).trim(); // 84
					String stCN_VEHICLE_DESC            = ((String)partHM.get("CN_VEHICLE_DESC"             )).trim(); // 85 VEHICLE 
					String stCN_VEHICLE_CODE            = ((String)partHM.get("CN_VEHICLE_CODE"             )).trim(); // 86
					String stVehicle_Cust               = ((String)partHM.get("VEHICLE_CUST"                )).trim(); // 87
					String stCN_DRAWING_NO              = ((String)partHM.get("CN_DRAWING_NO"               )).trim(); // 88 DRAWING_NO
					String stCN_SUB_ID         		    = ((String)partHM.get("CN_SUB_ID"                   )).trim(); // 89
	//				//String stCN_CHANGE_REASON 	        = ((String)partHM.get("CN_CHANGE_REASON"            )).trim(); // 90 다른 데이타 파일로 진행 예정 
					String stCN_SURFACE_TREATMENT_KEYIN = ((String)partHM.get("CN_SURFACE_TREATMENT_KEYIN"  )).trim(); // 91
					String stCN_OVERSEAS_ORG6           = ((String)partHM.get("CN_OVERSEAS_ORG6"            )).trim(); // 92
					String stCN_OVERSEAS_ORG6_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG6_PART_TYPE"  )).trim(); // 93
					String stCN_OVERSEAS_ORG6_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG6_INOUT"      )).trim(); // 94
//					String stCN_OVERSEAS_ORG7           = ((String)partHM.get("CN_OVERSEAS_ORG7"            )).trim(); // 95
//					String stCN_OVERSEAS_ORG7_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG7_PART_TYPE"  )).trim(); // 96
//					String stCN_OVERSEAS_ORG7_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG7_INOUT"      )).trim(); // 97

					String stCN_Project_Id			    = ((String)partHM.get("CN_PROJECT_ID"  )).trim(); // 98
					String stAccessProductGroup		    = ((String)partHM.get("PROD_GROUP"  )).trim(); // 99
					String stAceesOrg				    = ((String)partHM.get("CN_CUST_VEHICLE"  )).trim(); // 100
					
					
					if("-".equals(stAceesOrg)){
						stAceesOrg = "";
					}
					String stCADWeight					= ""; 
					
					String stGLOBAL_LOCAL = "";
//					String stITEM_TYPE2 = "";
					String stFOR_DRAWING_REMARK = "";
					String stOPTION_ETC = stCN_OPTION_ETC;
					String stOPTION_DESC = stCN_OPTION_DESC;
					String stPartInvestor =   "";
					String stESTIMATED_WEIGHT = "";
					String stITEM_TYPE1 = "";
					String stITEM_TYPE = "";
					String stSERIES_ITEM = "";
					String stPhase = "";
					
					String stPartCADWeight = ""; /*아직 데이타가 없음 속성 정보 재요청 필요 */
					subPartCount = Integer.parseInt(stPartCount);
					tempStRowNum = stPartCount;
					tempStPartNo = stCN_ID;
					tempStPartRevision = stREVISION;
					String personIdMql = "temp query bus Person '" + stTDM_ORG_USER_ID + "' - select id dump |";
					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
					String stPerson = "";
					boolean boolPerson = false;
					if (stListPersonIdMql.size() > 2) {
						stPerson = (String) stListPersonIdMql.get(3);
						boolPerson = true;
					}
					
					
					/*  **************************************************************************************
					 *   stCLS_NAME 정보가 "Option Item" 이라면 CN_SUB_ID 정보를 CN_ID에 합쳐야한다. 
					 *  ************************************************************************************ */
					if("Option Item".equalsIgnoreCase(stCLS_NAME)){
						if(cdmStringUtil.isNotEmpty(stCN_SUB_ID)){
							stCN_ID +=stCN_SUB_ID;
						}
					}
					
					/* **************************************************************************************
					 * cdmPartGlobal 의 정보는 global,local 값이 없으면 ""  처리 
					 * ************************************************************************************* */
					for (int i = 0; i < attrPartGlobalKOList.size(); i++) {
	
						if (stCN_GLOBAL_LOCAL.equalsIgnoreCase((String) attrPartGlobalKOList.get(i))) {
							stGLOBAL_LOCAL = (String) attrPartGlobalList.get(i);
							break;
						}
					}
					if(cdmStringUtil.isEmpty(stGLOBAL_LOCAL)){
						stGLOBAL_LOCAL = "";
					}
					
					/*  **************************************************************************************
					 *   stCN_ITEM_TYPE2 의 정보는 
					 *   attribute[cdmPartItemType]관련 정보
					 *   
					 *   attribute[cdmPartItemType]의 display name과 일치하지않다면 에러 처리  
					 *  ************************************************************************************** */
//					boolean bITEM_TYPE2 = false;
//					for (int i = 0; i < attrPartItemTypeKOList.size(); i++) {
//	
//						if (stCN_ITEM_TYPE2.equals((String) attrPartItemTypeKOList.get(i))) {
//							stITEM_TYPE2 = (String) attrPartItemTypeList.get(i);
//							bITEM_TYPE2 = true;
//							break;
//						}
//						
//					}
					
					/* *****************************************************************************************
					 * stCN_FOR_DRAWING_REMARK 의 정보는 Part 의 한글 속성과 일치 
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					if(cdmStringUtil.isNotEmpty(stCN_FOR_DRAWING_REMARK) ){
						for (int i = 0; i < attrPartERPInterfaceKOList.size(); i++) {
	
							if (stCN_FOR_DRAWING_REMARK.equals((String) attrPartERPInterfaceKOList.get(i))) {
								stFOR_DRAWING_REMARK = (String) attrPartERPInterfaceList.get(i);
								break;
							}
						}
					}
					
					
					/* *****************************************************************************************
					 * CDM 의 UOM 과 전달받은 UOM 은 정보는 달라 기준정보 (MAP )로 찾아 데이타를 입력한다.
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					String sTempUOM = "";
					sTempUOM= (String)tempUOMHMap.get(stTDM_UOM);
					sTempUOM = cdmCommonExcel.isVaildNullData(sTempUOM);
					
					
					/* ******************************************************************************************************************
					 * stPartInvestor 의경우 
					 * stCN_FOR_MAC ,stCN_FOR_MIL,stCN_FOR_MMT 의 정보가 checked 되어 있는지여부를 확인하여 하나의 String 값으로 만듬 
					 * ****************************************************************************************************************   */
					if("Checked".equals(stCN_FOR_MAC)){
						stPartInvestor = "MAC";
					}
					if("Checked".equals(stCN_FOR_MIL)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MIL";
					}
					if("Checked".equals(stCN_FOR_MMT)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MMT";
					}
	
					
					/* ******************************************************************************************************************
					 *  attribute[cdmPartEstimateWeightUnit] 중량 단위 
					 *  넘어오는 데이타의 데이타가 없으면  attribute[cdmPartEstimateWeightUnit] 속성값은 G 로 입력된다 .
					 *  (넘어오는 데이타가 default 중량단위는 G )
					 * ****************************************************************************************************************** */
					String sTempWeightUnit = "";
					if("".equals(stCN_WEIGHT_UNIT)){
						sTempWeightUnit = "G";
					}else {
						//중량단위를 kg로 변환 !!
						if("g".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "G";
						}else if("lb".equals(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "LBR";
						}else if("mg".equals(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "MGR";
						}else if("ton".equals(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "MT";
						}else if("N".equals(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "N";
						}else if("kg".equals(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "KG";
						}
						
					}
						
					
					/* *************************************************************************************
					 *   stCN_ORG1 가 PROTO 이면 stPhase 값은 proto 
					 *   stCN_PHANTOM_ITEM 가 체크되어있으면 파트 타입으로 "Phantom Part"변경
					 *   stPhase 여부와 상관없이 반드시 Proto 로 변경된다. 
					 * *********************************************************************************** */
					if("PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPhase = S_ATTRIBUTE_PHASE_PROTO;
					}else{
						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
					}
					
					if( "Checked".equalsIgnoreCase(stCN_PHANTOM_ITEM) &&  "PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPartType = "cdmPhantomPart";
						stPhase = S_ATTRIBUTE_PHASE_PROTO; //변경요청
					}
					
					
					
					  /* **********************************************************************************************************************
			         * type은 pre revision 정보가 있으며 그정보 의 object 가 phantom part 타입이면 생성할 object 타입도 phantom part 타입으로
			         * 변경  
			         *    
			         * ******************************************************************************************************************** */
//					if(cdmStringUtil.isNotEmpty(stPAR_REVISION)) {
//						 String stPreRevisionPhantomMql = "temp query bus '"+ TYPE_PHANTOMPART +"' '" +stCN_ID +"' '"+stPAR_REVISION+"'  select id  dump |";
//						 String stPreRevisionPhantomMqlResult =  MqlUtil.mqlCommand(context, stPreRevisionPhantomMql);
//						 StringList stListPreRevisionPhantomMqlResult = FrameworkUtil.split(stPreRevisionPhantomMqlResult, "|");
//						 
//						 if(stListPreRevisionPhantomMqlResult.size() > 2){
//							 stPartType = TYPE_PHANTOMPART;
//						 }
//					}
					
					
					
					/* ***************************************************************************************
				     *	데이타 중복확인 
					 * *************************************************************************************** */
					String duplicationPart = MqlUtil.mqlCommand(context, "temp query bus \""+stPartType+"\" \""+ stCN_ID+"\"  \""+ stREVISION +"\"  dump ");
					if(cdmStringUtil.isNotEmpty(duplicationPart)){
						String errorMessage = "ALREADY PART OBJECT ";
						throw new Exception(errorMessage);
					}
					
					/* *************************************************************************************
					 * stITEM_TYPE1 은  cdmPartApprovalType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					
					
					if("자작".equals(stCN_ITEM_TYPE1)){
						stITEM_TYPE1 = "inSourcing";
					}else if("외주".equals(stCN_ITEM_TYPE1)){
						stITEM_TYPE1 = "outSourcing";
					}else{
						stITEM_TYPE1 = "";
					}
					
					
					
					/* *************************************************************************************
					 * stITEM_TYPE 은  cdmPartType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					stITEM_TYPE = "";
//					for (int attrPartTypeNum = 0; attrPartTypeNum < attrPartTypeKOList.size(); attrPartTypeNum++) {
//						String temPattrPartTypeKO = (String) attrPartTypeKOList.get(attrPartTypeNum);
//						if (stCN_ITEM_TYPE.equals(temPattrPartTypeKO)) {
//							stITEM_TYPE = (String) attrPartTypeList.get(attrPartTypeNum);
//							break;
//						}
//					}
					
					//
					if("단품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "singleSupply";
					}else if("완제품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "completeProduct";
					}else if("반제품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "halfFinishedProduct";
					}else if("원부자재".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "rawMaterial";
					}
					//
//					if(stCN_ITEM_TYPE == null || "".equals(stCN_ITEM_TYPE) ){
//						stITEM_TYPE = "";
//					} else {
	
//						AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
//						attrPartType.open(context);
//						StringList attrPartTypeList = attrPartType.getChoices(context);
//	
//						StringList attrPartTypeKOList = new StringList();
//						attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
	
						
//					}
	
					
					/* *************************************************************************************
					 * SERIES_ITEM 값이 Checked 이면 true unChecked 이면 false 
					 * *********************************************************************************** */
					if("Checked".equalsIgnoreCase(stCN_SERIES_ITEM)){
						stSERIES_ITEM = "true"; 
					}else{
						stSERIES_ITEM = "false";
					}
					
					/*stCN_SURFACE_TREATMENT 은 사용되지않아 "" 처리한다. */
					String stSURFACE_TREATMENT = ""; 
					
					/*stCN_IS_CASTING*/
					String stIS_CASTING = "";
					if(!"0".equals(stCN_IS_CASTING)){
						stIS_CASTING = "yes";
					}else{
						stIS_CASTING = "no";
					}
					
					
					/*stCN_FOR_DRAWING_FINISH*/
					String stCFOR_DRAWING_FINISH = "";
					if("0".equals(stCN_FOR_DRAWING_FINISH)){
						stCFOR_DRAWING_FINISH = "unChecked";
					}else{
						stCFOR_DRAWING_FINISH = "Checked";
					}
					
					/*stCN_FOR_DRAWING_SIZE*/
					String stDRAWING_SIZE = "";
					if("0".equals(stCN_FOR_DRAWING_SIZE)){
						stDRAWING_SIZE = "unChecked";
					}else{
						stDRAWING_SIZE = "Checked";
					}
					
					HashMap attributes = new HashMap();
					if(UIUtil.isNotNullAndNotEmpty(stPhaseM)){
						attributes.put("cdmPartPhaseM", 		 	  stPhaseM		                   );
					}
			        attributes.put("cdmPartNo",          	      stCN_ID 			               );
//			        attributes.put("cdmPartVehicle", 	 	      stCN_VEHICLE_DESC		           );
			        attributes.put("cdmPartName", 		 	      stTDM_DESCRIPTION	               );
//			        attributes.put("cdmPartProject", 	 	      stCN_PROJECT		               );
			        attributes.put("cdmPartApprovalType", 	      stITEM_TYPE1	                   );
			        attributes.put("cdmPartType", 		          stITEM_TYPE	                   );
			        attributes.put("cdmPartGlobal", 			  stGLOBAL_LOCAL                   );
			        attributes.put("cdmPartDrawingNo", 			  stCN_DRAWING_NO                  );
//			        attributes.put("cdmPartUOM",     		      stTDM_UOM                        );
			        attributes.put("cdmPartUOM",     		      sTempUOM                        );
//			        데이타가 깨진것이 있어 추후 cdmPartUOM 값을 변경해야함 12/06/16 12:19:00 이후 마이그레이션 대상으로
//			        attributes.put("cdmPartUOM_TempM",     		      stTDM_UOM                        );
			        attributes.put("cdmPartECONumber", 			  stCN_ECO_NUMBER                  );
			        attributes.put("cdmPartItemType", 			  stCN_ITEM_TYPE2                  );
			        attributes.put("cdmPartOEMItemNumber", 		  stCN_OEM_PART_NUMBER             );
			        attributes.put("cdmPartProductType", 		  stCN_PRODUCT_DIV                 );
			        attributes.put("cdmPartERPInterface", 		  stFOR_DRAWING_REMARK             );
			        attributes.put("cdmPartSurface", 			  stCN_SURFACE_AREA                );
//			        attributes.put("cdmPartEstimatedWeight", 	  stESTIMATED_WEIGHT               );
			        attributes.put("cdmPartEstimatedWeight", 	  stCN_ESTIMATED_WEIGHT            );
			        attributes.put("cdmPartMaterial", 			  stCN_ITEM_MATERIAL               );
			        attributes.put("cdmPartRealWeight", 		  stCN_REAL_WEIGHT                 );
			        attributes.put("cdmPartSize", 				  stCN_SIZE                        );
			        attributes.put("cdmPartCADWeight", 			  stPartCADWeight                  );
			        attributes.put("cdmPartSurfaceTreatment", 	  stSURFACE_TREATMENT              );
			        attributes.put("cdmPartIsCasting", 			  stIS_CASTING                     );
//			        attributes.put("cdmPartOption1", 			  stCN_OPTION1                     );
//			        attributes.put("cdmPartOption2", 			  stCN_OPTION2                     );
//			        attributes.put("cdmPartOption3", 			  stCN_OPTION3                     );
//			        attributes.put("cdmPartOption4", 			  stCN_OPTION4                     );
//			        attributes.put("cdmPartOption5", 			  stCN_OPTION5                     );
//			        attributes.put("cdmPartOption6", 		   	  stCN_OPTION6                     );
			        attributes.put("cdmPartOptionETC",         	  stOPTION_ETC               	   );
			        attributes.put("cdmPartOptionDescription", 	  stOPTION_DESC            		   );
			        attributes.put("cdmPartPublishingTarget",     stCN_COST                        );
			        attributes.put("cdmPartInvestor",          	  stPartInvestor                   );
//			        attributes.put("cdmPartProjectType",          stCN_PRODUCT_GROUP               ); // 
//			        attributes.put("cdmPartProductDivision",      stCN_PRODUCT_GROUP               ); //?? 확인 작업이 필요 
					
			        /*migration을 작업을 위해 attribute 추가 start */
			        attributes.put("cdmPartItemOtionItemM",        stCLS_NAME                      );
			        attributes.put("cdmPartPreviousRevisionM",     stPAR_REVISION                  );
			        attributes.put("cdmPartCheckPhantomPartM",     stCN_PHANTOM_ITEM   	           );
			        attributes.put("cdmPartECNameM",               stEC_NAME    	               );
			        attributes.put("cdmPartSeriesItemM",           stSERIES_ITEM                   );
			        attributes.put("cdmPartMCAOrgM",               stCN_ORG      	               );
			        attributes.put("cdmPartMCABOMManagementM",     stCN_MCA_INOUT        	       );
			        attributes.put("cdmPartMCAPartTypeM",          stCN_MCA_PART_TYPE_REF          );
			        attributes.put("cdmPartOption7",          	   stCN_OPTION7                    );
			        attributes.put("cdmPartCountryM",          	   stCN_COUNTRY                    );
			        attributes.put("cdmPartDrawingFinishM",        stCFOR_DRAWING_FINISH           );
			        attributes.put("cdmPartDrawingSizeM",          stDRAWING_SIZE                  );
			        attributes.put("cdmPartApplyPartListM",        stCN_APPLY_PARTLIST             );
			        attributes.put("cdmPartSubIdM",                stCN_SUB_ID                     );
			        attributes.put("cdmPartMCPOrgM",          	   stCN_OVERSEAS_ORG6              );
			        attributes.put("cdmPartMCPPartTypeM",          stCN_OVERSEAS_ORG6_PART_TYPE    );
			        attributes.put("cdmPartMCPBOMManagementM",     stCN_OVERSEAS_ORG6_INOUT 	   );  
			        attributes.put("cdmPartCreationDateM",        stCREATION_DATE     	           );  
			        attributes.put("cdmPartCreationUserIdM",      stUSER_OBJECT_ID  	           );  
			        attributes.put("cdmPartModUserIdM",           stUSER_ID_MOD  	               );  
			        attributes.put("cdmPartModificationDateM",    stMODIFICATION_DATE  	           );  
			        attributes.put("cdmPartComplexBodyForRealWeightM",  stCN_COMPLEX_BODY          );
			        attributes.put("cdmCheckMigration",           "Y"					  	       );
			        attributes.put("cdmPartPhase",           	   stPhase			  	       	   );
			        //add attribute 11/17/2016 start 
			        attributes.put("cdmPartApplyPartList",           "true"				  	       );
			        attributes.put("cdmPartApplySizeList",           "false"			  	       );
			        attributes.put("cdmPartApplySurfaceTreatmentList", "false"	  				   );
			        //add attribute 11/17/2016 end 
			        attributes.put("cdmPartEstimateWeightUnit", sTempWeightUnit			   );
			        
			        /*migration을 작업을 위해 attribute 추가 end  */
			        
			      
			        /* **********************************************************************************************************************
			         * part 데이타 생성 및 데이타 
			         * 트리거 오프한 상태로 진행되며 트리거에서 제공되는 attribute[originator]속성 및 interface 추가 설정 필터 정보 와 
			         * rev 정보 part master 생성 및 연결 및 속성(attribute[Originator]속성 추가 
			         * 에러 발생시 정지 및 데이타 정보 검색 
			         * ******************************************************************************************************************* */
			        
			        DomainObject partObj = new DomainObject();
			        boolean bCommit = false;
//					partObj.createObject(context, stPartType, stCN_ID, stREVISION, cdmConstantsUtil.POLICY_CDM_PART_POLICY, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        ContextUtil.startTransaction(context, true);
			        bCommit = true;
			        boolean bNewPartCheck = false;
			        boolean reviseCheck = false;
			        BusinessObject previousPart  = null;
			        
			        previousPart  = new BusinessObject(TYPE_CDMMECHANICALPART,stCN_ID,stPAR_REVISION,"eService Production");
			        if(!previousPart.exists(context)){
			        	previousPart  = new BusinessObject("cdmPhantomPart",stCN_ID,stPAR_REVISION,"eService Production");
			        }
			        boolean checkPartPrevious = false;
			        boolean existPreviousPart = previousPart.exists(context);
			        
//			        if(  stCN_ID.equals(strPreviousPartNo) || existPreviousPart) {
			        if( existPreviousPart) {
			        	if(previousPart.exists(context)){
			        		checkPartPrevious = true;
			        	}
//			        	if(stCN_ID.equals(strPreviousPartNo) && !existPreviousPart){
//			        		previousPart  = new BusinessObject(strPreviousPartType,stCN_ID,strPreviousPartRevision,"eService Production");
//			        	}
//			        	if(previousPart.exists(context)){
//			        		checkPartPrevious = true;
//			        	}
			        }
			        
			        if(checkPartPrevious){
			        	BusinessObject currentPart = previousPart.revise(context, stREVISION, "eService Production");
			        	partObj.setId(currentPart.getObjectId(context));
			        	
			        	StringBuffer sbRelType = new StringBuffer();
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE).append(",");
			        	sbRelType.append(cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION);
			        	 
			        	StringList relList = new StringList();
			        	relList.add("id[connection]");
			        	
			        	MapList mlCodes = partObj.getRelatedObjects(context,
			        			sbRelType.toString(), // relationship pattern
			                    "*", // object pattern
			                    null, // object selects
			                    relList, // relationship selects
			                    true, // to direction
			                    false, // from direction
			                    (short) 1, // recursion level
			                    "", // object where clause
			                    null); // relationship where clause
			        	
			        	for (int jj = 0; jj < mlCodes.size(); jj++) {
							Map mapCode = (Map)mlCodes.get(jj);
							String relid = (String)mapCode.get("id[connection]");
							
							MqlUtil.mqlCommand(context, "del connection "+relid);
							
						}
			        } else {
			        	partObj.createObject(context, stPartType, stCN_ID, stREVISION, "cdmPartPolicy", cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        	bNewPartCheck = true;
			        }
			        strPreviousPartNo = stCN_ID;
					strPreviousPartRevision = stREVISION;
					strPreviousPartType = stPartType;

					
					
					if ("In Approval".equals(stSTATE)) {
						stSTATE = "Review";
						
					} else if ("Inactive".equals(stSTATE)) {
						stSTATE = "Obsolete";
						
					}else if ("Released".equals(stSTATE)) {
						stSTATE = "Release";
							
						
					}else if ("In Work".equals(stSTATE)) {
						stSTATE = "Preliminary";
					}
					
					partObj.setState(context, stSTATE);
					
//					partObj.setAttributeValues(context, attributes);
					
					String partObjectId = partObj.getId(context);

					if(boolPerson){
						partObj.setOwner(context, stTDM_ORG_USER_ID); 
					}
					
					
					/*
					 * *********************************************************
					 *  create 시 발생하는 trigger에서 발생하는 interface 생성 start
					 * *********************************************************
					 */
//					boolean isMEP = false;
//	
//					if (partObjectId != null && !"".equals(partObjectId)) {
//						String sExternalPartData = PropertyUtil.getSchemaProperty(context, DomainSymbolicConstants.SYMBOLIC_interface_ExternalPartData);
//						Part part = new Part(partObjectId);
//						String sPolicyClassification = part.getInfo(context, "policy.property[PolicyClassification].value");
//
//						// enable MEP by default
//						if (sPolicyClassification != null && "Equivalent".equals(sPolicyClassification)) {
//							isMEP = true;
//						}
//						if (isMEP) {
//							MqlUtil.mqlCommand(context, "modify bus $1 add interface $2;", partObjectId, sExternalPartData);
//						}
//					}
		
						/*
						 * *********************************************************
						 * attribute[attribute_Originator]
						 * 의 정보를stTDM_ORG_USER_ID 정보를 입력.
						 * *********************************************************
						 * 
						 */
						partObj.setAttributeValue(context, DomainConstants.ATTRIBUTE_ORIGINATOR, stTDM_ORG_USER_ID);
		
						/* part Master 생성 start */
						createPartMaster(context, partObjectId, stTDM_ORG_USER_ID,boolPerson);
						/* part Master 생성 end */
		
						/* create 시 발생하는 trigger에서 사용된 정보 interface 생성 end */
		
						/*
						 * *********************************************************
						 * 
						 *  EBOM 정보로 연결된 Part 을 생성할시 relationship 연결을 제외된다.
						 * 또한 relationship 연결의 경우 공통코드 데이타가 PLM에 스마트팀 정보가 다 있다고 가정하여
						 * 진행 공통코드를 검색하여 데이타가 없을시 오류 처리 . 오류가 발생하면 Exception 발생.
						 * *********************************************************
						 */
		
						StringBuffer sbVehicleId = new StringBuffer("");
						StringBuffer sbProjectId = new StringBuffer("");
						StringBuffer sbProjectTypeId = new StringBuffer("");
						StringBuffer sbProductTypeId = new StringBuffer("");
		
						StringBuffer sbOrg1Id = new StringBuffer();
						StringBuffer sbOrg2Id = new StringBuffer();
						StringBuffer sbOrg3Id = new StringBuffer();
		
						StringBuffer sbOption1Id = new StringBuffer("");
						StringBuffer sbOption2Id = new StringBuffer("");
						StringBuffer sbOption3Id = new StringBuffer("");
						StringBuffer sbOption4Id = new StringBuffer("");
						StringBuffer sbOption5Id = new StringBuffer("");
						StringBuffer sbOption6Id = new StringBuffer("");
		
						StringBuffer sbECONumberId = new StringBuffer("");
						StringBuffer sbDrawingNoId = new StringBuffer("");
						StringList sListPFs = new StringList();
						/* ************************************************
						 * stCN_VEHICLE_DESC 정보는 두개 이상 있을수 있으며 구분자 , 
						 * stVehicle_Cust 정보의 경우 두개이상 데이타 존재 있을수 있다 구분자 ;
						 * ************************************************
						 * */
						StringList stListCN_VEHICLE_DESC = new StringList();
						StringList stListVehicle_Cust = new StringList();
	
						stListCN_VEHICLE_DESC = FrameworkUtil.split(stCN_VEHICLE_DESC, ",");
	
						boolean checkErrorVehicleCust = false;
						if (stVehicle_Cust.startsWith("ORA-01422") || "-2147483647".equals(stVehicle_Cust)) {
							checkErrorVehicleCust = true;
						} else {
							stListVehicle_Cust = FrameworkUtil.split(stVehicle_Cust, ";");
						}
						int vehicleCustInt = 0;
						int vehicleDesInt = 0;
						vehicleCustInt = stListVehicle_Cust.size();
						vehicleDesInt = stListCN_VEHICLE_DESC.size();
						if (cdmStringUtil.isNotEmpty(stCN_VEHICLE_DESC) &&  !checkErrorVehicleCust) {
							StringList sListVehicleIds = new StringList();
//							if (vehicleCustInt == vehicleDesInt) {
//								for (int stListVehicleNum = 0; stListVehicleNum < stListCN_VEHICLE_DESC.size(); stListVehicleNum++) {
//	
//									String stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);
//	
//									String stTempVehicleCust = (String) stListVehicle_Cust.get(stListVehicleNum);
//	
//									String searchVehicle = stTempVehicle + "_" + stTempVehicle + "_" + stTempVehicleCust;
//	
//									String tempVehicleId = (String) vehicleCommonCodeMap.get(searchVehicle);
//									tempVehicleId = (tempVehicleId == null || "null".equals(tempVehicleId)) ? "" : tempVehicleId.trim();
//									if (StringUtils.isNotEmpty(tempVehicleId) && !sListVehicleIds.contains(tempVehicleId)) {
//										sListVehicleIds.add(tempVehicleId);
//										sbVehicleId.append(tempVehicleId);
//										sbVehicleId.append(",");
//									}
//	
//								}
								
								//
							if (vehicleCustInt >0) {
								for (int stListVehicleNum = 0; stListVehicleNum < stListVehicle_Cust.size(); stListVehicleNum++) {
	
									//
									String stTempVehicle = "";
									if(stListVehicleNum+1<=vehicleDesInt){
										stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);
									}else{
										continue;
									}
									//
//									String stTempVehicle = (String) stListCN_VEHICLE_DESC.get(stListVehicleNum);
	
									String stTempVehicleCust = (String) stListVehicle_Cust.get(stListVehicleNum);
									String checkVehicleCust = ""; 
									checkVehicleCust = stTempVehicleCust.trim();
									if("-".equals(checkVehicleCust)){
										continue;
									}
									String searchVehicle = stTempVehicle + "_" + stTempVehicle + "_" + stTempVehicleCust;
	
									String tempVehicleId = (String) vehicleCommonCodeMap.get(searchVehicle);
									tempVehicleId = (tempVehicleId == null || "null".equals(tempVehicleId)) ? "" : tempVehicleId.trim();
									if (StringUtils.isNotEmpty(tempVehicleId) && !sListVehicleIds.contains(tempVehicleId)) {
										sListVehicleIds.add(tempVehicleId);
										sbVehicleId.append(tempVehicleId);
										sbVehicleId.append(",");
									}
	
								}
								//
							}
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_VEHICLE_DESC) && cdmStringUtil.isEmpty(sbVehicleId.toString()) && !checkErrorVehicleCust){
//							sbErrorMessage.append("No Vehicle information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Project */
						if (cdmStringUtil.isNotEmpty(stCN_Project_Id)) {
							
//							String projectIdMql = " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectCode] =='" + stCN_PROJECT + "' &&  attribute[cdmProjectGroupCustomerAttribute] =='" + stCN_PROJECT_CUST + "' && attribute[cdmProjectGroupProductTypeAttribute] == '" + stCN_PRODUCT_DIV + "' \" select id dump |";
//							String projectIdMql = " temp query bus cdmProjectGroupObject * * where \" attribute[cdmProjectObjectIdM] =='" + stCN_Project_Id +"' select id dump |";
//							String projectIdMqlResult = MqlUtil.mqlCommand(context, projectIdMql);
//							StringList stListProjectMqlResult = FrameworkUtil.split(projectIdMqlResult, "|");
							String stTempProjectId = "";
							stTempProjectId = (String)projectMap.get(stCN_Project_Id);
							stTempProjectId = (stTempProjectId == null || "null".equals(stTempProjectId)) ? "" : stTempProjectId.trim();
							sbProjectId.append(stTempProjectId);
							
						}
						
						if(cdmStringUtil.isEmpty(sbProjectId.toString())){
//							sbErrorMessage.append("No Project information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						// Product Group
						if (cdmStringUtil.isNotEmpty(stCN_PRODUCT_GROUP)) {
							String stTempProductGroupId = (String)productGroupMap.get(stCN_PRODUCT_GROUP+"_"+stCN_PRODUCT_DIV);
							stTempProductGroupId = (stTempProductGroupId == null || "null".equals(stTempProductGroupId)) ? "" : stTempProductGroupId.trim();
							sbProjectTypeId.append(stTempProductGroupId);
	
						}
	
						if(cdmStringUtil.isNotEmpty(stCN_PRODUCT_GROUP) && cdmStringUtil.isEmpty(sbProjectTypeId.toString())){
//							sbErrorMessage.append("No Product Group information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Product Div */
						if ( cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempProductDivId = (String)productDivMap.get(stCN_PRODUCT_DIV);
							stTempProductDivId = (stTempProductDivId == null || "null".equals(stTempProductDivId)) ? "" : stTempProductDivId.trim();
							sbProductTypeId.append(stTempProductDivId);
	
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV) && cdmStringUtil.isEmpty(sbProductTypeId.toString())){
//							sbErrorMessage.append("No Product Div information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
	
						/* Option1 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION1)) {
							
							String stTempOption1 = "";
//							stTempOption1 = (String)option1Map.get(stCN_OPTION1+"_"+stCN_PRODUCT_DIV);
//							stTempOption1 = (stTempOption1 == null || "null".equals(stTempOption1)) ? "" : stTempOption1.trim();
//							sbOption1Id.append(stTempOption1);
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_OPTION1) && cdmStringUtil.isEmpty(sbOption1Id.toString())){
//							sbErrorMessage.append("No OPTION1 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						
						/* Option2 */
//						if (cdmStringUtil.isNotEmpty(tempLev2CommonCodeOption2Id) && cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
						if (cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption2 = "";
//							stTempOption2 = (String)option2Map.get(stCN_OPTION2+"_"+stCN_PRODUCT_DIV);
//							stTempOption2 = (stTempOption2 == null || "null".equals(stTempOption2)) ? "" : stTempOption2.trim();
//							sbOption2Id.append(stTempOption2);
						}
						
						if(cdmStringUtil.isNotEmpty(stCN_OPTION2) && cdmStringUtil.isEmpty(sbOption2Id.toString())){
//							sbErrorMessage.append("No OPTION2 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
	
						/* Option3 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION3) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption3 = "";
//							stTempOption3 = (String)option3Map.get(stCN_OPTION3+"_"+stCN_PRODUCT_DIV);
//							stTempOption3 = (stTempOption3 == null || "null".equals(stTempOption3)) ? "" : stTempOption3.trim();
//							sbOption3Id.append(stTempOption3);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION3) && cdmStringUtil.isEmpty(sbOption3Id.toString())){
//							sbErrorMessage.append("No OPTION3 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option4 */
						if ( cdmStringUtil.isNotEmpty(stCN_OPTION4) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption4 = "";
//							stTempOption4 = (String)option4Map.get(stCN_OPTION4+"_"+stCN_PRODUCT_DIV);
//							stTempOption4 = (stTempOption4 == null || "null".equals(stTempOption4)) ? "" : stTempOption4.trim();
//							sbOption4Id.append(stTempOption4);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION4) && cdmStringUtil.isEmpty(sbOption4Id.toString())){
//							sbErrorMessage.append("No OPTION4 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option5 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION5) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							
							String stTempOption5 = "";
//							stTempOption5 = (String)option5Map.get(stCN_OPTION5+"_"+stCN_PRODUCT_DIV);
//							stTempOption5 = (stTempOption5 == null || "null".equals(stTempOption5)) ? "" : stTempOption5.trim();
//							sbOption5Id.append(stTempOption5);
	
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION5) && cdmStringUtil.isEmpty(sbOption5Id.toString())){
//							sbErrorMessage.append("No OPTION5 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* Option6 */
						if (cdmStringUtil.isNotEmpty(stCN_OPTION6) && cdmStringUtil.isNotEmpty(stCN_PRODUCT_DIV)) {
							String stTempOption6 = "";
//							stTempOption6 = (String)option6Map.get(stCN_OPTION6+"_"+stCN_PRODUCT_DIV);
//							stTempOption6 = (stTempOption6 == null || "null".equals(stTempOption6)) ? "" : stTempOption6.trim();
//							sbOption6Id.append(stTempOption6);
						}
						if(cdmStringUtil.isNotEmpty(stCN_OPTION6) && cdmStringUtil.isEmpty(sbOption6Id.toString())){
//							sbErrorMessage.append("No OPTION6 information exists in the database.");
							sbErrorMessage.append("O").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t");
						}
						/* sbECONumberId */
					if (cdmStringUtil.isNotEmpty(stCN_ECO_NUMBER)) {
						StringBuffer sbfECType = new StringBuffer();
						sbfECType.append("cdmECO");
						sbfECType.append(",");
						sbfECType.append("cdmEAR");
						sbfECType.append(",");
						sbfECType.append("cdmDCR");
						sbfECType.append(",");
						sbfECType.append("cdmPEO");
//						sbfECType.append(",");
//						sbfECType.append("cdmTEO");
						
						
						String stTempECExist = "temp query bus \"" + sbfECType.toString() + "\" \""+stCN_ECO_NUMBER +"\"  *  select id dump |";
						String stTempECExistMql = MqlUtil.mqlCommand(context, stTempECExist);
						StringList sListTempECExistMql = FrameworkUtil.split(stTempECExistMql, "|");
						// test start start
						if (sListTempECExistMql.size() > 2) {
							sbECONumberId.append(sListTempECExistMql.get(3));
							sbErrorMessage.append("X").append("\t");
						} else {
//							sbErrorMessage.append( "EC information does not exist.");
							sbErrorMessage.append("O").append("\t");
						}
					}
					
					//Part Family
					if (stCN_ID.length() > 6) {

						String pfCodeName = stCN_ID.substring(0, 5);
						String partFamilys = (String)partFamilyMap.get(pfCodeName);
						partFamilys = (partFamilys == null || "null".equals(partFamilys)) ? "" : partFamilys.trim();
						sListPFs = FrameworkUtil.split(partFamilys, ",");
						if(cdmStringUtil.isEmpty(partFamilys) ){
//							if(bNewPartCheck){
								sbErrorMessage.append("O").append("\t");
//							}else{
//								sbErrorMessage.append("X").append("\t");
//							}
						}else{
//							if(bNewPartCheck){
								sbErrorMessage.append("X").append("\t");
//							}else{
//								sbErrorMessage.append("O").append("\t");
//							}
						}
					}
					
//						stCN_ECO_NUMBER
						/* sbDrawingNoId */
					
//					HashMap paramHM = new HashMap();
//					paramHM.put("partObjectId", partObjectId);
//					paramHM.put("VehicleObjectId", sbVehicleId.toString());
//					paramHM.put("ProjectObjectId", sbProjectId.toString());
//					paramHM.put("ProjectTypeObjectId", sbProjectTypeId.toString());
//					paramHM.put("ProductTypeObjectId", sbProductTypeId.toString());
						
					String[] objectIdArray = sbVehicleId.toString().split(",");
					for(int i=0; i<objectIdArray.length; i++){
	    				String strVehicleId = objectIdArray[i];
	    				
	    				if(StringUtils.isEmpty(strVehicleId.trim()))
	    					continue;
	    				
	    				DomainRelationship.connect(context, new DomainObject(strVehicleId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
	    			}
						
						if(UIUtil.isNotNullAndNotEmpty(sbProjectId.toString())){
			    			DomainRelationship.connect(context, new DomainObject(sbProjectId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT, partObj);
			    		}
						
						if(UIUtil.isNotNullAndNotEmpty(sbProjectTypeId.toString())){
							DomainRelationship.connect(context, new DomainObject(sbProjectTypeId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE, partObj);
			        	}
						
						//product group
						if(UIUtil.isNotNullAndNotEmpty(sbProductTypeId.toString())){
			    			DomainRelationship.connect(context, new DomainObject(sbProductTypeId.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE, partObj);
			        	}
						
						if(UIUtil.isNotNullAndNotEmpty(sbOption1Id.toString())){
							DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption1Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
							x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option1");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption2Id.toString())){
			    		     
			    		    DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption2Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option2");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption3Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption3Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option3");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption4Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption4Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option4");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption5Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption5Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option5");
			        	}
			        	if(UIUtil.isNotNullAndNotEmpty(sbOption6Id.toString())){
			        		DomainRelationship x  = DomainRelationship.connect(context, new DomainObject(sbOption6Id.toString()), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, partObj);
			        		x.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option6");
			        	}
			        	
//						paramHM.put("ECONumberOid", sbECONumberId.toString());
						if(UIUtil.isNotNullAndNotEmpty(sbECONumberId.toString())){
		        			DomainRelationship.connect(context, new DomainObject(sbECONumberId.toString()), DomainConstants.RELATIONSHIP_AFFECTED_ITEM, partObj);
			        		
			        	}
						bCommit = true;
						ContextUtil.commitTransaction(context);		
					if (bNewPartCheck) {
						int sListPartFamilyIdsSize = sListPFs.size();
						boolean bCheckPartNamePF = false;
						boolean bExceedOnePF = false;
						for (Iterator iterPF = sListPFs.iterator(); iterPF.hasNext();) {
							
							String sPF = (String) iterPF.next();
							HashMap connectPFHMap = new HashMap();
							
							if(sListPartFamilyIdsSize>1){
								String pfCodeName = stCN_ID.substring(0, 5);
								String checkPartFamilyName = pfCodeName+":"+stTDM_DESCRIPTION;
								bExceedOnePF = true;
								sPF = (String)partFamilyMap.get(checkPartFamilyName);
								if(UIUtil.isNotNullAndNotEmpty(sPF)){
									bCheckPartNamePF = true;
								}
							}
							
							if ( (UIUtil.isNotNullAndNotEmpty(sPF) && bExceedOnePF) || sListPartFamilyIdsSize == 1) {
								connectPFHMap.put("sPF", sPF);
								connectPFHMap.put("partObjectId", partObjectId);
//							
								String connectResult = JPO.invoke(context, "cdmPartMigration", null, "connectPartFamily", JPO.packArgs(connectPFHMap), String.class);
								
								if (connectResult.startsWith("false|")) {
//									int startIndex = connectResult.indexOf("false|");
//									System.out.println("errorMessage ------->  "+connectResult);
//									connectResult.substring(startIndex);
									sbErrorMessage.append("O (PartFamily)").append(connectResult).append("\t");
									
								} else {
									sbErrorMessage.append("X (PartFamily)").append("\t");
									
								}
								break;
							}
						}
						//2개 이상 part family 과 존재하지만  stCN_ID  자른 정보와 part family의 name 값이 일치하지않을경우 하나의 part family만 연결한다.
						if(bExceedOnePF && !bCheckPartNamePF){
							//
							for (int exceedOnePfCnt = 0 ;exceedOnePfCnt<sListPFs.size();exceedOnePfCnt++ ) {
								
								String sPF = (String) sListPFs.get(0);
								HashMap connectPFHMap = new HashMap();
								
								String pfCodeName = stCN_ID.substring(0, 5);
								String checkPartFamilyName = pfCodeName+":"+stTDM_DESCRIPTION;
								
								if ( UIUtil.isNotNullAndNotEmpty(sPF)  ) {
									connectPFHMap.put("sPF", sPF);
									connectPFHMap.put("partObjectId", partObjectId);
									
									String connectResult = JPO.invoke(context, "cdmPartMigration", null, "connectPartFamily", JPO.packArgs(connectPFHMap), String.class);
									
									if (connectResult.startsWith("false|")) {
//										int startIndex = connectResult.indexOf("false|");
//										connectResult.substring(startIndex);
										sbErrorMessage.append("O (PartFamily)").append("\t");
									} else {
										sbErrorMessage.append("X (PartFamily)").append("\t");

									}
									break;
								}
							}
							//
						}
						checkAddPart = true;
					}else{
						checkAddPart = true;
						sbErrorMessage.append("X (Revise PartFamily)").append("\t");
					}
//						paramHM.put("DrawingNo_Oid", sbDrawingNoId.toString());
//						Boolean ErrorCheck = (Boolean) JPO.invoke(context, "cdmPartLibrary", null, "checkPartObjectRelationShip", JPO.packArgs(paramHM), Boolean.class);
						//(Context context, String partObjectId, String vehicleObjectId,
//			    		String projectObjectId, String projectTypeObjectId, String productTypeObjectId, String org1ObjectId, 
//						String org2ObjectId, String org3ObjectId, String option1ObjectId, String option2ObjectId,
//						String option3ObjectId, String option4ObjectId, String option5ObjectId, String option6ObjectId, String ecId, String drawingId) 
						
//						partObjectRelationShip(context, partObjectId, VehicleObjectId, ProjectObjectId, ProjectTypeObjectId, ProductTypeObjectId, Org1ObjectId, Org2ObjectId, Org3ObjectId, Option1ObjectId, Option2ObjectId, Option3ObjectId, Option4ObjectId, Option5ObjectId, Option6ObjectId, ECONumberOid, DrawingNo_Oid);
//			    		DomainObject partObj = new DomainObject(partObjectId);
//			    		if(UIUtil.isNotNullAndNotEmpty(vehicleObjectId)){
//			    			StringList relVehicleIdList = partObj.getInfoList(context, "to["+cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE+"].id");
//			    			if(relVehicleIdList.size() > 0 && ! "".equals(relVehicleIdList)){
//			    				for(int k=0; k<relVehicleIdList.size(); k++){
//			    					DomainRelationship.disconnect(context, relVehicleIdList.get(k).toString());
//			    				}
//			    			}
//			    		    if(vehicleObjectId.contains(",")){
//			    				String[] objectIdArray = vehicleObjectId.split(",");
//			    				StringBuffer strBuffer = new StringBuffer();
//			    				for(int i=0; i<objectIdArray.length; i++){
//			    					String strVehicleId = objectIdArray[i];
//			    					DomainRelationship.connect(context, new DomainObject(strVehicleId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
//			    				}
//			    		    }else{
//			    			    if(!"".equals(vehicleObjectId)){
//			    					DomainRelationship.connect(context, new DomainObject(vehicleObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, partObj);
//			    				}
//			    		    }
//			    		}
					
						/*
						 * *********************************************************
						 * promote 및 revise "In Approval" 상태를
						 * 가진 part 정보일경우 enovia에서는 In Review 상태로 ... "Inactive" 상태를
						 * 가진 part 정보일경우 enovia에서는 Obsolete 상태로 변경. 과거 revision을 가진
						 * object 은 무조건 Released 상태를 가진다. 현재 eo 데이타는 존재하지않아 연결정보를
						 * 사용할 수 없다. 현재 상태로는 eo 데이타가 없고 drawing 데이타가 연결이 되지않아 추후 연결
						 * 필요
						 * 
						 * 도면 있을 때 에는 revise 될때 같이 처리해야한다. 참조 cdmPartLibray
						 * revise... 소스는 빼논 상태
						 * *********************************************************
						 * 
						 */
//					bCommit = true;
//					ContextUtil.commitTransaction(context);	
					

					if (UIUtil.isNotNullAndNotEmpty(stCREATION_DATE) ) {
						Date createdate = new Date(stCREATION_DATE);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa", new Locale("en", "US"));
						String tempCreatedDate = "";
						tempCreatedDate = sdf.format(createdate);
						//12/6/2016 10:40:16 AM
						MqlUtil.mqlCommand(context, "mod bus $1 originated $2", partObjectId, tempCreatedDate);
					}

					
					try {
						MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", partObjectId, stAccessProductGroup, stAceesOrg);
						
						if(UIUtil.isNullOrEmpty(stAccessProductGroup) || " - ".equals(stAceesOrg)  || UIUtil.isNullOrEmpty(stAceesOrg)){
							sbErrorMessage.append(stAccessProductGroup).append("\t").append(stAceesOrg).append("\t").append("project or Org not exist").append("\t");
						}else{
							sbErrorMessage.append("X").append("\t").append("X").append("\t");
						}
					} catch (Exception e) {
						sbErrorMessage.append(stAccessProductGroup).append("\t").append(stAceesOrg).append("\t");
					}
					
					
					if(bCommit){
						try{
						partObj.setAttributeValues(context, attributes);
						sbErrorMessage.append("X").append("\t");
						}catch(Exception e4){
							sbErrorMessage.append("O").append("\t");
						}
					}
					
					MqlUtil.mqlCommand(context, "trigger on");
					checkTriggerOff = false;	
						
					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
//						writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());	
						writeSuccessToFile(cdmCommonExcel.getTimeStamp() +"\t"+ subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+sbErrorMessage.toString());	
					}else{
//							writeSuccessToFile("LineNum(#): "+subPartCount +" \t PartNo: \t "+tempStPartNo+" \t ");
						writeSuccessToFile(cdmCommonExcel.getTimeStamp()+"\t"+subPartCount +"\t"+tempStPartNo+"\t"+stREVISION);
							
					}
						
					successCount++;
						
				} catch (Exception e) {
					ContextUtil.abortTransaction(context);

//					if(!checkAddPart){
//						MQLCommand mqlCommand = new MQLCommand();
//						mqlCommand.open(context);
//						mqlCommand.executeCommand(context, "abort transaction $1","PartFamily");
//					}
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "trigger on");
						checkTriggerOff = false;			
					}
					failCount++;
					writeErrorToFile("LineNum(#) \t"+tempStRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t "+ tempStPartNo+"\t"+tempStPartRevision +"\t"+e.getMessage().replaceAll("\r|\n", "")); 
					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t" +  data ) ;
					e.printStackTrace(errorStream);
					
					writeShotErrorToFile("LineNum(#) \t"+tempStRowNum + " \t"+cdmCommonExcel.getTimeStamp2()+"\t "+tempStPartNo+"\t"+tempStPartRevision +"\t"+e.toString().replaceAll("\r|\n", ""));
				}finally{
					
				}
				
			} // end of while 
			
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================");
			//
		} catch (Exception e1) {
			writeFailToFile(" LineNum(#):"+tempStRowNum);
			writeErrorToFile("LineNum(#):"+tempStRowNum + "  "+e1.getMessage());
			e1.printStackTrace(errorStream);
			
			
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("	SECOND CREATE PART OBJECT CLOSE TIME:  "+cdmCommonExcel.getTimeStamp2()+"          "  );
			writeMessageToConsole("	SECOND CREATE PART OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+") TOTALCOUNT :("+totalCount+")"  );
			writeMessageToConsole("==================================================================================== \n");
			MqlUtil.mqlCommand(context, "history on");
			if(checkTriggerOff){
				MqlUtil.mqlCommand(context, "trigger on");
			}
			try {
				if (null != errorStream )
					errorStream .close();

				if (null != logWriter)
					logWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if(null != bufferReader)
					bufferReader.close();
				
				if(null != errorLogFile)
					errorLogFile.close();
				
				if(null != debugLogFile)
					debugLogFile.close();

				if(null != errorLogFile)
					errorLogFile.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			
			long endTime = System.currentTimeMillis();
			long leadTime = (endTime-startTime)/1000/60;
			System.out.println("cdmPartMigration : secondExcutedCreatePart End.   endTime:"+cdmCommonExcel.getTimeStamp()  + " leadTime :"+leadTime);
			
		}
	
	
    
	
    }
    
    /**
     * 
     * @param context
     * @param args
     * @throws Exception
     */
    public void addAttributeTemp(Context context,String args[])throws Exception{


		long startTime = System.currentTimeMillis();
		System.out.println("cdmPartMigration : addAttributeTemp -StartTime:"+cdmCommonExcel.getTimeStamp());
		String logFileName = "addAttrPartM";
		
//	
//		if(args.length!=1){
//			throw new Exception("The excel path does not exist.");
//		}
//		String sFileLocationAndFileName = args[0];
		
		HashMap paramMap = (HashMap)JPO.unpackArgs(args);
		String sFileLocationAndFileName = (String)paramMap.get("fileData");
		
		String sFileLocation 		= "";
		String sFileName 			= "";
		
		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf(File.separator));
		sFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf(File.separator)+1);
		
		
//		sFileName = (String)paramMap.get("File");
		
		String sPartInputDirectory = sFileLocation;

		// documentDirectory does not ends with "/" add it
		if(sPartInputDirectory != null && !sPartInputDirectory.endsWith(sfileSeparator))
		{
			sPartInputDirectory = sPartInputDirectory + sfileSeparator;
		}
		String sPartOutputDirectory = "";
		// create a directory to add debug and error logs
		sPartOutputDirectory = new File(sPartInputDirectory).getParentFile() + sfileSeparator +  S_OUTPUT_DIRECTORY+sfileSeparator + logFileName  +"_"+  sfileSeparator;
        File fileOutputDirectory = new File(sPartOutputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        
        String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		logFileName +="_"+sFileName.substring(0, sFileName.lastIndexOf("."))+"_"+formatTime;
		
        
		logWriter 			 	= new BufferedWriter(new FileWriter(sPartOutputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(sPartOutputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(sPartOutputDirectory + logFileName + "_SuccessLogs.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(sPartOutputDirectory + logFileName + "_FailedLogs" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		shortErrorLogFile        = new File(sPartOutputDirectory + logFileName + "ShortErrorLogs" + ".txt");
		shortErrorWriter         = new BufferedWriter(new FileWriter(shortErrorLogFile,true));
		
		String tempStRowNum   = ""; //순번
		String tempStPartNo   = ""; //엑셀의 PartNo
		String tempStPartRevision   = ""; //엑셀의 PartNo
		int totalCount = 0;
		int successCount = 0;
		int failCount = 0;
		boolean checkTriggerOff = false;
		BufferedReader bufferReader = null;
		writeSuccessToFile("CreateTime \t LineNume(#) \t  PartNo. \t Revision \t No Vehicle Exist. \t No Project exists. \t No Product Group exists. \t No Product Div exists. \t  OPTION1 Wrong. \t OPTION2 Wrong. \t  OPTION3 Wrong. \t   OPTION4 Wrong. \t  OPTION5 Wrong. \t   OPTION6 Wrong. \t EC information does not exist. \t No Part Family exist. \t Part Connect \t Project Group \t Org  \t attributes ");
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole(" add attribute PART DATA MIGRATION "+ cdmCommonExcel.getTimeStamp()+" \n");
		writeMessageToConsole("	Reading input log file from : "+sPartInputDirectory+sFileName);
		writeMessageToConsole("	Writing Log files to: " + sPartInputDirectory );
		writeMessageToConsole("====================================================================================\n");
		boolean checkAddPart = false;
		MqlUtil.mqlCommand(context, "history off");
		try {
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(sPartInputDirectory+sFileName),"euc-kr"));
			String data = "";  							// 텍스트 파일 라인정보담을 변수 
			StringList stListHeader = new StringList(); // 텍스트파일의 헤더정보
			
			/* cdmCommonCode lev2 object 검색 start  */
			
			// 12/2 start 
			Map option1Map = getOptionCode(context,"Option1");
			Map option2Map = getOptionCode(context,"Option2");
			Map option3Map = getOptionCode(context,"Option3");
			Map option4Map = getOptionCode(context,"Option4");
			Map option5Map = getOptionCode(context,"Option5");
			Map option6Map = getOptionCode(context,"Option6");
			
			Map vehicleCommonCodeMap = getVehicleCode(context,"Vehicle");
			Map productGroupMap      = getProductGroupCode(context,"Product Group Name");
			Map productDivMap        = getProductDivCode(context,"Product Div");
			Map projectMap           = getProjectCode(context,"cdmProjectGroupObject");
//			Map partFamilyMap        = getPartFamilyId(context);
			Map partFamilyMap        = getPartFamilyId2(context,"Global R&D:Global R&D"); //top part family[cdmPartFamilyBlockCodeName]
			
			/*cdmCommonCode lev2 object 검색 end */ 
			
			String strLanguage = context.getLocale().getLanguage();
			
			AttributeType attrPartGlobal = new AttributeType("cdmPartGlobal");
			attrPartGlobal.open(context);
			StringList attrPartGlobalList = attrPartGlobal.getChoices(context);
			attrPartGlobal.close(context);
			StringList attrPartGlobalKOList = new StringList();
			attrPartGlobalKOList = i18nNow.getAttrRangeI18NStringList("cdmPartGlobal", attrPartGlobalList, strLanguage);
			
			
			AttributeType attrPartItemType = new AttributeType("cdmPartItemType");
			attrPartItemType.open(context);
			StringList attrPartItemTypeList = attrPartItemType.getChoices(context);
			attrPartItemType.close(context);
			StringList attrPartItemTypeKOList = new StringList();
			attrPartItemTypeKOList = i18nNow.getAttrRangeI18NStringList("cdmPartItemType", attrPartItemTypeList, strLanguage);
			
			
			AttributeType attrPartERPInterface = new AttributeType("cdmPartERPInterface");
			attrPartERPInterface.open(context);
			StringList attrPartERPInterfaceList = attrPartERPInterface.getChoices(context);
			attrPartERPInterface.close(context);
			StringList attrPartERPInterfaceKOList = new StringList();
			attrPartERPInterfaceKOList = i18nNow.getAttrRangeI18NStringList("cdmPartERPInterface", attrPartERPInterfaceList, strLanguage);
			
			AttributeType attrPartType = new AttributeType(S_ATTRIBUTE_CDMPARTTYPE);
			attrPartType.open(context);
			StringList attrPartTypeList = attrPartType.getChoices(context);
			attrPartType.close(context);
			StringList attrPartTypeKOList = new StringList();
			attrPartTypeKOList = i18nNow.getAttrRangeI18NStringList(S_ATTRIBUTE_CDMPARTTYPE, attrPartTypeList, strLanguage);
			
			HashMap tempUOMHMap = new HashMap();
			tempUOMHMap.put("EA"  , "Each");
			tempUOMHMap.put("BAG" , "bag");
			tempUOMHMap.put("BTL" , "bottle");
			tempUOMHMap.put("BOX" , "box");
			tempUOMHMap.put("CC"  , "cc");
			tempUOMHMap.put("CMM" , "mm³");
			tempUOMHMap.put("CMT" , "m³");
			tempUOMHMap.put("CN"  , "can");
			tempUOMHMap.put("CT"  , "carton");
			tempUOMHMap.put("DL"  , "dl");
			tempUOMHMap.put("DZ"  , "dozen");
			tempUOMHMap.put("FT"  , "ft");
			tempUOMHMap.put("GLL" , "gallon");
			tempUOMHMap.put("G"   , "g");
			tempUOMHMap.put("IN"  , "inch");
			tempUOMHMap.put("KG"  , "kg");
			tempUOMHMap.put("KMT" , "km");
			tempUOMHMap.put("L"   , "L");
			tempUOMHMap.put("LBR" , "lb");
			tempUOMHMap.put("M"   , "m");
			tempUOMHMap.put("MGR" , "mg");
			tempUOMHMap.put("ML"  , "ml");
			tempUOMHMap.put("MMT" , "mm");
			tempUOMHMap.put("MT"  , "ton");
			tempUOMHMap.put("N"   , "N");
			tempUOMHMap.put("PC"  , "Piece");
			tempUOMHMap.put("PL"  , "Pl");
			tempUOMHMap.put("ROL" , "Roll");
			tempUOMHMap.put("SET" , "Set");
			tempUOMHMap.put("SH"  , "Sheet");
			tempUOMHMap.put("SM"  , "m²");
			tempUOMHMap.put("UN"  , "unit");
			tempUOMHMap.put("DRM" , "drum");
			
			int lineNumber = 1;      
			int subPartCount = 0;
			
			String strPreviousPartNo = null;
			String strPreviousPartRevision = null;
			String strPreviousPartType = null;
			
			
			while ((data = bufferReader.readLine()) != null) {
				
				StringBuffer sbErrorMessage = new StringBuffer("");
				MqlUtil.mqlCommand(context, "trigger off");
				checkTriggerOff = true;
				checkAddPart = false;
				StringList stListData = FrameworkUtil.split(data, "\t");
				try {
					
					if (lineNumber == 1) {
						stListHeader = stListData;
						writeFailToFile("errorRecord \t"+data);
						lineNumber++;
						continue;
					}
					lineNumber++;
					totalCount++;
					LinkedHashMap<String, Object> partHM = new LinkedHashMap<String, Object>();
					int size_Data = stListData.size();
					int size_Header = stListHeader.size();
					if (size_Data != size_Header) {
						String errorMessage = " NOT MATCH DATA FIELD";
						throw new Exception(errorMessage);
					}

					for (int stListNum = 0; stListNum < stListData.size(); stListNum++) {

						String sPartInfos = cdmCommonExcel.isVaildNullData((String)stListData.get(stListNum));
						String sPartHeader = ((String) stListHeader.get(stListNum)).trim();
						partHM.put(sPartHeader, sPartInfos);
						
					}
					
					String stPartType                   = TYPE_CDMMECHANICALPART;  
					String stPartCount                  = ((String)partHM.get("#"            		        )).trim(); // 1 순번 
					String stCLS_NAME                   = ((String)partHM.get("CLS_NAME"                    )).trim(); // 2 
					String stOBJECT_ID                  = ((String)partHM.get("OBJECT_ID"                   )).trim(); // 3 //받은 자료에 unique 값 migration대상아님 
	
					String stCN_ID                      = ((String)partHM.get("CN_ID"  	                    )).trim(); // 5 Name
					String stREVISION                   = ((String)partHM.get("REVISION"                    )).trim(); // 6 Revision
					String stSTATE                      = ((String)partHM.get("STATE"                       )).trim(); // 7 State
					String stCREATION_DATE              = ((String)partHM.get("CREATION_DATE"               )).trim(); // 8  attribute[cdmPartCreationDateM]
					String stUSER_OBJECT_ID             = ((String)partHM.get("USER_OBJECT_ID"              )).trim(); // 9  attribute[cdmPartCreationUserIdM]
					String stUSER_ID_MOD                = ((String)partHM.get("USER_ID_MOD"                 )).trim(); // 10 attribute[cdmPartModUserIdM]
					String stMODIFICATION_DATE          = ((String)partHM.get("MODIFICATION_DATE"           )).trim(); // 11 attribute[cdmPartModificationDateM] 
					String stTDM_DESCRIPTION            = ((String)partHM.get("TDM_DESCRIPTION"             )).trim(); // 12 attribute[cdmPartName]
					String stTDM_UOM                    = ((String)partHM.get("TDM_UOM"  			        )).trim(); // 13 attribute[cdmPartUOM]
					String stPhaseM                     = ((String)partHM.get("PHASE"                       )).trim(); // 14 
					String stPAR_REVISION               = ((String)partHM.get("PAR_REVISION"                )).trim(); // 15 Previous Revision
	//				String stAPPROVAL_DATE              = ((String)partHM.get("APPROVAL_DATE"               )).trim(); // 16 
	//				String stREVISION_STG               = ((String)partHM.get("REVISION_STG"                )).trim(); // 17 
					String stTDM_ORG_USER_ID            = ((String)partHM.get("TDM_ORG_USER_ID"             )).trim(); // 18 First Revision creator
	//				String stTDM_ORG_CREATEDATE         = ((String)partHM.get("TDM_ORG_CREATEDATE"          )).trim(); // 19 
	//				String stTDM_APPROVED_BY            = ((String)partHM.get("TDM_APPROVED_BY"             )).trim(); // 20 
	//				String stTDM_ORIGIN_ID              = ((String)partHM.get("TDM_ORIGIN_ID"               )).trim(); // 21 
					String stCN_PROJECT                 = ((String)partHM.get("CN_PROJECT"                  )).trim(); // 22 PROJECT
					String stCN_PROJECT_CUST            = ((String)partHM.get("CN_PROJECT_CUST"             )).trim(); // 23 PROJECT_CUST
	//				String stCN_PRODUCT_NAME            = ((String)partHM.get("CN_PRODUCT_NAME"             )).trim(); // 24 
	//				String stCN_PART_GROUP              = ((String)partHM.get("CN_PART_GROUP"               )).trim(); // 25 
	//				String stCN_PART_NAME               = ((String)partHM.get("CN_PART_NAME"                )).trim(); // 26
	//				String stCN_WEIGHT                  = ((String)partHM.get("CN_WEIGHT"                   )).trim(); // 27
					String stCN_ESTIMATED_WEIGHT        = ((String)partHM.get("CN_ESTIMATED_WEIGHT"         )).trim(); // 28 attribute[cdmPartEstimatedWeight] 
					String stCN_WEIGHT_UNIT             = ((String)partHM.get("CN_WEIGHT_UNIT"              )).trim(); // 29
					String stCN_TOP_ITEM                = ((String)partHM.get("CN_TOP_ITEM"                 )).trim(); // 30
					String stCN_PHANTOM_ITEM            = ((String)partHM.get("CN_PHANTOM_ITEM"             )).trim(); // 31
					String stCN_ITEM_TYPE               = ((String)partHM.get("CN_ITEM_TYPE"                )).trim(); // 32
					String stCN_SERVICE_ITEM            = ((String)partHM.get("CN_SERVICE_ITEM"             )).trim(); // 33
					String stCN_ITEM_MATERIAL           = ((String)partHM.get("CN_ITEM_MATERIAL"            )).trim(); // 34
					String stCN_ITEM_UPDATE_FROM_ERP    = ((String)partHM.get("CN_ITEM_UPDATE_FROM_ERP"     )).trim(); // 35
					String stCN_COST                    = ((String)partHM.get("CN_COST"                     )).trim(); // 36
					String stCN_CURRENCY                = ((String)partHM.get("CN_CURRENCY"                 )).trim(); // 37
					//String stCN_COMMENTS              = ((String)partHM.get("CN_COMMENTS"                 )).trim(); // 38
					String stCN_OEM_PART_NUMBER         = ((String)partHM.get("CN_OEM_PART_NUMBER"          )).trim(); // 39
					String stEC_NAME                    = ((String)partHM.get("EC_NAME"                     )).trim(); // 40
					String stCN_ECO_NUMBER              = ((String)partHM.get("CN_ECO_NUMBER"               )).trim(); // 41
					String stCN_PRODUCT_GROUP           = ((String)partHM.get("CN_PRODUCT_GROUP"            )).trim(); // 42
					String stCN_SERIES_ITEM             = ((String)partHM.get("CN_SERIES_ITEM"              )).trim(); // 43
					String stCN_VEHICLE                 = ((String)partHM.get("CN_VEHICLE"                  )).trim(); // 44
					String stCN_CUSTOMER                = ((String)partHM.get("CN_CUSTOMER"                 )).trim(); // 45
					String stCN_SIZE                    = ((String)partHM.get("CN_SIZE"                     )).trim(); // 46
					String stCN_SURFACE_TREATMENT       = ((String)partHM.get("CN_SURFACE_TREATMENT"        )).trim(); // 47
					String stCN_SURFACE_AREA            = ((String)partHM.get("CN_SURFACE_AREA"             )).trim(); // 48
					String stCN_ITEM_TYPE1              = ((String)partHM.get("CN_ITEM_TYPE1"               )).trim(); // 49
					String stCN_MATERIAL               = ((String)partHM.get("CN_MATERIAL"                  )).trim(); // 50
					String stCN_ORG1                   = ((String)partHM.get("CN_ORG1"                      )).trim(); // 51  migration 대상 제외  
	//				String stCN_ORG2                   = ((String)partHM.get("CN_ORG2"                      )).trim(); // 52  migration 대상 제외 
	//				String stCN_ORG3                   = ((String)partHM.get("CN_ORG3"                      )).trim(); // 53  migration 대상 제외 
					String stCN_ORG                    = ((String)partHM.get("CN_ORG"                       )).trim(); // 54  MCA Org
					String stCN_MCA_INOUT              = ((String)partHM.get("CN_MCA_INOUT"                 )).trim(); // 55  MCA BOM Management
					String stCN_MCA_PART_TYPE_REF      = ((String)partHM.get("CN_MCA_PART_TYPE_REF"         )).trim(); // 56  MCA Part Type
					String stCN_OPTION1                = ((String)partHM.get("CN_OPTION1"                   )).trim(); // 57
					String stCN_OPTION2                = ((String)partHM.get("CN_OPTION2"                   )).trim(); // 58
					String stCN_OPTION3                = ((String)partHM.get("CN_OPTION3"                   )).trim(); // 59
					String stCN_OPTION4                = ((String)partHM.get("CN_OPTION4"                   )).trim(); // 60
					String stCN_OPTION5                = ((String)partHM.get("CN_OPTION5"                   )).trim(); // 61
					String stCN_OPTION6                = ((String)partHM.get("CN_OPTION6"                   )).trim(); // 62
					String stCN_OPTION7                = ((String)partHM.get("CN_OPTION7"                   )).trim(); // 63
					String stCN_OPTION_ETC             = ((String)partHM.get("CN_OPTION_ETC"                )).trim(); // 64
					String stCN_IS_CASTING             = ((String)partHM.get("CN_IS_CASTING"                )).trim(); // 65
					String stCN_OPTION_DESC            = ((String)partHM.get("CN_OPTION_DESC"               )).trim(); // 66
					String stCN_FOR_MAC                = ((String)partHM.get("CN_FOR_MAC"                   )).trim(); // 67
					String stCN_FOR_MIL                = ((String)partHM.get("CN_FOR_MIL"                   )).trim(); // 68
					String stCN_FOR_MIS                = ((String)partHM.get("CN_FOR_MIS"                   )).trim(); // 69
					String stCN_FOR_MMT                = ((String)partHM.get("CN_FOR_MMT"                   )).trim(); // 70
					String stCN_REAL_WEIGHT            = ((String)partHM.get("CN_REAL_WEIGHT"               )).trim(); // 71
					String stCN_COUNTRY                = ((String)partHM.get("CN_COUNTRY"                   )).trim(); // 72
					String stCN_PRODUCT_DIV            = ((String)partHM.get("CN_PRODUCT_DIV"               )).trim(); // 73
					String stCN_GLOBAL_LOCAL           = ((String)partHM.get("CN_GLOBAL_LOCAL"              )).trim(); // 74
					String stCN_PROJECT_CODE           = ((String)partHM.get("CN_PROJECT_CODE"              )).trim(); // 75
					String stCN_OPTION_DRAWING         = ((String)partHM.get("CN_OPTION_DRAWING"            )).trim(); // 76
					String stCN_FOR_DRAWING_FINISH     = ((String)partHM.get("CN_FOR_DRAWING_FINISH"        )).trim(); // 77
					String stCN_FOR_DRAWING_SIZE       = ((String)partHM.get("CN_FOR_DRAWING_SIZE"          )).trim(); // 78
					String stCN_FOR_DRAWING_REMARK     = ((String)partHM.get("CN_FOR_DRAWING_REMARK"        )).trim(); // 79
					String stCN_ITEM_TYPE2              = ((String)partHM.get("CN_ITEM_TYPE2"               )).trim(); // 80
					String stCN_APPLY_PARTLIST          = ((String)partHM.get("CN_APPLY_PARTLIST"           )).trim(); // 81
//					String stCN_PREVIOUS_PART           = ((String)partHM.get("CN_PREVIOUS_PART"            )).trim(); // 82
					String stCN_COMPLEX_BODY            = ((String)partHM.get("CN_COMPLEX_BODY"             )).trim(); // 83
					String stCN_MAIN_PART_NUMBER        = ((String)partHM.get("CN_MAIN_PART_NUMBER"         )).trim(); // 84
					String stCN_VEHICLE_DESC            = ((String)partHM.get("CN_VEHICLE_DESC"             )).trim(); // 85 VEHICLE 
					String stCN_VEHICLE_CODE            = ((String)partHM.get("CN_VEHICLE_CODE"             )).trim(); // 86
					String stVehicle_Cust               = ((String)partHM.get("VEHICLE_CUST"                )).trim(); // 87
					String stCN_DRAWING_NO              = ((String)partHM.get("CN_DRAWING_NO"               )).trim(); // 88 DRAWING_NO
					String stCN_SUB_ID         		    = ((String)partHM.get("CN_SUB_ID"                   )).trim(); // 89
	//				//String stCN_CHANGE_REASON 	        = ((String)partHM.get("CN_CHANGE_REASON"            )).trim(); // 90 다른 데이타 파일로 진행 예정 
					String stCN_SURFACE_TREATMENT_KEYIN = ((String)partHM.get("CN_SURFACE_TREATMENT_KEYIN"  )).trim(); // 91
					String stCN_OVERSEAS_ORG6           = ((String)partHM.get("CN_OVERSEAS_ORG6"            )).trim(); // 92
					String stCN_OVERSEAS_ORG6_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG6_PART_TYPE"  )).trim(); // 93
					String stCN_OVERSEAS_ORG6_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG6_INOUT"      )).trim(); // 94
//					String stCN_OVERSEAS_ORG7           = ((String)partHM.get("CN_OVERSEAS_ORG7"            )).trim(); // 95
//					String stCN_OVERSEAS_ORG7_PART_TYPE = ((String)partHM.get("CN_OVERSEAS_ORG7_PART_TYPE"  )).trim(); // 96
//					String stCN_OVERSEAS_ORG7_INOUT     = ((String)partHM.get("CN_OVERSEAS_ORG7_INOUT"      )).trim(); // 97

					String stCN_Project_Id			    = ((String)partHM.get("CN_PROJECT_ID"  )).trim(); // 98
					String stAccessProductGroup		    = ((String)partHM.get("PROD_GROUP"  )).trim(); // 99
					String stAceesOrg				    = ((String)partHM.get("CN_CUST_VEHICLE"  )).trim(); // 100
					if("-".equals(stAceesOrg)){
						stAceesOrg = "";
					}
					String stCADWeight					= ""; 
					
					String stGLOBAL_LOCAL = "";
//					String stITEM_TYPE2 = "";
					String stFOR_DRAWING_REMARK = "";
					String stOPTION_ETC = stCN_OPTION_ETC;
					String stOPTION_DESC = stCN_OPTION_DESC;
					String stPartInvestor =   "";
					String stESTIMATED_WEIGHT = "";
					String stITEM_TYPE1 = "";
					String stITEM_TYPE = "";
					String stSERIES_ITEM = "";
					String stPhase = "";
					
					String stPartCADWeight = ""; /*아직 데이타가 없음 속성 정보 재요청 필요 */
					subPartCount = Integer.parseInt(stPartCount);
					tempStRowNum = stPartCount;
					tempStPartNo = stCN_ID;
					tempStPartRevision = stREVISION;
					String personIdMql = "temp query bus Person '" + stTDM_ORG_USER_ID + "' - select id dump |";
					String personIdMqlResult = MqlUtil.mqlCommand(context, personIdMql);
					StringList stListPersonIdMql = FrameworkUtil.split(personIdMqlResult, "|");
					String stPerson = "";
					boolean boolPerson = false;
					if (stListPersonIdMql.size() > 2) {
						stPerson = (String) stListPersonIdMql.get(3);
						boolPerson = true;
					}
					
					
					/*  **************************************************************************************
					 *   stCLS_NAME 정보가 "Option Item" 이라면 CN_SUB_ID 정보를 CN_ID에 합쳐야한다. 
					 *  ************************************************************************************ */
					if("Option Item".equalsIgnoreCase(stCLS_NAME)){
						if(cdmStringUtil.isNotEmpty(stCN_SUB_ID)){
							stCN_ID +=stCN_SUB_ID;
						}
					}
					
					/* **************************************************************************************
					 * cdmPartGlobal 의 정보는 global,local 값이 없으면 ""  처리 
					 * ************************************************************************************* */
					for (int i = 0; i < attrPartGlobalKOList.size(); i++) {
	
						if (stCN_GLOBAL_LOCAL.equalsIgnoreCase((String) attrPartGlobalKOList.get(i))) {
							stGLOBAL_LOCAL = (String) attrPartGlobalList.get(i);
							break;
						}
					}
					if(cdmStringUtil.isEmpty(stGLOBAL_LOCAL)){
						stGLOBAL_LOCAL = "";
					}
					
					/*  **************************************************************************************
					 *   stCN_ITEM_TYPE2 의 정보는 
					 *   attribute[cdmPartItemType]관련 정보
					 *   
					 *   attribute[cdmPartItemType]의 display name과 일치하지않다면 에러 처리  
					 *  ************************************************************************************** */
//					boolean bITEM_TYPE2 = false;
//					for (int i = 0; i < attrPartItemTypeKOList.size(); i++) {
//	
//						if (stCN_ITEM_TYPE2.equals((String) attrPartItemTypeKOList.get(i))) {
//							stITEM_TYPE2 = (String) attrPartItemTypeList.get(i);
//							bITEM_TYPE2 = true;
//							break;
//						}
//						
//					}
					
					/* *****************************************************************************************
					 * stCN_FOR_DRAWING_REMARK 의 정보는 Part 의 한글 속성과 일치 
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					if(cdmStringUtil.isNotEmpty(stCN_FOR_DRAWING_REMARK) ){
						for (int i = 0; i < attrPartERPInterfaceKOList.size(); i++) {
	
							if (stCN_FOR_DRAWING_REMARK.equals((String) attrPartERPInterfaceKOList.get(i))) {
								stFOR_DRAWING_REMARK = (String) attrPartERPInterfaceList.get(i);
								break;
							}
						}
					}
					
					
					/* *****************************************************************************************
					 * CDM 의 UOM 과 전달받은 UOM 은 정보는 달라 기준정보 (MAP )로 찾아 데이타를 입력한다.
					 * 만약에 데이타가 일치하지않거나 정보가 없을시 "" 값으로 진행된다.
					 * *****************************************************************************************/
					String sTempUOM = "";
					sTempUOM= (String)tempUOMHMap.get(stTDM_UOM);
					sTempUOM = cdmCommonExcel.isVaildNullData(sTempUOM);
					
					
					/* ******************************************************************************************************************
					 * stPartInvestor 의경우 
					 * stCN_FOR_MAC ,stCN_FOR_MIL,stCN_FOR_MMT 의 정보가 checked 되어 있는지여부를 확인하여 하나의 String 값으로 만듬 
					 * ****************************************************************************************************************   */
					if("Checked".equals(stCN_FOR_MAC)){
						stPartInvestor = "MAC";
					}
					if("Checked".equals(stCN_FOR_MIL)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MIL";
					}
					if("Checked".equals(stCN_FOR_MMT)){
						if(cdmStringUtil.isNotEmpty(stPartInvestor)){
							stPartInvestor +=",";
						}
						stPartInvestor += "MMT";
					}
	
					
					/* ******************************************************************************************************************
					 *  attribute[cdmPartEstimateWeightUnit] 중량 단위 
					 *  넘어오는 데이타의 데이타가 없으면  attribute[cdmPartEstimateWeightUnit] 속성값은 G 로 입력된다 .
					 *  (넘어오는 데이타가 default 중량단위는 G )
					 * ****************************************************************************************************************** */
					String sTempWeightUnit = "";
					if("".equals(stCN_WEIGHT_UNIT)){
						sTempWeightUnit = "G";
					}else {
						//중량단위를 kg로 변환 !!
						if("g".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "G";
						}else if("lb".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "LBR";
						}else if("mg".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "MGR";
						}else if("ton".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "MT";
						}else if("N".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "N";
						}else if("kg".equalsIgnoreCase(stCN_WEIGHT_UNIT)){
							sTempWeightUnit = "KG";
						}
						
					}
					
					/* *************************************************************************************
					 *   stCN_ORG1 가 PROTO 이면 stPhase 값은 proto 
					 *   stCN_PHANTOM_ITEM 가 체크되어있으면 파트 타입으로 "Phantom Part"변경
					 *   stPhase 여부와 상관없이 반드시 Proto 로 변경된다. 
					 * *********************************************************************************** */
					if("PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPhase = S_ATTRIBUTE_PHASE_PROTO;
					}else{
						stPhase = S_ATTRIBUTE_PHASE_PRODUCTION;
					}
					
					if( "Checked".equalsIgnoreCase(stCN_PHANTOM_ITEM) &&  "PROTO".equalsIgnoreCase(stCN_ORG1)){
						stPartType = "cdmPhantomPart";
						stPhase = S_ATTRIBUTE_PHASE_PROTO; //변경요청
					}
					
					
					
					/* *************************************************************************************
					 * stITEM_TYPE1 은  cdmPartApprovalType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					if("자작".equals(stCN_ITEM_TYPE1)){
						stITEM_TYPE1 = "inSourcing";
					}else if("외주".equals(stCN_ITEM_TYPE1)){
						stITEM_TYPE1 = "outSourcing";
					}else{
						stITEM_TYPE1 = "";
					}
					
					
					
					/* *************************************************************************************
					 * stITEM_TYPE 은  cdmPartType 속성 정보와 일치 여부 확인 후
					 * 일치하지 않으면 데이타는 "" 로 처리된다. 
					 * *********************************************************************************** */
					stITEM_TYPE = "";
//					for (int attrPartTypeNum = 0; attrPartTypeNum < attrPartTypeKOList.size(); attrPartTypeNum++) {
//						String temPattrPartTypeKO = (String) attrPartTypeKOList.get(attrPartTypeNum);
//						if (stCN_ITEM_TYPE.equals(temPattrPartTypeKO)) {
//							stITEM_TYPE = (String) attrPartTypeList.get(attrPartTypeNum);
//							break;
//						}
//					}
					
					//
					if("단품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "singleSupply";
					}else if("완제품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "completeProduct";
					}else if("반제품".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "halfFinishedProduct";
					}else if("원부자재".equals(stCN_ITEM_TYPE)){
						stITEM_TYPE = "rawMaterial";
					}
					
					/* *************************************************************************************
					 * SERIES_ITEM 값이 Checked 이면 true unChecked 이면 false 
					 * *********************************************************************************** */
					if("Checked".equalsIgnoreCase(stCN_SERIES_ITEM)){
						stSERIES_ITEM = "true"; 
					}else{
						stSERIES_ITEM = "false";
					}
					
					/*stCN_SURFACE_TREATMENT 은 사용되지않아 "" 처리한다. */
					String stSURFACE_TREATMENT = ""; 
					
					/*stCN_IS_CASTING*/
					String stIS_CASTING = "";
					if(!"0".equals(stCN_IS_CASTING)){
						stIS_CASTING = "yes";
					}else{
						stIS_CASTING = "no";
					}
					
					
					/*stCN_FOR_DRAWING_FINISH*/
					String stCFOR_DRAWING_FINISH = "";
					if("0".equals(stCN_FOR_DRAWING_FINISH)){
						stCFOR_DRAWING_FINISH = "unChecked";
					}else{
						stCFOR_DRAWING_FINISH = "Checked";
					}
					
					/*stCN_FOR_DRAWING_SIZE*/
					String stDRAWING_SIZE = "";
					if("0".equals(stCN_FOR_DRAWING_SIZE)){
						stDRAWING_SIZE = "unChecked";
					}else{
						stDRAWING_SIZE = "Checked";
					}
					
					HashMap attributes = new HashMap();
					if(UIUtil.isNotNullAndNotEmpty(stPhaseM)){
						attributes.put("cdmPartPhaseM", 		 	  stPhaseM		                   );
					}
			        attributes.put("cdmPartNo",          	      stCN_ID 			               );
//			        attributes.put("cdmPartVehicle", 	 	      stCN_VEHICLE_DESC		           );
			        attributes.put("cdmPartName", 		 	      stTDM_DESCRIPTION	               );
//			        attributes.put("cdmPartProject", 	 	      stCN_PROJECT		               );
			        attributes.put("cdmPartApprovalType", 	      stITEM_TYPE1	                   );
			        attributes.put("cdmPartType", 		          stITEM_TYPE	                   );
			        attributes.put("cdmPartGlobal", 			  stGLOBAL_LOCAL                   );
			        attributes.put("cdmPartDrawingNo", 			  stCN_DRAWING_NO                  );
//			        attributes.put("cdmPartUOM",     		      stTDM_UOM                        );
			        attributes.put("cdmPartUOM",     		      sTempUOM                        );
//			        데이타가 깨진것이 있어 추후 cdmPartUOM 값을 변경해야함 12/06/16 12:19:00 이후 마이그레이션 대상으로
//			        attributes.put("cdmPartUOM_TempM",     		      stTDM_UOM                        );
			        attributes.put("cdmPartECONumber", 			  stCN_ECO_NUMBER                  );
			        attributes.put("cdmPartItemType", 			  stCN_ITEM_TYPE2                  );
			        attributes.put("cdmPartOEMItemNumber", 		  stCN_OEM_PART_NUMBER             );
			        attributes.put("cdmPartProductType", 		  stCN_PRODUCT_DIV                 );
			        attributes.put("cdmPartERPInterface", 		  stFOR_DRAWING_REMARK             );
			        attributes.put("cdmPartSurface", 			  stCN_SURFACE_AREA                );
//			        attributes.put("cdmPartEstimatedWeight", 	  stESTIMATED_WEIGHT               );
			        attributes.put("cdmPartEstimatedWeight", 	  stCN_ESTIMATED_WEIGHT            );
			        attributes.put("cdmPartMaterial", 			  stCN_ITEM_MATERIAL               );
			        attributes.put("cdmPartRealWeight", 		  stCN_REAL_WEIGHT                 );
			        attributes.put("cdmPartSize", 				  stCN_SIZE                        );
			        attributes.put("cdmPartCADWeight", 			  stPartCADWeight                  );
			        attributes.put("cdmPartSurfaceTreatment", 	  stSURFACE_TREATMENT              );
			        attributes.put("cdmPartIsCasting", 			  stIS_CASTING                     );
//			        attributes.put("cdmPartOption1", 			  stCN_OPTION1                     );
//			        attributes.put("cdmPartOption2", 			  stCN_OPTION2                     );
//			        attributes.put("cdmPartOption3", 			  stCN_OPTION3                     );
//			        attributes.put("cdmPartOption4", 			  stCN_OPTION4                     );
//			        attributes.put("cdmPartOption5", 			  stCN_OPTION5                     );
//			        attributes.put("cdmPartOption6", 		   	  stCN_OPTION6                     );
			        attributes.put("cdmPartOptionETC",         	  stOPTION_ETC               	   );
			        attributes.put("cdmPartOptionDescription", 	  stOPTION_DESC            		   );
			        attributes.put("cdmPartPublishingTarget",     stCN_COST                        );
			        attributes.put("cdmPartInvestor",          	  stPartInvestor                   );
//			        attributes.put("cdmPartProjectType",          stCN_PRODUCT_GROUP               ); // 
//			        attributes.put("cdmPartProductDivision",      stCN_PRODUCT_GROUP               ); //?? 확인 작업이 필요 
					
			        /*migration을 작업을 위해 attribute 추가 start */
			        attributes.put("cdmPartItemOtionItemM",        stCLS_NAME                      );
			        attributes.put("cdmPartPreviousRevisionM",     stPAR_REVISION                  );
			        attributes.put("cdmPartCheckPhantomPartM",     stCN_PHANTOM_ITEM   	           );
			        attributes.put("cdmPartECNameM",               stEC_NAME    	               );
			        attributes.put("cdmPartSeriesItemM",           stSERIES_ITEM                   );
			        attributes.put("cdmPartMCAOrgM",               stCN_ORG      	               );
			        attributes.put("cdmPartMCABOMManagementM",     stCN_MCA_INOUT        	       );
			        attributes.put("cdmPartMCAPartTypeM",          stCN_MCA_PART_TYPE_REF          );
			        attributes.put("cdmPartOption7",          	   stCN_OPTION7                    );
			        attributes.put("cdmPartCountryM",          	   stCN_COUNTRY                    );
			        attributes.put("cdmPartDrawingFinishM",        stCFOR_DRAWING_FINISH           );
			        attributes.put("cdmPartDrawingSizeM",          stDRAWING_SIZE                  );
			        attributes.put("cdmPartApplyPartListM",        stCN_APPLY_PARTLIST             );
			        attributes.put("cdmPartSubIdM",                stCN_SUB_ID                     );
			        attributes.put("cdmPartMCPOrgM",          	   stCN_OVERSEAS_ORG6              );
			        attributes.put("cdmPartMCPPartTypeM",          stCN_OVERSEAS_ORG6_PART_TYPE    );
			        attributes.put("cdmPartMCPBOMManagementM",     stCN_OVERSEAS_ORG6_INOUT 	   );  
			        attributes.put("cdmPartCreationDateM",        stCREATION_DATE     	           );  
			        attributes.put("cdmPartCreationUserIdM",      stUSER_OBJECT_ID  	           );  
			        attributes.put("cdmPartModUserIdM",           stUSER_ID_MOD  	               );  
			        attributes.put("cdmPartModificationDateM",    stMODIFICATION_DATE  	           );  
			        attributes.put("cdmPartComplexBodyForRealWeightM",  stCN_COMPLEX_BODY          );
			        attributes.put("cdmCheckMigration",           "Y"					  	       );
			        attributes.put("cdmPartPhase",           	   stPhase			  	       	   );
			        //add attribute 11/17/2016 start 
			        attributes.put("cdmPartApplyPartList",           "true"				  	       );
			        attributes.put("cdmPartApplySizeList",           "false"			  	       );
			        attributes.put("cdmPartApplySurfaceTreatmentList", "false"	  				   );
//			        //add attribute 11/17/2016 end 
			        attributes.put("cdmPartEstimateWeightUnit", sTempWeightUnit			   );
			        
			        /*migration을 작업을 위해 attribute 추가 end  */
			        
			      
			        /* **********************************************************************************************************************
			         * part 데이타 생성 및 데이타 
			         * 트리거 오프한 상태로 진행되며 트리거에서 제공되는 attribute[originator]속성 및 interface 추가 설정 필터 정보 와 
			         * rev 정보 part master 생성 및 연결 및 속성(attribute[Originator]속성 추가 
			         * 에러 발생시 정지 및 데이타 정보 검색 
			         * ******************************************************************************************************************* */
//			        if(UIUtil.isNullOrEmpty(stCN_OPTION1) && UIUtil.isNullOrEmpty(stCN_OPTION2) && UIUtil.isNullOrEmpty(stCN_OPTION3) && UIUtil.isNullOrEmpty(stCN_OPTION3) && UIUtil.isNullOrEmpty(stCN_OPTION4) && UIUtil.isNullOrEmpty(stCN_OPTION5) && UIUtil.isNullOrEmpty(stCN_OPTION6)){
//			        	continue;
//			        	
//			        }
			        DomainObject partObj = new DomainObject();
			        
			        BusinessObject busPart = new BusinessObject(stPartType,stCN_ID,stREVISION,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        String partId = "";
			        if(busPart.exists(context)){
			        	partId = busPart.getObjectId(context);
			        	
			        	partObj.setId(partId);
			        	
			        }else{
			        	
			        	busPart = new BusinessObject("cdmPhantomPart",stCN_ID,stREVISION,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        	if(!busPart.exists(context)){
			        		busPart = new BusinessObject("cdmMechanicalPart",stCN_ID,stREVISION,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        	}
			        	partId = busPart.getObjectId(context);
			        	
			        	partObj.setId(partId);
			        	if(!busPart.exists(context)){
			        		throw new Exception("not exist part object .");
			        	}
			        }
			        
			        boolean bCommit = false;
//					partObj.createObject(context, stPartType, stCN_ID, stREVISION, cdmConstantsUtil.POLICY_CDM_PART_POLICY, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			        ContextUtil.startTransaction(context, true);
			
			       	partObj.setAttributeValues(context, attributes);
					bCommit = true;
					ContextUtil.commitTransaction(context);		
					MqlUtil.mqlCommand(context, "trigger on");
					checkTriggerOff = false;	
						
//					if(cdmStringUtil.isNotEmpty(sbErrorMessage.toString())){
//						writeSuccessToFile("LineNum(#): \t "+subPartCount +" \t PartNo: \t "+tempStPartNo+"\t "+sbErrorMessage.toString());	
						writeSuccessToFile(cdmCommonExcel.getTimeStamp() +"\t"+ subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+sTempWeightUnit+"\t"+ sbErrorMessage.toString());	
//					}else{
//							writeSuccessToFile("LineNum(#): "+subPartCount +" \t PartNo: \t "+tempStPartNo+" \t ");
//						writeSuccessToFile(cdmCommonExcel.getTimeStamp()+"\t"+subPartCount +"\t"+tempStPartNo+"\t"+stREVISION);
//						writeSuccessToFile(cdmCommonExcel.getTimeStamp() +"\t"+ subPartCount +" \t "+tempStPartNo+"\t"+ stREVISION+"\t "+sTempWeightUnit+"\t"+sbErrorMessage.toString());
//							
//					}
						
					successCount++;
						
				} catch (Exception e) {
					ContextUtil.abortTransaction(context);

//					if(!checkAddPart){
//						MQLCommand mqlCommand = new MQLCommand();
//						mqlCommand.open(context);
//						mqlCommand.executeCommand(context, "abort transaction $1","PartFamily");
//					}
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "trigger on");
						checkTriggerOff = false;			
					}
					failCount++;
					writeErrorToFile("LineNum(#) \t"+tempStRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t "+ tempStPartNo+"\t"+tempStPartRevision +"\t"+e.getMessage().replaceAll("\r|\n", "")); 
					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t" +  data ) ;
					e.printStackTrace(errorStream);
					
					writeShotErrorToFile("LineNum(#) \t"+tempStRowNum + " \t"+cdmCommonExcel.getTimeStamp2()+"\t "+tempStPartNo+"\t"+tempStPartRevision +"\t"+e.toString().replaceAll("\r|\n", ""));
				}finally{
					
				}
				
			} // end of while 
			
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================");
			//
		} catch (Exception e1) {
			writeFailToFile(" LineNum(#):"+tempStRowNum);
			writeErrorToFile("LineNum(#):"+tempStRowNum + "  "+e1.getMessage());
			e1.printStackTrace(errorStream);
			
			
		}finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("	add attribute PART OBJECT CLOSE TIME:  "+cdmCommonExcel.getTimeStamp2()+"          "  );
			writeMessageToConsole("	add attribute PART OBJECT LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
			writeMessageToConsole("	FAILCOUNT:("+failCount +") SUCCESSCOUNT:("+successCount+") TOTALCOUNT :("+totalCount+")"  );
			writeMessageToConsole("==================================================================================== \n");
			MqlUtil.mqlCommand(context, "history on");
			if(checkTriggerOff){
				MqlUtil.mqlCommand(context, "trigger on");
			}
			try {
				if (null != errorStream )
					errorStream .close();

				if (null != logWriter)
					logWriter.close();

				if (null != failedObjectidWriter)
					failedObjectidWriter.close();
				
				if (null != successObjectidWriter)
					successObjectidWriter.close();

				if(null != bufferReader)
					bufferReader.close();
				
				if(null != errorLogFile)
					errorLogFile.close();
				
				if(null != debugLogFile)
					debugLogFile.close();

				if(null != errorLogFile)
					errorLogFile.close();
			} catch (IOException e) {
				System.out.println("Exception while closing log stream " + e.getMessage());
			}
			
			
			long endTime = System.currentTimeMillis();
			long leadTime = (endTime-startTime)/1000/60;
			System.out.println("cdmPartMigration : addAttributeTemp End.   endTime: "+cdmCommonExcel.getTimeStamp()  + " leadTime :"+leadTime);
			
		}
    	
    
    }
    
}


