/*
**  DSCWebFormActionsLink
**
**  Copyright Dassault Systemes, 1992-2007.
**  All Rights Reserved.
**  This program contains proprietary and trade secret information of Dassault Systemes and its 
**  subsidiaries, Copyright notice is precautionary only
**  and does not evidence any actual or intended publication of such program
**
**  Program to display Action Icons
*/
import java.util.HashMap;
import java.util.Hashtable;

import com.mando.util.cdmConstantsUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.MCADServerSettings;
import com.matrixone.MCADIntegration.server.beans.IEFIntegAccessUtil;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADAppletServletProtocol;
import com.matrixone.MCADIntegration.utils.MCADGlobalConfigObject;
import com.matrixone.MCADIntegration.utils.UUID;

import matrix.db.BusinessObject;
import matrix.db.BusinessObjectList;
import matrix.db.Context;
import matrix.db.JPO;

 
public class DSCWebFormActionsLink_mxJPO extends DSCWebFormActionsLinkBase_mxJPO
{		
    /**
	   * Constructor.
	   *
	   * @param context the eMatrix <code>Context</code> object
	   * @param args holds no arguments
	   * @throws Exception if the operation fails
	   * @since Sourcing V6R2008-2
	   */
	public DSCWebFormActionsLink_mxJPO (Context context, String[] args) throws Exception
	{
	  super(context, args);
	}

//	public String getHtmlString(Context context, String[] args) throws Exception
//	{
//		StringBuffer htmlBuffer			= new StringBuffer(300);
//
//		paramMap						= (HashMap)JPO.unpackArgs(args);  
//		HashMap requestMap				= (HashMap)paramMap.get("requestMap");
//		String objectId					= (String)requestMap.get("objectId");
//		attrIsVersionObject				= MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
//		attrSource						= MCADMxUtil.getActualNameForAEFData(context, "attribute_Source");
//		String validObjectId			= "";
//
//		try
//		{
//			localeLanguage			= (String)requestMap.get("languageStr");
//			serverResourceBundle	= new MCADServerResourceBundle(localeLanguage);
//			cache					= new IEFGlobalCache();
//			util					= new IEFIntegAccessUtil(context, serverResourceBundle, cache);
//			_mxUtil			 		= new MCADMxUtil(context, serverResourceBundle, cache);
//
//			HashMap attributeMap	= jpoUtil.getCommonDocumentAttributes(context,  objectId);
//			
//			BusinessObject busObj	= new BusinessObject(objectId);
//			busObj.open(context);
//			String majorObjectId	= objectId;
//
//			// to get the ECO connected List
//			Hashtable emptyHashtable	= new Hashtable();
//			String sRelName				= MCADMxUtil.getActualNameForAEFData(context,"relationship_NewSpecificationRevision");
//			BusinessObjectList busList	= util.getRelatedBusinessObjects(context, busObj, sRelName,"to",emptyHashtable);
//
//			if(busList != null && busList.size() == 0)
//			{
//				sRelName	= MCADMxUtil.getActualNameForAEFData(context,"relationship_AffectedItem");
//				busList		= util.getRelatedBusinessObjects(context, busObj, sRelName,"to",emptyHashtable);
//				if(busList != null && busList.size() == 0){
//					sRelName	= MCADMxUtil.getActualNameForAEFData(context,"relationship_ChangeAffectedItem");
//					busList		= util.getRelatedBusinessObjects(context, busObj, sRelName,"to",emptyHashtable);
//				}
//			}
//
//			if (true == isVersionObject(attributeMap))
//			{
//				BusinessObject majorObject = util.getMajorObject(context, busObj);
//				majorObject.open(context);
//				majorObjectId = majorObject.getObjectId();
//				majorObject.close(context);
//			}
//
//			// [B] modify by jtkim 2017-02-06
//			// [ACTION-002] Remove Subscription
////			htmlBuffer.append(addSubscriptionLink(context, majorObjectId));
//			// [E] modify by jtkim 2017-02-06
//
//			//[IR_394600:MAL3]:START
//			if(majorObjectId.equalsIgnoreCase(objectId))
//				validObjectId = majorObjectId;
//			else
//				validObjectId = getViewerValidObjectId(context, attributeMap, objectId, majorObjectId);
//			//[IR_394600:MAL3]:END
//			
//			String integrationName = getIntegrationName(attributeMap);
//
//			if(integrationName != null && util.getAssignedIntegrations(context).contains(integrationName))
//			{
//				MCADGlobalConfigObject globalConfigObject = getGlobalConfigObject(context, objectId);
//
//				String mode   = (String)requestMap.get("mode");
//				
//				String jpoName	= globalConfigObject.getFeatureJPO("OpenFromWeb");
//
//				if(null != jpoName && !"".equals(jpoName))	
//				{
//					htmlBuffer.append(addOpenFromWebLink(context, globalConfigObject, integrationName, objectId, jpoName));
//				}
//				
//				// [NDM] QWJ
//				htmlBuffer.append(addDownloadStructureLink(context, objectId, isVersionObject(attributeMap)));
//				
//				// [NDM] : H68
//				if (false == isVersionObject(attributeMap))
//				htmlBuffer.append(addLockUnlockLink(context, majorObjectId,  integrationName, mode));
//
//				// Check for connected ECO and disply of ECO icon
//				if(busList != null && busList.size() > 0)
//				{
//					BusinessObject relatedObj	= null;
//					String ecoObjId = "" ;
//					String ecoObjType = "";
//					for(int j=0; j<busList.size(); j++)
//					{
//						relatedObj	= busList.getElement(j);
//						ecoObjType = relatedObj.getTypeName();
////						if(!"".equals(ecoObjType) && ecoObjType.equals("ECO"))
////						{
//							ecoObjId = relatedObj.getObjectId();
////						}
//					}	
//
//					if(!"".equals(ecoObjId))
//					{
////						htmlBuffer.append(addECOIconLink(context, ecoObjId));
//						htmlBuffer.append(addChangeMgmtIconLink(context, ecoObjId, ecoObjType));
//					}
//				}
//			}
//			else
//			{
//				htmlBuffer.append(addDownloadLink(context, objectId));
//			}
//
//			// [B] modify by jtkim 2017-01-25
//			// [AUTOVIEW-001] Fixed to show only the key type.
//			String busTypeName = busObj.getTypeName();
//			if (cdmConstantsUtil.TYPE_CDMNXDRAWING.equals(busTypeName)) htmlBuffer.append(addViewerLink(context, validObjectId));
//			// [E] modify by jtkim 2017-01-25
//
//			busObj.close(context);
//		}
//		catch(Exception e)
//		{
//		}
//
//		return htmlBuffer.toString();
//	}

	/**
	 * OOTB Override
	 * @param context
	 * @param globalConfigObject
	 * @param integrationName
	 * @param objectId
	 * @param jpoName
	 * @return
	 * @throws Exception
	 */
//	private String addOpenFromWebLink(Context context, MCADGlobalConfigObject globalConfigObject, String integrationName, String objectId, String jpoName) throws Exception
//	{
//		String returnVal = "";
//		try
//		{
//			Hashtable jpoArgsTable = new Hashtable();
//			jpoArgsTable.put(MCADServerSettings.GCO_OBJECT, globalConfigObject);
//			jpoArgsTable.put(MCADServerSettings.LANGUAGE_NAME, serverResourceBundle.getLanguageName());
//			jpoArgsTable.put(MCADServerSettings.OBJECT_ID, objectId);
//			jpoArgsTable.put(MCADAppletServletProtocol.INTEGRATION_NAME, integrationName);
//			jpoArgsTable.put(MCADServerSettings.OPERATION_UID, UUID.getNewUUIDString());
//			jpoArgsTable.put("featureName", MCADGlobalConfigObject.FEATURE_OPEN);
//
//			String[] args 			= JPO.packArgs(jpoArgsTable);
//
//			Hashtable result 		= (Hashtable) JPO.invoke(context, jpoName, new String[] {}, "execute", args, Hashtable.class);
//			String hrefLink			= (String) result.get("hrefString");
//
//			String href				= "../integrations/IEFCustomProtocolHandler.jsp?hreflink=" + hrefLink + "&amp;integrationname=" + integrationName;
//			String featureImage		= "iconActionCheckOut.gif";
//			String openToolTip		= serverResourceBundle.getString("mcadIntegration.Server.AltText.Open");
//
//			returnVal 				= getFeatureIconContent(href, featureImage, openToolTip, null, "listHidden");
//
//		}
//		catch(Exception e)
//		{
//			e.printStackTrace();
//		}
//		return returnVal;
//
//	}
//
//	/**
//	 * OOTB Override
//	 * @param context
//	 * @param objectId
//	 * @param isVersionedObject
//	 * @return
//	 */
//	private String addDownloadStructureLink(Context context, String objectId, boolean isVersionedObject)  // [NDM] QWJ
//	{
//		String downloadStructureToolTip	= serverResourceBundle.getString("mcadIntegration.Server.AltText.DownloadStructure");
//		
//		String downloadStructureURL			= "../integrations/DSCMCADGenericActionsProcess.jsp?action=DownloadStructure" + "&amp;Target Location=hiddenFrame" + "&amp;emxTableRowId=" + objectId + "&amp;isVersionedObject=" + isVersionedObject+"&amp;fromLocation=Table";
//		String downloadStructureIcon		= "../../common/images/iconActionDownload.gif";
//		
//		String url = getFeatureIconContent(downloadStructureURL, downloadStructureIcon, downloadStructureToolTip, null, "listHidden");
//		
//		return url;
//	}
}
