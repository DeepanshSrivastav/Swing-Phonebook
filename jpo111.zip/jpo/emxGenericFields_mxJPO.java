import matrix.db.Context;


public class emxGenericFields_mxJPO extends emxGenericFieldsBase_mxJPO {
	
    /**
     * @param context
     * @param args
     * @throws Exception
     */
    public emxGenericFields_mxJPO(Context context, String[] args) throws Exception {
    	super(context, args);
    }

}
