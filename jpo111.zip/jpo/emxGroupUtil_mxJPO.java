import matrix.db.Context;

// ${CLASS:emxGroupUti}.java
//
// Created on Aug 7, 2010
//
// Copyright (c) 2005 MatrixOne Inc.
// All Rights Reserved
// This program contains proprietary and trade secret information of
// MatrixOne, Inc.  Copyright notice is precautionary only and does
// not evidence any actual or intended publication of such program.
//

/**
 * @author sg2
 *
 * The <code>${CLASS:emxGroupUti}</code> class/interface contains ...
 *
 * @version AEF 11.0.0.0 - Copyright (c) 2005, MatrixOne, Inc.
 */
public class emxGroupUtil_mxJPO extends emxGroupUtilBase_mxJPO {

    public emxGroupUtil_mxJPO(Context context, String[] args) throws Exception {
        super(context, args);
        // TODO Auto-generated constructor stub
    }

    /**
     * 
     */
    private static final long serialVersionUID = 1L;

}
