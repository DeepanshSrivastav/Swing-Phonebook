import matrix.db.Context;


public class emxDashboardDocuments_mxJPO extends emxDashboardDocumentsBase_mxJPO {
    /**
     * @param context
     * @param args
     * @throws Exception
     */
    public emxDashboardDocuments_mxJPO(Context context, String[] args) throws Exception {
    	super(context, args);
    }
}
