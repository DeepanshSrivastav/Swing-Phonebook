import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmOwnerRolesUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.beans.IEFIntegAccessUtil;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.beans.MCADServerGeneralUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADGlobalConfigObject;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.engineering.EngineeringUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.File;
import matrix.db.FileList;
import matrix.db.JPO;
import matrix.db.RelationshipType;
import matrix.util.StringList;

public class cdmOrCAD_mxJPO {
	public cdmOrCAD_mxJPO (Context context, String[] args) throws Exception {
	}
	
	/**
	 * OrCAD_003
	 * OrCAD Create Function.
	 * 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map createOrCAD(Context context, String[] args) throws Exception {
		Map resultMap = new HashMap();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			
			// EC Part Name
			String ecPartId = (String) programMap.get("cdmPartNumber");
			DomainObject ecPartDom = DomainObject.newInstance(context, ecPartId);
			
			StringList busSelect = new StringList();
			busSelect.add(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_NAME);
			busSelect.add(cdmConstantsUtil.SELECT_NAME);

			Map ecPartInfo = ecPartDom.getInfo(context, busSelect);
			String ecPartName = (String) ecPartInfo.get(cdmConstantsUtil.SELECT_NAME);
			String cdmPartName = (String) ecPartInfo.get(cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PART_NAME);

			// Create Object
			DomainObject orcadDom = DomainObject.newInstance(context);
			orcadDom.createObject(	context,
									cdmConstantsUtil.TYPE_CDMORCADPRODUCT,
									ecPartName,
									"A",
									cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION,
									cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			
			// Set Attribute
			String language		= (String) programMap.get("languageStr");
			IEFIntegAccessUtil util		= new IEFIntegAccessUtil(context, new MCADServerResourceBundle(language), new IEFGlobalCache());
			String integrationName  = (String) util.getAssignedIntegrations(context).get(0);
			programMap.put("Source", integrationName);
			programMap.put(cdmConstantsUtil.ATTRIBUTE_TITLE, cdmPartName);
			
			cdmUtil_mxJPO.setAttributeMap(context, programMap, cdmConstantsUtil.TYPE_CDMORCADPRODUCT, orcadDom);
			
			// Connect
			if (cdmStringUtil.isNotNullString(ecPartId)) {
				orcadDom.addFromObject(context, new RelationshipType(cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION), ecPartId);
			}
			
			String workspaceId = (String) programMap.get("WorkSpaceOID");
			if (cdmStringUtil.isEmpty(workspaceId)) workspaceId = (String) programMap.get("WorkSpace");
			if (cdmStringUtil.isNotNullString(workspaceId)) {
				orcadDom.addFromObject(context, new RelationshipType(cdmConstantsUtil.RELATIONSHIP_VAULTED_OBJECTS), workspaceId);
			}

			// OrCAD Template File Copy
			String orCADTemplateId = (String) programMap.get("cdmOrCADTemplateOID");
			if (cdmStringUtil.isNotNullString(orCADTemplateId)) {
				// Minor Version Create And Connect
				MCADGlobalConfigObject globalConfigObject = (MCADGlobalConfigObject) programMap.get("GCO");
				MCADServerResourceBundle resourceBundle     = new MCADServerResourceBundle((String) programMap.get("languageStr"));
				IEFGlobalCache cache				= new IEFGlobalCache();
				MCADMxUtil mxUtil               = new MCADMxUtil(context, resourceBundle, cache);
				MCADServerGeneralUtil generalUtil        = new MCADServerGeneralUtil(context, globalConfigObject, resourceBundle, cache);
				String minorPolicy                     = mxUtil.getRelatedPolicy(context, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION);    //[NDM] : L86

				String minorRevString			= mxUtil.getFirstVersionStringForStream("A");
				String minObjId = generalUtil.createAndConnectToMinorObject(context, minorRevString, true, orcadDom, globalConfigObject, true, false,minorPolicy);        //[NDM] : L86

				DomainObject minObject = DomainObject.newInstance(context, minObjId);
				minObject.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_TITLE, ecPartName + ".DSN");

				DomainObject orCADTemplateObject = DomainObject.newInstance(context, orCADTemplateId);
				
				String workspace = context.createWorkspace();
				FileList fileList = orCADTemplateObject.getFiles(context);
				orCADTemplateObject.checkoutFiles(context, false, "generic", fileList, workspace);
				
				if (fileList.size() > 0) {
					File tempFile = (File) fileList.getElement(0);
					String templateFileName = tempFile.getName();
					
					// OrCAD Template File CheckIn
					orcadDom.checkinFile(context, true, true, "", "DSN", templateFileName, workspace);
					
					// OrCAD File Rename
					String orCADObjectId = orcadDom.getObjectId(context);
					Map renameParamMap = new HashMap();
					renameParamMap.put("ORCAD_OID", orCADObjectId);
					renameParamMap.put("fileName", templateFileName);
					
					cdmOrCADUtil_mxJPO orCADUtil = new cdmOrCADUtil_mxJPO();
					orCADUtil.renameFile(context, renameParamMap);
				}
			}
			
			resultMap.put("id", orcadDom.getObjectId(context));
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultMap;
	}
	
	/**
	 * OrCAD_004 OrCAD Check In 시 BOM 생성 Function.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map createOrCADPartBOM(Context context, String[] args) throws Exception {
		Map resultMap = new HashMap();
		resultMap.put("MESSAGE", "");
		boolean isAdmin = false;
		try {
			String orgOwner = context.getUser();
			String match = "[^\uAC00-\uD7A3xfe0-9a-zA-Z]";

			String defaultSC = PersonUtil.getDefaultSecurityContext(context);
			PersonUtil.setDefaultSecurityContext(context, defaultSC);
			
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			cdmOrCADUtil_mxJPO orCADUtil = new cdmOrCADUtil_mxJPO();

			String orCadOid = (String) paramMap.get("ORCAD_OID");
			MapList partListData = (MapList) paramMap.get("PART_LIST");

			// Disconnect OrCADBOM
			orCADUtil.disconnectOrCADBOM(context, orCadOid);

			Map tempMap = null;
			String childPartName = null;
			String childPartId = null;
			String reference = null;
			String qty = null;
			String queryResult = null;
			String isCheck = null;
			String description = null;

			StringList queryResultList = null;

			boolean isNewpart = false;

			DomainObject parentObj = DomainObject.newInstance(context, orCadOid);

			for (Iterator itr = partListData.listIterator(); itr.hasNext();) {
				tempMap = (Map) itr.next();

				isNewpart = false;

				isCheck = Boolean.toString((boolean) tempMap.get("Check"));

				// [B] modify by jtkim 2017-01-03
				// [OrCAD_001] If the checkbox value of UI is not checked when OrCAD Part is created, the corresponding part number Skip.
				if ("true".equals(isCheck) == false) continue;
				// [E] modify by jtkim 2017-01-03

				childPartName = (String) tempMap.get("Mando Part No");
				reference = (String) tempMap.get("Part Reference");
				qty = (String) tempMap.get("Quantity");
				description = (String) tempMap.get("DESCRIPTION");

				childPartName = childPartName.replaceAll(match, "");

				queryResult = MqlUtil.mqlCommand(context, "temp query bus " + cdmConstantsUtil.TYPE_CDMORCADPART + " " + childPartName + " * where \"revision==last&&policy=='Design TEAM Definition'\" select id dump");

				if (cdmStringUtil.isNotNullString(queryResult)) {
					queryResultList = FrameworkUtil.split(queryResult, ",");
					childPartId = (String) queryResultList.get(3);
				} else {
					// Create Object

					ContextUtil.pushContext(context);
					isAdmin = true;
					DomainObject orcadDom = DomainObject.newInstance(context);

					// Create OrCAD Part
					orcadDom.createObject(context, cdmConstantsUtil.TYPE_CDMORCADPART, childPartName, "A", cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);

					// OrCAD Part Create Minor Version
					String[] init = new String[] {};
					Map versionParamMap = new HashMap();
					versionParamMap.put("ORCAD_OID", orcadDom.getObjectId());
					HashMap createVersionResult = (HashMap) JPO.invoke(context, "cdmOrCADUtil", init, "createMinorObject", JPO.packArgs(versionParamMap), HashMap.class);
					// 
					// Set OrCAD Owner
					orcadDom.setOwner(context, orgOwner);

					// Set OrCAD Originator
					String language		= (String) paramMap.get("languageStr");
					IEFIntegAccessUtil util		= new IEFIntegAccessUtil(context, new MCADServerResourceBundle(language), new IEFGlobalCache());
					String integrationName  = "MxCATIAV5"; //(String) util.getAssignedIntegrations(context).get(0);
					
					Map updateMap = new HashMap();
					updateMap.put("Source", integrationName);
					updateMap.put(cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, orgOwner);
					updateMap.put("IEF-EBOMSync-PartTypeAttribute", "cdmElectronicPart");

					orcadDom.setAttributeValues(context, updateMap);

					// Set OrCAD Description
					orcadDom.setDescription(context, description);

					ContextUtil.popContext(context);
					isAdmin = false;
					
					// Set OrCAD Project, Organization
					orcadDom.setPrimaryOwnership(context, EngineeringUtil.getDefaultProject(context), EngineeringUtil.getDefaultOrganization(context));

					childPartId = orcadDom.getObjectId();

					isNewpart = true;
				}

				DomainObject childObj = DomainObject.newInstance(context, childPartId);

				DomainRelationship connecRel = null;
				connecRel = DomainRelationship.connect(context, parentObj, new RelationshipType(cdmConstantsUtil.RELATIONSHIP_CAD_SUBCOMPONENT), childObj);

				Map setAttrMap = new HashMap();
				setAttrMap.put(cdmConstantsUtil.ATTRIBUTE_REFERENCE_DESIGNATOR, reference);
				setAttrMap.put(cdmConstantsUtil.ATTRIBUTE_QUANTITY, "1");

				connecRel.setAttributeValues(context, setAttrMap);
			}
			// EC Part Name
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("MESSAGE", e.toString());
			if (isAdmin) ContextUtil.popContext(context);
		}

		return resultMap;
	}
	
	/**
	 * OrCAD Version / All Version File Delete Function.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public Map deleteFileVersion(Context context, String[] args) throws Exception {
		Map resultMap = new HashMap();
		resultMap.put("msg", "");
		boolean isTransaction = false;
		cdmOrCADUtil_mxJPO orCADUtil = new cdmOrCADUtil_mxJPO();
		try {
			
			ContextUtil.startTransaction(context, true);
			isTransaction = true;
			
			Map paramMap = JPO.unpackArgs(args);
			
			String majorId = (String) paramMap.get("objectId");
			
			DomainObject majorObj = DomainObject.newInstance(context, majorId);
			String activeMinorId = orCADUtil.getActiveMinorObjectId(context, majorObj);
			DomainObject minorObj = DomainObject.newInstance(context, activeMinorId);

			orCADUtil.deleteFile(context, majorId);
			
			// Major OrCADProduct BOM Disconnect
			orCADUtil.disconnectOrCADBOM(context, majorId);
			
			BusinessObject preMinorObj = minorObj.getPreviousRevision(context);

			MqlUtil.mqlCommand(context, "set env $1 $2 $3", new String[] { "global", "DECDelete", "true" });
			minorObj.deleteObject(context);
			MqlUtil.mqlCommand(context, "unset env $1 $2 $3", new String[] { "global", "DECDelete", "true" });
			
			// 이전 Revision이 존재 할 경우.
			if (preMinorObj != null) {
				String preMinorObjId = preMinorObj.getObjectId(context);
				if (cdmStringUtil.isNotEmpty(preMinorObjId)) {
					orCADUtil.moveFileToMajorObject(context, majorId, preMinorObjId);
					orCADUtil.setActiveVersionObject(context, preMinorObjId);
					orCADUtil.connectPreVersionBOM(context, majorId, preMinorObjId);
				}
			}
			
			ContextUtil.commitTransaction(context);
		} catch(Exception e) {
			e.printStackTrace();
			if (isTransaction) ContextUtil.abortTransaction(context);
		} finally {
			
		}
		
		return resultMap;
	}
	
	/**
	 * OrCAD Version / All Version File Delete Function.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public Map deleteFileAllVersion(Context context, String[] args) throws Exception {
		Map resultMap = new HashMap();
		resultMap.put("msg", "");
		boolean isTransaction = false;
		cdmOrCADUtil_mxJPO orCADUtil = new cdmOrCADUtil_mxJPO();
		try {
			
			ContextUtil.startTransaction(context, true);
			isTransaction = true;
			
			Map paramMap = JPO.unpackArgs(args);
			
			String majorId = (String) paramMap.get("objectId");
			
			DomainObject majorObj = DomainObject.newInstance(context, majorId);

			orCADUtil.deleteFile(context, majorId);
			
			MqlUtil.mqlCommand(context, "set env $1 $2 $3", new String[] { "global", "DECDelete", "true" });

			MapList minorObjList = orCADUtil.getMinorObjectList(context, majorObj);
			
			String minorObjId = null;
			for (Iterator itr = minorObjList.listIterator(); itr.hasNext();) {
				Map tempMap = (Map) itr.next();
				minorObjId = (String) tempMap.get(cdmConstantsUtil.SELECT_ID);
				DomainObject minorObj = DomainObject.newInstance(context, minorObjId);
				minorObj.deleteObject(context);
			}
			MqlUtil.mqlCommand(context, "unset env $1 $2 $3", new String[] { "global", "DECDelete", "true" });
			
			ContextUtil.commitTransaction(context);
		} catch(Exception e) {
			e.printStackTrace();
			if (isTransaction) ContextUtil.abortTransaction(context);
		} finally {
			
		}
		
		return resultMap;
	}
	
	/**
	 * OrCAD 와 연결된 PCB Part 목록을 Return.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public MapList getRelatedPCBPart(Context context, String[] args) throws Exception {
		MapList resultList = new MapList();

		try {

			Map paramMap = JPO.unpackArgs(args);

			String objectId = (String) paramMap.get("objectId");
			DomainObject obj = DomainObject.newInstance(context, objectId);

			StringList selBusSelect = new StringList();
			selBusSelect.add(cdmConstantsUtil.SELECT_ID);

			StringList selRelSelect = new StringList();
			selRelSelect.add(cdmConstantsUtil.SELECT_RELATIONSHIP_ID);

			String sBusWhere = "";
			String sRelWhere = "";

			resultList = obj.getRelatedObjects(	context,
												cdmConstantsUtil.RELATIONSHIP_CDMRELATEDPCBPART + "," + cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION,
												cdmConstantsUtil.TYPE_PART,
												selBusSelect,
												selRelSelect,
												true,
												true,
												(short) 0,
												sBusWhere,
												sRelWhere,
												0
											);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return resultList;
	}
	
	/**
	 * OrCAD 와 연결된 Drawing(거버파일) 목록을 Return.
	 * @param context
	 * @param args
	 * @return
	 * @throws Exception
	 */
	public MapList getRelatedDrawing(Context context, String[] args) throws Exception {
		MapList resultList = new MapList();
		
		try {
			
			Map paramMap = JPO.unpackArgs(args);
			
			String objectId = (String) paramMap.get("objectId");
			DomainObject obj = DomainObject.newInstance(context, objectId);
			
			StringList selBusSelect = new StringList();
			selBusSelect.add(cdmConstantsUtil.SELECT_ID);
			
			StringList selRelSelect = new StringList();
			selRelSelect.add(cdmConstantsUtil.SELECT_RELATIONSHIP_ID);
			
			String sBusWhere = "";
			String sRelWhere = "";
			
			resultList = obj.getRelatedObjects(	context,
												cdmConstantsUtil.RELATIONSHIP_CDMRELATEDDRAWING,
												cdmConstantsUtil.QUERY_WILDCARD,
												selBusSelect,
												selRelSelect,
												false,
												true,
												(short) 0,
												sBusWhere,
												sRelWhere,
												0
											);
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return resultList;
	}


	public MapList getOrCADTemplateFirstNode(Context context, String[] args) throws Exception {
		
		MapList nodeList = new MapList();
		Map map = new HashMap();
		map.put("name", "OrCAD Template");
		map.put("IS_LEAF", "TRUE");
		map.put("hasChild", "TRUE");
		nodeList.add(map);
		return nodeList;
	}
	
	public MapList getOrCADTemplateList(Context context, String[] args) throws Exception {
		MapList nodeList = new MapList();
		
		String sBusWhere = "";

		StringList actualValue  = new StringList();
        StringList displayValue   = new StringList();
		StringList slBusSelect = new StringList();
		slBusSelect.add(cdmConstantsUtil.SELECT_ID);
		slBusSelect.add(cdmConstantsUtil.SELECT_NAME);
		

		MapList templateList = DomainObject.findObjects(	context,
															cdmConstantsUtil.TYPE_CDMORCADDESIGNTEMPLATE,       // type
															cdmConstantsUtil.QUERY_WILDCARD,            // name
															cdmConstantsUtil.QUERY_WILDCARD,            // rev
															cdmConstantsUtil.QUERY_WILDCARD,            // owner
															cdmConstantsUtil.QUERY_WILDCARD,           	// vault
															sBusWhere, 									// where
															false,                                   	// expand
															slBusSelect);                            	// selectbus
		
		Map tempMap = null;
		for (Iterator itr = templateList.listIterator(); itr.hasNext();) {
			tempMap = (Map) itr.next();
			tempMap.put("IS_LEAF", "TRUE");
			tempMap.put("hasChild", "TRUE");
		}
		return templateList;
	}

	/**
	 * OrCAD_004 OrCAD Variant BOM Check In 시 BOM 생성 Function.
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public Map createOrCADPartVariantBOM(Context context, String[] args) throws Exception {
		Map resultMap = new HashMap();
		resultMap.put("MESSAGE", "");
		boolean isAdmin = false;
		try {
			String orgOwner = context.getUser();

			String defaultSC = PersonUtil.getDefaultSecurityContext(context);
			PersonUtil.setDefaultSecurityContext(context, defaultSC);
			
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			cdmOrCADUtil_mxJPO orCADUtil = new cdmOrCADUtil_mxJPO();

			String orCadOId = (String) paramMap.get("ORCAD_OID");
			String orCADType = (String) paramMap.get("ORCAD_TYPE");
			String firstParent = (String) paramMap.get("MAIN_PARENT");
			String orCADPartType = cdmConstantsUtil.TYPE_CDM_ELECTRONIC_PART;
			if (cdmConstantsUtil.TYPE_CDMORCADPRODUCT.equals(orCADType)) orCADPartType = cdmConstantsUtil.TYPE_CDM_ELECTRONIC_ASSEMBLY_PART;

			MapList partListData = (MapList) paramMap.get("PART_LIST");

			// OrCAD Master
			if ("true".equals(firstParent)) {
				resultMap = orCADUtil.getOrCADMaster(context, orCadOId);
				String errorMsg = (String) resultMap.get("MESSAGE");
				if (cdmStringUtil.isNotEmpty(errorMsg)) return resultMap;
	
				orCadOId = (String) resultMap.get("MasterId");
			}
			
			// Disconnect OrCADBOM
			orCADUtil.disconnectOrCADBOM(context, orCadOId);

			Map tempMap = null;
			String childPartName = null;
			String childPartId = null;
			String reference = null;
			String qty = null;
			String queryResult = null;
			String isCheck = null;
			String description = null;
			String match = "[^\uAC00-\uD7A3xfe0-9a-zA-Z]";

			StringList queryResultList = null;

			MapList orCADAssyList = new MapList();

			boolean isNewpart = false;

			DomainObject parentObj = DomainObject.newInstance(context, orCadOId);

			for (Iterator itr = partListData.listIterator(); itr.hasNext();) {
				tempMap = (Map) itr.next();

				isNewpart = false;

				isCheck = Boolean.toString((boolean) tempMap.get("Check"));

				// [B] modify by jtkim 2017-01-03
				// [OrCAD_001] If the checkbox value of UI is not checked when OrCAD Part is created, the corresponding part number Skip.
				if ("true".equals(isCheck) == false) continue;
				// [E] modify by jtkim 2017-01-03

				childPartName = (String) tempMap.get("Mando Part No");
				reference = (String) tempMap.get("Part Reference");
				qty = (String) tempMap.get("Quantity");
				description = (String) tempMap.get("DESCRIPTION");

				
				childPartName = childPartName.replaceAll(match, "");

				queryResult = MqlUtil.mqlCommand(context, "temp query bus " + orCADType + " " + childPartName + " * where \"revision==last&&policy=='Design TEAM Definition'\" select id dump");

				if (cdmStringUtil.isNotNullString(queryResult)) {
					queryResultList = FrameworkUtil.split(queryResult, ",");
					childPartId = (String) queryResultList.get(3);
				} else {
					// Create Object

					ContextUtil.pushContext(context);
					isAdmin = true;
					DomainObject orcadDom = DomainObject.newInstance(context);

					// Create OrCAD Part
					orcadDom.createObject(context, orCADType, childPartName, "A", cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);

					// OrCAD Part Create Minor Version
					String[] init = new String[] {};
					Map versionParamMap = new HashMap();
					versionParamMap.put("ORCAD_OID", orcadDom.getObjectId());
					HashMap createVersionResult = (HashMap) JPO.invoke(context, "cdmOrCADUtil", init, "createMinorObject", JPO.packArgs(versionParamMap), HashMap.class);
					// 
					// Set OrCAD Owner
					orcadDom.setOwner(context, orgOwner);

					// Set OrCAD Originator
					String language		= (String) paramMap.get("languageStr");
					IEFIntegAccessUtil util		= new IEFIntegAccessUtil(context, new MCADServerResourceBundle(language), new IEFGlobalCache());
					String integrationName  = "MxCATIAV5"; //(String) util.getAssignedIntegrations(context).get(0);
					
					Map updateMap = new HashMap();
					updateMap.put("Source", integrationName);
					updateMap.put(cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, orgOwner);
					updateMap.put("IEF-EBOMSync-PartTypeAttribute", orCADPartType);

					orcadDom.setAttributeValues(context, updateMap);

					// Set OrCAD Description
					orcadDom.setDescription(context, description);

					ContextUtil.popContext(context);
					isAdmin = false;
					
					// Set OrCAD Project, Organization
					orcadDom.setPrimaryOwnership(context, EngineeringUtil.getDefaultProject(context), EngineeringUtil.getDefaultOrganization(context));

					childPartId = orcadDom.getObjectId();

					isNewpart = true;
				}

				DomainObject childObj = DomainObject.newInstance(context, childPartId);

				Map childInfoMap = new HashMap();
				childInfoMap.put("id", childPartId);
				childInfoMap.put("name", childPartName);
				orCADAssyList.add(childInfoMap);

				DomainRelationship connecRel = null;
				connecRel = DomainRelationship.connect(context, parentObj, new RelationshipType(cdmConstantsUtil.RELATIONSHIP_CAD_SUBCOMPONENT), childObj);

				Map setAttrMap = new HashMap();
				setAttrMap.put(cdmConstantsUtil.ATTRIBUTE_REFERENCE_DESIGNATOR, reference);
				setAttrMap.put(cdmConstantsUtil.ATTRIBUTE_QUANTITY, "1");

				connecRel.setAttributeValues(context, setAttrMap);
			}
			resultMap.put("orCADAssyList", orCADAssyList);
		} catch (Exception e) {
			e.printStackTrace();
			resultMap.put("MESSAGE", e.toString());
			if (isAdmin) ContextUtil.popContext(context);
		}

		return resultMap;
	}
}
