import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.dassault_systemes.WebServiceHandler.Domain;
import com.mando.util.cdmCommonExcel;
import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.MCADServerSettings;
import com.matrixone.MCADIntegration.server.beans.MCADIntegrationSessionData;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.beans.MCADReviseHelper;
import com.matrixone.MCADIntegration.server.beans.MCADServerGeneralUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADGlobalConfigObject;
import com.matrixone.MCADIntegration.utils.MCADUrlUtil;
import com.matrixone.MCADIntegration.utils.MCADUtil;
import com.matrixone.apps.classification.Classification;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.CacheUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.Libraries;
import com.matrixone.apps.library.LibraryCentralConstants;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.BusinessObjectList;
import matrix.db.BusinessObjectWithSelect;
import matrix.db.BusinessObjectWithSelectList;
import matrix.db.BusinessType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.Relationship;
import matrix.db.RelationshipType;
import matrix.db.ReviseParameters;
import matrix.db.Vault;
import matrix.util.StringList;

public class cdmCADAllMigration_mxJPO {
	public BufferedWriter consoleWriter = null;
	public BufferedWriter logWriter = null;

	public BufferedWriter successObjectidWriter = null;
	public BufferedWriter failedObjectidWriter = null;
	public BufferedWriter errorLogFile = null;
	public BufferedWriter debugLogFile = null;
	public BufferedReader bufferReader = null;

	public String inputDirectory = "";
	public String outputDirectory = "";
	public String fileName = "";

	public String failedIdsLogsDirectory = "";
	public PrintStream errorStream = null;
	public File successLogFile = null;
	public File failedLogFile = null;
	public Integer sequenceInt;
	public static final String partType = "cdmMechanicalPart,cdmPhantomPart";
	public static final String sourceInfo = "MxCATIAV5|CATIAV5R24SP7HF0";
	public static final String sfileSeparator = "\\";
	public static final String attributeCADType = PropertyUtil.getSchemaProperty("attribute_CADType");
	public static final String Output_Directory = "MIGRATION_LOGS";

	public int mxMain(Context context, String args[]) throws Exception {
		return 0;
	}

	/**
	 * 
	 * Part 정보가 없는 데이타는 만들지 않음 에러 처리 ?  
	 * Drawing type 에 CATIA PART 파일 타입이 존재하는 경우 에러 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "deprecation", "unchecked" })
	public void executeAllCADMigration(Context context, String args[]) throws Exception {

		if(args.length!=1){
			throw new Exception("The excel path does not exist.");
		}
		String sFileLocationAndFileName = args[0];
//		Map paramMap = new HashMap();
//		paramMap = (Map) JPO.unpackArgs(args);
//		String sFileLocationAndFileName = (String)paramMap.get("fileData");
		String cadFileLocation = "";
		String cadFileName = "";

		cadFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		cadFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		

		long startTime = System.currentTimeMillis();
		System.out.println("[cdmCADMigration_mxJPO : executeAllCADMigration] start ." + getTimeStamp());

		String logFileName = "CadAllM";
		int successInt = 0;
		int failInt = 0;
		
		int alreadyInt = 0;
		String[] argTemp = null;
//		logFileName+="_"+cadFileName;
		if (cdmStringUtil.isNotEmpty(cadFileLocation) && cdmStringUtil.isNotEmpty(cadFileName)) {
			argTemp = new String[] { cadFileLocation, cadFileName }; 
																	
		} else {
			argTemp = new String[] {};
		}
		// context , artTest,argTest 갯수 체크을위한 수,로그 파일명의 default 파일명.
		initializeM(context, argTemp, 2, logFileName); 
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("CAD DATA MIGRATION " + getTimeStamp() + " \n");
		writeMessageToConsole("Reading input log file from : " + inputDirectory+cadFileName);
		writeMessageToConsole("Writing Log files to: " + outputDirectory);
		writeMessageToConsole("====================================================================================\n");
		writeSuccessToFile("CreateTime \t rowNum(#) \t type \t name \t no exist Part name \t no exist Part rev \t Type \t Major Name \t major org && project \t minor org && project \t  ");
		int lineNumber = 0;
		int notMatchTypeCount = 0;
		StringList sListHeader = new StringList();
		String recordRowNum = "";
		boolean triggerCheck = false;
		try {
			MqlUtil.mqlCommand(context, "Trigger Off");
			triggerCheck = true;
			MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
			IEFGlobalCache cache = new IEFGlobalCache();
			MCADGlobalConfigObject globalConfigObject = null;
			MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
			
			MCADServerGeneralUtil generalUtil = new MCADServerGeneralUtil(context, globalConfigObject, resourceBundle, cache);
			String minorPolicy = mxUtil.getRelatedPolicy(context, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION);
			
			String sReadData = "";
			
			String strPreviousCadType = "";
			String strPreviousCadName = "";
			String strPreviousObjectRev = "";
			String strPreviousObjectTdmxId = "";
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
			while ((sReadData = bufferReader.readLine()) != null) {
				StringList sListReadData = FrameworkUtil.split(sReadData, "\t");

				if (lineNumber == 0) {
					sListHeader = sListReadData;
					lineNumber++;
					writeFailToFile( "Time"+"\t"+ "Error_Num"+"\t"+sReadData);
					continue;
				}
				
				lineNumber++;
				
				int headerSize = sListHeader.size();
				int readLineSize = sListReadData.size();
				try {
					if (headerSize != readLineSize) {
						String errorMessage = "NOT MATCH ROW INFOMATION"+"\t"+sListReadData.toString();
						throw new Exception(errorMessage);
					}

					LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();

					for (int dataCnt = 0; dataCnt < sListReadData.size(); dataCnt++) {

						String stTempCadInfos = (String) sListReadData.get(dataCnt);
						String stTempCadInfosHeader = (String) sListHeader.get(dataCnt);
						// 공백제거,null 처리,trim처리
						stTempCadInfosHeader = isVaildNullData(stTempCadInfosHeader);
						stTempCadInfos = isVaildNullData(stTempCadInfos);
						linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);

					}

					if (lineNumber == 1) {
						continue;
					}
					
					MqlUtil.mqlCommand(context, "history Off");
					StringBuffer sbErrorMessage = new StringBuffer(""); 
					
					recordRowNum = (String) linkedCadHM.get("#");
					
					String sTempType 	= (String) linkedCadHM.get("CLS_NAME"); 
					String sTdmxId		= (String) linkedCadHM.get("TDMX_ID"); 
					String sRevision	= (String) linkedCadHM.get("REVISION"); 
					String sState		= (String) linkedCadHM.get("STATE"); 
					String sUsers		= (String) linkedCadHM.get("CRT_USERS"); 
					
					String sDescription		 = (String) linkedCadHM.get("TDM_DESCRIPTION"); 
					String sRelated_PartName	 = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); 
					String sCADIdentifier  = (String) linkedCadHM.get("TDMX_CAD_IDENTIFIER"); 
					String sDetailedDescription	= (String) linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); 
					String s3dCADIdentifier	= (String) linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); 
					String sTitleType		= (String) linkedCadHM.get("TDMX_TITLE_TYPE"); 
					String sScale		    = (String) linkedCadHM.get("TDMX_SCALE"); 
					String sPageSize	    = (String) linkedCadHM.get("TDMX_PAGE_SIZE"); 
					String sFileType	    = (String) linkedCadHM.get("FILE_TYPE"); 
					String sFileName	    = (String) linkedCadHM.get("FILE_NAME"); 
					String sCadRefFileName  = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); 
//					String sVault= (String) linkedCadHM.get("VAULT_OBJECT_ID");  // 파일 업로드시 필요 
					String sPhase		    = (String) linkedCadHM.get("PHASE"); 
					String sOrg				= (String) linkedCadHM.get("TDM_ORG_USER_ID"); 
					String sDocumentType	= (String) linkedCadHM.get("TDM_DOCUMENT_TYPE"); 
					String sArchiveType		= (String) linkedCadHM.get("TDM_ARCHIVE_TYPE"); 
					String sArchiveName		= (String) linkedCadHM.get("TDM_ARCHIVE_NAME"); 
					String sProdDiv			= (String) linkedCadHM.get("PROD_DIV"); 
					String sProject			= (String) linkedCadHM.get("CN_PROJECT"); 
					String sProjectCust		= (String) linkedCadHM.get("CN_PROJECT_CUST"); 
					String sMASS			= (String) linkedCadHM.get("CN_MASS"); 
					String sSurfaceArea		= (String) linkedCadHM.get("CN_SURFACE_AREA"); 
					String sOEMPartNumber	= (String) linkedCadHM.get("CN_OEM_PART_NUMBER"); 
					String sECONumber		= (String) linkedCadHM.get("CN_ECO_NUMBER"); 
					String sMassEstimated	= (String) linkedCadHM.get("CN_MASS_ESTIMATED"); 
					String sProductGroup	= (String) linkedCadHM.get("CN_PRODUCT_GROUP"); 
					String sCustomer		= (String) linkedCadHM.get("CN_CUSTOMER"); 
					String sVehicle			= (String) linkedCadHM.get("CN_VEHICLE"); 
					String sRelatedPartName	= (String) linkedCadHM.get("CN_RELATED_ITEM_NAME"); 
					String sRelatedPartRev	= (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); 
					String sProjectId		= (String) linkedCadHM.get("CN_PROJECT_ID"); 
					String sProdGroup		= (String) linkedCadHM.get("PROD_GROUP"); 
					String sCustVehicle		= (String) linkedCadHM.get("CN_CUST_VEHICLE"); 
					String sCreationdate = (String) linkedCadHM.get("CREATION_DATE"); 
					String sRealName = (String) linkedCadHM.get("OBJECT_NAME"); 
					
					
//					if(sRealName.contains("'")){
//						sRealName = sRealName.replaceAll("'", "_");
//					}
					sTempType = sTempType.trim();
					sRealName = sRealName.trim();
					
					boolean bFileTypeCheck = false;
					String parentRelName = cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
					String sType = "";
					String sPartFindObjId = "";
					
					String strCadObjectName = "";
					String sRevisionSeqence = "";
					String stObjectId = "";
					String sCAD_Type = "";
					String strFormat = "";
					boolean isCatiaCadModel = false;
					boolean isExistCADNotCAT = false;
					String sTempFileType = "";
					
					
					/*file type 에 따라 sCAD_Type 명이 다르다.*/
					if ("CATIA Product".equals(sFileType)) {
						if ("Assembly".equals(sTempType)) {
							isCatiaCadModel = true;
							strFormat = "asm";
							sCAD_Type = "assembly";
							sType = cdmConstantsUtil.TYPE_CATPRODUCT;
						}
					}else if("AutoCAD".equals(sFileType)){
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
						}
						if ("Image Drawing".equals(sTempType)) {
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
						}
					}else if("CATIA Drawing".equals(sFileType)){
//						System.out.println("sTempType =-> "+ sTempType);
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
							//PDF ,ZIP 존재가능
						}
						
						if("Image Drawing".equals(sTempType)) {
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
							sFileType = "Image";							
						}
						
						if("V4 Model".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
							isExistCADNotCAT = true;
						}
						
						if("Drawing".equals(sTempType)){
							strFormat = "drw";
							sCAD_Type = "drawing";
							isCatiaCadModel = true;
							sType = "CATDrawing";
							
						}
						
						//Exchange 는 제외함 
					}else if("DXF".equals(sFileType)){
						sType = "cdmDXF";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
					}else if("CATIA cgm".equals(sFileType)){
						sType = "cdmCATIAcgm";
						sFileType = "CATIA cgm";
						isExistCADNotCAT = true;
					}else if("STEP".equals(sFileType)){
						sType = cdmConstantsUtil.TYPE_CDMSTEP;
						isExistCADNotCAT = true;
					}else if("CATIA Material".equals(sFileType)){
						sType = cdmConstantsUtil.TYPE_CDMCATIAMATERIAL;
						isExistCADNotCAT = true;
					}else if("CATIA Model".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CATPART;
							isCatiaCadModel = true;
							strFormat = "prt";
							sCAD_Type = "component";
						}
						if("V4 Model".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
							isExistCADNotCAT = true;
						}
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
						}
						
					}else if("CATIA Part".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CATPART;
							isCatiaCadModel = true;
							strFormat = "prt";
							sCAD_Type = "component";
						}
					}else if("IGES".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = "cdmIGES";
							bFileTypeCheck = true;
//							sFileType = "";
						}
					}else if("PDF".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
							sFileType = "Image";
//							sFileType = "";
						}
						if("AutoCAD".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							bFileTypeCheck = true;
//							sFileType = "";
							isExistCADNotCAT = true;
						}
					}else if("STEP".equals(sFileType)){
						sType = "cdmSTEP";
						isExistCADNotCAT = true;
					}else if("Text".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
							sFileType = "Image";
						}
					}else if("Unigraphics".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
						}
						if("UG NX Drawing".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
							isExistCADNotCAT = true;
						}
						if("UG NX Part".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMNXPART;
							isExistCADNotCAT = true;
						}
					}else if("ZIP".equals(sFileType)){
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//							sFileType = "";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}
					}else if("CATIA cgr".equals(sFileType)){
						sType = "cdmCATIAcgr";
//						sFileType = "";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
					}else if("CATIA Material".equals(sFileType)){
						sType = "cdmCATIAMaterial";
//						sFileType = "";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
						
					}else{
						
					}
					
					if (StringUtils.isEmpty(sType)) {
						// Image Drawing 파일 타입이 존재하지 않는 경우 제외
						sType = "cdmImageDrawing";
//						sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
						sFileType = "Image";
					}
					if(bFileTypeCheck){
						sTempFileType = "";
					}else{
						sTempFileType = sFileType;
					}
					
					
					
					/* *********************************************************
					 * Person 정보 확인.
					 * ********************************************************* */
					boolean IsExistPerson = false; // Person 정보 확인
					
					String sIsPersonMql = MqlUtil.mqlCommand(context, "print bus Person '" + sUsers + "' - select exists dump" );
					
					if ("true".equalsIgnoreCase(sIsPersonMql)) {
						IsExistPerson = true;
						sbErrorMessage.append("X").append("\t");
					} else {
						sbErrorMessage.append("○").append("\t");
					}
					/*
					 * *********************************************************
					 *  object name 설정. sCAD_REF_FILE_NAME 데이타가
					 * 존재하지않는다면 에러 처리 .
					 * *********************************************************
					 * 
					 */
					
					strCadObjectName = sRealName;
					
					boolean bAlreadyExist = false;
					
					String strMajorObjId = "";
					String exsitMinorObjId = "";
					AttributeList majorlocalAttributeList = new AttributeList();
					AttributeList minorlocalAttributeList = new AttributeList();
					Map docAttrMap = new HashMap();
					
					
					String tempCreatedDate = "";
					if (UIUtil.isNotNullAndNotEmpty(sCreationdate) ) {
						Date createdate = new Date(sCreationdate);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa", new Locale("en", "US"));
						tempCreatedDate = sdf.format(createdate);
						//12/6/2016 10:40:16 AM
					}
					
					sRevisionSeqence = sRevision.replaceAll("\\..+", "");

//					System.out.println("sTempType =-> "+ sTempType);
//					System.out.println("sType =-> "+ sType);
//					System.out.println("strCadObjectName =-> "+ strCadObjectName);
//					System.out.println("sRevisionSeqence =-> "+ sRevisionSeqence);
					
					ContextUtil.startTransaction(context, true);
				
					DomainObject busDOCUMENT = new DomainObject();
					String sTempDescription = "";
					if (isCatiaCadModel ) {
						/*
						 * *****************************************************
						 * REVISION 정보가 없다면 에러 처리. REVISION 설정 .
						 * 
						 * *****************************************************
						 */
						if (cdmStringUtil.isEmpty(sRevision)) {
							String errorMessage = "NOT EXIST REVISION DATA. ";
							throw new Exception(errorMessage);
						}

						String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
						DomainObject minorBusObject = new DomainObject();

						String sAttribute_MoveFileVersion = MCADMxUtil.getActualNameForAEFData(context, "attribute_MoveFilesToVersion");
						// original file name 과 데이타가 같다.
						String sAttribute_Title = MCADMxUtil.getActualNameForAEFData(context, "attribute_Title");
						String sAttribute_IsVersionObj = MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
						String sAttribute_IEFFileMessage = MCADMxUtil.getActualNameForAEFData(context, "attribute_IEF-FileMessageDigest");
						String sAttribute_Source = MCADMxUtil.getActualNameForAEFData(context, "attribute_Source");

						

//						boolean bBeforRevExistConnectSpecCheck = false;
						
						if (strPreviousCadName.equals(strCadObjectName) && sTdmxId.equals(strPreviousObjectTdmxId)) {
							
							if(!sType.equals(strPreviousCadType)){
								throw new Exception("not match revision Type Infomation.");
								
							}
							BusinessObject busPreviousObj = new BusinessObject(sType, strPreviousCadName, strPreviousObjectRev,  cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
							
							//
								// 현재 object는 제외하고 이전 revision 과 part 연결여부 확인 
									DomainObject preDocIdDobj = new DomainObject((String)busPreviousObj.getObjectId(context));
									
									String sConnectedPartId = "";
									String relName = "Part Specification";
									String connectType = "cdmPhantomPart,cdmMechanicalPart";
									StringList busSelect = new StringList();
									StringList relSelect = new StringList();
									busSelect.add("id");
									relSelect.add("id[connection]");
									relSelect.add("type[connection]");
									boolean isFrom = false;
									boolean isTo = true;
									String whereExpr = "from[Part Specification].to.id == '"+(String)busPreviousObj.getObjectId(context)+"'";
									MapList findMListRevisions = preDocIdDobj.getRelatedObjects(context,
																			relName,
																			connectType,
																			busSelect,
																			relSelect,
																			isTo,
																			isFrom,
																			(short)1,
																			whereExpr,
																			null);

									if(findMListRevisions.size()>0){
										for (Iterator connectPreObj = findMListRevisions.iterator(); connectPreObj.hasNext();) {
											Map connectPreObjMap = (Map) connectPreObj.next();
											String id = (String)connectPreObjMap.get("id");
											String relId = (String)connectPreObjMap.get("id[connection]");
											String relType = (String)connectPreObjMap.get("type[connection]");
											Relationship rel = new Relationship(relId);
								            rel.open(context);
								            DomainObject toDo = new DomainObject(rel.getTo());
								            rel.close(context);
								            String toDocObjId = (String)toDo.getObjectId(context);
								            
								            if (cdmStringUtil.isNotEmpty(sRelated_PartName) && cdmStringUtil.isNotEmpty(sRelatedPartRev)) {
												BusinessObject busPart = new BusinessObject("cdmMechanicalPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
												if(!busPart.exists(context)){
													busPart = new BusinessObject("cdmPhantomPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
												}
								            
									            if(toDocObjId.equals((String)busPreviousObj.getObjectId(context)) && "Part Specification".equals(relType) && busPart.exists(context) && busPart.getObjectId(context).equals(id)){
									            	DomainRelationship dObjRel = new DomainRelationship();
									            	dObjRel.disconnect(context, relId);
									            }
								            }
										}
									}
							//
//							MqlUtil.mqlCommand(context, "Trigger Off");
							BusinessObject busReviseMajorObject = new BusinessObject();
							busReviseMajorObject = busPreviousObj.revise(context, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//							MqlUtil.mqlCommand(context, "Trigger On");
							busDOCUMENT.setId(busReviseMajorObject.getObjectId(context));
//							revisionCheck = true;

						}else{
//							MqlUtil.mqlCommand(context, "Trigger Off");
							
							busDOCUMENT.createObject(context, sType, strCadObjectName, sRevisionSeqence, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//							MqlUtil.mqlCommand(context, "Trigger On");
							
						}
						strPreviousCadType = sType;
						strPreviousCadName = strCadObjectName;
						strPreviousObjectRev = sRevisionSeqence;
						strPreviousObjectTdmxId = sTdmxId;
						 
						stObjectId = busDOCUMENT.getObjectId();
							
						//create trigger start  CATPART 
//						String objId = stObjectId;
//						String autoPromote = MqlUtil.mqlCommand(context, "list expression $1 select $2 dump",
//								"VPLMAutoPromoteNextMinorRev", "value");
//						if ("true".equalsIgnoreCase(autoPromote) && !revisionCheck) {
//							String DESIGN_TEAM_DEF = MCADMxUtil.getActualNameForAEFData(context, "policy_DesignTEAMDefinition");
//							String busPolicy = cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION;
//							if (DESIGN_TEAM_DEF.equals(busPolicy)) {
//								BusinessObject obj = new BusinessObject(objId);
//
//								String Args[] = new String[2];
//								Args[0] = "IsDECAutoPromoteOnCreate";
//								Args[1] = "true";
//								mxUtil.executeMQL(context, "set env $1 $2", Args);
//
//								obj.promote(context);
//							}
//						}
						
						
						//create trigger end  CATPART 

						/* 속성 입력 start */
						AttributeList localAttributeList = new AttributeList();
						localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION), sDetailedDescription));
						localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER), s3dCADIdentifier));
						localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE), sDocumentType));
						localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_PART_DRAWING_NO), sRelated_PartName));
						if ("CATDrawing".equals(sType)) {
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE), sScale));
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE), sPageSize));
						}

						if ((cdmConstantsUtil.TYPE_CATPART).equals(sType)) {
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS), sMassEstimated));
						}

						if ((cdmConstantsUtil.TYPE_CATPART).equals(sType) || (cdmConstantsUtil.TYPE_CATPRODUCT).equals(sType)) {
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE), sSurfaceArea));
						}


						/*
						 * MAJOR VERSION OBJECT ATTRIBUTE[ORIGINATOR],OWNER
						 * 정보 추가, PERSON 정보가 존재하지않는다면 제외 였으나
						 * organization,owner,project,organization 정보를
						 * admin_platform의 정보로 구성 (10.31.16) originator 는 받은 데이타에서 처리
						 * 
						 * 11/23 access 의 project와 organization은 데이타는 project열의 정보로 구성된다. 
						 * access 의 project 과 organization의 name룰은 다음 예와 같다.
						 * ex :
						 * project 열의 정보 : CAPLIPER - HD
						 * project : CAPLIPER
						 * 
						 */
						strMajorObjId= busDOCUMENT.getObjectId(context);
//						MqlUtil.mqlCommand(context, "Trigger Off");
						if(IsExistPerson){
							busDOCUMENT.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sUsers);
							busDOCUMENT.setOwner(context, sUsers);
						}
						if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2", strMajorObjId, tempCreatedDate);
						}
//						MqlUtil.mqlCommand(context, "Trigger On");

						/* 
						 * MAJOR VERSION OBJECT ATTRIBUTE, DESCRIPTION 설정 
						 * 에러의 소지가 있어 트랜잭션이 없는곳으로 ATTRIBUTE 설정 ( 
						 * */
							 
						majorlocalAttributeList= localAttributeList;
						AttributeList tempAttributeList = new AttributeList();
						
						tempAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION), "Y"));
						//CAT 파일인 경우 (CATProduct,CATPart,CATDrawing만 해당)
						
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_Title), sCadRefFileName));
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IEFFileMessage), ""));
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_Source), sourceInfo));
						tempAttributeList.addElement(new Attribute(new AttributeType(attributeCADType), sCAD_Type));
						
						tempAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID), sTdmxId));
						tempAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE), sTempFileType));
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "True"));
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IsVersionObj), "False"));
						tempAttributeList.addElement(new Attribute(new AttributeType("cdmRevisionCheckInM"),sRevision ));
						
						if (cdmStringUtil.isNotEmpty(sDescription)) {
//							busDOCUMENT.setDescription(context, sDescription);
							sTempDescription = sDescription;
						}else{
							sTempDescription = "";
						}
						busDOCUMENT.setAttributes(context, tempAttributeList);
						
						/*
						 * RELATIONSHIP PART SPECIFICATION 연결 CAD NAME 값과
						 * PART 의 명이 일치하지않을때에는 RELATIONSHIP으로 연결되지않고 CAD
						 * object의 ATTRIBUTE 속성 [cdmPartDrawingNo]에만 데이타를
						 * 넣는다.
						 */
						
						/* MINOR VERSION */
						String stVersionId = generalUtil.createAndConnectToMinorObject(context, minorRevString, true, busDOCUMENT, globalConfigObject, true, false, minorPolicy); // [NDM]
						minorBusObject.setId(stVersionId);
						
						tempAttributeList.remove(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "True"));
						tempAttributeList.remove(new Attribute(new AttributeType(sAttribute_IsVersionObj), "False"));
						tempAttributeList.remove(new Attribute(new AttributeType("cdmRevisionCheckInM"),sRevision ));
						
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "False"));
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IsVersionObj), "True"));
						
						
						minorlocalAttributeList= localAttributeList;
						//에러 소지가 있어 트랜잭션 없는곳에서 데이타 처리 

						if (cdmStringUtil.isNotEmpty(sDescription)) {
							minorBusObject.setDescription(context, sDescription);
						}
						minorBusObject.setAttributes(context, tempAttributeList);	
						//현재 revise된 정보를 가져오지 않아 trigger 부분을 처리해야함 
							
//						MqlUtil.mqlCommand(context, "Trigger Off");
						
						String minorBusId = minorBusObject.getId(context);
						exsitMinorObjId = minorBusId;
						if(IsExistPerson){
							minorBusObject.setOwner(context, sUsers);
							minorBusObject.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sUsers);
						}
						if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2", minorBusId, tempCreatedDate);
						}
						
						if(UIUtil.isNotNullAndNotEmpty(sState) && "Checked In".equals(sState)){
							busDOCUMENT.setState(context, "IN_WORK");
						}else if("Released".equals(sState)){
							busDOCUMENT.setState(context, "RELEASED");
						}
//						MqlUtil.mqlCommand(context, "Trigger On");
					}else {
						/*
						 * Document 타입일 경우 Document 의 경우 'Document Release'
						 * policy 인 object 에 모든 파일이 저장되며 revision의 object의 경우에도
						 * 파일이 이동하지않고 변경한 데이타들이 저장 파일 이 추가 될
						 * cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성
						 * 추가 Originator은 user 정보로 변경 Person 정보가 enovia에 Person
						 * 정보에 있을시 Owner 추가. 
						 */

						String strPolicDoc_Release = "Document Release";
						String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;

						if (sCadRefFileName == null || "".equals(sCadRefFileName) || "null".equals(sCadRefFileName)) {
							sCadRefFileName = isVaildNullData(sCadRefFileName);
						}

						CommonDocument doMajorObject = (CommonDocument) DomainObject.newInstance(context, CommonDocument.TYPE_DOCUMENTS);
						DomainObject parentObject = null;
						if (sPartFindObjId != null && !"".equals(sPartFindObjId) && !"null".equals(sPartFindObjId)) {
							parentObject = DomainObject.newInstance(context, sPartFindObjId);
						}
						// MIGRATION DATA을 위해 속성 추가 AUTOCAD, ..
						HashMap<String, Object> mAttrMap = new HashMap<String, Object>();
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE, sPageSize);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE, sScale);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_TITLE_TYPE, sTitleType);
						
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION, sDetailedDescription);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER, s3dCADIdentifier);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE, sTempFileType);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE, sDocumentType);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS, sMassEstimated);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE, sSurfaceArea);

						docAttrMap = mAttrMap;
						
						DomainObject dObj = new DomainObject();
						// revise 데이타 있는경우
//						MqlUtil.mqlCommand(context, "Trigger Off");
						if (strPreviousCadName.equals(strCadObjectName)  && sTdmxId.equals(strPreviousObjectTdmxId)) {
							
							if(!sType.equals(strPreviousCadType)){
								throw new Exception("not match revision Type Infomation.");
							}

							BusinessObject busPreviousObj = new BusinessObject(sType, strPreviousCadName, strPreviousObjectRev,  cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
							
							//
							DomainObject preDocIdDobj = new DomainObject((String)busPreviousObj.getObjectId(context));
							
							String sConnectedPartId = "";
							String relName = "Part Specification";
							String connectType = "cdmPhantomPart,cdmMechanicalPart";
							StringList busSelect = new StringList();
							StringList relSelect = new StringList();
							busSelect.add("id");
							relSelect.add("id[connection]");
							relSelect.add("type[connection]");
							boolean isFrom = false;
							boolean isTo = true;
							String whereExpr = "from[Part Specification].to.id == '"+(String)busPreviousObj.getObjectId(context)+"'";
							MapList findMListRevisions = preDocIdDobj.getRelatedObjects(context,
																	relName,
																	connectType,
																	busSelect,
																	relSelect,
																	isTo,
																	isFrom,
																	(short)1,
																	whereExpr,
																	null);

							if(findMListRevisions.size()>0){
								for (Iterator connectPreObj = findMListRevisions.iterator(); connectPreObj.hasNext();) {
									Map connectPreObjMap = (Map) connectPreObj.next();
									String relId = (String)connectPreObjMap.get("id[connection]");
									String relType = (String)connectPreObjMap.get("type[connection]");
									String id = (String)connectPreObjMap.get("id");
									Relationship rel = new Relationship(relId);
						            rel.open(context);
						            DomainObject toDo = new DomainObject(rel.getTo());
						            rel.close(context);
						            String toDocObjId = (String)toDo.getObjectId(context);
						            //
						            if (cdmStringUtil.isNotEmpty(sRelated_PartName) && cdmStringUtil.isNotEmpty(sRelatedPartRev)) {
										BusinessObject busPart = new BusinessObject("cdmMechanicalPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
										if(!busPart.exists(context)){
											busPart = new BusinessObject("cdmPhantomPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
										}
						            
							            if(toDocObjId.equals((String)busPreviousObj.getObjectId(context)) && "Part Specification".equals(relType) && busPart.exists(context) && busPart.getObjectId(context).equals(id)){
							            	DomainRelationship dObjRel = new DomainRelationship();
							            	dObjRel.disconnect(context, relId);
							            }
						            }
						            //
								}
							}
							//
							
							CommonDocument localCommonDocument = new CommonDocument(busPreviousObj.getObjectId(context));

							//String nextRevision = sRevision.replaceAll("\\..+$", "");
							BusinessObject reviseBus = localCommonDocument.revise(context, sRevisionSeqence, false);
							dObj.setId(reviseBus.getObjectId(context));
							localCommonDocument.close(context);
						} else {
							dObj.createObject(context, sType, strCadObjectName, sRevisionSeqence, strPolicDoc_Release, vault);
						}
						strPreviousCadType = sType;
						strPreviousCadName = strCadObjectName;
						strPreviousObjectRev = sRevisionSeqence;
						strPreviousObjectTdmxId = sTdmxId;
						
						doMajorObject = new CommonDocument(dObj.getId(context));
						strMajorObjId = doMajorObject.getId(context);
						
						if (cdmStringUtil.isNotEmpty(sDescription)) {
//							doMajorObject.setDescription(context, sDescription);
//							dObj.setDescription(context, sDescription);
							sTempDescription = sDescription;
						}else{
							sTempDescription = "";
						}
						HashMap tempAttrMap = new HashMap();
						
						tempAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, "Y");
						tempAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID, sTdmxId);
						tempAttrMap.put(cdmConstantsUtil.ATTRIBUTE_TITLE, sCadRefFileName);
						tempAttrMap.put("cdmRevisionCheckInM",sRevision );

						
						dObj.setAttributeValues(context, tempAttrMap);
						

						String sVersionDescription = null;
						Map attrMapOfVersion = new HashMap();
						
						String strMinorVersionId = doMajorObject.createVersion(context, sVersionDescription, strCadObjectName, attrMapOfVersion);
						
						exsitMinorObjId = strMinorVersionId;
						
						if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2",  doMajorObject.getId(context), tempCreatedDate);
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2", strMinorVersionId, tempCreatedDate);
						}
						/* if person not exist, exception */
						DomainObject dObjVersion = DomainObject.newInstance(context, strMinorVersionId);
						dObjVersion.setAttributeValues(context, tempAttrMap);
						if (IsExistPerson) {
							
							doMajorObject.setOwner(context, sUsers);
							doMajorObject.setAttributeValue(context,cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sUsers);
							dObjVersion.setOwner(context, sUsers);
							dObjVersion.setAttributeValue(context,cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sUsers);
							sbErrorMessage.append("X").append("\t");
							
						} else {
							sbErrorMessage.append("○").append("\t");
						}

						//MqlUtil.mqlCommand(context, "Trigger On");
						//MqlUtil.mqlCommand(context, "Trigger Off");
						// state 정보필요 12/19
						if(UIUtil.isNotNullAndNotEmpty(sState) && "Checked In".equals(sState)){
							doMajorObject.setState(context, "IN_WORK");
						}else if(UIUtil.isNotNullAndNotEmpty(sState) && "Released".equals(sState)){
							doMajorObject.setState(context, "RELEASED");
						}

//						MqlUtil.mqlCommand(context, "Trigger On");
						
						busDOCUMENT.setId(strMajorObjId);
					}
					

					/*  *********************************************************
					 * 	존재한다면 연결 연결 정보는 Part Specification 으로 연결
					 * **********************************************************/
					String currentConncetedPart = "";
					
					if (cdmStringUtil.isNotEmpty(sRelated_PartName) && cdmStringUtil.isNotEmpty(sRelatedPartRev)) {

						BusinessObject busPart = new BusinessObject("cdmMechanicalPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						if(!busPart.exists(context)){
							busPart = new BusinessObject("cdmPhantomPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						}
						
						if(busPart != null && busPart.exists(context)){
							currentConncetedPart = busPart.getObjectId(context);
							DomainRelationship connectInfoDoc = new DomainRelationship();
							
							DomainObject docDObj = new DomainObject(busDOCUMENT.getObjectId(context));

				           StringList objectSelects = new StringList();
				           objectSelects.add("id");
//  			               MapList mListRevisionId = docDObj.getRevisions( context, objectSelects, true);
							
//							MqlUtil.mqlCommand(context, "Trigger Off");
							
							connectInfoDoc = DomainRelationship.connect(context, new DomainObject(busPart), DomainConstants.RELATIONSHIP_PART_SPECIFICATION, new DomainObject(busDOCUMENT));
							connectInfoDoc.setAttributeValue(context, "CAD Object Name", strCadObjectName );
									
							AttributeList tempRelAttributeList = new AttributeList();
							tempRelAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DRAWING_NO), sRelated_PartName));
							busDOCUMENT.setAttributes(context, tempRelAttributeList);
//							MqlUtil.mqlCommand(context, "Trigger On");
							
							
						}
						
					}
					
					ContextUtil.commitTransaction(context);
					
					if(!bAlreadyExist){
						/*
						 * *********************************************************
						 * project organization
						 * *********************************************************
						 * 
						 */
						successInt++;
						try {
							
							if(StringUtils.isNotEmpty(sProdGroup) && StringUtils.isNotEmpty(sCustVehicle) && !" - ".equals(sCustVehicle) ) {
//								MqlUtil.mqlCommand(context, "Trigger Off");
								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3",strMajorObjId , sProdGroup, sCustVehicle);
								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", exsitMinorObjId, sProdGroup, sCustVehicle);
//								MqlUtil.mqlCommand(context, "Trigger On");
							}
							
						} catch (Exception e) {
							sbErrorMessage.append(sProdGroup).append("\t").append(sCustVehicle).append("\t");
						}
						
						if (cdmStringUtil.isNotEmpty(strMajorObjId)) {
							try {
								DomainObject dMajorD = new DomainObject(strMajorObjId);
								DomainObject dMinorD = new DomainObject(exsitMinorObjId);
								
								dMajorD.setDescription(context, sTempDescription);
								if(isCatiaCadModel){
								dMajorD.setAttributes(context, majorlocalAttributeList);
								dMinorD.setAttributes(context, minorlocalAttributeList);
								
								
								}else{
									dMajorD.setAttributeValues(context, docAttrMap);
								}
								
							} catch (Exception e5) {
//								writeMessageToConsole(cdmCommonExcel.getTimeStamp2() +"\t"+ recordRowNum+" not input attribute"+e5.toString());
								sbErrorMessage.append("not input attribute \t");
							}
							
						}
						// part spec relationship은 1:1 관계이며 가져온 데이타 기준 으로 이외에 commit 실행 되어 revise 로 생성된 object 중 Part Specification 연결이 추가로 된부분을 disconnect 한다.
						if (cdmStringUtil.isNotEmpty(strMajorObjId)) {
							try{
								StringList sListPartSpectRelId = new StringList();
								DomainObject dMajorD = new DomainObject(strMajorObjId);
								sListPartSpectRelId = dMajorD.getInfoList(context, "to[Part Specification].id");
								
								
								for (Iterator iterPartSpecRel = sListPartSpectRelId.iterator(); iterPartSpecRel.hasNext();) {
									String sPartSpecForRelId = (String) iterPartSpecRel.next();
									DomainRelationship partSpecRel = new DomainRelationship(sPartSpecForRelId);
									partSpecRel.open(context);
									BusinessObject fromBus = new BusinessObject();
									fromBus = partSpecRel.getFrom();
									partSpecRel.close(context);
									String sPartSpecForFromPartId =  fromBus.getObjectId(context);
									if((UIUtil.isNotNullAndNotEmpty(currentConncetedPart) && !currentConncetedPart.equals(sPartSpecForFromPartId) ) || (UIUtil.isNullOrEmpty(currentConncetedPart)) ){
										DomainRelationship.disconnect(context, sPartSpecForRelId);
									}
								}
								
							}catch(Exception e3){
								e3.printStackTrace();
								sbErrorMessage.append("can not disconnect part specificaion before revision. \t");
							}
						
						}
						writeSuccessToFile(cdmCommonExcel.getTimeStamp2() +"\t"+ recordRowNum+"\t"+sType+"\t" +strCadObjectName +"\t"+sRevisionSeqence+"\t"+sbErrorMessage.toString());
					}
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failInt++;
					writeErrorToFile("LineNum(#)"+recordRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " );
					exception.printStackTrace(errorStream);
					String message = exception.getMessage();
					if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not a valid type or filetype.")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"1" +"\t"+sReadData);	
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not a valid sProdGroup or sCustVehicle.")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"2" +"\t"+sReadData);	
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not match revision Type Infomation.")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3" +"\t"+sReadData);
					}
					else{
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t"+sReadData);
					}
					
					

				}finally{
					MqlUtil.mqlCommand(context, "history on");
				}

			}
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        File CAD Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================\n");

		} catch (Exception exception) {

			writeMessageToConsole("LINE NUMBER"+recordRowNum+"\t "+exception.getMessage());
			exception.printStackTrace(errorStream);
		} finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms        \n");
			writeMessageToConsole("End Time :("+cdmCommonExcel.getTimeStamp2() +") total Count:("+(lineNumber-1)+")  Success Count:("+successInt+")   Fail Count: ("+failInt+") already Count: ("+alreadyInt+")  notMatchType Count: ("+notMatchTypeCount+")" );
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			if(triggerCheck){
				MqlUtil.mqlCommand(context, "Trigger On");
			}
			System.out.println("[cdmCADMigration_mxJPO : executeCadcMigration] end ." + getTimeStamp());
		}
	}

	/**
	 * 파일 저장 위치 확인 필요 (Document 파일,CAD 파일위치 동일여부 확인도 )
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void excuteCadCheckin(Context context, String args[]) throws Exception {
		
		long startTime = System.currentTimeMillis();
		
		int successInt = 0;
		int failedInt = 0;
		int totalCount = 0;
		int notMatchTypeCount = 0;
		try {
			
			MqlUtil.mqlCommand(context, "Trigger Off");
			MqlUtil.mqlCommand(context, "history off");
			
			System.out.println("[cdmCADMigration_mxJPO : excuteCadCheckin] start ." + cdmCommonExcel.getTimeStamp2() );

			String logFileName = "checkinFileM";

//			Map paramMap = new HashMap();
//			paramMap = (Map) JPO.unpackArgs(args);
//			String sFileLocationAndFileName = (String)paramMap.get("fileData");
			if(args.length!=1){
				throw new Exception("The excel path does not exist.");
			}
			String sFileLocationAndFileName = args[0];

			String cadFileLocation = "";
			String cadFileName = "";
			
			cadFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
			cadFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
//			logFileName +="_"+cadFileName.substring(0, cadFileName.lastIndexOf("."));
			// 읽을 파일경로 ,읽을 파일명
			String[] argTest = { cadFileLocation, cadFileName };
			// context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
			initializeM(context, argTest, 2, logFileName);
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("     CAD DATA MIGRATION " + getTimeStamp() + " \n");
			writeMessageToConsole("		Reading input log file from : " + inputDirectory+fileName);
			writeMessageToConsole("		Writing Log files to: " + outputDirectory);
			writeMessageToConsole("====================================================================================\n");
			int lineNumber = 0;
			
			StringList stListHeader = new StringList();
			String recordRowNum = "";
			String recordRowTdmxId = "";
			String recordRowRevision = "";
			
			String stReadData = "";
					
			MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
			IEFGlobalCache cache = new IEFGlobalCache();
			MCADGlobalConfigObject globalConfigObject = null;
			MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null) {
				StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
				try {
					if (lineNumber == 0) {
						stListHeader = stListReadData;
						writeFailToFile("errorTime"+"\t"+"errorNum"+"\t"+stReadData.toString());
						lineNumber++;
						continue;
					}
					lineNumber++;
					
					
					totalCount = lineNumber;
					LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();
					int readLineSize = stListReadData.size();
					int headerSize = stListHeader.size();

					if (headerSize != readLineSize) {
						String errorMessage = "NOT MATCH" + stListReadData.toString() ;
						throw new Exception(errorMessage);
					}

					for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {

						String stTempCadInfos = ((String) stListReadData.get(stListNum)).trim();
						String stTempCadInfosHeader = ((String) stListHeader.get(stListNum)).trim();
						stTempCadInfos = isVaildNullData(stTempCadInfos);
						linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);

					}

					recordRowNum = (String) linkedCadHM.get("#");
					String sTempType = (String) linkedCadHM.get("CLS_NAME"); // 1,Type
					String sTdmxId		= (String) linkedCadHM.get("TDMX_ID"); 
					String sTempRevision = (String) linkedCadHM.get("REVISION"); // 3,Revision
//					String sRelated_PartName = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6
					String sFileType = (String) linkedCadHM.get("FILE_TYPE"); // 14, //Real Type
					String sFileName = (String) linkedCadHM.get("FILE_NAME"); // 15, //Real File
					String sRef_FileName = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); // 16,ORIGINAL FILE
//					String sRelated_PartRev = (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
					
					String valutObjectId = (String) linkedCadHM.get("VAULT_OBJECT_ID"); // 36,
					String sObjectRealName = (String) linkedCadHM.get("OBJECT_NAME"); 
					String sRealName = ""; 
							
//					if(sObjectRealName.contains("'")){
//						sRealName = sObjectRealName.replaceAll("'", "_");
//					}else{
//						sRealName = sObjectRealName;
//					}
					
					sTempType = sTempType.trim();
					sRealName = sObjectRealName;
					sRealName = sRealName.trim();
					String strFormat = "";
					recordRowTdmxId= sTdmxId;
					recordRowRevision = sTempRevision;					
					String strWorkspacePath = "F:\\CDM_VALUT\\";
				
					if("WJ Released".equals(valutObjectId)){
						strWorkspacePath +="Wj Released";
					}else{
						strWorkspacePath +=valutObjectId;
					}
					//TEST start  206 위에 데이타가 진짜이며 이건 테스트 
//					String strWorkspacePath = "E:\\CDM_VALUT\\";
//					strWorkspacePath += "Work";
					//TEST end 206  

					String sType = "";
					String sCAD_Type = "";
					boolean isExistCAD = false;
					boolean isExistCADNotCAT = false;
					boolean bFileTypeCheck = false;
					
					String sTempFileType = "";
					
					//
					if ("CATIA Product".equals(sFileType)) {
						if ("Assembly".equals(sTempType)) {
//							isCatiaCadModel = true;
							isExistCAD = true;
							strFormat = "asm";
							sCAD_Type = "assembly";
							sType = cdmConstantsUtil.TYPE_CATPRODUCT;
						}
					}else if("AutoCAD".equals(sFileType)){
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
						}
						if ("Image Drawing".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
						}
					}else if("CATIA Drawing".equals(sFileType)){
//						System.out.println("sTempType =-> "+ sTempType);
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
							//PDF ,ZIP 존재가능
						}
						
						if("Image Drawing".equals(sTempType)) {
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
							sFileType = "Image";							
						}
						
						if("V4 Model".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
							isExistCADNotCAT = true;
						}
						
						if("Drawing".equals(sTempType)){
							strFormat = "drw";
							sCAD_Type = "drawing";
//							isCatiaCadModel = true;
							isExistCAD = true;
							sType = "CATDrawing";
							
						}
						
						//Exchange 는 제외함 
					}else if("DXF".equals(sFileType)){
						sType = "cdmDXF";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
					}else if("CATIA cgm".equals(sFileType)){
						sType = "cdmCATIAcgm";
						sFileType = "CATIA cgm";
						isExistCADNotCAT = true;
					}else if("STEP".equals(sFileType)){
						sType = cdmConstantsUtil.TYPE_CDMSTEP;
						isExistCADNotCAT = true;
					}else if("CATIA Material".equals(sFileType)){
						sType = cdmConstantsUtil.TYPE_CDMCATIAMATERIAL;
						isExistCADNotCAT = true;
					}else if("CATIA Model".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CATPART;
//							isCatiaCadModel = true;
							isExistCAD = true;
							strFormat = "prt";
							sCAD_Type = "component";
						}
						if("V4 Model".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
							isExistCADNotCAT = true;
						}
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
						}
						
					}else if("CATIA Part".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CATPART;
//							isCatiaCadModel = true;
							isExistCAD = true;
							strFormat = "prt";
							sCAD_Type = "component";
						}
					}else if("IGES".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = "cdmIGES";
							bFileTypeCheck = true;
//							sFileType = "";
						}
					}else if("PDF".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
							sFileType = "Image";
//							sFileType = "";
						}
						if("AutoCAD".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}
					}else if("STEP".equals(sFileType)){
						sType = "cdmSTEP";
						isExistCADNotCAT = true;
					}else if("Text".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
							sType = "cdmImageDrawing";
							sFileType = "Image";
						}
					}else if("Unigraphics".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
							sType = "cdmImageDrawing";
						}
						if("UG NX Drawing".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
							isExistCADNotCAT = true;
						}
						if("UG NX Part".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMNXPART;
							isExistCADNotCAT = true;
						}
					}else if("ZIP".equals(sFileType)){
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//							sFileType = "";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}
					}else if("CATIA cgr".equals(sFileType)){
						sType = "cdmCATIAcgr";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
					}else if("CATIA Material".equals(sFileType)){
						sType = "cdmCATIAMaterial";
//						sFileType = "";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
						
					}else{
						
					}
					
					if (StringUtils.isEmpty(sType)) {
						// Image Drawing 파일 타입이 존재하지 않는 경우 제외
						sType = "cdmImageDrawing";
//						sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
						sFileType = "Image";
					}
					
					if(bFileTypeCheck){
						sTempFileType = "";
					}else{
						sTempFileType = sFileType;
					}
					//
					
					
					File file = new File(strWorkspacePath+File.separator+sFileName);
					boolean isEixstFile = file.exists();
					if(!isEixstFile){
						String errorMessage = "NOT FIND FILE. "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;;
						throw new Exception(errorMessage);
					}
//					boolean bCgrFileExist = false; 
//					boolean b3dXmlFileExist = false; 
					String tempCgrFileName = "";
					String temp3dxmlFileName = "";
					String tempCgmFileName = "";
					
					String tempCgrObjectFileName = "";
					String temp3dxmlObjectFileName = "";
					String tempCgmObjectFileName = "";
					
					tempCgrFileName = sFileName;
					temp3dxmlFileName = sFileName;
					tempCgmFileName = sFileName;
					
					int intLastCGRExtension = tempCgrFileName.lastIndexOf(".");
					tempCgrFileName = tempCgrFileName.substring(0, intLastCGRExtension)+"."+sType+".cgr";
					
					int intLast3dxmlExtension = temp3dxmlFileName.lastIndexOf(".");
					temp3dxmlFileName = temp3dxmlFileName.substring(0, intLast3dxmlExtension)+"."+sType+".3dxml";
				
					int intLastCgmExtension = tempCgmFileName.lastIndexOf(".");
					tempCgmFileName = tempCgmFileName.substring(0,intLastCgmExtension)+"."+sType+ ".cgm";
							
					File cgrFile = new File(strWorkspacePath+File.separator+tempCgrFileName);
					boolean isExistCGRFile = cgrFile.exists();
					
					File xmlFile = new File(strWorkspacePath+File.separator+temp3dxmlFileName);
					boolean isExistXmlFile = xmlFile.exists();
					
					File cgmFile = new File(strWorkspacePath+File.separator+tempCgmFileName);
					boolean isExistCGMFile = cgmFile.exists();
					
					//change name
					tempCgrObjectFileName = sRef_FileName;
					temp3dxmlObjectFileName = sRef_FileName;
					tempCgmObjectFileName = sRef_FileName;
					
					tempCgrObjectFileName = tempCgrObjectFileName.substring(0,tempCgrObjectFileName.lastIndexOf("."))+"."+sType+".cgr";
					temp3dxmlObjectFileName = temp3dxmlObjectFileName.substring(0,temp3dxmlObjectFileName.lastIndexOf("."))+"."+sType+".3dxml";
					tempCgmObjectFileName = tempCgmObjectFileName.substring(0,tempCgmObjectFileName.lastIndexOf("."))+"."+sType+".cgm";
					String sRevisionSeqence = "";
					sRevisionSeqence = sTempRevision;

					if (sRevisionSeqence.contains(".")) {
						StringList sListSplitRevision = FrameworkUtil.split(sRevisionSeqence, ".");
						sRevisionSeqence = (String) sListSplitRevision.get(0);
					}
					
					String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
//					String relViewable = "Viewable";
					String cgrObjectId = "";
					String xmlObjectId = "";
					String cgmObjectId = "";
					
					/*
					 * *********************************************************
					 * object name 설정. sCAD_REF_FILE_NAME 데이타가 존재하지않는다면 에러 처리.
					 * *********************************************************
					 */
//					String sName = "";
//					String cadMajorFileName = "";
//					String cadMajorExtension = "";
					if (UIUtil.isNotNullAndNotEmpty(sRef_FileName)) {
//						int intLastExtension = sRef_FileName.lastIndexOf(".");
//						cadMajorExtension = sRef_FileName.substring(intLastExtension);
//						sName = sRef_FileName.substring(0, intLastExtension);
//						sName = sName.trim();
					} else {
						String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;
						throw new Exception(sErrorMessage);
					}
					
					
					String checkCADVehicle = "";
					String checkCADProject = "";
					boolean checkCGR = false;
					boolean checkXML = false;
					boolean checkCgm = false;
					String sViewableName = sRealName+"."+sType;
					ContextUtil.startTransaction(context, true);
					if (isExistCAD ) {

						/*
						 * *****************************************************
						 * REVISION 정보가 없다면 에러 처리. REVISION 설정 .
						 * *****************************************************
						 * 
						 */
						if (cdmStringUtil.isEmpty(sRevisionSeqence)) {
							String errorMessage = "NOT EXIST REVISION DATA. ";
							throw new Exception(errorMessage);
						}
						/*sName 값이 중복케이스가 존재하여 임의로 name 데이타 정보 추가하여 tnr의 name 정보로 사용된다. 0103 */
						BusinessObject existBusinessObj = new BusinessObject(sType,sRealName, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						BusinessObject existMinorBusinessObj = new BusinessObject(sType, sRealName, minorRevString, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						
						boolean isMajorExist = existBusinessObj.exists(context);
						String reviseCheckM = "";
						String sHasFileExistCheck = "";
						if(isMajorExist){
							reviseCheckM = existBusinessObj.getAttributeValues(context, "cdmRevisionCheckInM").getValue();
							String existId = existBusinessObj.getObjectId(context);
							DomainObject existDObj = new DomainObject(existId);
							
							sHasFileExistCheck = (String)existDObj.getInfo(context, "format.hasfile");
							
							
						}
						if (isMajorExist && UIUtil.isNotNullAndNotEmpty(reviseCheckM) && reviseCheckM.equals(sTempRevision) && "FALSE".equalsIgnoreCase(sHasFileExistCheck)) {
							
							existBusinessObj.checkinFile(context, false, false, "", strFormat,  sFileName, strWorkspacePath); 
							
							String cadId = existBusinessObj.getObjectId(context);
							if(!sFileName.equals(sRef_FileName)){
								MqlUtil.mqlCommand(context, "mod bus $1  rename format $2 $3 file $4 $5 ",cadId, strFormat,"!propagaterename",sFileName,sRef_FileName);
							}
							//xmlObjectId cgrObjectId
							DomainObject cadDobj = new DomainObject(cadId);
							DomainObject viewableDobj = new DomainObject();
							
							String sCgmUsers = cadDobj.getOwner(context).getName();
							sCgmUsers = isVaildNullData(sCgmUsers);
							String sViewableUsers = cadDobj.getOwner(context).getName();
							sViewableUsers = isVaildNullData(sViewableUsers);
							
							checkCADVehicle = (String)cadDobj.getInfo(context, "project");
							checkCADProject = (String)cadDobj.getInfo(context, "organization");
							
							BusinessObject lastRevivionObj = cadDobj.getLastRevision(context);
							String sLastRevisionObjId = lastRevivionObj.getObjectId(context);
							//cgm 
							if(isExistCGMFile && "CATDrawing".equals(sType) && cadId.equals(sLastRevisionObjId)){
								
								String cgmType = "Derived Output";
								String cgmPolicy = "Derived Output TEAM Policy";
								String attributeCADType = "cgmOutput";
								
								DomainObject cgmDboj = new DomainObject();
								String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
								
								cgmDboj.createObject(context, cgmType,sViewableName , minorRevString, cgmPolicy, vault);
								
								cgmObjectId = cgmDboj.getId(context);
								cgmDboj.checkinFile(context, false, false, "", "CGM", tempCgmFileName, strWorkspacePath);
								if(!tempCgrFileName.equals(tempCgrObjectFileName)){
									MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",cgmObjectId, "CGM","!propagaterename",tempCgmFileName,tempCgmObjectFileName);
								}
								checkCgm = true;
								if(UIUtil.isNotNullAndNotEmpty(sCgmUsers)){
									cgmDboj.setAttributeValue(context, "Originator",sCgmUsers);
									cgmDboj.setOwner(context, cadDobj.getOwner(context));
								}
//									cgmDboj.setAttributeValue(context, "cdmCheckMigration","Y");
									cgmDboj.setAttributeValue(context, "CAD Type", attributeCADType);
								
								DomainRelationship connectDerivedOutRel= new DomainRelationship();
								connectDerivedOutRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Derived Output"),cgmDboj );
								connectDerivedOutRel.setAttributeValue(context, "CAD Object Name", sRealName);
								
								String minorObjectId = existMinorBusinessObj.getObjectId(context);
								if(UIUtil.isNotNullAndNotEmpty(minorObjectId)){
									DomainObject cadMinorDobj = new DomainObject(minorObjectId);
									DomainRelationship connectMinorDerivedOutRel= new DomainRelationship();
									connectMinorDerivedOutRel = DomainRelationship.connect(context, cadMinorDobj, new RelationshipType("Derived Output"),cgmDboj );
									connectMinorDerivedOutRel.setAttributeValue(context, "CAD Object Name", sRealName);
								}
								
							}
							
							//cgr ,3dxml
//							if((isExistCGRFile || isExistXmlFile) && ("CATPart".equals(sType)|| "CATProduct".equals(sType))  ){
//								
//								if(isExistCGRFile){
//									String viewcgrType = "CgrViewable";
//									String view3dXmlPolicy = "Viewable TEAM Policy";
//									String attributeCADType = "cgrOutput";
//									
//									DomainObject cgrDboj = new DomainObject();
//									String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
//									BusinessObject CheckBus = new BusinessObject(viewcgrType,sViewableName,minorRevString,"");
//									boolean checkeeee = CheckBus.exists(context);
//									System.out.println("exist cgr"+checkeeee);
//									if(CheckBus.exists(context)){
//										System.out.println("exist cgr"+CheckBus.getObjectId(context));
//									}
//									cgrDboj.createObject(context, viewcgrType,sViewableName , minorRevString, view3dXmlPolicy, vault);
//									cgrObjectId = cgrDboj.getObjectId(context);
//									BusinessObject busCgr = new BusinessObject(cgrObjectId);
//									busCgr.checkinFile(context, false, false, "", "CGR", tempCgrFileName, strWorkspacePath);
////									busCgr.checkinFile(context, false, false, null, "CGR", "STORE", tempCgrFileName, strWorkspacePath);
//									if(!tempCgrFileName.equals(tempCgrObjectFileName)){
//										MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",cgrObjectId, "CGR","!propagaterename",tempCgrFileName,tempCgrObjectFileName);
//									}
//									
//									
//									checkCGR = true;
//									if(UIUtil.isNotNullAndNotEmpty(sViewableUsers)){
//										busCgr.setAttributeValue(context, "Originator",sViewableUsers);
//										busCgr.setAttributeValue(context, "cdmCheckMigration","Y");
//										busCgr.setAttributeValue(context, "CAD Type", attributeCADType);
//										busCgr.setOwner(context, cadDobj.getOwner(context));
//									}
//									viewableDobj.setId(cgrObjectId);
//									DomainRelationship connectRel= new DomainRelationship();
//									connectRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
////									connectRel.setAttributeValue(context, "CAD Object Name", sName);
//									connectRel.setAttributeValue(context, "CAD Object Name", sRealName);
//									if(existMinorBusinessObj.exists(context)){
//										
//										cadDobj.setId(existMinorBusinessObj.getObjectId(context));
//										DomainRelationship connectMinorRel= new DomainRelationship();
//										connectMinorRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
////										connectMinorRel.setAttributeValue(context, "CAD Object Name", sName);
//										connectMinorRel.setAttributeValue(context, "CAD Object Name", sRealName);
//									}
//								}
////								//연결한 CAT originator 혹은 Person 정보와 일치시킨다.  없으면 admin
////								
//								if (isExistXmlFile) {
//
//									String view3dXmlType = "3dxmlViewable";
//									String view3dXmlPolicy = "Viewable TEAM Policy";
//									String attributeCADType = "3dxmlOutput";
//									String originator = "";
//									cadDobj.setId(cadId);
//									DomainObject xmlDboj = new DomainObject();
//									String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
//									
//									BusinessObject CheckBus = new BusinessObject(view3dXmlType,sViewableName,minorRevString,vault);
//									if(CheckBus.exists(context)){
//										System.out.println("exist xml"+CheckBus.getObjectId(context));
//									}
//									xmlDboj.createObject(context, view3dXmlType, sViewableName, minorRevString, view3dXmlPolicy, vault);
//									xmlObjectId = xmlDboj.getObjectId(context);
//									xmlDboj.setAttributeValue(context, "CAD Type", attributeCADType);
//									BusinessObject busXml = new BusinessObject(xmlObjectId);
//									busXml.checkinFile(context, false, false, "", "3DXML", temp3dxmlFileName, strWorkspacePath);
////									busXml.checkinFile(context, false, false, null, "3DXML", "STORE", temp3dxmlFileName, strWorkspacePath);
//									if(!temp3dxmlFileName.equals(temp3dxmlObjectFileName)){
//										MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file  $4 $5", xmlObjectId, "3DXML", "!propagaterename",temp3dxmlFileName, temp3dxmlObjectFileName);
//									}
//									busXml.setOwner(context, cadDobj.getOwner(context));
//									// DomainRelationship viewable = new
//									// DomainRelationship();
//									// viewable.connect(context, xmlObjectId,
//									// relViewable, paramDomainObject2)
//									checkXML = true;
//									if(UIUtil.isNotNullAndNotEmpty(sViewableUsers)){
//										busXml.setAttributeValue(context, "Originator",sViewableUsers);
//										busXml.setAttributeValue(context, "cdmCheckMigration","Y");
//										busXml.setOwner(context, cadDobj.getOwner(context));
//									}
//
//									viewableDobj.setId(xmlObjectId);
//									DomainRelationship connectRel = new DomainRelationship();
//									connectRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
////									connectRel.setAttributeValue(context, "CAD Object Name", sName);
//									connectRel.setAttributeValue(context, "CAD Object Name", sRealName);
//									if (existMinorBusinessObj.exists(context)) {
//
//										cadDobj.setId(existMinorBusinessObj.getObjectId(context));
//										DomainRelationship connectMinorRel = new DomainRelationship();
//										connectMinorRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
//										connectMinorRel.setAttributeValue(context, "CAD Object Name", sRealName);
////										connectMinorRel.setAttributeValue(context, "CAD Object Name", sName);
//									}
//								}
//							}
//							successInt++;
							
							
						} else {
							String errorMessage = "NOT EXIST MAJOR OBJECT. \t type: \t"+sType+"\t Name: \t"+sRealName +"\t rev: \t"+sTempRevision;
							throw new Exception(errorMessage);
						}

					} else {
						/*
						 * Document 타입일 경우 Document 의 경우 'Document Release'
						 * policy 인 object 에 모든 파일이 저장되며 revision의 object의 경우에도
						 * 파일이 이동하지않고 변경한 데이타들이 저장 파일 이 추가 될
						 * cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성
						 */

						// DomainObject documentBusObj = new DomainObject();
						// DomainObject documentMinorBusObj = new
						// DomainObject();
						strFormat = "generic";
						BusinessObject existdocumentBusObj = new BusinessObject(sType, sRealName, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						boolean isMajorDocumentObjExist = existdocumentBusObj.exists(context);
						String reviseCheckM = "";
						String sHasFileExistDocumentCheck = "";
						if(isMajorDocumentObjExist){
							reviseCheckM = existdocumentBusObj.getAttributeValues(context, "cdmRevisionCheckInM").getValue();
							String existDocumentId = existdocumentBusObj.getObjectId(context);
							DomainObject existDocumentDObj = new DomainObject(existDocumentId);
							sHasFileExistDocumentCheck = (String)existDocumentDObj.getInfo(context, "format.hasfile");
						}
						
						if (isMajorDocumentObjExist && UIUtil.isNotNullAndNotEmpty(reviseCheckM) && reviseCheckM.equals(sTempRevision) && "FALSE".equalsIgnoreCase(sHasFileExistDocumentCheck)) {
							existdocumentBusObj.checkinFile(context, false, false, "", strFormat, sFileName, strWorkspacePath);

							String documentBusId= existdocumentBusObj.getObjectId(context);
							if(!sFileName.equals(sRef_FileName)){
								MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",documentBusId, strFormat,"!propagaterename",sFileName,sRef_FileName);
							}
						} else {
							
							String errorMessage = "NOT EXIST MAJOR DOCUMENT  OBJECT. \t type: \t"+sType+"\t Name: \t"+sRealName +"\t rev: \t"+sTempRevision;
							throw new Exception(errorMessage);
						}

					}
					ContextUtil.commitTransaction(context);
					successInt++;
					boolean bProjectOrg = false;
					/* project org 설정 */
					try {
						checkCADVehicle = isVaildNullData(checkCADVehicle);
						checkCADProject = isVaildNullData(checkCADProject);
						if (isExistCAD && UIUtil.isNotNullAndNotEmpty(checkCADVehicle) && UIUtil.isNotNullAndNotEmpty(checkCADProject) && (UIUtil.isNotNullAndNotEmpty(cgmObjectId))) {

//							if (UIUtil.isNotNullAndNotEmpty(cgrObjectId)) {
//								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", cgrObjectId, checkCADProject, checkCADVehicle);
//
//							}
//							if (UIUtil.isNotNullAndNotEmpty(xmlObjectId)) {
//								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", xmlObjectId, checkCADProject, checkCADVehicle);
//							}
							if (UIUtil.isNotNullAndNotEmpty(cgmObjectId)) {
								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", cgmObjectId, checkCADProject, checkCADVehicle);

							}
							bProjectOrg = true;
						}else{
							bProjectOrg = false;
						}
					}catch(Exception e4){
						bProjectOrg = false;
					}
					writeSuccessToFile(recordRowNum + "\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+checkXML+"\t"+checkCGR +"\t"+bProjectOrg+"\t"+checkCADProject+"\t"+checkCADVehicle);
//					writeMessageToConsole(recordRowNum + "\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+checkXML+"\t"+checkCGR+"\t"+bProjectOrg+"\t"+checkCADProject+"\t"+checkCADVehicle);
					
					
					
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failedInt++;
					String message = exception.getMessage();
					
					if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not a valid type or filetype.")){
						writeMessageToConsole(recordRowNum + "\t"+"1"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"1"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST CAD_REF_FILE_NAME FILE DATA .") ){
						writeMessageToConsole(recordRowNum + "\t"+"2"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"2"+"\t"+stReadData);
						
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR DOCUMENT")){
						writeMessageToConsole(recordRowNum + "\t"+"3"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR OBJECT.")){
						
						writeMessageToConsole(recordRowNum + "\t"+"4"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"4"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST REVISION DATA.")){
						writeMessageToConsole(recordRowNum + "\t"+"5"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"5"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT FIND FILE.")){
						writeMessageToConsole(recordRowNum + "\t"+"6"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"6"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT MATCH ROW INFOMATION")){
						writeMessageToConsole(recordRowNum + "\t"+"7"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"7"+"\t"+stReadData);
					}
					
					else{
						writeMessageToConsole(recordRowNum + "\t"+"7"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t"+stReadData);
						
					}
					writeErrorToFile("LineNum(#)"+recordRowNum+"\t"+recordRowTdmxId+"\t"+recordRowRevision);
					exception.printStackTrace(errorStream);

				}finally{
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			MqlUtil.mqlCommand(context, "Trigger On");
			MqlUtil.mqlCommand(context, "history on");
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms        \n");
			writeMessageToConsole("End Time :("+cdmCommonExcel.getTimeStamp2() +")  Total Count:("+(totalCount-1)+") Success Count:("+successInt+") notMacthType:("+notMatchTypeCount+"  Fail Count: ("+failedInt+")");
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			
			
			System.out.println("[cdmCADMigration_mxJPO : excuteCadCheckin] end ." + cdmCommonExcel.getTimeStamp2() );
		}
	}

	/**
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
//	public void modifyCreate(Context context ,String args[])throws Exception{
//
//
//		String sCATIA_Product = "CATIA Product";
//		String sSTEP = "STEP";
//				
//		if(args.length!=1){
//			throw new Exception("The excel path does not exist.");
//		}
//		String sFileLocationAndFileName = args[0];
//
//		String cadFileLocation = "";
//		String cadFileName = "";
//
//		cadFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
//		cadFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
//		
////		Map paramMap = new HashMap();
////		paramMap = (Map) JPO.unpackArgs(args);
////
////		cadFileLocation = (String) paramMap.get("File_Location");
////		cadFileName = (String) paramMap.get("File");
//
//		long startTime = System.currentTimeMillis();
//		System.out.println("[${CLASS:cdmCADMigration} : ModifyCadMigration] start ." + getTimeStamp());
//
//		String logFileName = "ModifyCadMigration";
//		int successInt = 0;
//		int failInt = 0;
//		int notExist = 0;
//		// String[] argTemp =
//		// {"C:\\temp\\Import_File\\CAD","CAD_Items_FULL_02.txt"}; //읽을 파일경로 ,읽을
//		// 파일명
//		String[] argTemp = null;
//		if (cdmStringUtil.isNotEmpty(cadFileLocation) && cdmStringUtil.isNotEmpty(cadFileName)) {
//			argTemp = new String[] { cadFileLocation, cadFileName }; // 읽을 파일경로
//																		// ,읽을
//																		// 파일명
//		} else {
//			argTemp = new String[] {};
//		}
//		initializeM(context, argTemp, 2, logFileName); // context , artTest,
//														// argTest 갯수 체크을위한 수,
//														// 로그 파일명의 default 파일명.
//		writeMessageToConsole("====================================================================================");
//		writeMessageToConsole("CAD DATA MIGRATION " + getTimeStamp() + " \n");
//		writeMessageToConsole("Reading input log file from : " + inputDirectory+cadFileName);
//		writeMessageToConsole("Writing Log files to: " + outputDirectory);
//		writeMessageToConsole("====================================================================================\n");
////		writeSuccessToFile(cdmCommonExcel.getTimeStamp2() +"\t"+ recordRowNum+"\t"+sType+"\t" +sName +"\t"+sbErrorMessage.toString());
//		writeSuccessToFile("CreateTime \t rowNum(#) \t type \t name \t no exist Part name \t no exist Part rev \t Type \t Major Name \t major org && project \t minor org && project \t  ");
//		int lineNumber = 0;
//		StringList sListHeader = new StringList();
//		String recordRowNum = "";
//		try {
//			
//			String sReadData = "";
//			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
//			while ((sReadData = bufferReader.readLine()) != null) {
//				StringList sListReadData = FrameworkUtil.split(sReadData, "\t");
//
//				if (lineNumber == 0) {
//					sListHeader = sListReadData;
//					lineNumber++;
//					continue;
//				}
//				lineNumber++;
//				
//				
//				int headerSize = sListHeader.size();
//				int readLineSize = sListReadData.size();
//				try {
//					if (headerSize != readLineSize) {
//						String errorMessage = "NOT MATCH" + sListReadData.toString() + " || " + sListHeader.toString();
//						throw new Exception(errorMessage);
//					}
//
//					LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();
//
//					for (int dataCnt = 0; dataCnt < sListReadData.size(); dataCnt++) {
//
//						String stTempCadInfos = (String) sListReadData.get(dataCnt);
//						String stTempCadInfosHeader = (String) sListHeader.get(dataCnt);
//						// 공백제거,null 처리,trim처리
//						stTempCadInfos = isVaildNullData(stTempCadInfos);
//						linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);
//
//					}
//
//					if (lineNumber == 1) {
//						continue;
//					}
//					MqlUtil.mqlCommand(context, "history Off");
//					StringBuffer sbErrorMessage = new StringBuffer(""); 
//					recordRowNum = (String) linkedCadHM.get("#");
//					String sTempType = (String) linkedCadHM.get("CLS_NAME"); // 1,Type
//					String sTdmxId = (String) linkedCadHM.get("TDMX_ID"); // 2 ,attribute[cdmTDMXID]
//					String sRevision = (String) linkedCadHM.get("REVISION"); // 3,Revision
//					String sUsers = (String) linkedCadHM.get("CRT_USERS"); // 4 ,originator,owner
//					String sTdm_Description = (String) linkedCadHM.get("TDM_DESCRIPTION"); // 5
//					String sRelated_PartName = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6
//					// String sTdmx_CAD_Identifier = (String)linkedCadHM.get("TDMX_CAD_IDENTIFIER"); // 7 , 
//					String sTdmx_Detailed_Description = (String) linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); // 8
////					String sTdmx_Comments = (String) linkedCadHM.get("TDMX_COMMENTS"); // 9
//					String sTdmx_3d_Cad_Identifier = (String) linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); // 10,
//					String sTdmx_Title_Type = (String) linkedCadHM.get("TDMX_TITLE_TYPE"); // 11,
//					String sTdmx_Scale = (String) linkedCadHM.get("TDMX_SCALE"); // 12,
//					String sTdmx_Page_Size = (String) linkedCadHM.get("TDMX_PAGE_SIZE"); // 13,
//					String sFile_Type = (String) linkedCadHM.get("FILE_TYPE"); // 14,
//					// String sFile_Name = (String)linkedCadHM.get("FILE_NAME"); // 15,
//
//					String sRef_FileName = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); // 16, ORIGINAL FILE
//					// String sVault_Object_Id = (String)linkedCadHM.get("VAULT_OBJECT_ID"); // 17,
//					// String sPhase = (String)linkedCadHM.get("PHASE"); // 18,
//					// String sTdm_Org_User_Id = (String)linkedCadHM.get("TDM_ORG_USER_ID"); // 19,
//					String sTdm_Document_Type = (String) linkedCadHM.get("TDM_DOCUMENT_TYPE"); // 20,
//					// String sTDM_ARCHIVE_TYPE = (String)linkedCadHM.get("TDM_ARCHIVE_TYPE"); // 21,
//					// String sTDM_ARCHIVE_NAME = (String)linkedCadHM.get("TDM_ARCHIVE_NAME"); // 22,
//					// String sPROD_DIV = (String)linkedCadHM.get("PROD_DIV"); // 23,
//					String sCN_Project = (String) linkedCadHM.get("CN_PROJECT"); // 24,
//					// String sCN_PROJECT =(String)linkedCadHM.get("CN_PROJECT"); // 25, 중복 데이타 이므로 무시함
//					String sCN_PROJECT_CUST = (String)linkedCadHM.get("CN_PROJECT_CUST"); // 26,
//					String sMass = (String) linkedCadHM.get("CN_MASS"); // 27,
//					String sSurface_Area = (String) linkedCadHM.get("CN_SURFACE_AREA"); // 28,
//					// String sCN_OEM_PART_NUMBER = (String)linkedCadHM.get("CN_OEM_PART_NUMBER"); // 29,
//					// String sCN_ECO_NUMBER = (String)linkedCadHM.get("CN_ECO_NUMBER"); // 30,
//					// String sCN_MASS_ESTIMATED = (String)linkedCadHM.get("CN_MASS_ESTIMATED"); // 31,
//					// String sCN_PRODUCT_GROUP = (String)linkedCadHM.get("CN_PRODUCT_GROUP"); // 32,
//					// String sCN_CUSTOMER = (String)linkedCadHM.get("CN_CUSTOMER"); // 33,
//					// String sCN_VEHICLE = (String)linkedCadHM.get("CN_VEHICLE"); // 34, 이 데이타는 migration 대상자 아님
//					// String sCN_RELATED_ITEM_NAME = (String)linkedCadHM.get("CN_RELATED_ITEM_NAME"); // 35,
//					String sRelated_PartRev = (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
//					String sProjectId = (String) linkedCadHM.get("CN_PROJECT_ID"); // 37,
//					String sRelated_PG = (String) linkedCadHM.get("PROD_GROUP"); // 38,
//					String sRelated_VehicldeCust = (String) linkedCadHM.get("CN_CUST_VEHICLE"); // 39
//					String Creationdate = (String) linkedCadHM.get("CREATION_DATE"); // 39
//
//					String parentRelName = cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
//					String sType = "";
//					String sPartFindObjId = "";
//					boolean IsExistPerson = false; // Person 정보 확인
//					String sName = "";
//					String sRevisionSeqence = "";
//					String stObjectId = "";
//					String sCAD_Type = "";
//					String strFormat = "";
//					// String strWorkspacePath = "";
//
//					boolean isExistCAD = false;
//					/*
//					 * file type 에 따라 sCAD_Type 명이 다르다.
//					 * 
//					 */
//
//					if ("Assembly".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CATPRODUCT;
//						isExistCAD = true;
//						strFormat = "asm";
//
//						if (!"CATIA Product".equals(sFile_Type)) {
//
//							String errorMessage = "This is not a valid format.";
//							throw new Exception(errorMessage);
//						}
//						sCAD_Type = "assembly";
//					} else if ("AutoCAD".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//					} else if ("Image Drawing".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
//					} else if ("Drawing".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CATDrawing;
//						isExistCAD = true;
//
//						if ("CATIA Part".equals(sFile_Type)) {
//							String errorMessage = "This is not a valid format.(CATIA Part)";
//							throw new Exception(errorMessage);
//						} else if ("CATIA cgm".equals(sFile_Type)) {
//							String errorMessage = "This is not a valid format.(CATIA cgm)";
//							throw new Exception(errorMessage);
//						}else if("STEP".equals(sFile_Type)){
//							String errorMessage = "This is not a valid format.(STEP)";
//							throw new Exception(errorMessage);
//						}else {
//							strFormat = "drw";
//						}
//						sCAD_Type = "drawing";
//
//					} else if ("Part".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CATPART;
//						isExistCAD = true;
//						if("IGES".equals(sFile_Type)){
//							strFormat="IGES";
//							sCAD_Type = "component";
//						}else if("STEP".equals(sFile_Type)){
//							String errorMessage = "This is not a valid format.(STEP)";
//							throw new Exception(errorMessage);
//						}else {
//							strFormat = "prt";
//							sCAD_Type = "component";
//						}
//
//					} else if ("V4 Model".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
//					} else if ("UG NX Drawing".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
//					} else {
//
//						/*
//						 * *****************************************************
//						 *  Type 정보가 없다면 에러 처리.
//						 * *****************************************************
//						 */
////						StringBuffer errorBuf = new StringBuffer();
////						errorBuf.append("NOT MATCH TYPE INFOAMTION. ");
////						throw new Exception(errorBuf.toString());
//						continue;
//
//					}
//					
//					/*
//					 * *********************************************************
//					 * 	PART 데이타 있는데 OBJECT 정보가 존재하지 않는다면 에러 발생
//					 * 	존재한다면 연결 연결 정보는 Part Specification 으로 연결
//					 * *********************************************************
//					 * 
//					 */
//
//					if (cdmStringUtil.isNotEmpty(sRelated_PartName) && cdmStringUtil.isNotEmpty(sRelated_PartRev)) {
//						String sPartFindMql = MqlUtil.mqlCommand(context, "temp query bus '" + partType + "' '" + sRelated_PartName + "'  '" + sRelated_PartRev + "' select id dump |");
//						StringList sListPartFindMqlResult = FrameworkUtil.split(sPartFindMql, "|");
//						if (sListPartFindMqlResult.size() > 2) {
//							sPartFindObjId = (String) sListPartFindMqlResult.get(3);
//							
//							sbErrorMessage.append("X").append("\t").append("X").append("\t");
//						} else {
//							sbErrorMessage.append(sRelated_PartName).append("\t").append(sRelated_PartRev).append("\t");
////							StringBuffer errorBuff = new StringBuffer();
////							errorBuff.append("NOT FIND PART OBJECT IN ENOVIA. ");
////							throw new Exception(errorBuff.toString());
//						}
//					}
//
//					/*
//					 * *********************************************************
//					 * Person 정보 확인.
//					 * *********************************************************
//					 */
//					
//					StringList fileType = new StringList();
//					
//					fileType.add("Microsoft Excel");
//					fileType.add("Unigraphics");
//					fileType.add("STEP");
//					fileType.add("CATIA cgm");
//					fileType.add("CATIA Model");
//					fileType.add("Image");
//					fileType.add("CATIA Product");
//					fileType.add("AutoCAD");
//					fileType.add("CATIA Part");
//					fileType.add("CATIA Drawing");
//					/*
//					 * *********************************************************
//					 *  object name 설정. sCAD_REF_FILE_NAME 데이타가
//					 * 존재하지않는다면 에러 처리 .
//					 * *********************************************************
//					 * 
//					 */
//					if (cdmStringUtil.isNotEmpty(sRef_FileName)) {
//						int intLastExtension = sRef_FileName.lastIndexOf(".");
//						sName = sRef_FileName.substring(0, intLastExtension);
//						sName = sName.trim();
//					} else {
//						String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . ";
//						throw new Exception(sErrorMessage);
//					}
//					boolean bAlreadyExist = false;
//					
//					String exsitMajorObjId = "";
//					String exsitMinorObjId = "";
//					AttributeList majorlocalAttributeList = new AttributeList();
//					AttributeList minorlocalAttributeList = new AttributeList();
//					Map docAttrMap = new HashMap();
//					ContextUtil.startTransaction(context, true);
//					if (isExistCAD) {
//
//						MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
//						IEFGlobalCache cache = new IEFGlobalCache();
//						MCADGlobalConfigObject globalConfigObject = null;
//						MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
//
//						/*
//						 * *****************************************************
//						 * REVISION 정보가 없다면 에러 처리. REVISION 설정 .
//						 * 
//						 * *****************************************************
//						 */
//						if (cdmStringUtil.isEmpty(sRevision)) {
//							String errorMessage = "NOT EXIST REVISION DATA. ";
//							throw new Exception(errorMessage);
//						}
//						
////						if (!"---".equals(sRevision)) {
////
////							Policy policyDesignTeamDefine = new Policy(cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION);
////							policyDesignTeamDefine.open(context);
////
////							String stPolicySequence = policyDesignTeamDefine.getSequence(context);
////							policyDesignTeamDefine.close(context);
////
////							int iSeqenceNumber = 0; // SEQUNCE
////							boolean checkSequence = false;
////							StringList stListPolicy = FrameworkUtil.split(stPolicySequence, ",");
////							for (int iPolicyCnt = 0; iPolicyCnt < stListPolicy.size(); iPolicyCnt++) {
////								String sPolicySequence = (String) stListPolicy.get(iPolicyCnt);
////
////								String tempSequence = sPolicySequence.replaceAll("-", "");
////								if (cdmStringUtil.isNotEmpty(tempSequence) && sRevision.equals(tempSequence)) {
////									iSeqenceNumber = iPolicyCnt;
////									checkSequence = true;
////								}
////							}
////							sRevisionSeqence = (String) stListPolicy.get(iSeqenceNumber);
////							/*
////							 * *************************************************
////							 *  파일정보의 revision 정보와 policy 정보가
////							 * 일치하는것이 없다면 에러 처리.
////							 * *************************************************
////							 * 
////							 */
////							if (!checkSequence) {
////								String errorMessage = "NOT MATCH POLICY SEQUENCE AND REVISION DATA. ";
////								throw new Exception(errorMessage);
////							}
////						} else {
////							sRevisionSeqence = sRevision;
////						}
//						sRevisionSeqence = sRevision;
//						BusinessObject existBusinessObj = new BusinessObject(sType, sName, sRevisionSeqence, "");
//						String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
//						BusinessObject existMinorBusinessObj = new BusinessObject(sType, sName, minorRevString, "");
//
//						boolean isMajorExist = existBusinessObj.exists(context);
//						boolean istMinorExist = existMinorBusinessObj.exists(context);
//						
//						if (isMajorExist) {
//							
//							if(!fileType.contains(sFile_Type)){
//								String errorMessage = "NOT MATCH attribute[cdmFILETYPE] range  ";
//								throw new Exception(errorMessage);
//							}
//							
//							String sAttribute_CADType = MCADMxUtil.getActualNameForAEFData(context, "attribute_CADType");
//							String sAttribute_MoveFileVersion = MCADMxUtil.getActualNameForAEFData(context, "attribute_MoveFilesToVersion");
//							// original file name 과 데이타가 같다.
//							String sAttribute_Title = MCADMxUtil.getActualNameForAEFData(context, "attribute_Title");
//							String sAttribute_IsVersionObj = MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
//							String sAttribute_IEFFileMessage = MCADMxUtil.getActualNameForAEFData(context, "attribute_IEF-FileMessageDigest");
//							String sAttribute_Source = MCADMxUtil.getActualNameForAEFData(context, "attribute_Source");
//
//
//							/* 속성 입력 start */
//							AttributeList localAttributeList = new AttributeList();
//							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_Title), sRef_FileName));
//							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IEFFileMessage), ""));
//							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_Source), sourceInfo));
//
//							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID), sTdmxId));
//							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION), sTdmx_Detailed_Description));
////							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_COMMENT), sTdmx_Comments));
//							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER), sTdmx_3d_Cad_Identifier));
//							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE), sFile_Type));
//							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE), sTdm_Document_Type));
//							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION), "Y"));
//
//							localAttributeList.addElement(new Attribute(new AttributeType(attributeCADType), sCAD_Type));
//							if ((cdmConstantsUtil.TYPE_CATDrawing).equals(sType)) {
//								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE), sTdmx_Scale));
//								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE), sTdmx_Page_Size));
//								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_PART_DRAWING_NO), sRelated_PartName));
//							}
//
//							if ((cdmConstantsUtil.TYPE_CATPART).equals(sType)) {
//								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS), sMass));
//							}
//
//							if ((cdmConstantsUtil.TYPE_CATPART).equals(sType) || (cdmConstantsUtil.TYPE_CATPRODUCT).equals(sType)) {
//								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE), sSurface_Area));
//							}
//
//							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "True"));
//							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IsVersionObj), "False"));
//							
//							DomainObject majorObject = new DomainObject(existBusinessObj.getObjectId(context));
//							majorObject.setAttributes(context, localAttributeList);
//
//							/* MINOR VERSION */
//							localAttributeList.remove(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "True"));
//							localAttributeList.remove(new Attribute(new AttributeType(sAttribute_IsVersionObj), "False"));
//
//							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "False"));
//							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IsVersionObj), "True"));
//							//에러 소지가 있어 트랜잭션 없는곳에서 데이타 처리
//							DomainObject minorObject = new DomainObject(existMinorBusinessObj.getObjectId(context));
//							minorObject.setAttributes(context, localAttributeList);
//							successInt++;
//						}else{
//							notExist++;
//							writeErrorToFile("LineNum(#)"+recordRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " +"already exist object");
//							
//						}
//					} else {
//						/*
//						 * Document 타입일 경우 Document 의 경우 'Document Release'
//						 * policy 인 object 에 모든 파일이 저장되며 revision의 object의 경우에도
//						 * 파일이 이동하지않고 변경한 데이타들이 저장 파일 이 추가 될
//						 * cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성
//						 * 추가 Originator은 user 정보로 변경 Person 정보가 enovia에 Person
//						 * 정보에 있을시 Owner 추가. 최신 release 정보 을 가지고 생성
//						 */
//
//						BusinessObject existdocumentBusObj = new BusinessObject(sType, sName, sRevision, "");
//						boolean isMajorDocumentObjExist = existdocumentBusObj.exists(context);
//
//						if (isMajorDocumentObjExist) {
//							
//							if(!fileType.contains(sFile_Type)){
//								String errorMessage = "NOT MATCH FILE TYPE ";
//								throw new Exception(errorMessage);
//							}
//							//
//							String policy = "Document Release";
//							String title = sName;
//							String language = null;
//							String isFrom = "true";
//							String objectGeneratorRevision = "";
//							String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
//
//							if (sTdm_Description == null || "".equals(sTdm_Description) || "null".equals(sTdm_Description)) {
//								sTdm_Description = (String) linkedCadHM.get("sTDM_DESCRIPTION");
//							}
//
//							if (sRef_FileName == null || "".equals(sRef_FileName) || "null".equals(sRef_FileName)) {
//								sRef_FileName = null;
//							}
//
//							CommonDocument docObj = (CommonDocument) DomainObject.newInstance(context, CommonDocument.TYPE_DOCUMENTS);
////							DomainObject parentObject = null;
////							if (sPartFindObjId != null && !"".equals(sPartFindObjId) && !"null".equals(sPartFindObjId)) {
////								parentObject = DomainObject.newInstance(context, sPartFindObjId);
////							}
//
//							HashMap<String, Object> mAttrMap = new HashMap<String, Object>();
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE, sTdmx_Page_Size);
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE, sTdmx_Scale);
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_TITLE_TYPE, sTdmx_Title_Type);
//
//							// MIGRATION DATA을 위해 속성 추가 AUTOCAD, ..
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID, sTdmxId);
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION, sTdmx_Detailed_Description);
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER, sTdmx_3d_Cad_Identifier);
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE, sFile_Type);
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE, sTdm_Document_Type);
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, "Y");
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS, sMass);
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE, sSurface_Area);
//							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sUsers);
//							
//							docAttrMap = mAttrMap;
//							
//							DomainObject documentObject = new DomainObject(existdocumentBusObj.getObjectId(context));
//							documentObject.setAttributeValues(context,mAttrMap);
//							
//							
//							
//							StringList selects = new StringList(2);
//							selects.add(DomainConstants.SELECT_ID);
//							selects.add(CommonDocument.SELECT_MOVE_FILES_TO_VERSION);
//							successInt++;
//						} else {
////							bAlreadyExist = true;
//							notExist++;
////							writeErrorToFile("LineNum(#) "+recordRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " +"already exist object");
//							writeMessageToConsole("LineNum(#)"+recordRowNum+" \t"+cdmCommonExcel.getTimeStamp2()+" not exist object");
//						}
//					}
//					ContextUtil.commitTransaction(context);
//					
//					
//				} catch (Exception exception) {
//					ContextUtil.abortTransaction(context);
//					failInt++;
//					writeErrorToFile("LineNum(#)"+recordRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " );
//					exception.printStackTrace(errorStream);
//					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+sReadData);
////					writeMessageToConsole(" Exception: " + exception.getMessage() + " LINE: " + recordRowNum);
////					writeErrorToFile(recordRowNum+exception.getMessage());
//
//				}finally{
//					MqlUtil.mqlCommand(context, "history on");
//				}
//
//			}
//			writeMessageToConsole("====================================================================================");
//			writeMessageToConsole("        File CAD Migration COMPLETED.                    ");
//			writeMessageToConsole("====================================================================================\n");
//
//		} catch (Exception exception) {
//
//			// writeFailToFile("[${CLASS:cdmCADMigration} : executeCadcMigration]
//			// fail occured. LINE NUMBER: " + recordRowNum);
//			// writeErrorToFile("[${CLASS:cdmCADMigration} : executeCadcMigration]
//			// Exception occured. LINE NUMBER: " + recordRowNum + " " +
//			// exception.getMessage());
//			writeMessageToConsole("LINE NUMBER"+recordRowNum+"| "+exception.getMessage());
//			exception.printStackTrace(errorStream);
//		} finally {
//			writeMessageToConsole("====================================================================================");
//			writeMessageToConsole("LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms        \n");
//			writeMessageToConsole("End Time :("+cdmCommonExcel.getTimeStamp2() +")   Success Count:("+successInt+")   Fail Count: ("+failInt+") already Count: ("+notExist+")" );
//			writeMessageToConsole("==================================================================================== \n");
//			closeLogStream();
//			System.out.println("[${CLASS:cdmCADMigration} : executeCadcMigration] end .");
//		}
//	
//	}
	
	
	
	
//	/**
//	 * 
//	 * @param context
//	 * @param args
//	 * @throws Exception
//	 */
//	public void modifyFileName(Context context,String args[])throws Exception{
//
//
//
//		String sCATIA_Product = "CATIA Product";
//		String sSTEP = "STEP";
//				
//		if(args.length!=1){
//			throw new Exception("The excel path does not exist.");
//		}
//		String sFileLocationAndFileName = args[0];
//
//		String cadFileLocation = "";
//		String cadFileName = "";
//
//		cadFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
//		cadFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
//		
////		Map paramMap = new HashMap();
////		paramMap = (Map) JPO.unpackArgs(args);
////
////		cadFileLocation = (String) paramMap.get("File_Location");
////		cadFileName = (String) paramMap.get("File");
//
//		long startTime = System.currentTimeMillis();
//		System.out.println("[${CLASS:cdmCADMigration} : ModifyCadMigration] start ." + getTimeStamp());
//
//		String logFileName = "ModifyCadMigration";
//		int successInt = 0;
//		int failInt = 0;
//		int notExist = 0;
//		// String[] argTemp =
//		// {"C:\\temp\\Import_File\\CAD","CAD_Items_FULL_02.txt"}; //읽을 파일경로 ,읽을
//		// 파일명
//		String[] argTemp = null;
//		if (cdmStringUtil.isNotEmpty(cadFileLocation) && cdmStringUtil.isNotEmpty(cadFileName)) {
//			argTemp = new String[] { cadFileLocation, cadFileName }; // 읽을 파일경로
//																		// ,읽을
//																		// 파일명
//		} else {
//			argTemp = new String[] {};
//		}
//		
//		StringBuffer sbType = new StringBuffer();
//		sbType.append(cdmConstantsUtil.TYPE_CATPRODUCT);
//		sbType.append(",");
//		sbType.append(cdmConstantsUtil.TYPE_CDMAUTOCAD);
//		sbType.append(",");
//		sbType.append(cdmConstantsUtil.TYPE_CDMIMAGEDRAWING);
//		sbType.append(",");
//		sbType.append(cdmConstantsUtil.TYPE_CATPART);
//		sbType.append(",");
//		sbType.append(cdmConstantsUtil.TYPE_CATDrawing);
//		sbType.append(",");
//		sbType.append(cdmConstantsUtil.TYPE_CDMV4MODEL);
//		sbType.append(",");
//		sbType.append(cdmConstantsUtil.TYPE_CDMNXDRAWING);
//		
//		StringList busSelect = new StringList();
//		busSelect.add("id");
//		busSelect.add("attribute[cdmTDMXID]");
//		String busWhere = "attribute[cdmCheckMigration]=='Y' && format.hasfile=='true'" ;
//		MapList mListCADobj = new MapList();
//		mListCADobj = DomainObject.findObjects(context,
//				sbType.toString(), 
//				"*", 
//				"*",
//				"*",
//				"*",
//				busWhere,
//				true,
//				busSelect );
//		
//		HashMap<String, String> mCadHm = new HashMap<String,String>();
//		for (Iterator iterCad = mListCADobj.iterator(); iterCad.hasNext();) {
//			Map cadMigraionMap = (Map) iterCad.next();
//			String cadTdmxId = (String)cadMigraionMap.get("attribute[cdmTDMXID]");
//			String cadMId = (String)cadMigraionMap.get("id");
//			mCadHm.put(cadTdmxId, cadMId);
//		}
//		
//		
//		initializeM(context, argTemp, 2, logFileName); // context , artTest,
//														// argTest 갯수 체크을위한 수,
//														// 로그 파일명의 default 파일명.
//		writeMessageToConsole("====================================================================================");
//		writeMessageToConsole("CAD DATA MIGRATION " + getTimeStamp() + " \n");
//		writeMessageToConsole("Reading input log file from : " + inputDirectory+cadFileName);
//		writeMessageToConsole("Writing Log files to: " + outputDirectory);
//		writeMessageToConsole("====================================================================================\n");
////		writeSuccessToFile(cdmCommonExcel.getTimeStamp2() +"\t"+ recordRowNum+"\t"+sType+"\t" +sName +"\t"+sbErrorMessage.toString());
//		writeSuccessToFile("CreateTime \t rowNum(#) \t type \t name \t no exist Part name \t no exist Part rev \t Type \t Major Name \t major org && project \t minor org && project \t  ");
//		int lineNumber = 0;
//		StringList sListHeader = new StringList();
//		String recordRowNum = "";
//		try {
//			
//			String sReadData = "";
//			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
//			while ((sReadData = bufferReader.readLine()) != null) {
//				StringList sListReadData = FrameworkUtil.split(sReadData, "\t");
//
//				if (lineNumber == 0) {
//					sListHeader = sListReadData;
//					lineNumber++;
//					continue;
//				}
//				lineNumber++;
//				
//				MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
//				IEFGlobalCache cache = new IEFGlobalCache();
//				MCADGlobalConfigObject globalConfigObject = null;
//				MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
//				
//				int headerSize = sListHeader.size();
//				int readLineSize = sListReadData.size();
//				try {
//					if (headerSize != readLineSize) {
//						String errorMessage = "NOT MATCH" + sListReadData.toString() + " || " + sListHeader.toString();
//						throw new Exception(errorMessage);
//					}
//
//					LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();
//
//					for (int dataCnt = 0; dataCnt < sListReadData.size(); dataCnt++) {
//
//						String stTempCadInfos = (String) sListReadData.get(dataCnt);
//						String stTempCadInfosHeader = (String) sListHeader.get(dataCnt);
//						// 공백제거,null 처리,trim처리
//						stTempCadInfos = isVaildNullData(stTempCadInfos);
//						linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);
//
//					}
//
//					if (lineNumber == 1) {
//						continue;
//					}
//					MqlUtil.mqlCommand(context, "history Off");
//					StringBuffer sbErrorMessage = new StringBuffer(""); 
//					recordRowNum = (String) linkedCadHM.get("#");
//					String sTempType = (String) linkedCadHM.get("CLS_NAME"); // 1,Type
//					String sTdmxId = (String) linkedCadHM.get("TDMX_ID"); // 2 ,attribute[cdmTDMXID]
//					String sRevision = (String) linkedCadHM.get("REVISION"); // 3,Revision
//					String sUsers = (String) linkedCadHM.get("CRT_USERS"); // 4 ,originator,owner
//					String sTdm_Description = (String) linkedCadHM.get("TDM_DESCRIPTION"); // 5
//					String sRelated_PartName = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6
//					// String sTdmx_CAD_Identifier = (String)linkedCadHM.get("TDMX_CAD_IDENTIFIER"); // 7 , 
//					String sTdmx_Detailed_Description = (String) linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); // 8
////					String sTdmx_Comments = (String) linkedCadHM.get("TDMX_COMMENTS"); // 9
//					String sTdmx_3d_Cad_Identifier = (String) linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); // 10,
//					String sTdmx_Title_Type = (String) linkedCadHM.get("TDMX_TITLE_TYPE"); // 11,
//					String sTdmx_Scale = (String) linkedCadHM.get("TDMX_SCALE"); // 12,
//					String sTdmx_Page_Size = (String) linkedCadHM.get("TDMX_PAGE_SIZE"); // 13,
//					String sFile_Type = (String) linkedCadHM.get("FILE_TYPE"); // 14,
//					String sFileName = (String) linkedCadHM.get("FILE_NAME"); // 15, //Real File
//					String sRef_FileName = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); // 16, ORIGINAL FILE
//					// String sVault_Object_Id = (String)linkedCadHM.get("VAULT_OBJECT_ID"); // 17,
//					// String sPhase = (String)linkedCadHM.get("PHASE"); // 18,
//					// String sTdm_Org_User_Id = (String)linkedCadHM.get("TDM_ORG_USER_ID"); // 19,
//					String sTdm_Document_Type = (String) linkedCadHM.get("TDM_DOCUMENT_TYPE"); // 20,
//					// String sTDM_ARCHIVE_TYPE = (String)linkedCadHM.get("TDM_ARCHIVE_TYPE"); // 21,
//					// String sTDM_ARCHIVE_NAME = (String)linkedCadHM.get("TDM_ARCHIVE_NAME"); // 22,
//					// String sPROD_DIV = (String)linkedCadHM.get("PROD_DIV"); // 23,
//					String sCN_Project = (String) linkedCadHM.get("CN_PROJECT"); // 24,
//					// String sCN_PROJECT =(String)linkedCadHM.get("CN_PROJECT"); // 25, 중복 데이타 이므로 무시함
//					String sCN_PROJECT_CUST = (String)linkedCadHM.get("CN_PROJECT_CUST"); // 26,
//					String sMass = (String) linkedCadHM.get("CN_MASS"); // 27,
//					String sSurface_Area = (String) linkedCadHM.get("CN_SURFACE_AREA"); // 28,
//					// String sCN_OEM_PART_NUMBER = (String)linkedCadHM.get("CN_OEM_PART_NUMBER"); // 29,
//					// String sCN_ECO_NUMBER = (String)linkedCadHM.get("CN_ECO_NUMBER"); // 30,
//					// String sCN_MASS_ESTIMATED = (String)linkedCadHM.get("CN_MASS_ESTIMATED"); // 31,
//					// String sCN_PRODUCT_GROUP = (String)linkedCadHM.get("CN_PRODUCT_GROUP"); // 32,
//					// String sCN_CUSTOMER = (String)linkedCadHM.get("CN_CUSTOMER"); // 33,
//					// String sCN_VEHICLE = (String)linkedCadHM.get("CN_VEHICLE"); // 34, 이 데이타는 migration 대상자 아님
//					// String sCN_RELATED_ITEM_NAME = (String)linkedCadHM.get("CN_RELATED_ITEM_NAME"); // 35,
//					String sRelated_PartRev = (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
//					String sProjectId = (String) linkedCadHM.get("CN_PROJECT_ID"); // 37,
//					String sRelated_PG = (String) linkedCadHM.get("PROD_GROUP"); // 38,
//					String sRelated_VehicldeCust = (String) linkedCadHM.get("CN_CUST_VEHICLE"); // 39
//
//					String parentRelName = cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
//					String sType = "";
//					String sPartFindObjId = "";
//					boolean IsExistPerson = false; // Person 정보 확인
//					String sName = "";
//					String sRevisionSeqence = "";
//					String stObjectId = "";
//					String sCAD_Type = "";
//					String strFormat = "";
//					// String strWorkspacePath = "";
//
//					boolean isExistCAD = false;
//					/*
//					 * file type 에 따라 sCAD_Type 명이 다르다.
//					 * 
//					 */
//
//					if ("Assembly".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CATPRODUCT;
//						isExistCAD = true;
//						strFormat = "asm";
//
//						if (!"CATIA Product".equals(sFile_Type)) {
//
//							String errorMessage = "This is not a valid format.";
//							throw new Exception(errorMessage);
//						}
//						sCAD_Type = "assembly";
//					} else if ("AutoCAD".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//					} else if ("Image Drawing".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
//					} else if ("Drawing".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CATDrawing;
//						isExistCAD = true;
//
//						if ("CATIA Part".equals(sFile_Type)) {
//							String errorMessage = "This is not a valid format.(CATIA Part)";
//							throw new Exception(errorMessage);
//						} else if ("CATIA cgm".equals(sFile_Type)) {
//							String errorMessage = "This is not a valid format.(CATIA cgm)";
//							throw new Exception(errorMessage);
//						}else if("STEP".equals(sFile_Type)){
//							String errorMessage = "This is not a valid format.(STEP)";
//							throw new Exception(errorMessage);
//						}else {
//							strFormat = "drw";
//						}
//						sCAD_Type = "drawing";
//
//					} else if ("Part".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CATPART;
//						isExistCAD = true;
//						if("IGES".equals(sFile_Type)){
//							strFormat="IGES";
//							sCAD_Type = "component";
//						}else if("STEP".equals(sFile_Type)){
//							String errorMessage = "This is not a valid format.(STEP)";
//							throw new Exception(errorMessage);
//						}else {
//							strFormat = "prt";
//							sCAD_Type = "component";
//						}
//
//					} else if ("V4 Model".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
//					} else if ("UG NX Drawing".equals(sTempType)) {
//						sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
//					} else {
//
//						/*
//						 * *****************************************************
//						 *  Type 정보가 없다면 에러 처리.
//						 * **************************************************** */
//						continue;
//
//					}
//				
//					if (cdmStringUtil.isNotEmpty(sRef_FileName)) {
//						int intLastExtension = sRef_FileName.lastIndexOf(".");
//						sName = sRef_FileName.substring(0, intLastExtension);
//						sName = sName.trim();
//					} else {
//						String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . ";
//						throw new Exception(sErrorMessage);
//					}
//					
//					boolean bAlreadyExist = false;
//					String cadId = "";
//					String exsitMajorObjId = "";
//					String exsitMinorObjId = "";
//					AttributeList majorlocalAttributeList = new AttributeList();
//					AttributeList minorlocalAttributeList = new AttributeList();
//					Map docAttrMap = new HashMap();
//					ContextUtil.startTransaction(context, true);
//					if (isExistCAD) {
//						
//
//						/*
//						 * *****************************************************
//						 * REVISION 정보가 없다면 에러 처리. REVISION 설정 .
//						 * 
//						 * *****************************************************
//						 */
//						if (cdmStringUtil.isEmpty(sRevision)) {
//							String errorMessage = "NOT EXIST REVISION DATA. ";
//							throw new Exception(errorMessage);
//						}
//						
//						sRevisionSeqence = sRevision;
//						cadId = mCadHm.get(sTdmxId);
//						if(UIUtil.isNotNullAndNotEmpty(cadId)){
////							StringBuffer sbRename = new StringBuffer();
////							sbRename.append("mod bus ");
////							sbRename.append( cadId);
////							sbRename.append("rename format ");
////							sbRename.append(" \"");
////							sbRename.append( strFormat);
////							sbRename.append("\"");
////							sbRename.append("  file \"");
////							sbRename.append(sFileName );
////							sbRename.append("\" \"");
////							sbRename.append( sRef_FileName);
////							sbRename.append("\"");
//							
//							MqlUtil.mqlCommand(context, "mod bus $1  rename format $2 file $3 $4 ",cadId, strFormat,sFileName,sRef_FileName);
////							MqlUtil.mqlCommand(context, sbRename.toString());
//							successInt++;
//						
//						}else{
//							notExist++;
//							writeMessageToLogFile("LineNum(#)" + recordRowNum + " \t" + cdmCommonExcel.getTimeStamp2() +"\t"+ sTdmxId+"\t"+sType+"\t"+sName+"\t"+sRevision+"\t not exist object");
//							throw new Exception("not file exist");
//						}
//					} else {
//
//						strFormat = "generic";
//						
//						cadId = mCadHm.get(sTdmxId);
//						if (UIUtil.isNotNullAndNotEmpty(cadId)) {
//							StringBuffer sbRename = new StringBuffer();
////							sbRename.append("mod bus ");
////							sbRename.append(cadId);
////							sbRename.append(" ");
////							sbRename.append(" rename file");
////							sbRename.append(" \"");
////							sbRename.append(sFileName);
////							sbRename.append("\"");
////							sbRename.append(" ");
////							sbRename.append("\"");
////							sbRename.append(sRef_FileName);
////							sbRename.append("\"");
////							MqlUtil.mqlCommand(context, sbRename.toString());
//							
//							MqlUtil.mqlCommand(context, "mod bus $1  rename format $2 file $3 $4 ",cadId, strFormat,sFileName,sRef_FileName);
//							successInt++;
//						} else {
//							// bAlreadyExist = true;
//							notExist++;
//							// writeErrorToFile("LineNum(#) "+recordRowNum +
//							// "\t"+cdmCommonExcel.getTimeStamp2()+"\t "
//							// +"already exist object");
//							writeMessageToLogFile("LineNum(#)" + recordRowNum + "\t"+ sTdmxId+"\t"+sType+"\t"+sName+"\t"+sRevision+"\t not exist object");
//							throw new Exception("not file exist");
//						}
//					}
//					ContextUtil.commitTransaction(context);
//					writeSuccessToFile("LineNum(#)" + recordRowNum + " \t" + cdmCommonExcel.getTimeStamp2() + "\t" +sType+"\t"+cadId+"\t ");
//					
//				} catch (Exception exception) {
//					ContextUtil.abortTransaction(context);
//					failInt++;
//					writeErrorToFile("LineNum(#)"+recordRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " );
//					exception.printStackTrace(errorStream);
//					writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+sReadData);
////					writeMessageToConsole(" Exception: " + exception.getMessage() + " LINE: " + recordRowNum);
////					writeErrorToFile(recordRowNum+exception.getMessage());
//
//				}finally{
//					MqlUtil.mqlCommand(context, "history on");
//				}
//
//			}
//			writeMessageToConsole("====================================================================================");
//			writeMessageToConsole("        File CAD Migration COMPLETED.                    ");
//			writeMessageToConsole("====================================================================================\n");
//
//		} catch (Exception exception) {
//
//			// writeFailToFile("[${CLASS:cdmCADMigration} : executeCadcMigration]
//			// fail occured. LINE NUMBER: " + recordRowNum);
//			// writeErrorToFile("[${CLASS:cdmCADMigration} : executeCadcMigration]
//			// Exception occured. LINE NUMBER: " + recordRowNum + " " +
//			// exception.getMessage());
//			writeMessageToConsole("LINE NUMBER"+recordRowNum+"| "+exception.getMessage());
//			exception.printStackTrace(errorStream);
//		} finally {
//			writeMessageToConsole("====================================================================================");
//			writeMessageToConsole("LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms        \n");
//			writeMessageToConsole("End Time :("+cdmCommonExcel.getTimeStamp2() +")   Success Count:("+successInt+")   Fail Count: ("+failInt+") not file Count: ("+notExist+")" );
//			writeMessageToConsole("==================================================================================== \n");
//			closeLogStream();
//			System.out.println("[${CLASS:cdmCADMigration} : executeCadcMigration] end .");
//		}
//	
//	
//	}
	
	
	// 
	// /**
	// *
	// * @param context
	// * @param minorRevString
	// * @param b
	// * @param stObjectId
	// * @param stVersionId
	// * @return
	// */
	// @SuppressWarnings("finally")
	// public boolean connectMajorAndMinorObjects(Context context, String
	// minorRevString, boolean parameBoolean, String stObjectId, String
	// stVersionId) {
	//
	// boolean result = false;
	// try {
	// ContextUtil.startTransaction(context, true);
	// String str4 = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_MoveFilesToVersion");
	// String str5 = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_Title");
	// String str6 = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_IsVersionObject");
	// String str7 = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_IEF-FileMessageDigest");
	//
	// StringBuffer localStringBufferVersion = new StringBuffer();
	// localStringBufferVersion.append("connect bus \"");
	// localStringBufferVersion.append(stVersionId);
	// localStringBufferVersion.append("\" relationship \"");
	// localStringBufferVersion.append(cdmConstantsUtil.RELATIONSHIP_VERSION_OF);
	// localStringBufferVersion.append("\" preserve to \"");
	// localStringBufferVersion.append(stObjectId);
	// localStringBufferVersion.append("\" ");
	//
	// MQLCommand localMQLCommand = new MQLCommand();
	// boolean boolBufferVersion = localMQLCommand.executeCommand(context,
	// localStringBufferVersion.toString());
	//
	// StringBuffer localStringBufferActive = new StringBuffer();
	// localStringBufferActive.append("connect bus \"");
	// localStringBufferActive.append(stObjectId);
	// localStringBufferActive.append("\" relationship \"");
	// localStringBufferActive.append(cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION);
	// localStringBufferActive.append("\" preserve to \"");
	// localStringBufferActive.append(stVersionId);
	// localStringBufferActive.append("\" ");
	//
	// MQLCommand activeMQLCommand = new MQLCommand();
	// boolean boolBufferActive = activeMQLCommand.executeCommand(context,
	// localStringBufferActive.toString());
	//
	// StringBuffer localStringBufferLatest = new StringBuffer();
	// localStringBufferLatest.append("connect bus \"");
	// localStringBufferLatest.append(stObjectId);
	// localStringBufferLatest.append("\" relationship \"");
	// localStringBufferLatest.append(cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION);
	// localStringBufferLatest.append("\" preserve to \"");
	// localStringBufferLatest.append(stVersionId);
	// localStringBufferLatest.append("\" ");
	//
	// MQLCommand latestMQLCommand = new MQLCommand();
	// boolean boolBufferLatest = latestMQLCommand.executeCommand(context,
	// localStringBufferLatest.toString());
	//
	// ContextUtil.commitTransaction(context);
	// result = true;
	// } catch (Exception e) {
	// ContextUtil.abortTransaction(context);
	// e.printStackTrace();
	// result = false;
	// }finally{
	// return result;
	//
	// }
	// }

	/**
	 * null 발생시 "" 로 체크
	 * 
	 * @param data
	 * @return
	 */
	public String isVaildNullData(String data) {
		return ((data == null || "null".equals(data)) ? "" : data.trim());
	}

	public boolean isValidData(String data) {
		return ((data == null || "null".equals(data)) ? 0 : data.trim().length()) > 0;
	}

	public void closeLogStream() throws IOException {
		try {
			if (null != logWriter)
				logWriter.close();

			if (null != errorStream)
				errorStream.close();

			if (null != successObjectidWriter)
				successObjectidWriter.close();

			if (null != failedObjectidWriter)
				failedObjectidWriter.close();
			
			if(null != bufferReader)
				bufferReader.close();
		} catch (IOException e) {
			System.out.println("Exception while closing log stream " + e.getMessage());
		}
	}

	public void writeErrorToFile(String message) throws Exception {
		errorStream.write(message.getBytes("UTF-8"));
		errorStream.write("\n".getBytes("UTF-8"));
		
//		errorStream.write(message.getBytes());
//		errorStream.write("\n".getBytes());
	}

	public void writeMessageToConsole(String message) throws Exception {
		writeMessageToLogFile(message);
	}

	public void writeMessageToLogFile(String message) throws Exception {
		logWriter.write(message + "\n");
		logWriter.flush();
	}

	public String getTimeStamp() {
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date) + "T" + new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}

	public void writeFailToFile(String message) throws Exception {
		failedObjectidWriter.write(message + "\n");
		failedObjectidWriter.flush();
	}

	public void writeSuccessToFile(String message) throws Exception {
		successObjectidWriter.write(message + "\n");
		successObjectidWriter.flush();
	}

	/**
	 * 
	 * 
	 * @param context
	 * @param args
	 * @param requestAgsNum
	 * @param logFileName
	 */
	public void initializeM(Context context, String args[], int requestAgsNum, String logFileName) throws Exception {

		if (args.length != requestAgsNum) {
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}

		inputDirectory = args[0];

		// documentDirectory does not ends with "/" add it
		if (inputDirectory != null && !inputDirectory.endsWith(sfileSeparator)) {
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + Output_Directory + sfileSeparator + logFileName + "_" +  sfileSeparator;
		File fileOutputDirectory = new File(outputDirectory);
		if (!fileOutputDirectory.isDirectory()) {
			fileOutputDirectory.mkdirs();
		}
		// input file name
		fileName = args[1];
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
        
		logWriter = new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt", true));
		errorStream = new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile = new File(outputDirectory + logFileName + "_SuccessLog.txt");
		successObjectidWriter = new BufferedWriter(new FileWriter(successLogFile, true));

		failedLogFile = new File(outputDirectory + logFileName + "_FailedLog" + ".txt");
		failedObjectidWriter = new BufferedWriter(new FileWriter(failedLogFile, true));



	}

//	/**
//	 * CATPart ,CATDrawing, CATProduct 데이타 삭제 ( 삭제하게되면 연결되어있는 version object 도
//	 * 같이 삭제된다.
//	 * 
//	 * @param context
//	 * @param majorObjectId
//	 * @throws Exception
//	 */
//	@SuppressWarnings({ "rawtypes", "unchecked" })
//	public void deleteCADDocument(Context context, String majorObjectId) throws Exception {
//
//		DomainObject dObj = DomainObject.newInstance(context);
//		String stObjType = (String) dObj.getInfo(context, cdmConstantsUtil.SELECT_TYPE);
//
//		MCADMxUtil util = null;
//		boolean IsCAD = false;
//		try {
//			if (cdmStringUtil.isNotEmpty(stObjType) && (cdmConstantsUtil.TYPE_CATDrawing.equals(stObjType) || cdmConstantsUtil.TYPE_CATPART.equals(stObjType) || cdmConstantsUtil.TYPE_CATPRODUCT.equals(stObjType))) {
//				String stCAD_DocumentObjectId = majorObjectId;
//
//				util.setRPEVariablesForIEFOperation(context, MCADServerSettings.ISDECDelete);
//				MCADIntegrationSessionData integSessionData = null;
//				IsCAD = true;
//				util.deleteDocument(context, integSessionData, stCAD_DocumentObjectId, false);
//				StringList slDeletedList = new StringList();
//				slDeletedList.addElement(stCAD_DocumentObjectId);
//
//				String recentlyAccessListEncoded = CacheUtil.getCacheString(context, "RECENTLY_ACCESSED_PARTS");
//				if (null != recentlyAccessListEncoded && !"".equals(recentlyAccessListEncoded)) {
//					String recentlyAccessList = MCADUrlUtil.decode(recentlyAccessListEncoded);
//
//					if (null != recentlyAccessList && !"".equals(recentlyAccessList)) {
//
//						MapList mpRecentlyAccessedList = (MapList) MCADUtil.covertToObject(recentlyAccessList, true, true);
//
//						StringList slPositionsToClear = new StringList();
//						for (int p = 0; p < mpRecentlyAccessedList.size(); p++) {
//							Map mpEach = (Map) mpRecentlyAccessedList.get(p);
//							String sId = (String) mpEach.get("id");
//							if (slDeletedList.contains(sId)) {
//								slPositionsToClear.addElement(p);
//							}
//						}
//						MapList mpUpdatedRecentlyAccessList = new MapList();
//						for (int k = 0; k < mpRecentlyAccessedList.size(); k++) {
//							Map mpEach = (Map) mpRecentlyAccessedList.get(k);
//							if (!slPositionsToClear.contains(k)) {
//								mpUpdatedRecentlyAccessList.add(mpEach);
//							}
//						}
//
//						String sUpdatedList = MCADUtil.covertToString(mpUpdatedRecentlyAccessList, true, true);
//
//						sUpdatedList = MCADUrlUtil.encode(sUpdatedList);
//						CacheUtil.setCacheObject(context, "RECENTLY_ACCESSED_PARTS", sUpdatedList);
//					}
//				}
//
//			} else if (cdmConstantsUtil.TYPE_DOCUMENT.equals(stObjType) && cdmStringUtil.isNotEmpty(stObjType)) {
//
//				String stDocumentObjectId = majorObjectId;
//				DomainObject domObj = DomainObject.newInstance(context);
//				StringBuffer sbLockedSelect = new StringBuffer();
//
//				sbLockedSelect.append("relationship[");
//				sbLockedSelect.append(com.matrixone.apps.common.CommonDocument.RELATIONSHIP_ACTIVE_VERSION);
//				sbLockedSelect.append("].to.locked");
//
//				StringList selDocumentList = new StringList();
//				selDocumentList.add(DomainObject.SELECT_TYPE);
//				selDocumentList.add(DomainObject.SELECT_NAME);
//				selDocumentList.add(sbLockedSelect.toString());
//				selDocumentList.add(com.matrixone.apps.common.CommonDocument.SELECT_VCFILE_LOCKED);
//				selDocumentList.add(DomainObject.SELECT_LOCKED);
//				selDocumentList.add(DomainObject.SELECT_CURRENT);
//
//				String objectId = stDocumentObjectId;
//				domObj.setId(objectId);
//				Map resultMap = domObj.getInfo(context, selDocumentList);
//				String docLocked = (String) resultMap.get(sbLockedSelect.toString());
//				String objectLocked = (String) resultMap.get(DomainObject.SELECT_LOCKED);
//				String vcDocLocked = (String) resultMap.get(com.matrixone.apps.common.CommonDocument.SELECT_VCFILE_LOCKED);
//				boolean isLocked = (!UIUtil.isNullOrEmpty(docLocked) && docLocked.indexOf("TRUE") != -1) || (!UIUtil.isNullOrEmpty(vcDocLocked) && (vcDocLocked.equalsIgnoreCase("TRUE"))) || (!UIUtil.isNullOrEmpty(objectLocked) && (objectLocked.equalsIgnoreCase("TRUE")));
//				String sDocumentType = (String) resultMap.get(DomainObject.SELECT_TYPE);
//				String sPart = LibraryCentralConstants.TYPE_PART;
//				String sState = (String) resultMap.get(DomainObject.SELECT_CURRENT);
//				String sActiveState = LibraryCentralConstants.STATE_DOCUMENT_SHEET_ACTIVE;
//
//				try {
//					if (isLocked) {
//						String errorMessage = "FILE IS LOCKED.PLEASE CHECK.";
//						throw new Exception(errorMessage);
//					} else {
//						if (sDocumentType != null && (sDocumentType.equalsIgnoreCase("Generic Document") || sDocumentType.equalsIgnoreCase(cdmConstantsUtil.TYPE_DOCUMENT))) {
//							com.matrixone.apps.common.CommonDocument.deleteDocuments(context, new String[] { objectId });
//						} else if (sDocumentType.equalsIgnoreCase("Document Sheet") && sState.equalsIgnoreCase(sActiveState)) {
//							String errorMessage = "DELETE TYPE HAVE TO DOCUMENT TYPE. PLEASE CHECK.";
//							throw new Exception(errorMessage);
//						} else {
//							BusinessType businessType = new BusinessType(sDocumentType, context.getVault());
//							String strParentType = businessType.getParent(context);
//							String strReturn = null;
//							if (strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_LIBRARIES)) {
//								Libraries LcObj = (Libraries) DomainObject.newInstance(context, objectId, LibraryCentralConstants.LIBRARY);
//								strReturn = LcObj.deleteObjects(context);
//							} else if (strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_CLASSIFICATION)) {
//								Classification LcObj = (Classification) DomainObject.newInstance(context, objectId, LibraryCentralConstants.LIBRARY);
//								strReturn = LcObj.deleteObjects(context);
//							} else if (sDocumentType != null && sDocumentType.equalsIgnoreCase(sPart)) {
//								com.matrixone.apps.library.Part LcObj = (com.matrixone.apps.library.Part) DomainObject.newInstance(context, objectId, LibraryCentralConstants.LIBRARY);
//								strReturn = LcObj.deleteObjects(context);
//								// } else if (sDocumentType != null &&
//								// sDocumentType.equalsIgnoreCase(sFolder)) {
//								// DCWorkspaceVault folderObj =
//								// (DCWorkspaceVault)
//								// DomainObject.newInstance(context, objectId,
//								// LibraryCentralConstants.DOCUMENT);
//								// strReturn = folderObj.deleteObjects(context);
//							} else {
//								domObj.deleteObject(context);
//							}
//							if (strReturn != null && strReturn.equalsIgnoreCase("false")) {
//								String errorMessage = "DELETE ERROR .";
//								throw new Exception(errorMessage);
//							}
//						}
//					}
//				} catch (Exception exp) {
//					exp.printStackTrace();
//				}
//
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		} finally {
//			if (IsCAD) {
//				util.unsetRPEVariablesForIEFOperation(context, MCADServerSettings.ISDECDelete);
//			}
//		}
//	}

	// /**
	// *
	// * @param context
	// * @param sType 생성할 major object_Type
	// * @param sName 생성할 major object_Name
	// * @param sRevisionSeqence 생성할 major object_rev
	// * @param minorRevString 생성할 minor object_Name
	// * @param sPartFindObjId 연결할 Part Id
	// * @param linkedCadHM 속성 데이타 ..etc
	// */
	// @SuppressWarnings("finally")
	// private boolean createCADMaster(Context context, String sType, String
	// sName, String sRevisionSeqence, String minorRevString, String
	// sPartFindObjId, LinkedHashMap<String, Object> linkedCadHM,boolean
	// IsExistPerson ) {
	// boolean result = false;
	// try {
	// // TODO Auto-generated method stub
	// DomainObject busObject = new DomainObject();
	// DomainObject minorBusObject = new DomainObject();
	//
	// String sAttribute_CADType = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_CADType");
	// String sAttribute_MoveFileVersion =
	// MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_MoveFilesToVersion");
	// // original file name 과 데이타가 같다.
	// String sAttribute_Title = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_Title");
	// String sAttribute_IsVersionObj =
	// MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
	// String sAttribute_IEFFileMessage =
	// MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_IEF-FileMessageDigest");
	// String sAttribute_Source = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_Source");
	//
	// ContextUtil.startTransaction(context, true);
	// MqlUtil.mqlCommand(context, "Trigger Off");
	// busObject.createObject(context, sType, sName, sRevisionSeqence,
	// cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION,
	// cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
	//
	// String stObjectId = busObject.getObjectId();
	//
	// /*
	// * *****************************************************************
	// * 파일 체크인 파일명은 sCAD_REF_FILE_NAME 으로 하며 최신 revision 에 연결된 file 을 Design
	// Team
	// * Resource 아직은 주석처리 10.17.2016 확인하고 추후 진행할것
	// * !!!!!!!!!!!!!!!!!!!!!!!!!!!! 파일 체크인 하는 부분은 따로 처리할 예정 10.19.16
	// */
	// /* 속성 입력 start */
	// String sTDMXID = (String)linkedCadHM.get("TDMX_ID"); // 2
	// attribute[cdmTDMXID]
	// String sCRT_USERS = (String)linkedCadHM.get("CRT_USERS"); // 4
	// ,originator, owner
	// String sTDM_DESCRIPTION = (String)linkedCadHM.get("TDM_DESCRIPTION"); //
	// 5 ,
	// String sTDMX_DETAILED_DESCRIPTION =
	// (String)linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); // 8 ,
	// String sTDMX_COMMENTS = (String)linkedCadHM.get("TDMX_COMMENTS"); // 9 ,
	// String sTDMX_3D_CAD_IDENTIFIER =
	// (String)linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); // 10,
	// String sTDMX_SCALE = (String)linkedCadHM.get("TDMX_SCALE"); // 12,
	// String sTDMX_PAGE_SIZE = (String)linkedCadHM.get("TDMX_PAGE_SIZE"); //
	// 13,
	// String sFILE_TYPE = (String)linkedCadHM.get("FILE_TYPE"); // 14,
	// String sCAD_REF_FILE_NAME = (String)linkedCadHM.get("CAD_REF_FILE_NAME");
	// // 16, ORIGINAL FILE
	// String sTDM_DOCUMENT_TYPE = (String)linkedCadHM.get("TDM_DOCUMENT_TYPE");
	// // 20,
	// String sCN_MASS = (String)linkedCadHM.get("CN_MASS"); // 27,
	// String sCN_SURFACE_AREA = (String)linkedCadHM.get("CN_SURFACE_AREA"); //
	// 28,
	//
	// AttributeList localAttributeList = new AttributeList();
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_Title), sCAD_REF_FILE_NAME));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_IEFFileMessage), ""));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_Source), sourceInfo));
	//
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID), sTDMXID));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION),
	// sTDMX_DETAILED_DESCRIPTION));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_COMMENT), sTDMX_COMMENTS));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER),
	// sTDMX_3D_CAD_IDENTIFIER));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE), sFILE_TYPE));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE),
	// sTDM_DOCUMENT_TYPE));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION), "Y"));
	//
	// if ((cdmConstantsUtil.TYPE_CATDrawing).equals(sType)) {
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE),
	// sTDMX_SCALE));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE),
	// sTDMX_PAGE_SIZE));
	// }
	//
	// if ((cdmConstantsUtil.TYPE_CATPART).equals(sType)) {
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS), sCN_MASS));
	// }
	//
	// if ((cdmConstantsUtil.TYPE_CATPART).equals(sType) ||
	// (cdmConstantsUtil.TYPE_CATPRODUCT).equals(sType)) {
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE),
	// sCN_SURFACE_AREA));
	// }
	//
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_MoveFileVersion), "True"));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_IsVersionObj), "False"));
	//
	// /*
	// * MAJOR VERSION OBJECT
	// * ATTRIBUTE[ORIGINATOR],OWNER 정보 추가
	// * PERSON 정보가 존재하지않는다면 제외
	// *
	// */
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_ORIGINATOR), sCRT_USERS));
	// if(IsExistPerson){
	// busObject.setOwner(context, sCRT_USERS);
	// }
	//
	// /* MAJOR VERSION OBJECT ATTRIBUTE, DESCRIPTION 설정 */
	// busObject.setAttributes(context, localAttributeList);
	// busObject.setDescription(context, sTDM_DESCRIPTION);
	//
	// /* minor version */
	// localAttributeList.remove(new Attribute(new
	// AttributeType(sAttribute_MoveFileVersion), "True"));
	// localAttributeList.remove(new Attribute(new
	// AttributeType(sAttribute_IsVersionObj), "False"));
	//
	// minorBusObject.createObject(context, sType, sName, minorRevString,
	// cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY,
	// cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
	// String stVersionId = minorBusObject.getObjectId();
	//
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_MoveFileVersion), "False"));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_IsVersionObj), "True"));
	//
	// minorBusObject.setAttributes(context, localAttributeList);
	//
	// if (cdmStringUtil.isNotEmpty(sTDM_DESCRIPTION)) {
	// minorBusObject.setDescription(context, sTDM_DESCRIPTION);
	// }
	//
	// /*
	// * MINOR VERSION OBJECT
	// * OWNER 정보 추가
	// * PERSON 정보가 존재하지않는다면 제외
	// */
	// if (IsExistPerson) {
	// minorBusObject.setOwner(context, sCRT_USERS);
	// }
	//
	// StringBuffer localStringBufferVersion = new StringBuffer();
	// localStringBufferVersion.append("connect bus \"");
	// localStringBufferVersion.append(stVersionId);
	// localStringBufferVersion.append("\" relationship \"");
	// localStringBufferVersion.append(cdmConstantsUtil.RELATIONSHIP_VERSION_OF);
	// localStringBufferVersion.append("\" preserve to \"");
	// localStringBufferVersion.append(stObjectId);
	// localStringBufferVersion.append("\" ");
	//
	// MQLCommand localMQLCommand = new MQLCommand();
	// localMQLCommand.open(context);
	// boolean boolBufferVersion = localMQLCommand.executeCommand(context,
	// localStringBufferVersion.toString());
	// if(!boolBufferVersion){
	// String errorMessage = " NOT RELATIONSHIP[VersionOf] CONNECT MAJOR OBJECT,
	// MINOR OBJECT ";
	// throw new Exception(errorMessage);
	// }
	// localMQLCommand.close(context);
	//
	//
	// StringBuffer localStringBufferActive = new StringBuffer();
	// localStringBufferActive.append("connect bus \"");
	// localStringBufferActive.append(stObjectId);
	// localStringBufferActive.append("\" relationship \"");
	// localStringBufferActive.append(cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION);
	// localStringBufferActive.append("\" preserve to \"");
	// localStringBufferActive.append(stVersionId);
	// localStringBufferActive.append("\" ");
	//
	// MQLCommand activeMQLCommand = new MQLCommand();
	// activeMQLCommand.open(context);
	// boolean boolBufferActive = activeMQLCommand.executeCommand(context,
	// localStringBufferActive.toString());
	// if(!boolBufferActive){
	// String errorMessage = " NOT RELATIONSHIP[Active Version] CONNECT MAJOR
	// OBJECT, MINOR OBJECT ";
	// throw new Exception(errorMessage);
	// }
	// activeMQLCommand.close(context);
	//
	// StringBuffer localStringBufferLatest = new StringBuffer();
	// localStringBufferLatest.append("connect bus \"");
	// localStringBufferLatest.append(stObjectId);
	// localStringBufferLatest.append("\" relationship \"");
	// localStringBufferLatest.append(cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION);
	// localStringBufferLatest.append("\" preserve to \"");
	// localStringBufferLatest.append(stVersionId);
	// localStringBufferLatest.append("\" ");
	//
	// MQLCommand latestMQLCommand = new MQLCommand();
	// latestMQLCommand.open(context);
	// boolean boolBufferLatest = latestMQLCommand.executeCommand(context,
	// localStringBufferLatest.toString());
	//
	// if(!boolBufferLatest){
	// String errorMessage = " NOT RELATIONSHIP[Latest Version] CONNECT MAJOR
	// OBJECT, MINOR OBJECT ";
	// throw new Exception(errorMessage);
	// }
	// latestMQLCommand.close(context);
	// /* 속성 입력 end */
	//
	// ContextUtil.commitTransaction(context);
	// }catch(Exception e){
	// result = false;
	// ContextUtil.abortTransaction(context);
	//// e.printStackTrace();
	// }finally{
	// return result;
	// }
	// }

	// /**
	// *참조 문서 cdmDocumentsCheckinProcess.jsp
	// * revision 정보는 아직 확인해야할 사항 읽을 revision정보로 진행
	// * Auto CAD 의 경우 rel 정보 parentRelName
	// * @param context
	// * @param sType
	// * @param sName
	// * @param linkedCadHM
	// * @return
	// */
	// @SuppressWarnings({ "unchecked", "rawtypes" })
	// public boolean createDocumentMaster(Context context, String sType, String
	// sName, String sPartFindObjId,LinkedHashMap<String, Object> linkedCadHM) {
	// // TODO Auto-generated method stub
	// boolean result = false;
	// try {
	// ContextUtil.startTransaction(context, true);
	//
	// String type = sType;
	// String name = sName;
	// String policy = "Document Release";
	// String title = sName;
	// String language = null;
	// String parentRelName = cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
	// String isFrom = "false";
	// String objectGeneratorRevision = "";
	// String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
	//// String objectGeneratorRevision = (String)
	// linkedCadHM.get("objectGeneratorRevision");
	//
	// String sTempType = (String)linkedCadHM.get("CLS_NAME"); // 1 Type
	// String sTDMXID = (String)linkedCadHM.get("TDMX_ID"); // 2
	// attribute[cdmTDMXID]
	// String sRevision = (String)linkedCadHM.get("REVISION"); // 3 Revision
	// String sCRT_USERS = (String)linkedCadHM.get("CRT_USERS"); // 4
	// ,originator, owner
	// String sTDM_DESCRIPTION = (String)linkedCadHM.get("TDM_DESCRIPTION"); //
	// 5 ,
	// String sTDMX_DETAILED_DESCRIPTION =
	// (String)linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); // 8 ,
	// String sTDMX_COMMENTS = (String)linkedCadHM.get("TDMX_COMMENTS"); // 9 ,
	// String sTDMX_3D_CAD_IDENTIFIER =
	// (String)linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); // 10,
	// String sTDMX_TITLE_TYPE = (String)linkedCadHM.get("TDMX_TITLE_TYPE"); //
	// 11,
	// String sTDMX_SCALE = (String)linkedCadHM.get("TDMX_SCALE"); // 12,
	// String sTDMX_PAGE_SIZE = (String)linkedCadHM.get("TDMX_PAGE_SIZE"); //
	// 13,
	// String sFILE_TYPE = (String)linkedCadHM.get("FILE_TYPE"); // 14,
	// String sCAD_REF_FILE_NAME = (String)linkedCadHM.get("CAD_REF_FILE_NAME");
	// // 16, ORIGINAL FILE
	// String sVAULT_OBJECT_ID = (String)linkedCadHM.get("VAULT_OBJECT_ID"); //
	// 17,
	// String sPHASE = (String)linkedCadHM.get("PHASE"); // 18,
	// String sTDM_ORG_USER_ID = (String)linkedCadHM.get("TDM_ORG_USER_ID"); //
	// 19,
	// String sTDM_DOCUMENT_TYPE = (String)linkedCadHM.get("TDM_DOCUMENT_TYPE");
	// // 20,
	// String sTDM_ARCHIVE_TYPE = (String)linkedCadHM.get("TDM_ARCHIVE_TYPE");
	// // 21,
	// String sTDM_ARCHIVE_NAME = (String)linkedCadHM.get("TDM_ARCHIVE_NAME");
	// // 22,
	// String sPROD_DIV = (String)linkedCadHM.get("PROD_DIV"); // 23,
	// String sCN_PROJECT = (String)linkedCadHM.get("CN_PROJECT"); // 24,
	// String sCN_PROJECT_CUST = (String)linkedCadHM.get("CN_PROJECT_CUST"); //
	// 26,
	// String sCN_MASS = (String)linkedCadHM.get("CN_MASS"); // 27,
	// String sCN_SURFACE_AREA = (String)linkedCadHM.get("CN_SURFACE_AREA"); //
	// 28,
	// String sCN_OEM_PART_NUMBER =
	// (String)linkedCadHM.get("CN_OEM_PART_NUMBER"); // 29,
	// String sCN_ECO_NUMBER = (String)linkedCadHM.get("CN_ECO_NUMBER"); // 30,
	// String sCN_MASS_ESTIMATED = (String)linkedCadHM.get("CN_MASS_ESTIMATED");
	// // 31,
	// String sCN_PRODUCT_GROUP = (String)linkedCadHM.get("CN_PRODUCT_GROUP");
	// // 32,
	// String sCN_CUSTOMER = (String)linkedCadHM.get("CN_CUSTOMER"); // 33,
	// String sCN_RELATED_ITEM_NAME =
	// (String)linkedCadHM.get("CN_RELATED_ITEM_NAME"); // 35,
	// String sCN_RELATED_ITEM_REV =
	// (String)linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
	//
	// if (sTDM_DESCRIPTION == null || "".equals(sTDM_DESCRIPTION) ||
	// "null".equals(sTDM_DESCRIPTION)) {
	// sTDM_DESCRIPTION = (String) linkedCadHM.get("sTDM_DESCRIPTION");
	// }
	//
	// if (title == null || "".equals(title) || "null".equals(title)) {
	// title = null;
	// }
	//
	// CommonDocument object = (CommonDocument)
	// DomainObject.newInstance(context, CommonDocument.TYPE_DOCUMENTS);
	// DomainObject parentObject = null;
	// if (sPartFindObjId != null && !"".equals(sPartFindObjId) &&
	// !"null".equals(sPartFindObjId)) {
	// parentObject = DomainObject.newInstance(context, sPartFindObjId);
	// }
	//
	// HashMap mAttrMap = new HashMap(); //데이타 입력해야함 10.18.16 속성정보 지정할것
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE,
	// sTDMX_PAGE_SIZE);
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE,
	// sTDMX_SCALE);
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_TITLE_TYPE,
	// sTDMX_TITLE_TYPE );
	//
	// //MIGRATION DATA을 위해 속성 추가 AUTOCAD, ..
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID, sTDMXID );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION,
	// sTDMX_DETAILED_DESCRIPTION );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_COMMENT, sTDMX_COMMENTS );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER,
	// sTDMX_3D_CAD_IDENTIFIER );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE, sFILE_TYPE );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE,
	// sTDM_DOCUMENT_TYPE );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, "Y" );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS, sCN_MASS );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE,
	// sCN_SURFACE_AREA );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sCRT_USERS );
	//
	//
	// MqlUtil.mqlCommand(context, "Trigger Off");
	// object = object.createAndConnect(context, type, name, sRevision, policy, sTDM_DESCRIPTION, vault, title, language, parentObject, parentRelName, isFrom, mAttrMap, objectGeneratorRevision);
	// MqlUtil.mqlCommand(context, "Trigger On");
	//
	// StringList selects = new StringList(2);
	// selects.add(DomainConstants.SELECT_ID);
	// selects.add(CommonDocument.SELECT_MOVE_FILES_TO_VERSION);
	//
	//// Map objectSelectMap = object.getInfo(context, selects);
	//// String objectId = "";
	//// objectId = (String) objectSelectMap.get(DomainConstants.SELECT_ID);
	//
	// boolean isFilePresent = true;
	// String sVersionDescription = null;
	// Map attrMapOfVersion = new HashMap();
	//
	// boolean createVersion = true;
	//
	// if (createVersion) {
	// MqlUtil.mqlCommand(context, "Trigger Off");
	// object.createVersion(context, sVersionDescription, sCAD_REF_FILE_NAME,
	// attrMapOfVersion);
	// MqlUtil.mqlCommand(context, "Trigger On");
	// }
	//
	// String sIsPersonMql = MqlUtil.mqlCommand(context, "temp query bus Person
	// '"+sCRT_USERS+"' * select name dump |");
	// StringList sListIsPersonMqlResult = FrameworkUtil.split(sIsPersonMql,
	// "|");
	//
	// if (sListIsPersonMqlResult.size()>2) {
	// object.setOwner(context, (String)sListIsPersonMqlResult.get(3));
	// }
	// //modify by 10.18.16 end
	//
	// result = true;
	// ContextUtil.commitTransaction(context);
	// } catch (Exception e) {
	// ContextUtil.abortTransaction(context);
	// e.printStackTrace();
	// result = false;
	// }finally{
	// return result;
	// }
	//
	// }

	// test start
	// /**
	// * ThumbnailViewable,CgrViewable object 생성후
	// * @param context
	// * @param args
	// * @throws Exception
	// */
	// public void testCheckin(Context context ,String args[])throws Exception{
	// try{
	// long startTime = System.currentTimeMillis();
	// System.out.println("[${CLASS:cdmCADMigration} : executeCadcMigration] start
	// ."+startTime +"ms");
	//
	//
	// String logFileName = "TEST_CAD_CHECKIN_FILE_MIGRATION";
	//
	// String[] argTest =
	// {"C:\\temp\\Import_File\\CAD","CAD_Items_FULL_02.txt"}; //읽을 파일경로 ,읽을 파일명
	// initializeM(context,argTest,2,logFileName); //context , artTest, argTest
	// 갯수 체크을위한 수, 로그 파일명의 default 파일명.
	//
	// writeMessageToConsole("====================================================================================");
	// writeMessageToConsole(" CAD DATA MIGRATION "+ getTimeStamp()+" \n");
	// writeMessageToConsole(" Reading input log file from : "+inputDirectory);
	// writeMessageToConsole(" Writing Log files to: " + outputDirectory );
	// writeMessageToConsole("====================================================================================\n");
	// int lineNumber = 0;
	// StringList stListHeader = new StringList();
	// String recordRowNum = "";
	//
	// try {
	//
	// String stReadData = "";
	//
	// LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String,
	// Object>();
	// linkedCadHM.put("id_0", "8820.41398.25960.9668");
	// for (int stListNum = 0; stListNum < linkedCadHM.size(); stListNum++) {
	// ContextUtil.startTransaction(context, true);
	//
	// String id = (String)linkedCadHM.get("id_"+stListNum);
	// DomainObject dObj = new DomainObject(id);
	// StringList stList = new StringList();
	//
	// stList.add("type");
	// stList.add("name");
	// stList.add("revision");
	// stList.add("description");
	// stList.add("attribute[Title]");
	// stList.add("attribute[cdmTDMXID]");
	// stList.add("attribute[cdmDetailDescription]");
	// stList.add("attribute[cdmComment]");
	// stList.add("attribute[cdm3DCadIdentifier]");
	// stList.add("attribute[cdmFileType]");
	// stList.add("attribute[cdmDocumentsTitleType]");
	// stList.add("attribute[cdmDocumentsMass]");
	// stList.add("attribute[cdmDocumentsPageSize]");
	// stList.add("attribute[cdmDocumentsSurface]");
	//
	//
	// Map dObjInfoMap = dObj.getInfo(context, stList);
	// String sType = (String)dObjInfoMap.get("type");
	// String sName = (String)dObjInfoMap.get("name");
	// String sRevisionSeqence = (String)dObjInfoMap.get("revision");
	// String sDescription = (String)dObjInfoMap.get("description");
	// String sAttrTitle = (String)dObjInfoMap.get("attribute[Title]");
	//
	// String sAttrTDMXID = (String)dObjInfoMap.get("attribute[cdmTDMXID]");
	// String sAttrDetailDescription =
	// (String)dObjInfoMap.get("attribute[cdmDetailDescription]");
	// String sAttrComment = (String)dObjInfoMap.get("attribute[cdmComment]");
	// String sAttr3DCadIdentifier =
	// (String)dObjInfoMap.get("attribute[cdm3DCadIdentifier]");
	// String sAttrFileType = (String)dObjInfoMap.get("attribute[cdmFileType]");
	// String sAttrDocumentsTitleType =
	// (String)dObjInfoMap.get("attribute[cdmDocumentsTitleType]");
	// String sAttrDocumentsMass =
	// (String)dObjInfoMap.get("attribute[cdmDocumentsMass]");
	// String sAttrDocumentsPageSize =
	// (String)dObjInfoMap.get("attribute[cdmDocumentsPageSize]");
	// String sAttrDocumentsSurface =
	// (String)dObjInfoMap.get("attribute[cdmDocumentsSurface]");
	//
	// String strWorkspacePath = "C:\\Users\\mj\\Documents\\20161028";
	// BusinessObject existBusinessObj = new BusinessObject(sType, sName,
	// sRevisionSeqence, "");
	// boolean isMajorExist = existBusinessObj.exists(context);
	//
	//
	//
	//
	// if (isMajorExist) {
	// String user1 = "admin_platform";
	// String sAttribute_Originator =
	// MCADMxUtil.getActualNameForAEFData(context, "attribute_originator");
	// MapList testMapList = new MapList();
	// Map<String, Object> requestMap = new HashMap();
	//
	// StringList sListOrg = (StringList)JPO.invoke(context,
	// "emxENCFullSearchBase", null , "getDefaultOrg",
	// JPO.packArgs(requestMap),StringList.class);
	//
	//// requestMap.put("DesignResponsibilityOID",(String)sListOrg.get(0) );
	//// requestMap.put("DesignResponsibility", sListOrg);
	//// requestMap.put("objectId", id);
	//// testMapList.add(requestMap) ;
	//// String sOrg = (String)JPO.invoke(context, "emxENCFullSearchBase", null
	// , "performPostProcessConnect", JPO.packArgs(requestMap),String.class);
	//
	// String rdoId = (String)sListOrg.get(0) ;
	// String rdoName = "";
	// String CURRENT_FROM_CONNECT_ACCESS = "current.access[fromconnect]";
	// boolean hasFromConnectAccess = ((new
	// DomainObject(rdoId)).getInfo(context,
	// CURRENT_FROM_CONNECT_ACCESS)).equalsIgnoreCase("true") ? true : false;
	// if (hasFromConnectAccess) {
	// DomainRelationship.connect(context,
	// new DomainObject(rdoId), // from side object Design Responsibilty
	// DomainConstants.RELATIONSHIP_DESIGN_RESPONSIBILITY, // Relationship
	// dObj);// toSide object Document
	//
	// //Added for IR-216979 start
	// if(UIUtil.isNotNullAndNotEmpty(rdoName)) {
	// dObj.setPrimaryOwnership(context,
	// EngineeringUtil.getDefaultProject(context), rdoName);
	// } else {
	// dObj.setPrimaryOwnership(context,
	// EngineeringUtil.getDefaultProject(context),
	// EngineeringUtil.getDefaultOrganization(context));
	// }
	// //Added for IR-216969 End
	//
	// } else {
	// PartDefinition partDefinition = new PartDefinition();
	// partDefinition.setRDO(context, rdoId, true);
	// }
	//
	//
	//
	////
	//// StringBuffer localStringBuffer = new StringBuffer(sRevisionSeqence);
	//// localStringBuffer.append(".0");
	//// String minorRevString = localStringBuffer.toString();
	////
	//// //
	//// String sAttribute_MoveFileVersion =
	// MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_MoveFilesToVersion");
	////
	//// String sAttribute_Title = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_Title");
	//// String sAttribute_IsVersionObj =
	// MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
	//// String sAttribute_IEFFileMessage =
	// MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_IEF-FileMessageDigest");
	//// String sAttribute_Source = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_Source");
	////
	//// DomainObject minorBusObject = new DomainObject();
	//// String stVersionId = "";
	//// MqlUtil.mqlCommand(context, "Trigger Off");
	//// minorBusObject.createObject(context, sType, sName, minorRevString,
	// cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY,
	// cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
	//// MqlUtil.mqlCommand(context, "Trigger On");
	//// stVersionId = minorBusObject.getObjectId();
	////
	//// AttributeList localAttributeList = new AttributeList();
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_Title), sAttrTitle));
	////// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_IEFFileMessage), ""));
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_Source), sourceInfo));
	////
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID), sAttrTDMXID));
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION),
	// sAttrDetailDescription));
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_COMMENT), sAttrComment));
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER),
	// sAttr3DCadIdentifier));
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE), sAttrFileType));
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE),
	// sAttrDocumentsTitleType));
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION), "Y"));
	////
	//// if ((cdmConstantsUtil.TYPE_CATDrawing).equals(sType)) {
	////// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE),
	// sTDMX_SCALE));
	////// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE),
	// sTDMX_PAGE_SIZE));
	//// }
	////
	//// if ((cdmConstantsUtil.TYPE_CATPART).equals(sType)) {
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS),
	// sAttrDocumentsMass));
	//// }
	////
	//// if ((cdmConstantsUtil.TYPE_CATPART).equals(sType) ||
	// (cdmConstantsUtil.TYPE_CATPRODUCT).equals(sType)) {
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE),
	// sAttrDocumentsSurface));
	//// }
	////
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_MoveFileVersion), "False"));
	//// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_IsVersionObj), "True"));
	////
	//// minorBusObject.setAttributes(context, localAttributeList);
	////
	//// if (cdmStringUtil.isNotEmpty(sDescription)) {
	//// minorBusObject.setDescription(context, sDescription);
	//// }
	////
	////// if (IsExistPerson) {
	////// minorBusObject.setOwner(context, sCRT_USERS);
	////// }
	////
	//// StringBuffer localStringBufferVersion = new StringBuffer();
	//// localStringBufferVersion.append("connect bus \"");
	//// localStringBufferVersion.append(stVersionId);
	//// localStringBufferVersion.append("\" relationship \"");
	//// localStringBufferVersion.append(cdmConstantsUtil.RELATIONSHIP_VERSION_OF);
	//// localStringBufferVersion.append("\" preserve to \"");
	//// localStringBufferVersion.append(id);
	//// localStringBufferVersion.append("\" ");
	////
	//// MQLCommand localMQLCommand = new MQLCommand();
	//// localMQLCommand.open(context);
	//// boolean boolBufferVersion = localMQLCommand.executeCommand(context,
	// localStringBufferVersion.toString());
	//// if(!boolBufferVersion){
	//// String errorMessage = " NOT RELATIONSHIP[VersionOf] CONNECT MAJOR
	// OBJECT, MINOR OBJECT ";
	//// throw new Exception(errorMessage);
	//// }
	//// localMQLCommand.close(context);
	////
	////
	//// StringBuffer localStringBufferActive = new StringBuffer();
	//// localStringBufferActive.append("connect bus \"");
	//// localStringBufferActive.append(id);
	//// localStringBufferActive.append("\" relationship \"");
	//// localStringBufferActive.append(cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION);
	//// localStringBufferActive.append("\" preserve to \"");
	//// localStringBufferActive.append(stVersionId);
	//// localStringBufferActive.append("\" ");
	////
	//// MQLCommand activeMQLCommand = new MQLCommand();
	//// activeMQLCommand.open(context);
	//// boolean boolBufferActive = activeMQLCommand.executeCommand(context,
	// localStringBufferActive.toString());
	//// if(!boolBufferActive){
	//// String errorMessage = " NOT RELATIONSHIP[Active Version] CONNECT MAJOR
	// OBJECT, MINOR OBJECT ";
	//// throw new Exception(errorMessage);
	//// }
	//// activeMQLCommand.close(context);
	////
	////
	//// StringBuffer localStringBufferLatest = new StringBuffer();
	//// localStringBufferLatest.append("connect bus \"");
	//// localStringBufferLatest.append(id);
	//// localStringBufferLatest.append("\" relationship \"");
	//// localStringBufferLatest.append(cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION);
	//// localStringBufferLatest.append("\" preserve to \"");
	//// localStringBufferLatest.append(stVersionId);
	//// localStringBufferLatest.append("\" ");
	////
	//// MQLCommand latestMQLCommand = new MQLCommand();
	//// latestMQLCommand.open(context);
	//// boolean boolBufferLatest = latestMQLCommand.executeCommand(context,
	// localStringBufferLatest.toString());
	//// if(!boolBufferLatest){
	//// String errorMessage = " NOT RELATIONSHIP[Latest Version] CONNECT MAJOR
	// OBJECT, MINOR OBJECT ";
	//// throw new Exception(errorMessage);
	//// }
	//// latestMQLCommand.close(context);
	//// String strFormat = "prt";
	//// String strFileCheckinName = "K801692_SYMBOLE_071212.CATPart";
	//// dObj.checkinFile(context, false, false, null, strFormat, "STORE",
	// strFileCheckinName,strWorkspacePath);
	//// //
	////
	////// DomainObject viewableDObj = new DomainObject();
	////// DomainObject cgrViewableDObj = new DomainObject();
	////// MCADMxUtil mxUtil = null;
	////// String thumbnailViewableFileName = sAttrTitle;
	////// String cgrViewableBusinessObjFileName = sAttrTitle;
	////
	////// StringBuffer localStringBuffer = new StringBuffer(sRevisionSeqence);
	////// localStringBuffer.append(".0");
	////// String minorRevString = localStringBuffer.toString();
	////
	////// viewableDObj.createObject(context, "ThumbnailViewable",
	// thumbnailViewableFileName , minorRevString, "Viewable TEAM Policy",
	// cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
	////// dObj.connectTo(context, "Viewable", viewableDObj );
	//////
	////// String strFileCheckinName= sName+".cgr";
	////// String strFormat = "CGR";
	////// viewableDObj.checkinFile(context,false, false, null, strFormat,
	// "STORE", strFileCheckinName,strWorkspacePath);
	//////
	////// cgrViewableDObj.createObject(context, "CgrViewable",
	// cgrViewableBusinessObjFileName , minorRevString, "Viewable TEAM Policy",
	// cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
	////// dObj.connectTo(context, "Viewable", cgrViewableDObj );
	//////
	////// strFormat = "PNG";
	////// strFileCheckinName= sName+".png";
	////// cgrViewableDObj.checkinFile(context, false, false, null, strFormat,
	// "STORE", strFileCheckinName,strWorkspacePath);
	//////
	////// strFormat = "THUMBNAIL";
	////// strFileCheckinName= sName+".jpg";
	////// cgrViewableDObj.checkinFile(context, false, false, null, strFormat,
	// "STORE", strFileCheckinName,strWorkspacePath);
	// }
	//
	// ContextUtil.commitTransaction(context);
	// }
	// writeSuccessToFile("SUCESS!! LINE NUMBER: " + recordRowNum);
	// writeMessageToConsole("SUCESS!! LINE NUMBER: " + recordRowNum);
	// } catch (Exception exception) {
	// ContextUtil.abortTransaction(context);
	//
	// writeMessageToConsole(" Exception occured : " + exception.getMessage() +
	// " LINE NUMBER: " + recordRowNum);
	// writeErrorToFile("[${CLASS:cdmCADMigration} : executeCadcMigration]
	// Exception occured : " + exception.getMessage() + " LINE NUMBER: " +
	// recordRowNum);
	// exception.printStackTrace(errorStream);
	//
	// writeFailToFile("[${CLASS:cdmCADMigration} : executeCadcMigration] fail
	// occured. LINE NUMBER: " + recordRowNum);
	// }
	//
	// }catch(Exception e){
	//
	// }
	// }
	// test end

	// /**
	// * 2016.10.28
	// * 테스트 K801692_SYMBOLE_071212 생성
	// *
	// * 파일 업로드는 이루어지지않음
	// * 파일의 저장위치는 CATPart , CATProduct, CATDrawing 의 major object 는 minor
	// object의 데이타 중 latest revision의 파일 정보를 가진다.
	// * latest revision object 의 파일정보는 major object에만 존재하며
	// * revise 될때 파일정보는 이동하여 minor object 의 파일 관리 object 에 저장된다.
	// * 파라미터 데이타를 사용하지않고
	// * argTest 이라는 string[] 에 직접 입력하여 initializeM 호출
	// *
	// * args[0] :inputDirectory 파일 경로 정보 (파일명 포함되지않음)
	// * args[1] : file name
	// * @param context
	// * @param args
	// * @throws Exception
	// */
	//
	// public void executeCadcMigration(Context context, String args[])throws
	// Exception{
	// long startTime = System.currentTimeMillis();
	// System.out.println("[${CLASS:cdmCADMigration} : executeCadcMigration] start
	// ."+startTime +"ms");
	//
	//
	// String logFileName = "CadMigration";
	//
	// String[] argTest =
	// {"C:\\temp\\Import_File\\CAD","CAD_Items_FULL_02.txt"}; //읽을 파일경로 ,읽을 파일명
	// initializeM(context,argTest,2,logFileName); //context , artTest, argTest
	// 갯수 체크을위한 수, 로그 파일명의 default 파일명.
	//
	// writeMessageToConsole("====================================================================================");
	// writeMessageToConsole(" CAD DATA MIGRATION "+ getTimeStamp()+" \n");
	// writeMessageToConsole(" Reading input log file from : "+inputDirectory);
	// writeMessageToConsole(" Writing Log files to: " + outputDirectory );
	// writeMessageToConsole("====================================================================================\n");
	// int lineNumber = 0;
	// StringList stListHeader = new StringList();
	// String recordRowNum = "";
	//
	// try{
	//
	// String stReadData = "";
	// bufferReader = new BufferedReader(new InputStreamReader(new
	// FileInputStream(inputDirectory+fileName),"euc-kr"));
	// while ((stReadData = bufferReader.readLine()) != null){
	// StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
	//
	// if(lineNumber == 0){
	// stListHeader = stListReadData ;
	//
	// lineNumber++;
	// continue;
	// }
	// LinkedHashMap<String, Object> linkedCadHM = new
	// LinkedHashMap<String,Object>();
	//
	// for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {
	//
	// String stTempCadInfos = ((String) stListReadData.get(stListNum)).trim();
	// String stTempCadInfosHeader = ((String)
	// stListHeader.get(stListNum)).trim();
	// stTempCadInfos = isVaildNullData(stTempCadInfos);
	// linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);
	//
	// }
	// lineNumber++;
	// //TEST start
	// if(lineNumber <1184){
	// continue;
	// }
	// if(lineNumber >1184){
	// break;
	// }
	// //TEST end
	// if(lineNumber == 1){
	// continue;
	// }
	// try {
	// recordRowNum = (String)linkedCadHM.get("#");
	// String sTempType = (String)linkedCadHM.get("CLS_NAME"); // 1 , Type
	// String sTDMXID = (String)linkedCadHM.get("TDMX_ID"); // 2 ,
	// attribute[cdmTDMXID]
	// String sRevision = (String)linkedCadHM.get("REVISION"); // 3 , Revision
	// String sCRT_USERS = (String)linkedCadHM.get("CRT_USERS"); // 4 ,
	// originator, owner
	// String sTDM_DESCRIPTION = (String)linkedCadHM.get("TDM_DESCRIPTION"); //
	// 5 ,
	// String sTDMX_RELATED_ITEM_ID =
	// (String)linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6 ,
	//// String sTDMX_CAD_IDENTIFIER =
	// (String)linkedCadHM.get("TDMX_CAD_IDENTIFIER"); // 7 ,
	// String sTDMX_DETAILED_DESCRIPTION =
	// (String)linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); // 8 ,
	// String sTDMX_COMMENTS = (String)linkedCadHM.get("TDMX_COMMENTS"); // 9 ,
	// String sTDMX_3D_CAD_IDENTIFIER =
	// (String)linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); // 10,
	// String sTDMX_TITLE_TYPE = (String)linkedCadHM.get("TDMX_TITLE_TYPE"); //
	// 11,
	// String sTDMX_SCALE = (String)linkedCadHM.get("TDMX_SCALE"); // 12,
	// String sTDMX_PAGE_SIZE = (String)linkedCadHM.get("TDMX_PAGE_SIZE"); //
	// 13,
	// String sFILE_TYPE = (String)linkedCadHM.get("FILE_TYPE"); // 14,
	//// String sFILE_NAME = (String)linkedCadHM.get("FILE_NAME"); // 15,
	// String sCAD_REF_FILE_NAME = (String)linkedCadHM.get("CAD_REF_FILE_NAME");
	// // 16, ORIGINAL FILE
	// String sVAULT_OBJECT_ID = (String)linkedCadHM.get("VAULT_OBJECT_ID"); //
	// 17,
	// String sPHASE = (String)linkedCadHM.get("PHASE"); // 18,
	// String sTDM_ORG_USER_ID = (String)linkedCadHM.get("TDM_ORG_USER_ID"); //
	// 19,
	// String sTDM_DOCUMENT_TYPE = (String)linkedCadHM.get("TDM_DOCUMENT_TYPE");
	// // 20,
	// String sTDM_ARCHIVE_TYPE = (String)linkedCadHM.get("TDM_ARCHIVE_TYPE");
	// // 21,
	// String sTDM_ARCHIVE_NAME = (String)linkedCadHM.get("TDM_ARCHIVE_NAME");
	// // 22,
	// String sPROD_DIV = (String)linkedCadHM.get("PROD_DIV"); // 23,
	// String sCN_PROJECT = (String)linkedCadHM.get("CN_PROJECT"); // 24,
	//// String sCN_PROJECT = (String)linkedCadHM.get("CN_PROJECT"); // 25, 중복
	// 데이타 이므로 무시함
	// String sCN_PROJECT_CUST = (String)linkedCadHM.get("CN_PROJECT_CUST"); //
	// 26,
	// String sCN_MASS = (String)linkedCadHM.get("CN_MASS"); // 27,
	// String sCN_SURFACE_AREA = (String)linkedCadHM.get("CN_SURFACE_AREA"); //
	// 28,
	// String sCN_OEM_PART_NUMBER =
	// (String)linkedCadHM.get("CN_OEM_PART_NUMBER"); // 29,
	// String sCN_ECO_NUMBER = (String)linkedCadHM.get("CN_ECO_NUMBER"); // 30,
	// String sCN_MASS_ESTIMATED = (String)linkedCadHM.get("CN_MASS_ESTIMATED");
	// // 31,
	// String sCN_PRODUCT_GROUP = (String)linkedCadHM.get("CN_PRODUCT_GROUP");
	// // 32,
	// String sCN_CUSTOMER = (String)linkedCadHM.get("CN_CUSTOMER"); // 33,
	//// String sCN_VEHICLE = (String)linkedCadHM.get("CN_VEHICLE"); // 34, 이
	// 데이타는 migration 대상자 아님
	// String sCN_RELATED_ITEM_NAME =
	// (String)linkedCadHM.get("CN_RELATED_ITEM_NAME"); // 35,
	// String sCN_RELATED_ITEM_REV =
	// (String)linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
	//
	// sCRT_USERS = "admin_platform";
	//
	// String parentRelName = cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
	// String sType = "";
	// boolean isExistCAD = false;
	// if("Assembly".equals(sTempType)){
	// sType = cdmConstantsUtil.TYPE_CATPRODUCT;
	// isExistCAD = true;
	// }else if("AutoCAD".equals(sTempType)){
	// sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
	// }else if("Image Drawing".equals(sTempType)){
	// sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
	// }else if("Drawing".equals(sTempType)){
	// sType = cdmConstantsUtil.TYPE_CATDrawing;
	// isExistCAD = true;
	// }else if("Part".equals(sTempType)){
	// sType = cdmConstantsUtil.TYPE_CATPART;
	// isExistCAD = true;
	// }else if("sV4Model".equals(sTempType)){
	// sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
	// }else if("UG NX Drawing".equals(sTempType)){
	// sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
	// }else{
	//
	// /*
	// ***********************************************************************
	// * Type 정보가 없다면 에러 처리.
	// * ***********************************************************************
	// */
	// StringBuffer errorSBuf = new StringBuffer();
	// errorSBuf.append("NOT MATCH TYPE INFOAMTION. ");
	// throw new Exception(errorSBuf.toString());
	//
	// }
	//
	// /*
	// ***********************************************************************
	// * PART 데이타 있는데 OBJECT 정보가 존재하지 않는다면 에러 발생
	// * 존재한다면 연결 연결 정보는 ??
	// * ***********************************************************************
	// */
	// String sPartFindObjId = "";
	// if(cdmStringUtil.isNotEmpty(sTDMX_RELATED_ITEM_ID) &&
	// cdmStringUtil.isNotEmpty(sCN_RELATED_ITEM_REV)){
	// String sPartFindMql = MqlUtil.mqlCommand(context, "temp query bus
	// 'cdmMechanicalPart,cdmPhantomPart' '"+sTDMX_RELATED_ITEM_ID +"'
	// '"+sCN_RELATED_ITEM_REV+"' select id dump |");
	// StringList sListPartFindMqlResult = FrameworkUtil.split(sPartFindMql,
	// "|");
	// if(sListPartFindMqlResult.size()>2){
	// sPartFindObjId = (String)sListPartFindMqlResult.get(3);
	// }else{
	// StringBuffer errorSBuff = new StringBuffer();
	// errorSBuff.append("NOT FIND PART OBJECT IN ENOVIA. ");
	// throw new Exception(errorSBuff.toString());
	// }
	// }
	//
	// /* Person 정보 확인 */
	// boolean IsExistPerson = false;
	// String sIsPersonMql = MqlUtil.mqlCommand(context, "temp query bus Person
	// '"+sCRT_USERS+"' * select name dump |");
	// StringList sListIsPersonMqlResult = FrameworkUtil.split(sIsPersonMql,
	// "|");
	// if(sListIsPersonMqlResult.size()>2){
	// IsExistPerson = true;
	// }
	//
	// /*
	// ***********************************************************************
	// * object name 설정
	// * sCAD_REF_FILE_NAME 데이타가 존재하지않는다면 에러 처리
	// * ***********************************************************************
	// */
	// String sName = "";
	// if(cdmStringUtil.isNotEmpty(sCAD_REF_FILE_NAME)) {
	// int intLastExtension = sCAD_REF_FILE_NAME.lastIndexOf(".");
	// sName = sCAD_REF_FILE_NAME.substring(0, intLastExtension);
	// sName = sName.trim();
	// }else{
	// String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . ";
	// throw new Exception(sErrorMessage);
	// }
	//
	//
	// ContextUtil.startTransaction(context, true);
	// if (isExistCAD) {
	//
	// MCADServerResourceBundle resourceBundle = new
	// MCADServerResourceBundle((String) context.getLocale().getLanguage());
	// IEFGlobalCache cache = new IEFGlobalCache();
	//
	// MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
	//
	//
	// /*
	// ***********************************************************************
	// * REVISION 정보가 없다면 에러 처리.
	// * REVISION 설정 .
	// * ***********************************************************************
	// */
	// if(cdmStringUtil.isEmpty(sRevision)){
	// String errorMessage = "NOT EXIST REVISION DATA. ";
	// throw new Exception(errorMessage);
	// }
	// String sRevisionSeqence = "";
	// if (!"---".equals(sRevision)) {
	//
	// Policy policyDesignTeamDefine = new
	// Policy(cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION);
	// policyDesignTeamDefine.open(context);
	//
	// String stPolicySequence = policyDesignTeamDefine.getSequence(context);
	// policyDesignTeamDefine.close(context);
	//
	// int iSeqenceNumber = 0; // SEQUNCE
	// boolean checkSequence = false;
	// StringList stListPolicy = FrameworkUtil.split(stPolicySequence, ",");
	// for (int iPolicyCnt = 0; iPolicyCnt < stListPolicy.size(); iPolicyCnt++)
	// {
	// String sPolicySequence = (String) stListPolicy.get(iPolicyCnt);
	//
	// String tempSequence = sPolicySequence.replaceAll("-", "");
	// if (cdmStringUtil.isNotEmpty(tempSequence) &&
	// sRevision.equals(tempSequence)) {
	// iSeqenceNumber = iPolicyCnt;
	// checkSequence = true;
	// }
	// }
	// sRevisionSeqence = (String) stListPolicy.get(iSeqenceNumber);
	// //System.out.println("sRevisionSeqence --->" + sRevisionSeqence);
	//
	// if(!checkSequence){
	// String errorMessage = "NOT MATCH POLICY SEQUENCE AND REVISION DATA. ";
	// throw new Exception(errorMessage);
	// }
	// }else{
	// sRevisionSeqence = sRevision;
	// }
	//
	// BusinessObject existBusinessObj = new BusinessObject(sType, sName,
	// sRevisionSeqence, "");
	// String minorRevString =
	// mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
	// BusinessObject existMinorBusinessObj = new BusinessObject(sType, sName,
	// minorRevString, "");
	//
	// boolean isMajorExist = existBusinessObj.exists(context);
	// boolean istMinorExist = existMinorBusinessObj.exists(context);
	//
	// if (!isMajorExist) {
	// //
	// DomainObject busObject = new DomainObject();
	// DomainObject minorBusObject = new DomainObject();
	//
	// String sAttribute_CADType = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_CADType");
	// String sAttribute_MoveFileVersion =
	// MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_MoveFilesToVersion");
	// // original file name 과 데이타가 같다.
	// String sAttribute_Title = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_Title");
	// String sAttribute_IsVersionObj =
	// MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
	// String sAttribute_IEFFileMessage =
	// MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_IEF-FileMessageDigest");
	// String sAttribute_Source = MCADMxUtil.getActualNameForAEFData(context,
	// "attribute_Source");
	//
	//
	//// MqlUtil.mqlCommand(context, "Trigger Off");
	// busObject.createObject(context, sType, sName, sRevisionSeqence,
	// cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION,
	// cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
	//// MqlUtil.mqlCommand(context, "Trigger On");
	// String stObjectId = busObject.getObjectId();
	//
	// String strWorkspacePath = "C:\\Users\\mj\\Documents\\20161031";
	// String strFormat = "prt";
	// String strFileCheckinName = "K801692_SYMBOLE_071212.CATPart";
	// busObject.checkinFile(context, true, true, null, strFormat, "STORE",
	// strFileCheckinName,strWorkspacePath);
	// /*
	// * *****************************************************************
	// * ************************************************ 파일 체크인 파일명은
	// * sCAD_REF_FILE_NAME 으로 하며 최신 revision 에 연결된 file 을 Design Team
	// * Resource 아직은 주석처리 10.17.2016 확인하고 추후 진행할것
	// * !!!!!!!!!!!!!!!!!!!!!!!!!!!! 파일 체크인 하는 부분은 따로 처리할 예정 10.19.16
	// */
	// /* 속성 입력 start */
	//// String sTDMXID = (String)linkedCadHM.get("TDMX_ID"); // 2
	// attribute[cdmTDMXID]
	//// String sCRT_USERS = (String)linkedCadHM.get("CRT_USERS"); // 4
	// ,originator, owner
	//// String sTDM_DESCRIPTION = (String)linkedCadHM.get("TDM_DESCRIPTION");
	// // 5 ,
	//// String sTDMX_DETAILED_DESCRIPTION =
	// (String)linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); // 8 ,
	//// String sTDMX_COMMENTS = (String)linkedCadHM.get("TDMX_COMMENTS"); // 9
	// ,
	//// String sTDMX_3D_CAD_IDENTIFIER =
	// (String)linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); // 10,
	//// String sTDMX_SCALE = (String)linkedCadHM.get("TDMX_SCALE"); // 12,
	//// String sTDMX_PAGE_SIZE = (String)linkedCadHM.get("TDMX_PAGE_SIZE"); //
	// 13,
	//// String sFILE_TYPE = (String)linkedCadHM.get("FILE_TYPE"); // 14,
	//// String sCAD_REF_FILE_NAME =
	// (String)linkedCadHM.get("CAD_REF_FILE_NAME"); // 16, ORIGINAL FILE
	//// String sTDM_DOCUMENT_TYPE =
	// (String)linkedCadHM.get("TDM_DOCUMENT_TYPE"); // 20,
	//// String sCN_MASS = (String)linkedCadHM.get("CN_MASS"); // 27,
	//// String sCN_SURFACE_AREA = (String)linkedCadHM.get("CN_SURFACE_AREA");
	// // 28,
	//
	// AttributeList localAttributeList = new AttributeList();
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_Title), sCAD_REF_FILE_NAME));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_IEFFileMessage), ""));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_Source), sourceInfo));
	//
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID), sTDMXID));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION),
	// sTDMX_DETAILED_DESCRIPTION));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_COMMENT), sTDMX_COMMENTS));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER),
	// sTDMX_3D_CAD_IDENTIFIER));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE), sFILE_TYPE));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE),
	// sTDM_DOCUMENT_TYPE));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION), "Y"));
	//
	// if ((cdmConstantsUtil.TYPE_CATDrawing).equals(sType)) {
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE),
	// sTDMX_SCALE));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE),
	// sTDMX_PAGE_SIZE));
	// }
	//
	// if ((cdmConstantsUtil.TYPE_CATPART).equals(sType)) {
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS), sCN_MASS));
	// }
	//
	// if ((cdmConstantsUtil.TYPE_CATPART).equals(sType) ||
	// (cdmConstantsUtil.TYPE_CATPRODUCT).equals(sType)) {
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE),
	// sCN_SURFACE_AREA));
	// }
	//
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_MoveFileVersion), "True"));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_IsVersionObj), "False"));
	//
	// /*
	// * MAJOR VERSION OBJECT
	// * ATTRIBUTE[ORIGINATOR],OWNER 정보 추가
	// * PERSON 정보가 존재하지않는다면 제외
	// *
	// */
	// //test start 임시로 주석처리 시작 10.28.16
	// String sAttribute_Originator =
	// MCADMxUtil.getActualNameForAEFData(context, "attribute_originator");
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_Originator), sCRT_USERS));
	// if(IsExistPerson){
	//
	//// busObject.setOwner(context, sCRT_USERS);
	// //test start 임시로 주석처리 끝
	// }
	//
	// /* MAJOR VERSION OBJECT ATTRIBUTE, DESCRIPTION 설정 */
	// busObject.setAttributes(context, localAttributeList);
	// busObject.setDescription(context, sTDM_DESCRIPTION);
	//
	// /*RELATIONSHIP PART SPECIFICATION 연결*/
	// String isFrom = "true";
	// if(cdmStringUtil.isNotEmpty(sPartFindObjId)){
	// busObject.addRelatedObject(context, new RelationshipType(parentRelName),
	// isFrom.equalsIgnoreCase("true"), sPartFindObjId);
	// }
	//
	//
	// /* MINOR VERSION */
	// localAttributeList.remove(new Attribute(new
	// AttributeType(sAttribute_MoveFileVersion), "True"));
	// localAttributeList.remove(new Attribute(new
	// AttributeType(sAttribute_IsVersionObj), "False"));
	//
	// String stVersionId = "";
	// if (!istMinorExist) {
	//
	// //
	//// MCADGlobalConfigObject globalConfigObject = (MCADGlobalConfigObject)
	// programMap.get("GCO");
	// MCADGlobalConfigObject globalConfigObject = null;
	//// IEFGlobalCache cache = new IEFGlobalCache();
	//// MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
	// MCADServerGeneralUtil generalUtil = new MCADServerGeneralUtil(context,
	// globalConfigObject, resourceBundle, cache);
	// String minorPolicy = mxUtil.getRelatedPolicy(context,
	// cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION); //[NDM] : L86
	//
	// stVersionId = generalUtil.createAndConnectToMinorObject(context,
	// minorRevString, true, busObject, globalConfigObject, true,
	// false,minorPolicy); //[NDM] : L86
	//
	//
	// //
	//// minorBusObject.createObject(context, sType, sName, minorRevString,
	// cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY,
	// cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
	// minorBusObject.setId(stVersionId);
	//
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_MoveFileVersion), "False"));
	// localAttributeList.addElement(new Attribute(new
	// AttributeType(sAttribute_IsVersionObj), "True"));
	//
	// minorBusObject.setAttributes(context, localAttributeList);
	//
	// if (cdmStringUtil.isNotEmpty(sTDM_DESCRIPTION)) {
	// minorBusObject.setDescription(context, sTDM_DESCRIPTION);
	// }
	//
	// }else{
	// String errorMessage = "ALREADY EXIST MINOR OBJECT.";
	// throw new Exception(errorMessage);
	// }
	//
	// /*
	// * MINOR VERSION OBJECT
	// * OWNER 정보 추가
	// * ORIGNATIOR 추가 예정
	// * PERSON 정보가 존재하지않는다면 제외
	// */
	//// if (IsExistPerson) {
	//// minorBusObject.setOwner(context, sCRT_USERS);
	//// }
	//// StringBuffer localStringBufferVersion = new StringBuffer();
	//// localStringBufferVersion.append("connect bus \"");
	//// localStringBufferVersion.append(stVersionId);
	//// localStringBufferVersion.append("\" relationship \"");
	//// localStringBufferVersion.append(cdmConstantsUtil.RELATIONSHIP_VERSION_OF);
	//// localStringBufferVersion.append("\" preserve to \"");
	//// localStringBufferVersion.append(stObjectId);
	//// localStringBufferVersion.append("\" ");
	////
	//// MQLCommand localMQLCommand = new MQLCommand();
	//// localMQLCommand.open(context);
	//// boolean boolBufferVersion = localMQLCommand.executeCommand(context,
	// localStringBufferVersion.toString());
	//// if(!boolBufferVersion){
	//// String errorMessage = " NOT RELATIONSHIP[VersionOf] CONNECT MAJOR
	// OBJECT, MINOR OBJECT ";
	//// throw new Exception(errorMessage);
	//// }
	//// localMQLCommand.close(context);
	////
	////
	//// StringBuffer localStringBufferActive = new StringBuffer();
	//// localStringBufferActive.append("connect bus \"");
	//// localStringBufferActive.append(stObjectId);
	//// localStringBufferActive.append("\" relationship \"");
	//// localStringBufferActive.append(cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION);
	//// localStringBufferActive.append("\" preserve to \"");
	//// localStringBufferActive.append(stVersionId);
	//// localStringBufferActive.append("\" ");
	////
	//// MQLCommand activeMQLCommand = new MQLCommand();
	//// activeMQLCommand.open(context);
	//// boolean boolBufferActive = activeMQLCommand.executeCommand(context,
	// localStringBufferActive.toString());
	//// if(!boolBufferActive){
	//// String errorMessage = " NOT RELATIONSHIP[Active Version] CONNECT MAJOR
	// OBJECT, MINOR OBJECT ";
	//// throw new Exception(errorMessage);
	//// }
	//// activeMQLCommand.close(context);
	////
	////
	//// StringBuffer localStringBufferLatest = new StringBuffer();
	//// localStringBufferLatest.append("connect bus \"");
	//// localStringBufferLatest.append(stObjectId);
	//// localStringBufferLatest.append("\" relationship \"");
	//// localStringBufferLatest.append(cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION);
	//// localStringBufferLatest.append("\" preserve to \"");
	//// localStringBufferLatest.append(stVersionId);
	//// localStringBufferLatest.append("\" ");
	////
	//// MQLCommand latestMQLCommand = new MQLCommand();
	//// latestMQLCommand.open(context);
	//// boolean boolBufferLatest = latestMQLCommand.executeCommand(context,
	// localStringBufferLatest.toString());
	//// if(!boolBufferLatest){
	//// String errorMessage = " NOT RELATIONSHIP[Latest Version] CONNECT MAJOR
	// OBJECT, MINOR OBJECT ";
	//// throw new Exception(errorMessage);
	//// }
	//// latestMQLCommand.close(context);
	// /* 속성 입력 end */
	//
	//
	// }else{
	//// String errorMessage = "ALREADY EXIST MAJOR OBJECT. NOT MAKE CAD OBJECT
	// .";
	//// throw new Exception(errorMessage);
	//
	// }
	//
	//
	// }else {
	// /* Document 타입일 경우
	// * Document 의 경우 'Document Release' policy 인 object 에 모든 파일이 저장되며
	// * revision의 object의 경우에도 파일이 이동하지않고 변경한 데이타들이 저장
	// * 파일 이 추가 될
	// * cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성 추가
	// * Originator은 user 정보로 변경 Person 정보가 enovia에 Person 정보에 있을시 Owner 추가.
	// * 최신 release 정보 을 가지고 생성
	// */
	//
	// DomainObject documentBusObj = new DomainObject();
	// DomainObject documentMinorBusObj = new DomainObject();
	// BusinessObject existdocumentBusObj = new BusinessObject(sType, sName,
	// sRevision, "");
	// boolean isMajorDocumentObjExist = existdocumentBusObj.exists(context);
	//
	// if(!isMajorDocumentObjExist){
	// //
	// String policy = "Document Release";
	// String title = sName;
	// String language = null;
	// String isFrom = "true";
	// String objectGeneratorRevision = "";
	// String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
	//
	// if (sTDM_DESCRIPTION == null || "".equals(sTDM_DESCRIPTION) ||
	// "null".equals(sTDM_DESCRIPTION)) {
	// sTDM_DESCRIPTION = (String) linkedCadHM.get("sTDM_DESCRIPTION");
	// }
	//
	// if (sCAD_REF_FILE_NAME == null || "".equals(sCAD_REF_FILE_NAME) ||
	// "null".equals(sCAD_REF_FILE_NAME)) {
	// sCAD_REF_FILE_NAME = null;
	// }
	//
	// CommonDocument object = (CommonDocument)
	// DomainObject.newInstance(context, CommonDocument.TYPE_DOCUMENTS);
	// DomainObject parentObject = null;
	// if (sPartFindObjId != null && !"".equals(sPartFindObjId) &&
	// !"null".equals(sPartFindObjId)) {
	// parentObject = DomainObject.newInstance(context, sPartFindObjId);
	// }
	//
	// HashMap<String,Object> mAttrMap = new HashMap<String,Object>(); //데이타
	// 입력해야함 10.18.16 속성정보 지정할것
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE,
	// sTDMX_PAGE_SIZE );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE, sTDMX_SCALE
	// );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_TITLE_TYPE,
	// sTDMX_TITLE_TYPE );
	//
	// //MIGRATION DATA을 위해 속성 추가 AUTOCAD, ..
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID, sTDMXID );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION,
	// sTDMX_DETAILED_DESCRIPTION );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_COMMENT, sTDMX_COMMENTS );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER,
	// sTDMX_3D_CAD_IDENTIFIER );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE, sFILE_TYPE );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE,
	// sTDM_DOCUMENT_TYPE );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, "Y" );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS, sCN_MASS );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE,
	// sCN_SURFACE_AREA );
	// mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sCRT_USERS );
	//// MqlUtil.mqlCommand(context, "Trigger Off");
	// object = object.createAndConnect(context, sType, sName, sRevision,
	// policy, sTDM_DESCRIPTION, vault, title, language, parentObject,
	// parentRelName, isFrom, mAttrMap, objectGeneratorRevision);
	//// MqlUtil.mqlCommand(context, "Trigger On");
	// StringList selects = new StringList(2);
	// selects.add(DomainConstants.SELECT_ID);
	// selects.add(CommonDocument.SELECT_MOVE_FILES_TO_VERSION);
	//
	// Map objectSelectMap = object.getInfo(context, selects);
	// String objectId = "";
	// objectId = (String) objectSelectMap.get(DomainConstants.SELECT_ID);
	//
	// boolean isFilePresent = true;
	// String sVersionDescription = null;
	// Map attrMapOfVersion = new HashMap();
	//
	// boolean createVersion = true;
	//
	// String checkinId = "";
	// if (createVersion) {
	//// MqlUtil.mqlCommand(context, "Trigger Off");
	// checkinId = object.createVersion(context, sVersionDescription,
	// sCAD_REF_FILE_NAME, attrMapOfVersion);
	//// MqlUtil.mqlCommand(context, "Trigger On");
	// }
	//
	// /*person 정보가 있다면 document와 version owner 속성 정보에 입력 */
	// if (sListIsPersonMqlResult.size()>2) {
	// object.setOwner(context, (String)sListIsPersonMqlResult.get(3));
	//
	// if(cdmStringUtil.isNotEmpty(checkinId)){
	// DomainObject dObjVersion = DomainObject.newInstance(context,checkinId);
	// dObjVersion.setOwner(context, (String)sListIsPersonMqlResult.get(3));
	// }
	// }
	//
	// }else{
	// String errorMessage = "ALREADY EXIST MAJOR OBJECT. NOT MAKE DOCUMENT
	// OBJECT .";
	// throw new Exception(errorMessage);
	// }
	//
	//
	// }
	// ContextUtil.commitTransaction(context);
	// writeSuccessToFile("SUCESS!! LINE NUMBER: " + recordRowNum);
	// writeMessageToConsole("SUCESS!! LINE NUMBER: " + recordRowNum);
	// } catch (Exception exception) {
	// ContextUtil.abortTransaction(context);
	//
	// writeMessageToConsole(" Exception occured : " + exception.getMessage()+"
	// LINE NUMBER: " + recordRowNum);
	// writeErrorToFile("[${CLASS:cdmCADMigration} : executeCadcMigration]
	// Exception occured : " + exception.getMessage()+ " LINE NUMBER: " +
	// recordRowNum);
	// exception.printStackTrace(errorStream);
	//
	// writeFailToFile("[${CLASS:cdmCADMigration} : executeCadcMigration] fail
	// occured. LINE NUMBER: " + recordRowNum);
	// }
	// }
	//
	//
	// writeMessageToConsole("====================================================================================");
	// writeMessageToConsole(" File CAD Migration COMPLETED. ");
	// writeMessageToConsole("====================================================================================\n");
	//
	//
	// }catch(Exception exception)
	// {
	// writeFailToFile("[${CLASS:cdmCADMigration} : executeCadcMigration] fail
	// occured. LINE NUMBER: " + recordRowNum);
	// writeMessageToConsole(" Exception occured : "+exception.getMessage() +"
	// LINE NUMBER: "+recordRowNum);
	// writeErrorToFile("[${CLASS:cdmCADMigration} : executeCadcMigration]
	// Exception occured. LINE NUMBER: "+recordRowNum + "
	// "+exception.getMessage());
	// exception.printStackTrace(errorStream);
	// }
	// finally {
	// writeMessageToConsole("====================================================================================");
	// writeMessageToConsole(" LEAD TIME:"+ (System.currentTimeMillis() -
	// startTime) + "ms \n" );
	// writeMessageToConsole("====================================================================================
	// \n");
	// closeLogStream();
	// System.out.println("[${CLASS:cdmCADMigration} : executeCadcMigration] end
	// .");
	// }
	// }

	// /**
	// * ThumbnailViewable,CgrViewable object 생성후
	// * CATPart 의 object policy [Design TEAM Definition] 을 파일 체크인
	// * revise 되면 처리
	// * Document 일때 파일의 위치
	// * CAD 파일일때 파일의 위치
	// * @param context
	// * @param args
	// * @throws Exception
	// */
	// public void excuteCadCheckin(Context context ,String args[])throws
	// Exception{
	// try{
	// long startTime = System.currentTimeMillis();
	// System.out.println("[${CLASS:cdmCADMigration} : executeCadcMigration] start
	// ."+startTime +"ms");
	//
	//
	// String logFileName = "CadCheckinFileMigration";
	//
	// String[] argTest =
	// {"C:\\temp\\Import_File\\CAD","CAD_Items_FULL_02.txt"}; //읽을 파일경로 ,읽을 파일명
	// initializeM(context,argTest,2,logFileName); //context , artTest, argTest
	// 갯수 체크을위한 수, 로그 파일명의 default 파일명.
	//
	// writeMessageToConsole("====================================================================================");
	// writeMessageToConsole(" CAD DATA MIGRATION "+ getTimeStamp()+" \n");
	// writeMessageToConsole(" Reading input log file from : "+inputDirectory);
	// writeMessageToConsole(" Writing Log files to: " + outputDirectory );
	// writeMessageToConsole("====================================================================================\n");
	// int lineNumber = 0;
	// StringList stListHeader = new StringList();
	// String recordRowNum = "";
	//
	// try {
	//
	// String stReadData = "";
	// bufferReader = new BufferedReader(new InputStreamReader(new
	// FileInputStream(inputDirectory + fileName), "euc-kr"));
	// while ((stReadData = bufferReader.readLine()) != null) {
	// StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
	//
	// if (lineNumber == 0) {
	// stListHeader = stListReadData;
	//
	// lineNumber++;
	// continue;
	// }
	// LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String,
	// Object>();
	//
	// for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {
	//
	// String stTempCadInfos = ((String) stListReadData.get(stListNum)).trim();
	// String stTempCadInfosHeader = ((String)
	// stListHeader.get(stListNum)).trim();
	// stTempCadInfos = isVaildNullData(stTempCadInfos);
	// linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);
	//
	// }
	// lineNumber++;
	// // //TEST start
	// if(lineNumber >3){
	// continue;
	// }
	// // //TEST end
	// if (lineNumber == 1) {
	// continue;
	// }
	//
	// recordRowNum = (String) linkedCadHM.get("#");
	// String sTempType = (String) linkedCadHM.get("CLS_NAME"); // 1 ,Type
	// String sTDMXID = (String) linkedCadHM.get("TDMX_ID"); // 2
	// ,attribute[cdmTDMXID]
	// String sRevision = (String) linkedCadHM.get("REVISION"); // 3 ,Revision
	// String sCRT_USERS = (String) linkedCadHM.get("CRT_USERS"); // 4
	// ,originator,owner
	// String sTDM_DESCRIPTION = (String) linkedCadHM.get("TDM_DESCRIPTION"); //
	// 5
	// String sTDMX_RELATED_ITEM_ID = (String)
	// linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6
	// // String sTDMX_CAD_IDENTIFIER =
	// (String)linkedCadHM.get("TDMX_CAD_IDENTIFIER"); // 7 ,
	// String sTDMX_DETAILED_DESCRIPTION = (String)
	// linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); // 8
	// String sTDMX_COMMENTS = (String) linkedCadHM.get("TDMX_COMMENTS"); // 9
	// String sTDMX_3D_CAD_IDENTIFIER = (String)
	// linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); // 10,
	// String sTDMX_TITLE_TYPE = (String) linkedCadHM.get("TDMX_TITLE_TYPE"); //
	// 11,
	// String sTDMX_SCALE = (String) linkedCadHM.get("TDMX_SCALE"); // 12,
	// String sTDMX_PAGE_SIZE = (String) linkedCadHM.get("TDMX_PAGE_SIZE"); //
	// 13,
	// String sFILE_TYPE = (String) linkedCadHM.get("FILE_TYPE"); // 14,
	// // String sFILE_NAME = (String)linkedCadHM.get("FILE_NAME"); //15,
	// String sCAD_REF_FILE_NAME = (String)
	// linkedCadHM.get("CAD_REF_FILE_NAME"); // 16,// ORIGINAL FILE
	//
	// String sVAULT_OBJECT_ID = (String) linkedCadHM.get("VAULT_OBJECT_ID"); //
	// 17,
	// String sPHASE = (String) linkedCadHM.get("PHASE"); // 18,
	// String sTDM_ORG_USER_ID = (String) linkedCadHM.get("TDM_ORG_USER_ID"); //
	// 19,
	// String sTDM_DOCUMENT_TYPE = (String)
	// linkedCadHM.get("TDM_DOCUMENT_TYPE"); // 20,
	// String sTDM_ARCHIVE_TYPE = (String) linkedCadHM.get("TDM_ARCHIVE_TYPE");
	// // 21,
	// String sTDM_ARCHIVE_NAME = (String) linkedCadHM.get("TDM_ARCHIVE_NAME");
	// // 22,
	// String sPROD_DIV = (String) linkedCadHM.get("PROD_DIV"); // 23,
	// String sCN_PROJECT = (String) linkedCadHM.get("CN_PROJECT"); // 24,
	// // String sCN_PROJECT = (String)linkedCadHM.get("CN_PROJECT"); // 25, 중복
	// 데이타 이므로 무시함
	// String sCN_PROJECT_CUST = (String) linkedCadHM.get("CN_PROJECT_CUST"); //
	// 26,
	// String sCN_MASS = (String) linkedCadHM.get("CN_MASS"); // 27,
	// String sCN_SURFACE_AREA = (String) linkedCadHM.get("CN_SURFACE_AREA"); //
	// 28,
	// String sCN_OEM_PART_NUMBER = (String)
	// linkedCadHM.get("CN_OEM_PART_NUMBER"); // 29,
	// String sCN_ECO_NUMBER = (String) linkedCadHM.get("CN_ECO_NUMBER"); // 30,
	// String sCN_MASS_ESTIMATED = (String)
	// linkedCadHM.get("CN_MASS_ESTIMATED"); // 31,
	// String sCN_PRODUCT_GROUP = (String) linkedCadHM.get("CN_PRODUCT_GROUP");
	// // 32,
	// String sCN_CUSTOMER = (String) linkedCadHM.get("CN_CUSTOMER"); // 33,
	// // String sCN_VEHICLE = (String)linkedCadHM.get("CN_VEHICLE"); // 34, 이
	// 데이타는 migration 대상자 아님
	// String sCN_RELATED_ITEM_NAME = (String)
	// linkedCadHM.get("CN_RELATED_ITEM_NAME"); // 35,
	// String sCN_RELATED_ITEM_REV = (String)
	// linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
	//
	// String parentRelName = cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
	// String sType = "";
	// boolean isExistCAD = false;
	// if ("Assembly".equals(sTempType)) {
	// sType = cdmConstantsUtil.TYPE_CATPRODUCT;
	// isExistCAD = true;
	// } else if ("AutoCAD".equals(sTempType)) {
	// sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
	// } else if ("Image Drawing".equals(sTempType)) {
	// sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
	// } else if ("Drawing".equals(sTempType)) {
	// sType = cdmConstantsUtil.TYPE_CATDrawing;
	// isExistCAD = true;
	// } else if ("Part".equals(sTempType)) {
	// sType = cdmConstantsUtil.TYPE_CATPART;
	// isExistCAD = true;
	// } else if ("sV4Model".equals(sTempType)) {
	// sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
	// } else if ("UG NX Drawing".equals(sTempType)) {
	// sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
	// } else {
	//
	// /*
	// * *****************************************************
	// * Type 정보가 없다면 에러 처리.
	// * *****************************************************
	// */
	// StringBuffer errorSBuf = new StringBuffer();
	// errorSBuf.append("NOT MATCH TYPE INFOAMTION. ");
	// throw new Exception(errorSBuf.toString());
	//
	// }
	//
	// /*
	// * *********************************************************
	// * PART 데이타 있는데 OBJECT 정보가 존재하지 않는다면 에러 발생
	// * 존재한다면 연결 연결 정보는 ??
	// * *********************************************************
	// */
	// String sPartFindObjId = "";
	// if (cdmStringUtil.isNotEmpty(sTDMX_RELATED_ITEM_ID) &&
	// cdmStringUtil.isNotEmpty(sCN_RELATED_ITEM_REV)) {
	// String sPartFindMql = MqlUtil.mqlCommand(context, "temp query bus
	// 'cdmMechanicalPart,cdmPhantomPart' '" + sTDMX_RELATED_ITEM_ID + "' '" +
	// sCN_RELATED_ITEM_REV + "' select id dump |");
	// StringList sListPartFindMqlResult = FrameworkUtil.split(sPartFindMql,
	// "|");
	// if (sListPartFindMqlResult.size() > 2) {
	// sPartFindObjId = (String) sListPartFindMqlResult.get(3);
	// } else {
	// StringBuffer errorSBuff = new StringBuffer();
	// errorSBuff.append("NOT FIND PART OBJECT IN ENOVIA. ");
	// throw new Exception(errorSBuff.toString());
	// }
	// }
	//
	// /* Person 정보 확인 */
	// boolean IsExistPerson = false;
	// String sIsPersonMql = MqlUtil.mqlCommand(context, "temp query bus Person
	// '" + sCRT_USERS + "' * select name dump |");
	// StringList sListIsPersonMqlResult = FrameworkUtil.split(sIsPersonMql,
	// "|");
	// if (sListIsPersonMqlResult.size() > 2) {
	// IsExistPerson = true;
	// }
	//
	// /*
	// * *********************************************************
	// * object name 설정 sCAD_REF_FILE_NAME 데이타가
	// * 존재하지않는다면 에러 처리
	// * *********************************************************
	// */
	// String sName = "";
	// if (cdmStringUtil.isNotEmpty(sCAD_REF_FILE_NAME)) {
	// int intLastExtension = sCAD_REF_FILE_NAME.lastIndexOf(".");
	// sName = sCAD_REF_FILE_NAME.substring(0, intLastExtension);
	// sName = sName.trim();
	// } else {
	// String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . ";
	// throw new Exception(sErrorMessage);
	// }
	//
	// if (isExistCAD) {
	//
	// MCADServerResourceBundle resourceBundle = new
	// MCADServerResourceBundle((String) context.getLocale().getLanguage());
	// IEFGlobalCache cache = new IEFGlobalCache();
	//
	// MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
	//
	// /*
	// * *****************************************************
	// * REVISION 정보가 없다면 에러 처리. REVISION 설정 .
	// * *****************************************************
	// *
	// */
	// if (cdmStringUtil.isEmpty(sRevision)) {
	// String errorMessage = "NOT EXIST REVISION DATA. ";
	// throw new Exception(errorMessage);
	// }
	// String sRevisionSeqence = "";
	// if (!"---".equals(sRevision)) {
	//
	// Policy policyDesignTeamDefine = new
	// Policy(cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION);
	// policyDesignTeamDefine.open(context);
	//
	// String stPolicySequence = policyDesignTeamDefine.getSequence(context);
	// policyDesignTeamDefine.close(context);
	//
	// int iSeqenceNumber = 0; // SEQUNCE
	// boolean checkSequence = false;
	// StringList stListPolicy = FrameworkUtil.split(stPolicySequence, ",");
	// for (int iPolicyCnt = 0; iPolicyCnt < stListPolicy.size(); iPolicyCnt++)
	// {
	// String sPolicySequence = (String) stListPolicy.get(iPolicyCnt);
	//
	// String tempSequence = sPolicySequence.replaceAll("-", "");
	// if (cdmStringUtil.isNotEmpty(tempSequence) &&
	// sRevision.equals(tempSequence)) {
	// iSeqenceNumber = iPolicyCnt;
	// checkSequence = true;
	// }
	// }
	// sRevisionSeqence = (String) stListPolicy.get(iSeqenceNumber);
	// // System.out.println("sRevisionSeqence --->" + sRevisionSeqence);
	//
	// if (!checkSequence) {
	// String errorMessage = "NOT MATCH POLICY SEQUENCE AND REVISION DATA. ";
	// throw new Exception(errorMessage);
	// }
	// } else {
	// sRevisionSeqence = sRevision;
	// }
	//
	// BusinessObject existBusinessObj = new BusinessObject(sType, sName,
	// sRevisionSeqence, "");
	// String minorRevString =
	// mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
	// BusinessObject existMinorBusinessObj = new BusinessObject(sType, sName,
	// minorRevString, "");
	//
	// boolean isMajorExist = existBusinessObj.exists(context);
	// boolean istMinorExist = existMinorBusinessObj.exists(context);
	//
	// if (isMajorExist) {
	//// String strFormat = "";
	//// String strOriginalFileName = "";
	//// if(cdmConstantsUtil.TYPE_CATPART.equals(sType)){
	//// strOriginalFileName = "TESTFILENAME_20161027_001-CATPART.CATPart";
	//// }else if(cdmConstantsUtil.TYPE_CATPRODUCT.equals(sType)){
	//// strOriginalFileName = "TEST1027-002-CATPRODUCT.CATProduct";
	//// }else if(cdmConstantsUtil.TYPE_CATDrawing.equals(sType)){
	//// strOriginalFileName = "TEST1027-001.CATDrawing";
	//// }else{
	//// String errorMessage = "NOT TYPE DATA.";
	//// throw new Exception(errorMessage);
	//// }
	////
	//// String strWorkspacePath = "C:\\Users\\mj\\Documents\20161027";
	//// existBusinessObj.checkinFile(context, false, false, null, strFormat,
	// "STORE", strOriginalFileName,strWorkspacePath);
	//
	// } else {
	// String errorMessage = "NOT EXIST MAJOR OBJECT. ";
	// throw new Exception(errorMessage);
	// }
	//
	// } else {
	// /*
	// * Document 타입일 경우 Document 의 경우 'Document Release'
	// * policy 인 object 에 모든 파일이 저장되며 revision의 object의 경우에도
	// * 파일이 이동하지않고 변경한 데이타들이 저장 파일 이 추가 될
	// * cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성
	// * 추가 Originator은 user 정보로 변경 Person 정보가 enovia에 Person
	// * 정보에 있을시 Owner 추가. 최신 release 정보 을 가지고 생성
	// *
	// *
	// * sName 은 난수가 추가 되므로 추후 변경 될 소지가 있음 .
	// */
	//
	//// DomainObject documentBusObj = new DomainObject();
	//// DomainObject documentMinorBusObj = new DomainObject();
	//// BusinessObject existdocumentBusObj = new BusinessObject(sType, sName,
	// sRevision, "");
	//// boolean isMajorDocumentObjExist = existdocumentBusObj.exists(context);
	//
	//// if (!isMajorDocumentObjExist) {
	////
	//// } else {
	//// String errorMessage = "ALREADY EXIST MAJOR OBJECT. NOT MAKE DOCUMENT
	// OBJECT .";
	//// throw new Exception(errorMessage);
	//// }
	// String errorMessage = "NOT CHECK ";
	// throw new Exception(errorMessage);
	//
	// }
	// }
	// ContextUtil.commitTransaction(context);
	// writeSuccessToFile("SUCESS!! LINE NUMBER: " + recordRowNum);
	// writeMessageToConsole("SUCESS!! LINE NUMBER: " + recordRowNum);
	// } catch (Exception exception) {
	// ContextUtil.abortTransaction(context);
	//
	// writeMessageToConsole(" Exception occured : " + exception.getMessage() +
	// " LINE NUMBER: " + recordRowNum);
	// writeErrorToFile("[${CLASS:cdmCADMigration} : executeCadcMigration]
	// Exception occured : " + exception.getMessage() + " LINE NUMBER: " +
	// recordRowNum);
	// exception.printStackTrace(errorStream);
	//
	// writeFailToFile("[${CLASS:cdmCADMigration} : executeCadcMigration] fail
	// occured. LINE NUMBER: " + recordRowNum);
	// }
	//
	// }catch(Exception e){
	//
	// }
	// }

	public static void main(String[] args)throws Exception{
		
		Context context = new Context("");
			try{
				
			context.setUser("admin_platform");
			context.setPassword("");
			context.connect();
//			MqlUtil.mqlCommand(context, "Trigger Off");
//			ContextUtil.startTransaction(context, true);
			//
//			MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
//			IEFGlobalCache cache = new IEFGlobalCache();
//			MCADGlobalConfigObject globalConfigObject = null;
//			MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
//			
//			MCADServerGeneralUtil generalUtil = new MCADServerGeneralUtil(context, globalConfigObject, resourceBundle, cache);
//			String minorPolicy = mxUtil.getRelatedPolicy(context, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION);
//			String majorPolicy = MCADMxUtil.getActualNameForAEFData(context,"policy_DesignTEAMDefinition");
//			
//			DomainObject busDOCUMENT = new DomainObject();
//			String sType = "CATPart";
//			String strCadObjectName = "CATPart_Test_0123_001";
//			String sRevisionSeqence = "A";
//			busDOCUMENT.createObject(context, sType, strCadObjectName, sRevisionSeqence, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//			busDOCUMENT.setAttributeValue(context, "CAD Type", "component");
//			String attribute_source = MCADMxUtil.getActualNameForAEFData(context, "attribute_Source");
//			busDOCUMENT.setAttributeValue(context, attribute_source, sourceInfo);
//			
//			String majorId = busDOCUMENT.getObjectId(context);
//			
//			String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
//			
//			
////			String next = mxUtil.getNextVersionString();
//			String stVersionId = generalUtil.createAndConnectToMinorObject(context, minorRevString, true, busDOCUMENT, globalConfigObject, true, false, minorPolicy); // [NDM]
//			
//			Vault vault = context.getVault();
//
//			DomainObject minorBusObject = new DomainObject();
//			minorBusObject.setId(stVersionId);
////			minorBusObject.setVault(context, vault);
//			
//			String valutValue =minorBusObject.getVault();
//			System.out.println("valutValue "+valutValue);
//			System.out.println("majorId ->"+majorId+" stVersionId ->"+stVersionId);
//			String relationshipMinorBus1 = minorBusObject.getInfo(context, "relationship");
//			System.out.println("relationshipMinorBus ->>>>" + relationshipMinorBus1);
//			// minor disconnect 
////			String relLatestVerion  = cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION;
////			mxUtil.disconnectBusObjects(context, majorId,  stVersionId,relLatestVerion, true);
////			String relActiveVerion  = cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION;
////			mxUtil.disconnectBusObjects(context, majorId, stVersionId, relActiveVerion, true);
////			
////			
//			 String relationshipMinorBus = minorBusObject.getInfo(context, "relationship");
//			 System.out.println("relationshipMinorBus ->>>>" + relationshipMinorBus);
//			 
////			 StringList sListRelMajor =busDOCUMENT.getInfoList(context, "relationship") ;
////			 System.out.println("relationshipMinorBus ->>>>" + sListRelMajor.toString());
//			 
//			// 2 minor
//			BusinessObject majorBus = new BusinessObject(majorId);
//			String minorLatestId = mxUtil.getLatestMinorID(context,majorBus);
//			String nextMinorRev = "A.1";
//			
////			String stNextVersionId =  nextMinorBus.getObjectId(context);
//			String stNextVersionId = generalUtil.createAndConnectToMinorObject(context, nextMinorRev, false, busDOCUMENT, globalConfigObject, true, false, minorPolicy); // [NDM]
//			 
//			DomainObject nextVersionBus = new DomainObject(stNextVersionId);
//			System.out.println(nextVersionBus.getName(context));
//			System.out.println(nextVersionBus.getInfo(context, "first"));
//			System.out.println("!!!!!!!!!!!!!!"+nextVersionBus.getInfo(context, "relationship"));
////			mxUtil.connectBusObjects(context, str2, (String)localObject2, str10, true, null);
//			
////			mxUtil.connectBusObjects(context, majorId,  stNextVersionId,relLatestVerion, true,null);
//			
////			mxUtil.connectBusObjects(context, majorId, stNextVersionId, relActiveVerion, true,null);
//			
////			String minorStandMajorId = mxUtil.getMajorIDByLatestVersion(context, new BusinessObject(stNextVersionId).getObjectId(context));
//			String minorStandMajorId = mxUtil.getMajorIDByLatestVersion(context, new BusinessObject(minorBusObject).getObjectId(context));
//			
//			BusinessObject majorCheckBus = new BusinessObject(minorStandMajorId);
//			System.out.println("majorMajorBus = >"+majorCheckBus);
//			String nextMajorRev = "B";
////			BusinessObject nextMajorBus = new BusinessObject();
//			BusinessObject preMajorBus = new BusinessObject();
////			
//			DomainObject dObjTest = new DomainObject(majorCheckBus.getObjectId(context));
//			
//			String nextMajorId  = generalUtil.createAndConnectToMajorObject(context, nextMajorRev, false, new BusinessObject(majorCheckBus.getObjectId(context)), majorPolicy, true, false);
//			System.out.println("nextMajorId ==>"+nextMajorId);
////			String nextMajorId =nextMajorBus.getObjectId(context);
//			DomainObject nextMajorDObj = new DomainObject(nextMajorId);
//			System.out.println(""+nextMajorDObj.getName(context) +"  "+nextMajorDObj.getRevision(context) +" "+ nextMajorDObj.getInfo(context, "first")+ " "+nextMajorDObj.getPolicies(context));
////			System.out.println("nextMajorBus =>"+nextMajorDObj.getObjectId(context) + " Name ==>"+nextMajorDObj.getName(context) +"first "+ nextMajorDObj.getInfo(context, "first"));
////			BusinessObject latestMinorBus = new BusinessObject(minorLatestId);
////			BusinessObject nextMinorRevBus = latestMinorBus.revise(context, nextMinorRev, "eService Production");
//			
////			mxUtil.connectMajorAndMinorObjects(context, localBusinessObject1, str6, localBusinessObject4);
////			generalUtil.connectMajorAndMinorObjects(context, paramString1, paramString2);
////			String minorStandMajorId = mxUtil.getMajorIDByLatestVersion(context, nextMinorRevBus.getObjectId(context));
		
			
			//transaction test start 
//			boolean checkTransaction = false;
//			for (int i = 0; i < 3; i++) {
//				if(i==0){
//					ContextUtil.startTransaction(context, true);
//					checkTransaction = true;
//				}
//				
//				if(i==2){
//					ContextUtil.abortTransaction(context);
//					ContextUtil.startTransaction(context, true);
//					checkTransaction= false;
//				}
//				DomainObject busDOCUMENT = new DomainObject();
//				String sType = "CATPart";
//				String strCadObjectName = "CATPart_Test_0123_001"+"_"+i;
//				String sRevisionSeqence = "A";
//				busDOCUMENT.createObject(context, sType, strCadObjectName, sRevisionSeqence, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//				if(i==2){
//					strCadObjectName = "CATPart_Test_0123_001"+"_1";
//					BusinessObject bus = new BusinessObject(sType, strCadObjectName, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//					System.out.println("exist bus => "+bus.exists(context));
//					
//				}
//				 
//				
//			}
//			
//			ContextUtil.abortTransaction(context);
//			//transaction test end
			
			//CATDrawing TEST start
//			ContextUtil.startTransaction(context, true);
//			String strPolicDoc_Release = "Document Release";
//			String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
//			
//			String sType = "";
////			sType = "cdmImageDrawing";
//			sType = "cdmIGES";
////			sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
////			sType = "cdmSTEP";
////			sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
////			sType = cdmConstantsUtil.TYPE_CDMNXPART;
////			sType = "cdmCATIAMaterial";
////			sType = "cdmCATIAcgr";
////			sType = "cdmCATIAcgm";
////				sType = "cdmDXF";
//			String sRevisionSeqence = "A";
//			String strCadObjectName = "TEST_0124_001_DOCUMENT_RELEASE";
//			CommonDocument doMajorObject = (CommonDocument) DomainObject.newInstance(context, CommonDocument.TYPE_DOCUMENTS);
//			DomainObject dObj = new DomainObject();
//			dObj.createObject(context, sType, strCadObjectName, sRevisionSeqence, strPolicDoc_Release, vault);
//			doMajorObject.setId(dObj.getObjectId(context));
//			HashMap attrMapOfVersion = new HashMap();
//			
//			String strMinorVersionId = doMajorObject.createVersion(context,"" , strCadObjectName, attrMapOfVersion);
//			
//			System.out.println("strMinorVersionId ==>"+strMinorVersionId );
//			
//			
//			CommonDocument  minorVersionCDoc = new CommonDocument(strMinorVersionId);
//			System.out.println("minorVersionCDoc ==>"+minorVersionCDoc.getName(context) );
//			String majorVersionConnection = minorVersionCDoc.getInfo(context, "to[Active Version].id");
//			CommonDocument nextMinorVersionCDoc = new CommonDocument(minorVersionCDoc.reviseObject(context, false));
//			 
//			String str9 = "mod connection $1 to $2";
//			String nextMinorId = nextMinorVersionCDoc.getObjectId(context);
//			 MqlUtil.mqlCommand(context, str9, new String[] { majorVersionConnection, nextMinorId });
//			 
//			System.out.println("strMinorVersionId ==>"+strMinorVersionId );
//			System.out.println("nextMinorVersionCDoc ==>"+nextMinorVersionCDoc.getObjectId(context) +"   "+ nextMinorVersionCDoc.getRevision(context) );
//			
//			String nextMajorRevise = "B";
//			String majorId  = nextMinorVersionCDoc.getInfo(context, "to[Active Version].from.id");
//			
//			CommonDocument localCommonDocument = (CommonDocument) DomainObject.newInstance(context, CommonDocument.TYPE_DOCUMENTS);
//			localCommonDocument.setId(majorId);
//			BusinessObject reviseBus = localCommonDocument.revise(context, nextMajorRevise, false);
//			
//			DomainObject dReviseObj = new DomainObject(reviseBus);
//			System.out.println("reviseBus   =>> " + reviseBus.getRevisions(context) +" "+dReviseObj.getName(context) +" "+dReviseObj.getPolicy(context));
//			
//			
//			ContextUtil.abortTransaction(context);
			//CATDrawing TEST end
//			ContextUtil.startTransaction(context, true);
//			String sRevision = "A.101";
//			String sRevision = "A.002";
//			String sRevision = "D";
//			String sRevisionSeqence = "";
//			StringList sListRevisionSequence = new StringList();
//			sListRevisionSequence = FrameworkUtil.split(sRevision, "\\..+");
//			boolean bMinorRevision = false;
//			
//			String splitMinorRevision = "";
//			if(sListRevisionSequence.size()>2){
//				bMinorRevision = true;
//				String sRevisionSequnceSplit = (String)sListRevisionSequence.get(2);
//				Integer intergerRevisionSequence = Integer.parseInt(sRevisionSequnceSplit);
//				splitMinorRevision = String.format("%01d", intergerRevisionSequence);
//				System.out.println("splitMinorRevision"+splitMinorRevision);
//				sRevisionSeqence = (String)sListRevisionSequence.get(0); 
//				splitMinorRevision = sRevisionSeqence+"."+splitMinorRevision;
//			}else{
//				sRevisionSeqence = (String)sListRevisionSequence.get(0); 
//			}
//			
//			System.out.println("sRevision => "+sRevision +"   sRevisionSeqence ==> "+sRevisionSeqence);
//			fileData
//			ContextUtil.startTransaction(context, true);
			HashMap paramMaps = new HashMap();
//			paramMaps.put("fileData", "E:\\Import_File_Operation_Before\\CAD\\20170125\\CAD_Items_Qry_00_SAMPLE2.txt");
//			paramMaps.put("count", "4091");
//			paramMaps.put("fileData", "E:\\Import_File_Operation_Before\\CAD\\20170126\\CAD_Items_Qry_00_sample_003Product.txt");
			
//			paramMaps.put("fileData", "E:\\Import_File_Operation_Before\\CAD\\20170126\\CAD_Items_Qry_00-sample_003.txt");
//			paramMaps.put("fileData", "E:\\Import_File_Operation_Before\\CAD\\20170130\\checkinFileM_CAD_Items_Qry_00_sample_003Product_01_30 19_18_50_FailedLog.txt");
//			paramMaps.put("count", "56");
//			JPO.invoke(context, "cdmCADAllMigration", null, "executeMajorMinorAllCADMigration", JPO.packArgs(paramMaps), void.class);
			
//			paramMaps.put("fileData", "E:\\Import_File_Operation_Before\\CAD\\20170126\\CAD_Items_Qry_00-sample_003.txt");
//			paramMaps.put("fileData", "E:\\Import_File_Operation_Before\\CAD\\20170126\\CAD_Items_Qry_00_sample_003Product.txt");
//			paramMaps.put("fileData", "E:\\Import_File_Operation_Before\\CAD\\20170130\\checkinFileM_CAD_Items_Qry_00_sample_003Product_01_30 19_18_50_FailedLog.txt");
//			JPO.invoke(context, "cdmCADAllMigration", null, "executeMajorMinorCheckin", JPO.packArgs(paramMaps), void.class);
//			ContextUtil.abortTransaction(context);
//			ContextUtil.commitTransaction(context);
			}catch(Exception e){
//				ContextUtil.abortTransaction(context);
				e.printStackTrace();
			}finally{
//				MqlUtil.mqlCommand(context, "Trigger On");
			}
	}
	
	/**
	 * 0124 
	 * 수정한 cad 생성 migration
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public  void executeMajorMinorAllCADMigration(Context context,String[] args)throws Exception{


		if(args.length!=2){
			throw new Exception("parmeter value count wrong.");
		}
		String sFileLocationAndFileName = args[0];
		String sFilecount = args[1];
		
		
		Map paramMap = new HashMap();
//		paramMap = (Map) JPO.unpackArgs(args);
//		String sFileLocationAndFileName = (String)paramMap.get("fileData");
//		String sFilecount = (String)paramMap.get("count");
		String cadFileLocation = "";
		String cadFileName = "";

		cadFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf(File.separator));
		cadFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf(File.separator)+1);
		

		long startTime = System.currentTimeMillis();
		System.out.println("[cdmCADMigration_mxJPO : executeMajorMinorAllCADMigration] start ." + getTimeStamp());

		String logFileName = "CAD_M";
		int successInt = 0;
		int failInt = 0;
		
		int alreadyInt = 0;
		String[] argTemp = null;
		if (cdmStringUtil.isNotEmpty(cadFileLocation) && cdmStringUtil.isNotEmpty(cadFileName)) {
			argTemp = new String[] { cadFileLocation, cadFileName }; 
																	
		} else {
			argTemp = new String[] {};
		}
		int lintCountInteger = Integer.parseInt(sFilecount);
		
		// context , artTest,argTest 갯수 체크을위한 수,로그 파일명의 default 파일명.
		initializeM(context, argTemp, 2, logFileName); 
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("CAD DATA MIGRATION " + getTimeStamp() + " \n");
		writeMessageToConsole("Reading input log file from : " + inputDirectory+cadFileName);
		writeMessageToConsole("Writing Log files to: " + outputDirectory);
		writeMessageToConsole("====================================================================================\n");
		writeSuccessToFile("CreateTime \t rowNum(#) \t type \t name \t rev \t Person \t Oringintor \t org \t project");
		
		int lineNumber = 0;
		int notMatchTypeCount = 0;
		StringList sListHeader = new StringList();
		String recordRowNum = "";
		String recordTdmxId = "";
		String recordRealName = "";
		String recordRevision = "";
		String recordType = "";
		boolean triggerCheck = false;
		boolean bTransaction = false;
		
		try {
			MqlUtil.mqlCommand(context, "Trigger Off");
			triggerCheck = true;
			MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
			IEFGlobalCache cache = new IEFGlobalCache();
			MCADGlobalConfigObject globalConfigObject = null;
			MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
			
			MCADServerGeneralUtil generalUtil = new MCADServerGeneralUtil(context, globalConfigObject, resourceBundle, cache);
//			String minorPolicy = mxUtil.getRelatedPolicy(context, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION);
			String minorPolicy = "Versioned Design TEAM Policy";
//			String majorPolicy = MCADMxUtil.getActualNameForAEFData(context,"policy_DesignTEAMDefinition");
			
			String sReadData = "";
			
			boolean bStartTransaction = false;
			boolean bEndTransaction = false;
			String strPreviousCadType = "";
			String strPreviousCadName = "";
			String strPreviousObjectRev = "";
			String strPreviousObjectTdmxId = "";
			
			//기록을 위한 데이타
			StringList sListForRecordRowData = new StringList();
			StringList sListSuccessRowData = new StringList();
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
			String relLatestVerion  = cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION;
			String relActiveVerion  = cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION;
		    int readCount = 0;
			while ((sReadData = bufferReader.readLine()) != null) {
				StringList sListReadData = FrameworkUtil.split(sReadData, "\t");
				
				if (lineNumber == 0) {
					sListHeader = sListReadData;
					lineNumber++;
					writeFailToFile( "Time"+"\t"+ "Error_Num"+"\t"+sReadData);
					continue;
				}
				
				lineNumber++;
				readCount++;
				int headerSize = sListHeader.size();
				int readLineSize = sListReadData.size();
				try {
					if (headerSize != readLineSize) {
						String errorMessage = "NOT MATCH ROW INFOMATION "+"\t"+sListReadData.toString();
//						String errorMessage = "Sheet column information does not match."+"\t"+sListReadData.toString();
						throw new Exception(errorMessage);
					}

					LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();

					for (int dataCnt = 0; dataCnt < sListReadData.size(); dataCnt++) {

						String stTempCadInfos = (String) sListReadData.get(dataCnt);
						String stTempCadInfosHeader = (String) sListHeader.get(dataCnt);
						// 공백제거,null 처리,trim처리
						stTempCadInfosHeader = isVaildNullData(stTempCadInfosHeader);
						stTempCadInfos = isVaildNullData(stTempCadInfos);
						linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);

					}

//					if (lineNumber == 1) {
//						continue;
//					}
					
					MqlUtil.mqlCommand(context, "history Off");
					StringBuffer sbErrorMessage = new StringBuffer(""); 
					
					recordRowNum = (String) linkedCadHM.get("#");
					
					String sTempType 	= (String) linkedCadHM.get("CLS_NAME"); 
					String sTdmxId		= (String) linkedCadHM.get("TDMX_ID"); 
					String sRevision	= (String) linkedCadHM.get("REVISION"); 
					String sState		= (String) linkedCadHM.get("STATE"); 
					String sUsers		= (String) linkedCadHM.get("CRT_USERS"); 
					
					String sDescription		 = (String) linkedCadHM.get("TDM_DESCRIPTION"); 
					String sRelated_PartName	 = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); 
					String sCADIdentifier  = (String) linkedCadHM.get("TDMX_CAD_IDENTIFIER"); 
					String sDetailedDescription	= (String) linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); 
					String s3dCADIdentifier	= (String) linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); 
					String sTitleType		= (String) linkedCadHM.get("TDMX_TITLE_TYPE"); 
					String sScale		    = (String) linkedCadHM.get("TDMX_SCALE"); 
					String sPageSize	    = (String) linkedCadHM.get("TDMX_PAGE_SIZE"); 
					String sFileType	    = (String) linkedCadHM.get("FILE_TYPE"); 
					String sFileName	    = (String) linkedCadHM.get("FILE_NAME"); 
					String sCadRefFileName  = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); 
//					String sVault= (String) linkedCadHM.get("VAULT_OBJECT_ID");  // 파일 업로드시 필요 
					String sPhase		    = (String) linkedCadHM.get("PHASE"); 
					String sOrg				= (String) linkedCadHM.get("TDM_ORG_USER_ID"); 
					String sDocumentType	= (String) linkedCadHM.get("TDM_DOCUMENT_TYPE"); 
					String sArchiveType		= (String) linkedCadHM.get("TDM_ARCHIVE_TYPE"); 
					String sArchiveName		= (String) linkedCadHM.get("TDM_ARCHIVE_NAME"); 
					String sProdDiv			= (String) linkedCadHM.get("PROD_DIV"); 
					String sProject			= (String) linkedCadHM.get("CN_PROJECT"); 
					String sProjectCust		= (String) linkedCadHM.get("CN_PROJECT_CUST"); 
					String sMASS			= (String) linkedCadHM.get("CN_MASS"); 
					String sSurfaceArea		= (String) linkedCadHM.get("CN_SURFACE_AREA"); 
					String sOEMPartNumber	= (String) linkedCadHM.get("CN_OEM_PART_NUMBER"); 
					String sECONumber		= (String) linkedCadHM.get("CN_ECO_NUMBER"); 
					String sMassEstimated	= (String) linkedCadHM.get("CN_MASS_ESTIMATED"); 
					String sProductGroup	= (String) linkedCadHM.get("CN_PRODUCT_GROUP"); 
					String sCustomer		= (String) linkedCadHM.get("CN_CUSTOMER"); 
					String sVehicle			= (String) linkedCadHM.get("CN_VEHICLE"); 
					String sRelatedPartName	= (String) linkedCadHM.get("CN_RELATED_ITEM_NAME"); 
					String sRelatedPartRev	= (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); 
					String sProjectId		= (String) linkedCadHM.get("CN_PROJECT_ID"); 
					String sProdGroup		= (String) linkedCadHM.get("PROD_GROUP"); 
					String sCustVehicle		= (String) linkedCadHM.get("CN_CUST_VEHICLE"); 
					String sCreationdate = (String) linkedCadHM.get("CREATION_DATE"); 
					String sRealName = (String) linkedCadHM.get("OBJECT_NAME"); 
					String sAction 	 = (String) linkedCadHM.get("ACTION"); 
					
					sTempType = sTempType.trim();
					sRealName = sRealName.trim();
					
					boolean bFileTypeCheck = false;
					String parentRelName = cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
					String sType = "";
					String sPartFindObjId = "";
					
					String strCadObjectName = "";
					String sRevisionSeqence = "";
					String stObjectId = "";
					String sCAD_Type = "";
					String strFormat = "";
					boolean isCatiaCadModel = false;
					boolean isExistCADNotCAT = false;
					String sTempFileType = "";
					
					recordTdmxId = sTdmxId;
					recordRealName = sRealName;
					recordRevision = sRevision;
					
					/*file type 에 따라 sCAD_Type 명이 다르다.*/
					if ("CATIA Product".equals(sFileType)) {
						if ("Assembly".equals(sTempType)) {
							isCatiaCadModel = true;
							strFormat = "asm";
							sCAD_Type = "assembly";
							sType = cdmConstantsUtil.TYPE_CATPRODUCT;
						}
					}else if("AutoCAD".equals(sFileType)){
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
						}
						if ("Image Drawing".equals(sTempType)) {
							sType = "cdmImageDrawing";
						}
					}else if("CATIA Drawing".equals(sFileType)){
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
							//PDF ,ZIP 존재가능
						}
						
						if("Image Drawing".equals(sTempType)) {
							sType = "cdmImageDrawing";
							sFileType = "Image";							
						}
						
						if("V4 Model".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
							isExistCADNotCAT = true;
						}
						
						if("Drawing".equals(sTempType)){
							strFormat = "drw";
							sCAD_Type = "drawing";
							isCatiaCadModel = true;
							sType = "CATDrawing";
							
						}
						
						//Exchange 는 제외함 
					}else if("DXF".equals(sFileType)){
						sType = "cdmDXF";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
					}else if("CATIA cgm".equals(sFileType)){
						sType = "cdmCATIAcgm";
						sFileType = "CATIA cgm";
						isExistCADNotCAT = true;
					}else if("STEP".equals(sFileType)){
						sType = cdmConstantsUtil.TYPE_CDMSTEP;
						isExistCADNotCAT = true;
					}else if("CATIA Material".equals(sFileType)){
						sType = cdmConstantsUtil.TYPE_CDMCATIAMATERIAL;
						isExistCADNotCAT = true;
						bFileTypeCheck = true;
					}else if("CATIA Model".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CATPART;
							isCatiaCadModel = true;
							strFormat = "prt";
							sCAD_Type = "component";
						}
						if("V4 Model".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
							isExistCADNotCAT = true;
						}
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
						}
						
					}else if("CATIA Part".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CATPART;
							isCatiaCadModel = true;
							strFormat = "prt";
							sCAD_Type = "component";
						}
					}else if("IGES".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = "cdmIGES";
							bFileTypeCheck = true;
						}
					}else if("PDF".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
							sType = "cdmImageDrawing";
							sFileType = "Image";
						}
						if("AutoCAD".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}
					}else if("STEP".equals(sFileType)){
						sType = "cdmSTEP";
						isExistCADNotCAT = true;
					}else if("Text".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
							sType = "cdmImageDrawing";
							sFileType = "Image";
						}
					}else if("Unigraphics".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
							sType = "cdmImageDrawing";
						}
						if("UG NX Drawing".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
							isExistCADNotCAT = true;
							bFileTypeCheck = true;
						}
						if("UG NX Part".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMNXPART;
							isExistCADNotCAT = true;
							bFileTypeCheck = true;
						}
					}else if("ZIP".equals(sFileType)){
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}
					}else if("CATIA cgr".equals(sFileType)){
						sType = "cdmCATIAcgr";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
					}else if("CATIA Material".equals(sFileType)){
						sType = "cdmCATIAMaterial";
//						sFileType = "";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
						
					}else{
						
					}
					
					if (StringUtils.isEmpty(sType)) {
						// Image Drawing 파일 타입이 존재하지 않는 경우 제외
						sType = "cdmImageDrawing";
//						sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
						sFileType = "Image";
					}
					if(bFileTypeCheck){
						sTempFileType = "";
					}else{
						sTempFileType = sFileType;
					}
					
					recordType = sType;
					
					/* *********************************************************
					 * Person 정보 확인.
					 * ********************************************************* */
					boolean IsExistPerson = false; // Person 정보 확인
					
					String sIsPersonMql = MqlUtil.mqlCommand(context, "print bus Person '" + sUsers + "' - select exists dump" );
					
					if ("true".equalsIgnoreCase(sIsPersonMql)) {
						IsExistPerson = true;
						sbErrorMessage.append("X").append("\t");
					} else {
						sbErrorMessage.append("○").append("\t");
					}
					/*
					 * *********************************************************
					 *  object name 설정. sCAD_REF_FILE_NAME 데이타가
					 * 존재하지않는다면 에러 처리 .
					 * *********************************************************
					 * 
					 */
					
					strCadObjectName = sRealName;
					
					boolean bAlreadyExist = false;
					
					String strMajorObjId = "";
					String exsitMinorObjId = "";
					AttributeList majorlocalAttributeList = new AttributeList();
					AttributeList minorlocalAttributeList = new AttributeList();
					Map docAttrMap = new HashMap();
					
					
					String tempCreatedDate = "";
					if (UIUtil.isNotNullAndNotEmpty(sCreationdate) ) {
						Date createdate = new Date(sCreationdate);
						SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa", new Locale("en", "US"));
						tempCreatedDate = sdf.format(createdate);
						//12/6/2016 10:40:16 AM
					}
					
//					sRevisionSeqence = sRevision.replaceAll("\\..+", "");//major
					StringList sListRevisionSequence = new StringList();
					sListRevisionSequence = FrameworkUtil.split(sRevision, "\\..+");
					boolean bMinorRevision = false;
					
					String splitMinorRevision = "";
					if(sListRevisionSequence.size()>2){
						bMinorRevision = true;
						String sRevisionSequnceSplit = (String)sListRevisionSequence.get(2);
						Integer intergerRevisionSequence = Integer.parseInt(sRevisionSequnceSplit);
						intergerRevisionSequence = intergerRevisionSequence-1;
						splitMinorRevision = String.format("%01d", intergerRevisionSequence);
						
						sRevisionSeqence = (String)sListRevisionSequence.get(0); 
						splitMinorRevision = sRevisionSeqence+"."+splitMinorRevision;
					}else{
						sRevisionSeqence = (String)sListRevisionSequence.get(0); 
					}
					
					//에러가 났을때 같은 sTdmxId 가 존재할경우 
					if((!"New".equals(sAction) &&  strPreviousObjectTdmxId.equals(sTdmxId)) && !bStartTransaction ){
						throw new Exception("error same sTdmxId object.");
					}
					
					//sTdmxId 관련데이타가 에러 처리시 관련 sTdmxId는 다 에러나도록 처리 
//					if( !"".equals(strPreviousObjectTdmxId) && !strPreviousObjectTdmxId.equals(sTdmxId)  ){
					if( UIUtil.isNotNullAndNotEmpty(strPreviousObjectTdmxId) && !strPreviousObjectTdmxId.equals(sTdmxId) && bStartTransaction ){
						ContextUtil.commitTransaction(context);
						bEndTransaction = true;
						for (int successRow = 0; successRow < sListSuccessRowData.size(); successRow++) {
							String sSuccessRowData= (String)sListSuccessRowData.get(successRow);
							writeSuccessToFile(sSuccessRowData);
							successInt++;
						}
						sListSuccessRowData = new StringList();
						sListForRecordRowData = new StringList();
//						ContextUtil.abortTransaction(context);
					}
					
					
					if(("New".equals(sAction) && "".equals(strPreviousObjectTdmxId )) || ("New".equals(sAction) && !strPreviousObjectTdmxId.equals(sTdmxId))  ){
						ContextUtil.startTransaction(context, true);
						bStartTransaction = true;
						
					}
					
					DomainObject busDOCUMENT = new DomainObject();
					String sTempDescription = "";
					boolean checkReviseMajorExist = false; // major revise 여부확인
					if (isCatiaCadModel ) {
						/*
						 * *****************************************************
						 * REVISION 정보가 없다면 에러 처리. REVISION 설정 .
						 * 
						 * *****************************************************
						 */
						if (cdmStringUtil.isEmpty(sRevision)) {
							String errorMessage = "NOT EXIST REVISION DATA. ";
							throw new Exception(errorMessage);
						}

//						String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
						String firstMinorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
						DomainObject minorBusObject = new DomainObject();

						String sAttribute_MoveFileVersion = MCADMxUtil.getActualNameForAEFData(context, "attribute_MoveFilesToVersion");
						// original file name 과 데이타가 같다.
						String sAttribute_Title = MCADMxUtil.getActualNameForAEFData(context, "attribute_Title");
						String sAttribute_IsVersionObj = MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
						String sAttribute_IEFFileMessage = MCADMxUtil.getActualNameForAEFData(context, "attribute_IEF-FileMessageDigest");
						String sAttribute_Source = MCADMxUtil.getActualNameForAEFData(context, "attribute_Source");

						

//						boolean bBeforRevExistConnectSpecCheck = false;
						
						if (strPreviousCadName.equals(strCadObjectName) && sTdmxId.equals(strPreviousObjectTdmxId)) {
							
							if(!sType.equals(strPreviousCadType)){
								throw new Exception("not match revision Type Infomation.");
								
							}
							BusinessObject busPreviousObj = new BusinessObject(sType, strPreviousCadName, strPreviousObjectRev,  cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
							
							//
							// 현재 object는 제외하고 이전 revision 과 part 연결여부 확인 
							DomainObject preDocIdDobj = new DomainObject((String)busPreviousObj.getObjectId(context));
									
							String sConnectedPartId = "";
							String relName = "Part Specification";
							String connectType = "cdmPhantomPart,cdmMechanicalPart";
							StringList busSelect = new StringList();
							StringList relSelect = new StringList();
							busSelect.add("id");
							relSelect.add("id[connection]");
							relSelect.add("type[connection]");
							boolean isFrom = false;
							boolean isTo = true;
							String whereExpr = "from[Part Specification].to.id == '"+(String)busPreviousObj.getObjectId(context)+"'";
							MapList findMListRevisions = preDocIdDobj.getRelatedObjects(context,
																			relName,
																			connectType,
																			busSelect,
																			relSelect,
																			isTo,
																			isFrom,
																			(short)1,
																			whereExpr,
																			null);

									if(findMListRevisions.size()>0){
										for (Iterator connectPreObj = findMListRevisions.iterator(); connectPreObj.hasNext();) {
											Map connectPreObjMap = (Map) connectPreObj.next();
											String id = (String)connectPreObjMap.get("id");
											String relId = (String)connectPreObjMap.get("id[connection]");
											String relType = (String)connectPreObjMap.get("type[connection]");
											Relationship rel = new Relationship(relId);
								            rel.open(context);
								            DomainObject toDo = new DomainObject(rel.getTo());
								            rel.close(context);
								            String toDocObjId = (String)toDo.getObjectId(context);
								            
								            if (cdmStringUtil.isNotEmpty(sRelated_PartName) && cdmStringUtil.isNotEmpty(sRelatedPartRev)) {
												BusinessObject busPart = new BusinessObject("cdmMechanicalPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
												if(!busPart.exists(context)){
													busPart = new BusinessObject("cdmPhantomPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
												}
								            
									            if(toDocObjId.equals((String)busPreviousObj.getObjectId(context)) && "Part Specification".equals(relType) && busPart.exists(context) && busPart.getObjectId(context).equals(id)){
									            	DomainRelationship dObjRel = new DomainRelationship();
									            	dObjRel.disconnect(context, relId);
									            }
								            }
										}
									}
							//데이타를 minor 을 revise 하는경우 존재 혹은 major을 revise 하는경우
							if("Revise".equals(sAction)){		
								BusinessObject busReviseMajorObject = new BusinessObject();
//								busReviseMajorObject = busPreviousObj.revise(context, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
								String reviseMajorId = "";
								BusinessObject busReviseCheckMajorObject = new BusinessObject(sType, strPreviousCadName, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
								if(busReviseCheckMajorObject.exists(context)){
									checkReviseMajorExist = true;
//									busDOCUMENT.setId(busPreviousObj.getObjectId(context));
									busDOCUMENT.setId(busReviseCheckMajorObject.getObjectId(context));
								}else{
//									reviseMajorId = generalUtil.createAndConnectToMajorObject(context, sRevisionSeqence, false, new BusinessObject(busPreviousObj.getObjectId(context)), majorPolicy, true, false);
									ReviseParameters reviseParameters = new ReviseParameters();
									reviseParameters.setNewvault(cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
									reviseParameters.setNewrev(sRevisionSeqence);
									
									BusinessObject busRevise = (new BusinessObject(busPreviousObj.getObjectId(context))).revise(context, reviseParameters);
									reviseMajorId = busRevise.getObjectId(context);
									busDOCUMENT.setId(reviseMajorId);
//									System.out.println("for TEST => " + busDOCUMENT.getName(context) +"   revision => "+busDOCUMENT.getRevision(context) +" bus Major => "+busDOCUMENT.getInfo(context, "first") +" "+busDOCUMENT.getInfo(context, "last.revision"));
								}
							}else if("Minor".equals(sAction)){
								busDOCUMENT.setId(busPreviousObj.getObjectId(context));
								
							}

						}else{
							busDOCUMENT.createObject(context, sType, strCadObjectName, sRevisionSeqence, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						}
						strPreviousCadType = sType;
						strPreviousCadName = strCadObjectName;
						strPreviousObjectRev = sRevisionSeqence;
						strPreviousObjectTdmxId = sTdmxId;
						 
						stObjectId = busDOCUMENT.getObjectId();
							
						//create trigger start  CATPART 
//						String objId = stObjectId;
//						String autoPromote = MqlUtil.mqlCommand(context, "list expression $1 select $2 dump",
//								"VPLMAutoPromoteNextMinorRev", "value");
//						if ("true".equalsIgnoreCase(autoPromote) && !revisionCheck) {
//							String DESIGN_TEAM_DEF = MCADMxUtil.getActualNameForAEFData(context, "policy_DesignTEAMDefinition");
//							String busPolicy = cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION;
//							if (DESIGN_TEAM_DEF.equals(busPolicy)) {
//								BusinessObject obj = new BusinessObject(objId);
//
//								String Args[] = new String[2];
//								Args[0] = "IsDECAutoPromoteOnCreate";
//								Args[1] = "true";
//								mxUtil.executeMQL(context, "set env $1 $2", Args);
//
//								obj.promote(context);
//							}
//						}
						//create trigger end  CATPART 

						/* 속성 입력 start */
						AttributeList localAttributeList = new AttributeList();
						localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION), sDetailedDescription));
						localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER), s3dCADIdentifier));
						localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE), sDocumentType));
						localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_PART_DRAWING_NO), sRelated_PartName));
						if ("CATDrawing".equals(sType)) {
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE), sScale));
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE), sPageSize));
						}

						if ((cdmConstantsUtil.TYPE_CATPART).equals(sType)) {
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS), sMassEstimated));
						}

						if ((cdmConstantsUtil.TYPE_CATPART).equals(sType) || (cdmConstantsUtil.TYPE_CATPRODUCT).equals(sType)) {
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE), sSurfaceArea));
						}


						/*
						 * MAJOR VERSION OBJECT ATTRIBUTE[ORIGINATOR],OWNER
						 * 정보 추가, PERSON 정보가 존재하지않는다면 제외 였으나
						 * organization,owner,project,organization 정보를
						 * admin_platform의 정보로 구성 (10.31.16) originator 는 받은 데이타에서 처리
						 * 
						 * 11/23 access 의 project와 organization은 데이타는 project열의 정보로 구성된다. 
						 * access 의 project 과 organization의 name룰은 다음 예와 같다.
						 * ex :
						 * project 열의 정보 : CAPLIPER - HD
						 * project : CAPLIPER
						 * 
						 */
						
						strMajorObjId= busDOCUMENT.getObjectId(context);
//						if(!"Minor".equals(sAction) || ("Minor".equals(sAction) && !bMinorRevision)){
							if(IsExistPerson){
								busDOCUMENT.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sUsers);
								busDOCUMENT.setOwner(context, sUsers);
							}
							if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
								MqlUtil.mqlCommand(context, "mod bus $1 originated $2", strMajorObjId, tempCreatedDate);
							}
//						}
						/* 
						 * MAJOR VERSION OBJECT ATTRIBUTE, DESCRIPTION 설정 
						 * 에러의 소지가 있어 트랜잭션이 없는곳으로 ATTRIBUTE 설정 ( 
						 * */
//						if(!"Minor".equals(sAction) || ("Minor".equals(sAction) && !bMinorRevision)){	 
							majorlocalAttributeList= localAttributeList;
//						}
						AttributeList tempAttributeList = new AttributeList();
						
						tempAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION), "Y"));
						//CAT 파일인 경우 (CATProduct,CATPart,CATDrawing만 해당)
						
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_Title), sCadRefFileName));
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IEFFileMessage), ""));
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_Source), sourceInfo));
						tempAttributeList.addElement(new Attribute(new AttributeType(attributeCADType), sCAD_Type));
						
						tempAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID), sTdmxId));
						tempAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE), sTempFileType));
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "True"));
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IsVersionObj), "False"));
						tempAttributeList.addElement(new Attribute(new AttributeType("cdmRevisionCheckInM"),sRevision ));
						
						if (cdmStringUtil.isNotEmpty(sDescription) && (!"Minor".equals(sAction) || ("Minor".equals(sAction) && !bMinorRevision) )) {
							sTempDescription = sDescription;
						}else{
							sTempDescription = "";
						}
//						if(!"Minor".equals(sAction) || ("Minor".equals(sAction) && !bMinorRevision) ){
							busDOCUMENT.setAttributes(context, tempAttributeList);
//						}
						
						
						/*
						 * RELATIONSHIP PART SPECIFICATION 연결 CAD NAME 값과
						 * PART 의 명이 일치하지않을때에는 RELATIONSHIP으로 연결되지않고 CAD
						 * object의 ATTRIBUTE 속성 [cdmPartDrawingNo]에만 데이타를
						 * 넣는다.
						 */
						
						/* MINOR VERSION */
						if(!"Minor".equals(sAction)){
//							String stVersionId = generalUtil.createAndConnectToMinorObject(context, minorRevString, true, busDOCUMENT, globalConfigObject, true, false, minorPolicy); // [NDM]
							String stVersionId = "";
//							String checkLatestMinorId = "";s
//							checkLatestMinorId = mxUtil.getActiveVersionObjectFromMinor(context, busDOCUMENT.getObjectId(context));
//							checkLatestMinorId = busDOCUMENT.getInfo(context, "from[Active Version].to.id");
							
							if(bMinorRevision ){
								stVersionId = generalUtil.createAndConnectToMinorObject(context,splitMinorRevision, true, busDOCUMENT, globalConfigObject, true, false, minorPolicy); // [NDM]
//							}else if(!bMinorRevision && UIUtil.isNullOrEmpty(checkLatestMinorId)){
							}else {
								stVersionId = generalUtil.createAndConnectToMinorObject(context,firstMinorRevString, true, busDOCUMENT, globalConfigObject, true, false, minorPolicy); // [NDM]
							}
							minorBusObject.setId(stVersionId);
						}else{
							String stNextVersionId = "";
							
							if("Minor".equals(sAction) && !bMinorRevision){
								String checkNextForLatestMinorId = "";
								checkNextForLatestMinorId = mxUtil.getLatestMinorID(context,new BusinessObject(busDOCUMENT.getObjectId(context)));
								
								DomainObject latestMinorDobj = new DomainObject(checkNextForLatestMinorId);
								String lastMinorRev = (String)latestMinorDobj.getInfo(context, "last.revision");
//								System.out.println("checkNextForLatestMinorId ===> "+checkNextForLatestMinorId);
//								System.out.println("lastMinorRev ===> "+lastMinorRev);
								String splitNextMinorRev = "";
								StringList sListSplitLastMinorRev = new StringList();
								sListSplitLastMinorRev = FrameworkUtil.split(lastMinorRev, "\\..+");
								
								if(sListSplitLastMinorRev.size()>2){
									String intergerMinorRev = (String)sListSplitLastMinorRev.get(2);
									int tempMinoreRev = Integer.parseInt(intergerMinorRev);
									tempMinoreRev = tempMinoreRev+1;
									String majorRev = (String)sListSplitLastMinorRev.get(0);
									splitNextMinorRev = majorRev.trim()+"."+tempMinoreRev;
								}
								
								/*disconnect latest minor version*/
								if(mxUtil.doesRelationExist(context, busDOCUMENT.getObjectId(context), checkNextForLatestMinorId, relLatestVerion)){
									mxUtil.disconnectBusObjects(context, busDOCUMENT.getObjectId(context),  checkNextForLatestMinorId,relLatestVerion, true);
								}
								if(mxUtil.doesRelationExist(context, busDOCUMENT.getObjectId(context), checkNextForLatestMinorId, relLatestVerion)){
									mxUtil.disconnectBusObjects(context, busDOCUMENT.getObjectId(context), checkNextForLatestMinorId, relActiveVerion, true);
								}
								
								/*revise minor version , connect*/ 
								ReviseParameters localReviseParameters = new ReviseParameters();
								localReviseParameters.setNewvault(cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
								localReviseParameters.setNewrev(splitNextMinorRev);
								
								BusinessObject latestMinorBus = new BusinessObject(checkNextForLatestMinorId);
								BusinessObject nextVersionBus = latestMinorBus.revise(context, localReviseParameters);
								stNextVersionId = nextVersionBus.getObjectId(context);
								
//								String str9 = "relationship_VersionOf";
//								String relVersionOf = MCADMxUtil.getActualNameForAEFData(context, str9);
								 
//								mxUtil.connectBusObjects(context, busDOCUMENT.getObjectId(context), (String)stNextVersionId, relVersionOf, false, null);
//								mxUtil.connectBusObjects(context,  busDOCUMENT.getObjectId(context), (String)stNextVersionId, relLatestVerion, true, null);
//								mxUtil.connectBusObjects(context,  busDOCUMENT.getObjectId(context), (String)stNextVersionId, relActiveVerion, true, null);
							}else{
								String checkNextForLatestMinorId = "";
								checkNextForLatestMinorId = mxUtil.getLatestMinorID(context,new BusinessObject(busDOCUMENT.getObjectId(context)));
								BusinessObject latestMinorBus = new BusinessObject(checkNextForLatestMinorId);
								ReviseParameters localReviseParameters = new ReviseParameters();
								localReviseParameters.setNewvault(cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
								localReviseParameters.setNewrev(splitMinorRevision);
								
								/*disconnect before minor version*/
								
								if(mxUtil.doesRelationExist(context, busDOCUMENT.getObjectId(context), checkNextForLatestMinorId, relLatestVerion)){
									mxUtil.disconnectBusObjects(context, busDOCUMENT.getObjectId(context),  checkNextForLatestMinorId,relLatestVerion, true);
								}
								
//								String relActiveVerion  = cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION;
								if(mxUtil.doesRelationExist(context, busDOCUMENT.getObjectId(context), checkNextForLatestMinorId, relActiveVerion)){
									mxUtil.disconnectBusObjects(context, busDOCUMENT.getObjectId(context), checkNextForLatestMinorId, relActiveVerion, true);
								}
								
								DomainObject testTemp = new DomainObject(checkNextForLatestMinorId);
								StringList sListrelTemp = new StringList();
								
								sListrelTemp = testTemp.getInfoList(context, "relationship");
//								System.out.println("s===========================> "+sListrelTemp.toString());
								/*revise minor version , connect*/ 
								BusinessObject nextVersionBus = latestMinorBus.revise(context, localReviseParameters);
								stNextVersionId = nextVersionBus.getObjectId(context);
								String str9 = "relationship_VersionOf";
								String relVersionOf = MCADMxUtil.getActualNameForAEFData(context, str9);
								 
//								mxUtil.connectBusObjects(context, busDOCUMENT.getObjectId(context), (String)stNextVersionId, relVersionOf, false, null);
//								mxUtil.connectBusObjects(context,  busDOCUMENT.getObjectId(context), (String)stNextVersionId, relLatestVerion, true, null);
//								mxUtil.connectBusObjects(context,  busDOCUMENT.getObjectId(context), (String)stNextVersionId, relActiveVerion, true, null);
								
								
							}
							minorBusObject.setId(stNextVersionId);
						}
						
						tempAttributeList.remove(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "True"));
						tempAttributeList.remove(new Attribute(new AttributeType(sAttribute_IsVersionObj), "False"));
						tempAttributeList.remove(new Attribute(new AttributeType("cdmRevisionCheckInM"),sRevision ));
						
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "False"));
						tempAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IsVersionObj), "True"));
						
						minorlocalAttributeList= localAttributeList;
						//에러 소지가 있어 트랜잭션 없는곳에서 데이타 처리 

						if (cdmStringUtil.isNotEmpty(sDescription)) {
							minorBusObject.setDescription(context, sDescription);
						}
//						StringList sListTestRel = new StringList();
//						sListTestRel= minorBusObject.getInfoList(context, "relationship");
//						
						
//						System.out.println("minorBusObject ----> "+minorBusObject.getId(context) + "  first --> "+minorBusObject.getInfo(context, "first") +" last --> "+minorBusObject.getInfo(context, "last.revision"));
						minorBusObject.setAttributes(context, tempAttributeList);	
						
						String minorBusId = minorBusObject.getId(context);
						exsitMinorObjId = minorBusId;
						if(IsExistPerson){
							minorBusObject.setOwner(context, sUsers);
							minorBusObject.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sUsers);
						}
						if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate)){
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2", minorBusId, tempCreatedDate);
						}
						
						if(UIUtil.isNotNullAndNotEmpty(sState) && "Checked In".equals(sState) && (!"Minor".equals(sAction) || (!bMinorRevision && "Minor".equals(sAction) )) ){
							busDOCUMENT.setState(context, "IN_WORK");
						}else if("Released".equals(sState) && (!"Minor".equals(sAction) || (!bMinorRevision && "Minor".equals(sAction) ))){
							busDOCUMENT.setState(context, "RELEASED");
						}
					}else {
						/*
						 * Document 타입일 경우 Document 의 경우 'Document Release'
						 * policy 인 object 에 모든 파일이 저장되며 revision의 object의 경우에도
						 * 파일이 이동하지않고 변경한 데이타들이 저장 파일 이 추가 될
						 * cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성
						 * 추가 Originator은 user 정보로 변경 Person 정보가 enovia에 Person
						 * 정보에 있을시 Owner 추가. 
						 */

						String strPolicDoc_Release = "Document Release";
						String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;

						if (sCadRefFileName == null || "".equals(sCadRefFileName) || "null".equals(sCadRefFileName)) {
							sCadRefFileName = isVaildNullData(sCadRefFileName);
						}

						CommonDocument doMajorObject = (CommonDocument) DomainObject.newInstance(context, CommonDocument.TYPE_DOCUMENTS);
						DomainObject parentObject = null;
						if (sPartFindObjId != null && !"".equals(sPartFindObjId) && !"null".equals(sPartFindObjId)) {
							parentObject = DomainObject.newInstance(context, sPartFindObjId);
						}
						// MIGRATION DATA을 위해 속성 추가 AUTOCAD, ..
						HashMap<String, Object> mAttrMap = new HashMap<String, Object>();
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE, sPageSize);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE, sScale);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_TITLE_TYPE, sTitleType);
						
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION, sDetailedDescription);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER, s3dCADIdentifier);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE, sTempFileType);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE, sDocumentType);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS, sMassEstimated);
						mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE, sSurfaceArea);
						
						if(!"Minor".equals(sAction) || (!bMinorRevision && "Minor".equals(sAction) )){
							docAttrMap = mAttrMap;
						}
						DomainObject dObj = new DomainObject();
//						boolean checkReviseMajorExist = false;  
						if (strPreviousCadName.equals(strCadObjectName)  && sTdmxId.equals(strPreviousObjectTdmxId)) {
							
							if(!sType.equals(strPreviousCadType)){
								throw new Exception("not match revision Type Infomation.");
							}

							BusinessObject busPreviousObj = new BusinessObject(sType, strPreviousCadName, strPreviousObjectRev,  cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
							
							//
							String preDocId = (String)busPreviousObj.getObjectId(context);
							DomainObject preDocIdDobj = new DomainObject(preDocId);
							
							String sConnectedPartId = "";
							String relName = "Part Specification";
							String connectType = "cdmPhantomPart,cdmMechanicalPart";
							StringList busSelect = new StringList();
							StringList relSelect = new StringList();
							busSelect.add("id");
							relSelect.add("id[connection]");
							relSelect.add("type[connection]");
							boolean isFrom = false;
							boolean isTo = true;
							String whereExpr = "from[Part Specification].to.id == '"+(String)busPreviousObj.getObjectId(context)+"'";
							MapList findMListRevisions = preDocIdDobj.getRelatedObjects(context,
																	relName,
																	connectType,
																	busSelect,
																	relSelect,
																	isTo,
																	isFrom,
																	(short)1,
																	whereExpr,
																	null);

							if(findMListRevisions.size()>0){
								for (Iterator connectPreObj = findMListRevisions.iterator(); connectPreObj.hasNext();) {
									Map connectPreObjMap = (Map) connectPreObj.next();
									String relId = (String)connectPreObjMap.get("id[connection]");
									String relType = (String)connectPreObjMap.get("type[connection]");
									String id = (String)connectPreObjMap.get("id");
									Relationship rel = new Relationship(relId);
						            rel.open(context);
						            DomainObject toDo = new DomainObject(rel.getTo());
						            rel.close(context);
						            String toDocObjId = (String)toDo.getObjectId(context);
						            //
						            if (cdmStringUtil.isNotEmpty(sRelated_PartName) && cdmStringUtil.isNotEmpty(sRelatedPartRev)) {
										BusinessObject busPart = new BusinessObject("cdmMechanicalPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
										if(!busPart.exists(context)){
											busPart = new BusinessObject("cdmPhantomPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
										}
						            
							            if(toDocObjId.equals((String)busPreviousObj.getObjectId(context)) && "Part Specification".equals(relType) && busPart.exists(context) && busPart.getObjectId(context).equals(id)){
							            	DomainRelationship dObjRel = new DomainRelationship();
							            	dObjRel.disconnect(context, relId);
							            }
						            }
						            //
								}
							}
							//
							
							CommonDocument localCommonDocument = new CommonDocument(busPreviousObj.getObjectId(context));
							if("Revise".equals(sAction)){		
								// object 존재확인 있으면 속성및 attribute 추가 없으면 revise (revision 정보가 .를 가지고 있는 경우 와 없는경우 나누어서 속성 입력 차이 발생함)  
								
								BusinessObject busReviseCheckObj = new BusinessObject(sType, strPreviousCadName, sRevisionSeqence,  cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
								if(busReviseCheckObj.exists(context)){
									checkReviseMajorExist = true;
									dObj.setId(busReviseCheckObj.getObjectId(context));
								}else{
									
									BusinessObject reviseBus = localCommonDocument.revise(context, sRevisionSeqence, false);
									dObj.setId(reviseBus.getObjectId(context));
								}
									
							}else if("Minor".equals(sAction)){
								dObj.setId(localCommonDocument.getObjectId(context));
							}
							localCommonDocument.close(context);
						} else {
							dObj.createObject(context, sType, strCadObjectName, sRevisionSeqence, strPolicDoc_Release, vault);
						}
						strPreviousCadType = sType;
						strPreviousCadName = strCadObjectName;
						strPreviousObjectRev = sRevisionSeqence;
						strPreviousObjectTdmxId = sTdmxId;
						
						doMajorObject = new CommonDocument(dObj.getId(context));
						strMajorObjId = doMajorObject.getId(context);
						
//						if (cdmStringUtil.isNotEmpty(sDescription) &&  (!"Minor".equals(sAction) || (!bMinorRevision && "Minor".equals(sAction) ))) {
						if (cdmStringUtil.isNotEmpty(sDescription) ) {
							sTempDescription = sDescription;
						}else{
							sTempDescription = "";
						}
						HashMap tempAttrMap = new HashMap();
						
						tempAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, "Y");
						tempAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID, sTdmxId);
						tempAttrMap.put(cdmConstantsUtil.ATTRIBUTE_TITLE, sCadRefFileName);
						tempAttrMap.put("cdmRevisionCheckInM",sRevision );

						if(!"Minor".equals(sAction) || (!bMinorRevision && "Minor".equals(sAction) )){
							dObj.setAttributeValues(context, tempAttrMap);
						}

						String sVersionDescription = null;
						Map attrMapOfVersion = new HashMap();
						
						String strMinorVersionId = "";
						if(!"Minor".equals(sAction)){
							 strMinorVersionId = doMajorObject.createVersion(context, sVersionDescription, strCadObjectName, attrMapOfVersion);
							exsitMinorObjId = strMinorVersionId;
						}else{
							
							String preMinorVersionId = doMajorObject.getInfo(context, "from[Active Version].to.id");
							String sVersionConnection = doMajorObject.getInfo(context, "from[Active Version].id");
							String sLatestVersionConnection = doMajorObject.getInfo(context, "from[Latest Version].id");
							
							CommonDocument  minorVersionCDoc = new CommonDocument(preMinorVersionId);
							CommonDocument nextMinorVersionCDoc = new CommonDocument(minorVersionCDoc.reviseObject(context, false));
							
//							
							String nextMinorId = nextMinorVersionCDoc.getObjectId(context);
							DomainRelationship doRel = new DomainRelationship();
							doRel.setToObject(context,sVersionConnection , new DomainObject(nextMinorId));
							doRel.setToObject(context, sLatestVersionConnection, new DomainObject(nextMinorId));
//							String str9 = "mod connection $1 from $2";
//							
//							 MqlUtil.mqlCommand(context, str9, new String[] { sVersionConnection, nextMinorId });
//							 
//							 String sLatestVersionConnection = doMajorObject.getInfo(context, "from[Latest Version].id");
//							
//							 MqlUtil.mqlCommand(context, str9, new String[] { sLatestVersionConnection, nextMinorId });
							 strMinorVersionId = nextMinorVersionCDoc.getId(context);
							 
							 exsitMinorObjId = strMinorVersionId;
							 //latest version 연결?확인 
						}
						
						if(UIUtil.isNotNullAndNotEmpty(tempCreatedDate) && !"".equals(strMinorVersionId) ){
							if(!"Minor".equals(sAction) || (!bMinorRevision && "Minor".equals(sAction) )){
								MqlUtil.mqlCommand(context, "mod bus $1 originated $2",  doMajorObject.getId(context), tempCreatedDate);
							}
							MqlUtil.mqlCommand(context, "mod bus $1 originated $2", strMinorVersionId, tempCreatedDate);
						}
						
						DomainObject dObjVersion = DomainObject.newInstance(context, strMinorVersionId);
						dObjVersion.setAttributeValues(context, tempAttrMap);
						
						/* if person not exist, exception */
						if (IsExistPerson) {
							if(!"Minor".equals(sAction) || (!bMinorRevision && "Minor".equals(sAction) )){
								doMajorObject.setOwner(context, sUsers);
								doMajorObject.setAttributeValue(context,cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sUsers);
							}
							dObjVersion.setOwner(context, sUsers);
							dObjVersion.setAttributeValue(context,cdmConstantsUtil.ATTRIBUTE_ORIGINATOR, sUsers);
							sbErrorMessage.append("X").append("\t");
							
						} else {
							sbErrorMessage.append("○").append("\t");
						}

						// state 정보필요 12/19
						if(UIUtil.isNotNullAndNotEmpty(sState) && "Checked In".equals(sState) && (!"Minor".equals(sAction) || (!bMinorRevision && "Minor".equals(sAction) ))){
							doMajorObject.setState(context, "IN_WORK");
						}else if(UIUtil.isNotNullAndNotEmpty(sState) && "Released".equals(sState) && !"Minor".equals(sAction) || (!bMinorRevision && "Minor".equals(sAction) )){
							doMajorObject.setState(context, "RELEASED");
						}
						
						busDOCUMENT.setId(strMajorObjId);
					}
					

					/*  *********************************************************
					 * 	존재한다면 연결 연결 정보는 Part Specification 으로 연결
					 * **********************************************************/
					String currentConncetedPart = "";
					
					if (cdmStringUtil.isNotEmpty(sRelated_PartName) && cdmStringUtil.isNotEmpty(sRelatedPartRev)) {

						BusinessObject busPart = new BusinessObject("cdmMechanicalPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						if(!busPart.exists(context)){
							busPart = new BusinessObject("cdmPhantomPart",sRelated_PartName,sRelatedPartRev,cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						}
						
						if(busPart != null && busPart.exists(context)){
							currentConncetedPart = busPart.getObjectId(context);
							DomainRelationship connectInfoDoc = new DomainRelationship();
							
							DomainObject docDObj = new DomainObject(busDOCUMENT.getObjectId(context));

				           StringList objectSelects = new StringList();
				           objectSelects.add("id");
							
				           connectInfoDoc = DomainRelationship.connect(context, new DomainObject(busPart), DomainConstants.RELATIONSHIP_PART_SPECIFICATION, new DomainObject(busDOCUMENT));
				           connectInfoDoc.setAttributeValue(context, "CAD Object Name", strCadObjectName );
						
						}
						
					}
					//part 존재상관 없이 part 데이타가 존재하면 기록 Documnet Relase policy로 존재하는 경우중 nxpart auto 와 CAT 
					if(cdmStringUtil.isNotEmpty(sRelated_PartName)){
						String partType = (String)busDOCUMENT.getInfo(context, "type");
						if(("cdmAutoCAD".equals(partType) || "cdmNXDrawing".equals(partType) )|| "CATDrawing".equals(partType) ){
						AttributeList tempRelAttributeList = new AttributeList();
						
				        tempRelAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DRAWING_NO), sRelated_PartName));
				        busDOCUMENT.setAttributes(context, tempRelAttributeList);
						}
					}
//					ContextUtil.commitTransaction(context);
//					ContextUtil.abortTransaction(context); //test 
					
					if(!bAlreadyExist){
						/*
						 * *********************************************************
						 * project organization
						 * *********************************************************
						 * 
						 */
						
//						try {
							
							//
							boolean checkOwner = false;
							boolean checkOrg = false;
							boolean checkProject = false;
							String sOwner = "";
							String findOrg = "list role $1 select $2 dump;";
							if (cdmStringUtil.isNotEmpty(sProdGroup) || cdmStringUtil.isNotEmpty(sCustVehicle)) {
								String str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sCustVehicle, "isanorg" });
								if ("TRUE".equalsIgnoreCase(str2)) {
									findOrg = "list role $1 select $2 dump;";
									checkOrg = true;
									str2 = MqlUtil.mqlCommand(context, findOrg, true, new String[] { sProdGroup, "isaproject" });
									if ("TRUE".equalsIgnoreCase(str2)) {
										checkProject = true;
									}
								}
								DomainObject dMajor = new DomainObject(strMajorObjId);
								DomainObject dMinor = new DomainObject(exsitMinorObjId);
								if(!"Minor".equals(sAction) || ("Minor".equals(sAction) &&  !bMinorRevision)){
//									dMajor.setOwnership(context, checkOwner, checkOrg, checkProject, sOwner, sCustVehicle, sProdGroup);
//									dMinor.setOwnership(context, checkOwner, checkOrg, checkProject, sOwner, sCustVehicle, sProdGroup);
									if(checkOrg && checkProject){
										MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", strMajorObjId, sProdGroup, sCustVehicle);
										MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", exsitMinorObjId, sProdGroup, sCustVehicle);
									}
								}else if("Minor".equals(sAction)){
									if(checkOrg && checkProject){
										MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", exsitMinorObjId, sProdGroup, sCustVehicle);
//									dMinor.setOwnership(context, checkOwner, checkOrg, checkProject, sOwner, sCustVehicle, sProdGroup);
									}
								}
								if(checkOrg && checkProject){
									sbErrorMessage.append("X").append("\t");
									sbErrorMessage.append("X").append("\t");
								}else if(!checkOrg && checkProject){
									sbErrorMessage.append(sCustVehicle).append("\t");
									sbErrorMessage.append("X").append("\t");
								}else if(checkOrg && !checkProject){
									sbErrorMessage.append("X").append("\t");
									sbErrorMessage.append(sProdGroup).append("\t");
								}
							}else{
								sbErrorMessage.append(sCustVehicle).append("\t");
								sbErrorMessage.append(sProdGroup).append("\t");
							}
							//
							
//							
//							if(StringUtils.isNotEmpty(sProdGroup) && StringUtils.isNotEmpty(sCustVehicle) && !" - ".equals(sCustVehicle) && !"Minor".equals(sAction)		) {
////								MqlUtil.mqlCommand(context, "Trigger Off");
//								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3",strMajorObjId , sProdGroup, sCustVehicle);
//								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", exsitMinorObjId, sProdGroup, sCustVehicle);
////								MqlUtil.mqlCommand(context, "Trigger On");
//							}else if(StringUtils.isNotEmpty(sProdGroup) && StringUtils.isNotEmpty(sCustVehicle) && !" - ".equals(sCustVehicle) && "Minor".equals(sAction)	){
//								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", exsitMinorObjId, sProdGroup, sCustVehicle);
//							}
//							
//						} catch (Exception e) {
//							sbErrorMessage.append(sProdGroup).append("\t").append(sCustVehicle).append("\t");
//						}
						
						if (cdmStringUtil.isNotEmpty(strMajorObjId)) {
							
							DomainObject dMajorD = new DomainObject(strMajorObjId);
							DomainObject dMinorD = new DomainObject(exsitMinorObjId);
								
							dMajorD.setDescription(context, sTempDescription);
							if(isCatiaCadModel){
								dMajorD.setAttributes(context, majorlocalAttributeList);
								dMinorD.setAttributes(context, minorlocalAttributeList);
							}else{
								dMajorD.setAttributeValues(context, docAttrMap);
							}
							
							
						}
						// part spec relationship은 1:1 관계이며 가져온 데이타 기준 으로 이외에 commit 실행 되어 revise 로 생성된 object 중 Part Specification 연결이 추가로 된부분을 disconnect 한다.
						if (cdmStringUtil.isNotEmpty(strMajorObjId)) {
//							try{
								StringList sListPartSpectRelId = new StringList();
								DomainObject dMajorD = new DomainObject(strMajorObjId);
								sListPartSpectRelId = dMajorD.getInfoList(context, "to[Part Specification].id");
								
								
								for (Iterator iterPartSpecRel = sListPartSpectRelId.iterator(); iterPartSpecRel.hasNext();) {
									String sPartSpecForRelId = (String) iterPartSpecRel.next();
									DomainRelationship partSpecRel = new DomainRelationship(sPartSpecForRelId);
									partSpecRel.open(context);
									BusinessObject fromBus = new BusinessObject();
									fromBus = partSpecRel.getFrom();
									partSpecRel.close(context);
									String sPartSpecForFromPartId =  fromBus.getObjectId(context);
									if((UIUtil.isNotNullAndNotEmpty(currentConncetedPart) && !currentConncetedPart.equals(sPartSpecForFromPartId) ) || (UIUtil.isNullOrEmpty(currentConncetedPart)) ){
										DomainRelationship.disconnect(context, sPartSpecForRelId);
									}
								}
								
//							}catch(Exception e3){
//								e3.printStackTrace();
//								sbErrorMessage.append("can not disconnect part specificaion before revision. \t");
//							}
						
						}
						sListForRecordRowData.add(sReadData);
						sListSuccessRowData.add(cdmCommonExcel.getTimeStamp2() +"\t"+ recordRowNum+"\t"+sType+"\t" +strCadObjectName +"\t"+sRevision+"\t"+sbErrorMessage.toString());
//						
						if(lintCountInteger == readCount && bStartTransaction){
							ContextUtil.commitTransaction(context);
//								bEndTransaction = true;
								for (int successRow = 0; successRow < sListSuccessRowData.size(); successRow++) {
									String sSuccessRowData= (String)sListSuccessRowData.get(successRow);
									writeSuccessToFile(sSuccessRowData);
									successInt++;
								}
								sListSuccessRowData = new StringList();
						}
//						writeSuccessToFile(cdmCommonExcel.getTimeStamp2() +"\t"+ recordRowNum+"\t"+sType+"\t" +strCadObjectName +"\t"+sRevisionSeqence+"\t"+sbErrorMessage.toString());
					}
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					bStartTransaction = false;
					
					strPreviousCadType = recordType;
					strPreviousCadName = recordRealName;
					strPreviousObjectTdmxId = recordTdmxId;
					
//					writeErrorToFile("LineNum(#) \t"+recordRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " );
//					exception.printStackTrace(errorStream);
					String message = exception.getMessage();
					
					for(int failCnt = 0;failCnt<sListForRecordRowData.size();failCnt++){
						String sFailRecordRowData = (String)sListForRecordRowData.get(failCnt);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"5" +"\t"+sFailRecordRowData);
						failInt++;
					}
					
//					if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not a valid type or filetype.")){
//						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"1" +"\t"+sReadData);	
//					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not a valid sProdGroup or sCustVehicle.")){
//						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"2" +"\t"+sReadData);	
//					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not match revision Type Infomation.")){
//						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3" +"\t"+sReadData);
//					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("error same sTdmxId object.")){
//						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"9" +"\t"+sReadData);
//						failInt++;
//					}
//					else{
					
					if(!sListForRecordRowData.contains(sReadData)){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t"+sReadData);
						failInt++;
					}
					
					
					if(sListForRecordRowData.contains(sReadData)){
						writeErrorToFile("LineNum(#) \t"+recordRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " );
						exception.printStackTrace(errorStream);
						writeMessageToConsole(cdmCommonExcel.getTimeStamp2()+"\t"+recordRowNum+"\t "+ recordTdmxId +" \t "+recordRevision+ " \t "+exception.getMessage());
					}
					
					
					if(!sListForRecordRowData.contains(sReadData)){
						int rowRecord = 0;
						if(UIUtil.isNotNullAndNotEmpty(recordRowNum)){
							rowRecord = Integer.parseInt(recordRowNum) ;
							rowRecord= rowRecord-1;
						}
						
//						writeErrorToFile("LineNum(#) \t"+rowRecord + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " );
//						writeMessageToConsole(cdmCommonExcel.getTimeStamp2()+"\t"+recordRowNum+"\t "+ recordTdmxId +" \t "+recordRevision+ " \t "+exception.getMessage());	
						for(int failCnt = 0;failCnt<sListForRecordRowData.size();failCnt++){
							Object sErrorRecordRowData = (Object)sListForRecordRowData.get(failCnt);
							writeErrorToFile("LineNum(#) \t"+sErrorRecordRowData );
							writeMessageToConsole(cdmCommonExcel.getTimeStamp2()+"\t "+"5"+"\t"+sErrorRecordRowData+" \t "+exception.getMessage());
								
						}
						exception.printStackTrace(errorStream);
						writeErrorToFile("LineNum(#) \t"+recordRowNum + "\t "+" not wrong \t"+cdmCommonExcel.getTimeStamp2()+"\t " );
						writeMessageToConsole(cdmCommonExcel.getTimeStamp2()+"\t "+"0"+"\t"+recordRowNum+"\t "+ recordTdmxId +" \t "+recordRevision+ " \t "+exception.getMessage());
					}
					
					if(sListForRecordRowData.size() ==0){
						writeErrorToFile("LineNum(#) \t"+recordRowNum + "\t"+cdmCommonExcel.getTimeStamp2()+"\t " );
						exception.printStackTrace(errorStream);
					}
//					}
//					writeMessageToConsole(cdmCommonExcel.getTimeStamp2()+"\t"+recordRowNum+"\t "+ recordTdmxId +" \t "+recordRevision+ " \t "+exception.getMessage());
					sListForRecordRowData = new StringList();

				}finally{
					
					
					MqlUtil.mqlCommand(context, "history on");
				}

			}
//			
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        File CAD Migration COMPLETED.                    ");
			writeMessageToConsole("====================================================================================\n");

		} catch (Exception exception) {

			writeMessageToConsole("LINE NUMBER \t "+recordRowNum+"\t"+recordTdmxId+"\t"+exception.getMessage());
			exception.printStackTrace(errorStream);
		} finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms        \n");
			writeMessageToConsole("End Time :("+cdmCommonExcel.getTimeStamp2() +") total Count:("+(lineNumber-1)+")  Success Count:("+successInt+")   Fail Count: ("+failInt+") already Count: ("+alreadyInt+")  notMatchType Count: ("+notMatchTypeCount+")" );
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			if(triggerCheck){
				MqlUtil.mqlCommand(context, "Trigger On");
			}
			System.out.println("[cdmCADMigration_mxJPO : executeMajorMinorAllCADMigration] end ." + getTimeStamp());
		}
	
	}
	
	
	/**
	 * minor major 관련 cad 파일 업로드및 파일 이동 
	 * 
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void executeMajorMinorCheckin(Context context,String []args)throws Exception{

		
		long startTime = System.currentTimeMillis();
		
		int successInt = 0;
		int failedInt = 0;
		int totalCount = 0;
		int notMatchTypeCount = 0;
		int cgmCount = 0;
		try {
			
			MqlUtil.mqlCommand(context, "Trigger Off");
			MqlUtil.mqlCommand(context, "history off");
			
			System.out.println("[cdmCADAllMigration : executeMajorMinorCheckin] start ." + cdmCommonExcel.getTimeStamp2() );

			String logFileName = "checkinFileM";

//			Map paramMap = new HashMap();
//			paramMap = (Map) JPO.unpackArgs(args);
//			String sFileLocationAndFileName = (String)paramMap.get("fileData");
			if(args.length!=1){
				throw new Exception("The excel path does not exist.");
			}
			String sFileLocationAndFileName = args[0];

			String cadFileLocation = "";
			String cadFileName = "";
			
			cadFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
			cadFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
//			logFileName +="_"+cadFileName.substring(0, cadFileName.lastIndexOf("."));
			// 읽을 파일경로 ,읽을 파일명
			String[] argTest = { cadFileLocation, cadFileName };
			// context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
			initializeM(context, argTest, 2, logFileName);
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("     CAD DATA MIGRATION " + getTimeStamp() + " \n");
			writeMessageToConsole("		Reading input log file from : " + inputDirectory+fileName);
			writeMessageToConsole("		Writing Log files to: " + outputDirectory);
			writeMessageToConsole("====================================================================================\n");
			int lineNumber = 0;
			
			StringList stListHeader = new StringList();
			String recordRowNum = "";
			String recordRowTdmxId = "";
			String recordRowRevision = "";
			
			String stReadData = "";
					
			MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
			IEFGlobalCache cache = new IEFGlobalCache();
			MCADGlobalConfigObject globalConfigObject = null;
			MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
			
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null) {
				StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
				try {
					if (lineNumber == 0) {
						stListHeader = stListReadData;
						writeFailToFile("errorTime"+"\t"+"errorNum"+"\t"+stReadData.toString());
						lineNumber++;
						continue;
					}
					lineNumber++;
					
					
					totalCount = lineNumber;
					LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();
					int readLineSize = stListReadData.size();
					int headerSize = stListHeader.size();

					if (headerSize != readLineSize) {
						String errorMessage = "NOT MATCH ROW INFOMATION." + stListReadData.toString() ;
						throw new Exception(errorMessage);
					}

					for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {

						String stTempCadInfos = ((String) stListReadData.get(stListNum)).trim();
						String stTempCadInfosHeader = ((String) stListHeader.get(stListNum)).trim();
						stTempCadInfos = isVaildNullData(stTempCadInfos);
						linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);

					}

					recordRowNum = (String) linkedCadHM.get("#");
					String sTempType = (String) linkedCadHM.get("CLS_NAME"); // 1,Type
					String sTdmxId		= (String) linkedCadHM.get("TDMX_ID"); 
					String sTempRevision = (String) linkedCadHM.get("REVISION"); // 3,Revision
//					String sRelated_PartName = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6
					String sFileType = (String) linkedCadHM.get("FILE_TYPE"); // 14, //Real Type
					String sFileName = (String) linkedCadHM.get("FILE_NAME"); // 15, //Real File
					String sRef_FileName = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); // 16,ORIGINAL FILE
//					String sRelated_PartRev = (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
					
					String valutObjectId = (String) linkedCadHM.get("VAULT_OBJECT_ID"); // 36,
					String sObjectRealName = (String) linkedCadHM.get("OBJECT_NAME"); 
					String sProjectGroup = (String) linkedCadHM.get("PROD_GROUP"); 
					String sVehicle     = (String) linkedCadHM.get("CN_CUST_VEHICLE"); 
					String sRealName = ""; 
							
//					if(sObjectRealName.contains("'")){
//						sRealName = sObjectRealName.replaceAll("'", "_");
//					}else{
//						sRealName = sObjectRealName;
//					}
					
					sTempType = sTempType.trim();
					sRealName = sObjectRealName;
					sRealName = sRealName.trim();
					String strFormat = "";
					recordRowTdmxId= sTdmxId;
					recordRowRevision = sTempRevision;					
					String strWorkspacePath = "F:\\CDM_VALUT\\";
					
					if("WJ Released".equals(valutObjectId)){
						strWorkspacePath +="Wj Released";
					}else{
						strWorkspacePath +=valutObjectId;
					}
					String sType = "";
					String sCAD_Type = "";
					boolean isExistCAD = false;
					boolean isExistCADNotCAT = false;
					boolean bFileTypeCheck = false;
					
					String sTempFileType = "";
					
					//
					if ("CATIA Product".equals(sFileType)) {
						if ("Assembly".equals(sTempType)) {
//							isCatiaCadModel = true;
							isExistCAD = true;
							strFormat = "asm";
							sCAD_Type = "assembly";
							sType = cdmConstantsUtil.TYPE_CATPRODUCT;
						}
					}else if("AutoCAD".equals(sFileType)){
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
						}
						if ("Image Drawing".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
						}
					}else if("CATIA Drawing".equals(sFileType)){
//						System.out.println("sTempType =-> "+ sTempType);
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
							//PDF ,ZIP 존재가능
						}
						
						if("Image Drawing".equals(sTempType)) {
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
							sFileType = "Image";							
						}
						
						if("V4 Model".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
							isExistCADNotCAT = true;
						}
						
						if("Drawing".equals(sTempType)){
							strFormat = "drw";
							sCAD_Type = "drawing";
//							isCatiaCadModel = true;
							isExistCAD = true;
							sType = "CATDrawing";
							
						}
						
						//Exchange 는 제외함 
					}else if("DXF".equals(sFileType)){
						sType = "cdmDXF";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
					}else if("CATIA cgm".equals(sFileType)){
						sType = "cdmCATIAcgm";
						sFileType = "CATIA cgm";
						isExistCADNotCAT = true;
					}else if("STEP".equals(sFileType)){
						sType = cdmConstantsUtil.TYPE_CDMSTEP;
						isExistCADNotCAT = true;
					}else if("CATIA Material".equals(sFileType)){
						sType = cdmConstantsUtil.TYPE_CDMCATIAMATERIAL;
						isExistCADNotCAT = true;
						bFileTypeCheck = true;
					}else if("CATIA Model".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CATPART;
//							isCatiaCadModel = true;
							isExistCAD = true;
							strFormat = "prt";
							sCAD_Type = "component";
						}
						if("V4 Model".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
							isExistCADNotCAT = true;
							bFileTypeCheck = true;
						}
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							isExistCADNotCAT = true;
						}
						
					}else if("CATIA Part".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CATPART;
//							isCatiaCadModel = true;
							isExistCAD = true;
							strFormat = "prt";
							sCAD_Type = "component";
						}
					}else if("IGES".equals(sFileType)){
						if("Part".equals(sTempType)){
							sType = "cdmIGES";
							bFileTypeCheck = true;
//							sFileType = "";
						}
					}else if("PDF".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sType = "cdmImageDrawing";
							sFileType = "Image";
//							sFileType = "";
						}
						if("AutoCAD".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}
					}else if("STEP".equals(sFileType)){
						sType = "cdmSTEP";
						isExistCADNotCAT = true;
					}else if("Text".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
							sType = "cdmImageDrawing";
							sFileType = "Image";
						}
					}else if("Unigraphics".equals(sFileType)){
						if("Image Drawing".equals(sTempType)){
							sType = "cdmImageDrawing";
						}
						if("UG NX Drawing".equals(sTempType)){
							sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
							isExistCADNotCAT = true;
						}
						if("UG NX Part".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMNXPART;
							isExistCADNotCAT = true;
						}
					}else if("ZIP".equals(sFileType)){
						if ("AutoCAD".equals(sTempType)) {
							sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//							sFileType = "";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}
					}else if("CATIA cgr".equals(sFileType)){
						sType = "cdmCATIAcgr";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
					}else if("CATIA Material".equals(sFileType)){
						sType = "cdmCATIAMaterial";
//						sFileType = "";
						bFileTypeCheck = true;
						isExistCADNotCAT = true;
						
					}else{
						
					}
					
					if (StringUtils.isEmpty(sType)) {
						// Image Drawing 파일 타입이 존재하지 않는 경우 제외
						sType = "cdmImageDrawing";
//						sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
						sFileType = "Image";
					}
					
					if(bFileTypeCheck){
						sTempFileType = "";
					}else{
						sTempFileType = sFileType;
					}
					//
					
					
					File file = new File(strWorkspacePath+File.separator+sFileName);
					boolean isEixstFile = file.exists();
					if(!isEixstFile){
						
						String errorMessage = "NOT FIND FILE. "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId+"\t"+sTempRevision;
						throw new Exception(errorMessage);
					}
					boolean bCgrFileExist = false; 
//					boolean b3dXmlFileExist = false; 
					String tempCgrFileName = "";
					String temp3dxmlFileName = "";
					String tempCgmFileName = "";
					
					String tempCgrObjectFileName = "";
					String temp3dxmlObjectFileName = "";
					String tempCgmObjectFileName = "";
					
					tempCgrFileName = sFileName;
					temp3dxmlFileName = sFileName;
					tempCgmFileName = sFileName;
					
					int intLastCGRExtension = tempCgrFileName.lastIndexOf(".");
					tempCgrFileName = tempCgrFileName.substring(0, intLastCGRExtension)+"."+sType+".cgr";
					
					int intLast3dxmlExtension = temp3dxmlFileName.lastIndexOf(".");
					temp3dxmlFileName = temp3dxmlFileName.substring(0, intLast3dxmlExtension)+"."+sType+".3dxml";
				
					int intLastCgmExtension = tempCgmFileName.lastIndexOf(".");
					tempCgmFileName = tempCgmFileName.substring(0,intLastCgmExtension)+"."+sType+ ".cgm";
							
					File cgrFile = new File(strWorkspacePath+File.separator+tempCgrFileName);
					boolean isExistCGRFile = cgrFile.exists();
					
					File xmlFile = new File(strWorkspacePath+File.separator+temp3dxmlFileName);
					boolean isExistXmlFile = xmlFile.exists();
					
					File cgmFile = new File(strWorkspacePath+File.separator+tempCgmFileName);
					boolean isExistCGMFile = cgmFile.exists();
					
					//change name
					tempCgrObjectFileName = sRef_FileName;
					temp3dxmlObjectFileName = sRef_FileName;
					tempCgmObjectFileName = sRef_FileName;
					
					tempCgrObjectFileName = tempCgrObjectFileName.substring(0,tempCgrObjectFileName.lastIndexOf("."))+"."+sType+".cgr";
					temp3dxmlObjectFileName = temp3dxmlObjectFileName.substring(0,temp3dxmlObjectFileName.lastIndexOf("."))+"."+sType+".3dxml";
					tempCgmObjectFileName = tempCgmObjectFileName.substring(0,tempCgmObjectFileName.lastIndexOf("."))+"."+sType+".cgm";
					String sRevisionSeqence = "";
					sRevisionSeqence = sTempRevision;

					
					//1/30 주석처리 시작
//					if (sRevisionSeqence.contains(".")) {
//						StringList sListSplitRevision = FrameworkUtil.split(sRevisionSeqence, ".");
//						sRevisionSeqence = (String) sListSplitRevision.get(0);
//					}
					
//					String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
					//1/30 주석처리 끝
//					String relViewable = "Viewable";
					
					boolean bMinorVersionCheck = false;
					StringList sListSplitRevision = FrameworkUtil.split(sRevisionSeqence, "\\..+");
					String splitMinorRevision = "";
					if(sListSplitRevision.size()>2){
						bMinorVersionCheck = true;
						String sRevisionSequnceSplit = (String)sListSplitRevision.get(2);
						Integer intergerRevisionSequence = Integer.parseInt(sRevisionSequnceSplit);
						intergerRevisionSequence = intergerRevisionSequence-1;
						splitMinorRevision = String.format("%01d", intergerRevisionSequence);
						sRevisionSeqence = (String)sListSplitRevision.get(0); 
						splitMinorRevision = sRevisionSeqence+"."+splitMinorRevision;
					}else{
						sRevisionSeqence = (String)sListSplitRevision.get(0); 
					}
					//
					
					String cgrObjectId = "";
					String xmlObjectId = "";
					String cgmObjectId = "";
					
					/*
					 * *********************************************************
					 * object name 설정. sCAD_REF_FILE_NAME 데이타가 존재하지않는다면 에러 처리.
					 * *********************************************************
					 */
					if (UIUtil.isNullOrEmpty(sRef_FileName)) {
						String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;
						throw new Exception(sErrorMessage);
					}
					
					
					String checkCADVehicle = "";
					String checkCADProject = "";
					boolean checkCGR = false;
					boolean checkXML = false;
					boolean checkCgm = false;
					String sViewableName = sRealName+"."+sType;
					
					//project org 
					String sLastRevisionVerionId = "";
					String sMajorVerionId = "";
					String sMinorVerionId = "";
					ContextUtil.startTransaction(context, true);
					if (isExistCAD ) {

						/*
						 * *****************************************************
						 * REVISION 정보가 없다면 에러 처리. REVISION 설정 .
						 * *****************************************************
						 * 
						 */
						if (cdmStringUtil.isEmpty(sRevisionSeqence)) {
							String errorMessage = "NOT EXIST REVISION DATA. ";
							throw new Exception(errorMessage);
						}
						/*sName 값이 중복케이스가 존재하여 임의로 name 데이타 정보 추가하여 tnr의 name 정보로 사용된다. 0103 */
						BusinessObject existBusinessObj = new BusinessObject();
						if(bMinorVersionCheck){
							existBusinessObj = new BusinessObject(sType,sRealName, splitMinorRevision, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						}else{
							existBusinessObj = new BusinessObject(sType,sRealName, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						}
						
						String sMajorConnectedLastMinorRevsion = "";
						boolean bLastRevisionCheck = false; //현재 minor object 가 last minor object 인경우 체크
						String sMinorVersionRevision = "";
						String lastAndExistCadVersionId = "";
						String lastVersionId = "";
						boolean isCadObjExist = existBusinessObj.exists(context);
//						String reviseCheckM = "";
						String sHasFileExistCheck = "";
				
						if(isCadObjExist){
//							reviseCheckM = existBusinessObj.getAttributeValues(context, "cdmRevisionCheckInM").getValue();
							String existId = existBusinessObj.getObjectId(context);
							DomainObject existDObj = new DomainObject(existId);
							
							sHasFileExistCheck = (String)existDObj.getInfo(context, "format.hasfile");
							
							if(bMinorVersionCheck){
								 BusinessObject lastBus = existDObj.getLastRevision(context);
								 String lastObjectId = lastBus.getObjectId(context);
								
								 if(existId.equals(lastObjectId)){
									 bLastRevisionCheck = true;
									 String  sRelFromVersionOfId = "";
									 
									 lastAndExistCadVersionId = existId ;
									 
									 Map paramDataMap = new HashMap();
									 StringList sListParamData = new StringList();
									 sListParamData.add("from[VersionOf].to.id");
									 sListParamData.add("revision");
									 
									 paramDataMap = existDObj.getInfo(context, sListParamData);
									 sRelFromVersionOfId = (String)paramDataMap.get("from[VersionOf].to.id");
									 sMinorVersionRevision = (String)paramDataMap.get("revision");
									 
									 //현재 minor object 가 last minor object 인경우 existBusinessObj 변경
									 if(UIUtil.isNotNullAndNotEmpty(sRelFromVersionOfId)){
										 existBusinessObj = new BusinessObject(sRelFromVersionOfId);
									 }else{
										 throw new Exception("not exist major object.");
									 }
								 }
							}else{
								String  sRelToVersionOfId = "";
								sRelToVersionOfId = existDObj.getInfo(context, "to[VersionOf].from.id");
								DomainObject relToVersionOfDobj = new DomainObject(sRelToVersionOfId);
								BusinessObject lastVersionBus = new BusinessObject();
								lastVersionBus = relToVersionOfDobj.getLastRevision(context);
								lastVersionId = lastVersionBus.getObjectId(context);
								DomainObject sMajorConnectedLastMinorDObj = new DomainObject(lastVersionId);
								sMajorConnectedLastMinorRevsion = sMajorConnectedLastMinorDObj.getRevision(context);
								
							}
						}else{
							//not exist
						}
						
//						if (isCadObjExist && UIUtil.isNotNullAndNotEmpty(reviseCheckM) && reviseCheckM.equals(sTempRevision) && "FALSE".equalsIgnoreCase(sHasFileExistCheck)) {
						if (isCadObjExist &&  "FALSE".equalsIgnoreCase(sHasFileExistCheck)) {
							
							existBusinessObj.checkinFile(context, false, false, "", strFormat,  sFileName, strWorkspacePath); 
							
							String cadId = existBusinessObj.getObjectId(context);
							if(!sFileName.equals(sRef_FileName)){
								MqlUtil.mqlCommand(context, "mod bus $1  rename format $2 $3 file $4 $5 ",cadId, strFormat,"!propagaterename",sFileName,sRef_FileName);
							}
							// owner , project ,organization,
							DomainObject cadDobj = new DomainObject(cadId);
							DomainObject viewableDobj = new DomainObject();
							
							String sCgmUsers = cadDobj.getOwner(context).getName();
							sCgmUsers = isVaildNullData(sCgmUsers);
							String sViewableUsers = cadDobj.getOwner(context).getName();
							sViewableUsers = isVaildNullData(sViewableUsers);
							
//							checkCADVehicle = sVehicle;
//							checkCADProject = sProjectGroup;
//							checkCADVehicle = (String)cadDobj.getInfo(context, "project");
//							checkCADProject = (String)cadDobj.getInfo(context, "organization");
							
//							BusinessObject lastRevivionObj = cadDobj.getLastRevision(context);
//							String sLastRevisionObjId = lastRevivionObj.getObjectId(context);
							//cgm 
							// // 임시로 cgm 주석처리함 다시 cgm 주석풀것 2.5 start 
							if(isExistCGMFile && "CATDrawing".equals(sType) ){
								
								String cgmType = "Derived Output";
								String cgmPolicy = "Derived Output TEAM Policy";
								String attributeCADType = "cgmOutput";
								
								DomainObject cgmDboj = new DomainObject();
								String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
								
//								cgmDboj.createObject(context, cgmType,sViewableName , minorRevString, cgmPolicy, vault);
								if(bMinorVersionCheck && !bLastRevisionCheck){
									cgmDboj.createObject(context, cgmType,sViewableName , splitMinorRevision, cgmPolicy, vault);
								}else if(bMinorVersionCheck && bLastRevisionCheck){
									cgmDboj.createObject(context, cgmType,sViewableName ,sMinorVersionRevision , cgmPolicy, vault);
								}else{
									cgmDboj.createObject(context, cgmType,sViewableName , sMajorConnectedLastMinorRevsion, cgmPolicy, vault);
								}
								cgmObjectId = cgmDboj.getId(context);
								cgmDboj.checkinFile(context, false, false, "", "CGM", tempCgmFileName, strWorkspacePath);
//								if(!tempCgrFileName.equals(tempCgrObjectFileName)){
								if(!tempCgmFileName.equals(tempCgmObjectFileName)){
									MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",cgmObjectId, "CGM","!propagaterename",tempCgmFileName,tempCgmObjectFileName);
								}
								checkCgm = true;
								
								if(UIUtil.isNotNullAndNotEmpty(sCgmUsers)){
									cgmDboj.setAttributeValue(context, "Originator",sCgmUsers);
									cgmDboj.setOwner(context, cadDobj.getOwner(context));
								}
									cgmDboj.setAttributeValue(context, "cdmCheckMigration","Y");
									cgmDboj.setAttributeValue(context, "CAD Type", attributeCADType);
								
								DomainRelationship connectDerivedOutRel= new DomainRelationship();
								connectDerivedOutRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Derived Output"),cgmDboj );
								connectDerivedOutRel.setAttributeValue(context, "CAD Object Name", sRealName);
								
								String minorObjectId = "";
								if(bMinorVersionCheck && !bLastRevisionCheck){
//									minorObjectId = cadId;
								}else if(bMinorVersionCheck && bLastRevisionCheck){
									minorObjectId = lastAndExistCadVersionId;
								}else{
									minorObjectId = lastVersionId;
								}
//								String minorObjectId = existMinorBusinessObj.getObjectId(context);
								if(UIUtil.isNotNullAndNotEmpty(minorObjectId)){
									DomainObject cadMinorDobj = new DomainObject(minorObjectId);
									DomainRelationship connectMinorDerivedOutRel= new DomainRelationship();
									connectMinorDerivedOutRel = DomainRelationship.connect(context, cadMinorDobj, new RelationshipType("Derived Output"),cgmDboj );
									connectMinorDerivedOutRel.setAttributeValue(context, "CAD Object Name", sRealName);
								}
								
							}
							// 임시로 cgm 주석처리함 다시 cgm 주석풀것 2.5 end 
							//cgr ,3dxml
//							if((isExistCGRFile || isExistXmlFile) && ("CATPart".equals(sType)|| "CATProduct".equals(sType))  ){
							if((isExistCGRFile || isExistXmlFile)  ){
								
								if(isExistCGRFile){
									String viewcgrType = "CgrViewable";
									String view3dXmlPolicy = "Viewable TEAM Policy";
									String attributeCADType = "cgrOutput";
									
									DomainObject cgrDboj = new DomainObject();
									String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
//									if(bMinorVersionCheck && !bLastRevisionCheck){
//									BusinessObject CheckBus = new BusinessObject(viewcgrType,sViewableName,minorRevString,"");
//									boolean checkCGRViewble = CheckBus.exists(context);
////									
//									if(CheckBus.exists(context)){
//										System.out.println("exist cgr"+CheckBus.getObjectId(context));
//									}
//									cgrDboj.createObject(context, viewcgrType,sViewableName , minorRevString, view3dXmlPolicy, vault);
									
									//
									if(bMinorVersionCheck && !bLastRevisionCheck){
										cgrDboj.createObject(context, viewcgrType,sViewableName , splitMinorRevision, view3dXmlPolicy, vault);
									}else if(bMinorVersionCheck && bLastRevisionCheck){
										cgrDboj.createObject(context, viewcgrType,sViewableName ,sMinorVersionRevision , view3dXmlPolicy, vault);
									}else{
										cgrDboj.createObject(context, viewcgrType,sViewableName , sMajorConnectedLastMinorRevsion, view3dXmlPolicy, vault);
									}
									//
									cgrObjectId = cgrDboj.getObjectId(context);
									BusinessObject busCgr = new BusinessObject(cgrObjectId);
									busCgr.checkinFile(context, false, false, "", "CGR", tempCgrFileName, strWorkspacePath);
//									busCgr.checkinFile(context, false, false, null, "CGR", "STORE", tempCgrFileName, strWorkspacePath);
									if(!tempCgrFileName.equals(tempCgrObjectFileName)){
										MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",cgrObjectId, "CGR","!propagaterename",tempCgrFileName,tempCgrObjectFileName);
									}
									
									checkCGR = true;
									if(UIUtil.isNotNullAndNotEmpty(sViewableUsers)){
										busCgr.setAttributeValue(context, "Originator",sViewableUsers);
										busCgr.setOwner(context, cadDobj.getOwner(context));
									}
									busCgr.setAttributeValue(context, "cdmCheckMigration","Y");
									busCgr.setAttributeValue(context, "CAD Type", attributeCADType);
									viewableDobj.setId(cgrObjectId);
									DomainRelationship connectRel= new DomainRelationship();
									connectRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
									connectRel.setAttributeValue(context, "CAD Object Name", sRealName);
									//
									//
									String minorObjectId = "";
									if(bMinorVersionCheck && bLastRevisionCheck){
										minorObjectId = lastAndExistCadVersionId;
									}else if(!bMinorVersionCheck){
										minorObjectId = lastVersionId;
									}
									if(UIUtil.isNotNullAndNotEmpty(minorObjectId)){
										DomainObject cadMinorDobj = new DomainObject(minorObjectId);
										DomainRelationship connectMinorDerivedOutRel= new DomainRelationship();
										connectMinorDerivedOutRel = DomainRelationship.connect(context, cadMinorDobj, new RelationshipType("Viewable"),viewableDobj );
										connectMinorDerivedOutRel.setAttributeValue(context, "CAD Object Name", sRealName);
									}
//									if(existMinorBusinessObj.exists(context)){
//										
//										cadDobj.setId(existMinorBusinessObj.getObjectId(context));
//										DomainRelationship connectMinorRel= new DomainRelationship();
//										connectMinorRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
////										connectMinorRel.setAttributeValue(context, "CAD Object Name", sName);
//										connectMinorRel.setAttributeValue(context, "CAD Object Name", sRealName);
//									}
								}
////								//연결한 CAT originator 혹은 Person 정보와 일치시킨다.  없으면 admin
////								
//								if (isExistXmlFile) {
//
//									String view3dXmlType = "3dxmlViewable";
//									String view3dXmlPolicy = "Viewable TEAM Policy";
//									String attributeCADType = "3dxmlOutput";
//									String originator = "";
//									cadDobj.setId(cadId);
//									DomainObject xmlDboj = new DomainObject();
//									String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
//									
//									BusinessObject CheckBus = new BusinessObject(view3dXmlType,sViewableName,minorRevString,vault);
//									if(CheckBus.exists(context)){
//										System.out.println("exist xml"+CheckBus.getObjectId(context));
//									}
//									xmlDboj.createObject(context, view3dXmlType, sViewableName, minorRevString, view3dXmlPolicy, vault);
//									xmlObjectId = xmlDboj.getObjectId(context);
//									xmlDboj.setAttributeValue(context, "CAD Type", attributeCADType);
//									BusinessObject busXml = new BusinessObject(xmlObjectId);
//									busXml.checkinFile(context, false, false, "", "3DXML", temp3dxmlFileName, strWorkspacePath);
////									busXml.checkinFile(context, false, false, null, "3DXML", "STORE", temp3dxmlFileName, strWorkspacePath);
//									if(!temp3dxmlFileName.equals(temp3dxmlObjectFileName)){
//										MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file  $4 $5", xmlObjectId, "3DXML", "!propagaterename",temp3dxmlFileName, temp3dxmlObjectFileName);
//									}
//									busXml.setOwner(context, cadDobj.getOwner(context));
//									// DomainRelationship viewable = new
//									// DomainRelationship();
//									// viewable.connect(context, xmlObjectId,
//									// relViewable, paramDomainObject2)
//									checkXML = true;
//									if(UIUtil.isNotNullAndNotEmpty(sViewableUsers)){
//										busXml.setAttributeValue(context, "Originator",sViewableUsers);
//										busXml.setAttributeValue(context, "cdmCheckMigration","Y");
//										busXml.setOwner(context, cadDobj.getOwner(context));
//									}
//
//									viewableDobj.setId(xmlObjectId);
//									DomainRelationship connectRel = new DomainRelationship();
//									connectRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
////									connectRel.setAttributeValue(context, "CAD Object Name", sName);
//									connectRel.setAttributeValue(context, "CAD Object Name", sRealName);
//									if (existMinorBusinessObj.exists(context)) {
//
//										cadDobj.setId(existMinorBusinessObj.getObjectId(context));
//										DomainRelationship connectMinorRel = new DomainRelationship();
//										connectMinorRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
//										connectMinorRel.setAttributeValue(context, "CAD Object Name", sRealName);
////										connectMinorRel.setAttributeValue(context, "CAD Object Name", sName);
//									}
//								}
							}
//							successInt++;
							
							
						} else {
							String errorMessage = "";
						
							if (!isCadObjExist &&  "FALSE".equalsIgnoreCase(sHasFileExistCheck)) {
								errorMessage = "The major object does not exist. \t "+sType+" \t "+sFileType+" \t"+sTdmxId+" \t"+sTempRevision;
							}else if(isCadObjExist && !"FALSE".equalsIgnoreCase(sHasFileExistCheck) ){
								errorMessage = "NOT EXIST MAJOR OBJECT. \t"+sType+"\t "+sRealName +"\t"+sTdmxId+" \t"+sTempRevision;
							}else {
								errorMessage = "can not checkin (default). \t"+sType+"\t "+sRealName +"\t"+sTdmxId+" \t"+sTempRevision;
							}
							throw new Exception(errorMessage);
						}
					} 
					else {
						/*
						 * Document 타입일 경우 Document 의 경우 'Document Release'
						 * policy 인 object 에 모든 파일이 저장되며 revision의 object의 경우에도
						 * 파일이 이동하지않고 변경한 데이타들이 저장 파일 이 추가 될
						 * cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성
						 */

						strFormat = "generic";
						BusinessObject existdocumentBusObj = new BusinessObject(sType, sRealName, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
						
						if(bMinorVersionCheck){
							String mqlQuery = "temp query bus $1 $2 $3 where $4 select $5 dump $6";
							String queryWhere = "attribute[cdmTDMXID] == '"+sTdmxId+"' && attribute[cdmRevisionCheckInM] == '"+sTempRevision+"' && policy == 'Version' ";
							String queryMql  = MqlUtil.mqlCommand(context,
												mqlQuery,sType,"*","*", queryWhere,"id","|");
							
							StringList sListQuery = new StringList();
							sListQuery = FrameworkUtil.split(queryMql, "|");
							if(sListQuery.size()>2){
								String minorDocumentId = (String)sListQuery.get(3);
								existdocumentBusObj = new BusinessObject(minorDocumentId);
							}else{
								throw new Exception("The minor object does not exist.\t"+sType+"\t "+sRealName +"\t"+sTdmxId+" \t"+sTempRevision);
							}
							

						}
						boolean isDocumentObjExist = existdocumentBusObj.exists(context);
						
						boolean bLastRevisionDocumentCheck = false;
//						String reviseCheckM = "";
						String sHasFileExistDocumentCheck = "";
						if(isDocumentObjExist){
//							reviseCheckM = existdocumentBusObj.getAttributeValues(context, "cdmRevisionCheckInM").getValue();
							String existDocumentId = existdocumentBusObj.getObjectId(context);
							DomainObject existDocumentDObj = new DomainObject(existDocumentId);
							sHasFileExistDocumentCheck = (String)existDocumentDObj.getInfo(context, "format.hasfile");
							
							
							if(bMinorVersionCheck){
								BusinessObject lastVersionDocumentBus = existDocumentDObj.getLastRevision(context);
								 String lastDocumentObjectId = lastVersionDocumentBus.getObjectId(context);
							
								 if(existDocumentId.equals(lastVersionDocumentBus)){
									 bLastRevisionDocumentCheck = true;

									 Map paramDataMap = new HashMap();
									 StringList sListParamData = new StringList();
									 sListParamData.add("to[Active Version].from.id");
									 
									 paramDataMap = existDocumentDObj.getInfo(context, sListParamData);
//									 sMinorVersionRevision = (String)paramDataMap.get("revision");
									 String majorDocumentId = "";
									 majorDocumentId = (String)paramDataMap.get("to[Active Version].from.id");
									 if(UIUtil.isNotNullAndNotEmpty(majorDocumentId)){
										 existdocumentBusObj = new BusinessObject(majorDocumentId);
									 }
								 }
							}
							
							
							
							//project ,org 
							if(bMinorVersionCheck && bLastRevisionDocumentCheck){

								 Map paramDataMap = new HashMap();
								 StringList sListParamData = new StringList();
								 sListParamData.add("to[Active Version].from.id");
								 paramDataMap = existDocumentDObj.getInfo(context, sListParamData);
								 
								 sMajorVerionId  = (String)paramDataMap.get("to[Active Version].from.id");
								 sLastRevisionVerionId = existDocumentId;  
							}else if(!bMinorVersionCheck){
								
								Map paramDataMap = new HashMap();
								 StringList sListParamData = new StringList();
								 sListParamData.add("from[Active Version].to.id");
								 paramDataMap = existDocumentDObj.getInfo(context, sListParamData);
								 
								 sLastRevisionVerionId  = (String)paramDataMap.get("from[Active Version].to.id");
								sMajorVerionId = existDocumentId;
							}else{
								sMinorVerionId  = existDocumentId;
							}
							//
						}

						
//						if (isMajorDocumentObjExist && UIUtil.isNotNullAndNotEmpty(reviseCheckM) && reviseCheckM.equals(sTempRevision) && "FALSE".equalsIgnoreCase(sHasFileExistDocumentCheck)) {
						if (isDocumentObjExist  && "FALSE".equalsIgnoreCase(sHasFileExistDocumentCheck)) {
							existdocumentBusObj.checkinFile(context, false, false, "", strFormat, sFileName, strWorkspacePath);

							String documentBusId= existdocumentBusObj.getObjectId(context);
							if(!sFileName.equals(sRef_FileName)){
								MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",documentBusId, strFormat,"!propagaterename",sFileName,sRef_FileName);
							}
						} else {
							String errorMessage = "";
							if(!isDocumentObjExist && "FALSE".equalsIgnoreCase(sHasFileExistDocumentCheck)){
								//String errorMessage = "NOT FIND FILE. "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;;
								 errorMessage = "The major object does not exist. \t "+sType+" \t "+sFileType+" \t"+sTdmxId+" \t"+sTempRevision;
								 throw new Exception(errorMessage);
							}else if(isDocumentObjExist && "TRUE".equalsIgnoreCase(sHasFileExistDocumentCheck)){
//								 errorMessage = "The file already exists.  \t "+sType+"\t"+sFileType +"\t"+sTempRevision;
							}else if(!isDocumentObjExist){
								errorMessage = "not object exist \t"+isDocumentObjExist+"\t not exist"+sHasFileExistDocumentCheck +"\t "+sType+"\t"+sFileType +"\t"+sTempRevision;
								throw new Exception(errorMessage);
							}else{
								
							}
							
						}

					}
					ContextUtil.commitTransaction(context);
					successInt++;
					boolean bProjectOrg = false;
					/* project org 설정 */
					try {
						checkCADVehicle = isVaildNullData(sVehicle);
						checkCADProject = isVaildNullData(sProjectGroup);
//						if (isExistCAD && UIUtil.isNotNullAndNotEmpty(checkCADVehicle) && UIUtil.isNotNullAndNotEmpty(checkCADProject) ) {
						if ( UIUtil.isNotNullAndNotEmpty(checkCADVehicle) && UIUtil.isNotNullAndNotEmpty(checkCADProject) ) {

							if (UIUtil.isNotNullAndNotEmpty(cgrObjectId)) {
								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", cgrObjectId, checkCADProject, checkCADVehicle);

							}
//							if (UIUtil.isNotNullAndNotEmpty(xmlObjectId)) {
//								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", xmlObjectId, checkCADProject, checkCADVehicle);
//							}
							if (UIUtil.isNotNullAndNotEmpty(cgmObjectId)) {
								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", cgmObjectId, checkCADProject, checkCADVehicle);

							}
							// 임시로 project org 추가 start
							if (UIUtil.isNotNullAndNotEmpty(sMajorVerionId ) && UIUtil.isNotNullAndNotEmpty(sLastRevisionVerionId )) {
//								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", sMajorVerionId, checkCADProject, checkCADVehicle);
//								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", sLastRevisionVerionId, checkCADProject, checkCADVehicle);
							}
							if (UIUtil.isNotNullAndNotEmpty(sMinorVerionId)) {
								
//								MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", sMinorVerionId, checkCADProject, checkCADVehicle);
							}
							// 임시로 project org 추가 end 
							bProjectOrg = true;
						}else{
							bProjectOrg = false;
						}
					}catch(Exception e4){
						bProjectOrg = false;
					}
					writeSuccessToFile(recordRowNum + "\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+checkXML+"\t"+checkCGR +"\t"+checkCgm+"\t"+bProjectOrg+"\t"+checkCADProject+"\t"+checkCADVehicle);
//					writeMessageToConsole(recordRowNum + "\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+checkXML+"\t"+checkCGR+"\t"+bProjectOrg+"\t"+checkCADProject+"\t"+checkCADVehicle);
					if(checkCgm){
						cgmCount++;
					}
					
					
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failedInt++;
					String message = exception.getMessage();
					
					if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not a valid type or filetype.")){
						writeMessageToConsole(recordRowNum + "\t"+"1"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"1"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST CAD_REF_FILE_NAME FILE DATA .") ){
						writeMessageToConsole(recordRowNum + "\t"+"2"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"2"+"\t"+stReadData);
						
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR DOCUMENT")){
						writeMessageToConsole(recordRowNum + "\t"+"3"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR OBJECT.")){
						
						writeMessageToConsole(recordRowNum + "\t"+"4"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"4"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST REVISION DATA.")){
						writeMessageToConsole(recordRowNum + "\t"+"5"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"5"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT FIND FILE.")){
						writeMessageToConsole(recordRowNum + "\t"+"6"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"6"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT MATCH ROW INFOMATION.")){
						writeMessageToConsole(recordRowNum + "\t"+"7"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"7"+"\t"+stReadData);
//					
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("The major object does not exist.")){
						writeMessageToConsole(recordRowNum + "\t"+"8"+" \t "+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+" \t "+"8"+"\t "+stReadData);
						
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("The file already exists.")){
						writeMessageToConsole(recordRowNum + "\t"+"9"+" \t "+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+" \t "+"9"+" \t "+stReadData);
					}
					else{
						writeMessageToConsole(recordRowNum + "\t"+"0"+"\t"+message);
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t "+stReadData);
						
					}
					writeErrorToFile("LineNum(#)"+recordRowNum+" \t "+recordRowTdmxId+" \t "+recordRowRevision);
					exception.printStackTrace(errorStream);

				}finally{
					
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}finally{
			MqlUtil.mqlCommand(context, "Trigger On");
			MqlUtil.mqlCommand(context, "history on");
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms        \n");
			writeMessageToConsole("End Time :("+cdmCommonExcel.getTimeStamp2() +")  Total Count:("+(totalCount-1)+") Success Count:("+successInt+") notMacthType:("+notMatchTypeCount+"  Fail Count: ("+failedInt+") cgmCount: ("+cgmCount+")" );
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			
			
			System.out.println("[cdmCADMigration_mxJPO : executeMajorMinorCheckin] end ." + cdmCommonExcel.getTimeStamp2() );
		}
	
		
	}
	/**
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void deleteCADORDocument(Context context,String args[])throws Exception{
		try{
			System.out.println("deleteCADORDocument start"+cdmCommonExcel.getTimeStamp2());
//			MqlUtil.mqlCommand(context, "Trigger On");
			String busWhere = "attribute[cdmCheckMigration] == 'Y' && policy == 'Document Release' " ;
//			String sType = "CATDrawing";
//			String sType = "cdmAutoCAD";
			String sType = "cdmNXDrawing,cdmNXPart,cdmNXPart";
			StringList busSelect = new StringList(1);
			busSelect.add("id");
			
			MapList mListCADobj = DomainObject.findObjects(context,
					sType, 
					"*", 
					"*",
					"*",
					"*",
					busWhere,
					false,
					busSelect );
			System.out.println("size :"+mListCADobj.size());
			for(int count=0;count<mListCADobj.size();count++){
				Map cadMap = (Map) mListCADobj.get(count);
				String cadId= (String)cadMap.get("id");
				DomainObject dObject = new DomainObject();
				
				dObject.setId(cadId);
				dObject.delete(context);
			}
			System.out.println("deleteCADORDocument end"+cdmCommonExcel.getTimeStamp2());
		}catch(Exception e2){
			e2.printStackTrace();
		}finally{
			
//			MqlUtil.mqlCommand(context, "Trigger Off");	
		}
	}
	
		
		
//		/**
//		 * 
//		 * @param context
//		 * @param args
//		 * @throws Exception
//		 */
//		public void deleteCAT(Context context,String args[])throws Exception{
//			try{
//				System.out.println("deleteCADORDocument start"+cdmCommonExcel.getTimeStamp2());
////				MqlUtil.mqlCommand(context, "Trigger On");
//				String busWhere = "attribute[cdmCheckMigration] == 'Y' && policy == 'Document Release' " ;
////				String sType = "CATDrawing";
////				sType = ",";
////				 sType = "CATPart";
////				 sType = ",";
////				 sType = "CATProduct";
//				String sType = "cdmImageDrawing";
//				StringList busSelect = new StringList(1);
//				busSelect.add("id");
//				
//				MapList mListCADobj = DomainObject.findObjects(context,
//						sType, 
//						"*", 
//						"*",
//						"*",
//						"*",
//						busWhere,
//						false,
//						busSelect );
//				System.out.println("test"+mListCADobj.size());
//				for(int count=0;count<mListCADobj.size();count++){
//					Map cadMap = (Map) mListCADobj.get(count);
//					String cadId= (String)cadMap.get("id");
//					DomainObject dObject = new DomainObject();
//					
//					dObject.setId(cadId);
//					
//					dObject.delete(context);
//				}
//				System.out.println("deleteCADORDocument end"+cdmCommonExcel.getTimeStamp2());
//			}catch(Exception e2){
//				e2.printStackTrace();
//			}finally{
//				
////				MqlUtil.mqlCommand(context, "Trigger Off");	
//			}
//		
//	}
		
		/**
		 * 한글깨짐
		 * @param context
		 * @param args
		 * @throws Exception
		 */
		public void modifyName(Context context,String args[])throws Exception{
			
			long startTime = System.currentTimeMillis();
			
			int successInt = 0;
			int failedInt = 0;
			int totalCount = 0;
			int notMatchTypeCount = 0;
			try {
				
				MqlUtil.mqlCommand(context, "Trigger Off");
				MqlUtil.mqlCommand(context, "history off");
				
				System.out.println("[cdmCADMigration_mxJPO : modifyName] start ." + cdmCommonExcel.getTimeStamp2() );

				String logFileName = "modifyCADName";
				
				Map paramMap = new HashMap();
				paramMap = (Map) JPO.unpackArgs(args);
				String sFileLocationAndFileName = (String)paramMap.get("fileData");
//				if(args.length!=1){
//					throw new Exception("The excel path does not exist.");
//				}
//				String sFileLocationAndFileName = args[0];

				String cadFileLocation = "";
				String cadFileName = "";
				
				cadFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
				cadFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
				logFileName+="_"+cadFileName.substring(0,cadFileName.lastIndexOf("."));
				// 읽을 파일경로 ,읽을 파일명
				String[] argTest = { cadFileLocation, cadFileName };
				// context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
				initializeM(context, argTest, 2, logFileName);
				
				writeMessageToConsole("====================================================================================");
				writeMessageToConsole("     CAD DATA MIGRATION " + getTimeStamp() + " \n");
				writeMessageToConsole("		Reading input log file from : " + inputDirectory+fileName);
				writeMessageToConsole("		Writing Log files to: " + outputDirectory);
				writeMessageToConsole("====================================================================================\n");
				int lineNumber = 0;
				
				StringList stListHeader = new StringList();
				String recordRowNum = "";
				String recordRowTdmxId = "";
				String recordRowRevision = "";
				
				String stReadData = "";
						
				MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
				IEFGlobalCache cache = new IEFGlobalCache();
				MCADGlobalConfigObject globalConfigObject = null;
				MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
				
				//
				bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
				while ((stReadData = bufferReader.readLine()) != null) {
					StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
					try {
						//
						if (lineNumber == 0) {
							stListHeader = stListReadData;
							writeFailToFile("errorTime"+"\t"+"errorNum"+"\t"+stReadData.toString());
							lineNumber++;
							continue;
						}
						lineNumber++;
						
						
						totalCount = lineNumber;
						LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();
						int readLineSize = stListReadData.size();
						int headerSize = stListHeader.size();

						if (headerSize != readLineSize) {
							String errorMessage = "NOT MATCH" + stListReadData.toString() ;
//							String errorMessage = "NOT MATCH ROW INFOMATION"+"\t"+lineNumber;
							throw new Exception(errorMessage);
						}

						for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {

							String stTempCadInfos = ((String) stListReadData.get(stListNum)).trim();
							String stTempCadInfosHeader = ((String) stListHeader.get(stListNum)).trim();
							stTempCadInfos = isVaildNullData(stTempCadInfos);
							linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);

						}

						recordRowNum = (String) linkedCadHM.get("#");
						String sTempType = (String) linkedCadHM.get("CLS_NAME"); // 1,Type
						String sTdmxId		= (String) linkedCadHM.get("TDMX_ID"); 
						String sTempRevision = (String) linkedCadHM.get("REVISION"); // 3,Revision
//						String sRelated_PartName = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6
						String sFileType = (String) linkedCadHM.get("FILE_TYPE"); // 14, //Real Type
						String sFileName = (String) linkedCadHM.get("FILE_NAME"); // 15, //Real File
						String sRef_FileName = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); // 16,ORIGINAL FILE
//						String sRelated_PartRev = (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
						String sDescription		 = (String) linkedCadHM.get("TDM_DESCRIPTION"); 
						String valutObjectId = (String) linkedCadHM.get("VAULT_OBJECT_ID"); // 36,
						String sObjectRealName = (String) linkedCadHM.get("OBJECT_NAME");
						//
						String sRelated_PartName	 = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); 
						String sCADIdentifier  = (String) linkedCadHM.get("TDMX_CAD_IDENTIFIER"); 
						String sDetailedDescription	= (String) linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); 
						String s3dCADIdentifier	= (String) linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); 
						String sTitleType		= (String) linkedCadHM.get("TDMX_TITLE_TYPE"); 
						String sScale		    = (String) linkedCadHM.get("TDMX_SCALE"); 
						String sPageSize	    = (String) linkedCadHM.get("TDMX_PAGE_SIZE");
						String sDocumentType	= (String) linkedCadHM.get("TDM_DOCUMENT_TYPE");
						String sMassEstimated	= (String) linkedCadHM.get("CN_MASS_ESTIMATED");
						String sSurfaceArea		= (String) linkedCadHM.get("CN_SURFACE_AREA");
						//
						
						String sRealName = ""; 
								
						if(sObjectRealName.contains("'")){
							sRealName = sObjectRealName.replaceAll("'", "_");
						}else{
							sRealName = sObjectRealName;
						}
						String strFormat = "";
						recordRowTdmxId= sTdmxId;
						recordRowRevision = sTempRevision;					
//						String strWorkspacePath = "F:\\CDM_VALUT\\";
//						if("WJ Released".equals(valutObjectId)){
////							strWorkspacePath +="Wj\\Released";
//							strWorkspacePath +="Wj Released";
//						}else{
//							strWorkspacePath +=valutObjectId;
//						}

						String sType = "";
						String sCAD_Type = "";
						boolean isExistCAD = false;
						boolean isExistCADNotCAT = false;
						boolean bFileTypeCheck = false;
						
						String sTempFileType = "";
//						if ("CATIA Product".equals(sFileType)) {
//							if ("Assembly".equals(sTempType)) {
//								isExistCAD = true;
//								strFormat = "asm";
//								sCAD_Type = "assembly";
//								sType = cdmConstantsUtil.TYPE_CATPRODUCT;
//							}
//						}else if("AutoCAD".equals(sFileType)){
//							if ("AutoCAD".equals(sTempType)) {
//								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//								isExistCADNotCAT = true;
//							}else if ("Image Drawing".equals(sTempType)) {
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
//							}
//						}else if("CATIA Drawing".equals(sFileType)){
//							if ("AutoCAD".equals(sTempType)) {
//								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//								isExistCADNotCAT = true;
//								//PDF ,ZIP 존재가능
//							}else if("Drawing".equals(sTempType)){
//								strFormat = "drw";
//								sCAD_Type = "drawing";
//								isExistCAD = true;
//								sType = cdmConstantsUtil.TYPE_CATDrawing;
//							}else if("Image Drawing".equals(sTempType)) {
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
//							}else if("V4 Model".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
//								isExistCADNotCAT = true;
//							}
//							//Exchange 는 제외함 
//						}else if("DXF".equals(sFileType)){
//							sType = "cdmDXF";
//							bFileTypeCheck = true;
//							isExistCADNotCAT = true;
//						}else if("CATIA cgm".equals(sFileType)){
//							sType = "cdmCATIAcgm";
//							sFileType = "CATIA cgm";
//							isExistCADNotCAT = true;
//						}else if("STEP".equals(sFileType)){
//							sType = cdmConstantsUtil.TYPE_CDMSTEP;
//							isExistCADNotCAT = true;
//						}else if("CATIA Material".equals(sFileType)){
//							sType = cdmConstantsUtil.TYPE_CDMCATIAMATERIAL;
//							isExistCADNotCAT = true;
//						}else if("CATIA Model".equals(sFileType)){
//							if("Part".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CATPART;
//								isExistCAD = true;
//								strFormat = "prt";
//								sCAD_Type = "component";
//							}else if("V4 Model".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
//								isExistCADNotCAT = true;
//							}else if ("AutoCAD".equals(sTempType)) {
//								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//								isExistCADNotCAT = true;
//							}
//							
//						}else if("CATIA Part".equals(sFileType)){
//							if("Part".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CATPART;
//								isExistCAD = true;
//								strFormat = "prt";
//								sCAD_Type = "component";
//							}
//						}else if("IGES".equals(sFileType)){
//							if("Part".equals(sTempType)){
//								sType = "cdmIGES";
//								bFileTypeCheck = true;
////								sFileType = "";
//							}
//						}else if("PDF".equals(sFileType)){
//							if("Image Drawing".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
//								bFileTypeCheck = true;
//							}else if("AutoCAD".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//								bFileTypeCheck = true;
//								isExistCADNotCAT = true;
//							}
//						}else if("STEP".equals(sFileType)){
//							sType = "cdmSTEP";
//							isExistCADNotCAT = true;
//						}else if("Text".equals(sFileType)){
//							if("Image Drawing".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
//								sFileType = "Image";
//							}
//						}else if("Unigraphics".equals(sFileType)){
//							if("Image Drawing".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
//							}else if("UG NX Drawing".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
//								isExistCADNotCAT = true;
//							}else if("UG NX Part".equals(sFileType)){
//								sType = cdmConstantsUtil.TYPE_CDMNXPART;
//								isExistCADNotCAT = true;
//							}
//						}else if("ZIP".equals(sFileType)){
//							if ("AutoCAD".equals(sTempType)) {
//								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
////								sFileType = "";
//								bFileTypeCheck = true;
//								isExistCADNotCAT = true;
//							}
//						}else if("CATIA cgr".equals(sFileType)){
//							sType = "cdmCATIAcgr";
//							bFileTypeCheck = true;
//							isExistCADNotCAT = true;
//						}else if("CATIA Material".equals(sFileType)){
//							sType = "cdmCATIAMaterial";
//							bFileTypeCheck = true;
//							isExistCADNotCAT = true;
//							
//						}
//						
//						if (UIUtil.isNullOrEmpty(sType)) {
//							// Image Drawing 파일 타입이 존재하지 않는 경우 제외
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
//							sFileType = "Image";
//						}
//						if(bFileTypeCheck){
//							sTempFileType = "";
//						}else{
//							sTempFileType = sFileType;
//						}
						
						if ("CATIA Product".equals(sFileType)) {
							if ("Assembly".equals(sTempType)) {
//								isCatiaCadModel = true;
								isExistCAD = true;
								strFormat = "asm";
								sCAD_Type = "assembly";
								sType = cdmConstantsUtil.TYPE_CATPRODUCT;
							}
						}else if("AutoCAD".equals(sFileType)){
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
							}
							if ("Image Drawing".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
								sType = "cdmImageDrawing";
							}
						}else if("CATIA Drawing".equals(sFileType)){
//							System.out.println("sTempType =-> "+ sTempType);
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
								//PDF ,ZIP 존재가능
							}
							
							if("Image Drawing".equals(sTempType)) {
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
								sType = "cdmImageDrawing";
								sFileType = "Image";							
							}
							
							if("V4 Model".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
								isExistCADNotCAT = true;
							}
							
							if("Drawing".equals(sTempType)){
								strFormat = "drw";
								sCAD_Type = "drawing";
//								isCatiaCadModel = true;
								isExistCAD = true;
								sType = "CATDrawing";
								
							}
							
							//Exchange 는 제외함 
						}else if("DXF".equals(sFileType)){
							sType = "cdmDXF";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}else if("CATIA cgm".equals(sFileType)){
							sType = "cdmCATIAcgm";
							sFileType = "CATIA cgm";
							isExistCADNotCAT = true;
						}else if("STEP".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMSTEP;
							isExistCADNotCAT = true;
						}else if("CATIA Material".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMCATIAMATERIAL;
							isExistCADNotCAT = true;
						}else if("CATIA Model".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CATPART;
//								isCatiaCadModel = true;
								isExistCAD = true;
								strFormat = "prt";
								sCAD_Type = "component";
							}
							if("V4 Model".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
								isExistCADNotCAT = true;
							}
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
							}
							
						}else if("CATIA Part".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CATPART;
//								isCatiaCadModel = true;
								isExistCAD = true;
								strFormat = "prt";
								sCAD_Type = "component";
							}
						}else if("IGES".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = "cdmIGES";
								bFileTypeCheck = true;
//								sFileType = "";
							}
						}else if("PDF".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
								sType = "cdmImageDrawing";
								sFileType = "Image";
//								sFileType = "";
							}
							if("AutoCAD".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								bFileTypeCheck = true;
								isExistCADNotCAT = true;
							}
						}else if("STEP".equals(sFileType)){
							sType = "cdmSTEP";
							isExistCADNotCAT = true;
						}else if("Text".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
								sType = "cdmImageDrawing";
								sFileType = "Image";
							}
						}else if("Unigraphics".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
								sType = "cdmImageDrawing";
							}
							if("UG NX Drawing".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
								isExistCADNotCAT = true;
							}
							if("UG NX Part".equals(sFileType)){
								sType = cdmConstantsUtil.TYPE_CDMNXPART;
								isExistCADNotCAT = true;
							}
						}else if("ZIP".equals(sFileType)){
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//								sFileType = "";
								bFileTypeCheck = true;
								isExistCADNotCAT = true;
							}
						}else if("CATIA cgr".equals(sFileType)){
							sType = "cdmCATIAcgr";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}else if("CATIA Material".equals(sFileType)){
							sType = "cdmCATIAMaterial";
//							sFileType = "";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
							
						}else{
							
						}
						
						if (StringUtils.isEmpty(sType)) {
							// Image Drawing 파일 타입이 존재하지 않는 경우 제외
							sType = "cdmImageDrawing";
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sFileType = "Image";
						}
						
						if(bFileTypeCheck){
							sTempFileType = "";
						}else{
							sTempFileType = sFileType;
						}
					
					
						
						String sRevisionSeqence = "";
						sRevisionSeqence = sTempRevision;

						if (sRevisionSeqence.contains(".")) {
							StringList sListSplitRevision = FrameworkUtil.split(sRevisionSeqence, ".");
							sRevisionSeqence = (String) sListSplitRevision.get(0);
						}
						
						String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
						
						/*
						 * *********************************************************
						 * object name 설정. sCAD_REF_FILE_NAME 데이타가 존재하지않는다면 에러 처리.
						 * *********************************************************
						 */
						if (UIUtil.isNullOrEmpty(sRef_FileName)) {
							String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;;;
							throw new Exception(sErrorMessage);
						}
						
						
//						String checkCADVehicle = "";
//						String checkCADProject = "";
//						boolean checkCGR = false;
//						boolean checkXML = false;
						
						String sWhere = "attribute[cdmTDMXID] == '"+sTdmxId+"' ";
						String createdDocFindMql = MqlUtil.mqlCommand(context, "temp query bus $1  $2 $3 where $4 select $5 $6 dump $7 ",sType, "*", sRevisionSeqence,sWhere ,"id","attribute[cdmRevisionCheckInM]","|");
						StringList sListCreatedDocFindMql = new StringList();
						sListCreatedDocFindMql = FrameworkUtil.split(createdDocFindMql, "\n");
						//
						String sFindDocId = "";
						for (Iterator iterFindDoc = sListCreatedDocFindMql.iterator(); iterFindDoc.hasNext();) {
							String sFindDoc = (String) iterFindDoc.next();
							StringList sFindDocSplit = FrameworkUtil.split(sFindDoc, "|");
							String sFindDocRevisionCheckInM = (String) sFindDocSplit.get(4);
							
							if(UIUtil.isNotNullAndNotEmpty(sFindDocRevisionCheckInM) && sFindDocRevisionCheckInM.equals(sTempRevision)){
								sFindDocId = (String) sFindDocSplit.get(3);
								break;
							}
							
						}
						int checkCount = 0;
						ContextUtil.startTransaction(context, true);
						if(UIUtil.isNotNullAndNotEmpty(sFindDocId)){
							DomainObject dObjDoc = new DomainObject(sFindDocId);
							String minorVersionId = "";
						
							minorVersionId = (String)dObjDoc.getInfo(context, "from[Active Version].to.id");
							DomainObject minorDobj = new DomainObject();
							String sDocDescription = dObjDoc.getDescription(context);
							String minorObjTitle = "";
							if(UIUtil.isNotNullAndNotEmpty(minorVersionId)){
							
							minorDobj.setId(minorVersionId);
							minorObjTitle = minorDobj.getAttributeValue(context, "Title");
							}
							String existName = dObjDoc.getName(context);
							existName = isVaildNullData(existName);
							
							
						if (!existName.equals(sRealName)) {
							dObjDoc.setName(context, sRealName);
							dObjDoc.setAttributeValue(context, "Title", sRef_FileName);
							checkCount = 1;
							if ((dObjDoc.isKindOf(context, "CATPart") || dObjDoc.isKindOf(context, "CATProduct") || dObjDoc.isKindOf(context, "CATDrawing"))) {
								if (!minorObjTitle.equals(sRef_FileName)) {
									minorDobj.setAttributeValue(context, "Title", sRef_FileName);
								}

								AttributeList localAttributeList = new AttributeList();
								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION), sDetailedDescription));
								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER), s3dCADIdentifier));
								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE), sDocumentType));
								if ("CATDrawing".equals(sType)) {
									localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_PART_DRAWING_NO), sRelated_PartName));
									localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE), sScale));
									localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE), sPageSize));
								}

								if ((cdmConstantsUtil.TYPE_CATPART).equals(sType)) {
									localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS), sMassEstimated));
								}

								if ((cdmConstantsUtil.TYPE_CATPART).equals(sType) || (cdmConstantsUtil.TYPE_CATPRODUCT).equals(sType)) {
									localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE), sSurfaceArea));
								}
								dObjDoc.setAttributeValues(context, localAttributeList);
								checkCount = 2;
							} else if (!(dObjDoc.isKindOf(context, "CATPart") || dObjDoc.isKindOf(context, "CATProduct") || dObjDoc.isKindOf(context, "CATDrawing")) && !minorObjTitle.equals(sRef_FileName)) {

								HashMap<String, Object> mAttrMap = new HashMap<String, Object>();
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE, sPageSize);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE, sScale);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_TITLE_TYPE, sTitleType);

								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION, sDetailedDescription);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER, s3dCADIdentifier);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE, sTempFileType);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE, sDocumentType);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS, sMassEstimated);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE, sSurfaceArea);
								dObjDoc.setAttributeValues(context, mAttrMap);

								minorDobj.setAttributeValue(context, "Title", sRef_FileName);
								checkCount = 3;
							} else {

								checkCount = 10;
							}

						} else {

							if ((dObjDoc.isKindOf(context, "CATPart") || dObjDoc.isKindOf(context, "CATProduct") || dObjDoc.isKindOf(context, "CATDrawing"))) {
								AttributeList localAttributeList = new AttributeList();
								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION), sDetailedDescription));
								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER), s3dCADIdentifier));
								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE), sDocumentType));
								if ("CATDrawing".equals(sType)) {
									localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE), sScale));
									localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE), sPageSize));
									localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_PART_DRAWING_NO), sRelated_PartName));
								}

								if ((cdmConstantsUtil.TYPE_CATPART).equals(sType)) {
									localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS), sMassEstimated));
								}

								if ((cdmConstantsUtil.TYPE_CATPART).equals(sType) || (cdmConstantsUtil.TYPE_CATPRODUCT).equals(sType)) {
									localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE), sSurfaceArea));
								}
								String existTitle = dObjDoc.getAttributeValue(context, "Title");
								if (!existTitle.equals(sRef_FileName)) {
									dObjDoc.setAttributeValues(context, localAttributeList);
									minorDobj.setAttributeValue(context, "Title", sRef_FileName);
								}
							}

							if (!(dObjDoc.isKindOf(context, "CATPart") || dObjDoc.isKindOf(context, "CATProduct") || dObjDoc.isKindOf(context, "CATDrawing"))) {
								HashMap<String, Object> mAttrMap = new HashMap<String, Object>();
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE, sPageSize);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE, sScale);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_TITLE_TYPE, sTitleType);

								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION, sDetailedDescription);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER, s3dCADIdentifier);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE, sTempFileType);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE, sDocumentType);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS, sMassEstimated);
								mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE, sSurfaceArea);
								dObjDoc.setAttributeValues(context, mAttrMap);
								
								String existTitle = dObjDoc.getAttributeValue(context, "Title");
								if (!existTitle.equals(sRef_FileName)) {
									dObjDoc.setAttributeValue(context, "Title", sRef_FileName);
									minorDobj.setAttributeValue(context, "Title", sRef_FileName);
								}
							}
						}
						dObjDoc.setAttributeValue(context,cdmConstantsUtil.ATTRIBUTE_CDM_DRAWING_NO, sRelated_PartName);
							if(UIUtil.isNotNullAndNotEmpty(sDescription) && !sDocDescription.equals(sDescription)  ){
								dObjDoc.setDescription(context, sDescription);
								checkCount = 9;
							}else{
								if(UIUtil.isNullOrEmpty(sDescription)){
									dObjDoc.setDescription(context, "");
								}
							}
						}else{
							throw new Exception("bad data");
						}
						successInt++;
						ContextUtil.commitTransaction(context);
						writeSuccessToFile(recordRowNum +"\t"+checkCount+"\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+sRef_FileName);
						
						
						
					} catch (Exception exception) {
						ContextUtil.abortTransaction(context);
						failedInt++;
						String message = exception.getMessage();
						
						if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not a valid type or filetype.")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"1"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST CAD_REF_FILE_NAME FILE DATA .") ){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"2"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR DOCUMENT")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR OBJECT.")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"4"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST REVISION DATA.")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"5"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT FIND FILE.")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"6"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT MATCH ROW INFOMATION")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"7"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not wrong file name and title object.")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"8"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("bad data")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"9"+"\t"+stReadData);
						}
						
						else{
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t"+stReadData);
							
						}
						writeErrorToFile("LineNum(#)"+recordRowNum+"\t"+recordRowTdmxId+"\t"+recordRowRevision);
						exception.printStackTrace(errorStream);

					}finally{
						
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				MqlUtil.mqlCommand(context, "Trigger On");
				MqlUtil.mqlCommand(context, "history on");
				
				writeMessageToConsole("====================================================================================");
				writeMessageToConsole("LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms        \n");
				writeMessageToConsole("End Time :("+cdmCommonExcel.getTimeStamp2() +")  Total Count:("+(totalCount-1)+") Success Count:("+successInt+") notMacthType:("+notMatchTypeCount+"  Fail Count: ("+failedInt+")");
				writeMessageToConsole("==================================================================================== \n");
				closeLogStream();
				
				
				System.out.println("[cdmCADMigration_mxJPO : excuteCadCheckin] end ." + cdmCommonExcel.getTimeStamp2() );
			}
		}
		
		
		/**
		 * 임시로 사용되는 devied output object 생성 및 연결
		 * @param context
		 * @param args
		 * @throws Exception
		 */
		public void tempDeviedOutput(Context context,String[] args)throws Exception{

			
			long startTime = System.currentTimeMillis();
			
			int successInt = 0;
			int failedInt = 0;
			int totalCount = 0;
			int notMatchTypeCount = 0;
			try {
				
				MqlUtil.mqlCommand(context, "Trigger Off");
				MqlUtil.mqlCommand(context, "history off");
				
				System.out.println("[cdmCADMigration_mxJPO : tempDeviedOutput] start ." + cdmCommonExcel.getTimeStamp2() );

				String logFileName = "DeviedOutputM";

//				Map paramMap = new HashMap();
//				paramMap = (Map) JPO.unpackArgs(args);
//				String sFileLocationAndFileName = (String)paramMap.get("fileData");
				if(args.length!=1){
					throw new Exception("The excel path does not exist.");
				}
				String sFileLocationAndFileName = args[0];

				String cadFileLocation = "";
				String cadFileName = "";
				
				cadFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
				cadFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
//				logFileName +="_"+cadFileName.substring(0, cadFileName.lastIndexOf("."));
				// 읽을 파일경로 ,읽을 파일명
				String[] argTest = { cadFileLocation, cadFileName };
				// context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
				initializeM(context, argTest, 2, logFileName);
				
				writeMessageToConsole("====================================================================================");
				writeMessageToConsole("     CAD DATA MIGRATION " + getTimeStamp() + " \n");
				writeMessageToConsole("		Reading input log file from : " + inputDirectory+fileName);
				writeMessageToConsole("		Writing Log files to: " + outputDirectory);
				writeMessageToConsole("====================================================================================\n");
				int lineNumber = 0;
				
				StringList stListHeader = new StringList();
				String recordRowNum = "";
				String recordRowTdmxId = "";
				String recordRowRevision = "";
				
				String stReadData = "";
						
				MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
				IEFGlobalCache cache = new IEFGlobalCache();
				MCADGlobalConfigObject globalConfigObject = null;
				MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
				
				bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
				while ((stReadData = bufferReader.readLine()) != null) {
					StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
					try {
						if (lineNumber == 0) {
							stListHeader = stListReadData;
							writeFailToFile("errorTime"+"\t"+"errorNum"+"\t"+stReadData.toString());
							lineNumber++;
							continue;
						}
						lineNumber++;
						
						
						totalCount = lineNumber;
						LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();
						int readLineSize = stListReadData.size();
						int headerSize = stListHeader.size();

						if (headerSize != readLineSize) {
							String errorMessage = "NOT MATCH" + stListReadData.toString() ;
							throw new Exception(errorMessage);
						}

						for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {

							String stTempCadInfos = ((String) stListReadData.get(stListNum)).trim();
							String stTempCadInfosHeader = ((String) stListHeader.get(stListNum)).trim();
							stTempCadInfos = isVaildNullData(stTempCadInfos);
							linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);

						}

						recordRowNum = (String) linkedCadHM.get("#");
						String sTempType = (String) linkedCadHM.get("CLS_NAME"); // 1,Type
						String sTdmxId		= (String) linkedCadHM.get("TDMX_ID"); 
						String sTempRevision = (String) linkedCadHM.get("REVISION"); // 3,Revision
//						String sRelated_PartName = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6
						String sFileType = (String) linkedCadHM.get("FILE_TYPE"); // 14, //Real Type
						String sFileName = (String) linkedCadHM.get("FILE_NAME"); // 15, //Real File
						String sRef_FileName = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); // 16,ORIGINAL FILE
//						String sRelated_PartRev = (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
						
						String valutObjectId = (String) linkedCadHM.get("VAULT_OBJECT_ID"); // 36,
						String sObjectRealName = (String) linkedCadHM.get("OBJECT_NAME"); 
						String sRealName = ""; 
								
//						if(sObjectRealName.contains("'")){
//							sRealName = sObjectRealName.replaceAll("'", "_");
//						}else{
//							sRealName = sObjectRealName;
//						}
						sRealName = sObjectRealName;
						sRealName = sRealName.trim();
						String strFormat = "";
						recordRowTdmxId= sTdmxId;
						recordRowRevision = sTempRevision;					
						String strWorkspacePath = "F:\\CDM_VALUT\\";
						if("WJ Released".equals(valutObjectId)){
							strWorkspacePath +="Wj Released";
						}else{
							strWorkspacePath +=valutObjectId;
						}

						String sType = "";
						String sCAD_Type = "";
						boolean isExistCAD = false;
						boolean isExistCADNotCAT = false;
						boolean bFileTypeCheck = false;
						
						String sTempFileType = "";
						
						//
						if ("CATIA Product".equals(sFileType)) {
							if ("Assembly".equals(sTempType)) {
//								isCatiaCadModel = true;
								isExistCAD = true;
								strFormat = "asm";
								sCAD_Type = "assembly";
								sType = cdmConstantsUtil.TYPE_CATPRODUCT;
							}
						}else if("AutoCAD".equals(sFileType)){
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
							}
							if ("Image Drawing".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
								sType = "cdmImageDrawing";
							}
						}else if("CATIA Drawing".equals(sFileType)){
//							System.out.println("sTempType =-> "+ sTempType);
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
								//PDF ,ZIP 존재가능
							}
							
							if("Image Drawing".equals(sTempType)) {
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
								sType = "cdmImageDrawing";
								sFileType = "Image";							
							}
							
							if("V4 Model".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
								isExistCADNotCAT = true;
							}
							
							if("Drawing".equals(sTempType)){
								strFormat = "drw";
								sCAD_Type = "drawing";
//								isCatiaCadModel = true;
								isExistCAD = true;
								sType = "CATDrawing";
								
							}
							
							//Exchange 는 제외함 
						}else if("DXF".equals(sFileType)){
							sType = "cdmDXF";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}else if("CATIA cgm".equals(sFileType)){
							sType = "cdmCATIAcgm";
							sFileType = "CATIA cgm";
							isExistCADNotCAT = true;
						}else if("STEP".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMSTEP;
							isExistCADNotCAT = true;
						}else if("CATIA Material".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMCATIAMATERIAL;
							isExistCADNotCAT = true;
						}else if("CATIA Model".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CATPART;
//								isCatiaCadModel = true;
								isExistCAD = true;
								strFormat = "prt";
								sCAD_Type = "component";
							}
							if("V4 Model".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
								isExistCADNotCAT = true;
							}
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
							}
							
						}else if("CATIA Part".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CATPART;
//								isCatiaCadModel = true;
								isExistCAD = true;
								strFormat = "prt";
								sCAD_Type = "component";
							}
						}else if("IGES".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = "cdmIGES";
								bFileTypeCheck = true;
//								sFileType = "";
							}
						}else if("PDF".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
								sType = "cdmImageDrawing";
								sFileType = "Image";
//								sFileType = "";
							}
							if("AutoCAD".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								bFileTypeCheck = true;
								isExistCADNotCAT = true;
							}
						}else if("STEP".equals(sFileType)){
							sType = "cdmSTEP";
							isExistCADNotCAT = true;
						}else if("Text".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
								sType = "cdmImageDrawing";
								sFileType = "Image";
							}
						}else if("Unigraphics".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
								sType = "cdmImageDrawing";
							}
							if("UG NX Drawing".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
								isExistCADNotCAT = true;
							}
							if("UG NX Part".equals(sFileType)){
								sType = cdmConstantsUtil.TYPE_CDMNXPART;
								isExistCADNotCAT = true;
							}
						}else if("ZIP".equals(sFileType)){
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//								sFileType = "";
								bFileTypeCheck = true;
								isExistCADNotCAT = true;
							}
						}else if("CATIA cgr".equals(sFileType)){
							sType = "cdmCATIAcgr";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}else if("CATIA Material".equals(sFileType)){
							sType = "cdmCATIAMaterial";
//							sFileType = "";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
							
						}else{
							
						}
						
						if (StringUtils.isEmpty(sType)) {
							// Image Drawing 파일 타입이 존재하지 않는 경우 제외
							sType = "cdmImageDrawing";
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sFileType = "Image";
						}
						
						if(bFileTypeCheck){
							sTempFileType = "";
						}else{
							sTempFileType = sFileType;
						}
						
						
						File file = new File(strWorkspacePath+File.separator+sFileName);
						boolean isEixstFile = file.exists();
						if(!isEixstFile){
							String errorMessage = "NOT FIND FILE. "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;;
							throw new Exception(errorMessage);
						}
						String tempCgrFileName = "";
						String temp3dxmlFileName = "";
						String tempCgmFileName = "";
						
						String tempCgrObjectFileName = "";
						String temp3dxmlObjectFileName = "";
						String tempCgmObjectFileName = "";
						
						tempCgrFileName = sFileName;
						temp3dxmlFileName = sFileName;
						tempCgmFileName = sFileName;
						
						int intLastCGRExtension = tempCgrFileName.lastIndexOf(".");
						tempCgrFileName = tempCgrFileName.substring(0, intLastCGRExtension)+"."+sType+".cgr";
						
						int intLast3dxmlExtension = temp3dxmlFileName.lastIndexOf(".");
						temp3dxmlFileName = temp3dxmlFileName.substring(0, intLast3dxmlExtension)+"."+sType+".3dxml";
					
						int intLastCgmExtension = tempCgmFileName.lastIndexOf(".");
						tempCgmFileName = tempCgmFileName.substring(0,intLastCgmExtension)+"."+sType+ ".cgm";
								
						File cgrFile = new File(strWorkspacePath+File.separator+tempCgrFileName);
						boolean isExistCGRFile = cgrFile.exists();
						
						File xmlFile = new File(strWorkspacePath+File.separator+temp3dxmlFileName);
						boolean isExistXmlFile = xmlFile.exists();
						
						File cgmFile = new File(strWorkspacePath+File.separator+tempCgmFileName);
						boolean isExistCGMFile = cgmFile.exists();
						
						
						//change name
						tempCgrObjectFileName = sRef_FileName;
						temp3dxmlObjectFileName = sRef_FileName;
						tempCgmObjectFileName = sRef_FileName;
						tempCgrObjectFileName = tempCgrObjectFileName.substring(0,tempCgrObjectFileName.lastIndexOf("."))+"."+sType+".cgr";
						temp3dxmlObjectFileName = temp3dxmlObjectFileName.substring(0,temp3dxmlObjectFileName.lastIndexOf("."))+"."+sType+".3dxml";
						tempCgmObjectFileName = tempCgmObjectFileName.substring(0,tempCgmObjectFileName.lastIndexOf("."))+"."+sType+".cgm";
						String sRevisionSeqence = "";
						sRevisionSeqence = sTempRevision;

						if (sRevisionSeqence.contains(".")) {
							StringList sListSplitRevision = FrameworkUtil.split(sRevisionSeqence, ".");
							sRevisionSeqence = (String) sListSplitRevision.get(0);
						}
						
						String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
//						String relViewable = "Viewable";
//						String cgrObjectId = "";
//						String xmlObjectId = "";
						String cgmObjectId = "";
						/*
						 * *********************************************************
						 * object name 설정. sCAD_REF_FILE_NAME 데이타가 존재하지않는다면 에러 처리.
						 * *********************************************************
						 */
//						String sName = "";
//						String cadMajorFileName = "";
//						String cadMajorExtension = "";
						if (UIUtil.isNotNullAndNotEmpty(sRef_FileName)) {
//							int intLastExtension = sRef_FileName.lastIndexOf(".");
//							cadMajorExtension = sRef_FileName.substring(intLastExtension);
//							sName = sRef_FileName.substring(0, intLastExtension);
//							sName = sName.trim();
						} else {
							String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;
							throw new Exception(sErrorMessage);
						}
						
						
						String checkCADVehicle = "";
						String checkCADProject = "";
						boolean checkCGR = false;
						boolean checkXML = false;
						boolean checkCgm = false;
						String sViewableName = sRealName+"."+sType;
						ContextUtil.startTransaction(context, true);
						if (isExistCAD ) {

							/*
							 * *****************************************************
							 * REVISION 정보가 없다면 에러 처리. REVISION 설정 .
							 * *****************************************************
							 * 
							 */
							if (cdmStringUtil.isEmpty(sRevisionSeqence)) {
								String errorMessage = "NOT EXIST REVISION DATA. ";
								throw new Exception(errorMessage);
							}
							/*sName 값이 중복케이스가 존재하여 임의로 name 데이타 정보 추가하여 tnr의 name 정보로 사용된다. 0103 */
							BusinessObject existBusinessObj = new BusinessObject(sType,sRealName, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
							BusinessObject existMinorBusinessObj = new BusinessObject(sType, sRealName, minorRevString, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
							
							boolean isMajorExist = existBusinessObj.exists(context);
							String reviseCheckM = "";
							String sHasFileExistCheck = "";
							if(isMajorExist){
								reviseCheckM = existBusinessObj.getAttributeValues(context, "cdmRevisionCheckInM").getValue();
								String existId = existBusinessObj.getObjectId(context);
								DomainObject existDObj = new DomainObject(existId);
								
//								sHasFileExistCheck = (String)existDObj.getInfo(context, "format.hasfile");
								
								
							}
							if (isMajorExist && UIUtil.isNotNullAndNotEmpty(reviseCheckM) && reviseCheckM.equals(sTempRevision) ) {
								
//								existBusinessObj.checkinFile(context, false, false, "", strFormat,  sFileName, strWorkspacePath);
								
								String cadId = existBusinessObj.getObjectId(context);
//								if(!sFileName.equals(sRef_FileName)){
//									MqlUtil.mqlCommand(context, "mod bus $1  rename format $2 $3 file $4 $5 ",cadId, strFormat,"!propagaterename",sFileName,sRef_FileName);
//								}
								//xmlObjectId cgrObjectId
								DomainObject cadDobj = new DomainObject(cadId);
								DomainObject viewableDobj = new DomainObject();
								
								String sCGMUsers = cadDobj.getOwner(context).getName();
//								String sViewableUsers = cadDobj.getOwner(context).getName();
//								sViewableUsers = isVaildNullData(sViewableUsers);
								sCGMUsers = isVaildNullData(sCGMUsers);
								
								BusinessObject lastRevivionObj = cadDobj.getLastRevision(context);
								String sLastRevisionObjId = lastRevivionObj.getObjectId(context);
								//cgm 
								if(isExistCGMFile && "CATDrawing".equals(sType) && sLastRevisionObjId.equals(cadId)){
									checkCADVehicle = (String)cadDobj.getInfo(context, "project");
									checkCADProject = (String)cadDobj.getInfo(context, "organization");
									
									String cgmType = "Derived Output";
									String cgmPolicy = "Derived Output TEAM Policy";
									String attributeCADType = "cgmOutput";
									
									DomainObject cgmDboj = new DomainObject();
									String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
									
									cgmDboj.createObject(context, cgmType,sViewableName , minorRevString, cgmPolicy, vault);
									
									cgmObjectId = cgmDboj.getId(context);
									cgmDboj.checkinFile(context, false, false, "", "CGM", tempCgmFileName, strWorkspacePath);
									if(!tempCgrFileName.equals(tempCgrObjectFileName)){
										MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",cgmObjectId, "CGM","!propagaterename",tempCgmFileName,tempCgmObjectFileName);
									}
									checkCgm = true;
									if(UIUtil.isNotNullAndNotEmpty(sCGMUsers) ){
										cgmDboj.setAttributeValue(context, "Originator",sCGMUsers);
									}
//									cgmDboj.setAttributeValue(context, "cdmCheckMigration","Y");
									cgmDboj.setAttributeValue(context, "CAD Type", attributeCADType);
									cgmDboj.setOwner(context, cadDobj.getOwner(context));
									
									DomainRelationship connectDerivedOutRel= new DomainRelationship();
									connectDerivedOutRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Derived Output"),cgmDboj );
									connectDerivedOutRel.setAttributeValue(context, "CAD Object Name", sRealName);
									String minorObjectId = existMinorBusinessObj.getObjectId(context);
									if(UIUtil.isNotNullAndNotEmpty(minorObjectId)){
										DomainObject cadMinorDobj = new DomainObject(minorObjectId);
										DomainRelationship connectMinorDerivedOutRel= new DomainRelationship();
										connectMinorDerivedOutRel = DomainRelationship.connect(context, cadMinorDobj, new RelationshipType("Derived Output"),cgmDboj );
										connectMinorDerivedOutRel.setAttributeValue(context, "CAD Object Name", sRealName);
									}
								}else{
									String errorMessage = "NOT CATDrawing OBJECT. \t type: \t"+sType+"\t Name: \t"+sRealName +"\t rev: \t"+sTempRevision;
									throw new Exception(errorMessage);
									
								}
								
								
								
							} else {
								String errorMessage = "NOT EXIST MAJOR OBJECT. \t type: \t"+sType+"\t Name: \t"+sRealName +"\t rev: \t"+sTempRevision;
								throw new Exception(errorMessage);
							}

						} else {
							String errorMessage = "NOT CATDrawing OBJECT. \t type: \t"+sType+"\t Name: \t"+sRealName +"\t rev: \t"+sTempRevision;
							throw new Exception(errorMessage);
						}
						ContextUtil.commitTransaction(context);
						successInt++;
						boolean bProjectOrg = false;
						/* project org 설정 */
						try {
							checkCADVehicle = isVaildNullData(checkCADVehicle);
							checkCADProject = isVaildNullData(checkCADProject);
							if (isExistCAD && UIUtil.isNotNullAndNotEmpty(checkCADVehicle) && UIUtil.isNotNullAndNotEmpty(checkCADProject) && (UIUtil.isNotNullAndNotEmpty(cgmObjectId)) ) {

//								if (UIUtil.isNotNullAndNotEmpty(cgrObjectId)) {
//									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", cgrObjectId, checkCADProject, checkCADVehicle);
//
//								}
//								if (UIUtil.isNotNullAndNotEmpty(xmlObjectId)) {
//									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", xmlObjectId, checkCADProject, checkCADVehicle);
//								}
								
								if (UIUtil.isNotNullAndNotEmpty(cgmObjectId)) {
									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", cgmObjectId, checkCADProject, checkCADVehicle);
								}
								bProjectOrg = true;
							}else{
								bProjectOrg = false;
							}
						}catch(Exception e4){
							bProjectOrg = false;
						}
						writeSuccessToFile(recordRowNum + "\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+checkXML+"\t"+checkCGR +"\t"+bProjectOrg+"\t"+checkCADProject+"\t"+checkCADVehicle);
//						writeMessageToConsole(recordRowNum + "\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+checkXML+"\t"+checkCGR+"\t"+bProjectOrg+"\t"+checkCADProject+"\t"+checkCADVehicle);
						
						
						
					} catch (Exception exception) {
						ContextUtil.abortTransaction(context);
						failedInt++;
						String message = exception.getMessage();
						writeMessageToConsole(recordRowNum + "\t"+message);
						if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not a valid type or filetype.")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"1"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST CAD_REF_FILE_NAME FILE DATA .") ){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"2"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR DOCUMENT")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR OBJECT.")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"4"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST REVISION DATA.")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"5"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT FIND FILE.")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"6"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT MATCH ROW INFOMATION")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"7"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT CATDrawing OBJECT.")){
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"8"+"\t"+stReadData);
						}
						
						else{
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t"+stReadData);
							
						}
						writeErrorToFile("LineNum(#)"+recordRowNum+"\t"+recordRowTdmxId+"\t"+recordRowRevision);
						exception.printStackTrace(errorStream);

					}finally{
						
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				MqlUtil.mqlCommand(context, "Trigger On");
				MqlUtil.mqlCommand(context, "history on");
				
				writeMessageToConsole("====================================================================================");
				writeMessageToConsole("LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms        \n");
				writeMessageToConsole("End Time :("+cdmCommonExcel.getTimeStamp2() +")  Total Count:("+(totalCount-1)+") Success Count:("+successInt+") notMacthType:("+notMatchTypeCount+"  Fail Count: ("+failedInt+")");
				writeMessageToConsole("==================================================================================== \n");
				closeLogStream();
				
				
				System.out.println("[cdmCADMigration_mxJPO : tempDeviedOutput] end ." + cdmCommonExcel.getTimeStamp2() );
			}
		
		}
		
		/**
		 * CATDrawing 혹은 CATPart 혹은 CATProduct 의 viewable 과 devied output 을 생성및 연결 그리고 CAT대상으로 project organization 
		 *  
		 * @param context
		 * @param args
		 * @throws Exception
		 */
		public void execMajorAndMinorModifyDeviedOutput(Context context,String args[])throws Exception{


			
			long startTime = System.currentTimeMillis();
			
			int successInt = 0;
			int failedInt = 0;
			int totalCount = 0;
			int notMatchTypeCount = 0;
			int cgmCount = 0;
			try {
				
				MqlUtil.mqlCommand(context, "Trigger Off");
				MqlUtil.mqlCommand(context, "history off");
				
				System.out.println("[cdmCADAllMigration : executeMajorMinorCheckin] start ." + cdmCommonExcel.getTimeStamp2() );

				String logFileName = "checkinFileM_Devied";

//				Map paramMap = new HashMap();
//				paramMap = (Map) JPO.unpackArgs(args);
//				String sFileLocationAndFileName = (String)paramMap.get("fileData");
				if(args.length!=1){
					throw new Exception("The excel path does not exist.");
				}
				String sFileLocationAndFileName = args[0];

				String cadFileLocation = "";
				String cadFileName = "";
				
				cadFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
				cadFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
				// 읽을 파일경로 ,읽을 파일명
				String[] argTest = { cadFileLocation, cadFileName };
				// context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
				initializeM(context, argTest, 2, logFileName);
				
				writeMessageToConsole("====================================================================================");
				writeMessageToConsole("     CAD DATA MIGRATION " + getTimeStamp() + " \n");
				writeMessageToConsole("		Reading input log file from : " + inputDirectory+fileName);
				writeMessageToConsole("		Writing Log files to: " + outputDirectory);
				writeMessageToConsole("====================================================================================\n");
				int lineNumber = 0;
				
				StringList stListHeader = new StringList();
				String recordRowNum = "";
				String recordRowTdmxId = "";
				String recordRowRevision = "";
				
				String stReadData = "";
						
				MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
				IEFGlobalCache cache = new IEFGlobalCache();
				MCADGlobalConfigObject globalConfigObject = null;
				MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
				
				bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
				while ((stReadData = bufferReader.readLine()) != null) {
					StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
					try {
						if (lineNumber == 0) {
							stListHeader = stListReadData;
							writeFailToFile("errorTime"+"\t"+"errorNum"+"\t"+stReadData.toString());
							lineNumber++;
							continue;
						}
						lineNumber++;
						
						
						totalCount = lineNumber;
						LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();
						int readLineSize = stListReadData.size();
						int headerSize = stListHeader.size();

						if (headerSize != readLineSize) {
							String errorMessage = "NOT MATCH ROW INFOMATION." + stListReadData.toString() ;
							throw new Exception(errorMessage);
						}

						for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {

							String stTempCadInfos = ((String) stListReadData.get(stListNum)).trim();
							String stTempCadInfosHeader = ((String) stListHeader.get(stListNum)).trim();
							stTempCadInfos = isVaildNullData(stTempCadInfos);
							linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);

						}

						recordRowNum = (String) linkedCadHM.get("#");
						String sTempType = (String) linkedCadHM.get("CLS_NAME"); // 1,Type
						String sTdmxId		= (String) linkedCadHM.get("TDMX_ID"); 
						String sTempRevision = (String) linkedCadHM.get("REVISION"); // 3,Revision
//						String sRelated_PartName = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6
						String sFileType = (String) linkedCadHM.get("FILE_TYPE"); // 14, //Real Type
						String sFileName = (String) linkedCadHM.get("FILE_NAME"); // 15, //Real File
						String sRef_FileName = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); // 16,ORIGINAL FILE
//						String sRelated_PartRev = (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
						
						String valutObjectId = (String) linkedCadHM.get("VAULT_OBJECT_ID"); // 36,
						String sObjectRealName = (String) linkedCadHM.get("OBJECT_NAME"); 
						String sProjectGroup = (String) linkedCadHM.get("PROD_GROUP"); 
						String sVehicle     = (String) linkedCadHM.get("CN_CUST_VEHICLE"); 
						String sRealName = ""; 
						
						sTempType = sTempType.trim();
						sRealName = sObjectRealName;
						sRealName = sRealName.trim();
						String strFormat = "";
						recordRowTdmxId= sTdmxId;
						recordRowRevision = sTempRevision;					
						String strWorkspacePath = "F:\\CDM_VALUT\\";
						if("WJ Released".equals(valutObjectId)){
							strWorkspacePath +="Wj Released";
						}else{
							strWorkspacePath +=valutObjectId;
						}

						String sType = "";
						String sCAD_Type = "";
						boolean isExistCAD = false;
						boolean isExistCADNotCAT = false;
						boolean bFileTypeCheck = false;
						
						String sTempFileType = "";
						
						//
						if ("CATIA Product".equals(sFileType)) {
							if ("Assembly".equals(sTempType)) {
//								isCatiaCadModel = true;
								isExistCAD = true;
								strFormat = "asm";
								sCAD_Type = "assembly";
								sType = cdmConstantsUtil.TYPE_CATPRODUCT;
							}
						}else if("AutoCAD".equals(sFileType)){
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
							}
							if ("Image Drawing".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
								sType = "cdmImageDrawing";
							}
						}else if("CATIA Drawing".equals(sFileType)){
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
								//PDF ,ZIP 존재가능
							}
							
							if("Image Drawing".equals(sTempType)) {
								sType = "cdmImageDrawing";
								sFileType = "Image";							
							}
							
							if("V4 Model".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
								isExistCADNotCAT = true;
							}
							
							if("Drawing".equals(sTempType)){
								strFormat = "drw";
								sCAD_Type = "drawing";
								isExistCAD = true;
								sType = "CATDrawing";
								
							}
							
							//Exchange 는 제외함 
						}else if("DXF".equals(sFileType)){
							sType = "cdmDXF";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}else if("CATIA cgm".equals(sFileType)){
							sType = "cdmCATIAcgm";
							sFileType = "CATIA cgm";
							isExistCADNotCAT = true;
						}else if("STEP".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMSTEP;
							isExistCADNotCAT = true;
						}else if("CATIA Material".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMCATIAMATERIAL;
							isExistCADNotCAT = true;
							bFileTypeCheck = true;
						}else if("CATIA Model".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CATPART;
								isExistCAD = true;
								strFormat = "prt";
								sCAD_Type = "component";
							}
							if("V4 Model".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
								isExistCADNotCAT = true;
								bFileTypeCheck = true;
							}
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
							}
							
						}else if("CATIA Part".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CATPART;
								isExistCAD = true;
								strFormat = "prt";
								sCAD_Type = "component";
							}
						}else if("IGES".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = "cdmIGES";
								bFileTypeCheck = true;
							}
						}else if("PDF".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
								sType = "cdmImageDrawing";
								sFileType = "Image";
							}
							if("AutoCAD".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								bFileTypeCheck = true;
								isExistCADNotCAT = true;
							}
						}else if("STEP".equals(sFileType)){
							sType = "cdmSTEP";
							isExistCADNotCAT = true;
						}else if("Text".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
								sType = "cdmImageDrawing";
								sFileType = "Image";
							}
						}else if("Unigraphics".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
								sType = "cdmImageDrawing";
							}
							if("UG NX Drawing".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
								isExistCADNotCAT = true;
							}
							if("UG NX Part".equals(sFileType)){
								sType = cdmConstantsUtil.TYPE_CDMNXPART;
								isExistCADNotCAT = true;
							}
						}else if("ZIP".equals(sFileType)){
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								bFileTypeCheck = true;
								isExistCADNotCAT = true;
							}
						}else if("CATIA cgr".equals(sFileType)){
							sType = "cdmCATIAcgr";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}else if("CATIA Material".equals(sFileType)){
							sType = "cdmCATIAMaterial";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
							
						}else{
							
						}
						
						if (StringUtils.isEmpty(sType)) {
							// Image Drawing 파일 타입이 존재하지 않는 경우 제외
							sType = "cdmImageDrawing";
							sFileType = "Image";
						}
						
						if(bFileTypeCheck){
							sTempFileType = "";
						}else{
							sTempFileType = sFileType;
						}
						
						
						File file = new File(strWorkspacePath+File.separator+sFileName);
						boolean isEixstFile = file.exists();
						if(!isEixstFile){
//							String errorMessage = "NOT FIND FILE. "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId+"\t"+sTempRevision;
//							throw new Exception(errorMessage);
						}
						boolean bCgrFileExist = false; 
//						boolean b3dXmlFileExist = false; 
						String tempCgrFileName = "";
						String temp3dxmlFileName = "";
						String tempCgmFileName = "";
						
						String tempCgrObjectFileName = "";
						String temp3dxmlObjectFileName = "";
						String tempCgmObjectFileName = "";
						
						tempCgrFileName = sFileName;
						temp3dxmlFileName = sFileName;
						tempCgmFileName = sFileName;
						
						int intLastCGRExtension = tempCgrFileName.lastIndexOf(".");
						tempCgrFileName = tempCgrFileName.substring(0, intLastCGRExtension)+"."+sType+".cgr";
						
						int intLast3dxmlExtension = temp3dxmlFileName.lastIndexOf(".");
						temp3dxmlFileName = temp3dxmlFileName.substring(0, intLast3dxmlExtension)+"."+sType+".3dxml";
					
						int intLastCgmExtension = tempCgmFileName.lastIndexOf(".");
						tempCgmFileName = tempCgmFileName.substring(0,intLastCgmExtension)+"."+sType+ ".cgm";
								
						File cgrFile = new File(strWorkspacePath+File.separator+tempCgrFileName);
						boolean isExistCGRFile = cgrFile.exists();
						
						File xmlFile = new File(strWorkspacePath+File.separator+temp3dxmlFileName);
						boolean isExistXmlFile = xmlFile.exists();
						
						File cgmFile = new File(strWorkspacePath+File.separator+tempCgmFileName);
						boolean isExistCGMFile = cgmFile.exists();
						
						//change name
						tempCgrObjectFileName = sRef_FileName;
						temp3dxmlObjectFileName = sRef_FileName;
						tempCgmObjectFileName = sRef_FileName;
						
						tempCgrObjectFileName = tempCgrObjectFileName.substring(0,tempCgrObjectFileName.lastIndexOf("."))+"."+sType+".cgr";
						temp3dxmlObjectFileName = temp3dxmlObjectFileName.substring(0,temp3dxmlObjectFileName.lastIndexOf("."))+"."+sType+".3dxml";
						tempCgmObjectFileName = tempCgmObjectFileName.substring(0,tempCgmObjectFileName.lastIndexOf("."))+"."+sType+".cgm";
						String sRevisionSeqence = "";
						sRevisionSeqence = sTempRevision;

						
						String relViewable = "Viewable";
						
						boolean bMinorVersionCheck = false;
						StringList sListSplitRevision = FrameworkUtil.split(sRevisionSeqence, "\\..+");
						String splitMinorRevision = "";
						if(sListSplitRevision.size()>2){
							bMinorVersionCheck = true;
							String sRevisionSequnceSplit = (String)sListSplitRevision.get(2);
							Integer intergerRevisionSequence = Integer.parseInt(sRevisionSequnceSplit);
							intergerRevisionSequence = intergerRevisionSequence-1;
							splitMinorRevision = String.format("%01d", intergerRevisionSequence);
							
							sRevisionSeqence = (String)sListSplitRevision.get(0); 
							splitMinorRevision = sRevisionSeqence+"."+splitMinorRevision;
						}else{
							sRevisionSeqence = (String)sListSplitRevision.get(0); 
						}
						
						String cgrObjectId = "";
						String xmlObjectId = "";
						String cgmObjectId = "";
						
						/*
						 * *********************************************************
						 * object name 설정. sCAD_REF_FILE_NAME 데이타가 존재하지않는다면 에러 처리.
						 * *********************************************************
						 */
						if (UIUtil.isNullOrEmpty(sRef_FileName)) {
							String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;
							throw new Exception(sErrorMessage);
						}
						
						
						String checkCADVehicle = "";
						String checkCADProject = "";
						boolean checkCGR = false;
						boolean checkXML = false;
						boolean checkCgm = false;
						String sViewableName = sRealName+"."+sType;
						//project,org 체크를 위한 boolean
						boolean bCheckMinorversion = false;
						boolean bCheckMajorversion = false;
						boolean bCheckLastMinorversion = false;
						
						String existCADOrDocumentId  = "";
						String existLastVerionConnectCADOrDocumentId  = "";
						String existMajorVerionConnectCADOrDocumentId  = "";
						
						ContextUtil.startTransaction(context, true);
						if (isExistCAD ) {

							/*
							 * *****************************************************
							 * REVISION 정보가 없다면 에러 처리. REVISION 설정 .
							 * *****************************************************
							 * 
							 */
							if (cdmStringUtil.isEmpty(sRevisionSeqence)) {
								String errorMessage = "NOT EXIST REVISION DATA. ";
								throw new Exception(errorMessage);
							}
							/*sName 값이 중복케이스가 존재하여 임의로 name 데이타 정보 추가하여 tnr의 name 정보로 사용된다. 0103 */
							BusinessObject existBusinessObj = new BusinessObject();
							if(bMinorVersionCheck){
								existBusinessObj = new BusinessObject(sType,sRealName, splitMinorRevision, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
							}else{
								existBusinessObj = new BusinessObject(sType,sRealName, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
							}
//							BusinessObject existMinorBusinessObj = new BusinessObject(sType, sRealName, minorRevString, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
					
							String sMajorConnectedLastMinorRevsion = "";
							boolean bLastRevisionCheck = false; //현재 minor object 가 last minor object 인경우 체크
							String sMinorVersionRevision = "";
							String lastAndExistCadVersionId = "";
							String lastVersionId = "";
							boolean isCadObjExist = existBusinessObj.exists(context);
							String sHasFileExistCheck = "";
							
							
							if(isCadObjExist){
								String existId = existBusinessObj.getObjectId(context);
								
								DomainObject existDObj = new DomainObject(existId);
								String sAttrTDMXID = (String)existDObj.getInfo(context, "attribute[cdmTDMXID]");
								if(!sTdmxId.equals(sAttrTDMXID)){
									throw new Exception("not match attribute[cdmTDMXID]");
								}
								sHasFileExistCheck = (String)existDObj.getInfo(context, "format.hasfile");
								existCADOrDocumentId = existId;
								if(bMinorVersionCheck){
									bCheckMinorversion = true;
									 BusinessObject lastBus = existDObj.getLastRevision(context);
									 String lastObjectId = lastBus.getObjectId(context);
									
									 if(existId.equals(lastObjectId)){
										 bLastRevisionCheck = true;
										 bCheckLastMinorversion = true;
										 String  sRelFromVersionOfId = "";
										 
										 lastAndExistCadVersionId = existId ;
										 
										 Map paramDataMap = new HashMap();
										 StringList sListParamData = new StringList();
										 sListParamData.add("from[VersionOf].to.id");
										 sListParamData.add("revision");
										 
										 paramDataMap = existDObj.getInfo(context, sListParamData);
										 sRelFromVersionOfId = (String)paramDataMap.get("from[VersionOf].to.id");
										 sMinorVersionRevision = (String)paramDataMap.get("revision");
										 existLastVerionConnectCADOrDocumentId =  sRelFromVersionOfId ;  
										 //현재 minor object 가 last minor object 인경우 existBusinessObj 변경
										 if(UIUtil.isNotNullAndNotEmpty(sRelFromVersionOfId)){
											 existBusinessObj = new BusinessObject(sRelFromVersionOfId);
										 }else{
											 throw new Exception("not exist major object.");
										 }
									 }
								}else{
									bCheckMajorversion = true;
									String  sRelToVersionOfId = "";
									sRelToVersionOfId = existDObj.getInfo(context, "to[VersionOf].from.id");
									DomainObject relToVersionOfDobj = new DomainObject(sRelToVersionOfId);
									BusinessObject lastVersionBus = new BusinessObject();
									lastVersionBus = relToVersionOfDobj.getLastRevision(context);
									lastVersionId = lastVersionBus.getObjectId(context);
									existMajorVerionConnectCADOrDocumentId = lastVersionId;
									DomainObject sMajorConnectedLastMinorDObj = new DomainObject(lastVersionId);
									sMajorConnectedLastMinorRevsion = sMajorConnectedLastMinorDObj.getRevision(context);
									
								}
							}
							
							if (isCadObjExist &&  "TRUE".equalsIgnoreCase(sHasFileExistCheck)) {
								
//								existBusinessObj.checkinFile(context, false, false, "", strFormat,  sFileName, strWorkspacePath); 
//								
								String cadId = existBusinessObj.getObjectId(context);
//								if(!sFileName.equals(sRef_FileName)){
//									MqlUtil.mqlCommand(context, "mod bus $1  rename format $2 $3 file $4 $5 ",cadId, strFormat,"!propagaterename",sFileName,sRef_FileName);
//								}
								// owner , project ,organization,
								DomainObject cadDobj = new DomainObject(cadId);
								DomainObject viewableDobj = new DomainObject();
								
								String sCgmUsers = cadDobj.getOwner(context).getName();
								sCgmUsers = isVaildNullData(sCgmUsers);
								String sViewableUsers = cadDobj.getOwner(context).getName();
								sViewableUsers = isVaildNullData(sViewableUsers);
								
//								checkCADVehicle = sVehicle;
//								checkCADProject = sProjectGroup;
//								checkCADVehicle = (String)cadDobj.getInfo(context, "project");
//								checkCADProject = (String)cadDobj.getInfo(context, "organization");
								
//								BusinessObject lastRevivionObj = cadDobj.getLastRevision(context);
//								String sLastRevisionObjId = lastRevivionObj.getObjectId(context);
								//cgm 
								// // 임시로 cgm 주석처리함 다시 cgm 주석풀것 2.5 start 
								if(isExistCGMFile && "CATDrawing".equals(sType) ){
									
									String cgmType = "Derived Output";
									String cgmPolicy = "Derived Output TEAM Policy";
									String attributeCADType = "cgmOutput";
									
									DomainObject cgmDboj = new DomainObject();
									String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
									
									if(bMinorVersionCheck && !bLastRevisionCheck){
										cgmDboj.createObject(context, cgmType,sViewableName , splitMinorRevision, cgmPolicy, vault);
									}else if(bMinorVersionCheck && bLastRevisionCheck){
										cgmDboj.createObject(context, cgmType,sViewableName ,sMinorVersionRevision , cgmPolicy, vault);
									}else{
										cgmDboj.createObject(context, cgmType,sViewableName , sMajorConnectedLastMinorRevsion, cgmPolicy, vault);
									}
									cgmObjectId = cgmDboj.getId(context);
									cgmDboj.checkinFile(context, false, false, "", "CGM", tempCgmFileName, strWorkspacePath);
									if(!tempCgmFileName.equals(tempCgmObjectFileName)){
										MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",cgmObjectId, "CGM","!propagaterename",tempCgmFileName,tempCgmObjectFileName);
									}
									checkCgm = true;
									
									if(UIUtil.isNotNullAndNotEmpty(sCgmUsers)){
										cgmDboj.setAttributeValue(context, "Originator",sCgmUsers);
										cgmDboj.setOwner(context, cadDobj.getOwner(context));
									}
										cgmDboj.setAttributeValue(context, "cdmCheckMigration","Y");
										cgmDboj.setAttributeValue(context, "CAD Type", attributeCADType);
									
									DomainRelationship connectDerivedOutRel= new DomainRelationship();
									connectDerivedOutRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Derived Output"),cgmDboj );
									connectDerivedOutRel.setAttributeValue(context, "CAD Object Name", sRealName);
									
									String minorObjectId = "";
									
									if(bMinorVersionCheck && bLastRevisionCheck){
										minorObjectId = lastAndExistCadVersionId;
									}else if(!bMinorVersionCheck){
										minorObjectId = lastVersionId;
									}
									if(UIUtil.isNotNullAndNotEmpty(minorObjectId)){
										DomainObject cadMinorDobj = new DomainObject(minorObjectId);
										DomainRelationship connectMinorDerivedOutRel= new DomainRelationship();
										connectMinorDerivedOutRel = DomainRelationship.connect(context, cadMinorDobj, new RelationshipType("Derived Output"),cgmDboj );
										connectMinorDerivedOutRel.setAttributeValue(context, "CAD Object Name", sRealName);
									}
									
								}
								// 임시로 cgm 주석처리함 다시 cgm 주석풀것 2.5 end 
								//cgr ,3dxml
								if((isExistCGRFile || isExistXmlFile)  ){
									
									if(isExistCGRFile){
										String viewcgrType = "CgrViewable";
										String view3dXmlPolicy = "Viewable TEAM Policy";
										String attributeCADType = "cgrOutput";
										
										DomainObject cgrDboj = new DomainObject();
										String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
										//
										if(bMinorVersionCheck && !bLastRevisionCheck){
											cgrDboj.createObject(context, viewcgrType,sViewableName , splitMinorRevision, view3dXmlPolicy, vault);
										}else if(bMinorVersionCheck && bLastRevisionCheck){
											cgrDboj.createObject(context, viewcgrType,sViewableName ,sMinorVersionRevision , view3dXmlPolicy, vault);
										}else{
											cgrDboj.createObject(context, viewcgrType,sViewableName , sMajorConnectedLastMinorRevsion, view3dXmlPolicy, vault);
										}
										cgrObjectId = cgrDboj.getObjectId(context);
										BusinessObject busCgr = new BusinessObject(cgrObjectId);
										busCgr.checkinFile(context, false, false, "", "CGR", tempCgrFileName, strWorkspacePath);
//										busCgr.checkinFile(context, false, false, null, "CGR", "STORE", tempCgrFileName, strWorkspacePath);
										if(!tempCgrFileName.equals(tempCgrObjectFileName)){
											MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",cgrObjectId, "CGR","!propagaterename",tempCgrFileName,tempCgrObjectFileName);
										}
										
										
										checkCGR = true;
										if(UIUtil.isNotNullAndNotEmpty(sViewableUsers)){
											busCgr.setAttributeValue(context, "Originator",sViewableUsers);
											busCgr.setOwner(context, cadDobj.getOwner(context));
										}
											busCgr.setAttributeValue(context, "cdmCheckMigration","Y");
											busCgr.setAttributeValue(context, "CAD Type", attributeCADType);
										viewableDobj.setId(cgrObjectId);
										DomainRelationship connectRel= new DomainRelationship();
										connectRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
										connectRel.setAttributeValue(context, "CAD Object Name", sRealName);
										
										String minorObjectId = "";
										if(bMinorVersionCheck && bLastRevisionCheck){
											minorObjectId = lastAndExistCadVersionId;
										}else if(!bMinorVersionCheck){
											minorObjectId = lastVersionId;
										}
										if(UIUtil.isNotNullAndNotEmpty(minorObjectId)){
											DomainObject cadMinorDobj = new DomainObject(minorObjectId);
											DomainRelationship connectMinorDerivedOutRel= new DomainRelationship();
											connectMinorDerivedOutRel = DomainRelationship.connect(context, cadMinorDobj, new RelationshipType("Viewable"),viewableDobj );
											connectMinorDerivedOutRel.setAttributeValue(context, "CAD Object Name", sRealName);
										}
										successInt++;
									}
////									//연결한 CAT originator 혹은 Person 정보와 일치시킨다.  없으면 admin
////									
//									if (isExistXmlFile) {
	//
//										String view3dXmlType = "3dxmlViewable";
//										String view3dXmlPolicy = "Viewable TEAM Policy";
//										String attributeCADType = "3dxmlOutput";
//										String originator = "";
//										cadDobj.setId(cadId);
//										DomainObject xmlDboj = new DomainObject();
//										String vault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
//										
//										BusinessObject CheckBus = new BusinessObject(view3dXmlType,sViewableName,minorRevString,vault);
//										if(CheckBus.exists(context)){
//											System.out.println("exist xml"+CheckBus.getObjectId(context));
//										}
//										xmlDboj.createObject(context, view3dXmlType, sViewableName, minorRevString, view3dXmlPolicy, vault);
//										xmlObjectId = xmlDboj.getObjectId(context);
//										xmlDboj.setAttributeValue(context, "CAD Type", attributeCADType);
//										BusinessObject busXml = new BusinessObject(xmlObjectId);
//										busXml.checkinFile(context, false, false, "", "3DXML", temp3dxmlFileName, strWorkspacePath);
////										busXml.checkinFile(context, false, false, null, "3DXML", "STORE", temp3dxmlFileName, strWorkspacePath);
//										if(!temp3dxmlFileName.equals(temp3dxmlObjectFileName)){
//											MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file  $4 $5", xmlObjectId, "3DXML", "!propagaterename",temp3dxmlFileName, temp3dxmlObjectFileName);
//										}
//										busXml.setOwner(context, cadDobj.getOwner(context));
//										// DomainRelationship viewable = new
//										// DomainRelationship();
//										// viewable.connect(context, xmlObjectId,
//										// relViewable, paramDomainObject2)
//										checkXML = true;
//										if(UIUtil.isNotNullAndNotEmpty(sViewableUsers)){
//											busXml.setAttributeValue(context, "Originator",sViewableUsers);
//											busXml.setAttributeValue(context, "cdmCheckMigration","Y");
//											busXml.setOwner(context, cadDobj.getOwner(context));
//										}
	//
//										viewableDobj.setId(xmlObjectId);
//										DomainRelationship connectRel = new DomainRelationship();
//										connectRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
////										connectRel.setAttributeValue(context, "CAD Object Name", sName);
//										connectRel.setAttributeValue(context, "CAD Object Name", sRealName);
//										if (existMinorBusinessObj.exists(context)) {
	//
//											cadDobj.setId(existMinorBusinessObj.getObjectId(context));
//											DomainRelationship connectMinorRel = new DomainRelationship();
//											connectMinorRel = DomainRelationship.connect(context, cadDobj, new RelationshipType("Viewable"), viewableDobj);
//											connectMinorRel.setAttributeValue(context, "CAD Object Name", sRealName);
////											connectMinorRel.setAttributeValue(context, "CAD Object Name", sName);
//										}
//									}
								}
//								successInt++;
								
								
							} else {
								String errorMessage = "";
							
//								if (!isCadObjExist &&  "FALSE".equalsIgnoreCase(sHasFileExistCheck)) {
//									errorMessage = "The major object does not exist. \t "+sType+" \t "+sFileType+" \t"+sTdmxId+" \t"+sTempRevision;
//								}else if(isCadObjExist && !"FALSE".equalsIgnoreCase(sHasFileExistCheck) ){
//									errorMessage = "NOT EXIST MAJOR OBJECT. \t"+sType+"\t "+sRealName +"\t"+sTdmxId+" \t"+sTempRevision;
//								}else{
//									errorMessage = "OBJECT. \t"+sType+"\t "+sRealName +"\t"+sTdmxId+" \t"+sTempRevision;
//								}
								if(!isCadObjExist){
									errorMessage = "NOT EXIST MAJOR OBJECT. \t"+sType+"\t "+sRealName +"\t"+sTdmxId+" \t"+sTempRevision;
									throw new Exception(errorMessage);
								}
							}
						} 
						
						// 임시 
						else{
							String errorMessage = "cdmMandoCADModel EXIST MAJOR OBJECT. \t"+sType+"\t "+sRealName +"\t"+sTdmxId+" \t"+sTempRevision;
							throw new Exception(errorMessage);
						}
						
//						else {
//							/*
//							 * Document 타입일 경우 Document 의 경우 'Document Release'
//							 * policy 인 object 에 모든 파일이 저장되며 revision의 object의 경우에도
//							 * 파일이 이동하지않고 변경한 데이타들이 저장 파일 이 추가 될
//							 * cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성
//							 */
//
//							strFormat = "generic";
////							BusinessObject existdocumentBusObj = new BusinessObject(sType, sRealName, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//							BusinessObject existdocumentBusObj = new BusinessObject();
//							
//							if(bMinorVersionCheck){
//								String mqlQuery = "temp query bus $1 $2 $3 where $4 select $5 dump $6";
////								String queryWhere = "attribute[cdmTDMXID] == '"+sTdmxId+"' && attribute[cdmRevisionCheckInM] == '"+sTempRevision+"' ";
//								String queryWhere = "attribute[cdmTDMXID] == '"+sTdmxId+"' && attribute[cdmRevisionCheckInM] == '"+sTempRevision+"' ";
//								String queryMql  = MqlUtil.mqlCommand(context,
//													mqlQuery,sType,"*","*", queryWhere,"id","|");
//								
//								StringList sListQuery = new StringList();
//								sListQuery = FrameworkUtil.split(queryMql, "|");
//								if(sListQuery.size()>2){
//									String minorDocumentId = (String)sListQuery.get(3);
//									existdocumentBusObj = new BusinessObject(minorDocumentId);
//								}else{
//									throw new Exception("The minor object does not exist.\t"+sType+"\t "+sRealName +"\t"+sTdmxId+" \t"+sTempRevision);
//								}
//
//							}else{
//								String mqlQuery = "temp query bus $1 $2 $3 where $4 select $5 dump $6";
//								String queryWhere = "attribute[cdmTDMXID] == '"+sTdmxId+"' && attribute[cdmRevisionCheckInM] == '"+sTempRevision+"' && revision == '"+sRevisionSeqence+"' ";
//								String queryMql  = MqlUtil.mqlCommand(context,
//													mqlQuery,sType,"*","*", queryWhere,"id","|");
//							}
//							boolean isDocumentObjExist = existdocumentBusObj.exists(context);
//							
//							boolean bLastRevisionDocumentCheck = false;
////							String reviseCheckM = "";
//							String sHasFileExistDocumentCheck = "";
//							if(isDocumentObjExist){
////								reviseCheckM = existdocumentBusObj.getAttributeValues(context, "cdmRevisionCheckInM").getValue();
//								String existDocumentId = existdocumentBusObj.getObjectId(context);
//								DomainObject existDocumentDObj = new DomainObject(existDocumentId);
//								sHasFileExistDocumentCheck = (String)existDocumentDObj.getInfo(context, "format.hasfile");
//								
//								
//								if(bMinorVersionCheck){
//									BusinessObject lastVersionDocumentBus = existDocumentDObj.getLastRevision(context);
//									 String lastDocumentObjectId = lastVersionDocumentBus.getObjectId(context);
//								
//									 if(existDocumentId.equals(lastVersionDocumentBus)){
//										 bLastRevisionDocumentCheck = true;
//
//										 Map paramDataMap = new HashMap();
//										 StringList sListParamData = new StringList();
////										 sListParamData.add("revision");
//										 sListParamData.add("to[Active Version].from.id");
//										 
//										 paramDataMap = existDocumentDObj.getInfo(context, sListParamData);
////										 sMinorVersionRevision = (String)paramDataMap.get("revision");
//										 String majorDocumentId = "";
//										 majorDocumentId = (String)paramDataMap.get("to[Active Version].from.id");
//										 if(UIUtil.isNotNullAndNotEmpty(majorDocumentId)){
//											 existdocumentBusObj = new BusinessObject(majorDocumentId);
//										 }
//									 }
//								}
//								
//							}else{
//								
//							}
//							
////							if (isMajorDocumentObjExist && UIUtil.isNotNullAndNotEmpty(reviseCheckM) && reviseCheckM.equals(sTempRevision) && "FALSE".equalsIgnoreCase(sHasFileExistDocumentCheck)) {
////							if (isDocumentObjExist  && "FALSE".equalsIgnoreCase(sHasFileExistDocumentCheck)) {
////								existdocumentBusObj.checkinFile(context, false, false, "", strFormat, sFileName, strWorkspacePath);
////
////								String documentBusId= existdocumentBusObj.getObjectId(context);
////								if(!sFileName.equals(sRef_FileName)){
////									MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",documentBusId, strFormat,"!propagaterename",sFileName,sRef_FileName);
////								}
////							} else {
////								String errorMessage = "";
////								if(!isDocumentObjExist && "FALSE".equalsIgnoreCase(sHasFileExistDocumentCheck)){
////									//String errorMessage = "NOT FIND FILE. "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;;
////									 errorMessage = "The major object does not exist. \t "+sType+" \t "+sFileType+" \t"+sTdmxId+" \t"+sTempRevision;
////								}else if(isDocumentObjExist && "TRUE".equalsIgnoreCase(sHasFileExistDocumentCheck)){
////									 errorMessage = "The file already exists.  \t "+sType+"\t"+sFileType +"\t"+sTempRevision;
////								}else{
////									errorMessage = "object exist \t"+isDocumentObjExist+"\t not exist"+sHasFileExistDocumentCheck +"\t "+sType+"\t"+sFileType +"\t"+sTempRevision;
////								}
////								throw new Exception(errorMessage);
////							}
//
//						}
						ContextUtil.commitTransaction(context);
						successInt++;
						boolean bProjectOrg = false;
						/* project org 설정 */
						try {
						
							checkCADVehicle = isVaildNullData(sVehicle);
							checkCADProject = isVaildNullData(sProjectGroup);
							
//							if (isExistCAD && UIUtil.isNotNullAndNotEmpty(checkCADVehicle) && UIUtil.isNotNullAndNotEmpty(checkCADProject) && (UIUtil.isNotNullAndNotEmpty(cgmObjectId))) {
							if (isExistCAD && UIUtil.isNotNullAndNotEmpty(checkCADVehicle) && UIUtil.isNotNullAndNotEmpty(checkCADProject) ) {

								if (UIUtil.isNotNullAndNotEmpty(cgrObjectId)) {
									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", cgrObjectId, checkCADProject, checkCADVehicle);
	
								}
//								if (UIUtil.isNotNullAndNotEmpty(xmlObjectId)) {
//									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", xmlObjectId, checkCADProject, checkCADVehicle);
//								}
								if (UIUtil.isNotNullAndNotEmpty(cgmObjectId)) {
									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", cgmObjectId, checkCADProject, checkCADVehicle);
									
								}
								if(bCheckLastMinorversion ){
									
									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", existCADOrDocumentId, checkCADProject, checkCADVehicle);
									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", existLastVerionConnectCADOrDocumentId, checkCADProject, checkCADVehicle);
								}else if(bCheckMajorversion){
									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", existCADOrDocumentId, checkCADProject, checkCADVehicle);
									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3",existMajorVerionConnectCADOrDocumentId , checkCADProject, checkCADVehicle);
								}else{
									MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", existCADOrDocumentId, checkCADProject, checkCADVehicle);
									
								}
								
								if(bCheckMinorversion)
								bProjectOrg = true;
							}else{
								bProjectOrg = false;
							}
						}catch(Exception e4){
							bProjectOrg = false;
						}
						writeSuccessToFile(recordRowNum + "\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+checkXML+"\t"+checkCGR +"\t"+checkCgm+"\t"+bProjectOrg+"\t"+checkCADProject+"\t"+checkCADVehicle);
//						writeMessageToConsole(recordRowNum + "\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+checkXML+"\t"+checkCGR+"\t"+bProjectOrg+"\t"+checkCADProject+"\t"+checkCADVehicle);
						if(checkCgm){
							cgmCount++;
						}
						
						
					} catch (Exception exception) {
						ContextUtil.abortTransaction(context);
						failedInt++;
						String message = exception.getMessage();
						
						if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not a valid type or filetype.")){
							writeMessageToConsole(recordRowNum + "\t"+"1"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"1"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST CAD_REF_FILE_NAME FILE DATA .") ){
							writeMessageToConsole(recordRowNum + "\t"+"2"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"2"+"\t"+stReadData);
							
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR DOCUMENT")){
							writeMessageToConsole(recordRowNum + "\t"+"3"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR OBJECT.")){
							
							writeMessageToConsole(recordRowNum + "\t"+"4"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"4"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST REVISION DATA.")){
							writeMessageToConsole(recordRowNum + "\t"+"5"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"5"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT FIND FILE.")){
							writeMessageToConsole(recordRowNum + "\t"+"6"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"6"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT MATCH ROW INFOMATION.")){
							writeMessageToConsole(recordRowNum + "\t"+"7"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"7"+"\t"+stReadData);
//						
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("The major object does not exist.")){
							writeMessageToConsole(recordRowNum + "\t"+"8"+" \t "+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+" \t "+"8"+"\t "+stReadData);
							
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("The file already exists.")){
							writeMessageToConsole(recordRowNum + "\t"+"9"+" \t "+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+" \t "+"9"+" \t "+stReadData);
						}
						else{
							writeMessageToConsole(recordRowNum + "\t"+"0"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t "+stReadData);
							
						}
						writeErrorToFile("LineNum(#)"+recordRowNum+" \t "+recordRowTdmxId+" \t "+recordRowRevision);
						exception.printStackTrace(errorStream);

					}finally{
						
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				MqlUtil.mqlCommand(context, "Trigger On");
				MqlUtil.mqlCommand(context, "history on");
				
				writeMessageToConsole("====================================================================================");
				writeMessageToConsole("LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms        \n");
				writeMessageToConsole("End Time :("+cdmCommonExcel.getTimeStamp2() +")  Total Count:("+(totalCount-1)+") Success Count:("+successInt+") notMacthType:("+notMatchTypeCount+"  Fail Count: ("+failedInt+") cgmCount: ("+cgmCount+")" );
				writeMessageToConsole("==================================================================================== \n");
				closeLogStream();
				
				
				System.out.println("[cdmCADMigration_mxJPO : executeMajorMinorCheckin] end ." + cdmCommonExcel.getTimeStamp2() );
			}
		
			
		
			
		}
		
		
		//
		/**
		 * 
		 * @param context
		 * @param args
		 * @throws Exception
		 */
		public void setProOrg(Context context,String args[])throws Exception{


			
			long startTime = System.currentTimeMillis();
			
			int successInt = 0;
			int failedInt = 0;
			int totalCount = 0;
			int notMatchTypeCount = 0;
			int cgmCount = 0;
			try {
				
				MqlUtil.mqlCommand(context, "Trigger Off");
				MqlUtil.mqlCommand(context, "history off");
				
				System.out.println("[cdmCADAllMigration : executeMajorMinorCheckin] start ." + cdmCommonExcel.getTimeStamp2() );

				String logFileName = "checkinFileM";

				Map paramMap = new HashMap();
				paramMap = (Map) JPO.unpackArgs(args);
				String sFileLocationAndFileName = (String)paramMap.get("fileData");
//				if(args.length!=1){
//					throw new Exception("The excel path does not exist.");
//				}
//				String sFileLocationAndFileName = args[0];

				String cadFileLocation = "";
				String cadFileName = "";
				
				cadFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
				cadFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
//				logFileName +="_"+cadFileName.substring(0, cadFileName.lastIndexOf("."));
				// 읽을 파일경로 ,읽을 파일명
				String[] argTest = { cadFileLocation, cadFileName };
				// context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
				initializeM(context, argTest, 2, logFileName);
				
				writeMessageToConsole("====================================================================================");
				writeMessageToConsole("     CAD DATA MIGRATION " + getTimeStamp() + " \n");
				writeMessageToConsole("		Reading input log file from : " + inputDirectory+fileName);
				writeMessageToConsole("		Writing Log files to: " + outputDirectory);
				writeMessageToConsole("====================================================================================\n");
				int lineNumber = 0;
				
				StringList stListHeader = new StringList();
				String recordRowNum = "";
				String recordRowTdmxId = "";
				String recordRowRevision = "";
				
				String stReadData = "";
						
				MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
				IEFGlobalCache cache = new IEFGlobalCache();
				MCADGlobalConfigObject globalConfigObject = null;
				MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
				
				bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
				while ((stReadData = bufferReader.readLine()) != null) {
					StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
					try {
						if (lineNumber == 0) {
							stListHeader = stListReadData;
							writeFailToFile("errorTime"+"\t"+"errorNum"+"\t"+stReadData.toString());
							lineNumber++;
							continue;
						}
						lineNumber++;
						
						
						totalCount = lineNumber;
						LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();
						int readLineSize = stListReadData.size();
						int headerSize = stListHeader.size();

						if (headerSize != readLineSize) {
							String errorMessage = "NOT MATCH ROW INFOMATION." + stListReadData.toString() ;
							throw new Exception(errorMessage);
						}

						for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {

							String stTempCadInfos = ((String) stListReadData.get(stListNum)).trim();
							String stTempCadInfosHeader = ((String) stListHeader.get(stListNum)).trim();
							stTempCadInfos = isVaildNullData(stTempCadInfos);
							linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);

						}

						recordRowNum = (String) linkedCadHM.get("#");
						String sTempType = (String) linkedCadHM.get("CLS_NAME"); // 1,Type
						String sTdmxId		= (String) linkedCadHM.get("TDMX_ID"); 
						String sTempRevision = (String) linkedCadHM.get("REVISION"); // 3,Revision
//						String sRelated_PartName = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6
						String sFileType = (String) linkedCadHM.get("FILE_TYPE"); // 14, //Real Type
						String sFileName = (String) linkedCadHM.get("FILE_NAME"); // 15, //Real File
						String sRef_FileName = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); // 16,ORIGINAL FILE
//						String sRelated_PartRev = (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,
						
						String valutObjectId = (String) linkedCadHM.get("VAULT_OBJECT_ID"); // 36,
						String sObjectRealName = (String) linkedCadHM.get("OBJECT_NAME"); 
						String sProjectGroup = (String) linkedCadHM.get("PROD_GROUP"); 
						String sVehicle     = (String) linkedCadHM.get("CN_CUST_VEHICLE"); 
						String sRealName = ""; 
								
//						if(sObjectRealName.contains("'")){
//							sRealName = sObjectRealName.replaceAll("'", "_");
//						}else{
//							sRealName = sObjectRealName;
//						}
						
						sTempType = sTempType.trim();
						sRealName = sObjectRealName;
						sRealName = sRealName.trim();
						String strFormat = "";
						recordRowTdmxId= sTdmxId;
						recordRowRevision = sTempRevision;					
						String strWorkspacePath = "F:\\CDM_VALUT\\";
						
						if("WJ Released".equals(valutObjectId)){
							strWorkspacePath +="Wj Released";
						}else{
							strWorkspacePath +=valutObjectId;
						}
						String sType = "";
						String sCAD_Type = "";
						boolean isExistCAD = false;
						boolean isExistCADNotCAT = false;
						boolean bFileTypeCheck = false;
						
						String sTempFileType = "";
						
						//
						if ("CATIA Product".equals(sFileType)) {
							if ("Assembly".equals(sTempType)) {
//								isCatiaCadModel = true;
								isExistCAD = true;
								strFormat = "asm";
								sCAD_Type = "assembly";
								sType = cdmConstantsUtil.TYPE_CATPRODUCT;
							}
						}else if("AutoCAD".equals(sFileType)){
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
							}
							if ("Image Drawing".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
								sType = "cdmImageDrawing";
							}
						}else if("CATIA Drawing".equals(sFileType)){
//							System.out.println("sTempType =-> "+ sTempType);
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
								//PDF ,ZIP 존재가능
							}
							
							if("Image Drawing".equals(sTempType)) {
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
								sType = "cdmImageDrawing";
								sFileType = "Image";							
							}
							
							if("V4 Model".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
								isExistCADNotCAT = true;
							}
							
							if("Drawing".equals(sTempType)){
								strFormat = "drw";
								sCAD_Type = "drawing";
//								isCatiaCadModel = true;
								isExistCAD = true;
								sType = "CATDrawing";
								
							}
							
							//Exchange 는 제외함 
						}else if("DXF".equals(sFileType)){
							sType = "cdmDXF";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}else if("CATIA cgm".equals(sFileType)){
							sType = "cdmCATIAcgm";
							sFileType = "CATIA cgm";
							isExistCADNotCAT = true;
						}else if("STEP".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMSTEP;
							isExistCADNotCAT = true;
						}else if("CATIA Material".equals(sFileType)){
							sType = cdmConstantsUtil.TYPE_CDMCATIAMATERIAL;
							isExistCADNotCAT = true;
							bFileTypeCheck = true;
						}else if("CATIA Model".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CATPART;
//								isCatiaCadModel = true;
								isExistCAD = true;
								strFormat = "prt";
								sCAD_Type = "component";
							}
							if("V4 Model".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
								isExistCADNotCAT = true;
								bFileTypeCheck = true;
							}
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								isExistCADNotCAT = true;
							}
							
						}else if("CATIA Part".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CATPART;
//								isCatiaCadModel = true;
								isExistCAD = true;
								strFormat = "prt";
								sCAD_Type = "component";
							}
						}else if("IGES".equals(sFileType)){
							if("Part".equals(sTempType)){
								sType = "cdmIGES";
								bFileTypeCheck = true;
//								sFileType = "";
							}
						}else if("PDF".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
//								sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
								sType = "cdmImageDrawing";
								sFileType = "Image";
//								sFileType = "";
							}
							if("AutoCAD".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
								bFileTypeCheck = true;
								isExistCADNotCAT = true;
							}
						}else if("STEP".equals(sFileType)){
							sType = "cdmSTEP";
							isExistCADNotCAT = true;
						}else if("Text".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
								sType = "cdmImageDrawing";
								sFileType = "Image";
							}
						}else if("Unigraphics".equals(sFileType)){
							if("Image Drawing".equals(sTempType)){
								sType = "cdmImageDrawing";
							}
							if("UG NX Drawing".equals(sTempType)){
								sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
								isExistCADNotCAT = true;
							}
							if("UG NX Part".equals(sFileType)){
								sType = cdmConstantsUtil.TYPE_CDMNXPART;
								isExistCADNotCAT = true;
							}
						}else if("ZIP".equals(sFileType)){
							if ("AutoCAD".equals(sTempType)) {
								sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
//								sFileType = "";
								bFileTypeCheck = true;
								isExistCADNotCAT = true;
							}
						}else if("CATIA cgr".equals(sFileType)){
							sType = "cdmCATIAcgr";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
						}else if("CATIA Material".equals(sFileType)){
							sType = "cdmCATIAMaterial";
//							sFileType = "";
							bFileTypeCheck = true;
							isExistCADNotCAT = true;
							
						}else{
							
						}
						
						if (StringUtils.isEmpty(sType)) {
							// Image Drawing 파일 타입이 존재하지 않는 경우 제외
							sType = "cdmImageDrawing";
//							sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
							sFileType = "Image";
						}
						
						if(bFileTypeCheck){
							sTempFileType = "";
						}else{
							sTempFileType = sFileType;
						}
						//
						
						
						File file = new File(strWorkspacePath+File.separator+sFileName);
						boolean isEixstFile = file.exists();
						if(!isEixstFile){
							
							//임시 테스트 시작 0207
							if(isExistCAD){
							//임시 테스트 끝
							String errorMessage = "NOT FIND FILE. "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId+"\t"+sTempRevision;
							throw new Exception(errorMessage);
							//	임시 테스트 시작 0207
							}
							//임시 테스트 끝
						}
						boolean bCgrFileExist = false; 
//						boolean b3dXmlFileExist = false; 
						String tempCgrFileName = "";
						String temp3dxmlFileName = "";
						String tempCgmFileName = "";
						
						String tempCgrObjectFileName = "";
						String temp3dxmlObjectFileName = "";
						String tempCgmObjectFileName = "";
						
						tempCgrFileName = sFileName;
						temp3dxmlFileName = sFileName;
						tempCgmFileName = sFileName;
						
						int intLastCGRExtension = tempCgrFileName.lastIndexOf(".");
						tempCgrFileName = tempCgrFileName.substring(0, intLastCGRExtension)+"."+sType+".cgr";
						
						int intLast3dxmlExtension = temp3dxmlFileName.lastIndexOf(".");
						temp3dxmlFileName = temp3dxmlFileName.substring(0, intLast3dxmlExtension)+"."+sType+".3dxml";
					
						int intLastCgmExtension = tempCgmFileName.lastIndexOf(".");
						tempCgmFileName = tempCgmFileName.substring(0,intLastCgmExtension)+"."+sType+ ".cgm";
								
						File cgrFile = new File(strWorkspacePath+File.separator+tempCgrFileName);
						boolean isExistCGRFile = cgrFile.exists();
						
						File xmlFile = new File(strWorkspacePath+File.separator+temp3dxmlFileName);
						boolean isExistXmlFile = xmlFile.exists();
						
						File cgmFile = new File(strWorkspacePath+File.separator+tempCgmFileName);
						boolean isExistCGMFile = cgmFile.exists();
						
						//change name
						tempCgrObjectFileName = sRef_FileName;
						temp3dxmlObjectFileName = sRef_FileName;
						tempCgmObjectFileName = sRef_FileName;
						
						tempCgrObjectFileName = tempCgrObjectFileName.substring(0,tempCgrObjectFileName.lastIndexOf("."))+"."+sType+".cgr";
						temp3dxmlObjectFileName = temp3dxmlObjectFileName.substring(0,temp3dxmlObjectFileName.lastIndexOf("."))+"."+sType+".3dxml";
						tempCgmObjectFileName = tempCgmObjectFileName.substring(0,tempCgmObjectFileName.lastIndexOf("."))+"."+sType+".cgm";
						String sRevisionSeqence = "";
						sRevisionSeqence = sTempRevision;

						
						//1/30 주석처리 시작
//						if (sRevisionSeqence.contains(".")) {
//							StringList sListSplitRevision = FrameworkUtil.split(sRevisionSeqence, ".");
//							sRevisionSeqence = (String) sListSplitRevision.get(0);
//						}
						
//						String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
						//1/30 주석처리 끝
//						String relViewable = "Viewable";
						
						boolean bMinorVersionCheck = false;
						StringList sListSplitRevision = FrameworkUtil.split(sRevisionSeqence, "\\..+");
						String splitMinorRevision = "";
						if(sListSplitRevision.size()>2){
							bMinorVersionCheck = true;
							String sRevisionSequnceSplit = (String)sListSplitRevision.get(2);
							Integer intergerRevisionSequence = Integer.parseInt(sRevisionSequnceSplit);
							splitMinorRevision = String.format("%01d", intergerRevisionSequence);
							
							sRevisionSeqence = (String)sListSplitRevision.get(0); 
							splitMinorRevision = sRevisionSeqence+"."+splitMinorRevision;
						}else{
							sRevisionSeqence = (String)sListSplitRevision.get(0); 
						}
						//
						
						String cgrObjectId = "";
						String xmlObjectId = "";
						String cgmObjectId = "";
						
						/*
						 * *********************************************************
						 * object name 설정. sCAD_REF_FILE_NAME 데이타가 존재하지않는다면 에러 처리.
						 * *********************************************************
						 */
						if (UIUtil.isNullOrEmpty(sRef_FileName)) {
							String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;
							throw new Exception(sErrorMessage);
						}
						
						
						String checkCADVehicle = "";
						String checkCADProject = "";
						boolean checkCGR = false;
						boolean checkXML = false;
						boolean checkCgm = false;
						String sViewableName = sRealName+"."+sType;
						
						//project org 
						String sLastRevisionVerionId = "";
						String sMajorVerionId = "";
						String sMinorVerionId = "";
						ContextUtil.startTransaction(context, true);
						if (isExistCAD ) {
							continue;
						} 
						else {
							/*
							 * Document 타입일 경우 Document 의 경우 'Document Release'
							 * policy 인 object 에 모든 파일이 저장되며 revision의 object의 경우에도
							 * 파일이 이동하지않고 변경한 데이타들이 저장 파일 이 추가 될
							 * cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성
							 */

//							strFormat = "generic";
							BusinessObject existdocumentBusObj = new BusinessObject(sType, sRealName, sRevisionSeqence, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
							
							if(bMinorVersionCheck){
								String mqlQuery = "temp query bus $1 $2 $3 where $4 select $5 dump $6";
								String queryWhere = "attribute[cdmTDMXID] == '"+sTdmxId+"' && attribute[cdmRevisionCheckInM] == '"+sTempRevision+"'";
								String queryMql  = MqlUtil.mqlCommand(context,
													mqlQuery,sType,"*","*", queryWhere,"id","|");
								
								StringList sListQuery = new StringList();
								sListQuery = FrameworkUtil.split(queryMql, "|");
								if(sListQuery.size()>2){
									String minorDocumentId = (String)sListQuery.get(3);
									existdocumentBusObj = new BusinessObject(minorDocumentId);
								}else{
									throw new Exception("The minor object does not exist.\t"+sType+"\t "+sRealName +"\t"+sTdmxId+" \t"+sTempRevision);
								}
								

							}
							boolean isDocumentObjExist = existdocumentBusObj.exists(context);
							
							boolean bLastRevisionDocumentCheck = false;
//							String reviseCheckM = "";
							String sHasFileExistDocumentCheck = "";
							if(isDocumentObjExist){
//								reviseCheckM = existdocumentBusObj.getAttributeValues(context, "cdmRevisionCheckInM").getValue();
								String existDocumentId = existdocumentBusObj.getObjectId(context);
								DomainObject existDocumentDObj = new DomainObject(existDocumentId);
								sHasFileExistDocumentCheck = (String)existDocumentDObj.getInfo(context, "format.hasfile");
								
								
								if(bMinorVersionCheck){
									BusinessObject lastVersionDocumentBus = existDocumentDObj.getLastRevision(context);
									 String lastDocumentObjectId = lastVersionDocumentBus.getObjectId(context);
								
									 if(existDocumentId.equals(lastVersionDocumentBus)){
										 bLastRevisionDocumentCheck = true;

										 Map paramDataMap = new HashMap();
										 StringList sListParamData = new StringList();
										 sListParamData.add("to[Active Version].from.id");
										 
										 paramDataMap = existDocumentDObj.getInfo(context, sListParamData);
//										 sMinorVersionRevision = (String)paramDataMap.get("revision");
										 String majorDocumentId = "";
										 majorDocumentId = (String)paramDataMap.get("to[Active Version].from.id");
										 if(UIUtil.isNotNullAndNotEmpty(majorDocumentId)){
											 existdocumentBusObj = new BusinessObject(majorDocumentId);
										 }
									 }
								}
								
								
								
								//project ,org 
								if(bMinorVersionCheck && bLastRevisionDocumentCheck){

									 Map paramDataMap = new HashMap();
									 StringList sListParamData = new StringList();
									 sListParamData.add("to[Active Version].from.id");
									 paramDataMap = existDocumentDObj.getInfo(context, sListParamData);
									 
									 sMajorVerionId  = (String)paramDataMap.get("to[Active Version].from.id");
									 sLastRevisionVerionId = existDocumentId;  
								}else if(!bMinorVersionCheck){
									
									Map paramDataMap = new HashMap();
									 StringList sListParamData = new StringList();
									 sListParamData.add("from[Active Version].to.id");
									 paramDataMap = existDocumentDObj.getInfo(context, sListParamData);
									 
									 sLastRevisionVerionId  = (String)paramDataMap.get("from[Active Version].to.id");
									sMajorVerionId = existDocumentId;
								}else{
									sMinorVerionId  = existDocumentId;
								}
								//
							
							}else{
								continue;
							}
							
							
//							if (isMajorDocumentObjExist && UIUtil.isNotNullAndNotEmpty(reviseCheckM) && reviseCheckM.equals(sTempRevision) && "FALSE".equalsIgnoreCase(sHasFileExistDocumentCheck)) {
							if (isDocumentObjExist  && "FALSE".equalsIgnoreCase(sHasFileExistDocumentCheck)) {
//								existdocumentBusObj.checkinFile(context, false, false, "", strFormat, sFileName, strWorkspacePath);
//
//								String documentBusId= existdocumentBusObj.getObjectId(context);
//								if(!sFileName.equals(sRef_FileName)){
//									MqlUtil.mqlCommand(context, "mod bus $1  rename format $2  $3 file $4 $5 ",documentBusId, strFormat,"!propagaterename",sFileName,sRef_FileName);
//								}
							} else {
								String errorMessage = "";
								if(!isDocumentObjExist && "FALSE".equalsIgnoreCase(sHasFileExistDocumentCheck)){
									//String errorMessage = "NOT FIND FILE. "+"\t"+sTempType+"\t"+sFileType+"\t"+sTdmxId;;
									 errorMessage = "The major object does not exist. \t "+sType+" \t "+sFileType+" \t"+sTdmxId+" \t"+sTempRevision;
									 throw new Exception(errorMessage);
								}else if(isDocumentObjExist && "TRUE".equalsIgnoreCase(sHasFileExistDocumentCheck)){
//									 errorMessage = "The file already exists.  \t "+sType+"\t"+sFileType +"\t"+sTempRevision;
								}else if(!isDocumentObjExist){
									errorMessage = "not object exist \t"+isDocumentObjExist+"\t not exist"+sHasFileExistDocumentCheck +"\t "+sType+"\t"+sFileType +"\t"+sTempRevision;
									throw new Exception(errorMessage);
								}else{
									
								}
								
							}

						}
						ContextUtil.commitTransaction(context);
						successInt++;
						boolean bProjectOrg = false;
						/* project org 설정 */
						try {
							checkCADVehicle = isVaildNullData(sVehicle);
							checkCADProject = isVaildNullData(sProjectGroup);
//							if (isExistCAD && UIUtil.isNotNullAndNotEmpty(checkCADVehicle) && UIUtil.isNotNullAndNotEmpty(checkCADProject) ) {
							if ( UIUtil.isNotNullAndNotEmpty(checkCADVehicle) && UIUtil.isNotNullAndNotEmpty(checkCADProject) ) {

								// 임시로 project org 추가 start
								if (UIUtil.isNotNullAndNotEmpty(sMajorVerionId ) && UIUtil.isNotNullAndNotEmpty(sLastRevisionVerionId )) {
									
									
									DomainObject majorVersionDObj = new DomainObject(sMajorVerionId);
									DomainObject lasterRevVersionDObj = new DomainObject(sLastRevisionVerionId);
									
									String majorVersionProject = "";
									String majorVersionOrg = "";
									String lasterRevVersionminorProject = "";
									String lasterRevVersionminorOrg = "";
									majorVersionProject = (String)majorVersionDObj.getInfo(context, "project");
									majorVersionOrg = (String)majorVersionDObj.getInfo(context, "organization");
									lasterRevVersionminorProject = (String)lasterRevVersionDObj.getInfo(context, "project");
									lasterRevVersionminorOrg = (String)lasterRevVersionDObj.getInfo(context, "organization");
									
									if(UIUtil.isNullOrEmpty(majorVersionProject) && (UIUtil.isNullOrEmpty(majorVersionOrg) )){
										MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", sMajorVerionId, checkCADProject, checkCADVehicle);
									}
									if(UIUtil.isNullOrEmpty(lasterRevVersionminorOrg) && (UIUtil.isNullOrEmpty(lasterRevVersionminorProject) )){
										MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", sLastRevisionVerionId, checkCADProject, checkCADVehicle);
									}
								}
								if (UIUtil.isNotNullAndNotEmpty(sMinorVerionId)) {
									DomainObject minorVersionDObj = new DomainObject(sMinorVerionId);
									String minorProject = "";
									String minorOrg = "";
									minorProject= (String)minorVersionDObj.getInfo(context, "project");
									minorOrg = (String)minorVersionDObj.getInfo(context, "organization");
									if(UIUtil.isNullOrEmpty(minorProject) || (UIUtil.isNullOrEmpty(minorOrg) )){
										MqlUtil.mqlCommand(context, "mod bus $1 project $2 organization $3", sMinorVerionId, checkCADProject, checkCADVehicle);
									}
								}
								// 임시로 project org 추가 end 
								bProjectOrg = true;
							}else{
								bProjectOrg = false;
							}
						}catch(Exception e4){
							bProjectOrg = false;
						}
						writeSuccessToFile(recordRowNum + "\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+checkXML+"\t"+checkCGR +"\t"+checkCgm+"\t"+bProjectOrg+"\t"+checkCADProject+"\t"+checkCADVehicle);
//						writeMessageToConsole(recordRowNum + "\t"+sType+"\t"+sRealName+"\t"+sTempRevision+"\t"+checkXML+"\t"+checkCGR+"\t"+bProjectOrg+"\t"+checkCADProject+"\t"+checkCADVehicle);
						if(checkCgm){
							cgmCount++;
						}
						
						
					} catch (Exception exception) {
						ContextUtil.abortTransaction(context);
						failedInt++;
						String message = exception.getMessage();
						
						if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("not a valid type or filetype.")){
							writeMessageToConsole(recordRowNum + "\t"+"1"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"1"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST CAD_REF_FILE_NAME FILE DATA .") ){
							writeMessageToConsole(recordRowNum + "\t"+"2"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"2"+"\t"+stReadData);
							
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR DOCUMENT")){
							writeMessageToConsole(recordRowNum + "\t"+"3"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST MAJOR OBJECT.")){
							
							writeMessageToConsole(recordRowNum + "\t"+"4"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"4"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST REVISION DATA.")){
							writeMessageToConsole(recordRowNum + "\t"+"5"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"5"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT FIND FILE.")){
							writeMessageToConsole(recordRowNum + "\t"+"6"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"6"+"\t"+stReadData);
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT MATCH ROW INFOMATION.")){
							writeMessageToConsole(recordRowNum + "\t"+"7"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"7"+"\t"+stReadData);
//						
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("The major object does not exist.")){
							writeMessageToConsole(recordRowNum + "\t"+"8"+" \t "+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+" \t "+"8"+"\t "+stReadData);
							
						}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("The file already exists.")){
							writeMessageToConsole(recordRowNum + "\t"+"9"+" \t "+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+" \t "+"9"+" \t "+stReadData);
						}
						else{
							writeMessageToConsole(recordRowNum + "\t"+"0"+"\t"+message);
							writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t "+stReadData);
							
						}
						writeErrorToFile("LineNum(#)"+recordRowNum+" \t "+recordRowTdmxId+" \t "+recordRowRevision);
						exception.printStackTrace(errorStream);

					}finally{
						
					}
				}

			} catch (Exception e) {
				e.printStackTrace();
			}finally{
				MqlUtil.mqlCommand(context, "Trigger On");
				MqlUtil.mqlCommand(context, "history on");
				
				writeMessageToConsole("====================================================================================");
				writeMessageToConsole("LEAD TIME:" + (System.currentTimeMillis() - startTime)/1000/60 + "ms        \n");
				writeMessageToConsole("End Time :("+cdmCommonExcel.getTimeStamp2() +")  Total Count:("+(totalCount-1)+") Success Count:("+successInt+") notMacthType:("+notMatchTypeCount+"  Fail Count: ("+failedInt+") cgmCount: ("+cgmCount+")" );
				writeMessageToConsole("==================================================================================== \n");
				closeLogStream();
				
				
				System.out.println("[cdmCADMigration_mxJPO : executeMajorMinorCheckin] end ." + cdmCommonExcel.getTimeStamp2() );
			}
		
			
		
		}

}
