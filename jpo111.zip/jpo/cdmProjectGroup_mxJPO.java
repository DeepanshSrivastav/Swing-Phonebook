import java.util.HashMap;
import java.util.Map;
import java.util.Vector;

import javax.servlet.http.HttpSession;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.common.SubscriptionManager;
import com.matrixone.apps.common.Workspace;
import com.matrixone.apps.common.WorkspaceVault;
import com.matrixone.apps.domain.DomainAccess;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.team.TeamUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.util.SelectList;
import matrix.util.StringList;

/**
 * @author jh.park
 * @date 2016. 8. 11 Type cdmSubProjectgroup, cdmProjectGroupObject
 */
public class cdmProjectGroup_mxJPO {

	private static final HttpSession HttpServletRequest = null;

	/**
	 * @author Project Tree Table
	 */
	@SuppressWarnings("static-access")
	public MapList getProjectTree(Context context, String[] args) throws Exception {
		MapList mlTreeList = new MapList();
		try {
			DomainObject domObj = new DomainObject();
			SelectList objSelect = new SelectList();
			objSelect.add(DomainConstants.SELECT_ID);
			String where = "name=='Project Tree'";
			mlTreeList = domObj.findObjects(context, cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP, "*", where, objSelect);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return mlTreeList;
	}

	/**
	 * @author Project Group Table
	 */
	@SuppressWarnings("rawtypes")
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getProjectGroup(Context context, String[] args) throws Exception {
		MapList mlProjectGroupList = new MapList();
		try {
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String objectId = (String) paramMap.get("objectId");
			DomainObject domObj = new DomainObject(objectId);
			StringList projectObjectList = new StringList();
			projectObjectList.addElement(DomainConstants.SELECT_ID);

			mlProjectGroupList = domObj.getRelatedObjects(context, 
														  cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_OBJECT_TYPE_RELATIONSHIP, // Relationship
														  cdmConstantsUtil.TYPE_CDM_SUB_PROJECT_GROUP, // From Type name
														  projectObjectList, // Type selects
														  null, // Rel selects
														  false, // to Direction
														  true, // from Direction
														  (short) 1, // recusion level
														  "", 
														  "", 
														  0);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return mlProjectGroupList;
	}

	/**
	 * @author Project Group Object Table
	 */
	@SuppressWarnings("rawtypes")
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getProject(Context context, String[] args) throws Exception {
		MapList mlProjectObjectList = new MapList();

		try {
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String objectId = (String) paramMap.get("objectId");
			DomainObject projectObject = new DomainObject(objectId);
			StringList projectObjectList = new StringList();
			projectObjectList.addElement(DomainConstants.SELECT_ID);

			mlProjectObjectList = projectObject.getRelatedObjects(context, 
																  cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_OBJECT_TYPE_RELATIONSHIP, // Relationship
																  cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT, // From Type
																  projectObjectList, // Type selects
																  null, // Rel selects
																  false, // to Direction
																  true, // from Direction
																  (short) 1, // recusion level
																  "", 
																  "", 
																  0);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return mlProjectObjectList;
	}

	/**
	 * @author Parts Object Table
	 */
	@SuppressWarnings("rawtypes")
	public MapList getParts(Context context, String[] args) throws Exception {
		MapList partsList = new MapList();
		MapList returnList  = new MapList();
		try {
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String objectId = (String) paramMap.get("objectId");
			DomainObject projectObject = new DomainObject(objectId);
			StringList projectObjectList = new StringList();
			projectObjectList.addElement(DomainConstants.SELECT_ID);
			projectObjectList.addElement(DomainConstants.SELECT_NAME);
			projectObjectList.addElement(DomainConstants.SELECT_REVISION);

			partsList = projectObject.getRelatedObjects(context, 
														cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT, // Relationship
														"cdmPart", // From Type name
														projectObjectList, // Type selects
														null, // Rel selects
														false, // to Direction
														true, // from Direction
														(short) 1, // recusion level
														"to[EBOM]==False", 
														"revision==last.revision", 
														0);
			
			partsList.sort("revision", "descending", "string");
			
			returnList  = getFilterList(partsList, "name");
			
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return returnList;

	}
	
	private MapList getFilterList(MapList objectList, String key) {
		MapList rtnList = new MapList();
		try {
			for (int i = 0; i < objectList.size(); i++) {
			    Map map = (Map) objectList.get(i);
			    String value = (String) map.get(key);
			    if (i == 0) {
			    	rtnList.add(map);
			    } else {
			    	boolean duplicationCheck = false;
			    	int rtnListSize = rtnList.size();
			    	for (int j = 0; j < rtnListSize; j++) {
			    		String compareValue = (String) ((Map) rtnList.get(j)).get(key);
			    		if (compareValue.equals(value)) {
			    			duplicationCheck = true;
			    		}
			    	}
			    	if (!duplicationCheck) {
			    		rtnList.add(map);
			    	}
			    }
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return rtnList;
	}

	/**
	 * @author Document Object Table
	 */
	@SuppressWarnings("rawtypes")
	public MapList getDocuments(Context context, String[] args) throws Exception {
		MapList documentsList = new MapList();
		try {
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String objectId = (String) paramMap.get("objectId");
			DomainObject projectObject = new DomainObject(objectId);
			StringList projectObjectList = new StringList();
			projectObjectList.addElement(DomainConstants.SELECT_ID);

			documentsList = projectObject.getRelatedObjects(context, 
															cdmConstantsUtil.RELATIONSHIP_CDM_DOCUMENTS_PROJECT_RELATIONSHIP, // Relationship
															"Document", // From Type name
															projectObjectList, // Type selects
															null, // Rel selects
															true, // to Direction
															false, // from Direction
															(short) 1, // recusion level
															"", 
															"", 
															0);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return documentsList;

	}

	/**
	 * @author EC Object Table
	 */
	@SuppressWarnings("rawtypes")
	public MapList getEC(Context context, String[] args) throws Exception {
		MapList ecList = new MapList();

		try {
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String objectId = (String) paramMap.get("objectId");
			DomainObject projectObject = new DomainObject(objectId);
			StringList projectObjectList = new StringList();
			projectObjectList.addElement(DomainConstants.SELECT_ID);

			ecList = projectObject.getRelatedObjects(context, 
													 cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_EC, // Relationship
													 "*", // From Type name
													 projectObjectList, // Type selects
													 null, // Rel selects
													 false, // to Direction
													 true, // from Direction
													 (short) 1, // recusion level
													 "", 
													 "", 
													 0);

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return ecList;

	}

	/**
	 * @author WorkSpace Object Table
	 */
	@SuppressWarnings("rawtypes")
	public MapList getWorkspace(Context context, String[] args) throws Exception {
		MapList workspaceList = new MapList();
		try {
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String objectId = (String) paramMap.get("objectId");
			DomainObject domProjectObject = new DomainObject(objectId);
			StringList projectObjectList = new StringList();
			projectObjectList.addElement(DomainConstants.SELECT_ID);

			workspaceList = domProjectObject.getRelatedObjects(context, 
															   cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_WORKSPACE, // Relationship
															   "*", // From Type name
															   projectObjectList, // Type selects
															   null, // Rel selects
															   false, // to Direction
															   true, // from Direction
															   (short) 1, // recusion level
															   "", 
															   "", 
															   0);
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
		return workspaceList;

	}

	/**
	 * @author Create Project Group Object return. returnMap
	 *
	 */
	@SuppressWarnings({ "deprecation", "unchecked", "static-access", "rawtypes" })
	@com.matrixone.apps.framework.ui.CreateProcessCallable
	public Map createProject(Context context, String[] args) throws Exception {
		Map returnMap = new HashMap();
		HashMap paramMap = (HashMap) JPO.unpackArgs(args);
		
		String strLanguage = (String)paramMap.get("languageStr");
		String strParentOID = (String) paramMap.get("objectId");
		String strName = (String) paramMap.get("Name");
		String strProductNameId = (String) paramMap.get("ProductNameObjectId");
		String strProductTypeId = (String) paramMap.get("ProductTypeObjectId");
		String strCustomerId = (String) paramMap.get("CustomerObjectId");
		String strVehicleId = (String) paramMap.get("VehicleObjectId");
		String strType	= (String) paramMap.get("TypeActual");
		String strPolicy = (String) paramMap.get("Policy");
		
		String title = cdmStringUtil.browserCommonCodeLanguage(strLanguage);
		
		try {
			DomainObject domProductNameId = new DomainObject(strProductNameId);
			DomainObject domCustomerId = new DomainObject(strCustomerId);
			DomainObject domVehicleId = new DomainObject(strVehicleId);
			
			String strProductName = domProductNameId.getInfo(context, title);
			String strCustomerName = domCustomerId.getInfo(context, title);
			String strVehicleName = domVehicleId.getInfo(context, title);
			
			String strOrganization = strCustomerName + " - " + strVehicleName;
			
			//domObj.createObject(context, strType, strName, "-", strPolicy, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
			//String strProjectObjectId = domObj.getObjectId(context);
			
			
			String strProjectObjectId = FrameworkUtil.autoName(context, "type_cdmProjectGroupObject", "policy_cdmProjectGroupPolicy");
			
			DomainObject domObj = new DomainObject(strProjectObjectId);
			
			MqlUtil.mqlCommand(context, "connect bus '" + strParentOID + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_OBJECT_TYPE_RELATIONSHIP + "' to " + strProjectObjectId);

			returnMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PROJECT_CODE, strName);

			domObj.setAttributeValues(context, returnMap);

			// Workspace Exist Check
			ContextUtil.pushContext(context, null, null, null);
			boolean isWorkspaceExists = (boolean) Workspace.isWorkspaceExists(context, FrameworkUtil.getVaultNames(context, false, true).toString(), strName);
			ContextUtil.popContext(context);

			if (!isWorkspaceExists) {
				Workspace WorkspaceObj = (Workspace) DomainObject.newInstance(context, DomainConstants.TYPE_WORKSPACE, DomainConstants.TEAM);
				String strWorkspaceObjectId = "";
				// WorkspaceObj.TYPE_PROJECT == "Workspace"
				// WorkspaceObj.POLICY_PROJECT == "Workspace"
				// Workspace Create
				strWorkspaceObjectId = TeamUtil.autoRevision(context, HttpServletRequest, WorkspaceObj.TYPE_PROJECT, strName, WorkspaceObj.POLICY_PROJECT, context.getVault().getName());
				WorkspaceObj.setId(strProjectObjectId);
				WorkspaceObj.open(context);
				WorkspaceObj.setDescription(context, strName);
				WorkspaceObj.update(context);
				
				MqlUtil.mqlCommand(context, "mod bus " + strWorkspaceObjectId + " project '" + strProductName + "' ");
				MqlUtil.mqlCommand(context, "mod bus " + strWorkspaceObjectId + " organization '" + strOrganization +"'");
				
				// Workspace - Project Connection
				DomainAccess.createObjectOwnership(context, strProjectObjectId, com.matrixone.apps.domain.util.PersonUtil.getPersonObjectID(context), "Full", DomainAccess.COMMENT_MULTIPLE_OWNERSHIP);
				DomainRelationship.connect(context, new DomainObject(strProjectObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_RELATIONSHIP_WORKSPACE, new DomainObject(strWorkspaceObjectId));

				// Workspace Vault Create Setting...
				BusinessObject boWorkspace = new BusinessObject(strWorkspaceObjectId);
				boWorkspace.open(context);
				Workspace workspace = (Workspace) DomainObject.newInstance(context, DomainConstants.TYPE_WORKSPACE, DomainConstants.TEAM);
				workspace.setId(strWorkspaceObjectId);
				String strWorkspaceRevision = MqlUtil.mqlCommand(context, "print bus $1 select $2 dump $3", strWorkspaceObjectId, "physicalid", "|");
				String strPolicyWorkspaceVault = PropertyUtil.getSchemaProperty(context, "policy_ProjectVault"); // Workspace Vaults
				String strRelProjectVaults = PropertyUtil.getSchemaProperty(context, "relationship_ProjectVaults"); // Data Vaults
				String strTypefolder = PropertyUtil.getSchemaProperty(context, "type_ProjectVault"); // Workspace Vault

				String strRelSubProjectValues = "Sub Vaults";
				String strSubType = "Workspace Vault";
				String strSubPolicy = "Workspace Vaults";

				// Workspace Vault Create(Folder)
				WorkspaceVault wExportVault = new WorkspaceVault();
				WorkspaceVault wFMEAVault = new WorkspaceVault();
				WorkspaceVault wCADVault = new WorkspaceVault();
				WorkspaceVault wDesignVault = new WorkspaceVault();
				WorkspaceVault wImportVault = new WorkspaceVault();

				

				/*
				 * String strFolderNames[] = {"OEM EXPORT","FMEA" ,"CAD","Design Document", "OEM IMPORT"}; 
				 * for (int i = 0; i <strFolderNames.length; i++) { 
				 * wVault.createObject(context, strTypefolder, strFolderNames[i], strWorkspaceRevision, strPolicyWorkspaceVault, context.getVault().getName()); 
				 * }
				 */
				
				// create Folders.
				wExportVault.createObject(context, strTypefolder, "OEM EXPORT", strWorkspaceRevision, strPolicyWorkspaceVault, context.getVault().getName());
				wExportVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String strExportFolderId = wExportVault.getObjectId();

				wFMEAVault.createObject(context, strTypefolder, "FMEA", strWorkspaceRevision, strPolicyWorkspaceVault, context.getVault().getName());
				wFMEAVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String strFMEAFolderId = wFMEAVault.getObjectId();

				wCADVault.createObject(context, strTypefolder, "CAD", strWorkspaceRevision, strPolicyWorkspaceVault, context.getVault().getName());
				wCADVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String strCADFolderId = wCADVault.getObjectId();

				wDesignVault.createObject(context, strTypefolder, "Design Document", strWorkspaceRevision, strPolicyWorkspaceVault, context.getVault().getName());
				wDesignVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String strDesignFolderId = wDesignVault.getObjectId();

				wImportVault.createObject(context, strTypefolder, "OEM IMPORT", strWorkspaceRevision, strPolicyWorkspaceVault, context.getVault().getName());
				wImportVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String strImportFolderId = wImportVault.getObjectId();

				// Sub Workspace Vault Create(Folder)
				WorkspaceVault wReviewVault = new WorkspaceVault();
				WorkspaceVault wApprovalVault = new WorkspaceVault();
				WorkspaceVault w3DMasterVault = new WorkspaceVault();
				WorkspaceVault w3DWorkingVault = new WorkspaceVault();
				WorkspaceVault w2DMasterVault = new WorkspaceVault();
				WorkspaceVault w2DWorkingVault = new WorkspaceVault();
				WorkspaceVault wReferenceVault = new WorkspaceVault();
				WorkspaceVault wApprovedVault = new WorkspaceVault();
				
				//Create. Sub Folders.
				wReviewVault.createObject(context, strSubType, "Review Model", strWorkspaceRevision, strSubPolicy, context.getVault().getName());
				wReviewVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String strReviewFolderId = wReviewVault.getObjectId();

				wApprovalVault.createObject(context, strSubType, "Approval Request", strWorkspaceRevision, strSubPolicy, context.getVault().getName());
				wApprovalVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String strApprovalFolderId = wApprovalVault.getObjectId();

				w3DMasterVault.createObject(context, strSubType, "CAD 3D MASTER", strWorkspaceRevision, strSubPolicy, context.getVault().getName());
				w3DMasterVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String str3DMasterFolderId = w3DMasterVault.getObjectId();

				w3DWorkingVault.createObject(context, strSubType, "CAD 3D WORKING", strWorkspaceRevision, strSubPolicy, context.getVault().getName());
				w3DWorkingVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String str3DWorkingFolderId = w3DWorkingVault.getObjectId();

				w2DMasterVault.createObject(context, strSubType, "CAD 2D MASTER", strWorkspaceRevision, strSubPolicy, context.getVault().getName());
				w2DMasterVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String str2DMasterFolderId = w2DMasterVault.getObjectId();

				w2DWorkingVault.createObject(context, strSubType, "CAD 2D WORKING", strWorkspaceRevision, strSubPolicy, context.getVault().getName());
				w2DWorkingVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String str2DWoringFolderId = w2DWorkingVault.getObjectId();

				wReferenceVault.createObject(context, strSubType, "Reference", strWorkspaceRevision, strSubPolicy, context.getVault().getName());
				wReferenceVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String strReferenceFolderId = wReferenceVault.getObjectId();

				wApprovedVault.createObject(context, strSubType, "Approved", strWorkspaceRevision, strSubPolicy, context.getVault().getName());
				wApprovedVault.setAttributeValue(context, DomainConstants.ATTRIBUTE_ACCESS_TYPE, "Inherited");
				String strApprovedFolderId = wApprovedVault.getObjectId();

				// Connect Workspace
				wExportVault.connect(context, strRelProjectVaults, (DomainObject) workspace, true);
				wFMEAVault.connect(context, strRelProjectVaults, (DomainObject) workspace, true);
				wCADVault.connect(context, strRelProjectVaults, (DomainObject) workspace, true);
				wDesignVault.connect(context, strRelProjectVaults, (DomainObject) workspace, true);
				wImportVault.connect(context, strRelProjectVaults, (DomainObject) workspace, true);

				// Connect Sub-Workspace
				MqlUtil.mqlCommand(context, "connect bus '" + strExportFolderId + "' relationship '" + strRelSubProjectValues + "' to " + strReviewFolderId);
				MqlUtil.mqlCommand(context, "connect bus '" + strExportFolderId + "' relationship '" + strRelSubProjectValues + "' to " + strApprovalFolderId);
				/*
				 * wReviewVault.connect(context, strRelSubProjectValues,
				 * (DomainObject)workspace, true);
				 * wApprovalVault.connect(context, strRelSubProjectValues,
				 * (DomainObject)workspace, true);
				 */

				MqlUtil.mqlCommand(context, "connect bus '" + strCADFolderId + "' relationship '" + strRelSubProjectValues + "' to " + str3DMasterFolderId);
				MqlUtil.mqlCommand(context, "connect bus '" + strCADFolderId + "' relationship '" + strRelSubProjectValues + "' to " + str3DWorkingFolderId);
				MqlUtil.mqlCommand(context, "connect bus '" + strCADFolderId + "' relationship '" + strRelSubProjectValues + "' to " + str2DMasterFolderId);
				MqlUtil.mqlCommand(context, "connect bus '" + strCADFolderId + "' relationship '" + strRelSubProjectValues + "' to " + str2DWoringFolderId);

				/*
				 * w3DMasterVault.connect(context, strRelSubProjectValues, (DomainObject)workspace, true);
				 * w3DWorkingVault.connect(context, strRelSubProjectValues, (DomainObject)workspace, true);
				 * w2DMasterVault.connect(context, strRelSubProjectValues, (DomainObject)workspace, true);
				 * w2DWorkingVault.connect(context, strRelSubProjectValues, (DomainObject)workspace, true);
				 */

				MqlUtil.mqlCommand(context, "connect bus '" + strImportFolderId + "' relationship '" + strRelSubProjectValues + "' to " + strReferenceFolderId);
				MqlUtil.mqlCommand(context, "connect bus '" + strImportFolderId + "' relationship '" + strRelSubProjectValues + "' to " + strApprovedFolderId);

				/*
				 * wReferenceVault.connect(context, strRelSubProjectValues, (DomainObject)workspace, true);
				 * wApprovedVault.connect(context, strRelSubProjectValues, (DomainObject)workspace, true);
				 */
				
				SubscriptionManager subscriptionMgr = workspace.getSubscriptionManager();
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, strExportFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, strFMEAFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, strCADFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, strDesignFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, strImportFolderId);

				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, strReviewFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, strApprovalFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, str3DMasterFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, str3DWorkingFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, str2DMasterFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, str2DWoringFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, strReferenceFolderId);
				subscriptionMgr.publishEvent(context, workspace.EVENT_FOLDER_CREATED, strApprovedFolderId);

				boWorkspace.close(context);
			}

			if (!strProductNameId.equals("")) {
				MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME + " to " + strProductNameId);
			}
			if (!strProductTypeId.equals("")) {
				MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE + " to " + strProductTypeId);
			}
			if (!strCustomerId.equals("")) {
				MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER + " to " + strCustomerId);
			}
			if (!strVehicleId.equals("")) {
				StringList slVehicleList = FrameworkUtil.split(strVehicleId, ",");
				for (int i = 0; i < slVehicleList.size(); i++) {
					String strVehicleObjectId = (String) slVehicleList.get(i);
					if (!"".equals(strVehicleObjectId)) {
						MqlUtil.mqlCommand(context, "connect bus " + strProjectObjectId + " relationship " + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE + " to " + strVehicleObjectId);
					}
				}
			}

			returnMap.put("id", strProjectObjectId);

			return returnMap;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * @author Create Project Group & SubProjectGroup. return. returnMap
	 */
	@SuppressWarnings({ "deprecation", "unchecked", "rawtypes" })
	@com.matrixone.apps.framework.ui.CreateProcessCallable
	public Map createProjectGroup(Context context, String[] args) throws Exception {
		Map returnMap = new HashMap();

		try {
			ContextUtil.startTransaction(context, true);
			HashMap paramMap = (HashMap) JPO.unpackArgs(args);
			String strParentOID = (String) paramMap.get("objectId");
			String strCode = (String) paramMap.get("Title");
			String strType = (String) paramMap.get(cdmConstantsUtil.TEXT_TYPEACTUAL);
			String strPolicy = (String) paramMap.get(cdmConstantsUtil.TEXT_POLICY);

			String strObjectId = FrameworkUtil.autoName(context, "type_" + strType, "policy_"+strPolicy);
			DomainObject domObj = new DomainObject(strObjectId);
			String strGroupObjectId = domObj.getObjectId(context);

			MqlUtil.mqlCommand(context, "connect bus '" + strParentOID + "' relationship '" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_OBJECT_TYPE_RELATIONSHIP + "' to " + strGroupObjectId);

			returnMap.put("cdmProjectCode", strCode);
			domObj.setAttributeValues(context, returnMap);

			returnMap.put("id", strGroupObjectId);
			ContextUtil.commitTransaction(context);

			return returnMap;
		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * @author Project Group Edit
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@com.matrixone.apps.framework.ui.CreateProcessCallable
	public Map cdmProjectGroupEdit(Context context, String[] args) throws Exception {
		Map returnMap = new HashMap();
		try {
			DomainObject domObj = new DomainObject();
			String objectId = domObj.getObjectId(context);
			returnMap.put("id", objectId);
			return returnMap;
		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * @author Get Structure (Project Group & Project)
	 */
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public MapList getStructure(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap   = (HashMap) programMap.get("paramMap");
		
		String strObjectId = (String) paramMap.get("objectId");
		
		StringList selectList = new StringList();
		selectList.add(DomainConstants.SELECT_ID);
		selectList.add(DomainConstants.SELECT_NAME);
		selectList.add("attribute[cdmProjectCode]");
		
		MapList mlResultList = new MapList();

		DomainObject subProjectObj = new DomainObject(strObjectId);

		try {
			
			
			String strObjType = subProjectObj.getInfo(context, DomainObject.SELECT_TYPE);
			
			if("cdmSubProjectGroup".equals(strObjType)) {
				mlResultList = subProjectObj.getRelatedObjects(context, 
																"cdmProjectGroupObjectTypeRelationShip,cdmPartRelationProject", // relationship
																"cdmSubProjectGroup,cdmProjectGroupObject", // type   cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT
																selectList, // objects
																null, // relationships
																false, // to
																true, // from
																(short) 1, // recurse
																"", // where
																null, // relationship where
																(short) 0); // limit
			
				mlResultList.sort("attribute[cdmProjectCode]", "ascending", "string");
			} else {

				
//				String strObjWhere = "";
//				if ("cdmProjectGroupObject".equals(strObjType)) {
//					
//					strObjWhere = "to[EBOM] == False";
//
//				} else if (subProjectObj.isKindOf(context, "cdmPart")) {
//
//					strObjWhere = "revision == last ";
//				}
//				
//				mlResultList = subProjectObj.getRelatedObjects(context, 
//																"cdmPartRelationProject,EBOM", // relationship
//																"cdmPart", // type   cdmConstantsUtil.TYPE_CDM_PROJECT_GROUP_OBJECT
//																selectList, // objects
//																null, // relationships
//																false, // to
//																true, // from
//																(short) 1, // recurse
//																strObjWhere, // where
//																null, // relationship where
//																(short) 0); // limit
//				
//				mlResultList.sort("name", "ascending", "string");
				
				
			}
			
			

		} catch (FrameworkException e) {
			throw new FrameworkException(e);
		}
		return mlResultList;
		
		
	}

	/**
	 * @author Return Vehicle when create object
	 */
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getCreateVehicle(Context context, String[] args) throws Exception {
		StringBuffer sbReturnString = new StringBuffer();

		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strObjectId = cdmStringUtil.setEmpty((String) paramMap.get("objectId"));
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strVehicle = DomainConstants.EMPTY_STRING;

		if (!DomainConstants.EMPTY_STRING.equals(strObjectId)) {
			strVehicle = MqlUtil.mqlCommand(context, "print bus " + strObjectId + " select to[" + cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE + "].from." + strDisplayTitle + " dump");
			sbReturnString.append("<input type=\"text\"  name=\"Vehicle\" id=\"Vehicle\" value=\"" + strVehicle + "\" width=\"30\" readOnly=\"true\">");
		} else {
			sbReturnString.append("<input type=\"text\"  name=\"Vehicle\" id=\"Vehicle\" value=\"\" width=\"30\" readOnly=\"true\">");
		}

		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"button\" name=\"\" value=\"...\" onclick=\"javascript:window.open('../common/cdmPartLibraryChooser.jsp?callbackFunction=showVehicleFocus&amp;header=emxEngineeringCentral.Label.Vehicle&amp;multiSelect=false&amp;ShowIcons=true&amp;searchMode=CommonCode&amp;program=cdmPartLibrary:getCommonCodeFirstNode&amp;expandProgram=cdmPartLibrary:expandCommonCodeLowLankNode&amp;isFromSearch=false&amp;isNeededOId=false&amp;displayKey=name&amp;rootNode=CommonCode&amp;fieldNameActual=CommonCode&amp;");
		sbReturnString.append("fieldNameDisplay=Vehicle&amp;fromPage=CommonCodeForm&amp;firstLevelSelect=false&amp;secondLevel=false&amp;processURL=../engineeringcentral/cdmProjectVehicleProcess.jsp&amp;StringResourceFileId=emxEngineeringCentralStringResource&amp;SuiteDirectory=engineeringcentral', '', 'width=450', 'height=550')\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"hidden\" name=\"VehicleObjectId\" value=\"\">");
		sbReturnString.append("</input>");

		return sbReturnString.toString();
	}

	/**
	 * @author Return Product Type when create Object
	 * @throws Exception
	 */

	@SuppressWarnings({ "rawtypes", "deprecation" })
	public String getCreateProductType(Context context, String[] args) throws Exception {
		StringBuffer sbReturnString = new StringBuffer();

		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strObjectId = cdmStringUtil.setEmpty((String) paramMap.get("objectId"));
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strProductType = DomainConstants.EMPTY_STRING;

		if (!DomainConstants.EMPTY_STRING.equals(strObjectId)) {
			strProductType = MqlUtil.mqlCommand(context, "print bus " + strObjectId + " select to[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE + "].from." + strDisplayTitle + " dump");
			sbReturnString.append("<input type=\"text\"  name=\"ProductType\" id=\"ProductType\" value=\"" + strProductType + "\" width=\"30\" readOnly=\"true\">");
		} else {
			sbReturnString.append("<input type=\"text\"  name=\"ProductType\" id=\"ProductType\" value=\"\" width=\"30\" readOnly=\"true\">");
		}
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"button\" name=\"\" value=\"...\" onclick=\"javascript:window.open('../common/cdmPartLibraryChooser.jsp?callbackFunction=showVehicleFocus&amp;header=emxEngineeringCentral.Label.ProductType&amp;multiSelect=false&amp;ShowIcons=true&amp;searchMode=CommonCode&amp;program=cdmPartLibrary:getCommonCodeFirstNode&amp;expandProgram=cdmPartLibrary:expandCommonCodeLowLankNode&amp;isFromSearch=false&amp;isNeededOId=false&amp;displayKey=name&amp;rootNode=CommonCode&amp;fieldNameActual=CommonCode&amp;");
		sbReturnString.append("fieldNameDisplay=Product_Div&amp;fromPage=CommonCodeForm&amp;firstLevelSelect=false&amp;secondLevel=false&amp;processURL=../engineeringcentral/cdmProjectProductTypeProcess.jsp&amp;StringResourceFileId=emxEngineeringCentralStringResource&amp;SuiteDirectory=engineeringcentral', '', 'width=450', 'height=550')\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"hidden\" name=\"ProductTypeObjectId\" value=\"\">");
		sbReturnString.append("</input>");

		return sbReturnString.toString();
	}

	/**
	 * @author Return Product Name when create Object
	 * @throws Exception
	 */

	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getCreateProductName(Context context, String[] args) throws Exception {
		StringBuffer sbReturnString = new StringBuffer();

		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strObjectId = cdmStringUtil.setEmpty((String) paramMap.get("objectId"));
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strProductName = DomainConstants.EMPTY_STRING;

		if (!DomainConstants.EMPTY_STRING.equals(strObjectId)) {
			strProductName = MqlUtil.mqlCommand(context, "print bus " + strObjectId + " select to[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME + "].from." + strDisplayTitle + " dump");
			sbReturnString.append("<input type=\"text\"  name=\"ProductName\" id=\"ProductName\" value=\"" + strProductName + "\" width=\"30\" readOnly=\"true\">");
		} else {
			sbReturnString.append("<input type=\"text\"  name=\"ProductName\" id=\"ProductName\" value=\"\" width=\"30\" readOnly=\"true\">");
		}
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"button\" name=\"\" value=\"...\" onclick=\"javascript:window.open('../common/cdmPartLibraryChooser.jsp?callbackFunction=showVehicleFocus&amp;header=emxEngineeringCentral.Label.ProductName&amp;multiSelect=false&amp;ShowIcons=true&amp;searchMode=CommonCode&amp;program=cdmPartLibrary:getCommonCodeFirstNode&amp;expandProgram=cdmPartLibrary:expandCommonCodeLowLankNode&amp;isFromSearch=false&amp;isNeededOId=false&amp;displayKey=name&amp;rootNode=CommonCode&amp;fieldNameActual=CommonCode&amp;");
		sbReturnString.append("fieldNameDisplay=Product_Group_Name&amp;fromPage=CommonCodeForm&amp;firstLevelSelect=false&amp;secondLevel=false&amp;processURL=../engineeringcentral/cdmProjectProductNameProcess.jsp&amp;StringResourceFileId=emxEngineeringCentralStringResource&amp;SuiteDirectory=engineeringcentral', '', 'width=450', 'height=550')\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"hidden\" name=\"ProductNameObjectId\" value=\"\">");
		sbReturnString.append("</input>");

		return sbReturnString.toString();
	}

	/**
	 * @author Return Product Name when create Object
	 * @throws Exception
	 */

	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getCreateCustomer(Context context, String[] args) throws Exception {
		StringBuffer sbReturnString = new StringBuffer();

		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strObjectId = cdmStringUtil.setEmpty((String) paramMap.get("objectId"));
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strCustomer = DomainConstants.EMPTY_STRING;

		if (!DomainConstants.EMPTY_STRING.equals(strObjectId)) {
			strCustomer = MqlUtil.mqlCommand(context, "print bus " + strObjectId + " select to[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER + "].from." + strDisplayTitle + " dump");
			sbReturnString.append("<input type=\"text\"  name=\"Customer\" id=\"Customer\" value=\"" + strCustomer + "\" width=\"30\" readOnly=\"true\">");
		} else {
			sbReturnString.append("<input type=\"text\"  name=\"Customer\" id=\"Customer\" value=\"\" width=\"30\" readOnly=\"true\">");
		}

		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"button\" name=\"\" value=\"...\" onclick=\"javascript:window.open('../common/cdmPartLibraryChooser.jsp?callbackFunction=showVehicleFocus&amp;header=emxEngineeringCentral.Label.Customer&amp;multiSelect=false&amp;ShowIcons=true&amp;searchMode=CommonCode&amp;program=cdmPartLibrary:getCommonCodeFirstNode&amp;expandProgram=cdmPartLibrary:expandCommonCodeLowLankNode&amp;isFromSearch=false&amp;isNeededOId=false&amp;displayKey=name&amp;rootNode=CommonCode&amp;fieldNameActual=CommonCode&amp;");
		sbReturnString.append("fieldNameDisplay=Customer&amp;fromPage=CommonCodeForm&amp;firstLevelSelect=false&amp;secondLevel=false&amp;processURL=../engineeringcentral/cdmProjectCustomerProcess.jsp&amp;StringResourceFileId=emxEngineeringCentralStringResource&amp;SuiteDirectory=engineeringcentral', '', 'width=450', 'height=550')\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"hidden\" name=\"CustomerObjectId\" value=\"\">");
		sbReturnString.append("</input>");

		return sbReturnString.toString();
	}

	/**
	 * ProductType for EditForm
	 */
	@SuppressWarnings({ "rawtypes", "deprecation" })
	@com.matrixone.apps.framework.ui.ProgramCallable
	public String getEditProductTypeField(Context context, String[] args) throws Exception {
		Map paramMap = (Map) JPO.unpackArgs(args);
		Map requestMap = (Map) paramMap.get("requestMap");
		String objectId = (String) requestMap.get("objectId");
		
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		
		String strProductTypeName = MqlUtil.mqlCommand(context, "print bus '" + objectId + "' select from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE+"].to." + strDisplayTitle + " dump");
		
		StringBuffer sbReturnString = new StringBuffer();

		sbReturnString.append("<input type=\"text\"  name=\"ProductType\" id=\"ProductType\" value=\"" + strProductTypeName + "\" width=\"30\" readOnly=\"true\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"button\" name=\"\" value=\"...\" onclick=\"javascript:window.open('../common/cdmPartLibraryChooser.jsp?fieldName=ProductTypeOID&amp;fieldId=ProductType&amp;callbackFunction=showVehicleFocus&amp;header=emxEngineeringCentral.Label.ProductType&amp;multiSelect=false&amp;ShowIcons=true&amp;searchMode=CommonCode&amp;program=cdmPartLibrary:getCommonCodeFirstNode&amp;expandProgram=cdmPartLibrary:expandCommonCodeLowLankNode&amp;isFromSearch=false&amp;isNeededOId=false&amp;displayKey=name&amp;rootNode=CommonCode&amp;fieldNameActual=CommonCode&amp;");
		sbReturnString.append("fieldNameDisplay=Product_Div&amp;fromPage=CommonCodeForm&amp;firstLevelSelect=false&amp;secondLevel=false&amp;processURL=../engineeringcentral/cdmProjectProductTypeEditProcess.jsp&amp;StringResourceFileId=emxEngineeringCentralStringResource&amp;SuiteDirectory=engineeringcentral', '', 'width=450', 'height=550')\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"hidden\" name=\"ProductTypeOID\" value=\"\">");
		sbReturnString.append("</input>");

		return sbReturnString.toString();
	}
	
	/**
	 * ProductName Search for EditForm
	 */
	@SuppressWarnings({ "rawtypes", "deprecation" })
	@com.matrixone.apps.framework.ui.ProgramCallable
	public String getEditProductNameField(Context context, String[] args) throws Exception {
		Map paramMap = (Map) JPO.unpackArgs(args);
		Map requestMap = (Map) paramMap.get("requestMap");
		String objectId = (String) requestMap.get("objectId");
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strProductName = MqlUtil.mqlCommand(context, "print bus '" + objectId + "' select from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME+"].to." + strDisplayTitle + " dump");
		
		StringBuffer sbReturnString = new StringBuffer();


		sbReturnString.append("<input type=\"text\"  name=\"ProductName\" id=\"ProductName\" value=\"" + strProductName + "\" width=\"30\" readOnly=\"true\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"button\" name=\"\" value=\"...\" onclick=\"javascript:window.open('../common/cdmPartLibraryChooser.jsp?fieldName=ProductNameOID&amp;callbackFunction=showVehicleFocus&amp;header=emxEngineeringCentral.Label.ProductName&amp;multiSelect=false&amp;ShowIcons=true&amp;searchMode=CommonCode&amp;program=cdmPartLibrary:getCommonCodeFirstNode&amp;expandProgram=cdmPartLibrary:expandCommonCodeLowLankNode&amp;isFromSearch=false&amp;isNeededOId=false&amp;displayKey=name&amp;rootNode=CommonCode&amp;fieldNameActual=CommonCode&amp;");
		sbReturnString.append("fieldNameDisplay=Product_Group_Name&amp;fromPage=CommonCodeForm&amp;firstLevelSelect=false&amp;secondLevel=false&amp;processURL=../engineeringcentral/cdmProjectProductNameEditProcess.jsp&amp;StringResourceFileId=emxEngineeringCentralStringResource&amp;SuiteDirectory=engineeringcentral', '', 'width=450', 'height=550')\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"hidden\" name=\"ProductNameOID\" value=\"\">");
		sbReturnString.append("</input>");

		return sbReturnString.toString();
	}
	
	/**
	 * Customer Search for EditForm
	 */
	@SuppressWarnings({ "rawtypes", "deprecation" })
	@com.matrixone.apps.framework.ui.ProgramCallable
	public String getEditCustomerField(Context context, String[] args) throws Exception {
		Map paramMap = (Map) JPO.unpackArgs(args);
		Map requestMap = (Map) paramMap.get("requestMap");
		String objectId = (String) requestMap.get("objectId");
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strCustomerName = MqlUtil.mqlCommand(context, "print bus '" + objectId + "' select from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER+"].to." + strDisplayTitle + " dump");
		
		String stringResource = (String) requestMap.get("StringResourceFileId");

		StringBuffer sbReturnString = new StringBuffer();


		sbReturnString.append("<input type=\"text\"  name=\"Customer\" id=\"Customer\" value=\"" + strCustomerName + "\" width=\"30\" readOnly=\"true\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"button\" name=\"\" value=\"...\" onclick=\"javascript:window.open('../common/cdmPartLibraryChooser.jsp?fieldName=CustomerOID&amp;callbackFunction=showVehicleFocus&amp;header=emxEngineeringCentral.Label.Customer&amp;multiSelect=false&amp;ShowIcons=true&amp;searchMode=CommonCode&amp;program=cdmPartLibrary:getCommonCodeFirstNode&amp;expandProgram=cdmPartLibrary:expandCommonCodeLowLankNode&amp;isFromSearch=false&amp;isNeededOId=false&amp;displayKey=name&amp;rootNode=CommonCode&amp;fieldNameActual=CommonCode&amp;");
		sbReturnString.append("StringResourceFileId=" + stringResource + "&amp;fieldNameDisplay=Customer&amp;fromPage=CommonCodeForm&amp;firstLevelSelect=false&amp;secondLevel=false&amp;processURL=../engineeringcentral/cdmProjectCustomerEditProcess.jsp&amp;StringResourceFileId=emxEngineeringCentralStringResource&amp;SuiteDirectory=engineeringcentral', '', 'width=450', 'height=550')\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"hidden\" name=\"CustomerOID\" value=\"\">");
		sbReturnString.append("</input>");

		return sbReturnString.toString();
	}
	
	/**
	 * Vehicle Search for EditForm
	 */
	@SuppressWarnings({ "rawtypes", "deprecation" })
	@com.matrixone.apps.framework.ui.ProgramCallable
	public String getEditVehicleField(Context context, String[] args) throws Exception {
		Map paramMap = (Map) JPO.unpackArgs(args);
		Map requestMap = (Map) paramMap.get("requestMap");
		String objectId = (String) requestMap.get("objectId");
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strVehicleName = MqlUtil.mqlCommand(context, "print bus '" + objectId + "' select from["+cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE+"].to." + strDisplayTitle + " dump");
		
		StringBuffer sbReturnString = new StringBuffer();

		sbReturnString.append("<input type=\"text\"  name=\"Vehicle\" id=\"Vehicle\" value=\"" + strVehicleName + "\" width=\"30\" readOnly=\"true\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"button\" name=\"\" value=\"...\" onclick=\"javascript:window.open('../common/cdmPartLibraryChooser.jsp?fieldName=VehicleOID&amp;callbackFunction=showVehicleFocus&amp;header=emxEngineeringCentral.Label.Vehicle&amp;multiSelect=false&amp;ShowIcons=true&amp;searchMode=CommonCode&amp;program=cdmPartLibrary:getCommonCodeFirstNode&amp;expandProgram=cdmPartLibrary:expandCommonCodeLowLankNode&amp;isFromSearch=false&amp;isNeededOId=false&amp;displayKey=name&amp;rootNode=CommonCode&amp;fieldNameActual=CommonCode&amp;");
		sbReturnString.append("fieldNameDisplay=Vehicle&amp;fromPage=CommonCodeForm&amp;firstLevelSelect=false&amp;secondLevel=false&amp;processURL=../engineeringcentral/cdmProjectVehicleEditProcess.jsp&amp;StringResourceFileId=emxEngineeringCentralStringResource&amp;SuiteDirectory=engineeringcentral', '', 'width=450', 'height=550')\">");
		sbReturnString.append("</input>");
		sbReturnString.append("<input type=\"hidden\" name=\"VehicleOID\" value=\"\">");
		sbReturnString.append("</input>");

		return sbReturnString.toString();
	}
	
	/**
	 * @desc Edit Project Customer Update.
	 */
	@SuppressWarnings({ "rawtypes", "deprecation" })
	public Object updateProductTypeForm(Context context, String[] args) throws Exception {
		HashMap hmProgramMap = (HashMap) JPO.unpackArgs(args);
		HashMap hmParamMap = (HashMap) hmProgramMap.get("paramMap");
		String strObjectId = (String) hmParamMap.get("objectId");
		String strNewOid = (String) hmParamMap.get("New OID");
		
		String relProjectId = MqlUtil.mqlCommand(context, "print bus '" + strObjectId + "' select from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE + "].id dump");

		if (relProjectId != null && !"".equals(relProjectId) && !"".equals(strNewOid)) {
			DomainRelationship.disconnect(context, relProjectId);
		}

		try {
			if (!"".equals(strNewOid)) {
				DomainRelationship.connect(context, new DomainObject(strObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE, new DomainObject(strNewOid));
			}
		} catch (Exception e) {
			throw e;
		}
		return Boolean.TRUE;
	}
	
	/**
	 * @desc Edit Project Customer Update.
	 */
	@SuppressWarnings({ "rawtypes", "deprecation" })
	public Object updateProductNameForm(Context context, String[] args) throws Exception {
		HashMap hmProgramMap = (HashMap) JPO.unpackArgs(args);
		HashMap hmParamMap = (HashMap) hmProgramMap.get("paramMap");
		String strObjectId = (String) hmParamMap.get("objectId");
		String strNewOid = (String) hmParamMap.get("New OID");

		String relProjectId = MqlUtil.mqlCommand(context, "print bus '" + strObjectId + "' select from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME + "].id dump");

		if (relProjectId != null && !"".equals(relProjectId) && !"".equals(strNewOid)) {
			DomainRelationship.disconnect(context, relProjectId);
		}

		try {
			if (!"".equals(strNewOid)) {
				DomainRelationship.connect(context, new DomainObject(strObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME, new DomainObject(strNewOid));
			}
		} catch (Exception e) {
			throw e;
		}
		return Boolean.TRUE;
	}
	
	/**
	 * @desc Edit Project Customer Update.
	 */
	@SuppressWarnings({ "rawtypes", "deprecation" })
	public Object updateCustomerForm(Context context, String[] args) throws Exception {
		HashMap hmProgramMap = (HashMap) JPO.unpackArgs(args);
		HashMap hmParamMap = (HashMap) hmProgramMap.get("paramMap");
		String strObjectId = (String) hmParamMap.get("objectId");
		String strNewOid = (String) hmParamMap.get("New OID");

		String relProjectId = MqlUtil.mqlCommand(context, "print bus '" + strObjectId + "' select from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER + "].id dump");
		
		if (relProjectId != null && !"".equals(relProjectId) && !"".equals(strNewOid)) {
			DomainRelationship.disconnect(context, relProjectId);
		}

		try {
			if (!"".equals(strNewOid)) {
				DomainRelationship.connect(context, new DomainObject(strObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER, new DomainObject(strNewOid));
			}
		} catch (Exception e) {
			throw e;
		}
		return Boolean.TRUE;
	}
	
	/**
	 * @desc Edit Project Customer Update.
	 */
	@SuppressWarnings({ "rawtypes", "deprecation" })
	public Object updateVehicleForm(Context context, String[] args) throws Exception {
		HashMap hmProgramMap = (HashMap) JPO.unpackArgs(args);
		HashMap hmParamMap = (HashMap) hmProgramMap.get("paramMap");
		String strObjectId = (String) hmParamMap.get("objectId");
		String strNewOid = (String) hmParamMap.get("New OID");

		String relProjectId = MqlUtil.mqlCommand(context, "print bus '" + strObjectId + "' select from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE + "].id dump");

		if (relProjectId != null && !"".equals(relProjectId) && !"".equals(strNewOid)) {
			DomainRelationship.disconnect(context, relProjectId);
		}

		try {
			if (!"".equals(strNewOid)) {
				DomainRelationship.connect(context, new DomainObject(strObjectId), cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE, new DomainObject(strNewOid));
			}
		} catch (Exception e) {
			throw e;
		}
		return Boolean.TRUE;
	}
	
	/**
	 * @desc BOM Lookup Default Vehicle
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public Vector lookupDefaultVehicle(Context context, String[] args) throws Exception {
		Vector columnValues = new Vector();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			MapList objList = (MapList) programMap.get("objectList");
			String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());

			for (int k = 0; k < objList.size(); k++) {
				Map map = (Map) objList.get(k);
				String strId = (String) map.get(DomainConstants.SELECT_ID);
				DomainObject partObj = new DomainObject(strId);
				StringList slPartRelVehicleList = partObj.getInfoList(context, "from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE + "].to." + strDisplayTitle);
				if (slPartRelVehicleList.size() > 0) {
					StringBuffer strBuffer = new StringBuffer();
					for (int i = 0; i < slPartRelVehicleList.size(); i++) {
						String strVehicle = (String) slPartRelVehicleList.get(i);
						strBuffer.append(strVehicle);
						if (i != slPartRelVehicleList.size() - 1) {
							strBuffer.append(",");
						}
					}
					columnValues.add(strBuffer.toString());
				} else {
					columnValues.add("");
				}
			}
		} catch (Exception e) {
			throw e;
		}
		return columnValues;
	}
	
	/**
	 * @desc BOM Lookup Default ProductType
	 */
	@SuppressWarnings({ "rawtypes", "deprecation", "unchecked" })
	public Vector lookupDefaultProductType(Context context, String[] args) throws Exception {
		Vector columnValues = new Vector();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			MapList objList = (MapList) programMap.get("objectList");
			String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());

			for (int k = 0; k < objList.size(); k++) {
				Map map = (Map) objList.get(k);
				String strId = (String) map.get(DomainConstants.SELECT_ID);
				String strProject = MqlUtil.mqlCommand(context, "print bus " + strId + " select from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE + "].to." + strDisplayTitle + " dump");
				columnValues.add(strProject);
			}

		} catch (Exception e) {
			throw e;
		}
		return columnValues;
	}

	/**
	 * @desc BOM Lookup Default ProductType
	 */
	@SuppressWarnings({ "rawtypes", "deprecation", "unchecked" })
	public Vector lookupDefaultProductName(Context context, String[] args) throws Exception {
		Vector columnValues = new Vector();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			MapList objList = (MapList) programMap.get("objectList");
			String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());

			for (int k = 0; k < objList.size(); k++) {
				Map map = (Map) objList.get(k);
				String strId = (String) map.get(DomainConstants.SELECT_ID);
				String strProject = MqlUtil.mqlCommand(context, "print bus " + strId + " select from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME + "].to." + strDisplayTitle + " dump");
				columnValues.add(strProject);
			}

		} catch (Exception e) {
			throw e;
		}
		return columnValues;
	}

	/**
	 * @desc BOM Lookup Default ProductType
	 */
	@SuppressWarnings({ "rawtypes", "deprecation", "unchecked" })
	public Vector lookupDefaultCustomer(Context context, String[] args) throws Exception {
		Vector columnValues = new Vector();
		try {
			HashMap programMap = (HashMap) JPO.unpackArgs(args);
			MapList objList = (MapList) programMap.get("objectList");
			String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());

			for (int k = 0; k < objList.size(); k++) {
				Map map = (Map) objList.get(k);
				String strId = (String) map.get(DomainConstants.SELECT_ID);
				String strProject = MqlUtil.mqlCommand(context, "print bus " + strId + " select from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER + "].to." + strDisplayTitle + " dump");
				columnValues.add(strProject);
			}

		} catch (Exception e) {
			throw e;
		}
		return columnValues;
	}

	/**
	 * @desc cdmPart Form Vehicle Field Value
	 */
	@SuppressWarnings("rawtypes")
	public String getVehicleForm(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strObjectId = cdmStringUtil.setEmpty((String) paramMap.get("objectId"));
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strVehicle = "";
		if (!"".equals(strObjectId)) {
			DomainObject partObj = new DomainObject(strObjectId);
			StringList slVehicleList = partObj.getInfoList(context, "from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_VEHICLE + "].to." + strDisplayTitle);
			if (slVehicleList.size() > 0) {
				StringBuffer strBuffer = new StringBuffer();
				for (int i = 0; i < slVehicleList.size(); i++) {
					String vehicle = (String) slVehicleList.get(i);
					strBuffer.append(vehicle);
					if (i != slVehicleList.size() - 1) {
						strBuffer.append(",");
					}
				}
				strVehicle = strBuffer.toString();
			}
		}
		return strVehicle;
	}

	/**
	 * @desc cdmPart Form ProductType Field Value
	 */
	@SuppressWarnings({ "rawtypes", "deprecation" })
	public String getProductTypeForm(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strObjectId = cdmStringUtil.setEmpty((String) paramMap.get("objectId"));
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strProductType = DomainConstants.EMPTY_STRING;

		try {
			if (!DomainConstants.EMPTY_STRING.equals(strObjectId)) {
				strProductType = MqlUtil.mqlCommand(context, "print bus " + strObjectId + " select from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_TYPE + "].to." + strDisplayTitle + " dump");
			}
		} catch (Exception e) {
			throw e;
		}
		return strProductType;
	}

	/**
	 * @desc cdmPart Form ProductType Field Value
	 */
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getProductNameForm(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strObjectId = cdmStringUtil.setEmpty((String) paramMap.get("objectId"));
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strProductName = DomainConstants.EMPTY_STRING;

		try {
			if (!DomainConstants.EMPTY_STRING.equals(strObjectId)) {
				strProductName = MqlUtil.mqlCommand(context, "print bus " + strObjectId + " select from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_PRODUCT_NAME + "].to." + strDisplayTitle + " dump");
			}
		} catch (Exception e) {
			throw e;
		}
		return strProductName;
	}

	/**
	 * @desc cdmPart Form ProductType Field Value
	 */
	@SuppressWarnings({ "deprecation", "rawtypes" })
	public String getCustomerForm(Context context, String[] args) throws Exception {
		HashMap programMap = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) programMap.get("paramMap");
		String strObjectId = cdmStringUtil.setEmpty((String) paramMap.get("objectId"));
		String strDisplayTitle = cdmStringUtil.browserCommonCodeLanguage(context.getSession().getLanguage());
		String strCustomer = DomainConstants.EMPTY_STRING;

		try {
			if (!DomainConstants.EMPTY_STRING.equals(strObjectId)) {
				strCustomer = MqlUtil.mqlCommand(context, "print bus " + strObjectId + " select from[" + cdmConstantsUtil.RELATIONSHIP_CDM_PROJECT_GROUP_CUSTOMER + "].to." + strDisplayTitle + " dump");
			}
		} catch (Exception e) {
			throw e;
		}
		return strCustomer;
	}

	/**
	 * @author jaehyun Check ProjectsCommand
	 */

	@SuppressWarnings({ "deprecation", "rawtypes" })
	public static boolean isProjectCheck(Context context, String[] args) throws Exception {
		HashMap paramMap = (HashMap) JPO.unpackArgs(args);
		String strObjectId = (String) paramMap.get("objectId");

		DomainObject domObj = new DomainObject(strObjectId);
		String name = domObj.getName(context);

		if ("Project Tree".equals(name)) {
			return false;
		}
		return true;
	}
	
	
	@SuppressWarnings("rawtypes")
	public String getProjectGroupLabel(Context context, String[] args) {
		try {
			Map unpackMap = JPO.unpackArgs(args);
			Map paramMap = (Map)unpackMap.get("paramMap");
			
			String objectId = (String)paramMap.get("objectId");
			
			DomainObject domObj = new DomainObject(objectId);
			
			String strProjectCodeName = domObj.getAttributeValue(context, "cdmProjectCode");
			
			if(DomainConstants.EMPTY_STRING.equals(strProjectCodeName)){
				strProjectCodeName = "Project Group";
			}
			
			return strProjectCodeName;
		} catch (Exception e) {
			e.printStackTrace();
			return "";
		} 
	}
	
	
	
}
