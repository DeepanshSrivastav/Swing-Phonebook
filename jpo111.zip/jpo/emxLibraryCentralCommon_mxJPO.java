/*
 *  emxLibraryCentralCommon.java
 *
 * Copyright (c) 1992-2015 Dassault Systemes.
 *
 * All Rights Reserved.
 * This program contains proprietary and trade secret information of
 * MatrixOne, Inc.  Copyright notice is precautionary only and does
 * not evidence any actual or intended publication of such program.
 *
 *  static const RCSID [] = "$Id: ${CLASSNAME}.java.rca 1.8 Wed Oct 22 16:02:38 2008 przemek Experimental przemek $";
 */

import matrix.db.*;
import java.lang.*;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.library.Libraries;
/**
 * @version AEF Rossini - Copyright (c) 2002, MatrixOne, Inc.
 */
public class emxLibraryCentralCommon_mxJPO extends emxLibraryCentralCommonBase_mxJPO
{

        /**
     * Constructor.
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args the Java <code>String[]</code> object
     *
     * @throws Exception if the operation fails
     *
     * @since AEF 10.6.0.1
     */

    public emxLibraryCentralCommon_mxJPO (Context context,
                         String[] args) throws Exception
    {
        super(context, args);
    }

    
    /**
     * To create a Library Central object like Library, Class etc..
     *
     * @param context the eMatrix <code>Context</code> object
     * @param args holds the following input arguments
     *      0 - requestMap
     * @return Map contains created objectId
     * @throws Exception
     */
    @com.matrixone.apps.framework.ui.CreateProcessCallable
    public Map createLBCObject(Context context, String[] args)
    throws Exception {

        HashMap requestMap  = (HashMap) JPO.unpackArgs(args);
        Map returnMap       = new HashMap();

        try {
            Libraries lib   = new Libraries();
            String objectId = lib.createLBCObject(context, requestMap);

            String ngType = "eService Number Generator";
            String ngName = "type_PartFamilyAuto";
            String ngRev = "";
            String ngVault = "eService Administration";
            BusinessObject numGenerator = new BusinessObject(ngType, ngName, ngRev, ngVault);
            int name = Integer.parseInt(numGenerator.getAttributeValues(context, "eService Next Number").getValue());
            
            MqlUtil.mqlCommand(context, "mod bus '" + objectId + "' name '" + String.format("BL%d", name));
            
            numGenerator.setAttributeValue(context, "eService Next Number", String.valueOf(name+1));
            
            returnMap.put("id", objectId);

        } catch (Exception e) {
            throw new FrameworkException(e);
        }

        return returnMap;
    }
}
