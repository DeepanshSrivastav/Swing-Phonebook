import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.beans.IEFIntegAccessUtil;
import com.matrixone.MCADIntegration.server.beans.MCADConfigObjectLoader;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.beans.MCADServerGeneralUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADGlobalConfigObject;
import com.matrixone.MCADIntegration.utils.MCADUtil;
import com.matrixone.apps.classification.AttributeGroup;
import com.matrixone.apps.classification.Classification;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainSymbolicConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.domain.util.mxBus;
import com.matrixone.apps.engineering.EBOMAutoSync;
import com.matrixone.apps.engineering.EBOMMarkup;
import com.matrixone.apps.engineering.EngineeringConstants;
import com.matrixone.apps.engineering.EngineeringUtil;
import com.matrixone.apps.engineering.PartFamily;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralConstants;
import com.matrixone.apps.library.PartLibrary;
import com.matrixone.apps.manufacturerequivalentpart.Part;
import com.matrixone.jdom.Element;
import com.matrixone.search.index.Config.formatIndexedType;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.BusinessType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.MatrixWriter;
import matrix.db.Policy;
import matrix.db.RelationshipType;
import matrix.db.StateRequirement;
import matrix.db.StateRequirementList;
import matrix.util.DateFormatUtil;
import matrix.util.List;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;
import com.mando.util.cdmCommonExcel;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

/**
 * part 이 존재하는 경우에 eng spec 이 붙여지는 경우로 생성된 migration
 *  
 *  
 * @author mj
 *
 */
public class cdmCADRelationMigration_mxJPO {
	public BufferedWriter consoleWriter			 = null;
	public BufferedWriter logWriter 			 = null;
	
	public BufferedWriter successObjectidWriter  = null;
	public BufferedWriter failedObjectidWriter   = null;
	public BufferedWriter errorLogFile        	 = null;
	public BufferedWriter debugLogFile           = null;
	public BufferedReader bufferReader           = null;
	       
	public String inputDirectory 			= "";
	public String outputDirectory 			= "";
	public String fileName 		        	= "";
	        
	public String failedIdsLogsDirectory 	= "";
	public PrintStream errorStream		    = null;
	public File successLogFile 				= null;
	public File failedLogFile 				= null;
	public Integer sequenceInt ;
	
	public static final String Output_Directory = "MIGRATION_LOGS";
	public static final String sfileSeparator 						    	= "\\";
	public static final String sRel_Associated_Drawing                      = "Associated Drawing";
	public static final String sRel_CAD_SubComponent                        = "CAD SubComponent";
	public int  mxMain(Context context,String args[])throws Exception{
		return 0;
	}
	
	/**
	 * error List
	 * 1:NOT MATCH 
	 * 2:NOT EXIST 3D CAD OBJECT.
	 * 3:NOT EXIST 2D CAD OBJECT. 
	 * 4:NOT EXIST 2D CAD ADN 3D CAD OBJECT. 
	 * 0: 기타 
	 * 
	 * 2D 와 3D 연결
	 *    
	 * initializeM 호출 하여 log 파일 생성 
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void execute2dCADRelationMigration(Context context, String args[])throws Exception{
		long startTime = System.currentTimeMillis();
		
		System.out.println("[cdmCADRelationMigration_mxJPO : execute2dCADRelationMigration] start. "+getTimeStamp() );
		String logFileName = "CAD2d3d_M";
		
		String sFileLocationAndFileName = args[0];
		String sFileLocation = "";
		String sFile = "";

		sFileLocation 	= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		sFile 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		String[] argTest = {sFileLocation,sFile}; // 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명  
//		String[] argTest = {"C:\\temp\\Import_File\\CAD","20161005_2D_3D_Relation_01.txt"}; // 읽을 파일 경로 정보 (파일명 포함되지않음) ,읽을 파일명  
		initializeM(context,argTest,2,logFileName);      //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("CAD RELATION 2D,3D DATA MIGRATION "+ getTimeStamp()+" \n");
		writeMessageToConsole("Reading input log file from : "+inputDirectory+fileName);
		writeMessageToConsole("Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		int lineNumber = 0;
		int notMajorCount = 0;
		String recordRowNum     = "";
		StringList sListHeader = new StringList();
		int successCount = 0;
		int failCount = 0;
		int totalCount = 0;
		try{
			StringBuffer sbType = new StringBuffer();
			sbType.append(cdmConstantsUtil.TYPE_CATPRODUCT);
			sbType.append(",");
			sbType.append(cdmConstantsUtil.TYPE_CATPART);
			sbType.append(",");
			sbType.append(cdmConstantsUtil.TYPE_CATDrawing);
//			sbType.append(",");
//			sbType.append("cdmSTEP");
//			sbType.append(",");
//			sbType.append("cdmV4Model");
//			sbType.append(",");
//			sbType.append("cdmCATIAcgm");
//			sbType.append(",");
//			sbType.append("cdmCATIAMaterial");
//			sbType.append(",");
//			sbType.append("cdmIGES");
//			sbType.append(",");
//			sbType.append("cdmCATIAcgr");
//			sbType.append(",");
//			sbType.append("cdmDXF");
//			sbType.append(",");
//			sbType.append("cdmSMG");
			
			StringList busSelect = new StringList();
			busSelect.add("id");
			busSelect.add("type");
			busSelect.add("attribute[cdmTDMXID]");
			busSelect.add("attribute[cdmRevisionCheckInM]");
			busSelect.add("revision");
			String where = "( policy == 'Document Release' || policy == 'Design TEAM Definition') && attribute[cdmCheckMigration] == 'Y'";
			MapList mListCADobj = new MapList();
			mListCADobj = DomainObject.findObjects(context,
					sbType.toString(), 
					"*", 
					"*",
					"*",
					"*",
					where,
					false,
					busSelect );
			
			
			
			
			HashMap<String, String> mCadHm = new HashMap<String,String>();
			HashMap<String, String> mSubCadHm = new HashMap<String,String>();
			for (Iterator iterCad = mListCADobj.iterator(); iterCad.hasNext();) {
				Map cadMigraionMap = (Map) iterCad.next();
				String cadTdmxId = (String)cadMigraionMap.get("attribute[cdmTDMXID]");
				String cadRevision = (String)cadMigraionMap.get("revision");
				String cadMId = (String)cadMigraionMap.get("id");
				String cadMType = (String)cadMigraionMap.get("type");
//				String cadRevisionCheckM = (String)cadMigraionMap.get("attribute[cdmRevisionCheckInM]");
				
				if(cdmConstantsUtil.TYPE_CATPRODUCT.equals(cadMType) || cdmConstantsUtil.TYPE_CATPART.equals(cadMType)){ 
					mCadHm.put(cadTdmxId+"_"+cadRevision, cadMId);
					
				}else if(cdmConstantsUtil.TYPE_CATDrawing.equals(cadMType) ){
					mSubCadHm.put(cadTdmxId+"_"+cadRevision, cadMId);
				}
//					else if( "cdmSTEP".equals(cadMType)){
//					mSubCadHm.put(cadTdmxId+"_"+cadRevision, cadMId);
//				}else if( "cdmV4Model".equals(cadMType)){
//					mSubCadHm.put(cadTdmxId+"_"+cadRevision, cadMId);
//				}else if( "cdmCATIAcgm".equals(cadMType)){
//					mSubCadHm.put(cadTdmxId+"_"+cadRevision, cadMId);
//				}else if( "cdmCATIAMaterial".equals(cadMType)){
//					mSubCadHm.put(cadTdmxId+"_"+cadRevision, cadMId);
//				}else if( "cdmIGES".equals(cadMType)){
//					mSubCadHm.put(cadTdmxId+"_"+cadRevision, cadMId);
//				}else if("cdmCATIAcgr" .equals(cadMType)){
//					mSubCadHm.put(cadTdmxId+"_"+cadRevision, cadMId);
//				}else if( "cdmDXF".equals(cadMType)){
//					mSubCadHm.put(cadTdmxId+"_"+cadRevision, cadMId);
//				}else if( "cdmSMG".equals(cadMType)){
//					mSubCadHm.put(cadTdmxId+"_"+cadRevision, cadMId);
//				}
			}
			//
			
			
			// minor major 
			String stReadData = "";
			while ((stReadData = bufferReader.readLine()) != null){
				StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
				/*헤더 정보 0열 위치 1열부터 데이타 존재 */
				if(lineNumber == 0){
					sListHeader = stListReadData;
					writeFailToFile("errorDate"+"\t"+"errorNum"+"\t"+stReadData);
					lineNumber++;
					continue;
				}
				lineNumber++;
				totalCount = lineNumber;
				int headerSize = sListHeader.size();
				int readLineSize = stListReadData.size();
				if (headerSize != readLineSize) {
					String errorMessage = "NOT MATCH" + stListReadData.toString() + " || " + sListHeader.toString();
					throw new Exception(errorMessage);
				}
					
				LinkedHashMap<String, Object> linkedCAD2D3DHM = new LinkedHashMap<String,Object>();
				/**
				 * header 정보는 라인이 깨지는 현상을 위해 에러처리만 함 
				 * header 정보가 중복되어 로 Map을 header정보로 구성하지않고 header 필드 열을 count .
				 * 열 정보 (필드 위치 , 열 정보, 열 관련 참조 
				 * 
				 * | 1  |NO                              | text 파일 row 정보
				 * | 2  |P_ID                            | 2D object 의 attribute[cdmTDMXID]
				 * | 3  |P_REV                           | 2D object 의 revision
				 * | 4  |TDMX_RELATED_ITEM_ID            | 2D object 의 연결된 Part 정보
				 * | 5  |TDM_DESCRIPTION                 | 
				 * | 6  |TDMX_CAD_IDENTIFIER             | 2D object 의 attribute[cdm3DCadIdentifier]
				 * | 7  |CN_RELATED_ITEM_REV             | 2D object 의 연결된 Part revision
				 * | 8  |CN_RELATED_ITEM_NAME            |
				 * | 9  |TDMX_ID                         | 3D object 의 attribute[cdmTDMXID]              
				 * | 10 |REVISION                        | 3D object 의 revision                           
				 * | 11 |TDMX_RELATED_ITEM_ID_1          | 3D object 의 연결된 Part 정보                       
				 * | 12 |TDM_DESCRIPTION_1               |                                               
				 * | 13 |TDMX_CAD_IDENTIFIER_1           | 3D object 의 attribute[cdm3DCadIdentifier]     
				 * | 14 |CN_RELATED_ITEM_REV_1           | 3D object 의 연결된 Part revision                  
				 * | 15 |CN_RELATED_ITEM_NAME_1          |  
				 * | 16 |2D            					 | 2d  major 인지 minor 인지 확인 정보   
				 * | 17 |3D            					 | 3d  major 인지 minor 인지 확인 정보 
				 * 
				 */
				for (int headerCNT = 0; headerCNT < stListReadData.size(); headerCNT++) {
//					int tempCount= headerCNT +1; 
//					String stTempCAD2D3DInfoHeaderCnt = String.valueOf(tempCount); 
					String sHeader = ((String) sListHeader.get(headerCNT)).trim();
					String stTempCAD2D3DInfos = ((String) stListReadData.get(headerCNT)).trim();
					/* 공백제거 */
					sHeader = isVaildNullData(sHeader);
					stTempCAD2D3DInfos = isVaildNullData(stTempCAD2D3DInfos);
//					linkedCAD2D3DHM.put(stTempCAD2D3DInfoHeaderCnt, stTempCAD2D3DInfos);
					linkedCAD2D3DHM.put(sHeader, stTempCAD2D3DInfos);

				}
				
				
				try {
//					recordRowNum           = (String)linkedCAD2D3DHM.get("1");                     // #  
//					String s2d_CAD         = (String)linkedCAD2D3DHM.get("2");                     // P_ID
//					String s2d_CAD_Rev     = (String)linkedCAD2D3DHM.get("3");                     // P_REV
//					String s3d_CAD	       = (String)linkedCAD2D3DHM.get("9");                     // TDMX_ID
//					String s3d_CAD_Rev     = (String)linkedCAD2D3DHM.get("14");                    // REVISION
					
					recordRowNum           = (String)linkedCAD2D3DHM.get("NO");                     // #  
					String s2d_CAD         = (String)linkedCAD2D3DHM.get("P_ID");                     // P_ID
					String s2d_CAD_Rev     = (String)linkedCAD2D3DHM.get("P_REV");                     // P_REV
					String s3d_CAD	       = (String)linkedCAD2D3DHM.get("TDMX_ID");                     // TDMX_ID
					String s3d_CAD_Rev     = (String)linkedCAD2D3DHM.get("REVISION");                    // REVISION
					String s2dMinorOrMajor = (String)linkedCAD2D3DHM.get("2D");                    // 2D
					String s3dMinorOrMajor = (String)linkedCAD2D3DHM.get("3D");                    // 3D
					
					
					String s2dCADId        = "";
					String s3dCADId        = "";
					
//					StringBuffer sbuf2dCADType = new StringBuffer();
//					sbuf2dCADType.append(cdmConstantsUtil.TYPE_CATDrawing);
					
//					StringBuffer sbufCADType = new StringBuffer();
//					sbufCADType.append(cdmConstantsUtil.TYPE_CATPRODUCT);
//					sbufCADType.append(",");
//					sbufCADType.append(cdmConstantsUtil.TYPE_CATPART);
					
					/*  검색되지않으면 에러 처리 */
					
//					String s2dCADMql       = "temp query bus "+sbuf2dCADType.toString()+" * '"+s2d_CAD_Rev+"' where \" attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID+"] == '"+s2d_CAD+"' && policy == '"+cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION +"' \" select id dump |";
//					String s2dCADMqlResult = MqlUtil.mqlCommand(context, s2dCADMql);
//					StringList sList2dCADMqlResult = new StringList();      
//					sList2dCADMqlResult = FrameworkUtil.split(s2dCADMqlResult, "|");
					
//					String s3dCADMql       = "temp query bus "+sbufCADType.toString()+" * '"+s3d_CAD_Rev+"' where \" attribute["+cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID+"] == '"+s3d_CAD+"' && policy == '"+cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION +"' \" select id dump |";
//					String s3dCADMqlResult = MqlUtil.mqlCommand(context, s3dCADMql);
//					StringList sList3dCADMqlResult = new StringList();      
//					sList3dCADMqlResult = FrameworkUtil.split(s3dCADMqlResult, "|");
					boolean b2dCADExist = false;
					boolean b3dCADExist = false;
					
//					String temp3dCadId = "";
					StringList sList2d_CAD_RevSplit = FrameworkUtil.split(s2d_CAD_Rev, "\\..+");
					StringList sList3d_CAD_RevSplit = FrameworkUtil.split(s3d_CAD_Rev, "\\..+");
					String s2d_CAD_RevSplit = "";
					s2d_CAD_RevSplit = (String)sList2d_CAD_RevSplit.get(0);
					s2d_CAD_RevSplit = s2d_CAD_RevSplit.trim();
					String s3d_CAD_RevSplit = "";
					s3d_CAD_RevSplit = (String)sList3d_CAD_RevSplit.get(0);
					s3d_CAD_RevSplit = s3d_CAD_RevSplit.trim();
					
					//
					// major 체크 필요 
					if(!"MAJOR".equalsIgnoreCase(s2dMinorOrMajor) || !"MAJOR".equalsIgnoreCase(s3dMinorOrMajor) ){
						notMajorCount++;
						continue;
					}
					
					s2dCADId = (String)mSubCadHm.get(s2d_CAD+"_"+s2d_CAD_RevSplit);
					s3dCADId = (String)mCadHm.get(s3d_CAD+"_"+s3d_CAD_RevSplit);
					
					if(UIUtil.isNotNullAndNotEmpty(s2dCADId)){
						b2dCADExist = true;
					}
					
					if(UIUtil.isNotNullAndNotEmpty(s3dCADId)){
						b3dCADExist = true;
					}
					
					if(!b3dCADExist || !b2dCADExist){
						if(b2dCADExist && !b3dCADExist ){
							String errorMessage = "NOT EXIST 3D CAD OBJECT. ";
							throw new Exception(errorMessage);
						}else if(!b2dCADExist && b3dCADExist ){
							String errorMessage = "NOT EXIST 2D CAD OBJECT. ";
							throw new Exception(errorMessage);
						}else if(!b2dCADExist && !b3dCADExist ){
							String errorMessage = "NOT EXIST 2D CAD AND 3D CAD OBJECT. ";
							throw new Exception(errorMessage);
						}
					}
					
					
					ContextUtil.startTransaction(context, true);
					DomainObject obj2D = DomainObject.newInstance(context, s2dCADId);
					DomainObject obj3D = DomainObject.newInstance(context, s3dCADId);
					MqlUtil.mqlCommand(context, "history off");
					MqlUtil.mqlCommand(context, "trigger off");
					RelationshipType relationshipType = new RelationshipType(sRel_Associated_Drawing);
					obj3D.addToObject(context, relationshipType, s2dCADId);
					MqlUtil.mqlCommand(context, "trigger on");
					MqlUtil.mqlCommand(context, "history on");
					ContextUtil.commitTransaction(context);
					successCount++;
					writeSuccessToFile("LINE_NUM(#):"+recordRowNum+"\t"+s2d_CAD+"\t"+s2d_CAD_Rev+"\t"+s3d_CAD+"\t"+s3d_CAD_Rev);
//					writeMessageToConsole(" SUCESS: LINE NUMBER: "+recordRowNum);
					
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failCount++;
					String message = exception.getMessage();
					writeMessageToConsole("LINE_NUM(#): "+recordRowNum+"\t"+message);
					if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT MATCH")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"1"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST 3D CAD OBJECT. ")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"2"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST 2D CAD OBJECT. ")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"3"+"\t"+stReadData);
					}else if(UIUtil.isNotNullAndNotEmpty(message) && message.startsWith("NOT EXIST 2D CAD AND 3D CAD OBJECT. ")){
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"4"+"\t"+stReadData);
					}else {
						writeFailToFile(cdmCommonExcel.getTimeStamp2()+"\t"+"0"+"\t"+stReadData);
						
					}
					writeErrorToFile("LINE_NUM(#): "+recordRowNum);
					exception.printStackTrace(errorStream);

//					writeFailToFile("Exception LINE NUMBER: " + recordRowNum);
				}	
			}
			

		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("        File CAD 2D,3D Relation Migration COMPLETED.                    ");
		writeMessageToConsole("====================================================================================\n");
	
		
		}catch(Exception exception)
		{
//			failCount++;
			writeMessageToConsole("LINE_NUM(#):"+recordRowNum);
			writeErrorToFile("LINE_NUM(#): "+recordRowNum );
			exception.printStackTrace(errorStream);
		}
		finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("CAD RELATION 2D,3D DATA MIGRATION CLOSE TIME:  "+getTimeStamp()+"          \n"  );
			writeMessageToConsole("LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "ms                  "  );
			
			writeMessageToConsole("failCount: ("+failCount+") successCount: ("+successCount+") not major count ("+notMajorCount+") total Count: ("+(totalCount-1)+")" );
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			System.out.println("[cdmCADRelationMigration_mxJPO : execute2dCADRelationMigration] end ."+cdmCommonExcel.getTimeStamp2());
		}
	}
	

	/**
	 * null 발생시 "" 로 체크  
	 * @param data
	 * @return
	 */
	public String isVaildNullData(String data){
		return ((data == null || "null".equals(data)) ? "" : data.trim());
	}
	
    
	private void closeLogStream() throws IOException
	{
		try 
		{
			if(null != logWriter)
				logWriter.close();

			if(null != errorStream)
				errorStream.close();

			if(null != successObjectidWriter)
				successObjectidWriter.close();

			if(null != failedObjectidWriter)
				failedObjectidWriter.close();
		} 
		catch (IOException e) 
		{
			System.out.println("Exception while closing log stream "+e.getMessage());
		}
	}
	
	private void writeErrorToFile(String message)throws Exception{
		errorStream.write(message.getBytes("UTF-8"));
		errorStream.write("\n".getBytes("UTF-8"));
	}
	
	private void writeMessageToConsole(String message) throws Exception
	{
		writeMessageToLogFile(message);
	}

	private void writeMessageToLogFile(String message) throws Exception
	{
		logWriter.write( message + "\n");
		logWriter.flush();
	}
	
	private String getTimeStamp(){
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date)+"T"+ new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}
	
	public void writeFailToFile(String message) throws Exception{
		failedObjectidWriter.write( message + "\n");
		failedObjectidWriter.flush();
	}
	public void writeSuccessToFile(String message)throws Exception{
		successObjectidWriter.write(message + "\n");
		successObjectidWriter.flush();
	}
	
	/**
	 *  로그파일4 개 생성 
	 * 
	 * @param context
	 * @param args
	 * @param requestAgsNum
	 * @param logFileName
	 */
	private void initializeM(Context context,String args[],int requestAgsNum , String logFileName)throws Exception{

		sequenceInt			= 1;

		if (args.length != requestAgsNum )
		{
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}


		inputDirectory = args[0];

		// documentDirectory does not ends with "/" add it
		if(inputDirectory != null && !inputDirectory.endsWith(sfileSeparator))
		{
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + Output_Directory + sfileSeparator + logFileName  +"_"+   sfileSeparator;
        File fileOutputDirectory = new File(outputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        // input file name
     	fileName = args[1];
     	
		String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
        logFileName += "_"+fileName.substring(0, fileName.lastIndexOf("."))+"_"+formatTime;
		logWriter 			 	= new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(outputDirectory + logFileName + "_SuccessObjectids.txt");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(outputDirectory + logFileName + "_FailedObjectids" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		
		bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory+fileName),"euc-kr"));
	
	}
	
	
	
	public void Test(Context context, String arg[])throws Exception{
		
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	public void delete(Context context, String arg[])throws Exception{
		
		try {
			
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}
	
	
}


