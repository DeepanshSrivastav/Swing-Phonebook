import matrix.db.Context;


@SuppressWarnings("serial")
public class emxCommonRDOMigration_mxJPO extends
		emxCommonRDOMigrationBase_mxJPO {

	public emxCommonRDOMigration_mxJPO(Context context, String[] args)
			throws Exception {
		super(context, args);
		// TODO Auto-generated constructor stub
	}

}
