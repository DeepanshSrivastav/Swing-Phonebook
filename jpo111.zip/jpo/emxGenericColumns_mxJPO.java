import matrix.db.Context;


public class emxGenericColumns_mxJPO extends emxGenericColumnsBase_mxJPO {
	
    /**
     * @param context
     * @param args
     * @throws Exception
     */
    public emxGenericColumns_mxJPO(Context context, String[] args) throws Exception {
    	super(context, args);
    } 

}
