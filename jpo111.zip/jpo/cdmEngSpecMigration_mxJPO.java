import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.nio.CharBuffer;
import java.nio.charset.Charset;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.beans.MCADConfigObjectLoader;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADUtil;
import com.matrixone.apps.classification.AttributeGroup;
import com.matrixone.apps.classification.Classification;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainSymbolicConstants;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.engineering.EBOMAutoSync;
import com.matrixone.apps.engineering.EBOMMarkup;
import com.matrixone.apps.engineering.EngineeringConstants;
import com.matrixone.apps.engineering.EngineeringUtil;
import com.matrixone.apps.engineering.PartFamily;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.LibraryCentralConstants;
import com.matrixone.apps.library.PartLibrary;
import com.matrixone.apps.manufacturerequivalentpart.Part;
import com.matrixone.jdom.Element;
import com.matrixone.search.index.Config.formatIndexedType;

import matrix.db.Attribute;
import matrix.db.AttributeItr;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.BusinessObjectAttributes;
import matrix.db.BusinessObjectList;
import matrix.db.BusinessType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.MatrixWriter;
import matrix.db.RelationshipType;
import matrix.util.DateFormatUtil;
import matrix.util.List;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;
import com.mando.util.cdmCommonExcel;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

/**
 * part 이 존재하는 경우에 eng spec 이 붙여지는 경우로 생성된 migration
 *  
 *  
 * @author mj
 *
 */
public class cdmEngSpecMigration_mxJPO {
	public BufferedWriter consoleWriter			 = null;
	public BufferedWriter logWriter 			 = null;
	public XSSFWorkbook workbook  				 = null;
	public XSSFSheet    sheet   				 = null;
	
	public BufferedWriter successObjectidWriter  = null;
	public BufferedWriter failedObjectidWriter   = null;
	public BufferedWriter noExistPartFamilyWriter= null;
	public BufferedWriter errorLogFile        	 = null;
	public BufferedWriter debugLogFile           = null;
	public BufferedReader bufferReader           = null;
	       
	public String inputDirectory 			= "";
	public String outputDirectory 			= "";
	public String fileName 		        	= "";
	        
	public PrintStream errorStream		    = null;
	public File successLogFile 				= null;
	public File failedLogFile 				= null;
	public File noExistPartFamilyFile		= null;
	
	public static final String S_PROPERTIESFILE             ="com/mando/migration/cdmMigrationStringResource";
	public static final String sCreateAttributeGroupSuffix				= "cdm";
	public static final String sClassificationAttributeGroups 			= DomainConstants.INTERFACE_CLASSIFICATION_ATTRIBUTE_GROUPS;
	public static final String sfileSeparator 							= "\\";
	public static final String sUnderline  								= "_";
	public static final String sColon   								= ":";
	public static final String sOutPutDirectory							= "MIGRATION_LOGS";
	public int  mxMain(Context context,String args[])throws Exception{
		return 0;
	}
	
	/**
	 * 파라미터 데이타를 사용하지않고 argTest 이라는 string[] 에 직접 입력하여  initializeM 호출.
	 * 엑셀 사용되는 시트명은 데이타.
	 * 
	 * args[0] :eng spec file path 
	 * args[1] :attribute group file path
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void executeEngSpecMigration(Context context, String args[])throws Exception{
		long startTime = System.currentTimeMillis();
		System.out.println("[cdmENGSPECMigration : executeENGSPECMigration] start ."+cdmCommonExcel.getTimeStamp2() );
		
//		if(args.length!=2){
//			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
//		}
		
//		Properties prop = new Properties();
//		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
//		String attributeGroupExcelPath 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Path"));
//		String attributeGroupExcelName 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Name"));
//		String attributeGroupDataSheetName			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Attribute_Data_Sheet_Name"));
		String attributeGroupDataSheetName			= "data";
//		Map paramMap = JPO.unpackArgs(args);
		String sFileLocationAndFileName = args[0];
//		String sFileLocationAndFileName = (String)paramMap.get("fileData");
		String engspecFilePath = "";
		String engspecFileName = "";

		engspecFilePath 		= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		engspecFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		String sAttributeGroupExcelPath = args[1];
//		String sAttributeGroupExcelPath = (String)paramMap.get("attributeFileData");;
		String attributeGroupExcelPath = sAttributeGroupExcelPath.substring(0, sAttributeGroupExcelPath.lastIndexOf(File.separator));
		String attributeGroupExcelName = sAttributeGroupExcelPath.substring(sAttributeGroupExcelPath.lastIndexOf(File.separator)+1); 
				
		String logFileName = "EngSpecM";
		
		
		 //읽을 파일경로 ,읽을 파일명,  읽을 엑셀 경로,엑셀 파일명,엑셀의 시트명
		String[] argTest = {engspecFilePath,engspecFileName,attributeGroupExcelPath,attributeGroupExcelName,attributeGroupDataSheetName}; 
		initializeM(context,argTest,5,logFileName);      //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("ENG SPEC DATA MIGRATION Start Time: "+ getTimeStamp()+" \n");
		writeMessageToConsole("Reading input log file from : "+inputDirectory+fileName);
		writeMessageToConsole("Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		int lineNumber = 0;
		StringList stListHeader = new StringList();
		int successcount = 0;
		int failCount = 0;
		int totalCount = 0;
		String recordRowNum     = "";
		try{
			
			HashMap<String,String> attributeHM = new HashMap<String,String>();
			int sheetPhysicalNumberRows = sheet.getPhysicalNumberOfRows();
			// 0 라인엔 헤더 정보 데이타존재 1부터 시작한다.
			for (int sheetrow = 1; sheetrow < sheetPhysicalNumberRows; sheetrow++) {
				 XSSFRow row = sheet.getRow(sheetrow);
				 if (row == null){
					 continue;
				 }
				 
				XSSFCell cell_1 = row.getCell(1);
				XSSFCell cell_2 = row.getCell(2);
				 
				String stCellAttributeDec 	= String.valueOf((Object) cdmCommonExcel.getCellValue(cell_1));
				String stCellAttributeName  = String.valueOf((Object) cdmCommonExcel.getCellValue(cell_2));
				
				stCellAttributeDec = isVaildNullData(stCellAttributeDec);
				stCellAttributeName = isVaildNullData(stCellAttributeName);
				
				if(cdmStringUtil.isNotEmpty(stCellAttributeName) && cdmStringUtil.isNotEmpty(stCellAttributeDec)){
					String tempAttributeName = "cdm"+stCellAttributeName;
					attributeHM.put(stCellAttributeDec, tempAttributeName);
				}
			}
			String stErrorRow = ""; // error
			boolean checkTriggerOff = false;
			String stReadData = "";
			/* **************************************************************************************
			 * The header information is 0 rows.Information from line 1.
			************************************************************************************** */
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory+sfileSeparator+fileName),"euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null){
				try {
					totalCount = lineNumber-1;
					StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
					
					if(lineNumber == 0){
						writeFailToFile("errorDate \t errorVersion \t"+stReadData);
						stListHeader = stListReadData ;
						
						lineNumber++;
						continue;
					}
					lineNumber++;
					stErrorRow = stReadData;
					
					LinkedHashMap<String, Object> linkedEngSpecHM = new LinkedHashMap<String,Object>();
					for(int stListNum = 0; stListNum<stListReadData.size() ;stListNum++){
						String stTempEngSpecnfos = ((String)stListReadData.get(stListNum)).trim();
						String stTempEngSpecHeader = ((String)stListHeader.get(stListNum)).trim();
						stTempEngSpecnfos = isVaildNullData(stTempEngSpecnfos);
						
						linkedEngSpecHM.put(stTempEngSpecHeader, stTempEngSpecnfos);
					}
					
					
					String stItem_Num         = (String)linkedEngSpecHM.get("#");            				//1   rowNumber
//					String stAttributeGroup   = (String)linkedEngSpecHM.get("TDM_DESCRIPTION");             //2    
//					String stPartFamilyName   = (String)linkedEngSpecHM.get("CN_CODE");            		    //3   AG 
					String sBlockCode   	  = (String)linkedEngSpecHM.get("CN_CODE");            		    //4   
					String stPartName         = (String)linkedEngSpecHM.get("CN_PART_NUMBER");              //5   Part Name
					String stPartRev          = (String)linkedEngSpecHM.get("CN_PART_REV");             	//6   Part Rev
					recordRowNum    		  =  stItem_Num;                                                        
					
					/*  ****************************************************************************************
					 * 	attribute group에 partFamily가 연결되어있는지 확인 	안되어있으면 연결
					 *  part family 존재 attribute group 여부 확인 필요 없으면 에러 처리  
					 *  연결이 되어있다면 partFamily에 연결
					 *  연결시 connect 정보에  attribute 추가 하여 마이그레이션 여부 체크 
					 *	***************************************************************************************  */
					ContextUtil.startTransaction(context, true);
					MqlUtil.mqlCommand(context, "Trigger Off");
					checkTriggerOff = true;
					
					/*Attribute Group Confirm creation*/
//					String sAttributeGroupName = sBlockCode;
					String checkAttributeGroup = "immediatederivative["+sBlockCode+"]";
					String checkCreateAttribute = "list interface $1 select $2 dump $3";
					String checkAGMqlResult = MqlUtil.mqlCommand(context, checkCreateAttribute, sClassificationAttributeGroups,checkAttributeGroup,"|");
					//block code 검사 
					if (!Boolean.valueOf(checkAGMqlResult)) {
						String errorMessage = "AG does not exist." ;
						throw new Exception(errorMessage);
					}
					
				
					/*part 생성 여부 확인 */
					String sPartTypes = cdmConstantsUtil.TYPE_CDMPHANTOMPART+","+cdmConstantsUtil.TYPE_CDMMECHANICALPART;
					String sPartCreateCheckMqlResult = MqlUtil.mqlCommand(context, "temp query bus \""+sPartTypes+"\"  \""+stPartName+"\"  \""+stPartRev +"\" select id dump |");
//					
					StringList stListPartCreateCheckMqlResult = new StringList(); 
					stListPartCreateCheckMqlResult = FrameworkUtil.split(sPartCreateCheckMqlResult, "|");
					String sPartId = "";
					String sPartFamilyId = "";
					StringList sListPartFamilyId = new StringList();
					if (stListPartCreateCheckMqlResult.size() > 2) {
						sPartId = (String) (FrameworkUtil.split(sPartCreateCheckMqlResult, "|").get(3));
						DomainObject dObjPart = new DomainObject();
						dObjPart.setId(sPartId);
//						sPartFamilyId = (String)dObjPart.getInfo(context, "to[Classified Item].from.id");
						sListPartFamilyId = dObjPart.getInfoList(context, "to[Classified Item].from.id");
						
//						if(UIUtil.isNotNullAndNotEmpty(sPartFamilyId)){
						if(sListPartFamilyId.size()>0 && sListPartFamilyId!=null){
							boolean checkExistAG = false;
							for (Iterator sListPFiterator = sListPartFamilyId.iterator(); sListPFiterator.hasNext();) {
								sPartFamilyId = (String) sListPFiterator.next();
							
								com.matrixone.apps.classification.Classification clsObject = (com.matrixone.apps.classification.Classification) DomainObject.newInstance(context, sPartFamilyId, "Classification");
								StringList stListGetAttributeGroup = new StringList();
								stListGetAttributeGroup = clsObject.getAttributeGroups(context, false);
								// 	part family 에 속한 AG 확인 
								if(stListGetAttributeGroup.contains(sBlockCode)){
									checkExistAG = true;
								}
							}
							if(!checkExistAG){
								String errorMessage = "There is no AG in part family.";
								throw new Exception(errorMessage);
							}
						}else{
							String errorMessage = "Not exist Part Family object.";
							throw new Exception(errorMessage);
						}
					}else{
						String errorMessage = "Not exist Part object.";
						throw new Exception(errorMessage);
					}
					
					/*속성정보 확인 */
					Map attributesMap = new HashMap();
					boolean checkAttributeInfo = true;
					String tempErrorAttributeName = "";
					String tempErrorKeyCnt= "";
					
					for (int keyCnt = 1; keyCnt <= 30; keyCnt++) {
						int tempKeyCnt = keyCnt;
						String stkeyCnt = String.format("%02d", tempKeyCnt);
						
						String sKeySpec = (String) linkedEngSpecHM.get("CN_SPEC_NAME_" + stkeyCnt);
						if (cdmStringUtil.isNotEmpty(sKeySpec)) {
							String sAttributeName = (String) attributeHM.get(sKeySpec);
	
							if (cdmStringUtil.isNotEmpty(sAttributeName)) {
	
								String sValueSpec = (String) linkedEngSpecHM.get("CN_VALUE_" + stkeyCnt);
	
								if (cdmStringUtil.isNotEmpty(sValueSpec)) {
									attributesMap.put(sAttributeName, sValueSpec);
								}
								
	
								
							} 
						}
					}

	
						/* 속성 입력 */
						DomainObject dObjPart = new DomainObject(sPartId);
						
						String sClassifiedRelationship = cdmConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM;
						String sFromTypeName = cdmConstantsUtil.TYPE_PART_FAMILY;
						boolean boolRelationshipDirectionTo = true;
						boolean boolRelationshipDirectionFrom = false;
						StringList stListClassifiedBusSelects = new StringList(1);
						StringList stListClassifiedRelSelects = new StringList(1);
						stListClassifiedBusSelects.add(cdmConstantsUtil.SELECT_ID);
						stListClassifiedRelSelects.add("id[connection]");
						String sBusWhere = "";
						String sRelWhere = "from.id == '"+sPartFamilyId+"'";
						MapList mapListClassified = (MapList)dObjPart.getRelatedObjects(context, 
								sClassifiedRelationship,
								sFromTypeName,
								stListClassifiedBusSelects,
								stListClassifiedRelSelects,
								boolRelationshipDirectionTo,
								boolRelationshipDirectionFrom,
								(short) 0,
								sBusWhere,
								sRelWhere,
								0
								);
						
						for (Iterator iterator = mapListClassified.iterator(); iterator.hasNext();) {
							Map mapClassified = (Map) iterator.next();
							String relId = (String)mapClassified.get("id[connection]");
							
							if(cdmStringUtil.isNotEmpty(relId)){
								String relModifyMql = "mod connection "+relId + " \"cdmCheckMigration\"  "+"  \"Y\"  ";
								MqlUtil.mqlCommand(context, relModifyMql);
								break;
							}
						}
	
						DomainObject dPart = new DomainObject(sPartId);
						Part part = new Part(dPart);
						Map attributePartMap = new HashMap();
						attributePartMap = part.getAttributeMap(context);
						StringList sListAttribute = new StringList();
						AttributeList localAttributeList = part.getAttributes(context).getAttributes();
						for (Iterator localAttr = localAttributeList.iterator(); localAttr.hasNext();) {
							Attribute attributePart = (Attribute) localAttr.next();
							String attributeName = attributePart.getAttributeType().getName();
							
							if(!sListAttribute.contains(attributeName)){
								sListAttribute.add(attributeName);
							}
						}
						StringList attributeKeyList = new StringList();
						if(attributesMap!=null){
							 Iterator itr  =  attributesMap.keySet().iterator();
				             while(itr.hasNext()){
				                 String key = (String)itr.next();
				                 if(!sListAttribute.contains(key)){
				                	 String errorMessage = "Not exist Part attribute Info. \t"+key;
										throw new Exception(errorMessage);
				                 }else{
				                	 attributeKeyList.add(key);
				                 }
				                 
				             }
						}
						//
						
						//
						
						
						part.setAttributeValues(context, attributesMap);
//					}
					ContextUtil.commitTransaction(context);
					successcount++;
					writeSuccessToFile(lineNumber+" \t SUB_LINENUBMER: \t "+ recordRowNum+"\t"+sBlockCode+"\t"+stPartName+"\t"+stPartRev+"\t"+attributeKeyList.toString());
					MqlUtil.mqlCommand(context, "Trigger On");
					checkTriggerOff = false;
					
					
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					failCount++;
					String errorMessage = exception.getMessage();
					
					writeMessageToConsole(getTimeStamp()+"\t"+"SUB_LINENUBMER \t"+ recordRowNum+" \t " + exception.getMessage());
					
					if(UIUtil.isNotNullAndNotEmpty(errorMessage) && errorMessage.startsWith("AG does not exist.")){
						writeFailToFile(getTimeStamp()+"\t"+"1"+"\t"+stErrorRow);
					}else if(UIUtil.isNotNullAndNotEmpty(errorMessage) && errorMessage.startsWith("There is no AG in part family.")){
						writeFailToFile(getTimeStamp()+"\t"+"2"+"\t"+stErrorRow);
					}else if(UIUtil.isNotNullAndNotEmpty(errorMessage) && errorMessage.startsWith("Not exist Part Family object.")){
						writeFailToFile(getTimeStamp()+"\t"+"3"+"\t"+stErrorRow);
					}else if(UIUtil.isNotNullAndNotEmpty(errorMessage) && errorMessage.startsWith("Not exist Part object.")){
						writeFailToFile(getTimeStamp()+"\t"+"4"+"\t"+stErrorRow);
					}else if(UIUtil.isNotNullAndNotEmpty(errorMessage) && errorMessage.startsWith("Not exist Part attribute Info.")){
						writeFailToFile(getTimeStamp()+"\t"+"5"+"\t"+stErrorRow);
					}
					
					else{
						writeFailToFile(getTimeStamp()+"\t"+"0"+"\t"+stErrorRow);
					}
					writeErrorToFile(lineNumber+"\t  SUB_LINENUBMER: \t"+ recordRowNum+" \t "+cdmCommonExcel.getTimeStamp2() +"\t"+errorMessage);
					exception.printStackTrace(errorStream);

				}finally{
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "Trigger On");
						checkTriggerOff = false;
					}
				}
			}
				
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        File ENG SPEC Migration COMPLETED                    ...\n");
			writeMessageToConsole("====================================================================================\n");
	
		
		}catch(Exception exception)
		{
			writeFailToFile("LINENUMBER: " +lineNumber+" | EXCEPTION: " + exception.getMessage());
			writeErrorToFile("LINENUMBER: " +lineNumber+" | EXCEPTION: "+exception.getMessage());
			exception.printStackTrace(errorStream);
		}
		finally {
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("END TIME: ("+ getTimeStamp() +")"+"LEAD TIME:"+ (System.currentTimeMillis() - startTime)/1000/60 + "             ");
			writeMessageToConsole("SUCCESS COUNT: ("+successcount+") FAILT COUNT: ("+failCount+") TOTAL COUNT: ("+(totalCount-1)+")");
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			System.out.println("[cdmENGSPECMigration : executeENGSPECMigration] end ."+cdmCommonExcel.getTimeStamp2());
		}
	}
	
	
	
	/**
	 * 위의 메서드와는 다르게 attribute group와 연결된 part family와 part을 연결하고  
	 * part 의 속성에  데이타를 추가한다. 
	 * 12/13
	 * 위에 있는 것은 기존에 연결된 attribute 속성과 연결되어있는 part와 속성을 추가하는것 뿐 (수정요구 전사항임)
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void executeEngSpecModify(Context context ,String args[])throws Exception{

		long startTime = System.currentTimeMillis();
		System.out.println("[cdmENGSPECMigration : executeEngSpecModify] start ."+cdmCommonExcel.getTimeStamp2() );
		
		Properties prop = new Properties();
		prop = cdmCommonExcel.getProperty(S_PROPERTIESFILE);
		String attributeGroupExcelPath 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Path"));
		String attributeGroupExcelName 			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Name"));
		String attributeGroupDataSheetName			= cdmStringUtil.convertISOtoUTF8((String)prop.get("Attribute_Group_Excel_Attribute_Data_Sheet_Name"));
	
		String sFileLocationAndFileName = args[0];
		String engspecFilePath = "";
		String engspecFileName = "";

		engspecFilePath 		= sFileLocationAndFileName.substring(0,sFileLocationAndFileName.lastIndexOf("\\"));
		engspecFileName 		= sFileLocationAndFileName.substring(sFileLocationAndFileName.lastIndexOf("\\")+1);
		
		String logFileName = "EngSpecM";
		logFileName+="_"+engspecFileName;
		
		 //읽을 파일경로 ,읽을 파일명,  읽을 엑셀 경로,엑셀 파일명,엑셀의 시트명
//		String[] argTest = {"C:\\temp\\Import_File\\ENG_SPEC","Retrieve_BD_EngSpec_Data_00.txt","C:\\temp\\Import_File\\ATTRIBUTE_GROUP\\","20160818_002 DM_SPEC_NAME.xlsx","데이타"}; 
		String[] argTest = {engspecFilePath,engspecFileName,attributeGroupExcelPath,attributeGroupExcelName,attributeGroupDataSheetName}; 
		//context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		initializeM(context,argTest,5,logFileName);      
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("ENG SPEC DATA MIGRATION Start Time: "+ getTimeStamp()+" \n");
		writeMessageToConsole("Reading input log file from : "+inputDirectory+fileName);
		writeMessageToConsole("Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		int lineNumber = 0;
		StringList stListHeader = new StringList();
		int successcount = 0;
		int failCount = 0;
		int totalCount = 0;
		String recordRowNum     = "";
		try{
			
			HashMap<String,String> attributeHM = new HashMap<String,String>();
			int sheetPhysicalNumberRows = sheet.getPhysicalNumberOfRows();
			// 0 라인엔 헤더 정보 데이타존재 1부터 시작한다.
			for (int sheetrow = 1; sheetrow < sheetPhysicalNumberRows; sheetrow++) {
				 XSSFRow row = sheet.getRow(sheetrow);
				 if (row == null){
					 continue;
				 }
				 
				XSSFCell cell_1 = row.getCell(1);
				XSSFCell cell_2 = row.getCell(2);
				 
				String stCellAttributeDec 	= String.valueOf((Object) cdmCommonExcel.getCellValue(cell_1));
				String stCellAttributeName  = String.valueOf((Object) cdmCommonExcel.getCellValue(cell_2));
				
				stCellAttributeDec = isVaildNullData(stCellAttributeDec);
				stCellAttributeName = isVaildNullData(stCellAttributeName);
				
				if(cdmStringUtil.isNotEmpty(stCellAttributeName) && cdmStringUtil.isNotEmpty(stCellAttributeDec)){
					String tempAttributeName = "cdm"+stCellAttributeName;
					attributeHM.put(stCellAttributeDec, tempAttributeName);
				}
			}
			String stErrorRow = ""; // error
			boolean checkTriggerOff = false;
			String stReadData = "";
			/* **************************************************************************************
			 * The header information is 0 rows.Information from line 1.
			************************************************************************************** */
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory+sfileSeparator+fileName),"euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null){
				try {
					totalCount = lineNumber-2;
					StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
					
					if(lineNumber == 0){
						writeFailToFile(stReadData);
						stListHeader = stListReadData ;
						
						lineNumber++;
						continue;
					}
					lineNumber++;
					stErrorRow = stReadData;
					
					LinkedHashMap<String, Object> linkedEngSpecHM = new LinkedHashMap<String,Object>();
					for(int stListNum = 0; stListNum<stListReadData.size() ;stListNum++){
						String stTempEngSpecnfos = ((String)stListReadData.get(stListNum)).trim();
						String stTempEngSpecHeader = ((String)stListHeader.get(stListNum)).trim();
						stTempEngSpecnfos = isVaildNullData(stTempEngSpecnfos);
						linkedEngSpecHM.put(stTempEngSpecHeader, stTempEngSpecnfos);
					}
					
					
					String stItem_Num         = (String)linkedEngSpecHM.get("#");            				//1   rowNumber
//					String stAttributeGroup   = (String)linkedEngSpecHM.get("TDM_DESCRIPTION");             //2    
					String sBlockCode    	  = (String)linkedEngSpecHM.get("CN_CODE");            	   		//3   AG
					String stPartName         = (String)linkedEngSpecHM.get("CN_PART_NUMBER");              //4   Part Name
					String stPartRev          = (String)linkedEngSpecHM.get("CN_PART_REV");             	//5   Part Rev
					recordRowNum    		  =  stItem_Num;                                                        
					
					/*  ****************************************************************************************
					 * 	attribute group에 partFamily가 연결되어있는지 확인 	안되어있으면 연결
					 *  part family 존재 attribute group 여부 확인 필요 없으면 에러 처리  
					 *  연결이 되어있다면 partFamily에 연결
					 *  연결시 connect 정보에  attribute 추가 하여 마이그레이션 여부 체크 
					 *	***************************************************************************************  */
					ContextUtil.startTransaction(context, true);
					MqlUtil.mqlCommand(context, "Trigger Off");
					checkTriggerOff = true;
					
					/*Attribute Group Confirm creation*/
					String sAttributeGroupName = sBlockCode;
					String checkAttributeGroup = "immediatederivative["+sBlockCode+"]";
					String checkCreateAttribute = "list interface $1 select $2 dump $3";
					String checkAGMqlResult = MqlUtil.mqlCommand(context, checkCreateAttribute, sClassificationAttributeGroups,checkAttributeGroup,"|");
					
					if (!Boolean.valueOf(checkAGMqlResult)) {
						String errorMessage = "NOT EXIST ATTRIBUTEFROUP OBJECT." ;
						throw new Exception(errorMessage);
					}
					
					String sFindPFMql = "temp query bus 'Part Family' * * where \" attribute[cdmPartFamilyBlockCodeName] ~= '"+ sBlockCode+"*' \" select id dump |";
					
					String sPartFamilyId = "";
					String sFindPFMqlResult = MqlUtil.mqlCommand(context,sFindPFMql);
					StringList sListFindPFMqlResult = new StringList();
					sListFindPFMqlResult = FrameworkUtil.split(sFindPFMqlResult, "|");
					boolean checkNotBlockCodePF = false;
					if(sListFindPFMqlResult.size() > 1){
						sPartFamilyId = (String)sListFindPFMqlResult.get(3);
						
					}else{
						
						//파일이 없을시 데이타는 part 에 연결된 part 의 classfied 정보로 가져와서 처리 한다. 
						/*그래도 없다면 에러 */
						checkNotBlockCodePF = true;
						writeNoPFFile(stItem_Num+"\t"+ sBlockCode+"\t"+stPartName+"\t"+stPartRev);
//						String errorMessage = "NOT EXIST PART FAMILY OBJECT." ;
//						throw new Exception(errorMessage);
						//로그 파일 별도로 추가할것 
						
					}
					
					/*part 생성 여부 확인 */
					String sPartTypes = cdmConstantsUtil.TYPE_CDMPHANTOMPART+","+cdmConstantsUtil.TYPE_CDMMECHANICALPART;
					String sPartCreateCheckMqlResult = MqlUtil.mqlCommand(context, "temp query bus \""+sPartTypes+"\"  \""+stPartName+"\"  \""+stPartRev +"\" select id dump |");
//					
					StringList stListPartCreateCheckMqlResult = new StringList(); 
					stListPartCreateCheckMqlResult = FrameworkUtil.split(sPartCreateCheckMqlResult, "|");
					String sPartId = "";
					if (stListPartCreateCheckMqlResult.size() > 2) {
						sPartId = (String) (FrameworkUtil.split(sPartCreateCheckMqlResult, "|").get(3));
						
					}else{
						String errorMessage = "NOT EXIST PART OBJECT." ;
						throw new Exception(errorMessage);
						
					}
					boolean bCheckAG = false;
					DomainObject existCheckPart = new DomainObject(sPartId);
					String classfiedItemFromId = "";
					classfiedItemFromId = (String)existCheckPart.getInfo(context, "to[Classified Item].from.id");
					if(UIUtil.isNotNullAndNotEmpty (classfiedItemFromId)){
						
						PartLibrary partfamilyCheck = new PartLibrary(classfiedItemFromId);

						com.matrixone.apps.classification.Classification clsObjectCheck = (com.matrixone.apps.classification.Classification) DomainObject.newInstance(context, partfamilyCheck, "Classification");
						StringList stListGetAttributeGroup = new StringList();
	
						stListGetAttributeGroup = clsObjectCheck.getAttributeGroups(context, false);
						for (Iterator iteratorGetAttributeGroup = stListGetAttributeGroup.iterator(); iteratorGetAttributeGroup.hasNext();) {
							String agName = (String) iteratorGetAttributeGroup.next();
							if(agName.equals(sBlockCode)){
								bCheckAG = true;
								break;
							}
							
						}
						
						
					}
					
					
					if(!bCheckAG){
						throw new Exception("not exist ag data.");
						
					}
					/*속성정보 확인 */
					Map attributesMap = new HashMap();
					boolean checkAttributeInfo = true;
					String tempErrorAttributeName = "";
					String tempErrorKeyCnt= "";
					
					for (int keyCnt = 1; keyCnt <= 30; keyCnt++) {
						int tempKeyCnt = keyCnt;
						String stkeyCnt = String.format("%02d", tempKeyCnt);
						
						String sKeySpec = (String) linkedEngSpecHM.get("CN_SPEC_NAME_" + stkeyCnt);
						if (cdmStringUtil.isNotEmpty(sKeySpec)) {
							String sAttributeName = (String) attributeHM.get(sKeySpec);
	
							if (cdmStringUtil.isNotEmpty(sAttributeName)) {

								String sValueSpec = (String) linkedEngSpecHM.get("CN_VALUE_" + stkeyCnt);

								if (cdmStringUtil.isNotEmpty(sValueSpec)) {
									attributesMap.put(sAttributeName, sValueSpec);
								}

							} 
						}
					}

					/* part family 와 ag 연결 
					 * 연결되어있지 않다면 AG 와 연결한다.
					 * */
//					com.matrixone.apps.classification.Classification clsObject = (com.matrixone.apps.classification.Classification) DomainObject.newInstance(context, sPartFamilyId, "Classification");
//					StringList stListGetAttributeGroup = new StringList();
//
//					stListGetAttributeGroup = clsObject.getAttributeGroups(context, false);
//					if ( !stListGetAttributeGroup.contains(sAttributeGroupName)){
//						
//						clsObject.addAttributeGroup(context, sAttributeGroupName);
//					 }

					/* partFamily 와 Part 연결 */
//					boolean checkAlreadyConnect = false;
//					DomainObject checkForPartDobj = new DomainObject(sPartId);
//					Object partFaimlyIdCheckObj = new Object();
//					partFaimlyIdCheckObj = checkForPartDobj.getInfo(context, "to[Classified Item].from.id");
//					if(partFaimlyIdCheckObj instanceof String){
//						if(sPartFamilyId.equals(partFaimlyIdCheckObj)){
//							checkAlreadyConnect = true;
//						}
//					}else if(partFaimlyIdCheckObj instanceof StringList){
//						StringList sListpartFaimlyIds = new StringList();
//						sListpartFaimlyIds = (StringList) partFaimlyIdCheckObj;
//						for (Iterator iterPartFamilyId = sListpartFaimlyIds.iterator(); iterPartFamilyId.hasNext();) {
//							String checkPartFamilyData = (String) iterPartFamilyId.next();
//							if(sPartFamilyId.equals(checkPartFamilyData)){
//								checkAlreadyConnect = true;
//								break;
//							}
//							
//						}
//					}
					
//					MQLCommand mqlConnectPartAndPFCommand = new MQLCommand();
//					mqlConnectPartAndPFCommand.open(context);
//
//					PartFamily partFamily = (PartFamily) DomainObject.newInstance(context, DomainConstants.TYPE_PART_FAMILY, DomainConstants.ENGINEERING);
//					partFamily.setId(sPartFamilyId);
					
//					if (!checkAlreadyConnect) {
//						try {
//
//							mqlConnectPartAndPFCommand.executeCommand(context, "set transaction savepoint $1", "PartFamily");
//							partFamily.addPart(context, sPartId);
//
//							// trigger start
//							// 1
//							// try {
//							// int status = 0;
//							// String ObjectId = sPartId;
//							// String sFromObjectId = sPartFamilyId;
//							// // String sFromObjectId = args[1]; //
//							// // ${FROMOBJECTID}
//							// if (sFromObjectId == null || ObjectId == null ||
//							// sFromObjectId.equals("") || ObjectId.equals(""))
//							// {
//							// String errrorMessage = "NOT EXIST PART FAMILY AND
//							// PART.";
//							// throw new Exception(errrorMessage);
//							//
//							// }
//							// DomainObject doFromObject = new
//							// DomainObject(ObjectId);
//							// DomainObject doToObject = new
//							// DomainObject(sFromObjectId);
//							//
//							// String sFromObjectType =
//							// doFromObject.getInfo(context,
//							// DomainConstants.SELECT_TYPE);
//							// // Get Created Part ObjectId from Environment
//							// // Variables
//							// String partFamilyReference =
//							// PropertyUtil.getSchemaProperty(context,
//							// "interface_PartFamilyReference");
//							// boolean isMEP = false;
//							//
//							// boolean booleanValue = false;
//							//
//							// String PartSeriesEnabled =
//							// EnoviaResourceBundle.getProperty(context,
//							// "emxEngineeringCentral.PartSeries.PartSeriesActive");
//							// // if returns true Part Series Functionality
//							// Feature
//							// // is enabled else not enabled.
//							// if ("true".equalsIgnoreCase(PartSeriesEnabled)) {
//							// booleanValue = true;
//							// }
//							// boolean PartseriesActive = booleanValue;
//							//
//							// if (PartseriesActive) {
//							// isMEP = true;
//							// }
//							// if (isMEP) {
//							//
//							// // 372257 : Modified the check for all the
//							// // subtype of Part instead of checking only type
//							// // Part
//							// if
//							// (sFromObjectType.equals(DomainConstants.TYPE_PART_FAMILY)
//							// && doToObject.isKindOf(context,
//							// DomainConstants.TYPE_PART)) {
//							// if (!(MqlUtil.mqlCommand(context, "print bus $1
//							// select $2 dump;", sFromObjectId, "interface[" +
//							// partFamilyReference + "]")).equals("TRUE")) {
//							// MqlUtil.mqlCommand(context, "modify bus $1 add
//							// interface $2;", true, sFromObjectId,
//							// partFamilyReference);
//							// }
//							// }
//							// }
//
//							// } catch (Exception e) {
//							// throw new FrameworkException(e);
//							// }
//
//							// 2 start
//							// 1: partfamily 2:part
//							String strResult = "";
//							DomainObject doObj = new DomainObject(sPartFamilyId);
//							String strInterface = doObj.getAttributeValue(context, LibraryCentralConstants.ATTRIBUTE_MXSYS_INTERFACE);
//
//							try {
//								String strMQL = "print bus $1 select interface dump";
//								strResult = MqlUtil.mqlCommand(context, strMQL, sPartId);
//
//								if (strResult != null && strResult.indexOf(strInterface) == -1) {
//									strMQL = "modify bus $1 add interface $2";
//									strResult = MqlUtil.mqlCommand(context, strMQL, sPartId, strInterface);
//
//									if (strResult.indexOf(LibraryCentralConstants.INTERFACE_CLASSIFICATION_SEARCH_FILTER) != -1) {
//										strMQL = "modify bus $1 remove interface $2";
//										strResult = MqlUtil.mqlCommand(context, strMQL, sPartId, LibraryCentralConstants.INTERFACE_CLASSIFICATION_SEARCH_FILTER);
//									}
//
//									// Changes Added for Designer Central -
//									// Integration
//									// DomainObject toObject = new
//									// DomainObject(sPartId);
//									// String implementIntOnMinorObjs =
//									// EnoviaResourceBundle.getProperty(context,
//									// "emxLibraryCentral.MinorObjects.Classify");
//
//									// if
//									// (CommonDocument.TYPE_DOCUMENTS.equals(CommonDocument.getParentType(context,
//									// toObject.getInfo(context,
//									// DomainObject.SELECT_TYPE))) &&
//									// (implementIntOnMinorObjs != null &&
//									// implementIntOnMinorObjs.equalsIgnoreCase("true")))
//									// {
//									// }
//
//									// End Changes
//								} else {
//									String errorMessage = "Attribute Group does not exist in Part Faimlly.";
//									throw new Exception(errorMessage);
//								}
//							} catch (Exception e) {
//								throw new FrameworkException(e);
//							}
//
//							// 2 end
//
//							// 3 start
//							// HashMap notificationParamHMap = new HashMap();
//							// notificationParamHMap.put("fromObjectId",
//							// sPartFamilyId);
//							// notificationParamHMap.put("event",
//							// "APPClassificationContentAddedEvent");
//							//
//							// String notificationParamArg[] =
//							// JPO.packArgs(notificationParamHMap);
//							// JPO.invoke(context, "emxNotificationUtil", null,
//							// "customGetObjectNotification",
//							// notificationParamArg);
//							// 3 end
//							// 4 start
//							String connectTclProg = "eServiceUpdateEndItemCountOnConnectDisconnect.tcl";
//							String updateCountConnection = "execute program \"" + connectTclProg + "\"  \"" + sPartFamilyId + "\" " + "\" create \"";
//							MQLCommand mqlcommand = new MQLCommand();
//							mqlcommand.open(context);
//							mqlcommand.executeCommand(context, updateCountConnection);
//							String sResult = mqlcommand.getResult();
//							String sError = mqlcommand.getError();
//							mqlcommand.close(context);
//							// 4 end
//							// trigger end
//
//						} catch (Exception e) {
//							mqlConnectPartAndPFCommand.executeCommand(context, "abort transaction $1", "PartFamily");
//							String sError = e.toString();
//							String errorMessage = "LINENUMBER:" + recordRowNum + "ERROR: NOT CONNECT PART OBJECT AND PART FAMILY OBJECT. | EXCEPTION: " + sError;
//
//							throw new Exception(errorMessage);
//						} finally {
//							mqlConnectPartAndPFCommand.close(context);
//						}
//					}
					/* 속성 입력 */
					DomainObject dObjPart = new DomainObject(sPartId);

					String sClassifiedRelationship = cdmConstantsUtil.RELATIONSHIP_CLASSIFIED_ITEM;
					String sFromTypeName = cdmConstantsUtil.TYPE_PART_FAMILY;
					boolean boolRelationshipDirectionTo = true;
					boolean boolRelationshipDirectionFrom = false;
					StringList stListClassifiedBusSelects = new StringList(1);
					StringList stListClassifiedRelSelects = new StringList(1);
					stListClassifiedBusSelects.add(cdmConstantsUtil.SELECT_ID);
					stListClassifiedRelSelects.add("id[connection]");
					String sBusWhere = "";
					String sRelWhere = "from.id==" + sPartFamilyId;
					MapList mapListClassified = (MapList) dObjPart.getRelatedObjects(context, sClassifiedRelationship, sFromTypeName, stListClassifiedBusSelects, stListClassifiedRelSelects, boolRelationshipDirectionTo, boolRelationshipDirectionFrom, (short) 0, sBusWhere, sRelWhere, 0);

					for (Iterator iterator = mapListClassified.iterator(); iterator.hasNext();) {
						Map mapClassified = (Map) iterator.next();
						String relId = (String) mapClassified.get("id[connection]");

						if (cdmStringUtil.isNotEmpty(relId)) {
							String relModifyMql = "mod connection " + relId + " \"cdmCheckMigration\"  " + "  \"Y\"  ";
							MqlUtil.mqlCommand(context, relModifyMql);
							break;
						}
					}

					DomainObject dPart = new DomainObject(sPartId);
					Part part = new Part(dPart);
					part.setAttributeValues(context, attributesMap);
					successcount++;
					ContextUtil.abortTransaction(context);
//					ContextUtil.commitTransaction(context);
					writeSuccessToFile(lineNumber+" \t SUB_LINENUBMER: \t "+ recordRowNum+"\t"+sBlockCode+"\t"+stPartName+"\t"+stPartRev);
					MqlUtil.mqlCommand(context, "Trigger On");
					checkTriggerOff = false;
//					stErrorRow = new String(stErrorRow.getBytes("euc-kr"), "utf-8");
//					stErrorRow = new String(stErrorRow.getBytes("utf-8"), "euc-kr");
//					stErrorRow = new String(stErrorRow.getBytes("euc-kr"),"ksc5601");
//					stErrorRow = new String(stErrorRow.getBytes("euc-kr"),"iso-8859-1");
//					stErrorRow = new String(stErrorRow.getBytes("iso-8859-1"),"ksc5601");
					
//					writeFailToFile(stErrorRow);
//					stErrorRow = new String(stErrorRow.getBytes("MS949-8"),"utf-8");
					
					
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					writeMessageToConsole("SUB_LINENUBMER \t"+ recordRowNum+" \t " + exception.getMessage());
					failCount++;
					writeFailToFile(stErrorRow);
					writeErrorToFile(lineNumber+"\t  SUB_LINENUBMER: \t"+ recordRowNum+" \t "+cdmCommonExcel.getTimeStamp2());
					exception.printStackTrace(errorStream);

				}finally{
					if(checkTriggerOff){
						MqlUtil.mqlCommand(context, "Trigger On");
						checkTriggerOff = false;
					}
				}
			}
				
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("        File ENG SPEC Migration COMPLETED                    ...\n");
			writeMessageToConsole("====================================================================================\n");
	
		
		}catch(Exception exception)
		{
			writeFailToFile("LINENUMBER: " +lineNumber+" | EXCEPTION: " + exception.getMessage());
			writeErrorToFile("LINENUMBER: " +lineNumber+" | EXCEPTION: "+exception.getMessage());
			exception.printStackTrace(errorStream);
		}
		finally {
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("END TIME: ("+ getTimeStamp() +")"+"LEAD TIME:"+ (System.currentTimeMillis() - startTime) + "second.             ");
			writeMessageToConsole("SUCCESS COUNT: ("+successcount+") FAILT COUNT: ("+failCount+") TOTAL COUNT: ("+(totalCount-1)+")");
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			System.out.println("[cdmENGSPECMigration : executeENGSPECMigration] end ."+cdmCommonExcel.getTimeStamp2());
		}
	
	}
	
	
	/**
	 * null 발생시 "" 로 체크  
	 * @param data
	 * @return
	 */
	public String isVaildNullData(String data){
		return ((data == null || "null".equals(data)) ? "" : data.trim());
	}
	
	
    private boolean isValidData(String data) {
		return ((data == null || "null".equals(data)) ? 0 : data.trim().length()) > 0;
	}
    
	private void closeLogStream() throws IOException
	{
		try 
		{
			if(null != logWriter)
				logWriter.close();

			if(null != errorStream)
				errorStream.close();

			if(null != successObjectidWriter)
				successObjectidWriter.close();

			if(null != failedObjectidWriter)
				failedObjectidWriter.close();
			
			if(null != noExistPartFamilyWriter)
				noExistPartFamilyWriter.close();
			
			if(null !=bufferReader)
				bufferReader.close();
		} 
		catch (IOException e) 
		{
			System.out.println("Exception while closing log stream "+e.getMessage());
		}
	}
	
	private void writeErrorToFile(String message)throws Exception{
		errorStream.write(message.getBytes("UTF-8"));
		errorStream.write("\n".getBytes("UTF-8"));
	}
	
	private void writeMessageToConsole(String message) throws Exception
	{
		writeMessageToLogFile(message);
	}

	private void writeMessageToLogFile(String message) throws Exception
	{
		logWriter.write( message + "\n");
	}
	
	private String getTimeStamp(){
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date)+"T"+ new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}
	
	public void writeFailToFile(String message) throws Exception{
		failedObjectidWriter.write( message + "\n");
	}
	public void writeSuccessToFile(String message)throws Exception{
		successObjectidWriter.write(message + "\n");
	}
	
	public void writeNoPFFile(String message) throws Exception{
		noExistPartFamilyWriter.write( message + "\n");
	}
	
	/**
	 * args{inputDirectory, 
	 * 
	 * @param context
	 * @param args
	 * @param requestAgsNum
	 * @param logFileName
	 */
	private void initializeM(Context context,String args[],int requestAgsNum , String logFileName)throws Exception{

		if (args.length != requestAgsNum )
		{
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}


		inputDirectory = args[0];

		// documentDirectory does not ends with "/" add it
		if(inputDirectory != null && !inputDirectory.endsWith(sfileSeparator))
		{
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile() + sfileSeparator + sOutPutDirectory + sfileSeparator + logFileName  +"_"+   sfileSeparator;
        File fileOutputDirectory = new File(outputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
        // input file name
     	fileName = args[1];
     	String formatTime = new SimpleDateFormat("MM-dd HH:mm:ss").format(new Date());
		formatTime = formatTime.replaceAll("-", "_");
		formatTime = formatTime.replaceAll(":", "_");
		
     	logFileName +="_"+fileName.substring(0,fileName.lastIndexOf("."))+"_"+formatTime;
     	
     		
		logWriter 			 	= new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(outputDirectory + logFileName + "_SuccessLog_Line.log");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		// Create directory to add failed object ids Row Number log .
		failedLogFile  			= new File(outputDirectory + logFileName + "_FailedLog_Line" + ".log");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		noExistPartFamilyFile   = new File(outputDirectory + logFileName + "_NoParFamilyLog_Line" + ".log");
		noExistPartFamilyWriter = new BufferedWriter(new FileWriter(noExistPartFamilyFile,true));
		
		
		// excel file path  
		String excelFileDirectory = args[2];
		String excelFileName = args[3];
		String excelSheetName = args[4];
		sheet = (XSSFSheet) cdmCommonExcel.getXssfSheet(context, excelFileDirectory+sfileSeparator+excelFileName, excelSheetName);
	
	}
	
	
	public void removeAttributeClassification(Context context, String args[])throws Exception{
		//
//		 final String MCM_STRING_RESOURCE = "emxLibraryCentralStringResource";
//
//
//		    boolean isSearchAllSublevels = "All Levels".equalsIgnoreCase( (String)session.getAttribute("LCSearchType") );
//		    
//		    String strarChildIds[]        = (String[]) emxGetParameterValues(request, "emxTableRowId");
//		    strarChildIds               = getTableRowIDsArray(strarChildIds); 
//		    String strParentObjectId    = emxGetParameter(request, "objectId");
//		    Vector vecCurrentAttributes = com.matrixone.apps.classification.Classification.findAttributes(context, strParentObjectId);
//
//		    int intCountOfPartsThatWillLoseAttributes = 0;
//		    if(strarChildIds != null && strarChildIds.length > 0) {
//		        for (int i=0; i<strarChildIds.length; i++)
//		        {
//		            boolean isGoingToLoseAttributes = com.matrixone.apps.classification.Classification.checkIfItLosesAttributeOnRemoval(context,
//		                                                                               strParentObjectId,
//		                                                                               vecCurrentAttributes,
//		                                                                               strarChildIds[i], isSearchAllSublevels);
//		            if (isGoingToLoseAttributes)
//		            {
//		                intCountOfPartsThatWillLoseAttributes++;
//		            }
//		        }
//		    }
		//
	}
}


