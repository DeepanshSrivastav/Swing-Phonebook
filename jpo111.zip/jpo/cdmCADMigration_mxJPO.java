import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.log4j.Logger;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.util.SystemOutLogger;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.SharedStringsTable;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.MCADIntegration.server.MCADServerResourceBundle;
import com.matrixone.MCADIntegration.server.MCADServerSettings;
import com.matrixone.MCADIntegration.server.beans.IEFIntegAccessUtil;
import com.matrixone.MCADIntegration.server.beans.MCADConfigObjectLoader;
import com.matrixone.MCADIntegration.server.beans.MCADIntegrationSessionData;
import com.matrixone.MCADIntegration.server.beans.MCADMxUtil;
import com.matrixone.MCADIntegration.server.beans.MCADServerGeneralUtil;
import com.matrixone.MCADIntegration.server.cache.IEFGlobalCache;
import com.matrixone.MCADIntegration.utils.MCADGlobalConfigObject;
import com.matrixone.MCADIntegration.utils.MCADUrlUtil;
import com.matrixone.MCADIntegration.utils.MCADUtil;
import com.matrixone.apps.classification.AttributeGroup;
import com.matrixone.apps.classification.Classification;
import com.matrixone.apps.common.CommonDocument;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.DomainSymbolicConstants;
import com.matrixone.apps.domain.util.CacheUtil;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkException;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MessageUtil;
import com.matrixone.apps.domain.util.MqlUtil;
import com.matrixone.apps.domain.util.PersonUtil;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.domain.util.i18nNow;
import com.matrixone.apps.domain.util.mxBus;
import com.matrixone.apps.engineering.EBOMAutoSync;
import com.matrixone.apps.engineering.EBOMMarkup;
import com.matrixone.apps.engineering.EngineeringConstants;
import com.matrixone.apps.engineering.EngineeringUtil;
import com.matrixone.apps.engineering.PartFamily;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.apps.library.Libraries;
import com.matrixone.apps.library.LibraryCentralConstants;
import com.matrixone.apps.library.PartLibrary;
import com.matrixone.apps.manufacturerequivalentpart.Part;
import com.matrixone.jdom.Element;
import com.matrixone.search.index.Config.formatIndexedType;

import matrix.db.Attribute;
import matrix.db.AttributeList;
import matrix.db.AttributeType;
import matrix.db.BusinessObject;
import matrix.db.BusinessType;
import matrix.db.Context;
import matrix.db.JPO;
import matrix.db.MQLCommand;
import matrix.db.MatrixWriter;
import matrix.db.Policy;
import matrix.db.RelationshipType;
import matrix.db.StateRequirement;
import matrix.db.StateRequirementList;
import matrix.util.DateFormatUtil;
import matrix.util.List;
import matrix.util.MatrixException;
import matrix.util.SelectList;
import matrix.util.StringList;
import com.mando.util.cdmCommonExcel;
import org.xml.sax.ContentHandler;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLReaderFactory;
import org.xml.sax.helpers.DefaultHandler;
import org.xml.sax.Attributes;

/**
 * part 이 존재하는 경우에 eng spec 이 붙여지는 경우로 생성된 migration
 *  
 *  
 * @author mj
 *
 */
public class cdmCADMigration_mxJPO {
	public BufferedWriter consoleWriter			 = null;
	public BufferedWriter logWriter 			 = null;
	
	public BufferedWriter successObjectidWriter  = null;
	public BufferedWriter failedObjectidWriter   = null;
	public BufferedWriter errorLogFile        	 = null;
	public BufferedWriter debugLogFile           = null;
	public BufferedReader bufferReader           = null;
	       
	public String inputDirectory 			= "";
	public String outputDirectory 			= "";
	public String fileName 		        	= "";
	        
	public String failedIdsLogsDirectory 	= "";
	public PrintStream errorStream		    = null;
	public File successLogFile 				= null;
	public File failedLogFile 				= null;
	public Integer sequenceInt ;
	
	public static final String sourceInfo                    			= "MxCATIAV5|CATIAV5R24SP7HF0";
	public static final String sfileSeparator 							= "\\";
	
	public int  mxMain(Context context,String args[])throws Exception{
		return 0;
	}
	
	/**
	 * 파일 업로드는 이루어지지않음 
	 * 파일의 저장위치는 CATPart , CATProduct, CATDrawing 의 major object 는 minor object의 데이타 중 latest revision의 파일 정보를 가진다.
	 * latest revision object 의 파일정보는 major object에만 존재하며 
	 * revise 될때 파일정보는 이동하여 minor object 의 파일 관리 object 에 저장된다.    
	 * 파라미터 데이타를 사용하지않고 
	 * argTest 이라는 string[] 에 직접 입력하여  initializeM 호출
	 * 
	 * args[0] :inputDirectory 파일 경로 정보 (파일명 포함되지않음) 
	 * args[1] : file name
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	
	public void executeCadcMigration(Context context, String args[])throws Exception{
		long startTime = System.currentTimeMillis();
		System.out.println("[cdmCADMigration_mxJPO : executeCadcMigration] start ."+startTime +"ms");
		
		
		String logFileName = "CadMigration";
		
		String[] argTest = {"C:\\temp\\Import_File\\CAD","CAD_Items_FULL_02.txt"}; //읽을 파일경로 ,읽을 파일명  
		initializeM(context,argTest,2,logFileName);      //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
		
		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("     CAD DATA MIGRATION "+ getTimeStamp()+" \n");
		writeMessageToConsole("		Reading input log file from : "+inputDirectory);
		writeMessageToConsole("		Writing Log files to: " + outputDirectory );
		writeMessageToConsole("====================================================================================\n");
		int lineNumber = 0;
		StringList stListHeader = new StringList();
		String recordRowNum     = "";
		
		try{
			
			String stReadData = "";
			bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory+fileName),"euc-kr"));
			while ((stReadData = bufferReader.readLine()) != null){
				StringList stListReadData = FrameworkUtil.split(stReadData, "\t");
				
				if(lineNumber == 0){
					stListHeader = stListReadData ;
					
					lineNumber++;
					continue;
				}
				//test start 
				//test end 
				LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String,Object>();
				
				for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {
					
					String stTempCadInfos = ((String) stListReadData.get(stListNum)).trim();
					String stTempCadInfosHeader = ((String) stListHeader.get(stListNum)).trim();
					stTempCadInfos = isVaildNullData(stTempCadInfos);
					linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);

				}
				lineNumber++;
				//TEST start 
//				if(lineNumber <4468){
//					continue;
//				}
				//TEST end 
				if(lineNumber == 1){
					continue;
				}
				try {
					recordRowNum                         =   (String)linkedCadHM.get("#");
					String sTempType                     =	 (String)linkedCadHM.get("CLS_NAME"); 					 		//  1 , Type 
					String sTDMXID 	                     =	 (String)linkedCadHM.get("TDMX_ID");  					 		//  2 , attribute[cdmTDMXID]  
					String sRevision				 	 =	 (String)linkedCadHM.get("REVISION");  	 	                    //  3 , Revision   
					String sCRT_USERS				 	 =	 (String)linkedCadHM.get("CRT_USERS");  	 	                //  4 , originator, owner  
					String sTDM_DESCRIPTION 	 		 =	 (String)linkedCadHM.get("TDM_DESCRIPTION"); 	                //  5 ,  
					String sTDMX_RELATED_ITEM_ID 	 	 =	 (String)linkedCadHM.get("TDMX_RELATED_ITEM_ID");               //  6 ,
//					String sTDMX_CAD_IDENTIFIER 	 	 =	 (String)linkedCadHM.get("TDMX_CAD_IDENTIFIER");                //  7 ,
					String sTDMX_DETAILED_DESCRIPTION 	 =	 (String)linkedCadHM.get("TDMX_DETAILED_DESCRIPTION");          //  8 ,
					String sTDMX_COMMENTS 	  			 =	 (String)linkedCadHM.get("TDMX_COMMENTS");                      //  9 ,
					String sTDMX_3D_CAD_IDENTIFIER 	  	 =	 (String)linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER");             //  10,
					String sTDMX_TITLE_TYPE 	  		 =	 (String)linkedCadHM.get("TDMX_TITLE_TYPE");                    //  11,
					String sTDMX_SCALE 					 =	 (String)linkedCadHM.get("TDMX_SCALE");                         //  12,
					String sTDMX_PAGE_SIZE 				 =	 (String)linkedCadHM.get("TDMX_PAGE_SIZE");                     //  13,
					String sFILE_TYPE 	 				 =	 (String)linkedCadHM.get("FILE_TYPE");                          //  14,
//					String sFILE_NAME 	 				 =	 (String)linkedCadHM.get("FILE_NAME");                          //  15,
					String sCAD_REF_FILE_NAME 	 		 =	 (String)linkedCadHM.get("CAD_REF_FILE_NAME");          		//  16, ORIGINAL FILE
					String sVAULT_OBJECT_ID 	  		 =	 (String)linkedCadHM.get("VAULT_OBJECT_ID");                    //  17,
					String sPHASE 	 					 =	 (String)linkedCadHM.get("PHASE");                              //  18,
					String sTDM_ORG_USER_ID 	         =	 (String)linkedCadHM.get("TDM_ORG_USER_ID");                    //  19,
					String sTDM_DOCUMENT_TYPE 	         =	 (String)linkedCadHM.get("TDM_DOCUMENT_TYPE");                  //  20,
					String sTDM_ARCHIVE_TYPE 	         =	 (String)linkedCadHM.get("TDM_ARCHIVE_TYPE");                   //  21,
					String sTDM_ARCHIVE_NAME 	         =	 (String)linkedCadHM.get("TDM_ARCHIVE_NAME");                   //  22,
					String sPROD_DIV 	                 =	 (String)linkedCadHM.get("PROD_DIV");                           //  23,
					String sCN_PROJECT 	                 =	 (String)linkedCadHM.get("CN_PROJECT");                         //  24,
//					String sCN_PROJECT 	                 =	 (String)linkedCadHM.get("CN_PROJECT");                         //  25, 중복 데이타 이므로 무시함 
					String sCN_PROJECT_CUST 	         =	 (String)linkedCadHM.get("CN_PROJECT_CUST");                    //  26,
					String sCN_MASS 	                 =	 (String)linkedCadHM.get("CN_MASS");                            //  27,
					String sCN_SURFACE_AREA 	         =	 (String)linkedCadHM.get("CN_SURFACE_AREA");                    //  28,
					String sCN_OEM_PART_NUMBER 	         =	 (String)linkedCadHM.get("CN_OEM_PART_NUMBER");                 //  29,
					String sCN_ECO_NUMBER 	             =	 (String)linkedCadHM.get("CN_ECO_NUMBER");                      //  30,
					String sCN_MASS_ESTIMATED 	         =	 (String)linkedCadHM.get("CN_MASS_ESTIMATED");                  //  31,
					String sCN_PRODUCT_GROUP 	         =	 (String)linkedCadHM.get("CN_PRODUCT_GROUP");                   //  32,
					String sCN_CUSTOMER 	             =	 (String)linkedCadHM.get("CN_CUSTOMER");                        //  33,
//					String sCN_VEHICLE 	                 =	 (String)linkedCadHM.get("CN_VEHICLE");                         //  34,  이 데이타는 migration 대상자 아님 
					String sCN_RELATED_ITEM_NAME 	     =	 (String)linkedCadHM.get("CN_RELATED_ITEM_NAME");               //  35,
					String sCN_RELATED_ITEM_REV 	     =	 (String)linkedCadHM.get("CN_RELATED_ITEM_REV");                //  36, 
					
					String parentRelName                 = cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
					String sType = "";
					boolean isExistCAD  = false;
					if("Assembly".equals(sTempType)){
						sType = cdmConstantsUtil.TYPE_CATPRODUCT;
						isExistCAD = true;
					}else if("AutoCAD".equals(sTempType)){
						sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
					}else if("Image Drawing".equals(sTempType)){
						sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
					}else if("Drawing".equals(sTempType)){
						sType = cdmConstantsUtil.TYPE_CATDrawing;
						isExistCAD = true;						
					}else if("Part".equals(sTempType)){
						sType = cdmConstantsUtil.TYPE_CATPART;
						isExistCAD = true;
					}else if("sV4Model".equals(sTempType)){
						sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
					}else if("UG NX Drawing".equals(sTempType)){
						sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
					}else{
						
						/* ***********************************************************************
						 * 	Type 정보가 없다면 에러 처리. 
						 * *********************************************************************** */
						StringBuffer errorSBuf = new StringBuffer();
						errorSBuf.append("NOT MATCH TYPE INFOAMTION. ");
						throw new Exception(errorSBuf.toString());
						
					}
					
					/* ***********************************************************************
					 * 	PART 데이타 있는데 OBJECT 정보가 존재하지 않는다면 에러 발생 
					 *  존재한다면 연결 연결 정보는 ??
					 * *********************************************************************** */
					String sPartFindObjId = "";
					if(cdmStringUtil.isNotEmpty(sTDMX_RELATED_ITEM_ID) && cdmStringUtil.isNotEmpty(sCN_RELATED_ITEM_REV)){
						String sPartFindMql = MqlUtil.mqlCommand(context, "temp query bus 'cdmMechanicalPart,cdmPhantomPart' '"+sTDMX_RELATED_ITEM_ID +"'  '"+sCN_RELATED_ITEM_REV+"' select id dump |");
						StringList sListPartFindMqlResult = FrameworkUtil.split(sPartFindMql, "|");
						if(sListPartFindMqlResult.size()>2){
							sPartFindObjId = (String)sListPartFindMqlResult.get(3);
						}else{
							StringBuffer errorSBuff = new StringBuffer();
							errorSBuff.append("NOT FIND PART OBJECT IN ENOVIA. ");
							throw new Exception(errorSBuff.toString());
						}
					}
					
					/* Person 정보 확인 */
					boolean IsExistPerson = false;
					String sIsPersonMql = MqlUtil.mqlCommand(context, "temp query bus Person '"+sCRT_USERS+"'  * select name dump |");
					StringList sListIsPersonMqlResult = FrameworkUtil.split(sIsPersonMql, "|");
					if(sListIsPersonMqlResult.size()>2){
						IsExistPerson = true; 
					}
					
					/* ***********************************************************************
					 * 	 object name 설정
					 * 	 sCAD_REF_FILE_NAME 데이타가 존재하지않는다면 에러 처리  
					 * ***********************************************************************  */
					String sName = "";
					if(cdmStringUtil.isNotEmpty(sCAD_REF_FILE_NAME)) {
						int intLastExtension = sCAD_REF_FILE_NAME.lastIndexOf(".");
						sName = sCAD_REF_FILE_NAME.substring(0, intLastExtension);
						sName = sName.trim();
					}else{
						String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . ";
						throw new Exception(sErrorMessage);
					}
					
					
					ContextUtil.startTransaction(context, true);
					if (isExistCAD) {
						
						MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
						IEFGlobalCache cache = new IEFGlobalCache();

						MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);

						
						/* ***********************************************************************
						 * 	REVISION 정보가 없다면 에러 처리. 
						 * 	REVISION 설정 .
						 * *********************************************************************** */
						if(cdmStringUtil.isEmpty(sRevision)){
							String errorMessage = "NOT EXIST REVISION DATA. ";
							throw  new Exception(errorMessage);
						}
						String sRevisionSeqence = "";
						if (!"---".equals(sRevision)) {

							Policy policyDesignTeamDefine = new Policy(cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION);
							policyDesignTeamDefine.open(context);

							String stPolicySequence = policyDesignTeamDefine.getSequence(context);
							policyDesignTeamDefine.close(context);

							int iSeqenceNumber = 0; // SEQUNCE 
							boolean checkSequence = false;
							StringList stListPolicy = FrameworkUtil.split(stPolicySequence, ",");
							for (int iPolicyCnt = 0; iPolicyCnt < stListPolicy.size(); iPolicyCnt++) {
								String sPolicySequence = (String) stListPolicy.get(iPolicyCnt);

								String tempSequence = sPolicySequence.replaceAll("-", "");
								if (cdmStringUtil.isNotEmpty(tempSequence) && sRevision.equals(tempSequence)) {
									iSeqenceNumber = iPolicyCnt;
									checkSequence = true;
								}
							}
							sRevisionSeqence = (String) stListPolicy.get(iSeqenceNumber);
							//System.out.println("sRevisionSeqence --->" + sRevisionSeqence);
							
							if(!checkSequence){
								String errorMessage = "NOT MATCH POLICY SEQUENCE AND REVISION DATA. ";
								throw  new Exception(errorMessage);
							}
						}else{
							sRevisionSeqence = sRevision;
						}

						BusinessObject existBusinessObj = new BusinessObject(sType, sName, sRevisionSeqence, "");
						String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
						BusinessObject existMinorBusinessObj = new BusinessObject(sType, sName, minorRevString, "");
						
						boolean isMajorExist = existBusinessObj.exists(context);
						boolean istMinorExist = existMinorBusinessObj.exists(context);
						
						if (!isMajorExist) {
							//
							DomainObject busObject = new DomainObject();
							DomainObject minorBusObject = new DomainObject();

							String sAttribute_CADType = MCADMxUtil.getActualNameForAEFData(context, "attribute_CADType");
							String sAttribute_MoveFileVersion = MCADMxUtil.getActualNameForAEFData(context, "attribute_MoveFilesToVersion");
							// original file name 과 데이타가 같다.
							String sAttribute_Title = MCADMxUtil.getActualNameForAEFData(context, "attribute_Title");
							String sAttribute_IsVersionObj = MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
							String sAttribute_IEFFileMessage = MCADMxUtil.getActualNameForAEFData(context, "attribute_IEF-FileMessageDigest");
							String sAttribute_Source = MCADMxUtil.getActualNameForAEFData(context, "attribute_Source");

							
							MqlUtil.mqlCommand(context, "Trigger Off");
							
							//test start 10.27
//							sName = "TESTFILENAME_20161027_001-CATPART";
							
							//test start end 10.27
							
							busObject.createObject(context, sType, sName, sRevisionSeqence, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);

							String stObjectId = busObject.getObjectId();
							
							/*
							 * *****************************************************************
							 * ************************************************ 파일 체크인 파일명은
							 * sCAD_REF_FILE_NAME 으로 하며 최신 revision 에 연결된 file 을 Design Team
							 * Resource 아직은 주석처리 10.17.2016 확인하고 추후 진행할것
							 * !!!!!!!!!!!!!!!!!!!!!!!!!!!! 파일 체크인 하는 부분은 따로 처리할 예정 10.19.16
							 */
							/* 속성 입력 start */
//							String sTDMXID                 		 =   (String)linkedCadHM.get("TDMX_ID");  					 		//  2  attribute[cdmTDMXID]
//							String sCRT_USERS				 	 =	 (String)linkedCadHM.get("CRT_USERS");  	 	                //  4 ,originator, owner
//							String sTDM_DESCRIPTION 	 		 =	 (String)linkedCadHM.get("TDM_DESCRIPTION"); 	                //  5 ,
//							String sTDMX_DETAILED_DESCRIPTION 	 =	 (String)linkedCadHM.get("TDMX_DETAILED_DESCRIPTION");          //  8 ,
//							String sTDMX_COMMENTS 	  			 =	 (String)linkedCadHM.get("TDMX_COMMENTS");                      //  9 ,
//							String sTDMX_3D_CAD_IDENTIFIER 	  	 =	 (String)linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER");             //  10,
//							String sTDMX_SCALE 					 =	 (String)linkedCadHM.get("TDMX_SCALE");                         //  12,
//							String sTDMX_PAGE_SIZE 				 =	 (String)linkedCadHM.get("TDMX_PAGE_SIZE");                     //  13,
//							String sFILE_TYPE 	 				 =	 (String)linkedCadHM.get("FILE_TYPE");                          //  14,
//							String sCAD_REF_FILE_NAME 	 		 =	 (String)linkedCadHM.get("CAD_REF_FILE_NAME");          		//  16, ORIGINAL FILE
//							String sTDM_DOCUMENT_TYPE 	         =	 (String)linkedCadHM.get("TDM_DOCUMENT_TYPE");                  //  20,
//							String sCN_MASS 	                 =	 (String)linkedCadHM.get("CN_MASS");                            //  27,
//							String sCN_SURFACE_AREA 	         =	 (String)linkedCadHM.get("CN_SURFACE_AREA");                    //  28,
							
							AttributeList localAttributeList = new AttributeList();
							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_Title), sCAD_REF_FILE_NAME));
							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IEFFileMessage), ""));
							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_Source), sourceInfo));

							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID),                  sTDMXID));
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION),      sTDMX_DETAILED_DESCRIPTION));
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_COMMENT),                 sTDMX_COMMENTS));
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER),       sTDMX_3D_CAD_IDENTIFIER));
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE),               sFILE_TYPE));
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE), sTDM_DOCUMENT_TYPE));
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION),           "Y"));

							if ((cdmConstantsUtil.TYPE_CATDrawing).equals(sType)) {
								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE),     sTDMX_SCALE));
								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE), sTDMX_PAGE_SIZE));
							}

							if ((cdmConstantsUtil.TYPE_CATPART).equals(sType)) {
								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS),      sCN_MASS));
							}

							if ((cdmConstantsUtil.TYPE_CATPART).equals(sType) || (cdmConstantsUtil.TYPE_CATPRODUCT).equals(sType)) {
								localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE),   sCN_SURFACE_AREA));
							}

							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "True"));
							localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IsVersionObj),    "False"));

							/* 
							 *  MAJOR VERSION OBJECT
							 *  ATTRIBUTE[ORIGINATOR],OWNER 정보 추가
							 *  PERSON 정보가 존재하지않는다면 제외 
							 * 
							 */
							localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_ORIGINATOR),      sCRT_USERS));
							if(IsExistPerson){
								busObject.setOwner(context, sCRT_USERS);
							}
							
							/*   MAJOR VERSION OBJECT ATTRIBUTE, DESCRIPTION 설정  */
							busObject.setAttributes(context, localAttributeList);
							busObject.setDescription(context, sTDM_DESCRIPTION);
							
							/*RELATIONSHIP PART SPECIFICATION 연결*/
							String isFrom = "true";
							busObject.addRelatedObject(context, new RelationshipType(parentRelName), isFrom.equalsIgnoreCase("true"), sPartFindObjId);
							
							
							/* MINOR VERSION */
							localAttributeList.remove(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "True"));
							localAttributeList.remove(new Attribute(new AttributeType(sAttribute_IsVersionObj),    "False"));
							
							String stVersionId = "";
							if (!istMinorExist) {
								
								minorBusObject.createObject(context, sType, sName, minorRevString, cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
								stVersionId = minorBusObject.getObjectId();

								localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "False"));
								localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IsVersionObj), "True"));

								minorBusObject.setAttributes(context, localAttributeList);

								if (cdmStringUtil.isNotEmpty(sTDM_DESCRIPTION)) {
									minorBusObject.setDescription(context, sTDM_DESCRIPTION);
								}

							}else{
								String errorMessage = "ALREADY EXIST MINOR OBJECT.";
								throw new Exception(errorMessage);
							}
							
							/* 
							 *  MINOR VERSION OBJECT
							 *  OWNER 정보 추가
							 *  PERSON 정보가 존재하지않는다면 제외 
							 */
							if (IsExistPerson) {
								minorBusObject.setOwner(context, sCRT_USERS);
							}
							StringBuffer localStringBufferVersion = new StringBuffer();
							localStringBufferVersion.append("connect bus \"");
							localStringBufferVersion.append(stVersionId);
							localStringBufferVersion.append("\" relationship \"");
							localStringBufferVersion.append(cdmConstantsUtil.RELATIONSHIP_VERSION_OF);
							localStringBufferVersion.append("\" preserve to \"");
							localStringBufferVersion.append(stObjectId);
							localStringBufferVersion.append("\" ");
							
							MQLCommand localMQLCommand = new MQLCommand();
							localMQLCommand.open(context);
							boolean boolBufferVersion = localMQLCommand.executeCommand(context, localStringBufferVersion.toString());
							if(!boolBufferVersion){
								String errorMessage = " NOT RELATIONSHIP[VersionOf] CONNECT MAJOR OBJECT, MINOR OBJECT ";
								throw new Exception(errorMessage);
							}
							localMQLCommand.close(context);
							
							
							StringBuffer localStringBufferActive = new StringBuffer();
							localStringBufferActive.append("connect bus \"");
							localStringBufferActive.append(stObjectId);
							localStringBufferActive.append("\" relationship \"");
							localStringBufferActive.append(cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION);
							localStringBufferActive.append("\" preserve to \"");
							localStringBufferActive.append(stVersionId);
							localStringBufferActive.append("\" ");

							MQLCommand activeMQLCommand = new MQLCommand();
							activeMQLCommand.open(context);
							boolean boolBufferActive = activeMQLCommand.executeCommand(context, localStringBufferActive.toString());
							if(!boolBufferActive){
								String errorMessage = " NOT RELATIONSHIP[Active Version] CONNECT MAJOR OBJECT, MINOR OBJECT ";
								throw new Exception(errorMessage);
							}
							activeMQLCommand.close(context);
							
							
							StringBuffer localStringBufferLatest = new StringBuffer();
							localStringBufferLatest.append("connect bus \"");
							localStringBufferLatest.append(stObjectId);
							localStringBufferLatest.append("\" relationship \"");
							localStringBufferLatest.append(cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION);
							localStringBufferLatest.append("\" preserve to \"");
							localStringBufferLatest.append(stVersionId);
							localStringBufferLatest.append("\" ");
							
							MQLCommand latestMQLCommand = new MQLCommand();
							latestMQLCommand.open(context);
							boolean boolBufferLatest = latestMQLCommand.executeCommand(context, localStringBufferLatest.toString());
							if(!boolBufferLatest){
								String errorMessage = " NOT RELATIONSHIP[Latest Version] CONNECT MAJOR OBJECT, MINOR OBJECT ";
								throw new Exception(errorMessage);
							}
							latestMQLCommand.close(context);
							/* 속성 입력 end */
							

						}else{
							String errorMessage = "ALREADY EXIST MAJOR OBJECT. NOT MAKE CAD OBJECT .";
							 throw new Exception(errorMessage);
						}
						
					
					}else {
						/*  Document 타입일 경우
						 *  Document 의 경우 'Document Release' policy 인 object 에 모든 파일이 저장되며
						 *  revision의 object의 경우에도 파일이 이동하지않고 변경한 데이타들이 저장
						 *  파일 이 추가 될  
						 *  cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성 추가
						 *  Originator은 user 정보로 변경 Person 정보가 enovia에 Person 정보에 있을시 Owner 추가.
						 *  최신 release 정보 을 가지고 생성
						*/
						
						DomainObject documentBusObj 	 = new DomainObject();
						DomainObject documentMinorBusObj = new DomainObject();
						BusinessObject existdocumentBusObj = new BusinessObject(sType, sName, sRevision, "");
						boolean isMajorDocumentObjExist = existdocumentBusObj.exists(context);
						
						if(!isMajorDocumentObjExist){
							//
							String policy 	                   = "Document Release";
							String title                       = sName;
							String language                    = null;
							String isFrom                      = "true";
							String objectGeneratorRevision     =  "";
							String vault                       = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
							
							if (sTDM_DESCRIPTION == null || "".equals(sTDM_DESCRIPTION) || "null".equals(sTDM_DESCRIPTION)) {
								sTDM_DESCRIPTION = (String) linkedCadHM.get("sTDM_DESCRIPTION");
							}
							
							if (sCAD_REF_FILE_NAME == null || "".equals(sCAD_REF_FILE_NAME) || "null".equals(sCAD_REF_FILE_NAME)) {
								sCAD_REF_FILE_NAME = null;
							}

							CommonDocument object = (CommonDocument) DomainObject.newInstance(context, CommonDocument.TYPE_DOCUMENTS);
							DomainObject parentObject = null;
							if (sPartFindObjId != null && !"".equals(sPartFindObjId) && !"null".equals(sPartFindObjId)) {
								parentObject = DomainObject.newInstance(context, sPartFindObjId);
							}

							HashMap<String,Object> mAttrMap = new HashMap<String,Object>(); //데이타 입력해야함 10.18.16 속성정보 지정할것 
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE,        sTDMX_PAGE_SIZE             );
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE, 	        sTDMX_SCALE                 );
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_TITLE_TYPE,       sTDMX_TITLE_TYPE            );
							
							//MIGRATION DATA을 위해 속성 추가 AUTOCAD,  ..
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID,  					sTDMXID						);
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION,   		sTDMX_DETAILED_DESCRIPTION	);
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_COMMENT,  					sTDMX_COMMENTS          	);
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER,  		sTDMX_3D_CAD_IDENTIFIER		);
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE, 					sFILE_TYPE					);
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE,  	sTDM_DOCUMENT_TYPE			);
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, 				"Y" 						);
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS,  			sCN_MASS					);
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE,  		sCN_SURFACE_AREA			);
							mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_ORIGINATOR,  					sCRT_USERS					);
							MqlUtil.mqlCommand(context, "Trigger Off");
							object = object.createAndConnect(context, sType, sName, sRevision, policy, sTDM_DESCRIPTION, vault, title, language, parentObject, parentRelName, isFrom, mAttrMap, objectGeneratorRevision);
							MqlUtil.mqlCommand(context, "Trigger On");
							StringList selects = new StringList(2);
							selects.add(DomainConstants.SELECT_ID);
							selects.add(CommonDocument.SELECT_MOVE_FILES_TO_VERSION);

							Map objectSelectMap = object.getInfo(context, selects);
							String objectId = "";
							objectId = (String) objectSelectMap.get(DomainConstants.SELECT_ID);
						
							boolean isFilePresent			= true;
							String  sVersionDescription 	= null;
							Map     attrMapOfVersion	 	= new HashMap();
							
							boolean createVersion = true;
							
							String checkinId = "";
							if (createVersion) {
								MqlUtil.mqlCommand(context, "Trigger Off");
								checkinId = object.createVersion(context, sVersionDescription, sCAD_REF_FILE_NAME, attrMapOfVersion);
								MqlUtil.mqlCommand(context, "Trigger On");
							}
							
							/*person 정보가 있다면 document와 version owner 속성 정보에 입력 */
							if (sListIsPersonMqlResult.size()>2) {
								object.setOwner(context, (String)sListIsPersonMqlResult.get(3));
								
								if(cdmStringUtil.isNotEmpty(checkinId)){
									DomainObject dObjVersion = DomainObject.newInstance(context,checkinId);
									dObjVersion.setOwner(context, (String)sListIsPersonMqlResult.get(3));
								}
							}
							
						}else{
							String errorMessage = "ALREADY EXIST MAJOR OBJECT. NOT MAKE DOCUMENT OBJECT .";
							 throw new Exception(errorMessage);
						}
						
						
					}
					ContextUtil.commitTransaction(context);
					writeSuccessToFile("SUCESS!! LINE NUMBER: " + recordRowNum);
					writeMessageToConsole("SUCESS!!  LINE NUMBER: " + recordRowNum);
				} catch (Exception exception) {
					ContextUtil.abortTransaction(context);
					
					writeMessageToConsole(" Exception occured : " + exception.getMessage()+" LINE NUMBER: " + recordRowNum);
					writeErrorToFile("[cdmCADMigration_mxJPO : executeCadcMigration] Exception occured : " + exception.getMessage()+ " LINE NUMBER: " + recordRowNum);
					exception.printStackTrace(errorStream);

					writeFailToFile("[cdmCADMigration_mxJPO : executeCadcMigration] fail occured. LINE NUMBER: " + recordRowNum);
				}	
			}
			

		writeMessageToConsole("====================================================================================");
		writeMessageToConsole("        File CAD Migration COMPLETED.                    ");
		writeMessageToConsole("====================================================================================\n");
	
		
		}catch(Exception exception)
		{
			writeFailToFile("[cdmCADMigration_mxJPO : executeCadcMigration] fail occured.  LINE NUMBER: " + recordRowNum);
			writeMessageToConsole(" Exception occured : "+exception.getMessage() +"  LINE NUMBER: "+recordRowNum);
			writeErrorToFile("[cdmCADMigration_mxJPO : executeCadcMigration] Exception occured.  LINE NUMBER: "+recordRowNum + "  "+exception.getMessage());
			exception.printStackTrace(errorStream);
		}
		finally {
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("		LEAD TIME:"+ (System.currentTimeMillis() - startTime) + "ms        \n"  );
			writeMessageToConsole("==================================================================================== \n");
			closeLogStream();
			System.out.println("[cdmCADMigration_mxJPO : executeCadcMigration] end .");
		}
	}
	
	/**
	 * 파일 업로드
	 * Document 일때 파일의 위치 
	 * CAD 파일일때 파일의 위치  
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	public void excuteCadCheckin(Context context ,String args[])throws Exception{
		try{
			long startTime = System.currentTimeMillis();
			System.out.println("[cdmCADMigration_mxJPO : executeCadcMigration] start ."+startTime +"ms");
			
			
			String logFileName = "CadCheckinFileMigration";
			
			String[] argTest = {"C:\\temp\\Import_File\\CAD","CAD_Items_FULL_02.txt"}; //읽을 파일경로 ,읽을 파일명  
			initializeM(context,argTest,2,logFileName);      //context , artTest, argTest 갯수 체크을위한 수, 로그 파일명의 default 파일명.
			
			writeMessageToConsole("====================================================================================");
			writeMessageToConsole("     CAD DATA MIGRATION "+ getTimeStamp()+" \n");
			writeMessageToConsole("		Reading input log file from : "+inputDirectory);
			writeMessageToConsole("		Writing Log files to: " + outputDirectory );
			writeMessageToConsole("====================================================================================\n");
			int lineNumber = 0;
			StringList stListHeader = new StringList();
			String recordRowNum     = "";
			
			try {

				String stReadData = "";
				bufferReader = new BufferedReader(new InputStreamReader(new FileInputStream(inputDirectory + fileName), "euc-kr"));
				while ((stReadData = bufferReader.readLine()) != null) {
					StringList stListReadData = FrameworkUtil.split(stReadData, "\t");

					if (lineNumber == 0) {
						stListHeader = stListReadData;

						lineNumber++;
						continue;
					}
					// test start
					// test end
					LinkedHashMap<String, Object> linkedCadHM = new LinkedHashMap<String, Object>();

					for (int stListNum = 0; stListNum < stListReadData.size(); stListNum++) {

						String stTempCadInfos = ((String) stListReadData.get(stListNum)).trim();
						String stTempCadInfosHeader = ((String) stListHeader.get(stListNum)).trim();
						stTempCadInfos = isVaildNullData(stTempCadInfos);
						linkedCadHM.put(stTempCadInfosHeader, stTempCadInfos);

					}
					lineNumber++;
					// //TEST start
					// if(lineNumber <4468){
					// continue;
					// }
					// //TEST end
					if (lineNumber == 1) {
						continue;
					}

					recordRowNum = (String) linkedCadHM.get("#");
					String sTempType = (String) linkedCadHM.get("CLS_NAME"); 	           // 1 ,Type
					String sTDMXID = (String) linkedCadHM.get("TDMX_ID"); 		           // 2 ,attribute[cdmTDMXID]
					String sRevision = (String) linkedCadHM.get("REVISION"); 	           // 3 ,Revision
					String sCRT_USERS = (String) linkedCadHM.get("CRT_USERS"); 	           // 4 ,originator,owner
					String sTDM_DESCRIPTION = (String) linkedCadHM.get("TDM_DESCRIPTION"); // 5
					String sTDMX_RELATED_ITEM_ID = (String) linkedCadHM.get("TDMX_RELATED_ITEM_ID"); // 6
					// String sTDMX_CAD_IDENTIFIER = (String)linkedCadHM.get("TDMX_CAD_IDENTIFIER"); // 7 ,
					String sTDMX_DETAILED_DESCRIPTION = (String) linkedCadHM.get("TDMX_DETAILED_DESCRIPTION"); // 8
					String sTDMX_COMMENTS = (String) linkedCadHM.get("TDMX_COMMENTS"); // 9
					String sTDMX_3D_CAD_IDENTIFIER = (String) linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER"); // 10,
					String sTDMX_TITLE_TYPE = (String) linkedCadHM.get("TDMX_TITLE_TYPE"); // 11,
					String sTDMX_SCALE = (String) linkedCadHM.get("TDMX_SCALE"); // 12,
					String sTDMX_PAGE_SIZE = (String) linkedCadHM.get("TDMX_PAGE_SIZE"); // 13,
					String sFILE_TYPE = (String) linkedCadHM.get("FILE_TYPE"); // 14,
					// String sFILE_NAME = (String)linkedCadHM.get("FILE_NAME"); //15,
					String sCAD_REF_FILE_NAME = (String) linkedCadHM.get("CAD_REF_FILE_NAME"); // 16,// ORIGINAL FILE
																								
					String sVAULT_OBJECT_ID = (String) linkedCadHM.get("VAULT_OBJECT_ID"); // 17,
					String sPHASE = (String) linkedCadHM.get("PHASE"); // 18,
					String sTDM_ORG_USER_ID = (String) linkedCadHM.get("TDM_ORG_USER_ID"); // 19,
					String sTDM_DOCUMENT_TYPE = (String) linkedCadHM.get("TDM_DOCUMENT_TYPE"); // 20,
					String sTDM_ARCHIVE_TYPE = (String) linkedCadHM.get("TDM_ARCHIVE_TYPE"); // 21,
					String sTDM_ARCHIVE_NAME = (String) linkedCadHM.get("TDM_ARCHIVE_NAME"); // 22,
					String sPROD_DIV = (String) linkedCadHM.get("PROD_DIV"); // 23,
					String sCN_PROJECT = (String) linkedCadHM.get("CN_PROJECT"); // 24,
				 // String sCN_PROJECT = (String)linkedCadHM.get("CN_PROJECT"); // 25, 중복 데이타 이므로 무시함
					String sCN_PROJECT_CUST = (String) linkedCadHM.get("CN_PROJECT_CUST"); // 26,
					String sCN_MASS = (String) linkedCadHM.get("CN_MASS"); // 27,
					String sCN_SURFACE_AREA = (String) linkedCadHM.get("CN_SURFACE_AREA"); // 28,
					String sCN_OEM_PART_NUMBER = (String) linkedCadHM.get("CN_OEM_PART_NUMBER"); // 29,
					String sCN_ECO_NUMBER = (String) linkedCadHM.get("CN_ECO_NUMBER"); // 30,
					String sCN_MASS_ESTIMATED = (String) linkedCadHM.get("CN_MASS_ESTIMATED"); // 31,
					String sCN_PRODUCT_GROUP = (String) linkedCadHM.get("CN_PRODUCT_GROUP"); // 32,
					String sCN_CUSTOMER = (String) linkedCadHM.get("CN_CUSTOMER"); // 33,
					// String sCN_VEHICLE = (String)linkedCadHM.get("CN_VEHICLE"); // 34, 이 데이타는 migration 대상자 아님
					String sCN_RELATED_ITEM_NAME = (String) linkedCadHM.get("CN_RELATED_ITEM_NAME"); // 35,
					String sCN_RELATED_ITEM_REV = (String) linkedCadHM.get("CN_RELATED_ITEM_REV"); // 36,

					String parentRelName = cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
					String sType = "";
					boolean isExistCAD = false;
					if ("Assembly".equals(sTempType)) {
						sType = cdmConstantsUtil.TYPE_CATPRODUCT;
						isExistCAD = true;
					} else if ("AutoCAD".equals(sTempType)) {
						sType = cdmConstantsUtil.TYPE_CDMAUTOCAD;
					} else if ("Image Drawing".equals(sTempType)) {
						sType = cdmConstantsUtil.TYPE_CDMIMAGEDRAWING;
					} else if ("Drawing".equals(sTempType)) {
						sType = cdmConstantsUtil.TYPE_CATDrawing;
						isExistCAD = true;
					} else if ("Part".equals(sTempType)) {
						sType = cdmConstantsUtil.TYPE_CATPART;
						isExistCAD = true;
					} else if ("sV4Model".equals(sTempType)) {
						sType = cdmConstantsUtil.TYPE_CDMV4MODEL;
					} else if ("UG NX Drawing".equals(sTempType)) {
						sType = cdmConstantsUtil.TYPE_CDMNXDRAWING;
					} else {

						/*
						 * *****************************************************
						 * Type 정보가 없다면 에러 처리.
						 * *****************************************************
						 */
						StringBuffer errorSBuf = new StringBuffer();
						errorSBuf.append("NOT MATCH TYPE INFOAMTION. ");
						throw new Exception(errorSBuf.toString());

					}

					/*
					 * *********************************************************
					 *  PART 데이타 있는데 OBJECT 정보가 존재하지 않는다면 에러 발생
					 * 존재한다면 연결 연결 정보는 ??
					 * *********************************************************
					 */
					String sPartFindObjId = "";
					if (cdmStringUtil.isNotEmpty(sTDMX_RELATED_ITEM_ID) && cdmStringUtil.isNotEmpty(sCN_RELATED_ITEM_REV)) {
						String sPartFindMql = MqlUtil.mqlCommand(context, "temp query bus 'cdmMechanicalPart,cdmPhantomPart' '" + sTDMX_RELATED_ITEM_ID + "'  '" + sCN_RELATED_ITEM_REV + "' select id dump |");
						StringList sListPartFindMqlResult = FrameworkUtil.split(sPartFindMql, "|");
						if (sListPartFindMqlResult.size() > 2) {
							sPartFindObjId = (String) sListPartFindMqlResult.get(3);
						} else {
							StringBuffer errorSBuff = new StringBuffer();
							errorSBuff.append("NOT FIND PART OBJECT IN ENOVIA. ");
							throw new Exception(errorSBuff.toString());
						}
					}

					/* Person 정보 확인 */
					boolean IsExistPerson = false;
					String sIsPersonMql = MqlUtil.mqlCommand(context, "temp query bus Person '" + sCRT_USERS + "'  * select name dump |");
					StringList sListIsPersonMqlResult = FrameworkUtil.split(sIsPersonMql, "|");
					if (sListIsPersonMqlResult.size() > 2) {
						IsExistPerson = true;
					}

					/*
					 * *********************************************************
					 *  object name 설정 sCAD_REF_FILE_NAME 데이타가
					 * 존재하지않는다면 에러 처리
					 * *********************************************************
					 */
					String sName = "";
					if (cdmStringUtil.isNotEmpty(sCAD_REF_FILE_NAME)) {
						int intLastExtension = sCAD_REF_FILE_NAME.lastIndexOf(".");
						sName = sCAD_REF_FILE_NAME.substring(0, intLastExtension);
						sName = sName.trim();
					} else {
						String sErrorMessage = "NOT EXIST CAD_REF_FILE_NAME FILE DATA . ";
						throw new Exception(sErrorMessage);
					}

					if (isExistCAD) {

						MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) context.getLocale().getLanguage());
						IEFGlobalCache cache = new IEFGlobalCache();

						MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);

						/*
						 * *****************************************************
						 *  REVISION 정보가 없다면 에러 처리. REVISION 설정 .
						 * *****************************************************
						 * 
						 */
						if (cdmStringUtil.isEmpty(sRevision)) {
							String errorMessage = "NOT EXIST REVISION DATA. ";
							throw new Exception(errorMessage);
						}
						String sRevisionSeqence = "";
						if (!"---".equals(sRevision)) {

							Policy policyDesignTeamDefine = new Policy(cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION);
							policyDesignTeamDefine.open(context);

							String stPolicySequence = policyDesignTeamDefine.getSequence(context);
							policyDesignTeamDefine.close(context);

							int iSeqenceNumber = 0; // SEQUNCE
							boolean checkSequence = false;
							StringList stListPolicy = FrameworkUtil.split(stPolicySequence, ",");
							for (int iPolicyCnt = 0; iPolicyCnt < stListPolicy.size(); iPolicyCnt++) {
								String sPolicySequence = (String) stListPolicy.get(iPolicyCnt);

								String tempSequence = sPolicySequence.replaceAll("-", "");
								if (cdmStringUtil.isNotEmpty(tempSequence) && sRevision.equals(tempSequence)) {
									iSeqenceNumber = iPolicyCnt;
									checkSequence = true;
								}
							}
							sRevisionSeqence = (String) stListPolicy.get(iSeqenceNumber);
							// System.out.println("sRevisionSeqence --->" + sRevisionSeqence);

							if (!checkSequence) {
								String errorMessage = "NOT MATCH POLICY SEQUENCE AND REVISION DATA. ";
								throw new Exception(errorMessage);
							}
						} else {
							sRevisionSeqence = sRevision;
						}

						BusinessObject existBusinessObj = new BusinessObject(sType, sName, sRevisionSeqence, "");
						String minorRevString = mxUtil.getFirstVersionStringForStream(sRevisionSeqence);
						BusinessObject existMinorBusinessObj = new BusinessObject(sType, sName, minorRevString, "");

						boolean isMajorExist = existBusinessObj.exists(context);
						boolean istMinorExist = existMinorBusinessObj.exists(context);

						if (isMajorExist) {
							String strFormat = "";
							String strOriginalFileName = "";
							if(cdmConstantsUtil.TYPE_CATPART.equals(sType)){
								strOriginalFileName = "TESTFILENAME_20161027_001-CATPART.CATPart";
							}else if(cdmConstantsUtil.TYPE_CATPRODUCT.equals(sType)){
								strOriginalFileName = "TEST1027-002-CATPRODUCT.CATProduct";
							}else if(cdmConstantsUtil.TYPE_CATDrawing.equals(sType)){
								strOriginalFileName = "TEST1027-001.CATDrawing";
							}else{
								String errorMessage = "NOT TYPE DATA.";
								throw new Exception(errorMessage);
							}
							
//							String strWorkspacePath = "C:\\Users\\mj\\Documents\20161027";
//							existBusinessObj.checkinFile(context, false, false, null, strFormat, "STORE", strOriginalFileName,strWorkspacePath);
							
						} else {
							String errorMessage = "NOT EXIST MAJOR OBJECT. ";
							throw new Exception(errorMessage);
						}

					} else {
						/*
						 * Document 타입일 경우 Document 의 경우 'Document Release'
						 * policy 인 object 에 모든 파일이 저장되며 revision의 object의 경우에도
						 * 파일이 이동하지않고 변경한 데이타들이 저장 파일 이 추가 될
						 * cdmAutoCAD,cdmImageDrawing,cdmV4Model 특정 attribute 속성
						 * 추가 Originator은 user 정보로 변경 Person 정보가 enovia에 Person
						 * 정보에 있을시 Owner 추가. 최신 release 정보 을 가지고 생성
						 * 
						 * 
						 * sName 은 난수가 추가 되므로 추후 변경 될 소지가 있음 .
						 */

//						DomainObject documentBusObj = new DomainObject();
//						DomainObject documentMinorBusObj = new DomainObject();
//						BusinessObject existdocumentBusObj = new BusinessObject(sType, sName, sRevision, "");
//						boolean isMajorDocumentObjExist = existdocumentBusObj.exists(context);

//						if (!isMajorDocumentObjExist) {
//							
//						} else {
//							String errorMessage = "ALREADY EXIST MAJOR OBJECT. NOT MAKE DOCUMENT OBJECT .";
//							throw new Exception(errorMessage);
//						}
						String errorMessage = "NOT CHECK ";
						throw new Exception(errorMessage);

					}
				}
				ContextUtil.commitTransaction(context);
				writeSuccessToFile("SUCESS!! LINE NUMBER: " + recordRowNum);
				writeMessageToConsole("SUCESS!!  LINE NUMBER: " + recordRowNum);
			} catch (Exception exception) {
				ContextUtil.abortTransaction(context);

				writeMessageToConsole(" Exception occured : " + exception.getMessage() + " LINE NUMBER: " + recordRowNum);
				writeErrorToFile("[cdmCADMigration_mxJPO : executeCadcMigration] Exception occured : " + exception.getMessage() + " LINE NUMBER: " + recordRowNum);
				exception.printStackTrace(errorStream);

				writeFailToFile("[cdmCADMigration_mxJPO : executeCadcMigration] fail occured. LINE NUMBER: " + recordRowNum);
			}	
			
		}catch(Exception e){
			
		}
	}

	/**
	 * 
	 * @param context
	 * @param minorRevString
	 * @param b
	 * @param stObjectId
	 * @param stVersionId
	 * @return
	 */
	@SuppressWarnings("finally")
	public boolean connectMajorAndMinorObjects(Context context, String minorRevString, boolean parameBoolean, String stObjectId, String stVersionId) {
		// TODO Auto-generated method stub
		boolean result = false;
		try {
			ContextUtil.startTransaction(context, true);
			String str4 = MCADMxUtil.getActualNameForAEFData(context, "attribute_MoveFilesToVersion");
			String str5 = MCADMxUtil.getActualNameForAEFData(context, "attribute_Title");
			String str6 = MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
			String str7 = MCADMxUtil.getActualNameForAEFData(context, "attribute_IEF-FileMessageDigest");
			
			StringBuffer localStringBufferVersion = new StringBuffer();
			localStringBufferVersion.append("connect bus \"");
			localStringBufferVersion.append(stVersionId);
			localStringBufferVersion.append("\" relationship \"");
			localStringBufferVersion.append(cdmConstantsUtil.RELATIONSHIP_VERSION_OF);
			localStringBufferVersion.append("\" preserve to \"");
			localStringBufferVersion.append(stObjectId);
			localStringBufferVersion.append("\" ");
			
			MQLCommand localMQLCommand = new MQLCommand();
			boolean boolBufferVersion = localMQLCommand.executeCommand(context, localStringBufferVersion.toString());
			
			StringBuffer localStringBufferActive = new StringBuffer();
			localStringBufferActive.append("connect bus \"");
			localStringBufferActive.append(stObjectId);
			localStringBufferActive.append("\" relationship \"");
			localStringBufferActive.append(cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION);
			localStringBufferActive.append("\" preserve to \"");
			localStringBufferActive.append(stVersionId);
			localStringBufferActive.append("\" ");

			MQLCommand activeMQLCommand = new MQLCommand();
			boolean boolBufferActive = activeMQLCommand.executeCommand(context, localStringBufferActive.toString());
			
			StringBuffer localStringBufferLatest = new StringBuffer();
			localStringBufferLatest.append("connect bus \"");
			localStringBufferLatest.append(stObjectId);
			localStringBufferLatest.append("\" relationship \"");
			localStringBufferLatest.append(cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION);
			localStringBufferLatest.append("\" preserve to \"");
			localStringBufferLatest.append(stVersionId);
			localStringBufferLatest.append("\" ");
			
			MQLCommand latestMQLCommand = new MQLCommand();
			boolean boolBufferLatest = latestMQLCommand.executeCommand(context, localStringBufferLatest.toString());
		
			ContextUtil.commitTransaction(context);
			result = true;
		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			e.printStackTrace();
			result = false;
		}finally{
			return result;
			
		}
	}

	/**
	 * null 발생시 "" 로 체크  
	 * @param data
	 * @return
	 */
	public String isVaildNullData(String data){
		return ((data == null || "null".equals(data)) ? "" : data.trim());
	}
	
	
    private boolean isValidData(String data) {
		return ((data == null || "null".equals(data)) ? 0 : data.trim().length()) > 0;
	}
    
	private void closeLogStream() throws IOException
	{
		try 
		{
			if(null != logWriter)
				logWriter.close();

			if(null != errorStream)
				errorStream.close();

			if(null != successObjectidWriter)
				successObjectidWriter.close();

			if(null != failedObjectidWriter)
				failedObjectidWriter.close();
		} 
		catch (IOException e) 
		{
			System.out.println("Exception while closing log stream "+e.getMessage());
		}
	}
	
	private void writeErrorToFile(String message)throws Exception{
		errorStream.write(message.getBytes("UTF-8"));
		errorStream.write("\n".getBytes("UTF-8"));
	}
	
	private void writeMessageToConsole(String message) throws Exception
	{
		writeMessageToLogFile(message);
	}

	private void writeMessageToLogFile(String message) throws Exception
	{
		logWriter.write( message + "\n");
	}
	
	private String getTimeStamp(){
		Date date = new Date();
		String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(date)+"T"+ new SimpleDateFormat("HH:mm:ss").format(date);

		timeStamp = timeStamp.replace('-', '_');
		timeStamp = timeStamp.replace(':', '_');

		return timeStamp;
	}
	
	public void writeFailToFile(String message) throws Exception{
		failedObjectidWriter.write( message + "\n");
	}
	public void writeSuccessToFile(String message)throws Exception{
		successObjectidWriter.write(message + "\n");
	}
	
	/**
	 * args{inputDirectory, 
	 * 
	 * @param context
	 * @param args
	 * @param requestAgsNum
	 * @param logFileName
	 */
	private void initializeM(Context context,String args[],int requestAgsNum , String logFileName)throws Exception{


		if (args.length != requestAgsNum )
		{
			throw new IllegalArgumentException("Wrong number of arguments or arguments with wrong values!");
		}


		inputDirectory = args[0];

		// documentDirectory does not ends with "/" add it
		if(inputDirectory != null && !inputDirectory.endsWith(sfileSeparator))
		{
			inputDirectory = inputDirectory + sfileSeparator;
		}

		// create a directory to add debug and error logs
		outputDirectory = new File(inputDirectory).getParentFile().getParent() + sfileSeparator + "confirm_File" + sfileSeparator + logFileName  +"_"+  getTimeStamp() + sfileSeparator;
        File fileOutputDirectory = new File(outputDirectory);
        if(!fileOutputDirectory.isDirectory()){
        	fileOutputDirectory.mkdirs();
        }
		logWriter 			 	= new BufferedWriter(new FileWriter(outputDirectory + logFileName + "_DebugLog.txt",true));
		errorStream 			= new PrintStream(new FileOutputStream(new File(outputDirectory + logFileName + "_ErrorLog.txt")));

		successLogFile  		= new File(outputDirectory + logFileName + "_SuccessObjectids.log");
		successObjectidWriter 	= new BufferedWriter(new FileWriter(successLogFile,true));

		failedLogFile  			= new File(outputDirectory + logFileName + "_FailedObjectids" + ".txt");
		failedObjectidWriter 	= new BufferedWriter(new FileWriter(failedLogFile,true));
		
		// input file name
		fileName = args[1];
		
	
	}
	
	
	
	public void Test(Context context, String arg[])throws Exception{
		
		try {
			String minorRevString = "";
//			connectMajorAndMinorObjects(context, minorRevString, true, "8820.41398.50872.37540", "8820.41398.50872.41508");
//			disConnectMajorAndMinorObjects(context, minorRevString, true, "8820.41398.2088.17333", "8820.41398.2088.19366");
//			connectMajorAndMinorObjects(context, minorRevString, true, "8820.41398.2088.17333", "8820.41398.2088.19366");
//			Map programMap = new HashMap();
//			String language = context.getLocale().getLanguage();
//			IEFIntegAccessUtil util = new IEFIntegAccessUtil(context, new MCADServerResourceBundle(language), new IEFGlobalCache());
//			String integrationName = (String) util.getAssignedIntegrations(context).get(0);
//			System.out.println("integrationName --- > "+integrationName);
//			MCADGlobalConfigObject globalConfigObject = (MCADGlobalConfigObject) programMap.get("GCO");
//			MCADServerResourceBundle resourceBundle = new MCADServerResourceBundle((String) programMap.get("languageStr"));
//			IEFGlobalCache cache = new IEFGlobalCache();
//			MCADMxUtil mxUtil = new MCADMxUtil(context, resourceBundle, cache);
//			MCADServerGeneralUtil generalUtil = new MCADServerGeneralUtil(context, globalConfigObject, resourceBundle, cache);
//			String minorPolicy = mxUtil.getRelatedPolicy(context, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION); // [NDM]
//			System.out.println("minorPolicy  "+minorPolicy);																										// :
																													// L86
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
	}

	
	
	/**
	 * CATPart ,CATDrawing, CATProduct 데이타 삭제 (
	 * 삭제하게되면 연결되어있는 version object 도 같이 삭제된다.  
	 * @param context
	 * @param majorObjectId
	 * @throws Exception
	 */
	public void deleteCADDocument(Context context,String majorObjectId)throws Exception{
		
		DomainObject dObj = DomainObject.newInstance(context);
		String stObjType = (String)dObj.getInfo(context, cdmConstantsUtil.SELECT_TYPE);
		
		MCADMxUtil util = null;
		boolean IsCAD = false;
		try{
			if (cdmStringUtil.isNotEmpty(stObjType) && (cdmConstantsUtil.TYPE_CATDrawing.equals(stObjType) || cdmConstantsUtil.TYPE_CATPART.equals(stObjType) || cdmConstantsUtil.TYPE_CATPRODUCT.equals(stObjType))) {
				String stCAD_DocumentObjectId = majorObjectId;
				
				util.setRPEVariablesForIEFOperation(context, MCADServerSettings.ISDECDelete);
				MCADIntegrationSessionData integSessionData = null;
				IsCAD = true;
				util.deleteDocument(context, integSessionData, stCAD_DocumentObjectId, false);
				StringList slDeletedList = new StringList();
				slDeletedList.addElement(stCAD_DocumentObjectId);

				String recentlyAccessListEncoded = CacheUtil.getCacheString(context, "RECENTLY_ACCESSED_PARTS");
				if (null != recentlyAccessListEncoded && !"".equals(recentlyAccessListEncoded)) {
					String recentlyAccessList = MCADUrlUtil.decode(recentlyAccessListEncoded);

					if (null != recentlyAccessList && !"".equals(recentlyAccessList)) {

						MapList mpRecentlyAccessedList = (MapList) MCADUtil.covertToObject(recentlyAccessList, true, true);

						StringList slPositionsToClear = new StringList();
						for (int p = 0; p < mpRecentlyAccessedList.size(); p++) {
							Map mpEach = (Map) mpRecentlyAccessedList.get(p);
							String sId = (String) mpEach.get("id");
							if (slDeletedList.contains(sId)) {
								slPositionsToClear.addElement(p);
							}
						}
						MapList mpUpdatedRecentlyAccessList = new MapList();
						for (int k = 0; k < mpRecentlyAccessedList.size(); k++) {
							Map mpEach = (Map) mpRecentlyAccessedList.get(k);
							if (!slPositionsToClear.contains(k)) {
								mpUpdatedRecentlyAccessList.add(mpEach);
							}
						}

						String sUpdatedList = MCADUtil.covertToString(mpUpdatedRecentlyAccessList, true, true);

						sUpdatedList = MCADUrlUtil.encode(sUpdatedList);
						CacheUtil.setCacheObject(context, "RECENTLY_ACCESSED_PARTS", sUpdatedList);
					}
				}

			} else if (cdmConstantsUtil.TYPE_DOCUMENT.equals(stObjType) && cdmStringUtil.isNotEmpty(stObjType)) {

				String stDocumentObjectId = majorObjectId;
				DomainObject domObj = DomainObject.newInstance(context);
				StringBuffer sbLockedSelect = new StringBuffer();

				sbLockedSelect.append("relationship[");
				sbLockedSelect.append(com.matrixone.apps.common.CommonDocument.RELATIONSHIP_ACTIVE_VERSION);
				sbLockedSelect.append("].to.locked");

				StringList selDocumentList = new StringList();
				selDocumentList.add(DomainObject.SELECT_TYPE);
				selDocumentList.add(DomainObject.SELECT_NAME);
				selDocumentList.add(sbLockedSelect.toString());
				selDocumentList.add(com.matrixone.apps.common.CommonDocument.SELECT_VCFILE_LOCKED);
				selDocumentList.add(DomainObject.SELECT_LOCKED);
				selDocumentList.add(DomainObject.SELECT_CURRENT);

				String objectId = stDocumentObjectId;
				domObj.setId(objectId);
				Map resultMap           = domObj.getInfo(context, selDocumentList);
				String docLocked 		= (String) resultMap.get(sbLockedSelect.toString());
				String objectLocked 	= (String) resultMap.get(DomainObject.SELECT_LOCKED);
				String vcDocLocked		= (String) resultMap.get(com.matrixone.apps.common.CommonDocument.SELECT_VCFILE_LOCKED);
				boolean isLocked 		= (!UIUtil.isNullOrEmpty(docLocked) && docLocked.indexOf("TRUE") != -1) || (!UIUtil.isNullOrEmpty(vcDocLocked) && (vcDocLocked.equalsIgnoreCase("TRUE"))) || (!UIUtil.isNullOrEmpty(objectLocked) && (objectLocked.equalsIgnoreCase("TRUE")));
				String sDocumentType 	= (String) resultMap.get(DomainObject.SELECT_TYPE);
				String sPart            = LibraryCentralConstants.TYPE_PART;
				String sState = (String) resultMap.get(DomainObject.SELECT_CURRENT);
				String sActiveState = LibraryCentralConstants.STATE_DOCUMENT_SHEET_ACTIVE;

				try {
					if (isLocked) {
						String errorMessage = "FILE IS LOCKED.PLEASE CHECK.";
						throw new Exception(errorMessage);
					} else {
						if (sDocumentType != null && (sDocumentType.equalsIgnoreCase("Generic Document") || sDocumentType.equalsIgnoreCase(cdmConstantsUtil.TYPE_DOCUMENT))) {
							com.matrixone.apps.common.CommonDocument.deleteDocuments(context, new String[] { objectId });
						} else if (sDocumentType.equalsIgnoreCase("Document Sheet") && sState.equalsIgnoreCase(sActiveState)) {
							String errorMessage = "DELETE TYPE HAVE TO DOCUMENT TYPE. PLEASE CHECK.";
							throw new Exception(errorMessage);
						} else {
							BusinessType businessType = new BusinessType(sDocumentType, context.getVault());
							String strParentType = businessType.getParent(context);
							String strReturn = null;
							if (strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_LIBRARIES)) {
								Libraries LcObj = (Libraries) DomainObject.newInstance(context, objectId, LibraryCentralConstants.LIBRARY);
								strReturn = LcObj.deleteObjects(context);
							} else if (strParentType != null && strParentType.equalsIgnoreCase(LibraryCentralConstants.TYPE_CLASSIFICATION)) {
								Classification LcObj = (Classification) DomainObject.newInstance(context, objectId, LibraryCentralConstants.LIBRARY);
								strReturn = LcObj.deleteObjects(context);
							} else if (sDocumentType != null && sDocumentType.equalsIgnoreCase(sPart)) {
								com.matrixone.apps.library.Part LcObj = (com.matrixone.apps.library.Part) DomainObject.newInstance(context, objectId, LibraryCentralConstants.LIBRARY);
								strReturn = LcObj.deleteObjects(context);
//							} else if (sDocumentType != null && sDocumentType.equalsIgnoreCase(sFolder)) {
//								DCWorkspaceVault folderObj = (DCWorkspaceVault) DomainObject.newInstance(context, objectId, LibraryCentralConstants.DOCUMENT);
//								strReturn = folderObj.deleteObjects(context);
							} else {
								domObj.deleteObject(context);
							}
							if (strReturn != null && strReturn.equalsIgnoreCase("false")) {
								String errorMessage = "DELETE ERROR .";
								throw new Exception(errorMessage);
							}
						}
					}
				} catch (Exception exp) {
					exp.printStackTrace();
				}


			}
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			if(IsCAD){
			util.unsetRPEVariablesForIEFOperation(context,MCADServerSettings.ISDECDelete);
			}
		}
	}
	
	
	
//	/**
//	 * 
//	 * @param context
//	 * @param sType 생성할 major object_Type
//	 * @param sName 생성할 major object_Name
//	 * @param sRevisionSeqence 생성할 major object_rev
//	 * @param minorRevString 생성할 minor object_Name
//	 * @param sPartFindObjId 연결할 Part Id
//	 * @param linkedCadHM 속성 데이타 ..etc
//	 */
//	@SuppressWarnings("finally")
//	private boolean createCADMaster(Context context, String sType, String sName, String sRevisionSeqence, String minorRevString, String sPartFindObjId, LinkedHashMap<String, Object> linkedCadHM,boolean IsExistPerson ) {
//		boolean result = false;
//		try {
//			// TODO Auto-generated method stub
//			DomainObject busObject = new DomainObject();
//			DomainObject minorBusObject = new DomainObject();
//
//			String sAttribute_CADType = MCADMxUtil.getActualNameForAEFData(context, "attribute_CADType");
//			String sAttribute_MoveFileVersion = MCADMxUtil.getActualNameForAEFData(context, "attribute_MoveFilesToVersion");
//			// original file name 과 데이타가 같다.
//			String sAttribute_Title = MCADMxUtil.getActualNameForAEFData(context, "attribute_Title");
//			String sAttribute_IsVersionObj = MCADMxUtil.getActualNameForAEFData(context, "attribute_IsVersionObject");
//			String sAttribute_IEFFileMessage = MCADMxUtil.getActualNameForAEFData(context, "attribute_IEF-FileMessageDigest");
//			String sAttribute_Source = MCADMxUtil.getActualNameForAEFData(context, "attribute_Source");
//
//			ContextUtil.startTransaction(context, true);
//			MqlUtil.mqlCommand(context, "Trigger Off");
//			busObject.createObject(context, sType, sName, sRevisionSeqence, cdmConstantsUtil.POLICY_DESIGN_TEAM_DEFINITION, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//
//			String stObjectId = busObject.getObjectId();
//
//			/*
//			 * *****************************************************************
//			 *  파일 체크인 파일명은 sCAD_REF_FILE_NAME 으로 하며 최신 revision 에 연결된 file 을 Design Team
//			 * Resource 아직은 주석처리 10.17.2016 확인하고 추후 진행할것
//			 * !!!!!!!!!!!!!!!!!!!!!!!!!!!! 파일 체크인 하는 부분은 따로 처리할 예정 10.19.16
//			 */
//			/* 속성 입력 start */
//			String sTDMXID                 		 =   (String)linkedCadHM.get("TDMX_ID");  					 		//  2  attribute[cdmTDMXID]
//			String sCRT_USERS				 	 =	 (String)linkedCadHM.get("CRT_USERS");  	 	                //  4 ,originator, owner
//			String sTDM_DESCRIPTION 	 		 =	 (String)linkedCadHM.get("TDM_DESCRIPTION"); 	                //  5 ,
//			String sTDMX_DETAILED_DESCRIPTION 	 =	 (String)linkedCadHM.get("TDMX_DETAILED_DESCRIPTION");          //  8 ,
//			String sTDMX_COMMENTS 	  			 =	 (String)linkedCadHM.get("TDMX_COMMENTS");                      //  9 ,
//			String sTDMX_3D_CAD_IDENTIFIER 	  	 =	 (String)linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER");             //  10,
//			String sTDMX_SCALE 					 =	 (String)linkedCadHM.get("TDMX_SCALE");                         //  12,
//			String sTDMX_PAGE_SIZE 				 =	 (String)linkedCadHM.get("TDMX_PAGE_SIZE");                     //  13,
//			String sFILE_TYPE 	 				 =	 (String)linkedCadHM.get("FILE_TYPE");                          //  14,
//			String sCAD_REF_FILE_NAME 	 		 =	 (String)linkedCadHM.get("CAD_REF_FILE_NAME");          		//  16, ORIGINAL FILE
//			String sTDM_DOCUMENT_TYPE 	         =	 (String)linkedCadHM.get("TDM_DOCUMENT_TYPE");                  //  20,
//			String sCN_MASS 	                 =	 (String)linkedCadHM.get("CN_MASS");                            //  27,
//			String sCN_SURFACE_AREA 	         =	 (String)linkedCadHM.get("CN_SURFACE_AREA");                    //  28,
//			
//			AttributeList localAttributeList = new AttributeList();
//			localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_Title), sCAD_REF_FILE_NAME));
//			localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IEFFileMessage), ""));
//			localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_Source), sourceInfo));
//
//			localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID),                  sTDMXID));
//			localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION),      sTDMX_DETAILED_DESCRIPTION));
//			localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_COMMENT),                 sTDMX_COMMENTS));
//			localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER),       sTDMX_3D_CAD_IDENTIFIER));
//			localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE),               sFILE_TYPE));
//			localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE), sTDM_DOCUMENT_TYPE));
//			localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION),           "Y"));
//
//			if ((cdmConstantsUtil.TYPE_CATDrawing).equals(sType)) {
//				localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE),     sTDMX_SCALE));
//				localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE), sTDMX_PAGE_SIZE));
//			}
//
//			if ((cdmConstantsUtil.TYPE_CATPART).equals(sType)) {
//				localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS),      sCN_MASS));
//			}
//
//			if ((cdmConstantsUtil.TYPE_CATPART).equals(sType) || (cdmConstantsUtil.TYPE_CATPRODUCT).equals(sType)) {
//				localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE),   sCN_SURFACE_AREA));
//			}
//
//			localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "True"));
//			localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IsVersionObj),    "False"));
//
//			/* 
//			 *  MAJOR VERSION OBJECT
//			 *  ATTRIBUTE[ORIGINATOR],OWNER 정보 추가
//			 *  PERSON 정보가 존재하지않는다면 제외 
//			 * 
//			 */
//			localAttributeList.addElement(new Attribute(new AttributeType(cdmConstantsUtil.ATTRIBUTE_ORIGINATOR),                  sCRT_USERS));
//			if(IsExistPerson){
//				busObject.setOwner(context, sCRT_USERS);
//			}
//			
//			/*   MAJOR VERSION OBJECT ATTRIBUTE, DESCRIPTION 설정  */
//			busObject.setAttributes(context, localAttributeList);
//			busObject.setDescription(context, sTDM_DESCRIPTION);
//			
//			/* minor version */
//			localAttributeList.remove(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "True"));
//			localAttributeList.remove(new Attribute(new AttributeType(sAttribute_IsVersionObj),    "False"));
//
//			minorBusObject.createObject(context, sType, sName, minorRevString, cdmConstantsUtil.POLICY_VERSIONED_DESIGN_TEAM_POLICY, cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION);
//			String stVersionId = minorBusObject.getObjectId();
//
//			localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_MoveFileVersion), "False"));
//			localAttributeList.addElement(new Attribute(new AttributeType(sAttribute_IsVersionObj),    "True"));
//
//			minorBusObject.setAttributes(context, localAttributeList);
//
//			if (cdmStringUtil.isNotEmpty(sTDM_DESCRIPTION)) {
//				minorBusObject.setDescription(context, sTDM_DESCRIPTION);
//			}
//			
//			/* 
//			 *  MINOR VERSION OBJECT
//			 *  OWNER 정보 추가
//			 *  PERSON 정보가 존재하지않는다면 제외 
//			 */
//			if (IsExistPerson) {
//				minorBusObject.setOwner(context, sCRT_USERS);
//			}
//
//			StringBuffer localStringBufferVersion = new StringBuffer();
//			localStringBufferVersion.append("connect bus \"");
//			localStringBufferVersion.append(stVersionId);
//			localStringBufferVersion.append("\" relationship \"");
//			localStringBufferVersion.append(cdmConstantsUtil.RELATIONSHIP_VERSION_OF);
//			localStringBufferVersion.append("\" preserve to \"");
//			localStringBufferVersion.append(stObjectId);
//			localStringBufferVersion.append("\" ");
//			
//			MQLCommand localMQLCommand = new MQLCommand();
//			localMQLCommand.open(context);
//			boolean boolBufferVersion = localMQLCommand.executeCommand(context, localStringBufferVersion.toString());
//			if(!boolBufferVersion){
//				String errorMessage = " NOT RELATIONSHIP[VersionOf] CONNECT MAJOR OBJECT, MINOR OBJECT ";
//				throw new Exception(errorMessage);
//			}
//			localMQLCommand.close(context);
//			
//			
//			StringBuffer localStringBufferActive = new StringBuffer();
//			localStringBufferActive.append("connect bus \"");
//			localStringBufferActive.append(stObjectId);
//			localStringBufferActive.append("\" relationship \"");
//			localStringBufferActive.append(cdmConstantsUtil.RELATIONSHIP_ACTIVE_VERSION);
//			localStringBufferActive.append("\" preserve to \"");
//			localStringBufferActive.append(stVersionId);
//			localStringBufferActive.append("\" ");
//
//			MQLCommand activeMQLCommand = new MQLCommand();
//			activeMQLCommand.open(context);
//			boolean boolBufferActive = activeMQLCommand.executeCommand(context, localStringBufferActive.toString());
//			if(!boolBufferActive){
//				String errorMessage = " NOT RELATIONSHIP[Active Version] CONNECT MAJOR OBJECT, MINOR OBJECT ";
//				throw new Exception(errorMessage);
//			}
//			activeMQLCommand.close(context);
//			
//			StringBuffer localStringBufferLatest = new StringBuffer();
//			localStringBufferLatest.append("connect bus \"");
//			localStringBufferLatest.append(stObjectId);
//			localStringBufferLatest.append("\" relationship \"");
//			localStringBufferLatest.append(cdmConstantsUtil.RELATIONSHIP_LATEST_VERSION);
//			localStringBufferLatest.append("\" preserve to \"");
//			localStringBufferLatest.append(stVersionId);
//			localStringBufferLatest.append("\" ");
//			
//			MQLCommand latestMQLCommand = new MQLCommand();
//			latestMQLCommand.open(context);
//			boolean boolBufferLatest = latestMQLCommand.executeCommand(context, localStringBufferLatest.toString());
//			
//			if(!boolBufferLatest){
//				String errorMessage = " NOT RELATIONSHIP[Latest Version] CONNECT MAJOR OBJECT, MINOR OBJECT ";
//				throw new Exception(errorMessage);
//			}
//			latestMQLCommand.close(context);
//			/* 속성 입력 end */
//			
//			ContextUtil.commitTransaction(context);
//		}catch(Exception e){
//			result = false;
//			ContextUtil.abortTransaction(context);
////			e.printStackTrace();
//		}finally{
//			return result;
//		}
//	}

	
//	/**
//	 *참조 문서 cdmDocumentsCheckinProcess.jsp 
//	 * revision 정보는 아직 확인해야할 사항  읽을 revision정보로 진행 
//	 * Auto CAD 의 경우 rel 정보 parentRelName 
//	 * @param context
//	 * @param sType
//	 * @param sName
//	 * @param linkedCadHM
//	 * @return
//	 */
//	@SuppressWarnings({ "unchecked", "rawtypes" })
//	public boolean createDocumentMaster(Context context, String sType, String sName, String sPartFindObjId,LinkedHashMap<String, Object> linkedCadHM) {
//		// TODO Auto-generated method stub
//		boolean result = false;
//		try {
//			ContextUtil.startTransaction(context, true);
//
//			String type 	                   = sType;
//			String name 	                   = sName;
//			String policy 	                   = "Document Release";
//			String title                       = sName;
//			String language                    = null;
//			String parentRelName               = cdmConstantsUtil.RELATIONSHIP_PART_SPECIFICATION;
//			String isFrom                      = "false";
//			String objectGeneratorRevision     =  "";
//			String vault                       = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
////			String objectGeneratorRevision     = (String) linkedCadHM.get("objectGeneratorRevision");
//			
//			String sTempType                     =	 (String)linkedCadHM.get("CLS_NAME"); 					 		//  1  Type 
//			String sTDMXID 	                     =	 (String)linkedCadHM.get("TDMX_ID");  					 		//  2  attribute[cdmTDMXID]  
//			String sRevision				 	 =	 (String)linkedCadHM.get("REVISION");  	 	                    //  3  Revision   
//			String sCRT_USERS				 	 =	 (String)linkedCadHM.get("CRT_USERS");  	 	                //  4 ,originator, owner  
//			String sTDM_DESCRIPTION 	 		 =	 (String)linkedCadHM.get("TDM_DESCRIPTION"); 	                //  5 ,  
//			String sTDMX_DETAILED_DESCRIPTION 	 =	 (String)linkedCadHM.get("TDMX_DETAILED_DESCRIPTION");          //  8 ,
//			String sTDMX_COMMENTS 	  			 =	 (String)linkedCadHM.get("TDMX_COMMENTS");                      //  9 ,
//			String sTDMX_3D_CAD_IDENTIFIER 	  	 =	 (String)linkedCadHM.get("TDMX_3D_CAD_IDENTIFIER");             //  10,
//			String sTDMX_TITLE_TYPE 	  		 =	 (String)linkedCadHM.get("TDMX_TITLE_TYPE");                    //  11,
//			String sTDMX_SCALE 					 =	 (String)linkedCadHM.get("TDMX_SCALE");                         //  12,
//			String sTDMX_PAGE_SIZE 				 =	 (String)linkedCadHM.get("TDMX_PAGE_SIZE");                     //  13,
//			String sFILE_TYPE 	 				 =	 (String)linkedCadHM.get("FILE_TYPE");                          //  14,
//			String sCAD_REF_FILE_NAME 	 		 =	 (String)linkedCadHM.get("CAD_REF_FILE_NAME");          		//  16, ORIGINAL FILE
//			String sVAULT_OBJECT_ID 	  		 =	 (String)linkedCadHM.get("VAULT_OBJECT_ID");                    //  17,
//			String sPHASE 	 					 =	 (String)linkedCadHM.get("PHASE");                              //  18,
//			String sTDM_ORG_USER_ID 	         =	 (String)linkedCadHM.get("TDM_ORG_USER_ID");                    //  19,
//			String sTDM_DOCUMENT_TYPE 	         =	 (String)linkedCadHM.get("TDM_DOCUMENT_TYPE");                  //  20,
//			String sTDM_ARCHIVE_TYPE 	         =	 (String)linkedCadHM.get("TDM_ARCHIVE_TYPE");                   //  21,
//			String sTDM_ARCHIVE_NAME 	         =	 (String)linkedCadHM.get("TDM_ARCHIVE_NAME");                   //  22,
//			String sPROD_DIV 	                 =	 (String)linkedCadHM.get("PROD_DIV");                           //  23,
//			String sCN_PROJECT 	                 =	 (String)linkedCadHM.get("CN_PROJECT");                         //  24,
//			String sCN_PROJECT_CUST 	         =	 (String)linkedCadHM.get("CN_PROJECT_CUST");                    //  26,
//			String sCN_MASS 	                 =	 (String)linkedCadHM.get("CN_MASS");                            //  27,
//			String sCN_SURFACE_AREA 	         =	 (String)linkedCadHM.get("CN_SURFACE_AREA");                    //  28,
//			String sCN_OEM_PART_NUMBER 	         =	 (String)linkedCadHM.get("CN_OEM_PART_NUMBER");                 //  29,
//			String sCN_ECO_NUMBER 	             =	 (String)linkedCadHM.get("CN_ECO_NUMBER");                      //  30,
//			String sCN_MASS_ESTIMATED 	         =	 (String)linkedCadHM.get("CN_MASS_ESTIMATED");                  //  31,
//			String sCN_PRODUCT_GROUP 	         =	 (String)linkedCadHM.get("CN_PRODUCT_GROUP");                   //  32,
//			String sCN_CUSTOMER 	             =	 (String)linkedCadHM.get("CN_CUSTOMER");                        //  33,
//			String sCN_RELATED_ITEM_NAME 	     =	 (String)linkedCadHM.get("CN_RELATED_ITEM_NAME");               //  35,
//			String sCN_RELATED_ITEM_REV 	     =	 (String)linkedCadHM.get("CN_RELATED_ITEM_REV");                //  36,
//
//			if (sTDM_DESCRIPTION == null || "".equals(sTDM_DESCRIPTION) || "null".equals(sTDM_DESCRIPTION)) {
//				sTDM_DESCRIPTION = (String) linkedCadHM.get("sTDM_DESCRIPTION");
//			}
//			
//			if (title == null || "".equals(title) || "null".equals(title)) {
//				title = null;
//			}
//
//			CommonDocument object = (CommonDocument) DomainObject.newInstance(context, CommonDocument.TYPE_DOCUMENTS);
//			DomainObject parentObject = null;
//			if (sPartFindObjId != null && !"".equals(sPartFindObjId) && !"null".equals(sPartFindObjId)) {
//				parentObject = DomainObject.newInstance(context, sPartFindObjId);
//			}
//
//			HashMap mAttrMap = new HashMap(); //데이타 입력해야함 10.18.16 속성정보 지정할것 
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_PAGE_SIZE,  sTDMX_PAGE_SIZE);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SCALE, 	  sTDMX_SCALE);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_TITLE_TYPE, sTDMX_TITLE_TYPE );
//			
//			//MIGRATION DATA을 위해 속성 추가 AUTOCAD,  ..
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_TDMXID,  					sTDMXID						);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DETAIL_DESCRIPTION,   		sTDMX_DETAILED_DESCRIPTION	);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_COMMENT,  					sTDMX_COMMENTS          	);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_3D_CAD_IDENTIFIER,  		sTDMX_3D_CAD_IDENTIFIER		);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_FILE_TYPE, 					sFILE_TYPE					);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_DOCUMENT_TYPE,  	sTDM_DOCUMENT_TYPE			);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDMCHECKMIGRATION, 				"Y" 						);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_MASS,  			sCN_MASS					);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_DOCUMENTS_SURFACE,  		sCN_SURFACE_AREA			);
//			mAttrMap.put(cdmConstantsUtil.ATTRIBUTE_ORIGINATOR,  					sCRT_USERS					);
//
//			
//			MqlUtil.mqlCommand(context, "Trigger Off");
//			object = object.createAndConnect(context, type, name, sRevision, policy, sTDM_DESCRIPTION, vault, title, language, parentObject, parentRelName, isFrom, mAttrMap, objectGeneratorRevision);
//			MqlUtil.mqlCommand(context, "Trigger On");
//			
//			StringList selects = new StringList(2);
//			selects.add(DomainConstants.SELECT_ID);
//			selects.add(CommonDocument.SELECT_MOVE_FILES_TO_VERSION);
//
////			Map objectSelectMap = object.getInfo(context, selects);
////			String objectId = "";
////			objectId = (String) objectSelectMap.get(DomainConstants.SELECT_ID);
//		
//			boolean isFilePresent			= true;
//			String  sVersionDescription 	= null;
//			Map     attrMapOfVersion	 	= new HashMap();
//			
//			boolean createVersion = true;
//			
//			if (createVersion) {
//				MqlUtil.mqlCommand(context, "Trigger Off");
//				object.createVersion(context, sVersionDescription, sCAD_REF_FILE_NAME, attrMapOfVersion);
//				MqlUtil.mqlCommand(context, "Trigger On");
//			}
//			
//			String sIsPersonMql = MqlUtil.mqlCommand(context, "temp query bus Person '"+sCRT_USERS+"'  * select name dump |");
//			StringList sListIsPersonMqlResult = FrameworkUtil.split(sIsPersonMql, "|");
//			
//			if (sListIsPersonMqlResult.size()>2) {
//				object.setOwner(context, (String)sListIsPersonMqlResult.get(3));
//			}
//			//modify by 10.18.16 end
//			
//			result = true;
//			ContextUtil.commitTransaction(context);
//		} catch (Exception e) {
//			ContextUtil.abortTransaction(context);
//			e.printStackTrace();
//			result = false;
//		}finally{
//			return result;
//		}
//		
//	}
	
	
}


