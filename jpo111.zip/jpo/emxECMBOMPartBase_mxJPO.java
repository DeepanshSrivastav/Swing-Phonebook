/*
 ** ${CLASSNAME}
 **
 ** Copyright (c) 1993-2015 Dassault Systemes. All Rights Reserved.
 ** This program contains proprietary and trade secret information of
 ** Dassault Systemes.
 ** Copyright notice is precautionary only and does not evidence any actual
 ** or intended publication of such program
 */

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

import com.matrixone.jdom.Element;

import com.dassault_systemes.enovia.e6wv2.foundation.db.MqlUtil;
import com.mando.util.cdmConstantsUtil;
import com.mando.util.cdmStringUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.EnoviaResourceBundle;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.PropertyUtil;
import com.matrixone.apps.engineering.EBOMAutoSync;
import com.matrixone.apps.engineering.EBOMMarkup;
import com.matrixone.apps.engineering.EngineeringConstants;
import com.matrixone.apps.engineering.EngineeringUtil;
import com.matrixone.jdom.Document;
import com.matrixone.apps.engineering.PartFamily;
import com.matrixone.apps.framework.ui.UINavigatorUtil;
import com.matrixone.apps.framework.ui.UITableIndented;
import com.matrixone.apps.framework.ui.UIUtil;
import com.matrixone.jsystem.util.StringUtils;

import matrix.db.Access;
import matrix.db.BusinessType;
import matrix.db.Context;
// Added for UIMenu and UITableCommon class for retreiving the command and settings end
import matrix.db.JPO;
import matrix.util.SelectList;
import matrix.util.StringList;

/**
 * The <code>emxMBOMPartBase</code> class contains implementation code for emxPart.
 *
 * @version EC 9.5.JCI.0 - Copyright (c) 2002, MatrixOne, Inc.
 */
public class emxECMBOMPartBase_mxJPO extends emxECPartBase_mxJPO
{
       /**
     * Constructor.
     *
     * @param context the eMatrix <code>Context</code> object.
     * @param args holds no arguments.
     * @throws Exception if the operation fails.
     * @since EC 9.5.JCI.0.
     */
    public emxECMBOMPartBase_mxJPO (Context context, String[] args)
        throws Exception
    {
        super(context, args);
    }

    /**
     * This method is executed if a specific method is not specified.
     *
     * @param context the eMatrix <code>Context</code> object.
     * @param args holds no arguments.
     * @return int.
     * @throws Exception if the operation fails.
     * @since EC 9.5.JCI.0.
     */
    public int mxMain(Context context, String[] args)
        throws Exception
    {
        if (true)
        {
            throw new Exception("must specify method on emxPart invocation");
        }
        return 0;
    }

    /**
     * To allow Apply edits in EBOM emxTable/Indented  Table
     * based on the state of the Parent assembly Part
     * @param context the eMatrix <code>Context</code> object.
     * @param args holds objectId.
     * @return HashMap.
     * @throws Exception If the operation fails.
     * @since X+3.
     * @author jh.Lee
     */

    @com.matrixone.apps.framework.ui.PostProcessCallable
    public HashMap validateStateForApply(Context context, String[] args) throws Exception {
 		HashMap retMap = new HashMap();
 		
 		// Need to pass a Refresh for Auto sync, because prod name should be shown in Specification Title column
 		retMap.put("Action", EBOMAutoSync.isAutoSyncDisabled(context) ? "success" : "Refresh");

 		try {
 			HashMap programMap = (HashMap) JPO.unpackArgs(args);
 			HashMap tableData  = (HashMap) programMap.get("tableData");
 			MapList objectList = (MapList) tableData.get("ObjectList");
 			HashMap requestMap = (HashMap) programMap.get("requestMap");
 			Document doc       = (Document) requestMap.get("XMLDoc");

 			com.matrixone.jdom.Element rootElement = doc.getRootElement();

 			java.util.List objList = rootElement.getChildren("object");
 			Iterator objItr = objList.iterator();
 			while (objItr.hasNext()) {
                com.matrixone.jdom.Element eleChild = (com.matrixone.jdom.Element) objItr.next();
 				com.matrixone.jdom.Attribute attrAction = eleChild.getAttribute("markup");
              	com.matrixone.jdom.Attribute attrObjectId = null;
              	
      			String strObjectId = null;

 				if (attrAction != null && "changed".equals(attrAction.getValue())) {
 					attrObjectId = eleChild.getAttribute("parentId");
 					strObjectId = attrObjectId.getValue();
                    
 					//364281
                    retMap.put("Action", "refresh");
                    //364281
 				} else {
 					attrObjectId = eleChild.getAttribute("objectId");
 					strObjectId = attrObjectId.getValue();
 				}

 				HashMap argMap = new HashMap();
 				argMap.put("objectId", strObjectId);

 				boolean isCamInstalled = FrameworkUtil.isSuiteRegistered(context,"appVersionX-BOMCostAnalytics",false,null,null);
 				Boolean blnIsApplyAllowed;

 				if (isCamInstalled) {
 					blnIsApplyAllowed =(Boolean)JPO.invoke(context, "CAENCActionLinkAccessBase", null, "isApplyAllowed", JPO.packArgs(argMap), Boolean.class);
 	            } else {
 	            	blnIsApplyAllowed = (Boolean)JPO.invoke(context, "emxENCActionLinkAccess", null, "isApplyAllowed", JPO.packArgs(argMap), Boolean.class);
                }

 				if (!(blnIsApplyAllowed.booleanValue())) {

 					retMap.put("Action", "ERROR");

 					String langStr = context.getSession().getLanguage();
 					String sErrorMsg=EngineeringUtil.i18nStringNow(context,"emxEngineeringCentral.BOM.ModifyError",langStr);

 					DomainObject domObj = new DomainObject(strObjectId);
 					matrix.db.Access mAccess = domObj.getAccessMask(context);
 					if(!mAccess.has(Access.cModify))
 						sErrorMsg = EngineeringUtil.i18nStringNow(context,"emxEngineeringCentral.BOM.SaveError",langStr);

 					retMap.put("Message", sErrorMsg);
 					break;
 				}
 			}
 			
 		} catch (Exception excep) {
 			throw new Exception(excep.toString());
 		}
 		return retMap;
    }
    
    /*
	  * Retrieves the EBOM data. Modified for expand issue for latest and latest complete.
	  * @param context the ENOVIA <code>Context</code> object
	  * @param args[] programMap
	  * @throws Exception if error encountered while carrying out the request
	  * @author jh.Lee 
	  */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	@com.matrixone.apps.framework.ui.ProgramCallable
	public MapList getEBOMsWithRelSelectablesSB(Context context, String[] args) throws Exception{
		HashMap paramMap = (HashMap) JPO.unpackArgs(args);
		String sExpandLevels = (String)paramMap.get("emxExpandFilter");
		String selectedFilterValue = (String)paramMap.get("ENCBOMRevisionCustomFilter");
		MapList retList = expandEBOM(context, paramMap);
		if("Latest".equals(selectedFilterValue) || "Latest Complete".equals(selectedFilterValue) || "Latest Release".equals(selectedFilterValue)){
			// handles manual expansion by each level for latest and latest complete
			int expandLevel = "All".equals(sExpandLevels) ? 0 : Integer.parseInt(sExpandLevels);
			MapList childList = null;
			Map obj = null;
			int level;
			retList = getFilterList(context, retList, selectedFilterValue);
			for(int index=0; index < retList.size(); index++){
			    obj = (Map)retList.get(index);
				if(expandLevel == 0 || Integer.parseInt((String)obj.get("level")) < expandLevel){
					paramMap.put("partId", (String)obj.get(SELECT_ID));
					childList = expandEBOM(context, paramMap);
					childList = getFilterList(context, childList, selectedFilterValue);
					
					if(childList != null && ! childList.isEmpty()){
						for(int cnt=0; cnt<childList.size(); cnt++){
							level = Integer.parseInt((String)obj.get("level"))+1;
							((Map)childList.get(cnt)).put("level", String.valueOf(level));
						}
						retList.addAll(index+1,childList);
					}
				}
			}
		}
		
		return retList;
	}
	
	
	/**
	 * 
	 * @param context
	 * @param objectList
	 * @param selectedFilterValue
	 * @return
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	private MapList getFilterList(Context context, MapList objectList, String selectedFilterValue) {
		MapList rtnList = new MapList();
		try {

			if ("Latest".equals(selectedFilterValue)) {

				StringList uniqueBucket = new StringList();
				for (int i = 0; i < objectList.size(); i++) {
					Map map = (Map) objectList.get(i);

					String strPartId = (String) map.get(DomainObject.SELECT_ID);
					if (uniqueBucket.contains(strPartId))
						continue;

					uniqueBucket.add(strPartId);
					rtnList.add(map);
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return rtnList;
	}

	
	
//	/*
//	 * @author jh.Lee 
//	 */
//	private MapList getFilterList(MapList objectList, String key) {
//		MapList rtnList = new MapList();
//		try {
//			for (int i = 0; i < objectList.size(); i++) {
//			    Map map = (Map) objectList.get(i);
//			    String value = (String) map.get(key);
//			    if (i == 0) {
//			    	rtnList.add(map);
//			    } else {
//			    	boolean duplicationCheck = false;
//			    	int rtnListSize = rtnList.size();
//			    	for (int j = 0; j < rtnListSize; j++) {
//			    		String compareValue = (String) ((Map) rtnList.get(j)).get(key);
//			    		if (compareValue.equals(value)) {
//			    			duplicationCheck = true;
//			    		}
//			    	}
//			    	if (!duplicationCheck) {
//			    		rtnList.add(map);
//			    	}
//			    }
//			}
//		} catch (Exception e) {
//			e.printStackTrace();
//		}
//		return rtnList;
//	}

	/*
	 * @see emxECPartBase_mxJPO#lookupEntries(matrix.db.Context, java.lang.String[])
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	@Override
	@com.matrixone.apps.framework.ui.LookUpCallable
    public MapList lookupEntries(Context context, String[] args) throws Exception {
		
		HashMap inputMap   = (HashMap) JPO.unpackArgs(args);
		HashMap requestMap = (HashMap) inputMap.get("requestMap");
		HashMap curObjectMap;
		HashMap itemMap;

		MapList objectMapList  = (MapList) inputMap.get("objectList");
		MapList returnList = new MapList();
		MapList resultsList;

		String languageStr = (String) requestMap.get("languageStr");
		String multipleMessage = EngineeringUtil.i18nStringNow(context,"emxEngineeringCentral.MultipleError.Message", languageStr);
		String noMessage = EngineeringUtil.i18nStringNow(context,"emxEngineeringCentral.NoObject.Message", languageStr);

		SelectList objectSelect = new SelectList();
		objectSelect.addId();
		objectSelect.addName();
		objectSelect.addPolicy();
		objectSelect.addCurrentState();
		
		try{
			Iterator objectItr = objectMapList.iterator();
	
			while (objectItr.hasNext()) {
				curObjectMap = (HashMap) objectItr.next();
				String strName = DomainConstants.EMPTY_STRING;
				String strObjId = (String)curObjectMap.get("Name");
				String strParentId = (String)curObjectMap.get("ParentId");
				String strRevision = (String)curObjectMap.get("Revision");
				strObjId = (strObjId == null) ? "" : strObjId.trim();
				
				StringBuffer strBufferWhere = new StringBuffer();
				String strExists = MqlUtil.mqlCommand(context, "print bus $1 select $2 dump", new String[]{strObjId, "exists"});
				
				if("TRUE".equals(strExists)){
					strName = new DomainObject(strObjId).getInfo(context, DomainConstants.SELECT_NAME);
					strBufferWhere.append(DomainConstants.SELECT_NAME);
					strBufferWhere.append(" == ");
					strBufferWhere.append(strName);
				}else{
					strName = strObjId;
					strBufferWhere.append(DomainConstants.SELECT_NAME);
					strBufferWhere.append(" == ");
					strBufferWhere.append(strName);
				}
				
				String latestReleased = EngineeringUtil.i18nStringNow(context,"emxEngineeringCentral.Part.WhereUsedRevisionLatestReleased", languageStr);
		        String latest = EngineeringUtil.i18nStringNow(context,"emxEngineeringCentral.EBOMManualAddExisting.RevisionOption.Latest", languageStr);
		        
		        if (strRevision.equals(latestReleased)) {
		        	strBufferWhere.append(" && ((current == '"+ DomainConstants.STATE_PART_RELEASE +"' && (revision == 'last' || (next.current != '" + DomainConstants.STATE_PART_RELEASE +"' && next.current != '" + DomainConstants.STATE_PART_OBSOLETE + "'))) || (revision == 'last' && current != '" + DomainConstants.STATE_PART_OBSOLETE + "'))");
		        } else if (strRevision.equals(latest)) {
		        	strBufferWhere.append(" && (revision == 'last' && current != '" + DomainConstants.STATE_PART_OBSOLETE +"')");
		        }
				
				resultsList = DomainObject.findObjects(
	                    context,                            // eMatrix context
	                    cdmConstantsUtil.TYPE_CDMPART,		// type pattern
	                    DomainConstants.QUERY_WILDCARD,		// name pattern
	                    DomainConstants.QUERY_WILDCARD,		// revision pattern
	                    DomainConstants.QUERY_WILDCARD,     // owner pattern
	                    DomainConstants.QUERY_WILDCARD,     // vault pattern
	                    strBufferWhere.toString(),			// where expression
	                    true,								// Expand Type
	                    objectSelect);						// object selects
				
		        if (strRevision.equals(latestReleased)) { 
	            	if (resultsList != null && resultsList.size() > 0) {
	            		resultsList = getReleasedList(resultsList);
	            	}
	            }
		        
				MapList mlList = new DomainObject(strParentId).getRelatedObjects(context, 
																DomainConstants.RELATIONSHIP_EBOM, // relationship
																cdmConstantsUtil.TYPE_CDMPART,     // type
																objectSelect,     				   // objects
																null,  							   // relationships
																false,                             // to
																true,          					   // from
																(short)0,                          // recurse
																null,           				   // where
																null,                              // relationship where
																(short)0);                         // limit
				
				boolean isExists = false;
				for(int i=0; i<mlList.size(); i++){
					Map map = (Map)mlList.get(i);
					String id = (String)map.get(DomainConstants.SELECT_ID);
					if(strObjId.equals(id)){
						isExists = true;
					}
				}
	
				itemMap = new HashMap();
	
				if (resultsList != null && resultsList.size() == 1) {
					itemMap.put(DomainConstants.SELECT_ID, ((Map) resultsList.get(0)).get(DomainConstants.SELECT_ID));
				} else if (resultsList != null && resultsList.size() > 0) {
					itemMap.put("Error", multipleMessage);
				} else if (isExists) {
					itemMap.put("Error", multipleMessage);
				} else {
					itemMap.put("Error", noMessage);
				}
				returnList.add(itemMap);
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		return returnList;
	}
	
	private MapList getReleasedList(MapList list) {
		Map mapTemp = null;
		MapList listReturn = new MapList(); 
		String strCurrent;
		for (int i = 0, size = list.size(); i < size; i++) {
			mapTemp = (Map) list.get(i);
			strCurrent = getStringValue(mapTemp, DomainObject.SELECT_CURRENT);
			if (DomainConstants.STATE_PART_RELEASE.equals(strCurrent)) {
				listReturn.add(mapTemp); 
				//break;
			}
		}
		return listReturn;
	}
	
	private String getStringValue(Map map, String key) {
		return (String) map.get(key);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	@com.matrixone.apps.framework.ui.ConnectionProgramCallable
    public HashMap inlineCreateAndConnectPart(Context context, String[] args) throws Exception {

		HashMap doc = new HashMap();
		HashMap request = (HashMap) JPO.unpackArgs(args);
		HashMap paramMap = (HashMap) request.get("paramMap");
		HashMap hmRelAttributesMap;
		HashMap columnsMap;
        HashMap changedRowMap;
        HashMap returnMap;
        String sType = (String)paramMap.get("type");
        String sSymbolicName = com.matrixone.apps.framework.ui.UICache.getSymbolicName(context, sType, "type");
	    
		Map smbAttribMap;

		Element elm = (Element) request.get("contextData");

		MapList chgRowsMapList = UITableIndented.getChangedRowsMapFromElement(context, elm);
		MapList mlItems = new MapList();

		String strRelType = (String) paramMap.get("relType");
		String parentObjectId = (String) request.get("parentOID");
		String rowFormat = "";
		String CONNECT_AS_DERIVED = EnoviaResourceBundle.getProperty(context, "emxEngineeringCentral.ReplaceBOM.Derived");
        String vpmControlState = null;
        String sUser = context.getUser();String objectName = "";
        String vName = "";
        String strComponentLocation = "";
        String[] attributeKeys = { DomainConstants.ATTRIBUTE_FIND_NUMBER,
									DomainConstants.ATTRIBUTE_REFERENCE_DESIGNATOR,
									DomainConstants.ATTRIBUTE_COMPONENT_LOCATION,
									DomainConstants.ATTRIBUTE_QUANTITY,
									DomainConstants.ATTRIBUTE_USAGE,
									DomainConstants.ATTRIBUTE_NOTES };

        StringList sResultList = new StringList();
        String tokValue = "";
        String tok = "";
        String sResult ="";
        String parentBusType = "";
        BusinessType busType = null;
        if(UIUtil.isNotNullAndNotEmpty(sSymbolicName)){
        	sResult = MqlUtil.mqlCommand(context, "temp query bus $1 $2 $3 select $4 dump","eService Number Generator",sSymbolicName,"*","revision");
        	while(UIUtil.isNullOrEmpty(sResult)) { 
        		busType = new BusinessType(sType, context.getVault());
        		if (busType != null){
        			parentBusType = busType.getParent(context);
        			if (UIUtil.isNotNullAndNotEmpty(parentBusType)) {
        				sType = parentBusType;
        				sSymbolicName = com.matrixone.apps.framework.ui.UICache.getSymbolicName(context, sType, "type");
        				sResult = MqlUtil.mqlCommand(context, "temp query bus $1 $2 $3 select $4 dump","eService Number Generator",sSymbolicName,"*","revision");
        				if(UIUtil.isNotNullAndNotEmpty(sResult)) {
        					break;
        				}
        			}
        		}
        	}
        }
        
        StringTokenizer stateTok = new StringTokenizer(sResult, "\n");
        while (stateTok.hasMoreTokens()) {
        	tok = (String)stateTok.nextToken();
      	 	tokValue = tok.substring(tok.lastIndexOf(',')+1);
      	 	sResultList.add(tokValue);
       	}
        int sResultListSize = sResultList.size();
        StringList objAutoNameList = new StringList();
       
        for(int i=0; i<sResultListSize; i++){
        	objAutoNameList.add(UINavigatorUtil.getI18nString("emxEngineeringCentral.Common."+((String)sResultList.get(i)).replace(" ", ""), "emxEngineeringCentralStringResource", "en"));
        }

        boolean isENGSMBInstalled = EngineeringUtil.isENGSMBInstalled(context, false); //Commented for IR-213006

        if (isENGSMBInstalled) { //Commented for IR-213006
        	String mqlQuery = new StringBuffer(100).append("print bus $1 select $2 dump").toString();
        	vpmControlState = MqlUtil.mqlCommand(context, mqlQuery,parentObjectId,"from["+RELATIONSHIP_PART_SPECIFICATION+"|to.type.kindof["+EngineeringConstants.TYPE_VPLM_CORE_REF+"]].to.attribute["+EngineeringConstants.ATTRIBUTE_VPM_CONTROLLED+"]");
		}
        EBOMAutoSync.backupContextUserInfo(context);
        ContextUtil.pushContext(context);

		try{
			DomainObject parentObj = DomainObject.newInstance(context, parentObjectId);
			DomainObject childObj;
			DomainRelationship domRelation;
			EBOMMarkup ebomMarkup = new EBOMMarkup();

			for (int i = 0, size = chgRowsMapList.size(); i < size; i++) {
				try {
					changedRowMap = (HashMap) chgRowsMapList.get(i);

					String childObjectId = (String) changedRowMap.get("childObjectId");
					String sRelId = (String) changedRowMap.get("relId");
					String sRowId = (String) changedRowMap.get("rowId");
					rowFormat = "[rowId:" + sRowId + "]";
					String markup = (String) changedRowMap.get("markup");
					String strParam2 = (String) changedRowMap.get("param2");
					// get parameters for replace operation
					String strParam1 = (String) changedRowMap.get("param1");
					columnsMap = (HashMap) changedRowMap.get("columns");

					String strUOM = (String) columnsMap.get("UOM");
					String desc = (String) columnsMap.get("Description");
					String strUOMType = (String)columnsMap.get("UOMType");

					String sChangeControlled = (String) columnsMap.get("ChangeControlled");
					String sReleaseProcess = (String) columnsMap.get("ReleaseProcess");

					hmRelAttributesMap = getAttributes(columnsMap, attributeKeys);
					strComponentLocation = (String)columnsMap.get(DomainConstants.ATTRIBUTE_COMPONENT_LOCATION);
					if(UIUtil.isNotNullAndNotEmpty(strComponentLocation)) {
						columnsMap.put(DomainConstants.ATTRIBUTE_COMPONENT_LOCATION, StringUtils.replace(strComponentLocation,"&", "&amp;"));
					}
					String vpmVisible = "";
					// TBE
           		 	if (isENGSMBInstalled) { //Commented for IR-213006
           		 		vpmVisible = (String)columnsMap.get("VPMVisible");
           		 		//If part is not in VPM Control set the isVPMVisible value according to user selection.
						if (isValidData(vpmVisible) && !"true".equalsIgnoreCase(vpmControlState)) {
							hmRelAttributesMap.put(EngineeringConstants.ATTRIBUTE_VPM_VISIBLE, vpmVisible);
						}
           		 	}
           		 	// TBE

           		 	changedRowMap.put("parentObj", parentObj);

					if ("add".equals(markup)) {
						childObj = DomainObject.newInstance(context, childObjectId);

						changedRowMap.put("childObj", childObj);
						changedRowMap.put("strRelType", strRelType);

						domRelation = ebomMarkup.connectToChildPart(context, changedRowMap);

						if (isValidData(desc)) {
							childObj.setDescription(context, desc);
						}

						domRelation.setAttributeValues(context, hmRelAttributesMap);

						if ("true".equalsIgnoreCase(CONNECT_AS_DERIVED) && isValidData(strParam2)) {
							StringList slParamObjs = childObj.getInfoList(context, "from[" + RELATIONSHIP_DERIVED + "]." + DomainConstants.SELECT_TO_ID);

							if (slParamObjs == null || !slParamObjs.contains(strParam2)) {
								DomainRelationship doRelDerived = DomainRelationship.connect(context, new DomainObject(strParam2), RELATIONSHIP_DERIVED, childObj);
								doRelDerived.setAttributeValue(context, "attribute_DerivedContext", "Replace");
							}
						}
						
						//UOM Management : Set UOM attribute value
						if(!UIUtil.isNullOrEmpty(strUOM)) {
							domRelation.setAttributeValue(context, "cdmPartUOM", strUOM);
						}

						sRelId = domRelation.toString();
					} else if ("new".equals(markup)) {
						smbAttribMap = new HashMap();
						objectName = (String) columnsMap.get("Name");
						String objectType = (String) columnsMap.get("Type");
						//String objectRev = (String) columnsMap.get("Revision");
						String objectPolicy = (String) columnsMap.get("Policy");
						String objectVault = (String) columnsMap.get("Vault");
						String objectPartFamily = (String) columnsMap.get("Part Family");
						
						//mod by jh.Lee 16.09.22 Start
						String languageStr = (String)paramMap.get("languageStr");
						
						String strVehicle            	= (String)columnsMap.get("Vehicle");
						String strPartName 			 	= (String)columnsMap.get("PartName");
						String strProject 				= (String)columnsMap.get("Project");
						String strApprovalType 			= (String)columnsMap.get("ApprovalType");
						String strPartType 				= (String)columnsMap.get("PartType");
						String strGlobal 				= (String)columnsMap.get("Global");
						String strDrawingNo 			= (String)columnsMap.get("DrawingNo");
						String strECONumber			 	= (String)columnsMap.get("ECONumber");
						String strItemType 				= (String)columnsMap.get("ItemType");
						String strOEMItemNumber 		= (String)columnsMap.get("OEMItemNumber");
						String strOrg1 					= (String)columnsMap.get("Org1");
						String strOrg2 					= (String)columnsMap.get("Org2");
						String strOrg3 					= (String)columnsMap.get("Org3");
						String strProjectType 			= (String)columnsMap.get("ProjectType");
						String strProductType 			= (String)columnsMap.get("ProductType");
						String strERPInterface 			= (String)columnsMap.get("ERPInterface");
						String strSurface 				= (String)columnsMap.get("Surface");
						String strEstimatedWeight 		= (String)columnsMap.get("EstimatedWeight");
						String strMaterial 				= (String)columnsMap.get("Material");
						String strRealWeight 			= (String)columnsMap.get("RealWeight");
						String strSize 					= (String)columnsMap.get("Size");
						String strCADWeight 			= (String)columnsMap.get("CADWeight");
						String strSurfaceTreatment 		= (String)columnsMap.get("SurfaceTreatment");
						String strIsCasting 			= (String)columnsMap.get("IsCasting");
						String strOption1 				= (String)columnsMap.get("Option1");
						String strOption2 				= (String)columnsMap.get("Option2");
						String strOption3 				= (String)columnsMap.get("Option3");
						String strOption4 				= (String)columnsMap.get("Option4");
						String strOption5 				= (String)columnsMap.get("Option5");
						String strOption6 				= (String)columnsMap.get("Option6");
						String strOptionETC 		   	= (String)columnsMap.get("OptionETC");
						String strInvestor 			   	= (String)columnsMap.get("Investor");
						String strOptionDescription    	= (String)columnsMap.get("OptionDescription");
						String strPublishingTarget     	= (String)columnsMap.get("PublishingTarget");
						String strChangeControlled     	= (String)columnsMap.get("ChangeControlled");
						String strReferenceDesignator  	= (String)columnsMap.get("Reference Designator");
						
						String strPhase  = "Proto";
						String objectRev = "01";
						if(objectPolicy.equals(cdmConstantsUtil.TEXT_PRODUCTION)){
							objectRev = "A";
							strPhase  = "Production";
						}
						objectPolicy = cdmConstantsUtil.POLICY_CDM_PART_POLICY;
						
						if(UIUtil.isNullOrEmpty(objectVault)){
							objectVault = cdmConstantsUtil.VAULT_ESERVICE_PRODUCTION;
						}
						
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_GLOBAL            , strGlobal);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_ERP_INTERFACE     , strERPInterface);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_IS_CASTING        , strIsCasting);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_APPROVAL_TYPE     , strApprovalType);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_PHASE             , strPhase);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_DRAWING_NO        , strDrawingNo);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_ECO_NUMBER        , strGlobal);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_INVESTOR          , strInvestor);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_ITEM_TYPE         , strItemType);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_NAME              , strPartName);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_NO                , objectName);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_OEM_ITEM_NUMBER   , strOEMItemNumber);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_ETC        , strOptionETC);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_PUBLISHING_TARGET , strPublishingTarget);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_ESTIMATED_WEIGHT  , strEstimatedWeight);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_SIZE              , strSize);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_CAD_WEIGHT        , strCADWeight);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_SURFACE_TREATMENT , strSurfaceTreatment);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_REAL_WEIGHT       , strRealWeight);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_MATERIAL          , strMaterial);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_SURFACE           , strSurface);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_DESCRIPTION, strOptionDescription);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_UOM               , strUOM);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_PROJECT           , strProject);
						smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_TYPE              , strPartType);
						//mod by jh.Lee 16.09.22 End
						
						smbAttribMap.put(DomainConstants.ATTRIBUTE_ORIGINATOR, sUser);
						if(UIUtil.isNotNullAndNotEmpty(sReleaseProcess)){
							smbAttribMap.put(EngineeringConstants.ATTRIBUTE_RELEASE_PHASE, sReleaseProcess);
						}
						if(UIUtil.isNotNullAndNotEmpty(sChangeControlled)){
							smbAttribMap.put(EngineeringConstants.ATTRIBUTE_CHANGE_CONTROLLED, sChangeControlled);
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strUOMType)){
							smbAttribMap.put(EngineeringConstants.ATTRIBUTE_UOM_TYPE, strUOMType);
						}
						// TBE
						if (isENGSMBInstalled) { //Commented for IR-213006
							vName = (String)columnsMap.get("V_Name");
							if(UIUtil.isNullOrEmpty(vName)) {
       							vName = (String) columnsMap.get("V_Name1");
       						}
       						if (isValidData(vName)) {
       							smbAttribMap.put(EngineeringConstants.ATTRIBUTE_V_NAME, vName);
       						}
       						if (isValidData(vpmVisible) && !"true".equalsIgnoreCase(vpmControlState)) {
       							smbAttribMap.put(EngineeringConstants.ATTRIBUTE_VPM_VISIBLE, "TRUE");
       						}
						}
						// TBE

						// Use Part Family for naming the Part - Start
						if (isValidData(objectPartFamily)) {
							PartFamily partFamilyObject = null;
							try {
						    	partFamilyObject = new PartFamily(objectPartFamily);
						    	partFamilyObject.open(context);

						    	if (partFamilyObject.exists(context)) {
						        	// check the "Part Family Name Generator On" attribute
						    		String usePartFamilyForName = partFamilyObject.getAttributeValue(context, ATTRIBUTE_PART_FAMILY_NAME_GENERATOR_ON);

						        	if ("TRUE".equalsIgnoreCase(usePartFamilyForName)) {
						            	objectName = partFamilyObject.getPartFamilyMemberName(context);
						        	}
						    	}
							} finally {
						    	if (partFamilyObject != null) {
						        	partFamilyObject.close(context);
						    	}
							}
						}
						// Use Part Family for naming the Part - End

						childObj = DomainObject.newInstance(context);
						childObj = createchildObj(context, objectType, objectName, objectRev, objectPolicy, objectVault, childObj, objAutoNameList.contains(objectName));
						// parts created with inline had owner - user agent. removing if condition to change owner.
						childObj.setOwner(context, sUser);
						
						//mod by jh.Lee 16.09.22 Start
						String[] languageStrArray = languageStr.split(",");
						String title = cdmStringUtil.browserCommonCodeLanguage(languageStrArray[0]);
						if(UIUtil.isNotNullAndNotEmpty(strProductType)){
							DomainObject productTypeDomObj = new DomainObject(strProductType);
							DomainRelationship.connect(context, productTypeDomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PRODUCT_TYPE, childObj);
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_PRODUCT_TYPE      , productTypeDomObj.getInfo(context, title));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strProjectType)){
							DomainObject projectTypeDomObj = new DomainObject(strProjectType);
							DomainRelationship.connect(context, projectTypeDomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT_TYPE, childObj);
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_PROJECT_TYPE      , projectTypeDomObj.getInfo(context, title));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strProject)){
							DomainObject projectDomObj = new DomainObject(strProject);
							DomainRelationship.connect(context, projectDomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_PROJECT, childObj);
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_PROJECT_TYPE      , projectDomObj.getAttributeValue(context, cdmConstantsUtil.SELECT_ATTRIBUTE_CDM_PROJECT_CODE));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strDrawingNo)){
							DomainObject drawingDomObj = new DomainObject(strDrawingNo);
							try {
			    				MqlUtil.mqlCommand(context, "trigger off");
			    				DomainRelationship.connect(context, childObj, DomainConstants.RELATIONSHIP_PART_SPECIFICATION, drawingDomObj);
								smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_DRAWING_NO      , drawingDomObj.getInfo(context, DomainConstants.SELECT_NAME));
							} catch (Exception e) {
								throw e;
							}finally {
								MqlUtil.mqlCommand(context, "trigger on");
							}
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strECONumber)){
							DomainObject ecDomObj = new DomainObject(strECONumber);
							try {
			    				MqlUtil.mqlCommand(context, "trigger off");
			    				DomainRelationship.connect(context, ecDomObj, DomainConstants.RELATIONSHIP_AFFECTED_ITEM, childObj);
								smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_ECO_NUMBER      , ecDomObj.getInfo(context, DomainConstants.SELECT_NAME));
							} catch (Exception e) {
								throw e;
							}finally {
								MqlUtil.mqlCommand(context, "trigger on");
							}
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strVehicle)){
							if(strVehicle.contains("|")){
								String[] vehicleIdArray = strVehicle.split("\\|");
								StringBuffer strBuffer = new StringBuffer();
								for(int h=0; h<vehicleIdArray.length; h++){
									String id = vehicleIdArray[h];
									DomainObject obj = new DomainObject(id);
									strBuffer.append(obj.getInfo(context, title));
									if(vehicleIdArray.length-1 != h){
							    		strBuffer.append(",");	
							    	}
									DomainRelationship.connect(context, new DomainObject(id), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, childObj);
								}
								smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_VEHICLE 			   , strBuffer.toString());
							}else{
								DomainObject vehicleDomObj = new DomainObject(strVehicle);
								DomainRelationship.connect(context, vehicleDomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_VEHICLE, childObj);
								smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_VEHICLE 			   , vehicleDomObj.getInfo(context, title));
							}
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strOrg1)){
							DomainObject org1DomObj = new DomainObject(strOrg1);
							DomainRelationship domainRel = DomainRelationship.connect(context, org1DomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_ORG, childObj);
							domainRel.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_ORG_REL_ATTRIBUTE, "Org1");
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_ORG1 			   , org1DomObj.getInfo(context, title));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strOrg2)){
							DomainObject org2DomObj = new DomainObject(strOrg2);
							DomainRelationship domainRel = DomainRelationship.connect(context, org2DomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_ORG, childObj);
							domainRel.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_ORG_REL_ATTRIBUTE, "Org2");
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_ORG2 			   , org2DomObj.getInfo(context, title));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strOrg3)){
							DomainObject org3DomObj = new DomainObject(strOrg3);
							DomainRelationship domainRel = DomainRelationship.connect(context, org3DomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_ORG, childObj);
							domainRel.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_ORG_REL_ATTRIBUTE, "Org3");
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_ORG3 			   , org3DomObj.getInfo(context, title));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strOption1)){
							DomainObject option1DomObj = new DomainObject(strOption1);
							DomainRelationship domainRel = DomainRelationship.connect(context, new DomainObject(strOption1), cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, childObj);
							domainRel.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option1");
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION1           , option1DomObj.getInfo(context, title));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strOption2)){
							DomainObject option2DomObj = new DomainObject(strOption2);
							DomainRelationship domainRel = DomainRelationship.connect(context, option2DomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, childObj);
							domainRel.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option2");
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION2           , option2DomObj.getInfo(context, title));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strOption3)){
							DomainObject option3DomObj = new DomainObject(strOption3);
							DomainRelationship domainRel = DomainRelationship.connect(context, option3DomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, childObj);
							domainRel.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option3");
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION3           , option3DomObj.getInfo(context, title));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strOption4)){
							DomainObject option4DomObj = new DomainObject(strOption4);
							DomainRelationship domainRel = DomainRelationship.connect(context, option4DomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, childObj);
							domainRel.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option4");
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION4           , option4DomObj.getInfo(context, title));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strOption5)){
							DomainObject option5DomObj = new DomainObject(strOption5);
							DomainRelationship domainRel = DomainRelationship.connect(context, option5DomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, childObj);
							domainRel.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option5");
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION5           , option5DomObj.getInfo(context, title));
						}
						
						if(UIUtil.isNotNullAndNotEmpty(strOption6)){
							DomainObject option6DomObj = new DomainObject(strOption6);
							DomainRelationship domainRel = DomainRelationship.connect(context, option6DomObj, cdmConstantsUtil.RELATIONSHIP_CDM_PART_RELATION_OPTION, childObj);
							domainRel.setAttributeValue(context, cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION_REL_ATTRIBUTE, "Option6");
							smbAttribMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_OPTION6           , option6DomObj.getInfo(context, title));
						}
						//mod by jh.Lee 16.09.22 End

						if (isValidData(desc)) {
							childObj.setDescription(context, desc);
						}
						childObj.setAttributeValues(context, smbAttribMap);

                    	changedRowMap.put("childObj", childObj);
                    	changedRowMap.put("strRelType", strRelType);

                    	domRelation = ebomMarkup.connectToChildPart(context, changedRowMap);
                    	
                    	//UOM Management : Set UOM attribute value
						if(!UIUtil.isNullOrEmpty(strUOM)) {
							//mod by jh.Lee 16.09.28 End
							hmRelAttributesMap.put(cdmConstantsUtil.ATTRIBUTE_CDM_PART_EBOM_RELATION_ATTRIBUTE_UOM, strUOM);
							//mod by jh.Lee 16.09.28 End
						}
						domRelation.setAttributeValues(context, hmRelAttributesMap);

						/* Connecting Part Family with Part starts */
						if (isValidData(objectPartFamily)) {
							DomainObject PartFamilyObj = DomainObject.newInstance(context, objectPartFamily);
							DomainRelationship.connect(context, PartFamilyObj, DomainConstants.RELATIONSHIP_CLASSIFIED_ITEM, childObj);
						}
						/* Connecting Part Family with Part ends */

						//Added RDO Convergence start
						String strDefaultRDO = childObj.getAltOwner1(context).toString();
						String defaultRDOId = MqlUtil.mqlCommand(context, "temp query bus $1 $2 $3 select $4 dump $5",DomainConstants.TYPE_ORGANIZATION,strDefaultRDO,"*","id","|");
			        	defaultRDOId = defaultRDOId.substring(defaultRDOId.lastIndexOf('|')+1);
			        	DomainRelationship.connect(context,
			        								new DomainObject(defaultRDOId), // from side object Design Responsibilty
			        								DomainConstants.RELATIONSHIP_DESIGN_RESPONSIBILITY, // Relationship
			        								childObj);// toSide object Document
			        	//Added RDO Convergence End

						childObjectId = childObj.getId();
						sRelId = domRelation.toString();
					} else if ("cut".equals(markup)) {
						if (!"replace".equals(strParam1)) {
							ebomMarkup.disconnectChildPart(context, changedRowMap);
						}
					}

					returnMap = new HashMap();
					returnMap.put("pid", parentObjectId);
					returnMap.put("relid", sRelId);
					returnMap.put("oid", childObjectId);
					returnMap.put("rowId", sRowId);
					returnMap.put("markup", markup);
					objectName = (String)columnsMap.get("Name");
					if(objectName != null && !"null".equals(objectName) && !"".equals(objectName)) {
						columnsMap.put("Name", StringUtils.replace(objectName,"&", "&amp;"));
					}
					if(isENGSMBInstalled) { //Commented for IR-213006
						vName = (String)columnsMap.get("V_Name");
						if(UIUtil.isNullOrEmpty(vName)) {
       						vName = (String) columnsMap.get("V_Name1");
       					}
						if(vName != null){
							columnsMap.put("V_Name", StringUtils.replace(vName,"&", "&amp;"));
							columnsMap.put("V_Name1", StringUtils.replace(vName,"&", "&amp;"));
						}
					}
					returnMap.put("columns", columnsMap);
					mlItems.add(returnMap); // returnMap having all the

				} catch (Exception e) {
					if (e.toString().indexOf("license") > -1) {
						throw e;
					}
					throw new Exception(rowFormat + e);
				}
			}
			doc.put("Action", "success"); // Here the action can be "Success" or
			// "refresh"
			doc.put("changedRows", mlItems);// Adding the key "ChangedRows"
		} catch (Exception e) {
			doc.put("Action", "ERROR"); // If any exception is there send "Action" as "ERROR"
			if (e.toString().indexOf("license") > -1) { // If any License Issue throw the exception to user.
				doc.put("Message", rowFormat);
				throw e;
			}
			if ((e.toString().indexOf("recursion")) != -1) {
				//Multitenant
				String recursionMesssage = EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(),"emxEngineeringCentral.RecursionError.Message");
				doc.put("Message", rowFormat + recursionMesssage);
			} else if ((e.toString().indexOf("recursion")) == -1 && ((e.toString().indexOf("Check trigger")) != -1)) {
				//Multitenant
				String tnrMesssage = EnoviaResourceBundle.getProperty(context, "emxEngineeringCentralStringResource", context.getLocale(),"emxEngineeringCentral.TNRError.Message");
				doc.put("Message", rowFormat + tnrMesssage);
			} else {
				String strExcpn = e.toString();
				int j = strExcpn.indexOf(']');
			    strExcpn = strExcpn.substring(j + 1, strExcpn.length());
				doc.put("Message", rowFormat + strExcpn);
			}

		} finally {
			ContextUtil.popContext(context);
			context.removeFromCustomData(EBOMAutoSync.LOGGEDIN_USER);
		}

		return doc;

	}
    
    private boolean isValidData(String data) {
		return ((data == null || "null".equals(data)) ? 0 : data.trim().length()) > 0;
	}
    
    private HashMap getAttributes(HashMap map, String[] keys) throws Exception {
    	int length = length (keys);
   	 	HashMap mapReturn = new HashMap(length);
   	 	String data;
   	 	for (int i = 0; i < length; i++) {
   	 		data = (String)map.get(keys[i]);
   	 		if (isValidData(data)) {
   	 			mapReturn.put(keys[i], data);
   	 		}
   	 	}
   	 	return mapReturn;
    }
    
    private int length(Object[] array) {
		return array == null ? 0 : array.length;
	}
    
    
    public Boolean updateUOM(Context context, String[] args) throws Exception {
    	HashMap programMap = (HashMap)JPO.unpackArgs(args);
	    HashMap paramMap = (HashMap)programMap.get("paramMap");
	    String relId  = (String)paramMap.get("relId");
	    String newUOM = (String)paramMap.get("New Value");
	    String objectId = (String)paramMap.get("objectId");
	    if(UIUtil.isNotNullAndNotEmpty(newUOM) && "(percent)".equalsIgnoreCase(newUOM)){
	    	newUOM = EnoviaResourceBundle.getProperty(context, "emxFrameworkStringResource", context.getLocale(),"emxFramework.Range.Unit_of_Measure.%_(percent)");
	    }
		if(UIUtil.isNotNullAndNotEmpty(objectId)){
		    DomainObject domObj = new DomainObject(objectId);
		    domObj.setAttributeValue(context, "cdmPartUOM", newUOM);
		}
	    return Boolean.TRUE;
	}
    
    
}
