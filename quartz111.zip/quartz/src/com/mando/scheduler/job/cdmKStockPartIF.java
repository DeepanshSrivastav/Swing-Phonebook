package com.mando.scheduler.job;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.StringList;

@DisallowConcurrentExecution
public class cdmKStockPartIF implements Job {
	
	
	public static String CDM_FLAG_SUCCESS = "S";
	public static String CDM_FLAG_PROCESSING = "P";
	public static String CDM_FLAG_DELETED = "D";
	public static String RESULT_OK = "OK";
	public static String RESULT_FAIL = "FAIL";
	
	public static String POLICY_CDM_PART_POLICY = "cdmPartPolicy";
	public static String POLICY_CDM_EC_POLICY = "cdmECPolicy";
	public static String VAULT_ESERVICE_PRODUCTION = "eService Production";
 	
	
	org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(cdmKStockPartIF.class.getName());
	
	/**
	 * 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		
		
		log.info("!!!!!!! K-Stock IF START !!!!!!!");
	    SqlSession sqlSession = SqlSessionUtil.getSqlSession();
	    
	    try {

			Context context = ContextManager.getContext();
			
			Map paramMap = new HashMap();
			List partList = sqlSession.selectList("get_new_kstock_part", paramMap);
			
			StringList busSelect = new StringList();
			busSelect.add(DomainObject.SELECT_ID);
			
			
			for (Iterator iterator = partList.iterator(); iterator.hasNext();) {
				Map partMap  = (Map) iterator.next();
				
				
				BigDecimal OBJECT_ID = (BigDecimal) partMap.get("OBJECT_ID");
			
				try {
					String result = null;
					
					result = this.createKStockPart(context, sqlSession, partMap);
					
					if(RESULT_OK.equals(result)) {
						//update flag 
						paramMap = new HashMap();
						paramMap.put("CDM_FLAG", CDM_FLAG_SUCCESS);
						paramMap.put("OBJECT_ID", OBJECT_ID);
						
						sqlSession.update("update_flag_after_create_kstock_part", paramMap);
						sqlSession.commit();
					}
				} catch (Exception e) {
					log.debug("error", e);
					e.printStackTrace();
				}
				
			}
	    	
		
	    } catch (Exception e) {
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
	}
	
	
	/**
	 * 
	 * @param context
	 * @param sqlSession
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public String createKStockPart(Context context, SqlSession sqlSession, Map objectMap) throws Exception {
		
		try {

			Map partMap = objectMap;
			
			//BigDecimal OBJECT_ID = (BigDecimal) partMap.get("OBJECT_ID");
			//String CARTYPE = (String) partMap.get("CARTYPE");

			String strEONo = (String) partMap.get("EONO");
			
			String strPartNo = (String) partMap.get("ITEMNUMBER");
			String strPartName = (String) partMap.get("ITEMNAME");
			String strPartRevision = (String) partMap.get("VERSION");
			String strCreator = (String) partMap.get("CFGCREATOR");

			String strProduct = (String) partMap.get("PRODUCT");
			String strMeterial = (String) partMap.get("MATERIAL");
			
			String strPartType= "cdmMechanicalPart";
			
			BusinessObject busPartObj = new BusinessObject(strPartType, strPartNo, strPartRevision, VAULT_ESERVICE_PRODUCTION);
			if (busPartObj.exists(context)) {
				return RESULT_FAIL;
			}
			
			ContextUtil.startTransaction(context, true);
			
			DomainObject partObj = new DomainObject();

			log.info(">>>>>>>>> Create K-Stock Part");

			ContextUtil.pushContext(context, null, null, null);
			MqlUtil.mqlCommand(context, "trigger off", new String[] {});

			partObj.createObject(context, strPartType, strPartNo, strPartRevision, POLICY_CDM_PART_POLICY, VAULT_ESERVICE_PRODUCTION);

			log.info("Part [" + strPartNo + "] has been created.");
			
			MqlUtil.mqlCommand(context, "trigger on", new String[]{});
        	ContextUtil.popContext(context);
			

			Map partAttrMap = new HashMap();
			partAttrMap.put("cdmPartName", strPartName);
			partAttrMap.put("cdmPartMaterial", strMeterial);
			partAttrMap.put("cdmPartPhase", "Production");
			
			partObj.setAttributeValues(context, partAttrMap);

			String strECTitle = "Temporary ECO for K-Stock.";
			
			DomainObject domECObj = new DomainObject();
			domECObj.createObject(context, "cdmECO", strEONo, "-", POLICY_CDM_EC_POLICY, "eService Production");
			domECObj.setAttributeValue(context, "Title", strECTitle);
			
			DomainRelationship.connect(context, domECObj, "Affected Item", partObj);
			
			//modify owner
			String isPerson = MqlUtil.mqlCommand(context, "print bus Person '" + strCreator + "' - select exists dump");
			if ("true".equalsIgnoreCase(isPerson)) {
				partObj.setOwner(context, strCreator);
				domECObj.setOwner(context, strCreator);
			}
			
			
			MqlUtil.mqlCommand(context, "trigger off;");
			//set up Security Context.
			MqlUtil.mqlCommand(context, "mod bus " + partObj.getObjectId(context) + " project '" + strProduct + "'  organization 'Mando' ;");

			partObj.setState(context, "Release");
			domECObj.setState(context, "Release");

			MqlUtil.mqlCommand(context, "trigger on;");

			ContextUtil.commitTransaction(context);
			return RESULT_OK;

		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			e.printStackTrace();
			
			log.debug("error", e);
			throw e;
			
		}
	}
	
}
