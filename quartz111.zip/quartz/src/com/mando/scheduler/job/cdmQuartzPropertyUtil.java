package com.mando.scheduler.job;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

public class cdmQuartzPropertyUtil {
		
	public static Properties getPropFile( String sFileName ) throws IOException, ClassNotFoundException {
		Properties prop = new Properties();

	    File inputFile           = new File(sFileName);
	    InputStream inputStream  = new FileInputStream(inputFile);
		prop.load( inputStream );
		inputStream.close();
		return prop;
	}

	public static String getPropValue(Properties prop, String sName ){
		String sRet = "";
		try {
			sRet = (String) prop.get( sName );
		} catch( Exception e ) {
			
		}
		return StringUtils.defaultString(sRet);
	}
		
	public static String getPropValue( String sFileName, String sName ){
		String sRet = "";
		try {
			sRet = ( String )getPropFile( sFileName ).get( sName );
		} catch( Exception e ) {
			
		}
		return StringUtils.defaultString(sRet);
	}

}
