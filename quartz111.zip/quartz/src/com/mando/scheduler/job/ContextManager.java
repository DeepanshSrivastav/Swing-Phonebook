package com.mando.scheduler.job;

import java.util.Properties;

import org.apache.commons.lang3.StringUtils;

import matrix.db.Context;

public class ContextManager {

	
	/**
	 * 
	 * @return
	 * @throws Exception
	 */
	public static Context getContext()throws Exception{
		
		Context context = null;
		try{
			
			Properties prop = new Properties();
			prop.load(ContextManager.class.getClassLoader().getResourceAsStream("com/mando/scheduler/job/config.properties"));
			String user = prop.getProperty("CDM_USER");
			String pwd = prop.getProperty("CDM_USER_PASSWORD");
			String cdmUrl = StringUtils.EMPTY; //prop.getProperty("CDM_URL");
			
			context = new Context(cdmUrl);
			
			context.setUser(user);
			context.setPassword(pwd);
			//context.setRole("ctx::VPLMProjectAdministrator.Mando.Default");
			context.connect();
			
			
			
		}catch(Exception e){
			e.printStackTrace();
			throw e;
		}
		return context;
	}
	
}
