package com.mando.scheduler.job;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.Pattern;
import matrix.util.StringList;


public class ECHandler {

	public static final int SUCCESS = 0;
	public static final int READY = 1;
	
	
	org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(ECHandler.class.getName());
	
	/**
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public int releaseEC(Context context, String[] args) throws Exception {
		int result = READY;
		try {
			
			ContextUtil.startTransaction(context, true);
			
			
			String strECName = args[0];
			StringList objectSelects = new StringList();
			objectSelects.add(DomainObject.SELECT_ID);
			

			//MapList mlEco = DomainObject.findObjects(context, "cdmPEO", strECName, strWhere, objectSelects);
			
			MapList mlEco = DomainObject.findObjects(context, "ECO",
					strECName, "*", "*", "*", "",
                    true, objectSelects);
			
			

			String strECId = null;;
			for (int i = 0; i < mlEco.size();) {
				Map objMap = (Map) mlEco.get(i);
				strECId = (String) objMap.get(DomainObject.SELECT_ID);
				break;
			}

			if (StringUtils.isNotEmpty(strECId)) {

				DomainObject doEC = new DomainObject(strECId);
				
				log.info("Start Release EO :: " + doEC.getInfo(context, "name"));
				
				this.promotePartDocument(context, strECId, "Release");
				doEC.setState(context, "Release");
				
				log.info("Release EO OK :: " + doEC.getInfo(context, "name"));
				
			}

			ContextUtil.commitTransaction(context);

			result = SUCCESS;
			
		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			e.printStackTrace();
			throw e;
		}
		
		return result;
	}
	
	/**
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public int rejectEC(Context context, String[] args) throws Exception {
		int result = READY;
		try {
			
			ContextUtil.startTransaction(context, true);
			
			String strECName = args[0];
			StringList objectSelects = new StringList();
			objectSelects.add(DomainObject.SELECT_ID);
			
			
			//MapList mlEco = DomainObject.findObjects(context, strType, strECName, strWhere, objectSelects);
			
			MapList mlEco = DomainObject.findObjects(context, "ECO",
					strECName, "*", "*", "*", "",
                    true, objectSelects);
			
			String strECId = null;
			for (int i = 0; i < mlEco.size();) {
				Map objMap = (Map) mlEco.get(i);
				strECId = (String) objMap.get(DomainObject.SELECT_ID);
				break;
			}
			
			if (StringUtils.isNotEmpty(strECId)) {
				
				
				DomainObject doEC = new DomainObject(strECId);
				log.info("Start REJECT EO :: " + doEC.getInfo(context, "name"));
				
				this.demotePartDocumentToInWork(context, strECId);
				
				doEC.setState(context, "Preliminary");
				
				log.info("REJECT EO OK :: " + doEC.getInfo(context, "name"));
			}
			
			ContextUtil.commitTransaction(context);
			result = SUCCESS;
			
		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			throw e;
		}
		return result;
	}
	
	
	
	/**
	 * 
	 * @param context
	 * @param args
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public int obsoleteEC(Context context, String[] args) throws Exception {
		int result = READY;
		try {
			
			ContextUtil.startTransaction(context, true);
			
			String strECName = args[0];
			StringList objectSelects = new StringList();
			objectSelects.add(DomainObject.SELECT_ID);
			
			
			//MapList mlEco = DomainObject.findObjects(context, strType, strECName, strWhere, objectSelects);
			
			MapList mlEco = DomainObject.findObjects(context, "ECO",
					strECName, "*", "*", "*", "",
                    true, objectSelects);
			
			String strECId = null;
			for (int i = 0; i < mlEco.size();) {
				Map objMap = (Map) mlEco.get(i);
				strECId = (String) objMap.get(DomainObject.SELECT_ID);
				break;
			}
			
			if (StringUtils.isNotEmpty(strECId)) {
				
				DomainObject doEC = new DomainObject(strECId);

				String strOrgEONo = doEC.getInfo(context, "name");
				String strDeletedEONo = strOrgEONo + "-D";

				log.info("Start DELETE EO :: " + strOrgEONo);

				this.demotePartDocumentToInWork(context, strECId);

				MqlUtil.mqlCommand(context, "trigger off", new String[] {});

				log.info("change state to 'Obsolete' ");

				doEC.setState(context, "Obsolete");

				log.info("rename eo no with suffix '-D'");
				MqlUtil.mqlCommand(context, "mod bus $1 name $2", strECId, strDeletedEONo);

				MqlUtil.mqlCommand(context, "trigger on", new String[] {});

				log.info("DELETE EO OK :: " + strOrgEONo);
			}
			
			ContextUtil.commitTransaction(context);
			result = SUCCESS;

		} catch (Exception e) {
			ContextUtil.abortTransaction(context);
			throw e;
		}
		return result;
	}
	
	
	
	
	
	
	/**
	 * promote EC, Part, CAD Model and Drawings.
	 * 
	 * @param context
	 * @param strECId
	 * @param actionType 'Review' or 'Release'
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void promotePartDocument(Context context, String strECId, String actionType) throws Exception {

		try {

			StringList selectStmts = new StringList();
			selectStmts.add(DomainConstants.SELECT_ID);
			selectStmts.add("to[" + DomainConstants.RELATIONSHIP_EBOM + "].from.id");
			StringList selectRel = new StringList();
			selectRel.add(DomainRelationship.SELECT_LEVEL);

			Pattern typePattern = new Pattern("");
			typePattern.addPattern("cdmPart");
			typePattern.addPattern("DOCUMENTS");

			Pattern relPattern = new Pattern("");
			relPattern.addPattern(DomainConstants.RELATIONSHIP_AFFECTED_ITEM);
			relPattern.addPattern(DomainConstants.RELATIONSHIP_PART_SPECIFICATION);
			relPattern.addPattern("Associated Drawing");

			DomainObject eoObj = new DomainObject(strECId);
			MapList mlEbomPartList = eoObj.getRelatedObjects(context, relPattern.getPattern(), // relationship
																		typePattern.getPattern(), // type
																		selectStmts, 			// objects
																		selectRel, 			// relationships
																		false, 			// to
																		true, 			// from
																		(short) 3, 			// recurse
																		null, 			// where
																		null, 			// relationship where
																		(short) 0); 		// limit

			// Document has to be place prior to Part
			mlEbomPartList.sort(DomainRelationship.SELECT_LEVEL, "decending", "integer");

			for (int i = 0; i < mlEbomPartList.size(); i++) {
				Map mPartMap = (Map) mlEbomPartList.get(i);

				String strObjectId = (String) mPartMap.get(DomainConstants.SELECT_ID);
				DomainObject doObject = new DomainObject(strObjectId);

				// if object is a kind of Drawing, CAD
				if (doObject.isKindOf(context, "DOCUMENTS")) {

					
					ContextUtil.pushContext(context);
					MqlUtil.mqlCommand(context, "trigger off", new String[] {});
					

					if ("Review".equals(actionType)) {
						
						MqlUtil.mqlCommand(context, "unlock bus $1", strObjectId);
						doObject.setState(context, "FROZEN");
						
					} else if ("Release".equals(actionType)) {
					
						doObject.setState(context, "RELEASED");
						
					}
					
					MqlUtil.mqlCommand(context, "trigger on", new String[] {});
					ContextUtil.popContext(context);

					// if object is a kind of Part
				} else {

					String strPartId = strObjectId;
					String strHighLankPartId = MqlUtil.mqlCommand(context, "print bus $1 select $2 dump", new String[] { strPartId, "to[" + DomainConstants.RELATIONSHIP_EBOM + "].from.id" });

					DomainObject partObj = new DomainObject(strPartId);

					ContextUtil.pushContext(context);
					MqlUtil.mqlCommand(context, "trigger off", new String[] {});

					if ("Review".equals(actionType))
						partObj.setState(context, "Review");

					else if ("Release".equals(actionType))
						partObj.setState(context, "Release");

					MqlUtil.mqlCommand(context, "trigger on", new String[] {});
					ContextUtil.popContext(context);

					if ("Release".equals(actionType)) {

						BusinessObject strPreviousRev = partObj.getPreviousRevision(context);
						if (!"..".equals(strPreviousRev.toString())) {

							String strPreviousObjectId = strPreviousRev.getObjectId(context);
							String strPreviousObjectHighLankIds = StringUtils.trimToEmpty(MqlUtil.mqlCommand(context, "print bus $1 select $2 dump ", new String[] { strPreviousObjectId, "to[" + DomainConstants.RELATIONSHIP_EBOM + "].from.id" }));

							if (!DomainConstants.EMPTY_STRING.equals(strPreviousObjectHighLankIds)) {
								String[] strPreviousObjectHighLankIdArray = strPreviousObjectHighLankIds.split(",");
								String strPreviousObjectHighLankId = DomainConstants.EMPTY_STRING;
								String strPreviousObjectHighLankRelId = DomainConstants.EMPTY_STRING;
								for (int k = 0; k < strPreviousObjectHighLankIdArray.length; k++) {
									strPreviousObjectHighLankId = strPreviousObjectHighLankIdArray[k]; // strPreviousObjectHighLankId
									strPreviousObjectHighLankRelId = StringUtils.trimToEmpty(MqlUtil.mqlCommand(context, "print bus $1 select $2 dump ", new String[] { strPreviousObjectId, "to[" + DomainConstants.RELATIONSHIP_EBOM + "].id" }));
									if (strPreviousObjectHighLankId.equals(strHighLankPartId) && !DomainConstants.EMPTY_STRING.equals(strPreviousObjectHighLankRelId)) {
										MqlUtil.mqlCommand(context, "mod connection $1 type $2 ", new String[] { strPreviousObjectHighLankRelId, DomainConstants.RELATIONSHIP_EBOM_HISTORY });
									}
								}
							}
						}
					}
				}
			}

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	/**
	 * demote EO state to In-Work(Preliminary) when EO is rejected from PLM.
	 * @param context
	 * @param strECId
	 * @throws Exception
	 */
	@SuppressWarnings("rawtypes")
	public void demotePartDocumentToInWork(Context context, String strECId) throws Exception {

		try {

			StringList selectStmts = new StringList();
			selectStmts.add(DomainConstants.SELECT_ID);
			
			
			StringList selectRel = new StringList();
			//selectRel.add(DomainRelationship.SELECT_LEVEL);

			Pattern typePattern = new Pattern("");
			typePattern.addPattern("cdmPart");
			typePattern.addPattern("DOCUMENTS");

			Pattern relPattern = new Pattern("");
			relPattern.addPattern(DomainConstants.RELATIONSHIP_AFFECTED_ITEM);
			relPattern.addPattern(DomainConstants.RELATIONSHIP_PART_SPECIFICATION);
			relPattern.addPattern("Associated Drawing");

			
			// EC -> Part -> 3D -> 2D
			// or
			// EC -> Part -> 2D
			
			DomainObject eoObj = new DomainObject(strECId);
			MapList mlEbomPartList = eoObj.getRelatedObjects(context, relPattern.getPattern(), // relationship
																		typePattern.getPattern(), // type
																		selectStmts, // objects
																		selectRel, // relationships
																		false, // to
																		true, // from
																		(short) 3, // recurse
																		null, // where
																		null, // relationship where
																		(short) 0); // limit

			// Document has to be place prior to Part
			mlEbomPartList.sort(DomainRelationship.SELECT_LEVEL, "decending", "integer");

			
			
			try {
				ContextUtil.pushContext(context);
				MqlUtil.mqlCommand(context, "trigger off", new String[] {});
				
				
				
				for (int i = 0; i < mlEbomPartList.size(); i++) {
					Map mPartMap = (Map) mlEbomPartList.get(i);

					String strObjectId = (String) mPartMap.get(DomainConstants.SELECT_ID);
					DomainObject doObject = new DomainObject(strObjectId);


					// if object is a kind of Part
					if (doObject.isKindOf(context, DomainConstants.TYPE_PART)) {
						
						doObject.setState(context, "Preliminary");

						// if object is a kind of Drawing, CAD
					} else {
						doObject.setState(context, "IN_WORK");
					}
				}
				
				
			} catch (Exception e) {
				throw e;
			} finally {
				MqlUtil.mqlCommand(context, "trigger on", new String[] {});
				ContextUtil.popContext(context);
			}
			

		} catch (Exception e) {
			e.printStackTrace();
			throw e;
		}
	}

	


	
}
