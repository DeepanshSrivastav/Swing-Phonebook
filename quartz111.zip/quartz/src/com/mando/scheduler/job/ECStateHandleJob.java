package com.mando.scheduler.job;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import matrix.db.Context;

@DisallowConcurrentExecution
public class ECStateHandleJob implements Job {
	
	
	public static String CDM_FLAG_SUCCESS = "S";
	public static String CDM_FLAG_PROCESSING = "P";
	public static String CDM_FLAG_DELETED = "D";
	
	
	org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(ECStateHandleJob.class.getName());
	
	/**
	 * 
	 */
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		
		log.info("!!!!! Run ECStateHandleJob !!!!!");
		
	    SqlSession sqlSession = SqlSessionUtil.getSqlSession();
	    try {
	    	Context context = ContextManager.getContext();
	    	

	    	// Review -> Release (Approved) 
	    	this.approveEC(context, sqlSession);

	    	// Review -> Obsolete (Deleted)
	    	this.deleteEC(context, sqlSession);

	    	// Review -> In-Work (Rejected)
	    	this.rejectEC(context,  sqlSession);
	    	
	    	
		} catch (Exception e) {
			e.printStackTrace();
			log.debug("error", e);
		} finally {
			sqlSession.close();
		}
	}
	
	
	/**
	 * 
	 * @param context
	 * @param sqlSession
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void approveEC(Context context, SqlSession sqlSession) throws Exception {
		try {
			
			Map paramMap = new HashMap();
			Map paramMap1 = new HashMap();
			List listOfApproved = sqlSession.selectList("get_approved_ec", paramMap);
			
			for (Iterator iterator = listOfApproved.iterator(); iterator.hasNext();) {
				String strECONo = (String) iterator.next();
				
				try {

					log.info("approve ec ::::::::::::: " + strECONo);
					
					String[] args = new String[]{strECONo};
					ECHandler handler = new ECHandler();
					int result = handler.releaseEC(context, args);
					//int result = (Integer)JPO.invoke(context, "cdmEC", null, "releaseEC", args, Integer.class);
					
					
					log.info("approve ec result ::::::::::::: " + strECONo);

					if(result == ECHandler.SUCCESS) {
						//update flag 
						paramMap = new HashMap();
						paramMap.put("CDM_FLAG", CDM_FLAG_SUCCESS);
						paramMap.put("EO_NUMBER", strECONo);
						
						sqlSession.update("update_flag_after_release_ec", paramMap);
						
						
						//update ECPART flag 
						paramMap1 = new HashMap();
						paramMap1.put("STATUS", "RELEASED");
						paramMap1.put("EONO", strECONo);
						
						sqlSession.update("update_flag_after_release_part", paramMap1);
						
						sqlSession.commit();
					}
				} catch (Exception e) {
					e.printStackTrace();
					log.debug("error", e);
				}
				
				
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * @param context
	 * @param sqlSession
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void deleteEC(Context context, SqlSession sqlSession) throws Exception {
		try {
			Map paramMap = new HashMap();
			List listOfDeleted = sqlSession.selectList("get_deleted_ec", paramMap);
			
			for (Iterator iterator = listOfDeleted.iterator(); iterator.hasNext();) {
				String strECONo = (String) iterator.next();
				
				
				// Deleted EO has Name suffix -D like 'PKA17CS001-D'
				strECONo = strECONo.replaceAll("\\-D$", "");

				try {
					
					String[] args = new String[]{strECONo};
					
					ECHandler handler = new ECHandler();
					int result = handler.obsoleteEC(context, args);
					

					if(result == ECHandler.SUCCESS) {
						//update flag 
						paramMap = new HashMap();
						paramMap.put("CDM_FLAG", CDM_FLAG_DELETED);
						paramMap.put("EO_NUMBER", strECONo+"-D");
						
						sqlSession.update("update_cdm_flag_ec", paramMap);
						sqlSession.commit();

					}
				} catch (Exception e) {
					e.printStackTrace();
					log.debug("error", e);
				}

			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	
	
	/**
	 * 
	 * @param context
	 * @param sqlSession
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void rejectEC(Context context, SqlSession sqlSession) throws Exception {
		try {
			Map paramMap = new HashMap();
			List listOfRejected = sqlSession.selectList("get_rejected_ec", paramMap);
			
			for (Iterator iterator = listOfRejected.iterator(); iterator.hasNext();) {
				String strECONo = (String) iterator.next();
				
				try {
					
					String[] args = new String[]{strECONo};
					ECHandler handler = new ECHandler();
					int result = handler.rejectEC(context, args);


					if(result == ECHandler.SUCCESS) {
						//update flag 
						paramMap = new HashMap();
						paramMap.put("CDM_FLAG", CDM_FLAG_PROCESSING);
						paramMap.put("EO_NUMBER", strECONo);
						
						sqlSession.update("update_cdm_flag_ec", paramMap);
						sqlSession.commit();
					}
				} catch (Exception e) {
					e.printStackTrace();
					log.debug("error", e);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		
	}
	
	public static void main(String[] args) throws JobExecutionException {
		ECStateHandleJob  job = new ECStateHandleJob();
		job.execute(null);
	}
	
	
	
	
}
