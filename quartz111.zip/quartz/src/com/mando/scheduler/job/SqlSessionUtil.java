package com.mando.scheduler.job;

import java.io.InputStream;

import org.apache.ibatis.io.Resources;
import org.apache.ibatis.session.SqlSession;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.ibatis.session.SqlSessionFactoryBuilder;

public class SqlSessionUtil {
	private final static String resource = "org/mybatis/config/mybatis-config.xml";
	private static SqlSessionFactory sqlSessionFactory;
	
	static {
        try {
			InputStream inputStream = Resources.getResourceAsStream(SqlSessionUtil.resource);
			
			if(sqlSessionFactory == null)
				sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
    }
	
	public static SqlSession getSqlSession() {
		return SqlSessionUtil.sqlSessionFactory.openSession();
	}
	
//	public static void reNew() {
//		reNew(null);
//	}
	
//	public static void reNew(String environmentName) {
//		try {
//			InputStream inputStream = Resources.getResourceAsStream(SqlSessionUtil.resource);
//			if(environmentName == null || environmentName.equals("")){
//				SqlSessionUtil.sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream);
//			}else{
//				SqlSessionUtil.sqlSessionFactory = new SqlSessionFactoryBuilder().build(inputStream, environmentName);
//			}
//		} catch (IOException e) {
//			e.printStackTrace();
//		}
//	}
	
}

