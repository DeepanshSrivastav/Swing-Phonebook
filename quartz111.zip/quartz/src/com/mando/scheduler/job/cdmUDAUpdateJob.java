package com.mando.scheduler.job;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.FrameworkUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.Context;
import matrix.util.SelectList;
import matrix.util.StringList;

@DisallowConcurrentExecution
public class cdmUDAUpdateJob implements Job {

	private static String STR_CDM_PART 				= "cdmPart";
	private static String STR_CDM_COMMON_CODE 		= "cdmCommonCode";
	private static String STR_ESERVICE_PRODUCTION 	= "eService Production";
	private static String STR_ATTRIBUTE_COMMON_CODE_KO 	= "attribute[cdmCommonCodeNameKo]";
	private static String STR_ATTRIBUTE_COMMON_CODE_EN 	= "attribute[cdmCommonCodeNameEn]";
	private static String STR_ATTRIBUTE_COMMON_CODE_CN 	= "attribute[cdmCommonCodeNameCn]";
	private static String STR_RELATIONSHIP_CDM_PART_RELATION_VEHICLE = "cdmPartRelationVehicle";
	
	
	org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(cdmUDAUpdateJob.class.getName());
	
	
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		
		log.info("Run Update UDA Job");
	    
		SqlSession sqlSession = null;
		
	    try {
	    	Context context = ContextManager.getContext();
	    	String displayTitle = browserCommonCodeLanguage(context.getSession().getLanguage());
		    sqlSession = SqlSessionUtil.getSqlSession();
		    
		    Map paramMap = new HashMap();
	        List<Map<String, String>> udaDataList = sqlSession.selectList("select_UDA_Data", paramMap);
	        int iUDAListSize = udaDataList.size();
	        
	        SelectList selectList = new SelectList();
	        selectList.add(DomainConstants.SELECT_ID);
	        
	    	
	        for(int i=0; i<iUDAListSize; i++){
	        	
	        	Map udaMap = (Map)udaDataList.get(i);
	        	String strPartNo           = (String)udaMap.get("ITEMNUMBER");
	        	String strPartName         = (String)udaMap.get("ITEMNAME");
	        	String strPartRevision     = (String)udaMap.get("VERSION");
	        	String strPartEONo   	   = (String)udaMap.get("EONO");
	        	String strPartCarType      = (String)udaMap.get("CARTYPE");
	        	String strPartCustomerId   = (String)udaMap.get("CUSTOMER_ID");
	        	
	        	String strOption1    = (String)udaMap.get("OPTION1");
	        	String strOption2    = (String)udaMap.get("OPTION2");
	        	String strOption3    = (String)udaMap.get("OPTION3");
	        	String strOption4    = (String)udaMap.get("OPTION4");
	        	String strOption5    = (String)udaMap.get("OPTION5");
	        	String strOption6    = (String)udaMap.get("OPTION6");
	        	String strOption7    = (String)udaMap.get("OPTION7");
	        	String strOption8    = (String)udaMap.get("OPTION8");
	        	String strOption9    = (String)udaMap.get("OPTION9");
	        	String strOption10   = (String)udaMap.get("OPTION10");
	        	          
	        	String strOption11   = (String)udaMap.get("OPTION11");
	        	String strOption12   = (String)udaMap.get("OPTION12");
	        	String strOption13   = (String)udaMap.get("OPTION13");
	        	String strOption14   = (String)udaMap.get("OPTION14");
	        	String strOption15   = (String)udaMap.get("OPTION15");
	        	String strOption16   = (String)udaMap.get("OPTION16");
	        	String strOption17   = (String)udaMap.get("OPTION17");
	        	String strOption18   = (String)udaMap.get("OPTION18");
	        	String strOption19   = (String)udaMap.get("OPTION19");
	        	String strOption20   = (String)udaMap.get("OPTION20");
	        	
	        	
	        	String strMqlValue = StringUtils.trimToEmpty(MqlUtil.mqlCommand(context, "temp query bus $1 $2 $3 select $4 $5 $6 dump $7", new String[] {STR_CDM_PART, strPartNo, strPartRevision, "id", "name", "revision", "|"}));  
	            
	        	if(! DomainConstants.EMPTY_STRING.equals(strMqlValue)){
	        		
	        		StringTokenizer valueTokens = new StringTokenizer(strMqlValue, "\n", false);
		            
		            while(valueTokens.hasMoreTokens()) {
		            	
		                String resultToken = valueTokens.nextToken();
		               	StringList resultList = FrameworkUtil.split(resultToken, "|");
		               	String strPartObjectId = StringUtils.trimToEmpty((String)resultList.get(3));
		               	String strPartObjectName = StringUtils.trimToEmpty((String)resultList.get(4));
		               	String strPartObjectRevision = StringUtils.trimToEmpty((String)resultList.get(5));
		               	
		               	if(! DomainConstants.EMPTY_STRING.equals(strPartObjectId)){
		               		
		               		DomainObject domObj = new DomainObject(strPartObjectId);
		               		
		               		
		               		HashMap attributes = new HashMap();
		                	attributes.put("cdmPartOEMItemNumber"	, 	 strPartCustomerId);                       
		                    attributes.put("cdmPartOption1"			,    strOption1);     
		                    attributes.put("cdmPartOption2"			,    strOption2);   
		                    attributes.put("cdmPartOption3"			,    strOption3);     
		                    attributes.put("cdmPartOption4"			,    strOption4);
		                    attributes.put("cdmPartOption5"			,    strOption5);     
		                    attributes.put("cdmPartOption6"			,    strOption6);
		                    attributes.put("cdmPartOption7"			,    strOption7);     
		                    attributes.put("cdmPartOption8"			,    strOption8);
		                    attributes.put("cdmPartOption9"			,    strOption9);     
		                    attributes.put("cdmPartOption10"		,    strOption10);
		                    attributes.put("cdmPartOption11"		,    strOption11);     
		                    attributes.put("cdmPartOption12"		,    strOption12);
		                    attributes.put("cdmPartOption13"		,    strOption13);     
		                    attributes.put("cdmPartOption14"		,    strOption14);
		                    attributes.put("cdmPartOption15"		,    strOption15);     
		                    attributes.put("cdmPartOption16"		,    strOption16);
		                    attributes.put("cdmPartOption17"		,    strOption17);     
		                    attributes.put("cdmPartOption18"		,    strOption18);
		                    attributes.put("cdmPartOption19"		,    strOption19);     
		                    attributes.put("cdmPartOption20"		,    strOption20);
		                    domObj.setAttributeValues(context, attributes);
		                    
		                    
		                    String[] strPartCarTypeArray = strPartCarType.split(";");
		                    
		                    for(int k=0; k<strPartCarTypeArray.length; k++){
		                    	
		                    	String strVehicle = strPartCarTypeArray[k];
		                    	
		                    	MapList mlVehicleList = DomainObject.findObjects(context, 
		                    														STR_CDM_COMMON_CODE, 
		                    														"*", 
		                    														"-", 
		                    														"*", 
		                    														STR_ESERVICE_PRODUCTION, 
		                    														displayTitle + "=='"+strVehicle+"'",
		                    														"",
		                    														true, 
		                    														selectList, 
		                    														(short)0 );
		                    	
		                    	if(mlVehicleList.size() > 0){
		                    		
		                    		StringList relVehicleIdList = domObj.getInfoList(context, "to["+STR_RELATIONSHIP_CDM_PART_RELATION_VEHICLE+"].id");
		                			
		                    		if(relVehicleIdList.size() > 0 && ! "".equals(relVehicleIdList)){
		                    			
		                				for(int j=0; j<relVehicleIdList.size(); j++){
		                					
		                					DomainRelationship.disconnect(context, relVehicleIdList.get(j).toString());
		                					
		                				}
		                				
		                			}
		                			
		                			for(int h=0; h<mlVehicleList.size(); h++){
			                    		
			                    		Map vehicleMap = (Map)mlVehicleList.get(h);
			                    		String strVehicleObjectId = (String) vehicleMap.get(DomainConstants.SELECT_ID);
			                    		
			                    		DomainRelationship.connect(context, new DomainObject(strVehicleObjectId), STR_RELATIONSHIP_CDM_PART_RELATION_VEHICLE, new DomainObject(strPartObjectId) );
			                    		
			                    	}
		                			
		                    	}
		                    	
		                    }
		                    
		                    Map updateUDAMap = new HashMap();
					        updateUDAMap.put("ITEMNUMBER"	, 	strPartObjectName);
					        updateUDAMap.put("VERSION"		, 	strPartObjectRevision);
							sqlSession.update("update_UDA"	, 	updateUDAMap);
		               		
		               	}
		               	
		            }
		            
	        	}
	        	
	        }
		    
		    sqlSession.commit();
		    
	    }catch(Exception e){
	    	e.printStackTrace();
	    	sqlSession.rollback();
	    	log.debug("error", e);
	    	
	    }finally {
	    	sqlSession.close();
		}

	}
	
	
	static public String browserCommonCodeLanguage(String languageStr) {
    	String displayTitle = "";
    	String firstLang = languageStr.split("-")[0];
    	if ("ko".equals(firstLang)) {
    		displayTitle = STR_ATTRIBUTE_COMMON_CODE_KO;
    	}else if ("en".equals(firstLang)) {
    		displayTitle = STR_ATTRIBUTE_COMMON_CODE_KO;
    	}else if ("zh".equals(firstLang)) {
    		displayTitle = STR_ATTRIBUTE_COMMON_CODE_KO;
    	}else{
    		displayTitle = STR_ATTRIBUTE_COMMON_CODE_KO;
    	}
        return displayTitle;
    }
	    
	
	    
}
