package com.mando.scheduler.job;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.DomainRelationship;
import com.matrixone.apps.domain.util.ContextUtil;
import com.matrixone.apps.domain.util.MapList;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.BusinessObject;
import matrix.db.Context;
import matrix.util.StringList;

@DisallowConcurrentExecution
public class cdmElectronicPartIF implements Job {
	
	
	public static String CDM_FLAG_SUCCESS = "S";
	public static String CDM_FLAG_PROCESSING = "P";
	public static String CDM_FLAG_DELETED = "D";
	public static String RESULT_OK = "OK";
	public static String RESULT_FAIL = "FAIL";
	
	
	public static String Type_ElectronicAssemblyPart = "cdmElectronicAssemblyPart";
	public static String Type_ElectronicPart = "cdmElectronicPart";
	public static String POLICY_CDM_PART_POLICY = "cdmPartPolicy";
	public static String VAULT_ESERVICE_PRODUCTION = "eService Production";
	
	
	
	
	org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(cdmElectronicPartIF.class.getName());
	
	/**
	 * 
	 */
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		
		
		log.info("!!!!!!! ElectronicPart IF START !!!!!!!");

		
	    SqlSession sqlSession = SqlSessionUtil.getSqlSession();
	    
	    try {
	    	

			Context context = ContextManager.getContext();
			
			Map paramMap = new HashMap();
			List partList = sqlSession.selectList("get_new_electronic_part", paramMap);
			
			StringList busSelect = new StringList();
			busSelect.add(DomainObject.SELECT_ID);
			
			
			for (Iterator iterator = partList.iterator(); iterator.hasNext();) {
				Map partMap  = (Map) iterator.next();
				
				
				
				BigDecimal OBJECT_ID = (BigDecimal) partMap.get("OBJECT_ID");
				String REQTYPE = (String) partMap.get("REQTYPE");   // NEW, REVISE, INACTIVE
 
			
				try {
				
					String result = null;
					
					if("NEW".equals(REQTYPE) || "REVISE".equals(REQTYPE)) {
						
						result = this.createOrReviseElectroicPart(context, sqlSession, partMap);
						
					} else if ("INACTIVE".equals(REQTYPE)) {
						
						result = this.obsoleteElectroicPart(context, sqlSession, partMap);
					} 
					
					
		
					
					
					if(RESULT_OK.equals(result)) {
						//update flag 
						paramMap = new HashMap();
						paramMap.put("CDM_FLAG", CDM_FLAG_SUCCESS);
						paramMap.put("OBJECT_ID", OBJECT_ID);
						
						sqlSession.update("update_flag_after_create_part", paramMap);
						sqlSession.commit();
					}
				} catch (Exception e) {
					log.debug("error", e);
					e.printStackTrace();
				}
				
			}
	    	
		
	    } catch (Exception e) {
			e.printStackTrace();
		} finally {
			sqlSession.close();
		}
	}
	
	
	/**
	 * 
	 * @param context
	 * @param sqlSession
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked", "deprecation" })
	public String createOrReviseElectroicPart(Context context, SqlSession sqlSession, Map objectMap) throws Exception {
		try {
			
			

			Map partMap = objectMap;
			
			BigDecimal OBJECT_ID = (BigDecimal) partMap.get("OBJECT_ID");
			String BOARDASSYYN = (String) partMap.get("BOARDASSYYN");
			String EONO = (String) partMap.get("EONO");

			String PARENTCLASSCODE = (String) partMap.get("PARENTCLASSCODE");
			String PARENTCLASSNAME = (String) partMap.get("PARENTCLASSNAME");
			String EMPLOYEE_NUMBER = (String) partMap.get("EMPLOYEE_NUMBER");

			String ITEMDESC = (String) partMap.get("ITEMDESC"); // eg: Resistor Thick Film 1mΩ 0.5% 1005 1/16W -55~85°C N 1
			String REQTYPE = (String) partMap.get("REQTYPE");   // NEW, REVISE, INACTIVE
			
			
			String strPartNo = (String) partMap.get("ITEMNUMBER");
			String strPartName = (String) partMap.get("ITEMNAME");
			String strPartRevision = (String) partMap.get("VERSION");;
			
			String strPartType = null;
			
			if("Y".equalsIgnoreCase(BOARDASSYYN)) {
				strPartType= Type_ElectronicAssemblyPart;
			} else {
				strPartType = Type_ElectronicPart;
			}
			
			
			BusinessObject busPartObj = new BusinessObject(strPartType, strPartNo, strPartRevision, VAULT_ESERVICE_PRODUCTION);
			if(busPartObj.exists(context)) {
				return RESULT_FAIL;
			}
			
			
			ContextUtil.startTransaction(context, true);
			
			
			DomainObject partObj = new DomainObject();

			if("NEW".equals(REQTYPE)) {

				log.info(">>>>>>>>> Create Electronic Part");
				
				ContextUtil.pushContext(context, null, null, null);
	        	MqlUtil.mqlCommand(context, "trigger off", new String[]{});	
	        	
				partObj.createObject(context, strPartType, strPartNo, strPartRevision, POLICY_CDM_PART_POLICY, VAULT_ESERVICE_PRODUCTION);
				
				
				
				log.info("Part [" + strPartNo + "] has been created.");
				
				
				MqlUtil.mqlCommand(context, "trigger on", new String[]{});
	        	ContextUtil.popContext(context);
				
				// find part family and connect REL.
				StringList busSelect = new StringList();
				busSelect.add(DomainObject.SELECT_ID);
				
				
				String strPfCodeName = PARENTCLASSCODE + ":" + PARENTCLASSNAME;
				String strObjWhere = "attribute[cdmPartFamilyBlockCodeName] == \"" + strPfCodeName + "\"";

				MapList mlPFList = DomainObject.findObjects(context, "Part Family",
						"*", "*", "*", "*", strObjWhere,
	                    				true, busSelect);

				
				if (mlPFList.size() > 0) {
					Map pfMap = (Map) mlPFList.get(0);

					String strPFOid = (String) pfMap.get(DomainObject.SELECT_ID);

					log.info(">>>>>>>>> Connect Part Family.");
					
					DomainObject doPartFamily = new DomainObject(strPFOid);
					DomainRelationship.connect(context, doPartFamily, "Classified Item", partObj);
				}
				
				
				
				
				
			} else if("REVISE".equals(REQTYPE)) {
				
				BusinessObject busPart = new BusinessObject(strPartType, strPartNo, "A", VAULT_ESERVICE_PRODUCTION);
				
				if(busPart.exists(context)) {
					
					DomainObject doFirstRevPart = new DomainObject(busPart);
					BusinessObject doLastPart = doFirstRevPart.getLastRevision(context);
					String strOwner = doFirstRevPart.getInfo(context, "owner");
					
					log.info(">>>>>>>>> Revise Part");
					
					ContextUtil.pushContext(context, null, null, null);
					MqlUtil.mqlCommand(context, "trigger off", new String[]{});
					
					BusinessObject busPartRev = doLastPart.revise(context, strPartRevision, VAULT_ESERVICE_PRODUCTION);
					partObj = new DomainObject(busPartRev);
					
					MqlUtil.mqlCommand(context, "mod bus $1 $2 $3", new String[] {partObj.getObjectId(context), "owner", strOwner});
					
					MqlUtil.mqlCommand(context, "trigger on", new String[]{});
					ContextUtil.popContext(context);
					
					log.info("Part [" + strPartNo + "] has been revised.");
					
				}
			}
			

			Map partAttrMap = new HashMap();
			partAttrMap.put("cdmSpecificationExpr", ITEMDESC);
			partAttrMap.put("cdmPartName", strPartName);
			partAttrMap.put("cdmPartPhase", "Production");

			String strSpecification = "";
			if (Type_ElectronicPart.equals(strPartType)) {

				Map paramMap = new HashMap();
				paramMap.put("PARENT_OBJECT_ID", OBJECT_ID);

				List specList = sqlSession.selectList("get_part_specification", paramMap);

				for (Iterator iterator2 = specList.iterator(); iterator2.hasNext();) {
					Map specMap = (Map) iterator2.next();

					String SPEC_NAME = (String) specMap.get("SPEC_NAME");
					String SPEC_VALUE = (String) specMap.get("SPEC_VALUE");
					String strPec = SPEC_NAME + " : " + SPEC_VALUE;

					strSpecification = strSpecification + strPec + "\n";

				}
				partAttrMap.put("cdmSpecification", strSpecification);
			}

			
			EMPLOYEE_NUMBER = EMPLOYEE_NUMBER.toUpperCase();
			
			String isPerson = MqlUtil.mqlCommand(context, "print bus Person '" + EMPLOYEE_NUMBER + "' - select exists dump");
			if ("true".equalsIgnoreCase(isPerson)) {
				partObj.setOwner(context, EMPLOYEE_NUMBER);
			}
			
			partObj.setAttributeValues(context, partAttrMap);

			
			
			MqlUtil.mqlCommand(context, "trigger off;");
			
			
			//set up Security Context.
			MqlUtil.mqlCommand(context, "mod bus "+partObj.getObjectId(context)+ " project 'OrCAD'  organization 'Mando' ;");

			
			if (Type_ElectronicPart.equals(strPartType)) {
				log.info(">>>>>>>>> Promote Part.");
				partObj.setState(context, "Release");
			}
			
			MqlUtil.mqlCommand(context, "trigger on;");

			
			
			
			if (Type_ElectronicAssemblyPart.equals(strPartType) && StringUtils.isNotEmpty(EONO)) {

				log.info(">>>>>>>>> Start Connecting ECO to Part.");

				
				StringList busSelect = new StringList();
				busSelect.add(DomainObject.SELECT_ID);
				
				
				String strObjWhere = "";
				MapList mlECList = DomainObject.findObjects(context, "ECO", EONO, "*", "*", "*", strObjWhere, true,
						busSelect);

				if (mlECList.size() > 0) {
					Map ecoMap = (Map) mlECList.get(0);
					String strEcoId = (String) ecoMap.get(DomainObject.SELECT_ID);
					DomainObject doEco = new DomainObject(strEcoId);

					DomainRelationship.connect(context, doEco, "Affected Item", partObj);
				}
			}

			ContextUtil.commitTransaction(context);
			
			return RESULT_OK;
			
		} catch (Exception e) {
			
			ContextUtil.abortTransaction(context);
			e.printStackTrace();
			
			log.debug("error", e);
			throw e;
			
		}
	}
	
	
	/**
	 * 
	 * @param context
	 * @param sqlSession
	 * @throws Exception
	 */
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String obsoleteElectroicPart(Context context, SqlSession sqlSession, Map objectMap) throws Exception {
		
		try {
			
			Map partMap = objectMap;
			String BOARDASSYYN = (String) partMap.get("BOARDASSYYN");
			
			
			String strPartNo = (String) partMap.get("ITEMNUMBER");;
			String strPartRevision = (String) partMap.get("VERSION");;
			
			String strPartType = null;

			
			if("Y".equalsIgnoreCase(BOARDASSYYN)) {
				strPartType= Type_ElectronicAssemblyPart;
			} else {
				strPartType = Type_ElectronicPart;
			}

			
			DomainObject partObj = new DomainObject();
		
			BusinessObject busPart = new BusinessObject(strPartType, strPartNo, strPartRevision, VAULT_ESERVICE_PRODUCTION);
			if (busPart.exists(context)) {
				
				partObj = new DomainObject(busPart);
				partObj.setState(context, "Obsolete");
			}
			
			return RESULT_OK;
			
		} catch (Exception e) {
			e.printStackTrace();
			log.debug("error", e);
			throw e;
		}
	}
	
}
