package com.mando.scheduler.job;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.jdom.Document;
import com.matrixone.jdom.Element;
import com.matrixone.jdom.xpath.XPath;

import matrix.db.Context;

@DisallowConcurrentExecution
public class cdmMandoStepFileConvertJob implements Job {
	
	private static final String resourceSyncTemplate = "SyncTemplate.seeb";
	private static final String FTPProperties = "FTP.properties";
	private static final String exeFile = "c:\\Program Files\\Dassault Systemes\\CATIAComposer\\7.2\\Bin\\ComposerSync.exe";
	
	private static String PLM_FTP_SERVER     = DomainConstants.EMPTY_STRING;
	private static String PLM_FTP_ID         = DomainConstants.EMPTY_STRING;
	private static String PLM_FTP_PASSWORD   = DomainConstants.EMPTY_STRING;
	
	
	org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(cdmUDAUpdateJob.class.getName());
	
	

	@SuppressWarnings("unchecked")
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
		System.out.println("!!!!!!! 3D STEP FILE JOB START !!!!!!!");
		
	    SqlSession sqlSession = SqlSessionUtil.getSqlSession();
	    try {
	    	Context context = this.getContext();
	    	Map paramMap = new HashMap();
	    	String strCurrentDate = new SimpleDateFormat("yyyyMMddhhmm").format(new Date());
	    	List<Map<String, String>> list = sqlSession.selectList("get3DStepFileMap", paramMap);
	    	
	    	String strWorkspace = context.createWorkspace();
	    	directoryFile(strCurrentDate, strWorkspace);
	    	
	    	Properties prop = new Properties();
			prop = cdmQuartzPropertyUtil.getPropFile(cdmMandoStepFileConvertJob.class.getResource("").getPath() + FTPProperties);
			
            if(prop != null){
            	PLM_FTP_SERVER    =  prop.getProperty(PLM_FTP_SERVER);
            	PLM_FTP_ID        =  prop.getProperty(PLM_FTP_ID);
            	PLM_FTP_PASSWORD  =  prop.getProperty(PLM_FTP_PASSWORD);
            }
            
            int iListSize = list.size();
	    	for(int i=0; i<iListSize; i++){
	    		Map map = (Map)list.get(i);
	    		//{FILE_3D_STP=S1207122-[ONEBODY-FRONT_WHEEL](OUT)-140703.stp}
	    		String str3dStepFileName = StringUtils.trimToEmpty((String)map.get("FILE_3D_STP"));
	    		System.out.println("str3dStepFileName     :     "+str3dStepFileName);
	    		
	    		if(! DomainConstants.EMPTY_STRING.equals(str3dStepFileName)){
		    		
		    		cdmQuartzFTPUtil.FTPFileDownload(PLM_FTP_SERVER, PLM_FTP_ID, PLM_FTP_PASSWORD, strWorkspace + java.io.File.separator + strCurrentDate, str3dStepFileName);
		    		
		    		File dFile = new File(strWorkspace + java.io.File.separator + strCurrentDate +java.io.File.separator + str3dStepFileName);
		    		
		    		if(dFile.length() > 0){
		    			
		    			java.io.File srcXMLFile = new java.io.File(resourceSyncTemplate);
						String templateFilePath = makeTemplate(context, resourceSyncTemplate, strWorkspace, resourceSyncTemplate);
						java.io.File XMLFile = new java.io.File(templateFilePath);
						
				        com.matrixone.jdom.input.SAXBuilder builder = new com.matrixone.jdom.input.SAXBuilder();
				        com.matrixone.jdom.Document docXML = builder.build(XMLFile);
				        com.matrixone.jdom.Element mxRootElement = docXML.getRootElement();
				        Element templateElement = (Element) XPath.selectSingleNode(mxRootElement, "//SeemageBatch");
				        
				        Element elementFile = null;
				        Element elFile = templateElement.getChild("ListFiles");
				        elementFile = new Element("File");
				        elementFile.addContent(strWorkspace + java.io.File.separator + str3dStepFileName);
				        elFile.addContent(elementFile);
				        
				        Element properties = (Element) XPath.selectSingleNode(mxRootElement, "//SeemageBatch//Properties");
				        Element logFilePath = properties.getChild("Batch.LogFilePath");
				        logFilePath.setAttribute("Value", strWorkspace + java.io.File.separator + "SyncLog.xml");
				        
				        write(docXML, XMLFile);
				        //write(docXML, new java.io.File(path + java.io.File.separator + folderName + java.io.File.separator + XMLFile.getName() ));
				    
				    	String strLine = null;
				        StringBuilder sb = new StringBuilder();
				        String XmlString = "";
				        
				        BufferedReader bfReader = new BufferedReader(new InputStreamReader(new FileInputStream(XMLFile), "UTF-8"));
				        while ((strLine = bfReader.readLine()) != null) {
				            sb.append(strLine.trim());
				        }
				        XmlString = sb.toString();
				        XmlString = XmlString.replaceAll("<\\?.+\\?>", "").trim();
				        
				        str3dStepFileName = str3dStepFileName.substring(0, str3dStepFileName.lastIndexOf("."));
				        String strReplaceFile = strWorkspace + java.io.File.separator + str3dStepFileName + ".seeb";
				        FileWriter out = new FileWriter(strReplaceFile);
				        out.write(XmlString);
				        out.flush();
				        out.close();
				        
				    	try {
				        	Process p = Runtime.getRuntime().exec("\""+ exeFile + "\" -batch " + strReplaceFile + " -verbose:no");
				            
				            BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()));
				            String line = null;
				            while ((line = br.readLine()) != null) {
				            }
				        	Path file = Paths.get(strWorkspace + java.io.File.separator + str3dStepFileName + ".smg");
				        	Path movePath = Paths.get(strWorkspace + java.io.File.separator + strCurrentDate);
				        	Files.move(file, movePath.resolve(file.getFileName()));
				        	
				        } catch (Exception e) {
				            System.err.println(e);
				        } 
				    	
				    	//파일 변환 완료 되면 PLM 변환서버 FTP Upload
						cdmQuartzFTPUtil.FTPFileUpload(PLM_FTP_SERVER, PLM_FTP_ID, PLM_FTP_PASSWORD, strWorkspace + java.io.File.separator + strCurrentDate, "/FILE/PLM_File/");
						
						removeAllFiles(strWorkspace + java.io.File.separator + strCurrentDate);
						removeAllFiles(strWorkspace);
						
		    		}
	    		}
	    	}
	    	
	    }catch (Exception e) {
	    	e.printStackTrace();
	    	log.debug("error", e);
		}finally {
			sqlSession.close();
		}
	}
	
	public void directoryFile(String folderName, String filePath) {
		 
        String path = filePath+"/"+folderName;
        File dir = new File(path);
        if (!dir.exists()) { 
            dir.mkdirs();
        }
        
    }
	
	private void removeAllFiles(String strDirPath) {

        File tmpDir = null;
        File tmpFile = null;
        File[] tmpFiles = null;

        try {

            tmpDir = new File(strDirPath);

            // 지우려는 디렉토리가 존재하는 경우
            if(tmpDir != null && tmpDir.exists()) {

                // 하위의 요소(파일,디렉토리)를 가져온다.
                tmpFiles = tmpDir.listFiles();

                if(tmpFiles != null) {

                    for(int i=0; i < tmpFiles.length; i++) {

                        tmpFile = new File(strDirPath + "\\" + tmpFiles[i].getName());
                        tmpFile.delete();
                    }
                    
                    File f = new File(strDirPath);
        			f.delete();
                }
            }

        } catch(Exception e) {
            e.printStackTrace();
        } finally {
            tmpDir = null;
            tmpFile = null;
            tmpFiles = null;
        }

    }
	
	public void write(Document document, File file) {
		try {
			com.matrixone.jdom.output.XMLOutputter xmlOutput = new com.matrixone.jdom.output.XMLOutputter();
			com.matrixone.jdom.output.Format format = com.matrixone.jdom.output.Format.getPrettyFormat();
			format.setEncoding("UTF-8");
            
			//BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(new File("C:\\TEST!!!!!!!!!!!!!!!.seeb")), "UTF-8"));
			BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(file), "UTF-8"));
			xmlOutput.setFormat(format);
			xmlOutput.output(document, bufferedWriter);
			bufferedWriter.flush();
			bufferedWriter.close();
		} catch(Exception e) {
		    e.printStackTrace();
		}
	}
	
	public static String makeTemplate(Context context, String strFullPath, String strCopyFilePath, String strCopyFileName) throws Exception {
	    File in = null;
	    File out = null;
	    String strReturnFileFullPath = "";
	    try{
	    	String strTempFilePath = strCopyFilePath;
	    	strReturnFileFullPath = strTempFilePath + File.separator + strCopyFileName;
	    	 
	    	in = new File(strFullPath);
	    	out = new File(strTempFilePath  + File.separator + strCopyFileName);
			
			/* 복사할 파일의 내용을 읽어들여 원하는 디렉토리에 파일 복사 */
	        FileInputStream fis = new FileInputStream(in);
	        FileOutputStream fos = new FileOutputStream(out);
	
	        byte[] buf = new byte[1024];
	        int i = 0;
	
	        while( (i = fis.read(buf)) != -1){
	            fos.write(buf, 0, i);
	        }
	
	        fis.close();
	        fos.close();
	
	        return strReturnFileFullPath;
	    } catch(IOException ioe) {
	        throw ioe;
	    }
	}
	
	public Context getContext()throws Exception{
		Context context = new Context("");
		try{
			String user = "admin_platform";
			String pwd = "Qwer1234";
			
			context.setUser(user);
			context.setPassword(pwd);
			context.connect();
			
		}catch(Exception e){
			e.printStackTrace();
		}
		return context;
	}
	
	public static void main(String[] args) {
		
		try {
			//cdmConvertJob job = new cdmConvertJob();
			//job.execute(null);
			//Path file = Paths.get("c:/TEST.txt");
	        //Path movePath = Paths.get("c:/TEST/");
	        //Files.move(file, movePath.resolve(file.getFileName()));
	        
			//File tmpFile = new File("C:\\enoviaV6R2016x\\server\\workspace\\mx64e644900dec1e12581184f8\\SyncTemplate.seeb");
            //tmpFile.delete();
			
            //File f = new File("C:\\enoviaV6R2016x\\server\\workspace\\mx64e644900dec1e12581184f8");
			//f.delete();
		} catch (Exception e) {
			e.printStackTrace();
		} 
	}
	
	
}
