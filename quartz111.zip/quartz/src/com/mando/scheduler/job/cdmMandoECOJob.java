package com.mando.scheduler.job;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.apache.ibatis.session.SqlSession;
import org.quartz.DisallowConcurrentExecution;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.dassault_systemes.enovia.e6wv2.foundation.db.ContextUtil;
import com.matrixone.apps.domain.DomainConstants;
import com.matrixone.apps.domain.DomainObject;
import com.matrixone.apps.domain.util.MqlUtil;

import matrix.db.Context;

@DisallowConcurrentExecution
public class cdmMandoECOJob implements Job {
	

	private String TYPE_EAR = "cdmEAR";
	private String TYPE_ECO = "cdmECO";
	private String TYPE_PEO = "cdmPEO";
	private String EAR_FLAG = "N";
	private String ECO_FLAG = "Y";
	private String PEO_FLAG = "P";
	private String PAR_FLAG = "NP";
	
	private String STR_NO = "No";
	private String STR_EC_POLICY = "cdmECPolicy";
	private String STR_ESERVICE_PRODUCTION = "eService Production";
	private String STR_EC_CATEGORY_ONLY_CDM_ATTRIBUTE = "cdmECCategoryOnlyCDM";
	
	
	
	org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(cdmMandoECOJob.class.getName());
	
	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {

		
		log.debug("!!!!!!! EC CREATE START !!!!!!!");
		Context context = null;
	    SqlSession sqlSession = null;
	    try {
	    	context = ContextManager.getContext();
	        Map paramMap = new HashMap();
	        
	        
	        
	        MqlUtil.mqlCommand(context, "trigger off", new String[]{});
	        
	        sqlSession = SqlSessionUtil.getSqlSession();
	        
	        SimpleDateFormat sdFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.US);
	    	List<Map<String, String>> list = sqlSession.selectList("getECOMap", paramMap);
	    	
	    	String strType = null;
	    	String strPolicy = STR_EC_POLICY;
	    	
	    	
    		
			for (int i = 0; i < list.size(); i++) {
				
	    		Map map = (Map)list.get(i);
	    		String strEcoId = null;
	    		String strECONo = null;
	    		
	    		String strProductGrp = (String) map.get("PRODUCT_GRP");
	    		
	    		try {
	    			
	    			
	    			
	    			strECONo = (String)map.get("EO_NUMBER");
					String mqlValue = MqlUtil.mqlCommand(context, "temp query bus $1 $2 $3 select $4 dump", "ECO", strECONo, "*", "id");
					if (StringUtils.isNotEmpty(mqlValue))
						continue;
					
					
					

					String strEOTypeFlag = (String) map.get("EO_EAR");
					String strECMCreator = (String) map.get("EO_USER");
					Date dCreationDate = (Date) map.get("PLM_CREATION_DATE");

					String strECOTitle = (String) map.get("EO_TITLE");
					
					
					
					//String strChangeDesc = (String) map.get(STR_CHANGE_DESC);
		    		//String strOrg1          = (String)map.get(STR_ORG1);
		    		//String strEAR           = (String)map.get(STR_EAR);
		    	    //String strECMCreateDate = sdFormat.format(strDate);
		    	    
		    		HashMap attributes = new HashMap();
					attributes.put(DomainConstants.ATTRIBUTE_TITLE, strECOTitle);
					attributes.put(STR_EC_CATEGORY_ONLY_CDM_ATTRIBUTE, STR_NO);
	    			
					if (EAR_FLAG.equals(strEOTypeFlag)) {
						strType = TYPE_EAR;
					} else if (ECO_FLAG.equals(strEOTypeFlag)) {
						strType = TYPE_ECO;
					} else if (PEO_FLAG.equals(strEOTypeFlag) || PAR_FLAG.equals(strEOTypeFlag)) {
						strType = TYPE_PEO;
					} else {
						continue;
					}
		    		
					
					
					
					//ContextUtil.startTransaction(context, true);
					
					
					
					
					DomainObject domObj = new DomainObject();
					domObj.createObject(context, strType, strECONo, "-", strPolicy, STR_ESERVICE_PRODUCTION);
					domObj.setAttributeValues(context, attributes);

					strEcoId = domObj.getObjectId(context);
					
					//domObj.setDescription(context, strChangeDesc);
		    		//System.out.println("strECMCreateDate     :     "+strECMCreateDate);//2006-03-14 14:12:52
		    		
					sdFormat.applyPattern("M/d/yyyy hh:mm:ss a");
					String strFormatDate = sdFormat.format(dCreationDate);
		    		
					strECMCreator = strECMCreator.toUpperCase();
		    		String strPersonExists = MqlUtil.mqlCommand(context, "print bus $1 $2 $3 select $4 dump", new String[] {"Person", strECMCreator, "-", "exists"});
		    		if("TRUE".equalsIgnoreCase(strPersonExists)){
		    			MqlUtil.mqlCommand(context, "mod bus $1 $2 $3 $4 $5", new String[] {strEcoId, "originated", strFormatDate, "owner", strECMCreator});
		    		}else{
		    			MqlUtil.mqlCommand(context, "mod bus $1 $2 $3", new String[] {strEcoId, "originated", strFormatDate});
		    		}
		    		
					//ContextUtil.commitTransaction(context);
					
					paramMap = new HashMap();
					paramMap.put("CDM_FLAG", ECStateHandleJob.CDM_FLAG_PROCESSING);
					paramMap.put("EO_NUMBER", strECONo);
					sqlSession.update("update_flag_after_create_ec", paramMap);
					sqlSession.commit();
					
			    	
			    	log.info("********************************");
			    	log.info("EO has been created : " + strECONo);
			    	log.info("********************************");
			    	
			    	
			    	
				} catch (Exception e) {
					//ContextUtil.abortTransaction(context);
					e.printStackTrace();
					
					log.debug("----------------------------------");
					log.debug("Error EO No : " + strECONo);
					log.debug("----------------------------------");
					
					log.debug("error", e);
				} // end try
	    		
	    		
	    		
//				try {
//					
//					MqlUtil.mqlCommand(context, "mod bus " + strEcoId + " project '" + strProductGrp + "'  organization 'Mando' ;");
//				} catch (Exception e) {
//					log.debug("----------------------------------");
//					log.debug("Error EO No : " + strECONo);
//					log.debug("----------------------------------");
//					log.debug("error", e);
//				}	    		
	    		
	    	} //end for

			
			MqlUtil.mqlCommand(context, "trigger on", new String[]{});
			
			
			
	    	
		} catch (Exception e) {
			e.printStackTrace();
			ContextUtil.abortTransaction(context);
			sqlSession.rollback();
		} finally {
			sqlSession.close();
		}
	}
	
	
}
