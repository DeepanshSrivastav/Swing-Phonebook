/* 
 * All content copyright Terracotta, Inc., unless otherwise indicated. All rights reserved. 
 * 
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not 
 * use this file except in compliance with the License. You may obtain a copy 
 * of the License at 
 * 
 *   http://www.apache.org/licenses/LICENSE-2.0 
 *   
 * Unless required by applicable law or agreed to in writing, software 
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT 
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the 
 * License for the specific language governing permissions and limitations 
 * under the License.
 * 
 */

package com.mando.scheduler.server;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import org.apache.log4j.xml.DOMConfigurator;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.Scheduler;
import org.quartz.SchedulerFactory;
import org.quartz.impl.StdSchedulerFactory;

import com.mando.scheduler.job.ECStateHandleJob;
import com.mando.scheduler.job.cdmElectronicPartIF;
import com.mando.scheduler.job.cdmKStockPartIF;
import com.mando.scheduler.job.cdmMandoECOJob;
import com.mando.scheduler.job.cdmUDAUpdateJob;


public class CronTriggerServer {
	
	static {
		DOMConfigurator.configure("log4j.xml");
	}
	org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(CronTriggerServer.class.getName());
	
	
	
	public void run() throws Exception {
		SchedulerFactory sf = new StdSchedulerFactory();
		Scheduler sched = sf.getScheduler();
		try {
			
			
			
			
			
			log.info("------- Initializing -------------------");
			
			
//			JobDetail job = newJob(SampleJob.class).withIdentity("SampleJob", "group1").build();
//			log.info("------- Scheduling SampleJob ----------------");
//			CronTrigger trigger = newTrigger().withIdentity("trigger1", "group1").withSchedule(cronSchedule(SchedulerConstants.PERIOD_EVERYDAY_10S)).build();
//			log.info("------- Scheduling trigger1 ----------------");
//			Date ft = sched.scheduleJob(job, trigger);
			
			
			//ECO Job
			
			log.info("------- Scheduling trigger1 ----------------");
			
			CronTrigger trigger1 = newTrigger().withIdentity("trigger1", "group1").withSchedule(cronSchedule(SchedulerConstants.PERIOD_EVERYDAY_1M_REPEAT)).build();//0/1
			CronTrigger trigger2 = newTrigger().withIdentity("trigger2", "group2").withSchedule(cronSchedule(SchedulerConstants.PERIOD_EVERYDAY_1M_REPEAT)).build();//0/1
			CronTrigger trigger3 = newTrigger().withIdentity("trigger3", "group3").withSchedule(cronSchedule(SchedulerConstants.PERIOD_EVERYDAY_1M_REPEAT)).build();//0/1
			CronTrigger trigger4 = newTrigger().withIdentity("trigger4", "group4").withSchedule(cronSchedule(SchedulerConstants.PERIOD_EVERYDAY_1M_REPEAT)).build();//0/1
			CronTrigger trigger5 = newTrigger().withIdentity("trigger5", "group5").withSchedule(cronSchedule(SchedulerConstants.PERIOD_EVERYDAY_1M_REPEAT)).build();//0/1
			
			log.info("------- Scheduling trigger1 ----------------");
			
			
			JobDetail ecoJob = newJob(cdmMandoECOJob.class).withIdentity("cdmMandoECOJob", "group1").build();
			sched.scheduleJob(ecoJob, trigger1);
			
			JobDetail ecStateHadleJob = newJob(ECStateHandleJob.class).withIdentity("ECStateHandleJob", "group2").build();
			sched.scheduleJob(ecStateHadleJob, trigger2);
			
			JobDetail udaUpdateJob = newJob(cdmUDAUpdateJob.class).withIdentity("cdmUDAUpdateJob", "group3").build();
			sched.scheduleJob(udaUpdateJob, trigger3);

			JobDetail electronicPartIf = newJob(cdmElectronicPartIF.class).withIdentity("cdmElectronicPartIF", "group4").build();
			sched.scheduleJob(electronicPartIf, trigger4);
			
			JobDetail kstockPartIF = newJob(cdmKStockPartIF.class).withIdentity("cdmKStockPartIF", "group4").build();
			sched.scheduleJob(kstockPartIF, trigger5);
			
			sched.start();
	
//			log.info(job.getKey() + " has been scheduled to run at: " + ft + " and repeat based on expression: " + trigger.getCronExpression());
			

		} catch (Exception e) {
			e.printStackTrace();
			log.debug("", e);
		}
	}
	
	

	public static void main(String[] args) throws Exception {
		CronTriggerServer example = new CronTriggerServer();
		example.run();
	}

}
